import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0477
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r15801 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.var 4)))))))) (.var 1))
theorem reject15801 : ¬ Reader r15801 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.app (.var 1) (.var 3))))), (.lam (.lam (.lam (.app (.var 1) (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15801
def r15802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 3) (.lam (.var 2)))))))) (.var 1))
theorem reject15802 : ¬ Reader r15802 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.app (.var 2) (.lam (.var 2))))), (.lam (.lam (.app (.var 2) (.lam (.var 2))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15802
def r15803 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.var 4)))))))) (.var 1))
theorem reject15803 : ¬ Reader r15803 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.app (.var 1) (.lam (.var 3))))), (.lam (.lam (.app (.var 1) (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15803
def r15804 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))) (.var 1))
theorem reject15804 : ¬ Reader r15804 := by
  exact replay_absent true [] 7 1 (by decide +kernel) (by decide +kernel)
#print axioms reject15804
def r15805 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.lam (.var 2))))) (.var 1))
theorem reject15805 : ¬ Reader r15805 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[8,9],[],[],[],[],[]] [[],[],[],[],[],[],[7],[],[8,9],[0],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.lam 7 (.app (.app (.var 1 [6]) (.var 1 [6]) [7]) (.lam 8 (.var 1 [8,9]) [8]) []) [7]) [6]) [7]) (.lam 9 (.var 2 [0]) [9]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15805
def r15806 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2))))))) (.var 1)))) (.var 1))
theorem reject15806 : ¬ Reader r15806 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[0,8],[],[],[],[],[]] [[],[],[],[],[],[],[7],[],[9],[0,8],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.lam 7 (.app (.app (.var 1 [6]) (.var 1 [6]) [7]) (.lam 8 (.lam 9 (.var 2 [0,8]) [9]) [8]) []) [7]) [6]) [7]) (.var 1 [0]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15806
def r15807 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.lam (.lam (.var 0)))))) (.var 1))
theorem reject15807 : ¬ Reader r15807 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)) [] [(.lam (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15807
def r15808 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.lam (.var 0)))))))))) (.var 1))
theorem reject15808 : ¬ Reader r15808 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.app (.var 2) (.lam (.var 0)))))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15808
def r15809 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.lam (.var 1)))))))))) (.var 1))
theorem reject15809 : ¬ Reader r15809 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.app (.var 1) (.lam (.lam (.var 1)))))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15809
def r15810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 2)))))))))) (.var 1))
theorem reject15810 : ¬ Reader r15810 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.app (.var 0) (.lam (.lam (.lam (.var 2)))))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15810
def r15811 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.lam (.var 0)))))))))) (.var 1))
theorem reject15811 : ¬ Reader r15811 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 5) (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 3) (.lam (.var 0)))))))) [(.lam (.lam (.app (.var 2) (.lam (.var 0))))), (.lam (.lam (.app (.var 2) (.lam (.var 0)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15811
def r15812 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.lam (.var 1)))))))))) (.var 1))
theorem reject15812 : ¬ Reader r15812 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.lam (.var 1))))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.lam (.lam (.var 1)))))))))) (.lam (.app (.var 2) (.lam (.lam (.var 1)))))))) [(.lam (.app (.var 1) (.lam (.lam (.var 1))))), (.lam (.app (.var 1) (.lam (.lam (.var 1)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15812
def r15813 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.lam (.var 2)))))))))) (.var 1))
theorem reject15813 : ¬ Reader r15813 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.lam (.var 2))))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.lam (.lam (.var 2)))))))))) (.app (.var 1) (.lam (.lam (.lam (.var 2)))))))) [(.app (.var 0) (.lam (.lam (.lam (.var 2))))), (.app (.var 0) (.lam (.lam (.lam (.var 2)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15813
def r15814 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15814 : ¬ Reader r15814 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.var 0)), (.lam (.lam (.var 2)))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15814
def r15815 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.lam (.var 3))))))) (.var 1))
theorem reject15815 : ¬ Reader r15815 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.var 1))), (.lam (.var 1))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15815
def r15816 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 2))))) (.var 2)))))) (.var 1))
theorem reject15816 : ¬ Reader r15816 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.lam (.var 2)))), (.var 0)] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15816
def r15817 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 2))))))))) (.var 1))
theorem reject15817 : ¬ Reader r15817 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.var 0), (.lam (.lam (.lam (.var 2))))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15817
def r15818 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.lam (.var 1)))))))) (.var 1))
theorem reject15818 : ¬ Reader r15818 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.var 1)), (.lam (.lam (.var 1)))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15818
def r15819 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.lam (.var 0))))))) (.var 1))
theorem reject15819 : ¬ Reader r15819 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.var 2))), (.lam (.var 0))] [] [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15819
def r15820 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15820 : ¬ Reader r15820 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 4))))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 5)))))))) (.lam (.var 0))) (.lam (.lam (.var 3)))))) [(.lam (.var 0)), (.lam (.lam (.var 2))), (.lam (.var 0)), (.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15820
def r15821 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.lam (.var 3))))))) (.var 1))
theorem reject15821 : ¬ Reader r15821 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.lam (.var 3)))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.lam (.var 4))))))) (.lam (.lam (.var 1)))) (.lam (.var 2))))) [(.lam (.lam (.var 1))), (.lam (.var 1)), (.lam (.lam (.var 1))), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15821
def r15822 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 2))))) (.var 2)))))) (.var 1))
theorem reject15822 : ¬ Reader r15822 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 2))))) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 2))))) (.var 3)))))) (.lam (.lam (.lam (.var 2))))) (.var 1)))) [(.lam (.lam (.lam (.var 2)))), (.var 0), (.lam (.lam (.lam (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15822
def r15823 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 2))))))))) (.var 1))
theorem reject15823 : ¬ Reader r15823 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 2)))))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.lam (.lam (.var 2))))))))) (.var 1)) (.lam (.lam (.lam (.var 2))))))) [(.var 0), (.lam (.lam (.lam (.var 2)))), (.var 0), (.lam (.lam (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15823
def r15824 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.lam (.var 1)))))))) (.var 1))
theorem reject15824 : ¬ Reader r15824 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.lam (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.lam (.lam (.var 1)))))))) (.lam (.var 2))) (.lam (.lam (.var 1)))))) [(.lam (.var 1)), (.lam (.lam (.var 1))), (.lam (.var 1)), (.lam (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15824
def r15825 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.lam (.var 0))))))) (.var 1))
theorem reject15825 : ¬ Reader r15825 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.lam (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5)))) (.lam (.var 0))))))) (.lam (.lam (.var 3)))) (.lam (.var 0))))) [(.lam (.lam (.var 2))), (.lam (.var 0)), (.lam (.lam (.var 2))), (.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15825
def r15826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.lam (.var 2))))))) (.var 1))
theorem reject15826 : ¬ Reader r15826 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.var 0)] [(.lam (.lam (.lam (.var 2))))] [(.lam (.lam (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15826
def r15827 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.lam (.var 2))))))) (.var 1))
theorem reject15827 : ¬ Reader r15827 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.lam (.lam (.lam (.var 2))))))) (.var 1)))) [(.var 0), (.var 0), (.lam (.lam (.lam (.var 2))))] [(.lam (.lam (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15827
def r15828 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject15828 : ¬ Reader r15828 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.var 1))] [(.lam (.lam (.var 1)))] [(.lam (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15828
def r15829 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject15829 : ¬ Reader r15829 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.lam (.lam (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))) (.lam (.lam (.var 1)))))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.var 1)), (.lam (.lam (.var 1)))] [(.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15829
def r15830 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))) (.lam (.var 0))))) (.var 1))
theorem reject15830 : ¬ Reader r15830 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.var 2)))] [(.lam (.var 0))] [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15830
def r15831 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))) (.lam (.var 0))))) (.var 1))
theorem reject15831 : ¬ Reader r15831 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5)))))) (.lam (.var 0))))) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.lam (.var 0))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15831
def r15832 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))))) (.var 1))
theorem reject15832 : ¬ Reader r15832 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 4))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 5)))))))))) [(.lam (.lam (.lam (.app (.var 0) (.var 3)))))] [(.lam (.lam (.lam (.app (.var 0) (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15832
def r15833 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 3) (.lam (.var 1)))))))) (.var 1))
theorem reject15833 : ¬ Reader r15833 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 3) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 4) (.lam (.var 1)))))))))) [(.lam (.lam (.app (.var 2) (.lam (.var 1)))))] [(.lam (.lam (.app (.var 2) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15833
def r15834 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 4)))))))) (.var 1))
theorem reject15834 : ¬ Reader r15834 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 4))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 5)))))))))) [(.lam (.lam (.app (.var 0) (.lam (.var 3)))))] [(.lam (.lam (.app (.var 0) (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15834
def r15835 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 2) (.lam (.lam (.var 2)))))))) (.var 1))
theorem reject15835 : ¬ Reader r15835 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 2) (.lam (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 3) (.lam (.lam (.var 2)))))))))) [(.lam (.app (.var 1) (.lam (.lam (.var 2)))))] [(.lam (.app (.var 1) (.lam (.lam (.var 2))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15835
def r15836 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15836 : ¬ Reader r15836 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.var 5)))))))))) [(.lam (.app (.var 0) (.lam (.lam (.var 3)))))] [(.lam (.app (.var 0) (.lam (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15836
def r15837 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15837 : ¬ Reader r15837 := by
  exact replay_loop true [] 7 9 (.app (.lam (.app (.var 0) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 6))))) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 6))))) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 1)))))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15837
def r15838 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15838 : ¬ Reader r15838 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 3))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 5)))))))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15838
def r15839 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))) (.lam (.var 2))))) (.var 1))
theorem reject15839 : ¬ Reader r15839 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))))) (.lam (.var 3))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))))) (.lam (.var 3))) (.lam (.var 0)))))) (.lam (.var 1))) [(.lam (.var 0))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject15839
def r15840 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))) (.lam (.var 2))))) (.var 1))
theorem reject15840 : ¬ Reader r15840 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))) (.lam (.var 4))))) (.lam (.var 0)))))) [(.lam (.var 0))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15840
end Blc.HandlerLet.Slice45Main0477
