import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0488
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r16243 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject16243 : ¬ Reader r16243 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0, 2], [1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16243
def r16244 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 1))
theorem reject16244 : ¬ Reader r16244 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))) [(.lam (.app (.app (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 5)) (.var 1)))))) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 5)) (.var 1)))))))) (.var 1)) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 5)) (.var 1)))))) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 5)) (.var 1))))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16244
def r16245 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1))))))))) (.var 1))
theorem reject16245 : ¬ Reader r16245 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0, 2], [1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16245
def r16246 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)))))) (.var 1))
theorem reject16246 : ¬ Reader r16246 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1))))))) [(.lam (.app (.app (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)))))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1))))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16246
def r16247 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))) (.var 1))
theorem reject16247 : ¬ Reader r16247 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0, 2], [1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16247
def r16248 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))) (.var 1))
theorem reject16248 : ¬ Reader r16248 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))) [(.lam (.app (.app (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))) (.lam (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16248
def r16249 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject16249 : ¬ Reader r16249 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 1))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16249
def r16250 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject16250 : ¬ Reader r16250 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 1))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16250
def r16251 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))) (.var 1))
theorem reject16251 : ¬ Reader r16251 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16251
def r16252 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject16252 : ¬ Reader r16252 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16252
def r16253 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject16253 : ¬ Reader r16253 := by
  exact replay_loop true [] 3 8 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.var 2))))) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.var 3)))))) (.lam (.var 1)))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.var 3)))))) (.lam (.var 1))) (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16253
def r16254 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.var 1)))))) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject16254 : ¬ Reader r16254 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 1, 2, 0, 0], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 1, 2, 0, 0], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 2, 0, 0, 2], [1, 1, 1], [1, 1, 1, 2], [1, 1, 1, 1, 2, 0, 0], [1, 1, 1, 1]] [] (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.var 1)))))) (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16254
def r16255 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject16255 : ¬ Reader r16255 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16255
def r16256 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject16256 : ¬ Reader r16256 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.app (.var 1) (.lam (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16256
def r16257 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject16257 : ¬ Reader r16257 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.app (.var 1) (.lam (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16257
def r16258 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 3))))))) (.var 1))
theorem reject16258 : ¬ Reader r16258 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16258
def r16259 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject16259 : ¬ Reader r16259 := by
  exact replay_loop true [] 4 4 (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2)))) (.lam (.app (.var 0) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 5))))))) (.lam (.lam (.var 3))))))) [(.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 5))))))) (.lam (.lam (.var 3)))))) (.lam (.lam (.var 2))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2)))) (.lam (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16259
def r16260 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3)))))))) (.var 1))
theorem reject16260 : ¬ Reader r16260 := by
 exact mixed_reduct true [[1, 1]] [[2], [1], [], [2], [2, 1], [2], [2, 1], [2]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4))))))))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16260
def r16261 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1)))))))) (.var 1))
theorem reject16261 : ¬ Reader r16261 := by
 exact mixed_reduct true [[1, 1]] [[2], [1], [], [2], [2, 1], [2, 2]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1))))))))) [(.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.var 1)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16261
def r16262 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3)))))))) (.var 1))
theorem reject16262 : ¬ Reader r16262 := by
 exact mixed_reduct true [[1, 1]] [[2], [1], [], [2], [2, 1], [2, 1], [2], [2, 1], [2, 1], [2, 1]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4))))))))) [(.app (.var 0) (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16262
def r16263 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject16263 : ¬ Reader r16263 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16263
def r16264 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.var 2)))))))) (.var 1))
theorem reject16264 : ¬ Reader r16264 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16264
def r16265 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.lam (.lam (.var 2)))))))) (.var 1))
theorem reject16265 : ¬ Reader r16265 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16265
def r16266 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject16266 : ¬ Reader r16266 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16266
def r16267 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.var 0))))) (.var 1))
theorem reject16267 : ¬ Reader r16267 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.var 0)))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16267
def r16268 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject16268 : ¬ Reader r16268 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 0], [1, 1, 1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1, 1], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.lam (.app (.var 1) (.var 4)))))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16268
def r16269 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject16269 : ¬ Reader r16269 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 0], [1, 1, 1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1, 1], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16269
def r16270 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1))))) (.var 1))
theorem reject16270 : ¬ Reader r16270 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 4)))) (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16270
def r16271 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1))))) (.lam (.var 1))))) (.var 1))
theorem reject16271 : ¬ Reader r16271 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1))))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 1))))) (.lam (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.lam (.var 1))))) (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16271
def r16272 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject16272 : ¬ Reader r16272 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 1))))))) [(.lam (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16272
def r16273 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0))))) (.var 1))
theorem reject16273 : ¬ Reader r16273 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0)))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16273
def r16274 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0))))) (.var 1))
theorem reject16274 : ¬ Reader r16274 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 0)))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16274
def r16275 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))) (.app (.var 0) (.var 0))))) (.var 1))
theorem reject16275 : ¬ Reader r16275 := by
  exact replay_loop true [] 3 7 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))) (.app (.var 0) (.var 0)))) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 5)))))) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 5)))))) (.app (.var 0) (.var 0))))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16275
def r16276 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))))))) (.var 1))
theorem reject16276 : ¬ Reader r16276 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 4) (.lam (.var 0)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16276
def r16277 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))))))) (.var 1))
theorem reject16277 : ¬ Reader r16277 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 1)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16277
def r16278 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 4))))))))) (.var 1))
theorem reject16278 : ¬ Reader r16278 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 5))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 3))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 5))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16278
def r16279 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.var 1))))))))) (.var 1))
theorem reject16279 : ¬ Reader r16279 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 4) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 2) (.lam (.var 1))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 4) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 2) (.lam (.var 1)))))) (.lam (.lam (.app (.var 2) (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16279
def r16280 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.var 4))))))))) (.var 1))
theorem reject16280 : ¬ Reader r16280 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.var 4)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.var 5))))))))) (.lam (.lam (.app (.var 0) (.lam (.var 3))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.var 5))))))))) (.lam (.lam (.app (.var 0) (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16280
def r16281 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.var 2))))))))) (.var 1))
theorem reject16281 : ¬ Reader r16281 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.var 2)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 1) (.lam (.lam (.var 2)))))) (.lam (.app (.var 1) (.lam (.lam (.var 2))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16281
def r16282 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 4))))))))) (.var 1))
theorem reject16282 : ¬ Reader r16282 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 4)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 5))))))))) (.lam (.app (.var 0) (.lam (.lam (.var 3))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 5))))))))) (.lam (.app (.var 0) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16282
end Blc.HandlerLet.Slice45Main0488
