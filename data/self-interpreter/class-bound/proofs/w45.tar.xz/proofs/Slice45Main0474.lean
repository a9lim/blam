import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0474
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r15681 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15681 : ¬ Reader r15681 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15681
def r15682 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15682 : ¬ Reader r15682 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15682
def r15683 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))) (.var 0)))) (.var 1))
theorem reject15683 : ¬ Reader r15683 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15683
def r15684 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))) (.var 0)))) (.var 1))
theorem reject15684 : ¬ Reader r15684 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15684
def r15685 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15685 : ¬ Reader r15685 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15685
def r15686 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))) (.var 0)))) (.var 1))
theorem reject15686 : ¬ Reader r15686 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15686
def r15687 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15687 : ¬ Reader r15687 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15687
def r15688 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15688 : ¬ Reader r15688 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15688
def r15689 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))) (.var 0)))) (.var 1))
theorem reject15689 : ¬ Reader r15689 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15689
def r15690 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))) (.var 0)))) (.var 1))
theorem reject15690 : ¬ Reader r15690 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15690
def r15691 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))) (.var 0)))) (.var 1))
theorem reject15691 : ¬ Reader r15691 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15691
def r15692 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))))) (.var 0)))) (.var 1))
theorem reject15692 : ¬ Reader r15692 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15692
def r15693 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)))) (.var 0)))) (.var 1))
theorem reject15693 : ¬ Reader r15693 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15693
def r15694 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15694 : ¬ Reader r15694 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15694
def r15695 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1)))) (.var 0)))) (.var 1))
theorem reject15695 : ¬ Reader r15695 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15695
def r15696 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15696 : ¬ Reader r15696 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15696
def r15697 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1))) (.var 0)))) (.var 1))
theorem reject15697 : ¬ Reader r15697 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15697
def r15698 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15698 : ¬ Reader r15698 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15698
def r15699 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject15699 : ¬ Reader r15699 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15699
def r15700 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))) (.var 0)))) (.var 1))
theorem reject15700 : ¬ Reader r15700 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15700
def r15701 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15701 : ¬ Reader r15701 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15701
def r15702 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 1))) (.var 0)))) (.var 1))
theorem reject15702 : ¬ Reader r15702 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15702
def r15703 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)))) (.var 1))
theorem reject15703 : ¬ Reader r15703 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15703
def r15704 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15704 : ¬ Reader r15704 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15704
def r15705 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)))) (.var 1))
theorem reject15705 : ¬ Reader r15705 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15705
def r15706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15706 : ¬ Reader r15706 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15706
def r15707 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))) (.var 1))
theorem reject15707 : ¬ Reader r15707 := by
  exact replay_loop true [] 1 12 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15707
def r15708 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)) (.var 0)))) (.var 1))
theorem reject15708 : ¬ Reader r15708 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15708
def r15709 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)) (.var 0)))) (.var 1))
theorem reject15709 : ¬ Reader r15709 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15709
def r15710 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)) (.var 0)))) (.var 1))
theorem reject15710 : ¬ Reader r15710 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15710
def r15711 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))) (.var 1))
theorem reject15711 : ¬ Reader r15711 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))) [(.app (.var 0) (.var 0)), (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15711
def r15712 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))) (.var 1))
theorem reject15712 : ¬ Reader r15712 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))) [(.app (.var 0) (.lam (.lam (.var 0)))), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15712
def r15713 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 1)) (.var 0)))) (.var 1))
theorem reject15713 : ¬ Reader r15713 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 2)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15713
def r15714 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)))) (.var 1))
theorem reject15714 : ¬ Reader r15714 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))) [(.lam (.lam (.var 0))), (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15714
def r15715 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 1)) (.var 0)))) (.var 1))
theorem reject15715 : ¬ Reader r15715 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 2)) (.var 0))))) [(.var 0), (.var 0), (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15715
def r15716 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))) (.var 1))
theorem reject15716 : ¬ Reader r15716 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))) [(.lam (.lam (.var 0))), (.var 0), (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15716
def r15717 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))) (.var 1))
theorem reject15717 : ¬ Reader r15717 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))) [(.var 0), (.lam (.lam (.var 0))), (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15717
def r15718 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))))) (.var 1))
theorem reject15718 : ¬ Reader r15718 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0))))))))) [(.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15718
def r15719 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))))) (.var 1))
theorem reject15719 : ¬ Reader r15719 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)))))) [(.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15719
def r15720 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.var 1))
theorem reject15720 : ¬ Reader r15720 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))))))) [(.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15720
end Blc.HandlerLet.Slice45Main0474
