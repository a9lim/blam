import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0349
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r10706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject10706 : ¬ Reader r10706 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 0, 1], [1, 1], [1, 1], [1, 1, 0, 1, 2, 0], [1, 1, 0, 1, 1], [1]] [[1, 1, 0, 1, 2, 0], [1, 1, 0, 1, 1], [1]] (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 3)))))) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject10706
def r10707 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject10707 : ¬ Reader r10707 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10707
def r10708 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject10708 : ¬ Reader r10708 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10708
def r10709 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))
theorem reject10709 : ¬ Reader r10709 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10709
def r10710 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject10710 : ¬ Reader r10710 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10710
def r10711 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject10711 : ¬ Reader r10711 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10711
def r10712 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))) (.var 1))
theorem reject10712 : ¬ Reader r10712 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10712
def r10713 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject10713 : ¬ Reader r10713 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10713
def r10714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject10714 : ¬ Reader r10714 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10714
def r10715 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.var 3))))))))) (.var 1))
theorem reject10715 : ¬ Reader r10715 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 6) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 10) (.var 3)))))))))))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 6) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 10) (.var 3))))))))))))))))))) [(.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 5) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 9) (.var 3))))))))))))))))] [(.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 6) (.var 3))))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10715
def r10716 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 4))))))))) (.var 1))
theorem reject10716 : ¬ Reader r10716 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 10)))))))) (.var 6)))))) (.var 3)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 10)))))))) (.var 6)))))) (.var 3))))))) [(.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 9)))))))) (.var 5)))))) (.var 2))))] [(.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 6)))))))) (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10716
def r10717 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 2)))))) (.var 1))
theorem reject10717 : ¬ Reader r10717 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[0,1,9],[],[],[]] [[],[],[],[],[8],[8],[8],[8],[8],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [8]) [4]) (.lam 5 (.app (.var 0 [5,6,7]) (.lam 6 (.app (.app (.var 0 [6,7]) (.lam 7 (.lam 8 (.app (.var 3 [5,6,7]) (.var 2 [6,7]) [8]) [8]) [7]) [8]) (.var 2 [0]) [8]) [6]) [8]) [5]) [8]) (.var 1 [1]) [8]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [8]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10717
def r10718 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 2)))))) (.var 1))
theorem reject10718 : ¬ Reader r10718 := by
  exact replay_loop true [] 2 9 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 5))))))))) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10718
def r10719 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4))))))))) (.var 1))
theorem reject10719 : ¬ Reader r10719 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[],[]] [[],[],[],[],[],[],[],[],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6,7]) (.lam 6 (.app (.var 0 [6,7]) (.lam 7 (.app (.app (.var 2 [5,6,7]) (.var 1 [6,7]) []) (.lam 8 (.var 4 [0]) [8]) []) [7]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10719
def r10720 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4))))))))) (.var 1))
theorem reject10720 : ¬ Reader r10720 := by
  exact replay_loop true [] 2 7 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 6))))))))) (.lam (.var 3))))))) [(.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10720
def r10721 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 4))))))))) (.var 1))
theorem reject10721 : ¬ Reader r10721 := by
  exact replay_absent true [] 7 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10721
def r10722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4))))))))) (.var 1))
theorem reject10722 : ¬ Reader r10722 := by
  exact replay_loop true [] 6 5 (.app (.lam (.app (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 6)))))))) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.lam (.app (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 6)))))))) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))) [(.lam (.var 1)), (.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10722
def r10723 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 2)))))) (.var 1))
theorem reject10723 : ¬ Reader r10723 := by
  exact replay_loop true [] 6 7 (.app (.lam (.app (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 5))))) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 3))) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 2))) (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 5))))) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 3))) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 2))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10723
def r10724 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.var 2))))))))) (.var 1))
theorem reject10724 : ¬ Reader r10724 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[]] [[],[],[],[],[],[],[],[8],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.lam 8 (.app (.var 4 [0]) (.var 2 [6]) [0]) [8]) [7]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10724
def r10725 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.var 4))))))))) (.var 1))
theorem reject10725 : ¬ Reader r10725 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,6],[],[],[],[],[]] [[],[],[],[],[0],[0],[0],[8],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [0]) [4]) (.lam 5 (.app (.var 0 [0,5,6]) (.lam 6 (.app (.app (.var 1 [0,5,6]) (.var 0 [0,6]) [0]) (.lam 7 (.lam 8 (.app (.var 2 [0,6]) (.var 4 [0]) [0]) [8]) [7]) [0]) [6]) [0]) [5]) [0]) (.var 1 [1]) [0]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10725
def r10726 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 2))))))))) (.var 1))
theorem reject10726 : ¬ Reader r10726 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 5) (.var 2))))))))) (.lam (.lam (.app (.var 3) (.var 2))))))) [(.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 6) (.var 2))))))))))), (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 8) (.var 2))))))))) (.lam (.lam (.app (.var 6) (.var 2))))))) (.lam (.lam (.app (.var 5) (.var 2)))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10726
def r10727 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 4))))))))) (.var 1))
theorem reject10727 : ¬ Reader r10727 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 4)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 5))))))))) (.lam (.lam (.app (.var 2) (.var 3))))))) [(.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 6)))))))) (.var 2)))), (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 8))))))))) (.lam (.lam (.app (.var 2) (.var 6))))))) (.lam (.lam (.app (.var 2) (.var 5)))))) (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10727
def r10728 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject10728 : ¬ Reader r10728 := by
  exact replay_loop true [] 2 4 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10728
def r10729 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject10729 : ¬ Reader r10729 := by
  exact replay_loop true [] 2 4 (.app (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.app (.var 2) (.var 2))))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10729
def r10730 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject10730 : ¬ Reader r10730 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10730
def r10731 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.lam (.var 0))))))))) (.var 1))
theorem reject10731 : ¬ Reader r10731 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10731
def r10732 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 3))))))) (.var 1))
theorem reject10732 : ¬ Reader r10732 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10732
def r10733 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.lam (.var 0)))))))) (.var 1))
theorem reject10733 : ¬ Reader r10733 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10733
def r10734 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 3))))))) (.var 1))
theorem reject10734 : ¬ Reader r10734 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 3))))))) [(.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10734
def r10735 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3))))))))) (.var 1))
theorem reject10735 : ¬ Reader r10735 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[]] [[],[],[],[],[],[],[],[0],[5,6],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.app (.var 3 [0]) (.lam 8 (.var 3 [5,6]) [8]) [0]) [7]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10735
def r10736 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 3))))))))) (.var 1))
theorem reject10736 : ¬ Reader r10736 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.lam (.var 3))))))))) (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 6) (.lam (.var 3)))))))))))))) [(.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 6) (.lam (.var 3))))))))) (.lam (.app (.var 4) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 8) (.lam (.var 3)))))))))))))))), (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 5) (.lam (.var 3)))))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10736
def r10737 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4))))))))) (.var 1))
theorem reject10737 : ¬ Reader r10737 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[],[]] [[],[],[],[],[],[],[],[],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6,7]) (.lam 6 (.app (.var 1 [5,6,7]) (.lam 7 (.app (.app (.var 2 [5,6,7]) (.var 0 [6,7]) []) (.lam 8 (.var 4 [0]) [8]) []) [7]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10737
def r10738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4))))))))) (.var 1))
theorem reject10738 : ¬ Reader r10738 := by
  exact replay_loop true [] 4 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 5))))))))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10738
def r10739 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3))))))) (.var 1))
theorem reject10739 : ¬ Reader r10739 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[],[]] [[],[],[],[],[],[],[],[],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6,7]) (.lam 6 (.app (.app (.var 1 [5,6,7]) (.lam 7 (.app (.var 2 [5,6,7]) (.var 1 [6,7]) []) [7]) []) (.lam 8 (.var 3 [0]) [8]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10739
def r10740 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3))))))) (.var 1))
theorem reject10740 : ¬ Reader r10740 := by
  exact replay_loop true [] 2 9 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 4)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 5))))))))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10740
def r10741 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4))))))))) (.var 1))
theorem reject10741 : ¬ Reader r10741 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,8],[6,8],[],[6,8],[],[],[]] [[],[],[],[],[0],[0],[0],[0],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [0]) [4]) (.lam 5 (.app (.var 0 [5,6,8]) (.lam 6 (.app (.app (.var 1 [5,6,8]) (.var 0 [6,8]) [0]) (.lam 7 (.app (.var 2 [5,6,8]) (.lam 8 (.var 4 [0]) [8]) [0]) [7]) [0]) [6]) [0]) [5]) [0]) (.var 1 [1]) [0]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10741
def r10742 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 4))))))))) (.var 1))
theorem reject10742 : ¬ Reader r10742 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 5))))))))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 6)))))))) (.lam (.var 3))))))) [(.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 6))))))))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 7)))))))) (.lam (.var 4)))))) (.lam (.var 2)))), (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 5)))))))) (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10742
def r10743 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 4) (.var 1))))))))) (.var 1))
theorem reject10743 : ¬ Reader r10743 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 4) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 4) (.var 1))))))))) [(.lam (.lam (.app (.var 2) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10743
def r10744 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 4))))))))) (.var 1))
theorem reject10744 : ¬ Reader r10744 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 4)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 4))))))))) [(.lam (.lam (.app (.var 1) (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10744
def r10745 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2))))))))) (.var 1))
theorem reject10745 : ¬ Reader r10745 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2))))))))) [(.lam (.app (.var 1) (.lam (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 7) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 7) (.lam (.var 2))))))))) (.lam (.app (.var 5) (.lam (.var 2)))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 7) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 7) (.lam (.var 2))))))))) (.lam (.app (.var 5) (.lam (.var 2))))))) (.lam (.app (.var 4) (.lam (.var 2)))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10745
end Blc.HandlerLet.Slice45Main0349
