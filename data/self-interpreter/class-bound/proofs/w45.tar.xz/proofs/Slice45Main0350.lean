import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0350
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r10746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4))))))))) (.var 1))
theorem reject10746 : ¬ Reader r10746 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4))))))))) [(.lam (.app (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 7)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 7))))))))) (.lam (.app (.var 1) (.lam (.var 5)))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 7)))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 7))))))))) (.lam (.app (.var 1) (.lam (.var 5))))))) (.lam (.app (.var 1) (.lam (.var 4)))))) (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10746
def r10747 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4))))))))) (.var 1))
theorem reject10747 : ¬ Reader r10747 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 2, 0, 0, 1], [1, 1], [1, 1, 1], [1, 1, 1, 2, 2, 0, 0, 1], [1, 1, 1, 2, 2, 0, 0], [1, 1, 1], [1, 1]] [[1, 1, 0, 1, 2, 2, 0, 0, 1], [1, 1, 0, 1, 2, 2, 0, 0], [1], [1, 1], [1]] (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 7))))))) (.lam (.var 5))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 7))))))) (.lam (.var 5)))))) (.var 1)) (.lam (.var 3))))))) (.lam (.var 1))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10747
def r10748 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4))))))))) (.var 1))
theorem reject10748 : ¬ Reader r10748 := by
  exact replay_loop true [] 6 7 (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 6))))))))) (.lam (.var 3))))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 8))))))))) (.lam (.var 5)))))) (.lam (.var 3)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4))))))))) [(.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10748
def r10749 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))) (.lam (.var 0))))) (.var 1))
theorem reject10749 : ¬ Reader r10749 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))) (.lam (.var 0))))) [(.var 0), (.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10749
def r10750 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.var 1))
theorem reject10750 : ¬ Reader r10750 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1], [1, 1, 1, 1], [1, 1, 1], [1, 1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1], [1, 1, 1], [1, 1, 1, 0, 2], [1, 1, 1, 0, 2, 0, 0], [1, 1], [1, 1]] [[1, 1, 1, 0, 2, 0, 0, 1], [1, 1, 1, 0, 1, 2, 0], [1, 1, 1, 0, 1, 1], [1, 1]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 3)))) (.lam (.lam (.app (.app (.var 3) (.var 4)) (.app (.var 1) (.var 4)))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 2) (.var 4)))) (.lam (.lam (.app (.app (.var 3) (.var 5)) (.app (.var 1) (.var 5)))))))))) (.lam (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.lam (.app (.var 2) (.var 5)))) (.lam (.lam (.app (.app (.var 3) (.var 6)) (.app (.var 1) (.var 6)))))))) (.app (.var 1) (.var 2)))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject10750
def r10751 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))) (.lam (.var 1))))) (.var 1))
theorem reject10751 : ¬ Reader r10751 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 4))))) (.lam (.var 2))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 4))))) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 5))))) (.lam (.var 2))) (.var 3)))))) [(.var 0)] [(.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 4))))) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10751
def r10752 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))) (.lam (.var 1))))) (.var 1))
theorem reject10752 : ¬ Reader r10752 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 5))))) (.lam (.var 1))))) (.var 2))))) [(.var 0)] [(.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 4))))) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10752
def r10753 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))) (.var 0)))) (.var 1))
theorem reject10753 : ¬ Reader r10753 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))) (.var 0)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10753
def r10754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))) (.var 0)))) (.var 1))
theorem reject10754 : ¬ Reader r10754 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))) (.var 0)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10754
def r10755 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))) (.var 0)))) (.var 1))
theorem reject10755 : ¬ Reader r10755 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0], [1, 1, 1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))) (.var 0)))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject10755
def r10756 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))) (.var 0)))) (.var 1))
theorem reject10756 : ¬ Reader r10756 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5)))))) (.var 1)) (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5)))))) (.var 1)) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 5)))))) (.var 1)) (.lam (.var 3)))))) [(.lam (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10756
def r10757 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))) (.var 0)))) (.var 1))
theorem reject10757 : ¬ Reader r10757 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 6)))))) (.var 0)))) (.lam (.var 3)))))) [(.lam (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10757
def r10758 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))) (.lam (.var 2))))) (.var 1))
theorem reject10758 : ¬ Reader r10758 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[1,6,7,8,9],[],[],[],[]] [[],[],[],[],[7],[7],[7],[7],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [7]) [4]) (.lam 5 (.app (.app (.var 0 [5,6,7]) (.lam 6 (.lam 7 (.app (.var 2 [5,6,7]) (.app (.var 2 [5,6,7]) (.var 1 [6,7]) [7]) [7]) [7]) [6]) [7]) (.lam 8 (.var 2 [0]) [8]) [7]) [5]) [7]) (.var 1 [1]) [7]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [7]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10758
def r10759 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 2))))) (.var 1))
theorem reject10759 : ¬ Reader r10759 := by
  exact replay_loop true [] 2 9 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 2)))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4)))) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4))))))))) [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 2)))), (.lam (.lam (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4)))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 6)))) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 6))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4))))) (.app (.var 1) (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4)))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 6)))) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 6))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))) (.lam (.var 4))))))))), (.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10759
def r10760 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 2))))) (.var 1))
theorem reject10760 : ¬ Reader r10760 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 2))))) [(.lam (.lam (.app (.app (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 6)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 6))))) (.var 1)))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 6)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))) (.lam (.var 6))))) (.var 1))))) (.var 1)))), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10760
def r10761 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 2))))) (.var 1))
theorem reject10761 : ¬ Reader r10761 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 2))))) [(.app (.lam (.lam (.app (.var 1) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 4)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 4)))))))) (.lam (.lam (.app (.var 1) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 4)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))) (.lam (.var 4)))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10761
def r10762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))) (.lam (.var 2))))) (.var 1))
theorem reject10762 : ¬ Reader r10762 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 3))))) (.lam (.var 3))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))) (.lam (.var 4))))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 3))))) (.lam (.var 3))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))) (.lam (.var 4)))))))) (.lam (.var 1))) [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))) (.lam (.var 2))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10762
def r10763 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 2))))) (.var 1))
theorem reject10763 : ¬ Reader r10763 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 4))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 4)))))))) [(.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 4))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))) (.lam (.var 4)))))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10763
def r10764 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 1)))) (.var 1))
theorem reject10764 : ¬ Reader r10764 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 1))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 1)))) [(.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 6))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 6)))) (.lam (.var 2))))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 6))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))) (.var 6)))) (.lam (.var 2)))))) (.lam (.var 2)))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10764
def r10765 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 2))))))) (.var 1)))) (.var 1))
theorem reject10765 : ¬ Reader r10765 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 0, 2, 0, 0], [1, 2, 0], [1, 2, 0, 1], [1, 2, 0]] (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 2))))))) (.var 1))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 2))))))) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10765
def r10766 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 1)))) (.var 1))
theorem reject10766 : ¬ Reader r10766 := by
  exact replay_loop true [] 2 12 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 1))) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 2))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 4))))))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10766
def r10767 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 3))))))) (.var 1)))) (.var 1))
theorem reject10767 : ¬ Reader r10767 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 3))))))) (.var 1))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 3))))))) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10767
def r10768 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))) (.var 1)))) (.var 1))
theorem reject10768 : ¬ Reader r10768 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 4)))))) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))) (.var 4))))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 4)))))) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))) (.var 4)))))))) (.var 0)) [(.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))) (.var 2))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject10768
def r10769 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 1)))) (.var 1))
theorem reject10769 : ¬ Reader r10769 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 3)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 4)))))))) [(.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 4)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))) (.var 5))))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10769
def r10770 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))) (.var 1)))) (.var 1))
theorem reject10770 : ¬ Reader r10770 := by
  exact replay_loop true [] 2 6 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))) (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))) (.var 4))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))) (.var 3))))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10770
def r10771 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))) (.var 1))
theorem reject10771 : ¬ Reader r10771 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10771
def r10772 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 2))))))) (.var 1))
theorem reject10772 : ¬ Reader r10772 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 2)))))) (.var 0)) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10772
def r10773 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.var 1))
theorem reject10773 : ¬ Reader r10773 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 2)))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10773
def r10774 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.var 1))
theorem reject10774 : ¬ Reader r10774 := by
  exact replay_loop true [] 3 4 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))) (.lam (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 6)) (.var 1))))))) (.var 2)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10774
def r10775 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.var 1))
theorem reject10775 : ¬ Reader r10775 := by
  exact replay_absent true [] 8 1 (by decide +kernel) (by decide +kernel)
#print axioms reject10775
def r10776 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))) (.var 0)))) (.var 1))
theorem reject10776 : ¬ Reader r10776 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10776
def r10777 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))) (.var 0)))) (.var 1))
theorem reject10777 : ¬ Reader r10777 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 2)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10777
def r10778 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))) (.var 0)))) (.var 1))
theorem reject10778 : ¬ Reader r10778 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10778
def r10779 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))) (.var 0)))) (.var 1))
theorem reject10779 : ¬ Reader r10779 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 4)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10779
def r10780 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))) (.var 0)))) (.var 1))
theorem reject10780 : ¬ Reader r10780 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10780
def r10781 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))) (.var 0)))) (.var 1))
theorem reject10781 : ¬ Reader r10781 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10781
def r10782 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))) (.var 0)))) (.var 1))
theorem reject10782 : ¬ Reader r10782 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 2)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10782
def r10783 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))) (.var 0)))) (.var 1))
theorem reject10783 : ¬ Reader r10783 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 4)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10783
def r10784 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))) (.var 0)))) (.var 1))
theorem reject10784 : ¬ Reader r10784 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10784
def r10785 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))) (.var 0)))) (.var 1))
theorem reject10785 : ¬ Reader r10785 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 2))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10785
end Blc.HandlerLet.Slice45Main0350
