import Blc.SelfintRootLetBinaryOrbit
import Certificates
namespace Blc.Slice45Demand67975
open Term SelfintClass SelfintLowerBound WeakHeadClock
set_option linter.unusedSimpArgs false
set_option maxRecDepth 16000
def F0 : Term := (.lam (.app (.var 0) (.app (.var 0) (.var 0))))
def F1 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))))))
def F2 (x0 : Term) : Term := (.lam (shift 1 0 x0))
def F3 : Term := (.lam (.var 0))
theorem weak0 (y : Term) : weakStep (.app (F0 ) y) = some (.app y (.app y y)) := by
 simp (disch := decide) [F0,F1,F2,F3,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step0 (y : Term) : Beta (.app (F0 ) y) (.app y (.app y y)) := weakStep_beta (weak0 y)
theorem weak1 (y : Term) : weakStep (.app (F1 ) y) = some (.app y (.app y (.app (.app y (F2 y)) (F3 )))) := by
 simp (disch := decide) [F0,F1,F2,F3,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step1 (y : Term) : Beta (.app (F1 ) y) (.app y (.app y (.app (.app y (F2 y)) (F3 )))) := weakStep_beta (weak1 y)
theorem weak2 (x0 y : Term) : weakStep (.app (F2 x0) y) = some x0 := by
 simp (disch := decide) [F0,F1,F2,F3,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step2 (x0 y : Term) : Beta (.app (F2 x0) y) x0 := weakStep_beta (weak2 x0 y)
theorem weak3 (y : Term) : weakStep (.app (F3 ) y) = some y := by
 simp (disch := decide) [F0,F1,F2,F3,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step3 (y : Term) : Beta (.app (F3 ) y) y := weakStep_beta (weak3 y)
def n0 : Term := .var 0
def n1 : Term := .var 1
def n2 : Term := F0 
def n3 : Term := F1 
def n4 : Term := .app n2 n3
def n5 : Term := .app n4 n0
def n6 : Term := .app n5 n1
def n7 : Term := .app n3 n3
def n8 : Term := .app n3 n7
def n9 : Term := F2 n7
def n10 : Term := .app n7 n9
def n11 : Term := F3 
def n12 : Term := .app n10 n11
def n13 : Term := .app n7 n12
def n14 : Term := .app n7 n13
def n15 : Term := F2 n3
def n16 : Term := .app n3 n15
def n17 : Term := .app n16 n11
def n18 : Term := .app n3 n17
def n19 : Term := .app n3 n18
def n20 : Term := F2 n18
def n21 : Term := .app n18 n20
def n22 : Term := .app n21 n11
def n23 : Term := .app n18 n22
def n24 : Term := .app n18 n23
def n25 : Term := F2 n17
def n26 : Term := .app n17 n25
def n27 : Term := .app n26 n11
def n28 : Term := .app n17 n27
def n29 : Term := .app n17 n28
def n30 : Term := F2 n15
def n31 : Term := .app n15 n30
def n32 : Term := .app n31 n11
def n33 : Term := .app n15 n32
def n34 : Term := .app n15 n33
def n35 : Term := F2 n11
def n36 : Term := .app n11 n35
def n37 : Term := .app n36 n11
def n38 : Term := .app n11 n37
def n39 : Term := .app n11 n38
def n40 : Term := .app n0 n1
theorem ev2 : Betas n2 n2 := .refl _
theorem ev3 : Betas n3 n3 := .refl _
theorem ev15 : Betas n15 n15 := .refl _
theorem ev34 : Betas n34 n3 := betas_trans (betas_appL n33 ev15) (.head (step2 n3 n33) ev3)
theorem ev16 : Betas n16 n3 := betas_trans (betas_appL n15 ev3) (.head (step1 n15) ev34)
theorem ev11 : Betas n11 n11 := .refl _
theorem ev35 : Betas n35 n35 := .refl _
theorem ev36 : Betas n36 n35 := betas_trans (betas_appL n35 ev11) (.head (step3 n35) ev35)
theorem ev37 : Betas n37 n11 := betas_trans (betas_appL n11 ev36) (.head (step2 n11 n11) ev11)
theorem ev38 : Betas n38 n11 := betas_trans (betas_appL n37 ev11) (.head (step3 n37) ev37)
theorem ev39 : Betas n39 n11 := betas_trans (betas_appL n38 ev11) (.head (step3 n38) ev38)
theorem ev17 : Betas n17 n11 := betas_trans (betas_appL n11 ev16) (.head (step1 n11) ev39)
theorem ev25 : Betas n25 n25 := .refl _
theorem ev26 : Betas n26 n25 := betas_trans (betas_appL n25 ev17) (.head (step3 n25) ev25)
theorem ev27 : Betas n27 n11 := betas_trans (betas_appL n11 ev26) (.head (step2 n17 n11) ev17)
theorem ev28 : Betas n28 n11 := betas_trans (betas_appL n27 ev17) (.head (step3 n27) ev27)
theorem ev29 : Betas n29 n11 := betas_trans (betas_appL n28 ev17) (.head (step3 n28) ev28)
theorem ev18 : Betas n18 n11 := betas_trans (betas_appL n17 ev3) (.head (step1 n17) ev29)
theorem ev20 : Betas n20 n20 := .refl _
theorem ev21 : Betas n21 n20 := betas_trans (betas_appL n20 ev18) (.head (step3 n20) ev20)
theorem ev22 : Betas n22 n11 := betas_trans (betas_appL n11 ev21) (.head (step2 n18 n11) ev18)
theorem ev23 : Betas n23 n11 := betas_trans (betas_appL n22 ev18) (.head (step3 n22) ev22)
theorem ev24 : Betas n24 n11 := betas_trans (betas_appL n23 ev18) (.head (step3 n23) ev23)
theorem ev19 : Betas n19 n11 := betas_trans (betas_appL n18 ev3) (.head (step1 n18) ev24)
theorem ev7 : Betas n7 n11 := betas_trans (betas_appL n3 ev3) (.head (step1 n3) ev19)
theorem ev9 : Betas n9 n9 := .refl _
theorem ev10 : Betas n10 n9 := betas_trans (betas_appL n9 ev7) (.head (step3 n9) ev9)
theorem ev12 : Betas n12 n11 := betas_trans (betas_appL n11 ev10) (.head (step2 n7 n11) ev7)
theorem ev13 : Betas n13 n11 := betas_trans (betas_appL n12 ev7) (.head (step3 n12) ev12)
theorem ev14 : Betas n14 n11 := betas_trans (betas_appL n13 ev7) (.head (step3 n13) ev13)
theorem ev8 : Betas n8 n11 := betas_trans (betas_appL n7 ev3) (.head (step1 n7) ev14)
theorem ev4 : Betas n4 n11 := betas_trans (betas_appL n3 ev2) (.head (step0 n3) ev8)
theorem ev0 : Betas n0 n0 := .refl _
theorem ev5 : Betas n5 n0 := betas_trans (betas_appL n0 ev4) (.head (step3 n0) ev0)
theorem ev6 : Betas n6 n40 := betas_appL n1 ev5
def r67975 : Term := (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))))))) (.var 0)) (.var 1))
theorem reject67975 : ¬ Reader r67975 := by
 intro hr
 exact reader_not_rigid (SelfintRootLetPowers.reader_betas hr ev6) (.app _ (.var _))
#print axioms reject67975
end Blc.Slice45Demand67975
