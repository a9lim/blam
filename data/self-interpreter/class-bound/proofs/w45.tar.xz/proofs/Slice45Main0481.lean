import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0481
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r15961 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject15961 : ¬ Reader r15961 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject15961
def r15962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15962 : ¬ Reader r15962 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15962
def r15963 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject15963 : ¬ Reader r15963 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2)))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15963
def r15964 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1)))) (.var 1))
theorem reject15964 : ¬ Reader r15964 := by
 exact mixed_reduct true [[1, 1, 2, 0, 1], [1, 1, 2, 0], [1, 1]] [[1, 1, 2], [1, 1, 2, 1], [1, 1, 2], [1, 1, 1], [1, 1, 1, 1], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.lam (.lam (.var 2))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15964
def r15965 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 1) (.var 1)))) (.var 1)))) (.var 1))
theorem reject15965 : ¬ Reader r15965 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 1) (.var 1)))) (.var 1))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 1) (.var 1)))) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15965
def r15966 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15966 : ¬ Reader r15966 := by
  exact replay_loop true [] 7 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15966
def r15967 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0)))))))) (.var 1))
theorem reject15967 : ¬ Reader r15967 := by
  exact replay_loop true [] 8 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))) [] [(.lam (.lam (.var 2))), (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15967
def r15968 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))))))) (.var 1))
theorem reject15968 : ¬ Reader r15968 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) [(.lam (.lam (.lam (.var 3))))] [(.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))), (.lam (.lam (.lam (.var 3)))), (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15968
def r15969 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.lam (.lam (.var 3)))))))) (.var 1))
theorem reject15969 : ¬ Reader r15969 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))), (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 5) (.lam (.lam (.var 3))))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15969
def r15970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.lam (.lam (.var 3))))))) (.var 1))
theorem reject15970 : ¬ Reader r15970 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) [(.var 0)] [(.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))))), (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 5)))) (.lam (.lam (.lam (.var 3))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15970
def r15971 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15971 : ¬ Reader r15971 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))), (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.lam (.lam (.var 5))))))) (.lam (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15971
def r15972 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))) (.lam (.var 1))))) (.var 1))
theorem reject15972 : ¬ Reader r15972 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))), (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 5)))))) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15972
def r15973 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))) (.lam (.lam (.var 2)))))) (.var 1))
theorem reject15973 : ¬ Reader r15973 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) [(.lam (.var 1))] [(.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))), (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))) (.lam (.lam (.var 2))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15973
def r15974 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 4)))))) (.var 0)))) (.var 1))
theorem reject15974 : ¬ Reader r15974 := by
  exact replay_loop true [] 6 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 4)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 5)))))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15974
def r15975 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))))) (.var 0)))) (.var 1))
theorem reject15975 : ¬ Reader r15975 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))))) (.var 0)))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15975
def r15976 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0))))) (.var 0)))) (.var 1))
theorem reject15976 : ¬ Reader r15976 := by
  exact replay_loop true [] 4 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15976
def r15977 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))) (.var 0)))) (.var 1))
theorem reject15977 : ¬ Reader r15977 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) [(.lam (.lam (.lam (.var 3))))] [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))), (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15977
def r15978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3))))))) (.var 1)) (.var 0)))) (.var 1))
theorem reject15978 : ¬ Reader r15978 := by
  exact replay_absent true [] 11 1 (by decide +kernel) (by decide +kernel)
#print axioms reject15978
def r15979 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15979 : ¬ Reader r15979 := by
  exact replay_loop true [] 5 3 (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 6)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 6)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))) [(.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 6)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 6)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))), (.lam (.app (.app (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))) (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))))) (.app (.var 0) (.var 0)))), (.lam (.lam (.lam (.var 3))))] [(.lam (.app (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 7)))))) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 0)))), (.lam (.lam (.lam (.var 3)))), (.lam (.lam (.lam (.var 3)))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15979
def r15980 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15980 : ¬ Reader r15980 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[],[8],[9],[0],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.app (.var 0 [6]) (.app (.var 1 [5,6]) (.var 0 [6]) []) []) [6]) []) (.lam 7 (.lam 8 (.lam 9 (.var 4 [0]) [9]) [8]) [7]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15980
def r15981 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15981 : ¬ Reader r15981 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 5)))))))))) [(.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 5)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 6))))))))))))), (.lam (.lam (.lam (.var 3)))), (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 6)))))))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.var 5)))))))))), (.lam (.lam (.lam (.var 3))))] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15981
def r15982 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15982 : ¬ Reader r15982 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[],[8],[9],[0],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.var 0 [6]) []) [6]) []) (.lam 7 (.lam 8 (.lam 9 (.var 4 [0]) [9]) [8]) [7]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15982
def r15983 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15983 : ¬ Reader r15983 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.var 5))))))) (.var 0)))) [(.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.var 4)))))), (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.var 6))))))) (.var 0)))) (.var 0))), (.lam (.lam (.lam (.var 3))))] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15983
def r15984 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject15984 : ¬ Reader r15984 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 6)))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 6))))))))))) [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 5))))))))] [(.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 4)))))), (.lam (.lam (.lam (.var 3)))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15984
def r15985 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))) (.var 1))
theorem reject15985 : ¬ Reader r15985 := by
  exact replay_loop true [] 6 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))) [] [(.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15985
def r15986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))) (.var 1))
theorem reject15986 : ¬ Reader r15986 := by
  exact replay_loop true [] 5 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15986
def r15987 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15987 : ¬ Reader r15987 := by
 exact Rootcert2Flow.reject [[1, 1]] [[],[],[],[],[9],[10],[11],[],[],[5],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[10],[8],[0],[],[],[6],[13],[0],[],[16],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [9]) (.lam 5 (.app (.var 1 [9]) (.app (.var 0 [10]) (.lam 6 (.var 1 [10]) [6]) []) []) [5]) []) (.lam 7 (.lam 8 (.var 3 [0]) [8]) [7]) []) [4]) (.lam 9 (.app (.app (.var 0 [5]) (.lam 10 (.app (.var 1 [5]) (.app (.var 0 [6]) (.lam 11 (.var 1 [6]) [11]) [10]) []) [10]) []) (.lam 12 (.lam 13 (.var 3 [0]) [13]) [12]) []) [9]) []) (.var 1 [1]) []) (.lam 14 (.app (.app (.var 0 []) (.lam 15 (.lam 16 (.var 1 []) [16]) [15]) []) (.var 4 [3]) []) [14]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15987
def r15988 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15988 : ¬ Reader r15988 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[],[6],[9],[0],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.var 1 [6]) [7]) []) [6]) []) (.lam 8 (.lam 9 (.var 3 [0]) [9]) [8]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15988
def r15989 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15989 : ¬ Reader r15989 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.var 3))))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.var 4)))))) (.lam (.var 1))))) [(.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.var 4)))))), (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.var 6)))))) (.lam (.var 1))))) (.lam (.var 1))))), (.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15989
def r15991 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))) (.lam (.var 2))))) (.var 1))
theorem reject15991 : ¬ Reader r15991 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[],[8],[6],[0],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.lam 8 (.var 2 [6]) [8]) [7]) []) [6]) []) (.lam 9 (.var 2 [0]) [9]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15991
def r15992 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.var 2))))) (.var 1))
theorem reject15992 : ¬ Reader r15992 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.var 3))))) (.lam (.lam (.var 2)))))) [(.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.var 4)))))), (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.var 6))))) (.lam (.lam (.var 2)))))) (.lam (.lam (.var 2))))))), (.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15992
def r15993 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject15993 : ¬ Reader r15993 := by
  exact replay_loop true [] 2 9 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))) (.lam (.var 3))))))) [(.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15993
def r15994 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 3))))))) (.var 1)))) (.var 1))
theorem reject15994 : ¬ Reader r15994 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[],[]] [[],[],[],[],[],[],[],[8],[9],[6],[],[12],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.lam 8 (.lam 9 (.var 3 [6]) [9]) [8]) [7]) []) [6]) []) (.var 1 [0]) []) [5]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15994
def r15995 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 1)))) (.var 1))
theorem reject15995 : ¬ Reader r15995 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 1))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 2)))) (.lam (.lam (.lam (.var 3))))))) [(.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 4)))))), (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 6)))) (.lam (.lam (.lam (.var 3))))))) (.lam (.lam (.lam (.var 3))))))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15995
def r15996 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15996 : ¬ Reader r15996 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.var 7))))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.var 7)))))))))))) [(.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.var 6)))))))))] [(.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.var 4)))))), (.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15996
def r15997 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))) (.var 1))
theorem reject15997 : ¬ Reader r15997 := by
  exact replay_loop true [] 7 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15997
def r15998 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))) (.var 1))
theorem reject15998 : ¬ Reader r15998 := by
  exact replay_loop true [] 9 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15998
def r15999 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject15999 : ¬ Reader r15999 := by
  exact replay_loop true [] 10 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0)) (.lam (.var 3)))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15999
def r16000 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject16000 : ¬ Reader r16000 := by
 exact mixed_reduct true [[1, 1, 2, 0, 1], [1, 1, 2, 0], [1, 1]] [[1], [1, 2], [1, 1]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))))) [(.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16000
def r16001 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.lam (.var 1)))) (.var 1)))) (.var 1))
theorem reject16001 : ¬ Reader r16001 := by
 exact mixed_reduct true [[1, 1, 2, 0, 1], [1, 1, 2, 0], [1, 1], [1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2)))))))) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16001
end Blc.HandlerLet.Slice45Main0481
