import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0478
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r15841 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1)))) (.var 1))
theorem reject15841 : ¬ Reader r15841 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 1))))))) (.var 2)) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 1))))))) (.var 2)) (.lam (.lam (.var 1))))))) (.var 0)) [(.lam (.lam (.var 1)))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject15841
def r15842 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))) (.var 1)))) (.var 1))
theorem reject15842 : ¬ Reader r15842 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))) (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))) (.var 3)))) (.lam (.lam (.var 1))))))) [(.lam (.lam (.var 1)))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15842
def r15843 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 0))) (.lam (.var 2))))) (.var 1))
theorem reject15843 : ¬ Reader r15843 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 0))) (.lam (.var 2)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 0))) (.lam (.var 4)))))))) [] [(.lam (.var 0)), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15843
def r15844 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.var 1)))) (.var 1)))) (.var 1))
theorem reject15844 : ¬ Reader r15844 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.var 1)))) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.var 1)))) (.var 3))))))) [] [(.lam (.lam (.var 1))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15844
def r15845 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.var 1)) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject15845 : ¬ Reader r15845 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.var 1)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.var 3)) (.lam (.lam (.var 1))))))))) [] [(.var 0), (.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15845
def r15846 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 2))) (.lam (.var 0))))) (.var 1))
theorem reject15846 : ¬ Reader r15846 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 2))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2))))) (.lam (.var 4))) (.lam (.var 0)))))))) [] [(.lam (.var 1)), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15846
def r15847 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15847 : ¬ Reader r15847 := by
 exact BodyLetGrow.grow_reduct true [[1, 1]] [(.lam (.lam (.var 2)))] [] [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel)
#print axioms reject15847
def r15848 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15848 : ¬ Reader r15848 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5)))))))) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2))), (.lam (.lam (.var 2)))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15848
def r15849 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15849 : ¬ Reader r15849 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15849
def r15850 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))))) (.var 1))
theorem reject15850 : ¬ Reader r15850 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 4)))))))) [(.lam (.lam (.lam (.app (.var 0) (.var 3)))))] [(.lam (.lam (.lam (.app (.var 0) (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15850
def r15851 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.lam (.var 1)))))))) (.var 1))
theorem reject15851 : ¬ Reader r15851 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.lam (.var 1)))))))) [(.lam (.lam (.app (.var 2) (.lam (.var 1)))))] [(.lam (.lam (.app (.var 2) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15851
def r15852 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.var 4)))))))) (.var 1))
theorem reject15852 : ¬ Reader r15852 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.var 4)))))))) [(.lam (.lam (.app (.var 0) (.lam (.var 3)))))] [(.lam (.lam (.app (.var 0) (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15852
def r15853 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.lam (.var 2)))))))) (.var 1))
theorem reject15853 : ¬ Reader r15853 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.lam (.var 2)))))))) [(.lam (.app (.var 1) (.lam (.lam (.var 2)))))] [(.lam (.app (.var 1) (.lam (.lam (.var 2))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15853
def r15854 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject15854 : ¬ Reader r15854 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.var 4)))))))) [(.lam (.app (.var 0) (.lam (.lam (.var 3)))))] [(.lam (.app (.var 0) (.lam (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15854
def r15855 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15855 : ¬ Reader r15855 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.var 4)))))))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15855
def r15856 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject15856 : ¬ Reader r15856 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.lam (.lam (.var 1))))))) (.lam (.lam (.var 1)))) [(.lam (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject15856
def r15857 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2))))))) (.var 1))
theorem reject15857 : ¬ Reader r15857 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2)))))) (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2)))))) (.var 0)) (.var 1)))) [(.var 0), (.lam (.lam (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15857
def r15858 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2))))))) (.var 1))
theorem reject15858 : ¬ Reader r15858 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 2))))))) [(.lam (.lam (.lam (.var 2))))] [(.var 0), (.var 0), (.lam (.lam (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15858
def r15859 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15859 : ¬ Reader r15859 := by
  exact replay_loop true [] 2 4 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))) (.lam (.app (.var 0) (.var 1)))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15859
def r15860 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject15860 : ¬ Reader r15860 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15860
def r15861 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))) (.var 1))
theorem reject15861 : ¬ Reader r15861 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1], [1, 1, 2, 1], [1, 1, 2, 1, 0, 0], [1, 1, 2], [1, 1]] [[1, 1, 2, 0, 0, 1], [1, 1, 2, 0, 0], [1, 1, 1, 1], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.var 5))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15861
def r15862 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))) (.var 1))
theorem reject15862 : ¬ Reader r15862 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1], [1, 1, 2, 1], [1, 1, 2, 1, 0, 0], [1, 1, 2], [1, 1]] [[1, 1, 2, 0, 0, 1], [1, 1, 2, 0, 0], [1, 1, 1, 1], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 5)) (.lam (.var 0)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15862
def r15863 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 1))
theorem reject15863 : ¬ Reader r15863 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15863
def r15864 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject15864 : ¬ Reader r15864 := by
 exact mixed_reduct true [[1, 1, 2, 0], [1, 1, 2, 0, 1], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15864
def r15865 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))) (.var 1))
theorem reject15865 : ¬ Reader r15865 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 4))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15865
def r15866 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.var 1))
theorem reject15866 : ¬ Reader r15866 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15866
def r15867 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.var 1))
theorem reject15867 : ¬ Reader r15867 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15867
def r15868 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject15868 : ¬ Reader r15868 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15868
def r15869 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 1))
theorem reject15869 : ¬ Reader r15869 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15869
def r15870 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 1))
theorem reject15870 : ¬ Reader r15870 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15870
def r15871 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2))))))))) (.var 1))
theorem reject15871 : ¬ Reader r15871 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15871
def r15872 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2))))))))) (.var 1))
theorem reject15872 : ¬ Reader r15872 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15872
def r15873 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1))))))))) (.var 1))
theorem reject15873 : ¬ Reader r15873 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15873
def r15874 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.lam (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject15874 : ¬ Reader r15874 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15874
def r15875 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))) (.var 1))
theorem reject15875 : ¬ Reader r15875 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject15875
def r15876 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 1))))))) (.var 0)))) (.var 1))
theorem reject15876 : ¬ Reader r15876 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.lam (.app (.var 0) (.var 1))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15876
def r15877 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 4))))))) (.var 0)))) (.var 1))
theorem reject15877 : ¬ Reader r15877 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 4))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 5))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15877
def r15878 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 0))))))) (.var 0)))) (.var 1))
theorem reject15878 : ¬ Reader r15878 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.lam (.var 0))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15878
def r15879 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.var 1))))) (.var 0)))) (.var 1))
theorem reject15879 : ¬ Reader r15879 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.lam (.var 0))) (.var 1))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15879
def r15880 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))) (.var 0)))) (.var 1))
theorem reject15880 : ¬ Reader r15880 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.lam (.var 0))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject15880
end Blc.HandlerLet.Slice45Main0478
