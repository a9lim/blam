import Blc.SelfintRootLetBinaryOrbit
import Certificates
namespace Blc.Slice45Demand13233
open Term SelfintClass SelfintLowerBound WeakHeadClock
set_option linter.unusedSimpArgs false
set_option maxRecDepth 16000
def F0 : Term := (.lam (.app (.var 0) (.var 0)))
def F1 (x0 : Term) : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))) (shift 1 0 x0)))
def F2 : Term := (.lam (.app (.var 0) (.lam (.lam (.var 2)))))
def F3 (x0 : Term) : Term := (.lam (.lam (shift 2 0 x0)))
def F4 (x1 : Term) : Term := (.lam (shift 1 0 x1))
theorem weak0 (y : Term) : weakStep (.app (F0 ) y) = some (.app y y) := by
 simp (disch := decide) [F0,F1,F2,F3,F4,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step0 (y : Term) : Beta (.app (F0 ) y) (.app y y) := weakStep_beta (weak0 y)
theorem weak1 (x0 y : Term) : weakStep (.app (F1 x0) y) = some (.app (.app y (.app y (.app y (F2 )))) x0) := by
 simp (disch := decide) [F0,F1,F2,F3,F4,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step1 (x0 y : Term) : Beta (.app (F1 x0) y) (.app (.app y (.app y (.app y (F2 )))) x0) := weakStep_beta (weak1 x0 y)
theorem weak2 (y : Term) : weakStep (.app (F2 ) y) = some (.app y (F3 y)) := by
 simp (disch := decide) [F0,F1,F2,F3,F4,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step2 (y : Term) : Beta (.app (F2 ) y) (.app y (F3 y)) := weakStep_beta (weak2 y)
theorem weak3 (x0 y : Term) : weakStep (.app (F3 x0) y) = some (F4 x0) := by
 simp (disch := decide) [F0,F1,F2,F3,F4,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step3 (x0 y : Term) : Beta (.app (F3 x0) y) (F4 x0) := weakStep_beta (weak3 x0 y)
theorem weak4 (x1 y : Term) : weakStep (.app (F4 x1) y) = some x1 := by
 simp (disch := decide) [F0,F1,F2,F3,F4,weakStep,contract,substDec,shift_shift0,substDec_shift0,shift_zero]
theorem step4 (x1 y : Term) : Beta (.app (F4 x1) y) x1 := weakStep_beta (weak4 x1 y)
def n0 : Term := .var 0
def n1 : Term := .var 1
def n2 : Term := F0 
def n3 : Term := F1 n0
def n4 : Term := .app n2 n3
def n5 : Term := .app n4 n1
def n6 : Term := .app n3 n3
def n7 : Term := F2 
def n8 : Term := .app n3 n7
def n9 : Term := .app n3 n8
def n10 : Term := .app n3 n9
def n11 : Term := .app n10 n0
def n12 : Term := .app n9 n7
def n13 : Term := .app n9 n12
def n14 : Term := .app n9 n13
def n15 : Term := .app n14 n0
def n16 : Term := .app n8 n7
def n17 : Term := .app n8 n16
def n18 : Term := .app n8 n17
def n19 : Term := .app n18 n0
def n20 : Term := .app n7 n7
def n21 : Term := .app n7 n20
def n22 : Term := .app n7 n21
def n23 : Term := .app n22 n0
def n24 : Term := F3 n21
def n25 : Term := .app n21 n24
def n26 : Term := F3 n20
def n27 : Term := .app n20 n26
def n28 : Term := F3 n7
def n29 : Term := .app n7 n28
def n30 : Term := F3 n28
def n31 : Term := .app n28 n30
def n32 : Term := F4 n7
def n33 : Term := F3 n24
def n34 : Term := .app n24 n33
def n35 : Term := F4 n21
def n36 : Term := F3 n17
def n37 : Term := .app n17 n36
def n38 : Term := F3 n16
def n39 : Term := .app n16 n38
def n40 : Term := F3 n36
def n41 : Term := .app n36 n40
def n42 : Term := F4 n17
def n43 : Term := F3 n13
def n44 : Term := .app n13 n43
def n45 : Term := F3 n12
def n46 : Term := .app n12 n45
def n47 : Term := F3 n43
def n48 : Term := .app n43 n47
def n49 : Term := F4 n13
def n50 : Term := F3 n0
def n51 : Term := .app n0 n50
def n52 : Term := .app n51 n1
theorem ev2 : Betas n2 n2 := .refl _
theorem ev3 : Betas n3 n3 := .refl _
theorem ev7 : Betas n7 n7 := .refl _
theorem ev28 : Betas n28 n28 := .refl _
theorem ev32 : Betas n32 n32 := .refl _
theorem ev31 : Betas n31 n32 := betas_trans (betas_appL n30 ev28) (.head (step3 n7 n30) ev32)
theorem ev29 : Betas n29 n32 := betas_trans (betas_appL n28 ev7) (.head (step2 n28) ev31)
theorem ev20 : Betas n20 n32 := betas_trans (betas_appL n7 ev7) (.head (step2 n7) ev29)
theorem ev27 : Betas n27 n7 := betas_trans (betas_appL n26 ev20) (.head (step4 n7 n26) ev7)
theorem ev21 : Betas n21 n7 := betas_trans (betas_appL n20 ev7) (.head (step2 n20) ev27)
theorem ev24 : Betas n24 n24 := .refl _
theorem ev35 : Betas n35 n35 := .refl _
theorem ev34 : Betas n34 n35 := betas_trans (betas_appL n33 ev24) (.head (step3 n21 n33) ev35)
theorem ev25 : Betas n25 n35 := betas_trans (betas_appL n24 ev21) (.head (step2 n24) ev34)
theorem ev22 : Betas n22 n35 := betas_trans (betas_appL n21 ev7) (.head (step2 n21) ev25)
theorem ev23 : Betas n23 n7 := betas_trans (betas_appL n0 ev22) (.head (step4 n21 n0) ev21)
theorem ev8 : Betas n8 n7 := betas_trans (betas_appL n7 ev3) (.head (step1 n0 n7) ev23)
theorem ev16 : Betas n16 n32 := betas_trans (betas_appL n7 ev8) (.head (step2 n7) ev29)
theorem ev39 : Betas n39 n7 := betas_trans (betas_appL n38 ev16) (.head (step4 n7 n38) ev7)
theorem ev17 : Betas n17 n7 := betas_trans (betas_appL n16 ev8) (.head (step2 n16) ev39)
theorem ev36 : Betas n36 n36 := .refl _
theorem ev42 : Betas n42 n42 := .refl _
theorem ev41 : Betas n41 n42 := betas_trans (betas_appL n40 ev36) (.head (step3 n17 n40) ev42)
theorem ev37 : Betas n37 n42 := betas_trans (betas_appL n36 ev17) (.head (step2 n36) ev41)
theorem ev18 : Betas n18 n42 := betas_trans (betas_appL n17 ev8) (.head (step2 n17) ev37)
theorem ev19 : Betas n19 n7 := betas_trans (betas_appL n0 ev18) (.head (step4 n17 n0) ev17)
theorem ev9 : Betas n9 n7 := betas_trans (betas_appL n8 ev3) (.head (step1 n0 n8) ev19)
theorem ev12 : Betas n12 n32 := betas_trans (betas_appL n7 ev9) (.head (step2 n7) ev29)
theorem ev46 : Betas n46 n7 := betas_trans (betas_appL n45 ev12) (.head (step4 n7 n45) ev7)
theorem ev13 : Betas n13 n7 := betas_trans (betas_appL n12 ev9) (.head (step2 n12) ev46)
theorem ev43 : Betas n43 n43 := .refl _
theorem ev49 : Betas n49 n49 := .refl _
theorem ev48 : Betas n48 n49 := betas_trans (betas_appL n47 ev43) (.head (step3 n13 n47) ev49)
theorem ev44 : Betas n44 n49 := betas_trans (betas_appL n43 ev13) (.head (step2 n43) ev48)
theorem ev14 : Betas n14 n49 := betas_trans (betas_appL n13 ev9) (.head (step2 n13) ev44)
theorem ev15 : Betas n15 n7 := betas_trans (betas_appL n0 ev14) (.head (step4 n13 n0) ev13)
theorem ev10 : Betas n10 n7 := betas_trans (betas_appL n9 ev3) (.head (step1 n0 n9) ev15)
theorem ev0 : Betas n0 n0 := .refl _
theorem ev51 : Betas n51 n51 := betas_appL n50 ev0
theorem ev11 : Betas n11 n51 := betas_trans (betas_appL n0 ev10) (.head (step2 n0) ev51)
theorem ev6 : Betas n6 n51 := betas_trans (betas_appL n3 ev3) (.head (step1 n0 n3) ev11)
theorem ev4 : Betas n4 n51 := betas_trans (betas_appL n3 ev2) (.head (step0 n3) ev6)
theorem ev5 : Betas n5 n52 := betas_appL n1 ev4
def r13233 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))) (.var 1)))) (.var 1))
theorem reject13233 : ¬ Reader r13233 := by
 intro hr
 exact reader_not_rigid (SelfintRootLetPowers.reader_betas hr ev5) (.app _ (.app _ (.var _)))
#print axioms reject13233
end Blc.Slice45Demand13233
