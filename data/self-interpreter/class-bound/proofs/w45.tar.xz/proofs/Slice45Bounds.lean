import Slice45Arity100B0
namespace Blc.Slice45Bounds
open Slice45Arity100B0
theorem upper {a b m : Nat} (hm : 0<m) (ha : a≤m+1) (hb : b≤m+1) : flow a b ≤ m := by
 by_cases hf : a=0 <;> by_cases hx : b=0 <;> simp [flow,hf,hx] <;> omega
theorem leftBound (a b : Nat) : a ≤ flow a b+1 := by
 by_cases hf : a=0 <;> simp [flow,hf] <;> omega
theorem rightBound (a b : Nat) (ha : 0<a) : b ≤ flow a b+1 := by
 by_cases hx : b=0 <;> simp [flow,hx,Nat.ne_of_gt ha] <;> omega
theorem zeroArg (a b : Nat) (ha : 0<a) (hz : flow a b=0) : b=0 := by
 by_cases hx : b=0
 · exact hx
 · simp [flow,hx,Nat.ne_of_gt ha] at hz
end Blc.Slice45Bounds
