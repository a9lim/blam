import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0482
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r16002 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 0))) (.lam (.var 2))))) (.var 1))
theorem reject16002 : ¬ Reader r16002 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 0))) (.lam (.var 2)))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 0))) (.lam (.var 2))))) [(.lam (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 0))) (.lam (.var 3)))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 0))) (.lam (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16002
def r16003 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1))
theorem reject16003 : ¬ Reader r16003 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1)))) [(.lam (.lam (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 3))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16003
def r16005 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.var 2))))) (.var 1))
theorem reject16005 : ¬ Reader r16005 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.var 8)))))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.var 8))))))))))))) [(.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.var 7))))))))))] [(.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.var 4)))))), (.lam (.var 1)), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16005
def r16006 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1)))) (.var 1))
theorem reject16006 : ¬ Reader r16006 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 9))))))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 9)))))))))))))) [(.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 8)))))))))))] [(.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 4)))))), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16006
def r16007 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16007 : ¬ Reader r16007 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.app (.var 0) (.var 0))))) [(.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.app (.var 0) (.var 0))))), (.lam (.lam (.lam (.var 3))))] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16007
def r16008 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16008 : ¬ Reader r16008 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.var 0))))) [(.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.var 0)))))), (.lam (.lam (.lam (.var 3))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16008
def r16009 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16009 : ¬ Reader r16009 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) [(.lam (.lam (.lam (.var 3))))] [(.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))), (.lam (.lam (.lam (.var 3)))), (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16009
def r16010 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16010 : ¬ Reader r16010 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.var 0)) (.var 0)))) [(.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))) (.var 0)) (.var 0))), (.lam (.lam (.lam (.var 3))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16010
def r16011 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16011 : ¬ Reader r16011 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) [(.lam (.lam (.lam (.var 3))))] [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))), (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))) (.var 0))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16011
def r16012 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject16012 : ¬ Reader r16012 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))))) [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16012
def r16013 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject16013 : ¬ Reader r16013 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2)))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16013
def r16014 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject16014 : ¬ Reader r16014 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 4)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 5)))))) (.var 0))))) [] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16014
def r16015 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.var 1))
theorem reject16015 : ¬ Reader r16015 := by
  exact replay_loop true [] 2 4 (.app (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 3)))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 5)))) (.var 0)) (.var 0)))))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16015
def r16016 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject16016 : ¬ Reader r16016 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1], [1, 1, 1], [1, 1, 1, 2], [1, 1, 1, 2, 0, 0], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 0, 0], [1, 1, 1, 1]] [[1, 2], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 1, 1], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))))) [(.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject16016
def r16017 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.var 1))
theorem reject16017 : ¬ Reader r16017 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 2))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16017
def r16018 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject16018 : ¬ Reader r16018 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 2, 0], [1, 1, 2, 2, 0, 0], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0, 2, 0], [1, 1, 2, 0], [1, 1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.var 4))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16018
def r16019 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject16019 : ¬ Reader r16019 := by
  exact replay_loop true [] 1 6 (.app (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4)))))))) [(.lam (.lam (.var 2))), (.app (.app (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4)))))))) (.lam (.lam (.var 2)))) (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.lam (.var 4)))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16019
def r16020 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject16020 : ¬ Reader r16020 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.lam (.var 4)))))))) [(.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16020
def r16021 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject16021 : ¬ Reader r16021 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1, 1, 0, 1], [1, 1, 1, 0, 1, 0], [1, 1, 1, 0], [1, 1, 1, 0, 1], [1, 1, 1, 0, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 1) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16021
def r16022 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject16022 : ¬ Reader r16022 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 3))))))) [(.lam (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 4)))))) (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16022
def r16023 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject16023 : ¬ Reader r16023 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject16023
def r16024 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject16024 : ¬ Reader r16024 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject16024
def r16025 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.var 1))
theorem reject16025 : ¬ Reader r16025 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0, 0, 1], [1, 1, 2, 0, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16025
def r16026 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.var 1))
theorem reject16026 : ¬ Reader r16026 := by
  exact replay_loop true [] 3 6 (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16026
def r16027 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 1))
theorem reject16027 : ¬ Reader r16027 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0, 0, 1], [1, 1, 2, 0, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16027
def r16028 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 1))
theorem reject16028 : ¬ Reader r16028 := by
  exact replay_loop true [] 7 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 6))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 7))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16028
def r16029 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 1))
theorem reject16029 : ¬ Reader r16029 := by
  exact replay_loop true [] 3 6 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16029
def r16030 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.lam (.var 3))))))) (.var 1))
theorem reject16030 : ¬ Reader r16030 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16030
def r16031 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject16031 : ¬ Reader r16031 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16031
def r16032 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1))))))))) (.var 1))
theorem reject16032 : ¬ Reader r16032 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16032
def r16033 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))) (.var 1))
theorem reject16033 : ¬ Reader r16033 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2)))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16033
def r16034 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))) (.var 1))
theorem reject16034 : ¬ Reader r16034 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16034
def r16035 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))) (.var 1))
theorem reject16035 : ¬ Reader r16035 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16035
def r16036 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))) (.var 1))
theorem reject16036 : ¬ Reader r16036 := by
  exact replay_loop true [] 7 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 7)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 8)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))) (.var 0)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16036
def r16037 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0)))) (.var 1))
theorem reject16037 : ¬ Reader r16037 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16037
def r16038 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 2)))) (.var 0)))) (.var 1))
theorem reject16038 : ¬ Reader r16038 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.var 3)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16038
def r16039 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.app (.var 0) (.var 1))) (.var 0)))) (.var 1))
theorem reject16039 : ¬ Reader r16039 := by
 exact mixed_reduct true [[1, 1, 2, 0, 1], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject16039
def r16040 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 0))))))) (.var 0)))) (.var 1))
theorem reject16040 : ¬ Reader r16040 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.var 0))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16040
def r16041 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 0))))))) (.var 0)))) (.var 1))
theorem reject16041 : ¬ Reader r16041 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.var 0))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16041
def r16042 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 4))))))) (.var 0)))) (.var 1))
theorem reject16042 : ¬ Reader r16042 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 4))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 5))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject16042
end Blc.HandlerLet.Slice45Main0482
