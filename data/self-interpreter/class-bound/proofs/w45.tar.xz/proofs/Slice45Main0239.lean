import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice45Main0239
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r7036 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7036 : ¬ Reader r7036 := by
  exact replay_loop true [] 5 2 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 1)))) [(.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 2)))) (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 2)))))), (.var 0)] [(.lam (.app (.app (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))))) (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3)))))) (.app (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))))) (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.var 0) (.var 0))) (.var 3)))))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7036
def r7037 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7037 : ¬ Reader r7037 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))))) [(.var 0), (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))))) (.var 0))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7037
def r7038 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7038 : ¬ Reader r7038 := by
  exact replay_loop true [] 8 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.var 0), (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1)))), (.var 0), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7038
def r7039 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7039 : ¬ Reader r7039 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 1) (.var 0))))) [(.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 1) (.var 0))))), (.app (.var 0) (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 2) (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7039
def r7040 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7040 : ¬ Reader r7040 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 0) (.var 1))))) [(.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0)), (.app (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 0) (.var 2)))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7040
def r7041 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7041 : ¬ Reader r7041 := by
  exact replay_loop true [] 6 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))), (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 0))))), (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 2) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 2) (.var 0))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7041
def r7042 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7042 : ¬ Reader r7042 := by
  exact replay_loop true [] 6 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)), (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 0) (.var 1)))) (.var 0)), (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 0) (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.var 0) (.var 2)))))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7042
def r7043 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7043 : ¬ Reader r7043 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1)) (.var 0)))) [(.var 0), (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1)) (.var 0))), (.var 0), (.lam (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 2)) (.var 0)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7043
def r7044 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7044 : ¬ Reader r7044 := by
  exact replay_loop true [] 6 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.var 0), (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))), (.var 0), (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1)) (.var 0))), (.var 0), (.lam (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 2)) (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7044
def r7045 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7045 : ¬ Reader r7045 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))))) [(.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))] [(.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7045
def r7046 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7046 : ¬ Reader r7046 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 1))))) [(.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0))] [(.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7046
def r7047 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7047 : ¬ Reader r7047 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))) [(.var 0), (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))] [(.var 0), (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7047
def r7048 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7048 : ¬ Reader r7048 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0))) (.var 1)))) [(.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0))) (.var 1))))), (.var 0), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7048
def r7049 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7049 : ¬ Reader r7049 := by
  exact replay_loop true [] 8 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))), (.var 0), (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))), (.var 0), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7049
def r7050 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7050 : ¬ Reader r7050 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 0)) (.var 1)))) [(.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 0)) (.var 1))), (.var 0), (.lam (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 0)) (.var 2))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7050
def r7051 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7051 : ¬ Reader r7051 := by
  exact replay_loop true [] 6 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) [] [(.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))), (.var 0), (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.var 1))), (.var 0), (.lam (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.var 2))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7051
def r7052 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject7052 : ¬ Reader r7052 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))) (.var 1)))) [(.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))), (.var 0)] [(.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7052
def r7053 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7053 : ¬ Reader r7053 := by
  exact replay_loop true [] 2 6 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))) [(.app (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))) (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))))), (.var 0), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7053
def r7054 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7054 : ¬ Reader r7054 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))) [(.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7054
def r7055 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7055 : ¬ Reader r7055 := by
  exact replay_loop true [] 2 4 (.app (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 1) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 1) (.var 1))))))) [(.app (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 1) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 1) (.var 1))))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7055
def r7056 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7056 : ¬ Reader r7056 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1))))))) [(.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 4))) (.var 1))))))) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 4))) (.var 1)))))))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7056
def r7057 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7057 : ¬ Reader r7057 := by
  exact replay_loop true [] 10 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) [(.var 0)] [(.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))), (.var 0), (.var 0), (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7057
def r7058 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7058 : ¬ Reader r7058 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)) (.var 1)))))) [(.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)) (.var 1))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7058
def r7059 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7059 : ¬ Reader r7059 := by
  exact replay_loop true [] 8 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) [(.var 0)] [(.lam (.app (.app (.var 0) (.var 0)) (.var 1))), (.var 0), (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 1))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7059
def r7060 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))
theorem reject7060 : ¬ Reader r7060 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))) [(.lam (.app (.app (.var 0) (.var 0)) (.var 1)))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7060
def r7061 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7061 : ¬ Reader r7061 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7061
def r7062 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7062 : ¬ Reader r7062 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7062
def r7063 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7063 : ¬ Reader r7063 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7063
def r7064 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7064 : ¬ Reader r7064 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7064
def r7065 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7065 : ¬ Reader r7065 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7065
def r7066 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject7066 : ¬ Reader r7066 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7066
def r7067 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1))
theorem reject7067 : ¬ Reader r7067 := by
  exact replay_loop true [] 4 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1))))))) [(.app (.var 0) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7067
def r7068 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject7068 : ¬ Reader r7068 := by
  exact replay_loop true [] 4 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1))))))) [(.app (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1)))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7068
def r7069 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1))
theorem reject7069 : ¬ Reader r7069 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7069
def r7070 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject7070 : ¬ Reader r7070 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7070
def r7071 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1))
theorem reject7071 : ¬ Reader r7071 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7071
def r7072 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject7072 : ¬ Reader r7072 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject7072
def r7073 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1))
theorem reject7073 : ¬ Reader r7073 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))) (.var 1)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7073
def r7074 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject7074 : ¬ Reader r7074 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))) (.var 1)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7074
def r7075 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1))
theorem reject7075 : ¬ Reader r7075 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) [(.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))] [(.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject7075
end Blc.HandlerLet.Slice45Main0239
