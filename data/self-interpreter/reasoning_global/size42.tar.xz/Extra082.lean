import Batch082
import ExtraBase
namespace Blc.Floor42.Extra082
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196710522094 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1196710522094 : ¬ IsSelfInterpreter e1196710522094 := by
  intro he
  have hp := replay_sound (t := e1196710522094) (u := t_e1196710522094) (ps := [[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710522094) (by decide) (by decide) hj
#print axioms ex_e1196710522094
private def t_e1196710522102 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1)))))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1))))))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1))))))))))) (.var 1)))))))
theorem ex_e1196710522102 : ¬ IsSelfInterpreter e1196710522102 := by
  intro he
  have hp := replay_sound (t := e1196710522102) (u := t_e1196710522102) (ps := [[],[.left],[.left,.right,.under,.under,.right],[.left],[.left,.right,.under,.under,.right],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710522102) (by decide) (by decide) hj
#print axioms ex_e1196710522102
private def t_e1196710522486 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))))))
theorem ex_e1196710522486 : ¬ IsSelfInterpreter e1196710522486 := by
  intro he
  have hp := replay_sound (t := e1196710522486) (u := t_e1196710522486) (ps := [[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710522486) (by decide) (by decide) hj
#print axioms ex_e1196710522486
private def t_e1196710524142 : Term := (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1196710524142 : ¬ IsSelfInterpreter e1196710524142 := by
  intro he
  have hp := replay_sound (t := e1196710524142) (u := t_e1196710524142) (ps := [[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710524142) (by decide) (by decide) hj
#print axioms ex_e1196710524142
private def t_e1196710524150 : Term := (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.var 1)))))))
theorem ex_e1196710524150 : ¬ IsSelfInterpreter e1196710524150 := by
  intro he
  have hp := replay_sound (t := e1196710524150) (u := t_e1196710524150) (ps := [[],[.left],[.left,.right,.under,.under,.right],[.left],[.left,.right,.under,.under,.right],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710524150) (by decide) (by decide) hj
#print axioms ex_e1196710524150
private def t_e1196710525558 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem ex_e1196710525558 : ¬ IsSelfInterpreter e1196710525558 := by
  intro he
  have hp := replay_sound (t := e1196710525558) (u := t_e1196710525558) (ps := [[],[.left],[.left,.right,.under,.under,.left],[.left],[.left,.right,.under,.under,.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196710525558) (by decide) (by decide) hj
#print axioms ex_e1196710525558
private def t_e1196710532974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem ex_e1196710532974 : ¬ IsSelfInterpreter e1196710532974 := by
  intro he
  have hp := replay_sound (t := e1196710532974) (u := t_e1196710532974) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2))) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1196710532974
private def t_e1196710533046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem ex_e1196710533046 : ¬ IsSelfInterpreter e1196710533046 := by
  intro he
  have hp := replay_sound (t := e1196710533046) (u := t_e1196710533046) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1196710533046
private def t_e1196710534774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem ex_e1196710534774 : ¬ IsSelfInterpreter e1196710534774 := by
  intro he
  have hp := replay_sound (t := e1196710534774) (u := t_e1196710534774) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1)))) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1196710534774
end Blc.Floor42.Extra082
