import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1204481909098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204481909098 : Closed e1204481909098 ∧ code e1204481909098 = 5602528420202 := by decide
private def t_e1204481909098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204481909098 : ¬ IsSelfInterpreter e1204481909098 :=
  wSource (t := t_e1204481909098) (replay_sound (ps := []) (t := e1204481909098) (by decide)) (by decide)
def e1204481909146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204481909146 : Closed e1204481909146 ∧ code e1204481909146 = 5602528420250 := by decide
private def t_e1204481909146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204481909146 : ¬ IsSelfInterpreter e1204481909146 :=
  wSource (t := t_e1204481909146) (replay_sound (ps := []) (t := e1204481909146) (by decide)) (by decide)
def e1204482059802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482059802 : Closed e1204482059802 ∧ code e1204482059802 = 5602528570906 := by decide
private def t_e1204482059802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482059802 : ¬ IsSelfInterpreter e1204482059802 :=
  wSource (t := t_e1204482059802) (replay_sound (ps := []) (t := e1204482059802) (by decide)) (by decide)
def e1204482062874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482062874 : Closed e1204482062874 ∧ code e1204482062874 = 5602528573978 := by decide
private def t_e1204482062874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482062874 : ¬ IsSelfInterpreter e1204482062874 :=
  wSource (t := t_e1204482062874) (replay_sound (ps := []) (t := e1204482062874) (by decide)) (by decide)
def e1204482075162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482075162 : Closed e1204482075162 ∧ code e1204482075162 = 5602528586266 := by decide
private def t_e1204482075162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482075162 : ¬ IsSelfInterpreter e1204482075162 :=
  wSource (t := t_e1204482075162) (replay_sound (ps := []) (t := e1204482075162) (by decide)) (by decide)
def e1204482108954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482108954 : Closed e1204482108954 ∧ code e1204482108954 = 5602528620058 := by decide
private def t_e1204482108954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482108954 : ¬ IsSelfInterpreter e1204482108954 :=
  wSource (t := t_e1204482108954) (replay_sound (ps := []) (t := e1204482108954) (by decide)) (by decide)
def e1204482112026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482112026 : Closed e1204482112026 ∧ code e1204482112026 = 5602528623130 := by decide
private def t_e1204482112026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482112026 : ¬ IsSelfInterpreter e1204482112026 :=
  wSource (t := t_e1204482112026) (replay_sound (ps := []) (t := e1204482112026) (by decide)) (by decide)
def e1204482138138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204482138138 : Closed e1204482138138 ∧ code e1204482138138 = 5602528649242 := by decide
theorem cert_e1204482138138 : check e1204482138138 [[]] .width = true := by decide
def e1204482138230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204482138230 : Closed e1204482138230 ∧ code e1204482138230 = 5602528649334 := by decide
private def t_e1204482138230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204482138230 : ¬ IsSelfInterpreter e1204482138230 :=
  wSource (t := t_e1204482138230) (replay_sound (ps := []) (t := e1204482138230) (by decide)) (by decide)
def e1204482138474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204482138474 : Closed e1204482138474 ∧ code e1204482138474 = 5602528649578 := by decide
private def t_e1204482138474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204482138474 : ¬ IsSelfInterpreter e1204482138474 :=
  wSource (t := t_e1204482138474) (replay_sound (ps := []) (t := e1204482138474) (by decide)) (by decide)
def e1204482138522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204482138522 : Closed e1204482138522 ∧ code e1204482138522 = 5602528649626 := by decide
private def t_e1204482138522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204482138522 : ¬ IsSelfInterpreter e1204482138522 :=
  wSource (t := t_e1204482138522) (replay_sound (ps := []) (t := e1204482138522) (by decide)) (by decide)
def e1204482185754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482185754 : Closed e1204482185754 ∧ code e1204482185754 = 5602528696858 := by decide
private def t_e1204482185754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482185754 : ¬ IsSelfInterpreter e1204482185754 :=
  wSource (t := t_e1204482185754) (replay_sound (ps := []) (t := e1204482185754) (by decide)) (by decide)
def e1204482187290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204482187290 : Closed e1204482187290 ∧ code e1204482187290 = 5602528698394 := by decide
theorem cert_e1204482187290 : check e1204482187290 [[]] .width = true := by decide
def e1204482187382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204482187382 : Closed e1204482187382 ∧ code e1204482187382 = 5602528698486 := by decide
private def t_e1204482187382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204482187382 : ¬ IsSelfInterpreter e1204482187382 :=
  wSource (t := t_e1204482187382) (replay_sound (ps := []) (t := e1204482187382) (by decide)) (by decide)
def e1204482187626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204482187626 : Closed e1204482187626 ∧ code e1204482187626 = 5602528698730 := by decide
private def t_e1204482187626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204482187626 : ¬ IsSelfInterpreter e1204482187626 :=
  wSource (t := t_e1204482187626) (replay_sound (ps := []) (t := e1204482187626) (by decide)) (by decide)
def e1204482187674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204482187674 : Closed e1204482187674 ∧ code e1204482187674 = 5602528698778 := by decide
private def t_e1204482187674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204482187674 : ¬ IsSelfInterpreter e1204482187674 :=
  wSource (t := t_e1204482187674) (replay_sound (ps := []) (t := e1204482187674) (by decide)) (by decide)
def e1204482266650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482266650 : Closed e1204482266650 ∧ code e1204482266650 = 5602528777754 := by decide
private def t_e1204482266650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482266650 : ¬ IsSelfInterpreter e1204482266650 :=
  wSource (t := t_e1204482266650) (replay_sound (ps := []) (t := e1204482266650) (by decide)) (by decide)
def e1204482267674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482267674 : Closed e1204482267674 ∧ code e1204482267674 = 5602528778778 := by decide
private def t_e1204482267674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482267674 : ¬ IsSelfInterpreter e1204482267674 :=
  wSource (t := t_e1204482267674) (replay_sound (ps := []) (t := e1204482267674) (by decide)) (by decide)
def e1204482271770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482271770 : Closed e1204482271770 ∧ code e1204482271770 = 5602528782874 := by decide
private def t_e1204482271770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482271770 : ¬ IsSelfInterpreter e1204482271770 :=
  wSource (t := t_e1204482271770) (replay_sound (ps := []) (t := e1204482271770) (by decide)) (by decide)
def e1204482291226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482291226 : Closed e1204482291226 ∧ code e1204482291226 = 5602528802330 := by decide
private def t_e1204482291226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482291226 : ¬ IsSelfInterpreter e1204482291226 :=
  wSource (t := t_e1204482291226) (replay_sound (ps := []) (t := e1204482291226) (by decide)) (by decide)
def e1204482292250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482292250 : Closed e1204482292250 ∧ code e1204482292250 = 5602528803354 := by decide
private def t_e1204482292250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482292250 : ¬ IsSelfInterpreter e1204482292250 :=
  wSource (t := t_e1204482292250) (replay_sound (ps := []) (t := e1204482292250) (by decide)) (by decide)
def e1204482301978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204482301978 : Closed e1204482301978 ∧ code e1204482301978 = 5602528813082 := by decide
theorem cert_e1204482301978 : check e1204482301978 [[]] .width = true := by decide
def e1204482302070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204482302070 : Closed e1204482302070 ∧ code e1204482302070 = 5602528813174 := by decide
private def t_e1204482302070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204482302070 : ¬ IsSelfInterpreter e1204482302070 :=
  wSource (t := t_e1204482302070) (replay_sound (ps := []) (t := e1204482302070) (by decide)) (by decide)
def e1204482302314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204482302314 : Closed e1204482302314 ∧ code e1204482302314 = 5602528813418 := by decide
private def t_e1204482302314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204482302314 : ¬ IsSelfInterpreter e1204482302314 :=
  wSource (t := t_e1204482302314) (replay_sound (ps := []) (t := e1204482302314) (by decide)) (by decide)
def e1204482302362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204482302362 : Closed e1204482302362 ∧ code e1204482302362 = 5602528813466 := by decide
private def t_e1204482302362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204482302362 : ¬ IsSelfInterpreter e1204482302362 :=
  wSource (t := t_e1204482302362) (replay_sound (ps := []) (t := e1204482302362) (by decide)) (by decide)
def e1204482316826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482316826 : Closed e1204482316826 ∧ code e1204482316826 = 5602528827930 := by decide
private def t_e1204482316826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482316826 : ¬ IsSelfInterpreter e1204482316826 :=
  wSource (t := t_e1204482316826) (replay_sound (ps := []) (t := e1204482316826) (by decide)) (by decide)
def e1204482318362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204482318362 : Closed e1204482318362 ∧ code e1204482318362 = 5602528829466 := by decide
theorem cert_e1204482318362 : check e1204482318362 [[]] .width = true := by decide
def e1204482318454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204482318454 : Closed e1204482318454 ∧ code e1204482318454 = 5602528829558 := by decide
private def t_e1204482318454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204482318454 : ¬ IsSelfInterpreter e1204482318454 :=
  wSource (t := t_e1204482318454) (replay_sound (ps := []) (t := e1204482318454) (by decide)) (by decide)
def e1204482318698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204482318698 : Closed e1204482318698 ∧ code e1204482318698 = 5602528829802 := by decide
private def t_e1204482318698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204482318698 : ¬ IsSelfInterpreter e1204482318698 :=
  wSource (t := t_e1204482318698) (replay_sound (ps := []) (t := e1204482318698) (by decide)) (by decide)
def e1204482318746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204482318746 : Closed e1204482318746 ∧ code e1204482318746 = 5602528829850 := by decide
private def t_e1204482318746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204482318746 : ¬ IsSelfInterpreter e1204482318746 :=
  wSource (t := t_e1204482318746) (replay_sound (ps := []) (t := e1204482318746) (by decide)) (by decide)
def e1204482727450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482727450 : Closed e1204482727450 ∧ code e1204482727450 = 5602529238554 := by decide
private def t_e1204482727450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482727450 : ¬ IsSelfInterpreter e1204482727450 :=
  wSource (t := t_e1204482727450) (replay_sound (ps := []) (t := e1204482727450) (by decide)) (by decide)
def e1204482731546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204482731546 : Closed e1204482731546 ∧ code e1204482731546 = 5602529242650 := by decide
private def t_e1204482731546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204482731546 : ¬ IsSelfInterpreter e1204482731546 :=
  wSource (t := t_e1204482731546) (replay_sound (ps := []) (t := e1204482731546) (by decide)) (by decide)
def e1204483223066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483223066 : Closed e1204483223066 ∧ code e1204483223066 = 5602529734170 := by decide
private def t_e1204483223066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483223066 : ¬ IsSelfInterpreter e1204483223066 :=
  wSource (t := t_e1204483223066) (replay_sound (ps := []) (t := e1204483223066) (by decide)) (by decide)
def e1204483225114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483225114 : Closed e1204483225114 ∧ code e1204483225114 = 5602529736218 := by decide
private def t_e1204483225114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483225114 : ¬ IsSelfInterpreter e1204483225114 :=
  wSource (t := t_e1204483225114) (replay_sound (ps := []) (t := e1204483225114) (by decide)) (by decide)
def e1204483239450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483239450 : Closed e1204483239450 ∧ code e1204483239450 = 5602529750554 := by decide
private def t_e1204483239450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483239450 : ¬ IsSelfInterpreter e1204483239450 :=
  wSource (t := t_e1204483239450) (replay_sound (ps := []) (t := e1204483239450) (by decide)) (by decide)
def e1204483242522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483242522 : Closed e1204483242522 ∧ code e1204483242522 = 5602529753626 := by decide
private def t_e1204483242522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483242522 : ¬ IsSelfInterpreter e1204483242522 :=
  wSource (t := t_e1204483242522) (replay_sound (ps := []) (t := e1204483242522) (by decide)) (by decide)
def e1204483249690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483249690 : Closed e1204483249690 ∧ code e1204483249690 = 5602529760794 := by decide
private def t_e1204483249690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483249690 : ¬ IsSelfInterpreter e1204483249690 :=
  wSource (t := t_e1204483249690) (replay_sound (ps := []) (t := e1204483249690) (by decide)) (by decide)
def e1204483250714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483250714 : Closed e1204483250714 ∧ code e1204483250714 = 5602529761818 := by decide
private def t_e1204483250714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483250714 : ¬ IsSelfInterpreter e1204483250714 :=
  wSource (t := t_e1204483250714) (replay_sound (ps := []) (t := e1204483250714) (by decide)) (by decide)
def e1204483321370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483321370 : Closed e1204483321370 ∧ code e1204483321370 = 5602529832474 := by decide
private def t_e1204483321370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483321370 : ¬ IsSelfInterpreter e1204483321370 :=
  wSource (t := t_e1204483321370) (replay_sound (ps := []) (t := e1204483321370) (by decide)) (by decide)
def e1204483323418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483323418 : Closed e1204483323418 ∧ code e1204483323418 = 5602529834522 := by decide
private def t_e1204483323418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483323418 : ¬ IsSelfInterpreter e1204483323418 :=
  wSource (t := t_e1204483323418) (replay_sound (ps := []) (t := e1204483323418) (by decide)) (by decide)
def e1204483419674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483419674 : Closed e1204483419674 ∧ code e1204483419674 = 5602529930778 := by decide
private def t_e1204483419674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483419674 : ¬ IsSelfInterpreter e1204483419674 :=
  wSource (t := t_e1204483419674) (replay_sound (ps := []) (t := e1204483419674) (by decide)) (by decide)
def e1204483422746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483422746 : Closed e1204483422746 ∧ code e1204483422746 = 5602529933850 := by decide
private def t_e1204483422746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483422746 : ¬ IsSelfInterpreter e1204483422746 :=
  wSource (t := t_e1204483422746) (replay_sound (ps := []) (t := e1204483422746) (by decide)) (by decide)
def e1204483448858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204483448858 : Closed e1204483448858 ∧ code e1204483448858 = 5602529959962 := by decide
theorem cert_e1204483448858 : check e1204483448858 [[]] .width = true := by decide
def e1204483448950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204483448950 : Closed e1204483448950 ∧ code e1204483448950 = 5602529960054 := by decide
private def t_e1204483448950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204483448950 : ¬ IsSelfInterpreter e1204483448950 :=
  wSource (t := t_e1204483448950) (replay_sound (ps := []) (t := e1204483448950) (by decide)) (by decide)
def e1204483449194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204483449194 : Closed e1204483449194 ∧ code e1204483449194 = 5602529960298 := by decide
private def t_e1204483449194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204483449194 : ¬ IsSelfInterpreter e1204483449194 :=
  wSource (t := t_e1204483449194) (replay_sound (ps := []) (t := e1204483449194) (by decide)) (by decide)
def e1204483449242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204483449242 : Closed e1204483449242 ∧ code e1204483449242 = 5602529960346 := by decide
private def t_e1204483449242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204483449242 : ¬ IsSelfInterpreter e1204483449242 :=
  wSource (t := t_e1204483449242) (replay_sound (ps := []) (t := e1204483449242) (by decide)) (by decide)
def e1204483470874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483470874 : Closed e1204483470874 ∧ code e1204483470874 = 5602529981978 := by decide
private def t_e1204483470874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483470874 : ¬ IsSelfInterpreter e1204483470874 :=
  wSource (t := t_e1204483470874) (replay_sound (ps := []) (t := e1204483470874) (by decide)) (by decide)
def e1204483471898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204483471898 : Closed e1204483471898 ∧ code e1204483471898 = 5602529983002 := by decide
private def t_e1204483471898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204483471898 : ¬ IsSelfInterpreter e1204483471898 :=
  wSource (t := t_e1204483471898) (replay_sound (ps := []) (t := e1204483471898) (by decide)) (by decide)
def e1204483481626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204483481626 : Closed e1204483481626 ∧ code e1204483481626 = 5602529992730 := by decide
theorem cert_e1204483481626 : check e1204483481626 [[]] .width = true := by decide
def e1204483481718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204483481718 : Closed e1204483481718 ∧ code e1204483481718 = 5602529992822 := by decide
private def t_e1204483481718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204483481718 : ¬ IsSelfInterpreter e1204483481718 :=
  wSource (t := t_e1204483481718) (replay_sound (ps := []) (t := e1204483481718) (by decide)) (by decide)
def e1204483481962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204483481962 : Closed e1204483481962 ∧ code e1204483481962 = 5602529993066 := by decide
private def t_e1204483481962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204483481962 : ¬ IsSelfInterpreter e1204483481962 :=
  wSource (t := t_e1204483481962) (replay_sound (ps := []) (t := e1204483481962) (by decide)) (by decide)
def e1204483482010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204483482010 : Closed e1204483482010 ∧ code e1204483482010 = 5602529993114 := by decide
private def t_e1204483482010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204483482010 : ¬ IsSelfInterpreter e1204483482010 :=
  wSource (t := t_e1204483482010) (replay_sound (ps := []) (t := e1204483482010) (by decide)) (by decide)
def e1204484693530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484693530 : Closed e1204484693530 ∧ code e1204484693530 = 5602531204634 := by decide
private def t_e1204484693530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484693530 : ¬ IsSelfInterpreter e1204484693530 :=
  wSource (t := t_e1204484693530) (replay_sound (ps := []) (t := e1204484693530) (by decide)) (by decide)
def e1204484699674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484699674 : Closed e1204484699674 ∧ code e1204484699674 = 5602531210778 := by decide
private def t_e1204484699674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484699674 : ¬ IsSelfInterpreter e1204484699674 :=
  wSource (t := t_e1204484699674) (replay_sound (ps := []) (t := e1204484699674) (by decide)) (by decide)
def e1204484943386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484943386 : Closed e1204484943386 ∧ code e1204484943386 = 5602531454490 := by decide
private def t_e1204484943386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484943386 : ¬ IsSelfInterpreter e1204484943386 :=
  wSource (t := t_e1204484943386) (replay_sound (ps := []) (t := e1204484943386) (by decide)) (by decide)
def e1204484946458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484946458 : Closed e1204484946458 ∧ code e1204484946458 = 5602531457562 := by decide
private def t_e1204484946458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484946458 : ¬ IsSelfInterpreter e1204484946458 :=
  wSource (t := t_e1204484946458) (replay_sound (ps := []) (t := e1204484946458) (by decide)) (by decide)
def e1204484958746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484958746 : Closed e1204484958746 ∧ code e1204484958746 = 5602531469850 := by decide
private def t_e1204484958746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484958746 : ¬ IsSelfInterpreter e1204484958746 :=
  wSource (t := t_e1204484958746) (replay_sound (ps := []) (t := e1204484958746) (by decide)) (by decide)
def e1204484992538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484992538 : Closed e1204484992538 ∧ code e1204484992538 = 5602531503642 := by decide
private def t_e1204484992538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484992538 : ¬ IsSelfInterpreter e1204484992538 :=
  wSource (t := t_e1204484992538) (replay_sound (ps := []) (t := e1204484992538) (by decide)) (by decide)
def e1204484995610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204484995610 : Closed e1204484995610 ∧ code e1204484995610 = 5602531506714 := by decide
private def t_e1204484995610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204484995610 : ¬ IsSelfInterpreter e1204484995610 :=
  wSource (t := t_e1204484995610) (replay_sound (ps := []) (t := e1204484995610) (by decide)) (by decide)
def e1204485021722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204485021722 : Closed e1204485021722 ∧ code e1204485021722 = 5602531532826 := by decide
theorem cert_e1204485021722 : check e1204485021722 [[]] .width = true := by decide
def e1204485021814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204485021814 : Closed e1204485021814 ∧ code e1204485021814 = 5602531532918 := by decide
private def t_e1204485021814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204485021814 : ¬ IsSelfInterpreter e1204485021814 :=
  wSource (t := t_e1204485021814) (replay_sound (ps := []) (t := e1204485021814) (by decide)) (by decide)
def e1204485022058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204485022058 : Closed e1204485022058 ∧ code e1204485022058 = 5602531533162 := by decide
private def t_e1204485022058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204485022058 : ¬ IsSelfInterpreter e1204485022058 :=
  wSource (t := t_e1204485022058) (replay_sound (ps := []) (t := e1204485022058) (by decide)) (by decide)
def e1204485022106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204485022106 : Closed e1204485022106 ∧ code e1204485022106 = 5602531533210 := by decide
private def t_e1204485022106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204485022106 : ¬ IsSelfInterpreter e1204485022106 :=
  wSource (t := t_e1204485022106) (replay_sound (ps := []) (t := e1204485022106) (by decide)) (by decide)
def e1204485069338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485069338 : Closed e1204485069338 ∧ code e1204485069338 = 5602531580442 := by decide
private def t_e1204485069338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485069338 : ¬ IsSelfInterpreter e1204485069338 :=
  wSource (t := t_e1204485069338) (replay_sound (ps := []) (t := e1204485069338) (by decide)) (by decide)
def e1204485070874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204485070874 : Closed e1204485070874 ∧ code e1204485070874 = 5602531581978 := by decide
theorem cert_e1204485070874 : check e1204485070874 [[]] .width = true := by decide
def e1204485070966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204485070966 : Closed e1204485070966 ∧ code e1204485070966 = 5602531582070 := by decide
private def t_e1204485070966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204485070966 : ¬ IsSelfInterpreter e1204485070966 :=
  wSource (t := t_e1204485070966) (replay_sound (ps := []) (t := e1204485070966) (by decide)) (by decide)
def e1204485071210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204485071210 : Closed e1204485071210 ∧ code e1204485071210 = 5602531582314 := by decide
private def t_e1204485071210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204485071210 : ¬ IsSelfInterpreter e1204485071210 :=
  wSource (t := t_e1204485071210) (replay_sound (ps := []) (t := e1204485071210) (by decide)) (by decide)
def e1204485071258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204485071258 : Closed e1204485071258 ∧ code e1204485071258 = 5602531582362 := by decide
private def t_e1204485071258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204485071258 : ¬ IsSelfInterpreter e1204485071258 :=
  wSource (t := t_e1204485071258) (replay_sound (ps := []) (t := e1204485071258) (by decide)) (by decide)
def e1204485680666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485680666 : Closed e1204485680666 ∧ code e1204485680666 = 5602532191770 := by decide
private def t_e1204485680666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485680666 : ¬ IsSelfInterpreter e1204485680666 :=
  wSource (t := t_e1204485680666) (replay_sound (ps := []) (t := e1204485680666) (by decide)) (by decide)
def e1204485682714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485682714 : Closed e1204485682714 ∧ code e1204485682714 = 5602532193818 := by decide
private def t_e1204485682714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485682714 : ¬ IsSelfInterpreter e1204485682714 :=
  wSource (t := t_e1204485682714) (replay_sound (ps := []) (t := e1204485682714) (by decide)) (by decide)
def e1204485805594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485805594 : Closed e1204485805594 ∧ code e1204485805594 = 5602532316698 := by decide
private def t_e1204485805594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485805594 : ¬ IsSelfInterpreter e1204485805594 :=
  wSource (t := t_e1204485805594) (replay_sound (ps := []) (t := e1204485805594) (by decide)) (by decide)
def e1204485806618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485806618 : Closed e1204485806618 ∧ code e1204485806618 = 5602532317722 := by decide
private def t_e1204485806618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485806618 : ¬ IsSelfInterpreter e1204485806618 :=
  wSource (t := t_e1204485806618) (replay_sound (ps := []) (t := e1204485806618) (by decide)) (by decide)
def e1204485810714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485810714 : Closed e1204485810714 ∧ code e1204485810714 = 5602532321818 := by decide
private def t_e1204485810714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485810714 : ¬ IsSelfInterpreter e1204485810714 :=
  wSource (t := t_e1204485810714) (replay_sound (ps := []) (t := e1204485810714) (by decide)) (by decide)
def e1204485830170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485830170 : Closed e1204485830170 ∧ code e1204485830170 = 5602532341274 := by decide
private def t_e1204485830170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485830170 : ¬ IsSelfInterpreter e1204485830170 :=
  wSource (t := t_e1204485830170) (replay_sound (ps := []) (t := e1204485830170) (by decide)) (by decide)
def e1204485831194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485831194 : Closed e1204485831194 ∧ code e1204485831194 = 5602532342298 := by decide
private def t_e1204485831194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485831194 : ¬ IsSelfInterpreter e1204485831194 :=
  wSource (t := t_e1204485831194) (replay_sound (ps := []) (t := e1204485831194) (by decide)) (by decide)
def e1204485840922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204485840922 : Closed e1204485840922 ∧ code e1204485840922 = 5602532352026 := by decide
theorem cert_e1204485840922 : check e1204485840922 [[]] .width = true := by decide
def e1204485841014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204485841014 : Closed e1204485841014 ∧ code e1204485841014 = 5602532352118 := by decide
private def t_e1204485841014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204485841014 : ¬ IsSelfInterpreter e1204485841014 :=
  wSource (t := t_e1204485841014) (replay_sound (ps := []) (t := e1204485841014) (by decide)) (by decide)
def e1204485841258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204485841258 : Closed e1204485841258 ∧ code e1204485841258 = 5602532352362 := by decide
private def t_e1204485841258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204485841258 : ¬ IsSelfInterpreter e1204485841258 :=
  wSource (t := t_e1204485841258) (replay_sound (ps := []) (t := e1204485841258) (by decide)) (by decide)
def e1204485841306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204485841306 : Closed e1204485841306 ∧ code e1204485841306 = 5602532352410 := by decide
private def t_e1204485841306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204485841306 : ¬ IsSelfInterpreter e1204485841306 :=
  wSource (t := t_e1204485841306) (replay_sound (ps := []) (t := e1204485841306) (by decide)) (by decide)
def e1204485855770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204485855770 : Closed e1204485855770 ∧ code e1204485855770 = 5602532366874 := by decide
private def t_e1204485855770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204485855770 : ¬ IsSelfInterpreter e1204485855770 :=
  wSource (t := t_e1204485855770) (replay_sound (ps := []) (t := e1204485855770) (by decide)) (by decide)
def e1204485857306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204485857306 : Closed e1204485857306 ∧ code e1204485857306 = 5602532368410 := by decide
theorem cert_e1204485857306 : check e1204485857306 [[]] .width = true := by decide
def e1204485857398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204485857398 : Closed e1204485857398 ∧ code e1204485857398 = 5602532368502 := by decide
private def t_e1204485857398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204485857398 : ¬ IsSelfInterpreter e1204485857398 :=
  wSource (t := t_e1204485857398) (replay_sound (ps := []) (t := e1204485857398) (by decide)) (by decide)
def e1204485857642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204485857642 : Closed e1204485857642 ∧ code e1204485857642 = 5602532368746 := by decide
private def t_e1204485857642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204485857642 : ¬ IsSelfInterpreter e1204485857642 :=
  wSource (t := t_e1204485857642) (replay_sound (ps := []) (t := e1204485857642) (by decide)) (by decide)
def e1204485857690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204485857690 : Closed e1204485857690 ∧ code e1204485857690 = 5602532368794 := by decide
private def t_e1204485857690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204485857690 : ¬ IsSelfInterpreter e1204485857690 :=
  wSource (t := t_e1204485857690) (replay_sound (ps := []) (t := e1204485857690) (by decide)) (by decide)
def e1204486712686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1204486712686 : Closed e1204486712686 ∧ code e1204486712686 = 5602533223790 := by decide
theorem cert_e1204486712686 : check e1204486712686 [[],[]] .chain = true := by decide
def e1204486712694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1204486712694 : Closed e1204486712694 ∧ code e1204486712694 = 5602533223798 := by decide
theorem cert_e1204486712694 : check e1204486712694 [[],[]] .chain = true := by decide
def e1204486712750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1204486712750 : Closed e1204486712750 ∧ code e1204486712750 = 5602533223854 := by decide
theorem cert_e1204486712750 : check e1204486712750 [[],[]] .chain = true := by decide
def e1204486712762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1204486712762 : Closed e1204486712762 ∧ code e1204486712762 = 5602533223866 := by decide
theorem cert_e1204486712762 : check e1204486712762 [[],[]] .chain = true := by decide
def e1204486712790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1204486712790 : Closed e1204486712790 ∧ code e1204486712790 = 5602533223894 := by decide
theorem cert_e1204486712790 : check e1204486712790 [[],[]] .chain = true := by decide
def e1204486712794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1204486712794 : Closed e1204486712794 ∧ code e1204486712794 = 5602533223898 := by decide
theorem cert_e1204486712794 : check e1204486712794 [[],[]] .chain = true := by decide
def e1204486713006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1204486713006 : Closed e1204486713006 ∧ code e1204486713006 = 5602533224110 := by decide
theorem cert_e1204486713006 : check e1204486713006 [[],[]] .chain = true := by decide
def e1204486713018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1204486713018 : Closed e1204486713018 ∧ code e1204486713018 = 5602533224122 := by decide
theorem cert_e1204486713018 : check e1204486713018 [[],[]] .chain = true := by decide
def e1204486713066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1204486713066 : Closed e1204486713066 ∧ code e1204486713066 = 5602533224170 := by decide
theorem cert_e1204486713066 : check e1204486713066 [[],[]] .chain = true := by decide
def e1204486713174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1204486713174 : Closed e1204486713174 ∧ code e1204486713174 = 5602533224278 := by decide
theorem cert_e1204486713174 : check e1204486713174 [[],[]] .chain = true := by decide
def e1204486713178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1204486713178 : Closed e1204486713178 ∧ code e1204486713178 = 5602533224282 := by decide
theorem cert_e1204486713178 : check e1204486713178 [[],[]] .chain = true := by decide
def e1204486713194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1204486713194 : Closed e1204486713194 ∧ code e1204486713194 = 5602533224298 := by decide
theorem cert_e1204486713194 : check e1204486713194 [[],[]] .chain = true := by decide
def e1204486714222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1204486714222 : Closed e1204486714222 ∧ code e1204486714222 = 5602533225326 := by decide
theorem cert_e1204486714222 : check e1204486714222 [[],[]] .chain = true := by decide
def e1204486714230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1204486714230 : Closed e1204486714230 ∧ code e1204486714230 = 5602533225334 := by decide
theorem cert_e1204486714230 : check e1204486714230 [[],[]] .chain = true := by decide
def e1204486714286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1204486714286 : Closed e1204486714286 ∧ code e1204486714286 = 5602533225390 := by decide
theorem cert_e1204486714286 : check e1204486714286 [[],[]] .chain = true := by decide
def e1204486714298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1204486714298 : Closed e1204486714298 ∧ code e1204486714298 = 5602533225402 := by decide
theorem cert_e1204486714298 : check e1204486714298 [[],[]] .chain = true := by decide
def e1204486714326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1204486714326 : Closed e1204486714326 ∧ code e1204486714326 = 5602533225430 := by decide
theorem cert_e1204486714326 : check e1204486714326 [[],[]] .chain = true := by decide
def e1204486714330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1204486714330 : Closed e1204486714330 ∧ code e1204486714330 = 5602533225434 := by decide
theorem cert_e1204486714330 : check e1204486714330 [[],[]] .chain = true := by decide
def e1204486714606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204486714606 : Closed e1204486714606 ∧ code e1204486714606 = 5602533225710 := by decide
theorem cert_e1204486714606 : check e1204486714606 [[],[]] .chain = true := by decide
def e1204486714614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204486714614 : Closed e1204486714614 ∧ code e1204486714614 = 5602533225718 := by decide
theorem cert_e1204486714614 : check e1204486714614 [[],[]] .chain = true := by decide
def e1204486714990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204486714990 : Closed e1204486714990 ∧ code e1204486714990 = 5602533226094 := by decide
theorem cert_e1204486714990 : check e1204486714990 [[],[]] .chain = true := by decide
def e1204486715002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204486715002 : Closed e1204486715002 ∧ code e1204486715002 = 5602533226106 := by decide
theorem cert_e1204486715002 : check e1204486715002 [[],[]] .chain = true := by decide
def e1204486715190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204486715190 : Closed e1204486715190 ∧ code e1204486715190 = 5602533226294 := by decide
theorem cert_e1204486715190 : check e1204486715190 [[],[]] .chain = true := by decide
def e1204486715194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204486715194 : Closed e1204486715194 ∧ code e1204486715194 = 5602533226298 := by decide
theorem cert_e1204486715194 : check e1204486715194 [[],[]] .chain = true := by decide
def e1204486715822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1204486715822 : Closed e1204486715822 ∧ code e1204486715822 = 5602533226926 := by decide
theorem cert_e1204486715822 : check e1204486715822 [[],[]] .chain = true := by decide
def e1204486715834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1204486715834 : Closed e1204486715834 ∧ code e1204486715834 = 5602533226938 := by decide
theorem cert_e1204486715834 : check e1204486715834 [[],[]] .chain = true := by decide
def e1204486715882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1204486715882 : Closed e1204486715882 ∧ code e1204486715882 = 5602533226986 := by decide
theorem cert_e1204486715882 : check e1204486715882 [[],[]] .chain = true := by decide
def e1204486716014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204486716014 : Closed e1204486716014 ∧ code e1204486716014 = 5602533227118 := by decide
theorem cert_e1204486716014 : check e1204486716014 [[],[]] .chain = true := by decide
def e1204486716026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204486716026 : Closed e1204486716026 ∧ code e1204486716026 = 5602533227130 := by decide
theorem cert_e1204486716026 : check e1204486716026 [[],[]] .chain = true := by decide
def e1204486716314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1204486716314 : Closed e1204486716314 ∧ code e1204486716314 = 5602533227418 := by decide
theorem cert_e1204486716314 : check e1204486716314 [[],[]] .chain = true := by decide
def e1204486716630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1204486716630 : Closed e1204486716630 ∧ code e1204486716630 = 5602533227734 := by decide
theorem cert_e1204486716630 : check e1204486716630 [[],[]] .chain = true := by decide
def e1204486716634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1204486716634 : Closed e1204486716634 ∧ code e1204486716634 = 5602533227738 := by decide
theorem cert_e1204486716634 : check e1204486716634 [[],[]] .chain = true := by decide
def e1204486716650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1204486716650 : Closed e1204486716650 ∧ code e1204486716650 = 5602533227754 := by decide
theorem cert_e1204486716650 : check e1204486716650 [[],[]] .chain = true := by decide
def e1204486716726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204486716726 : Closed e1204486716726 ∧ code e1204486716726 = 5602533227830 := by decide
theorem cert_e1204486716726 : check e1204486716726 [[],[]] .chain = true := by decide
def e1204486716730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204486716730 : Closed e1204486716730 ∧ code e1204486716730 = 5602533227834 := by decide
theorem cert_e1204486716730 : check e1204486716730 [[],[]] .chain = true := by decide
def e1204486716826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1204486716826 : Closed e1204486716826 ∧ code e1204486716826 = 5602533227930 := by decide
theorem cert_e1204486716826 : check e1204486716826 [[],[]] .chain = true := by decide
def e1204486720366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204486720366 : Closed e1204486720366 ∧ code e1204486720366 = 5602533231470 := by decide
theorem cert_e1204486720366 : check e1204486720366 [[],[]] .chain = true := by decide
def e1204486720374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204486720374 : Closed e1204486720374 ∧ code e1204486720374 = 5602533231478 := by decide
theorem cert_e1204486720374 : check e1204486720374 [[],[]] .chain = true := by decide
def e1204486720430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204486720430 : Closed e1204486720430 ∧ code e1204486720430 = 5602533231534 := by decide
theorem cert_e1204486720430 : check e1204486720430 [[],[]] .chain = true := by decide
def e1204486720442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204486720442 : Closed e1204486720442 ∧ code e1204486720442 = 5602533231546 := by decide
theorem cert_e1204486720442 : check e1204486720442 [[],[]] .chain = true := by decide
def e1204486720470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204486720470 : Closed e1204486720470 ∧ code e1204486720470 = 5602533231574 := by decide
theorem cert_e1204486720470 : check e1204486720470 [[],[]] .chain = true := by decide
def e1204486720474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204486720474 : Closed e1204486720474 ∧ code e1204486720474 = 5602533231578 := by decide
theorem cert_e1204486720474 : check e1204486720474 [[],[]] .chain = true := by decide
def e1204486720750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204486720750 : Closed e1204486720750 ∧ code e1204486720750 = 5602533231854 := by decide
theorem cert_e1204486720750 : check e1204486720750 [[],[]] .chain = true := by decide
def e1204486720758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204486720758 : Closed e1204486720758 ∧ code e1204486720758 = 5602533231862 := by decide
theorem cert_e1204486720758 : check e1204486720758 [[],[]] .chain = true := by decide
def e1204486721134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204486721134 : Closed e1204486721134 ∧ code e1204486721134 = 5602533232238 := by decide
theorem cert_e1204486721134 : check e1204486721134 [[],[]] .chain = true := by decide
def e1204486721146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204486721146 : Closed e1204486721146 ∧ code e1204486721146 = 5602533232250 := by decide
theorem cert_e1204486721146 : check e1204486721146 [[],[]] .chain = true := by decide
def e1204486721334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204486721334 : Closed e1204486721334 ∧ code e1204486721334 = 5602533232438 := by decide
theorem cert_e1204486721334 : check e1204486721334 [[],[]] .chain = true := by decide
def e1204486721338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204486721338 : Closed e1204486721338 ∧ code e1204486721338 = 5602533232442 := by decide
theorem cert_e1204486721338 : check e1204486721338 [[],[]] .chain = true := by decide
def e1204486727086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1204486727086 : Closed e1204486727086 ∧ code e1204486727086 = 5602533238190 := by decide
theorem cert_e1204486727086 : check e1204486727086 [[],[]] .chain = true := by decide
def e1204486727098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1204486727098 : Closed e1204486727098 ∧ code e1204486727098 = 5602533238202 := by decide
theorem cert_e1204486727098 : check e1204486727098 [[],[]] .chain = true := by decide
def e1204486727146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1204486727146 : Closed e1204486727146 ∧ code e1204486727146 = 5602533238250 := by decide
theorem cert_e1204486727146 : check e1204486727146 [[],[]] .chain = true := by decide
def e1204486727278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1204486727278 : Closed e1204486727278 ∧ code e1204486727278 = 5602533238382 := by decide
theorem cert_e1204486727278 : check e1204486727278 [[],[]] .chain = true := by decide
def e1204486727290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1204486727290 : Closed e1204486727290 ∧ code e1204486727290 = 5602533238394 := by decide
theorem cert_e1204486727290 : check e1204486727290 [[],[]] .chain = true := by decide
def e1204486727578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1204486727578 : Closed e1204486727578 ∧ code e1204486727578 = 5602533238682 := by decide
theorem cert_e1204486727578 : check e1204486727578 [[],[]] .chain = true := by decide
def e1204486730454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1204486730454 : Closed e1204486730454 ∧ code e1204486730454 = 5602533241558 := by decide
theorem cert_e1204486730454 : check e1204486730454 [[],[]] .chain = true := by decide
def e1204486730458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1204486730458 : Closed e1204486730458 ∧ code e1204486730458 = 5602533241562 := by decide
theorem cert_e1204486730458 : check e1204486730458 [[],[]] .chain = true := by decide
def e1204486730474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1204486730474 : Closed e1204486730474 ∧ code e1204486730474 = 5602533241578 := by decide
theorem cert_e1204486730474 : check e1204486730474 [[],[]] .chain = true := by decide
def e1204486730550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1204486730550 : Closed e1204486730550 ∧ code e1204486730550 = 5602533241654 := by decide
theorem cert_e1204486730550 : check e1204486730550 [[],[]] .chain = true := by decide
def e1204486730554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1204486730554 : Closed e1204486730554 ∧ code e1204486730554 = 5602533241658 := by decide
theorem cert_e1204486730554 : check e1204486730554 [[],[]] .chain = true := by decide
def e1204486730650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1204486730650 : Closed e1204486730650 ∧ code e1204486730650 = 5602533241754 := by decide
theorem cert_e1204486730650 : check e1204486730650 [[],[]] .chain = true := by decide
def e1204486867822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204486867822 : Closed e1204486867822 ∧ code e1204486867822 = 5602533378926 := by decide
theorem cert_e1204486867822 : check e1204486867822 [[],[]] .chain = true := by decide
def e1204486867830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204486867830 : Closed e1204486867830 ∧ code e1204486867830 = 5602533378934 := by decide
theorem cert_e1204486867830 : check e1204486867830 [[],[]] .chain = true := by decide
def e1204486867886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204486867886 : Closed e1204486867886 ∧ code e1204486867886 = 5602533378990 := by decide
theorem cert_e1204486867886 : check e1204486867886 [[],[]] .chain = true := by decide
def e1204486867898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204486867898 : Closed e1204486867898 ∧ code e1204486867898 = 5602533379002 := by decide
theorem cert_e1204486867898 : check e1204486867898 [[],[]] .chain = true := by decide
def e1204486867926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204486867926 : Closed e1204486867926 ∧ code e1204486867926 = 5602533379030 := by decide
theorem cert_e1204486867926 : check e1204486867926 [[],[]] .chain = true := by decide
def e1204486867930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204486867930 : Closed e1204486867930 ∧ code e1204486867930 = 5602533379034 := by decide
theorem cert_e1204486867930 : check e1204486867930 [[],[]] .chain = true := by decide
def e1204486868206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204486868206 : Closed e1204486868206 ∧ code e1204486868206 = 5602533379310 := by decide
theorem cert_e1204486868206 : check e1204486868206 [[],[]] .chain = true := by decide
def e1204486868214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204486868214 : Closed e1204486868214 ∧ code e1204486868214 = 5602533379318 := by decide
theorem cert_e1204486868214 : check e1204486868214 [[],[]] .chain = true := by decide
def e1204486868590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204486868590 : Closed e1204486868590 ∧ code e1204486868590 = 5602533379694 := by decide
theorem cert_e1204486868590 : check e1204486868590 [[],[]] .chain = true := by decide
def e1204486868602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204486868602 : Closed e1204486868602 ∧ code e1204486868602 = 5602533379706 := by decide
theorem cert_e1204486868602 : check e1204486868602 [[],[]] .chain = true := by decide
def e1204486868790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204486868790 : Closed e1204486868790 ∧ code e1204486868790 = 5602533379894 := by decide
theorem cert_e1204486868790 : check e1204486868790 [[],[]] .chain = true := by decide
def e1204486868794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204486868794 : Closed e1204486868794 ∧ code e1204486868794 = 5602533379898 := by decide
theorem cert_e1204486868794 : check e1204486868794 [[],[]] .chain = true := by decide
def e1204487457646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204487457646 : Closed e1204487457646 ∧ code e1204487457646 = 5602533968750 := by decide
theorem cert_e1204487457646 : check e1204487457646 [[],[],[]] .smaller = true := by decide
def e1204487457654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204487457654 : Closed e1204487457654 ∧ code e1204487457654 = 5602533968758 := by decide
theorem cert_e1204487457654 : check e1204487457654 [[],[],[]] .smaller = true := by decide
def e1204487457710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204487457710 : Closed e1204487457710 ∧ code e1204487457710 = 5602533968814 := by decide
theorem cert_e1204487457710 : check e1204487457710 [[],[],[]] .smaller = true := by decide
def e1204487457722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204487457722 : Closed e1204487457722 ∧ code e1204487457722 = 5602533968826 := by decide
theorem cert_e1204487457722 : check e1204487457722 [[],[],[]] .smaller = true := by decide
end Blc.Floor42
