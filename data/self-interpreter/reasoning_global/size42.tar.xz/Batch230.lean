import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211212704598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211212704598 : Closed e1211212704598 ∧ code e1211212704598 = 5609259215702 := by decide
theorem cert_e1211212704598 : check e1211212704598 [[],[]] .chain = true := by decide
def e1211212704602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211212704602 : Closed e1211212704602 ∧ code e1211212704602 = 5609259215706 := by decide
theorem cert_e1211212704602 : check e1211212704602 [[],[]] .chain = true := by decide
def e1211212704618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211212704618 : Closed e1211212704618 ∧ code e1211212704618 = 5609259215722 := by decide
theorem cert_e1211212704618 : check e1211212704618 [[],[]] .chain = true := by decide
def e1211212704682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211212704682 : Closed e1211212704682 ∧ code e1211212704682 = 5609259215786 := by decide
theorem cert_e1211212704682 : check e1211212704682 [[],[]] .chain = true := by decide
def e1211212704790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211212704790 : Closed e1211212704790 ∧ code e1211212704790 = 5609259215894 := by decide
theorem cert_e1211212704790 : check e1211212704790 [[],[]] .chain = true := by decide
def e1211212704794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211212704794 : Closed e1211212704794 ∧ code e1211212704794 = 5609259215898 := by decide
theorem cert_e1211212704794 : check e1211212704794 [[],[]] .chain = true := by decide
def e1211212704838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211212704838 : Closed e1211212704838 ∧ code e1211212704838 = 5609259215942 := by decide
theorem cert_e1211212704838 : check e1211212704838 [[],[]] .chain = true := by decide
def e1211212704866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211212704866 : Closed e1211212704866 ∧ code e1211212704866 = 5609259215970 := by decide
theorem cert_e1211212704866 : check e1211212704866 [[],[]] .chain = true := by decide
def e1211212704878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211212704878 : Closed e1211212704878 ∧ code e1211212704878 = 5609259215982 := by decide
theorem cert_e1211212704878 : check e1211212704878 [[],[],[.under,.under]] .three = true := by decide
def e1211212704886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211212704886 : Closed e1211212704886 ∧ code e1211212704886 = 5609259215990 := by decide
theorem cert_e1211212704886 : check e1211212704886 [[],[]] .chain = true := by decide
def e1211212704890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211212704890 : Closed e1211212704890 ∧ code e1211212704890 = 5609259215994 := by decide
theorem cert_e1211212704890 : check e1211212704890 [[],[],[.under,.under]] .three = true := by decide
def e1211212704982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211212704982 : Closed e1211212704982 ∧ code e1211212704982 = 5609259216086 := by decide
theorem cert_e1211212704982 : check e1211212704982 [[],[]] .chain = true := by decide
def e1211212704986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211212704986 : Closed e1211212704986 ∧ code e1211212704986 = 5609259216090 := by decide
theorem cert_e1211212704986 : check e1211212704986 [[],[]] .chain = true := by decide
def e1211212705002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211212705002 : Closed e1211212705002 ∧ code e1211212705002 = 5609259216106 := by decide
theorem cert_e1211212705002 : check e1211212705002 [[],[]] .chain = true := by decide
def e1211212705030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212705030 : Closed e1211212705030 ∧ code e1211212705030 = 5609259216134 := by decide
theorem cert_e1211212705030 : check e1211212705030 [[],[]] .chain = true := by decide
def e1211212705054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211212705054 : Closed e1211212705054 ∧ code e1211212705054 = 5609259216158 := by decide
theorem cert_e1211212705054 : check e1211212705054 [[],[],[.under,.under]] .three = true := by decide
def e1211212705078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212705078 : Closed e1211212705078 ∧ code e1211212705078 = 5609259216182 := by decide
theorem cert_e1211212705078 : check e1211212705078 [[],[]] .chain = true := by decide
def e1211212705082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212705082 : Closed e1211212705082 ∧ code e1211212705082 = 5609259216186 := by decide
theorem cert_e1211212705082 : check e1211212705082 [[],[]] .chain = true := by decide
def e1211212705154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212705154 : Closed e1211212705154 ∧ code e1211212705154 = 5609259216258 := by decide
theorem cert_e1211212705154 : check e1211212705154 [[],[]] .chain = true := by decide
def e1211212705166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211212705166 : Closed e1211212705166 ∧ code e1211212705166 = 5609259216270 := by decide
theorem cert_e1211212705166 : check e1211212705166 [[],[]] .chain = true := by decide
def e1211212705178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212705178 : Closed e1211212705178 ∧ code e1211212705178 = 5609259216282 := by decide
theorem cert_e1211212705178 : check e1211212705178 [[],[]] .chain = true := by decide
def e1211212705222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211212705222 : Closed e1211212705222 ∧ code e1211212705222 = 5609259216326 := by decide
theorem cert_e1211212705222 : check e1211212705222 [[],[],[.under,.under]] .three = true := by decide
def e1211212705290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211212705290 : Closed e1211212705290 ∧ code e1211212705290 = 5609259216394 := by decide
theorem cert_e1211212705290 : check e1211212705290 [[],[]] .chain = true := by decide
def e1211212705334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211212705334 : Closed e1211212705334 ∧ code e1211212705334 = 5609259216438 := by decide
theorem cert_e1211212705334 : check e1211212705334 [[],[]] .chain = true := by decide
def e1211212705338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211212705338 : Closed e1211212705338 ∧ code e1211212705338 = 5609259216442 := by decide
theorem cert_e1211212705338 : check e1211212705338 [[],[]] .chain = true := by decide
def e1211212705386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211212705386 : Closed e1211212705386 ∧ code e1211212705386 = 5609259216490 := by decide
theorem cert_e1211212705386 : check e1211212705386 [[],[]] .chain = true := by decide
def e1211212705410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212705410 : Closed e1211212705410 ∧ code e1211212705410 = 5609259216514 := by decide
theorem cert_e1211212705410 : check e1211212705410 [[],[]] .chain = true := by decide
def e1211212705422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211212705422 : Closed e1211212705422 ∧ code e1211212705422 = 5609259216526 := by decide
theorem cert_e1211212705422 : check e1211212705422 [[],[]] .chain = true := by decide
def e1211212705434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212705434 : Closed e1211212705434 ∧ code e1211212705434 = 5609259216538 := by decide
theorem cert_e1211212705434 : check e1211212705434 [[],[]] .chain = true := by decide
def e1211212705478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211212705478 : Closed e1211212705478 ∧ code e1211212705478 = 5609259216582 := by decide
theorem cert_e1211212705478 : check e1211212705478 [[],[]] .chain = true := by decide
def e1211212705562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211212705562 : Closed e1211212705562 ∧ code e1211212705562 = 5609259216666 := by decide
theorem cert_e1211212705562 : check e1211212705562 [[],[],[.under,.under]] .three = true := by decide
def e1211212705606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211212705606 : Closed e1211212705606 ∧ code e1211212705606 = 5609259216710 := by decide
theorem cert_e1211212705606 : check e1211212705606 [[],[],[.under,.under]] .three = true := by decide
def e1211212705822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211212705822 : Closed e1211212705822 ∧ code e1211212705822 = 5609259216926 := by decide
theorem cert_e1211212705822 : check e1211212705822 [[],[]] .chain = true := by decide
def e1211212705990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211212705990 : Closed e1211212705990 ∧ code e1211212705990 = 5609259217094 := by decide
theorem cert_e1211212705990 : check e1211212705990 [[],[],[.under,.under]] .three = true := by decide
def e1211212706014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211212706014 : Closed e1211212706014 ∧ code e1211212706014 = 5609259217118 := by decide
theorem cert_e1211212706014 : check e1211212706014 [[],[],[.under,.under]] .three = true := by decide
def e1211212706018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211212706018 : Closed e1211212706018 ∧ code e1211212706018 = 5609259217122 := by decide
theorem cert_e1211212706018 : check e1211212706018 [[],[]] .chain = true := by decide
def e1211212706030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212706030 : Closed e1211212706030 ∧ code e1211212706030 = 5609259217134 := by decide
theorem cert_e1211212706030 : check e1211212706030 [[],[]] .chain = true := by decide
def e1211212706038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212706038 : Closed e1211212706038 ∧ code e1211212706038 = 5609259217142 := by decide
theorem cert_e1211212706038 : check e1211212706038 [[],[]] .chain = true := by decide
def e1211212706042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211212706042 : Closed e1211212706042 ∧ code e1211212706042 = 5609259217146 := by decide
theorem cert_e1211212706042 : check e1211212706042 [[],[],[.under,.under]] .three = true := by decide
def e1211212706518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211212706518 : Closed e1211212706518 ∧ code e1211212706518 = 5609259217622 := by decide
theorem cert_e1211212706518 : check e1211212706518 [[],[]] .chain = true := by decide
def e1211212706522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211212706522 : Closed e1211212706522 ∧ code e1211212706522 = 5609259217626 := by decide
theorem cert_e1211212706522 : check e1211212706522 [[],[]] .chain = true := by decide
def e1211212706538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211212706538 : Closed e1211212706538 ∧ code e1211212706538 = 5609259217642 := by decide
theorem cert_e1211212706538 : check e1211212706538 [[],[]] .chain = true := by decide
def e1211212706566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211212706566 : Closed e1211212706566 ∧ code e1211212706566 = 5609259217670 := by decide
theorem cert_e1211212706566 : check e1211212706566 [[],[]] .chain = true := by decide
def e1211212706590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211212706590 : Closed e1211212706590 ∧ code e1211212706590 = 5609259217694 := by decide
theorem cert_e1211212706590 : check e1211212706590 [[],[],[.under,.under]] .three = true := by decide
def e1211212706614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212706614 : Closed e1211212706614 ∧ code e1211212706614 = 5609259217718 := by decide
theorem cert_e1211212706614 : check e1211212706614 [[],[]] .chain = true := by decide
def e1211212706618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212706618 : Closed e1211212706618 ∧ code e1211212706618 = 5609259217722 := by decide
theorem cert_e1211212706618 : check e1211212706618 [[],[]] .chain = true := by decide
def e1211212706690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211212706690 : Closed e1211212706690 ∧ code e1211212706690 = 5609259217794 := by decide
theorem cert_e1211212706690 : check e1211212706690 [[],[]] .chain = true := by decide
def e1211212706702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211212706702 : Closed e1211212706702 ∧ code e1211212706702 = 5609259217806 := by decide
theorem cert_e1211212706702 : check e1211212706702 [[],[]] .chain = true := by decide
def e1211212706714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211212706714 : Closed e1211212706714 ∧ code e1211212706714 = 5609259217818 := by decide
theorem cert_e1211212706714 : check e1211212706714 [[],[]] .chain = true := by decide
def e1211212706758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211212706758 : Closed e1211212706758 ∧ code e1211212706758 = 5609259217862 := by decide
theorem cert_e1211212706758 : check e1211212706758 [[],[],[.under,.under]] .three = true := by decide
def e1211212707958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212707958 : Closed e1211212707958 ∧ code e1211212707958 = 5609259219062 := by decide
theorem cert_e1211212707958 : check e1211212707958 [[],[]] .chain = true := by decide
def e1211212708202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211212708202 : Closed e1211212708202 ∧ code e1211212708202 = 5609259219306 := by decide
theorem cert_e1211212708202 : check e1211212708202 [[],[]] .chain = true := by decide
def e1211212708226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211212708226 : Closed e1211212708226 ∧ code e1211212708226 = 5609259219330 := by decide
theorem cert_e1211212708226 : check e1211212708226 [[],[]] .chain = true := by decide
def e1211212708238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211212708238 : Closed e1211212708238 ∧ code e1211212708238 = 5609259219342 := by decide
theorem cert_e1211212708238 : check e1211212708238 [[],[]] .chain = true := by decide
def e1211212708250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211212708250 : Closed e1211212708250 ∧ code e1211212708250 = 5609259219354 := by decide
theorem cert_e1211212708250 : check e1211212708250 [[],[]] .chain = true := by decide
def e1211212708294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211212708294 : Closed e1211212708294 ∧ code e1211212708294 = 5609259219398 := by decide
theorem cert_e1211212708294 : check e1211212708294 [[],[]] .chain = true := by decide
def e1211212708918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212708918 : Closed e1211212708918 ∧ code e1211212708918 = 5609259220022 := by decide
theorem cert_e1211212708918 : check e1211212708918 [[],[],[.under,.under]] .three = true := by decide
def e1211212708922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212708922 : Closed e1211212708922 ∧ code e1211212708922 = 5609259220026 := by decide
theorem cert_e1211212708922 : check e1211212708922 [[],[],[.under,.under]] .three = true := by decide
def e1211212709062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211212709062 : Closed e1211212709062 ∧ code e1211212709062 = 5609259220166 := by decide
theorem cert_e1211212709062 : check e1211212709062 [[],[],[.under,.under]] .three = true := by decide
def e1211212728094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211212728094 : Closed e1211212728094 ∧ code e1211212728094 = 5609259239198 := by decide
theorem cert_e1211212728094 : check e1211212728094 [[],[],[.under,.under]] .three = true := by decide
def e1211212728206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211212728206 : Closed e1211212728206 ∧ code e1211212728206 = 5609259239310 := by decide
theorem cert_e1211212728206 : check e1211212728206 [[],[],[.under,.under]] .three = true := by decide
def e1211212731958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211212731958 : Closed e1211212731958 ∧ code e1211212731958 = 5609259243062 := by decide
theorem cert_e1211212731958 : check e1211212731958 [[],[],[.under,.under]] .three = true := by decide
def e1211212731962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211212731962 : Closed e1211212731962 ∧ code e1211212731962 = 5609259243066 := by decide
theorem cert_e1211212731962 : check e1211212731962 [[],[],[.under,.under]] .three = true := by decide
def e1211212732046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211212732046 : Closed e1211212732046 ∧ code e1211212732046 = 5609259243150 := by decide
theorem cert_e1211212732046 : check e1211212732046 [[],[],[.under,.under]] .three = true := by decide
def e1211212732102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211212732102 : Closed e1211212732102 ∧ code e1211212732102 = 5609259243206 := by decide
theorem cert_e1211212732102 : check e1211212732102 [[],[],[.under,.under]] .three = true := by decide
def e1211212732186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211212732186 : Closed e1211212732186 ∧ code e1211212732186 = 5609259243290 := by decide
theorem cert_e1211212732186 : check e1211212732186 [[],[],[.under,.under]] .three = true := by decide
def e1211212732230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211212732230 : Closed e1211212732230 ∧ code e1211212732230 = 5609259243334 := by decide
theorem cert_e1211212732230 : check e1211212732230 [[],[],[.under,.under]] .three = true := by decide
def e1211212732526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212732526 : Closed e1211212732526 ∧ code e1211212732526 = 5609259243630 := by decide
theorem cert_e1211212732526 : check e1211212732526 [[],[],[.under,.under]] .three = true := by decide
def e1211212732538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212732538 : Closed e1211212732538 ∧ code e1211212732538 = 5609259243642 := by decide
theorem cert_e1211212732538 : check e1211212732538 [[],[],[.under,.under]] .three = true := by decide
def e1211212732814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211212732814 : Closed e1211212732814 ∧ code e1211212732814 = 5609259243918 := by decide
theorem cert_e1211212732814 : check e1211212732814 [[],[],[.under,.under]] .three = true := by decide
def e1211212732870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211212732870 : Closed e1211212732870 ∧ code e1211212732870 = 5609259243974 := by decide
theorem cert_e1211212732870 : check e1211212732870 [[],[],[.under,.under]] .three = true := by decide
def e1211212733494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212733494 : Closed e1211212733494 ∧ code e1211212733494 = 5609259244598 := by decide
theorem cert_e1211212733494 : check e1211212733494 [[],[],[.under,.under]] .three = true := by decide
def e1211212733498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212733498 : Closed e1211212733498 ∧ code e1211212733498 = 5609259244602 := by decide
theorem cert_e1211212733498 : check e1211212733498 [[],[],[.under,.under]] .three = true := by decide
def e1211212733638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211212733638 : Closed e1211212733638 ∧ code e1211212733638 = 5609259244742 := by decide
theorem cert_e1211212733638 : check e1211212733638 [[],[],[.under,.under]] .three = true := by decide
def e1211254377326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211254377326 : Closed e1211254377326 ∧ code e1211254377326 = 5609300888430 := by decide
theorem cert_e1211254377326 : check e1211254377326 [[],[],[.under],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254377334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211254377334 : Closed e1211254377334 ∧ code e1211254377334 = 5609300888438 := by decide
theorem cert_e1211254377334 : check e1211254377334 [[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254377390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211254377390 : Closed e1211254377390 ∧ code e1211254377390 = 5609300888494 := by decide
theorem cert_e1211254377390 : check e1211254377390 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254377402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211254377402 : Closed e1211254377402 ∧ code e1211254377402 = 5609300888506 := by decide
theorem cert_e1211254377402 : check e1211254377402 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254377430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211254377430 : Closed e1211254377430 ∧ code e1211254377430 = 5609300888534 := by decide
theorem cert_e1211254377430 : check e1211254377430 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254377434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211254377434 : Closed e1211254377434 ∧ code e1211254377434 = 5609300888538 := by decide
theorem cert_e1211254377434 : check e1211254377434 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1211254377710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211254377710 : Closed e1211254377710 ∧ code e1211254377710 = 5609300888814 := by decide
theorem cert_e1211254377710 : check e1211254377710 [[],[],[.under],[.under],[.under]] .chain = true := by decide
def e1211254377718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211254377718 : Closed e1211254377718 ∧ code e1211254377718 = 5609300888822 := by decide
theorem cert_e1211254377718 : check e1211254377718 [[],[],[.under],[.under],[.under]] .chain = true := by decide
def e1211254378094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211254378094 : Closed e1211254378094 ∧ code e1211254378094 = 5609300889198 := by decide
theorem cert_e1211254378094 : check e1211254378094 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254378106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211254378106 : Closed e1211254378106 ∧ code e1211254378106 = 5609300889210 := by decide
theorem cert_e1211254378106 : check e1211254378106 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254378294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211254378294 : Closed e1211254378294 ∧ code e1211254378294 = 5609300889398 := by decide
theorem cert_e1211254378294 : check e1211254378294 [[],[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211254378298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211254378298 : Closed e1211254378298 ∧ code e1211254378298 = 5609300889402 := by decide
theorem cert_e1211254378298 : checkPay e1211254378298 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[]] 0 [[.under,.under],[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e1211254707934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211254707934 : Closed e1211254707934 ∧ code e1211254707934 = 5609301219038 := by decide
theorem cert_e1211254707934 : check e1211254707934 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under],[.under,.under]] .identityHead = true := by decide
def e1211254707958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211254707958 : Closed e1211254707958 ∧ code e1211254707958 = 5609301219062 := by decide
theorem cert_e1211254707958 : check e1211254707958 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211254708062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211254708062 : Closed e1211254708062 ∧ code e1211254708062 = 5609301219166 := by decide
theorem cert_e1211254708062 : check e1211254708062 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[],[.under,.left],[.under]] .identityHead = true := by decide
def e1211254708090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211254708090 : Closed e1211254708090 ∧ code e1211254708090 = 5609301219194 := by decide
private def t_e1211254708090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e1211254708090 : ¬ IsSelfInterpreter e1211254708090 :=
  wSource (t := t_e1211254708090) (replay_sound (ps := []) (t := e1211254708090) (by decide)) (by decide)
def e1211254708182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211254708182 : Closed e1211254708182 ∧ code e1211254708182 = 5609301219286 := by decide
theorem cert_e1211254708182 : check e1211254708182 [[],[],[.under],[.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211254708186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211254708186 : Closed e1211254708186 ∧ code e1211254708186 = 5609301219290 := by decide
private def t_e1211254708186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e1211254708186 : ¬ IsSelfInterpreter e1211254708186 :=
  wSource (t := t_e1211254708186) (replay_sound (ps := []) (t := e1211254708186) (by decide)) (by decide)
def e1211254708702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211254708702 : Closed e1211254708702 ∧ code e1211254708702 = 5609301219806 := by decide
theorem cert_e1211254708702 : check e1211254708702 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under],[.under]] .identityHead = true := by decide
def e1211254708726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211254708726 : Closed e1211254708726 ∧ code e1211254708726 = 5609301219830 := by decide
theorem cert_e1211254708726 : check e1211254708726 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under],[.under]] .identityHead = true := by decide
def e1211254709470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211254709470 : Closed e1211254709470 ∧ code e1211254709470 = 5609301220574 := by decide
theorem cert_e1211254709470 : check e1211254709470 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211254709498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211254709498 : Closed e1211254709498 ∧ code e1211254709498 = 5609301220602 := by decide
theorem cert_e1211254709498 : check e1211254709498 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211254710070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211254710070 : Closed e1211254710070 ∧ code e1211254710070 = 5609301221174 := by decide
theorem cert_e1211254710070 : check e1211254710070 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211254710074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211254710074 : Closed e1211254710074 ∧ code e1211254710074 = 5609301221178 := by decide
theorem cert_e1211254710074 : check e1211254710074 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211254724846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211254724846 : Closed e1211254724846 ∧ code e1211254724846 = 5609301235950 := by decide
theorem cert_e1211254724846 : check e1211254724846 [[],[],[.under],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211254724854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211254724854 : Closed e1211254724854 ∧ code e1211254724854 = 5609301235958 := by decide
theorem cert_e1211254724854 : check e1211254724854 [[],[],[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211254725406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211254725406 : Closed e1211254725406 ∧ code e1211254725406 = 5609301236510 := by decide
theorem cert_e1211254725406 : check e1211254725406 [[],[],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211254725518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211254725518 : Closed e1211254725518 ∧ code e1211254725518 = 5609301236622 := by decide
private def t_e1211254725518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e1211254725518 : ¬ IsSelfInterpreter e1211254725518 :=
  wSource (t := t_e1211254725518) (replay_sound (ps := []) (t := e1211254725518) (by decide)) (by decide)
def e1211254725742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211254725742 : Closed e1211254725742 ∧ code e1211254725742 = 5609301236846 := by decide
theorem cert_e1211254725742 : check e1211254725742 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254725754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211254725754 : Closed e1211254725754 ∧ code e1211254725754 = 5609301236858 := by decide
theorem cert_e1211254725754 : check e1211254725754 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254725918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211254725918 : Closed e1211254725918 ∧ code e1211254725918 = 5609301237022 := by decide
theorem cert_e1211254725918 : check e1211254725918 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254726086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211254726086 : Closed e1211254726086 ∧ code e1211254726086 = 5609301237190 := by decide
theorem cert_e1211254726086 : check e1211254726086 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254726198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211254726198 : Closed e1211254726198 ∧ code e1211254726198 = 5609301237302 := by decide
theorem cert_e1211254726198 : check e1211254726198 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254726202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211254726202 : Closed e1211254726202 ∧ code e1211254726202 = 5609301237306 := by decide
theorem cert_e1211254726202 : check e1211254726202 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254726286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211254726286 : Closed e1211254726286 ∧ code e1211254726286 = 5609301237390 := by decide
private def t_e1211254726286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e1211254726286 : ¬ IsSelfInterpreter e1211254726286 :=
  wSource (t := t_e1211254726286) (replay_sound (ps := []) (t := e1211254726286) (by decide)) (by decide)
def e1211254726342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211254726342 : Closed e1211254726342 ∧ code e1211254726342 = 5609301237446 := by decide
theorem cert_e1211254726342 : check e1211254726342 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1211254728478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211254728478 : Closed e1211254728478 ∧ code e1211254728478 = 5609301239582 := by decide
theorem cert_e1211254728478 : check e1211254728478 [[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1211254728590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211254728590 : Closed e1211254728590 ∧ code e1211254728590 = 5609301239694 := by decide
theorem cert_e1211254728590 : check e1211254728590 [[],[],[.under],[.under],[.under],[.under,.left],[.under],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1211254731550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211254731550 : Closed e1211254731550 ∧ code e1211254731550 = 5609301242654 := by decide
theorem cert_e1211254731550 : check e1211254731550 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254731718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211254731718 : Closed e1211254731718 ∧ code e1211254731718 = 5609301242822 := by decide
theorem cert_e1211254731718 : check e1211254731718 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211254733198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211254733198 : Closed e1211254733198 ∧ code e1211254733198 = 5609301244302 := by decide
theorem cert_e1211254733198 : check e1211254733198 [[],[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211254733254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211254733254 : Closed e1211254733254 ∧ code e1211254733254 = 5609301244358 := by decide
theorem cert_e1211254733254 : checkPay e1211254733254 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[]] 0 [[.under,.under],[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e1211271048662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)) (.var 1)))))
theorem wire_e1211271048662 : Closed e1211271048662 ∧ code e1211271048662 = 5609317559766 := by decide
theorem cert_e1211271048662 : check e1211271048662 [[],[]] .sourceHead = true := by decide
def e1211271048666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)) (.var 0)))))
theorem wire_e1211271048666 : Closed e1211271048666 ∧ code e1211271048666 = 5609317559770 := by decide
theorem cert_e1211271048666 : check e1211271048666 [[],[]] .sourceHead = true := by decide
def e1211271048918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 1)))))
theorem wire_e1211271048918 : Closed e1211271048918 ∧ code e1211271048918 = 5609317560022 := by decide
theorem cert_e1211271048918 : check e1211271048918 [[],[]] .sourceHead = true := by decide
def e1211271048922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)) (.var 0)))))
theorem wire_e1211271048922 : Closed e1211271048922 ∧ code e1211271048922 = 5609317560026 := by decide
theorem cert_e1211271048922 : check e1211271048922 [[],[]] .sourceHead = true := by decide
def e1211271050710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)) (.var 1)))))
theorem wire_e1211271050710 : Closed e1211271050710 ∧ code e1211271050710 = 5609317561814 := by decide
theorem cert_e1211271050710 : check e1211271050710 [[],[]] .sourceHead = true := by decide
def e1211271050714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)) (.var 0)))))
theorem wire_e1211271050714 : Closed e1211271050714 ∧ code e1211271050714 = 5609317561818 := by decide
theorem cert_e1211271050714 : check e1211271050714 [[],[]] .sourceHead = true := by decide
def e1211271051094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)) (.var 1)))))
theorem wire_e1211271051094 : Closed e1211271051094 ∧ code e1211271051094 = 5609317562198 := by decide
theorem cert_e1211271051094 : check e1211271051094 [[],[]] .sourceHead = true := by decide
def e1211271051098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)) (.var 0)))))
theorem wire_e1211271051098 : Closed e1211271051098 ∧ code e1211271051098 = 5609317562202 := by decide
theorem cert_e1211271051098 : check e1211271051098 [[],[]] .sourceHead = true := by decide
def e1211271051990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 1)))))
theorem wire_e1211271051990 : Closed e1211271051990 ∧ code e1211271051990 = 5609317563094 := by decide
theorem cert_e1211271051990 : check e1211271051990 [[],[]] .sourceHead = true := by decide
def e1211271051994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)) (.var 0)))))
theorem wire_e1211271051994 : Closed e1211271051994 ∧ code e1211271051994 = 5609317563098 := by decide
theorem cert_e1211271051994 : check e1211271051994 [[],[]] .sourceHead = true := by decide
def e1211271052118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)) (.var 1)))))
theorem wire_e1211271052118 : Closed e1211271052118 ∧ code e1211271052118 = 5609317563222 := by decide
theorem cert_e1211271052118 : check e1211271052118 [[],[]] .sourceHead = true := by decide
def e1211271052122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)) (.var 0)))))
theorem wire_e1211271052122 : Closed e1211271052122 ∧ code e1211271052122 = 5609317563226 := by decide
theorem cert_e1211271052122 : check e1211271052122 [[],[]] .sourceHead = true := by decide
def e1211271060950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)) (.var 1)))))
theorem wire_e1211271060950 : Closed e1211271060950 ∧ code e1211271060950 = 5609317572054 := by decide
theorem cert_e1211271060950 : check e1211271060950 [[],[]] .sourceHead = true := by decide
def e1211271060954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)) (.var 0)))))
theorem wire_e1211271060954 : Closed e1211271060954 ∧ code e1211271060954 = 5609317572058 := by decide
theorem cert_e1211271060954 : check e1211271060954 [[],[]] .sourceHead = true := by decide
def e1211271061206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)) (.var 1)))))
theorem wire_e1211271061206 : Closed e1211271061206 ∧ code e1211271061206 = 5609317572310 := by decide
theorem cert_e1211271061206 : check e1211271061206 [[],[]] .sourceHead = true := by decide
def e1211271061210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)) (.var 0)))))
theorem wire_e1211271061210 : Closed e1211271061210 ∧ code e1211271061210 = 5609317572314 := by decide
theorem cert_e1211271061210 : check e1211271061210 [[],[]] .sourceHead = true := by decide
def e1211271073238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)) (.var 1)))))
theorem wire_e1211271073238 : Closed e1211271073238 ∧ code e1211271073238 = 5609317584342 := by decide
theorem cert_e1211271073238 : check e1211271073238 [[],[]] .sourceHead = true := by decide
def e1211271073242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)) (.var 0)))))
theorem wire_e1211271073242 : Closed e1211271073242 ∧ code e1211271073242 = 5609317584346 := by decide
theorem cert_e1211271073242 : check e1211271073242 [[],[]] .sourceHead = true := by decide
def e1211271073622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)) (.var 1)))))
theorem wire_e1211271073622 : Closed e1211271073622 ∧ code e1211271073622 = 5609317584726 := by decide
theorem cert_e1211271073622 : check e1211271073622 [[],[]] .sourceHead = true := by decide
def e1211271073626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)) (.var 0)))))
theorem wire_e1211271073626 : Closed e1211271073626 ∧ code e1211271073626 = 5609317584730 := by decide
theorem cert_e1211271073626 : check e1211271073626 [[],[]] .sourceHead = true := by decide
def e1211271079638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)) (.var 1)))))
theorem wire_e1211271079638 : Closed e1211271079638 ∧ code e1211271079638 = 5609317590742 := by decide
theorem cert_e1211271079638 : check e1211271079638 [[],[]] .sourceHead = true := by decide
def e1211271079642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)) (.var 0)))))
theorem wire_e1211271079642 : Closed e1211271079642 ∧ code e1211271079642 = 5609317590746 := by decide
theorem cert_e1211271079642 : check e1211271079642 [[],[]] .sourceHead = true := by decide
def e1211271079766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)) (.var 1)))))
theorem wire_e1211271079766 : Closed e1211271079766 ∧ code e1211271079766 = 5609317590870 := by decide
theorem cert_e1211271079766 : check e1211271079766 [[],[]] .sourceHead = true := by decide
def e1211271079770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)) (.var 0)))))
theorem wire_e1211271079770 : Closed e1211271079770 ∧ code e1211271079770 = 5609317590874 := by decide
theorem cert_e1211271079770 : check e1211271079770 [[],[]] .sourceHead = true := by decide
def e1211271502710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1211271502710 : Closed e1211271502710 ∧ code e1211271502710 = 5609318013814 := by decide
theorem cert_e1211271502710 : check e1211271502710 [[],[]] .sourceHead = true := by decide
def e1211271502774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1211271502774 : Closed e1211271502774 ∧ code e1211271502774 = 5609318013878 := by decide
theorem cert_e1211271502774 : check e1211271502774 [[],[]] .sourceHead = true := by decide
def e1211271503222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1211271503222 : Closed e1211271503222 ∧ code e1211271503222 = 5609318014326 := by decide
theorem cert_e1211271503222 : check e1211271503222 [[],[]] .sourceHead = true := by decide
def e1211271503318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1211271503318 : Closed e1211271503318 ∧ code e1211271503318 = 5609318014422 := by decide
theorem cert_e1211271503318 : check e1211271503318 [[],[]] .sourceHead = true := by decide
def e1211271503542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1211271503542 : Closed e1211271503542 ∧ code e1211271503542 = 5609318014646 := by decide
theorem cert_e1211271503542 : check e1211271503542 [[],[]] .sourceHead = true := by decide
def e1211271503574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1211271503574 : Closed e1211271503574 ∧ code e1211271503574 = 5609318014678 := by decide
theorem cert_e1211271503574 : check e1211271503574 [[],[]] .sourceHead = true := by decide
def e1211271505782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1211271505782 : Closed e1211271505782 ∧ code e1211271505782 = 5609318016886 := by decide
theorem cert_e1211271505782 : check e1211271505782 [[],[]] .sourceHead = true := by decide
def e1211271505846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1211271505846 : Closed e1211271505846 ∧ code e1211271505846 = 5609318016950 := by decide
theorem cert_e1211271505846 : check e1211271505846 [[],[]] .sourceHead = true := by decide
def e1211271508854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1211271508854 : Closed e1211271508854 ∧ code e1211271508854 = 5609318019958 := by decide
theorem cert_e1211271508854 : check e1211271508854 [[],[]] .sourceHead = true := by decide
def e1211271508950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1211271508950 : Closed e1211271508950 ∧ code e1211271508950 = 5609318020054 := by decide
theorem cert_e1211271508950 : check e1211271508950 [[],[]] .sourceHead = true := by decide
def e1211271510454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1211271510454 : Closed e1211271510454 ∧ code e1211271510454 = 5609318021558 := by decide
theorem cert_e1211271510454 : check e1211271510454 [[],[]] .sourceHead = true := by decide
def e1211271510486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1211271510486 : Closed e1211271510486 ∧ code e1211271510486 = 5609318021590 := by decide
theorem cert_e1211271510486 : check e1211271510486 [[],[]] .sourceHead = true := by decide
def e1211271678830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211271678830 : Closed e1211271678830 ∧ code e1211271678830 = 5609318189934 := by decide
theorem cert_e1211271678830 : check e1211271678830 [[],[]] .sourceHead = true := by decide
def e1211271678838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211271678838 : Closed e1211271678838 ∧ code e1211271678838 = 5609318189942 := by decide
theorem cert_e1211271678838 : check e1211271678838 [[],[]] .sourceHead = true := by decide
def e1211271678894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211271678894 : Closed e1211271678894 ∧ code e1211271678894 = 5609318189998 := by decide
theorem cert_e1211271678894 : check e1211271678894 [[],[]] .sourceHead = true := by decide
def e1211271678906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211271678906 : Closed e1211271678906 ∧ code e1211271678906 = 5609318190010 := by decide
theorem cert_e1211271678906 : check e1211271678906 [[],[]] .sourceHead = true := by decide
def e1211271678934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211271678934 : Closed e1211271678934 ∧ code e1211271678934 = 5609318190038 := by decide
theorem cert_e1211271678934 : check e1211271678934 [[],[]] .sourceHead = true := by decide
def e1211271678938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211271678938 : Closed e1211271678938 ∧ code e1211271678938 = 5609318190042 := by decide
theorem cert_e1211271678938 : check e1211271678938 [[],[]] .sourceHead = true := by decide
def e1211271679214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211271679214 : Closed e1211271679214 ∧ code e1211271679214 = 5609318190318 := by decide
theorem cert_e1211271679214 : check e1211271679214 [[],[]] .sourceHead = true := by decide
def e1211271679222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211271679222 : Closed e1211271679222 ∧ code e1211271679222 = 5609318190326 := by decide
theorem cert_e1211271679222 : check e1211271679222 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
