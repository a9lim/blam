import Tables
import Batch263
namespace Blc.Floor42.Grades263
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211585419098 : ¬ IsSelfInterpreter e1211585419098 := cutM0_2 (by decide)
#print axioms ex_e1211585419098
theorem ex_e1211585420506 : ¬ IsSelfInterpreter e1211585420506 := cutM0_2 (by decide)
#print axioms ex_e1211585420506
theorem ex_e1211585420522 : ¬ IsSelfInterpreter e1211585420522 := cutM0_2 (by decide)
#print axioms ex_e1211585420522
theorem ex_e1211585420598 : ¬ IsSelfInterpreter e1211585420598 := cutM0_2 (by decide)
#print axioms ex_e1211585420598
theorem ex_e1211585420602 : ¬ IsSelfInterpreter e1211585420602 := cutM0_2 (by decide)
#print axioms ex_e1211585420602
theorem ex_e1211585426134 : ¬ IsSelfInterpreter e1211585426134 := cutM0_2 (by decide)
#print axioms ex_e1211585426134
theorem ex_e1211585426138 : ¬ IsSelfInterpreter e1211585426138 := cutM0_2 (by decide)
#print axioms ex_e1211585426138
theorem ex_e1211585426154 : ¬ IsSelfInterpreter e1211585426154 := cutM0_2 (by decide)
#print axioms ex_e1211585426154
theorem ex_e1211585426234 : ¬ IsSelfInterpreter e1211585426234 := cutM0_2 (by decide)
#print axioms ex_e1211585426234
theorem ex_e1211585426330 : ¬ IsSelfInterpreter e1211585426330 := cutM0_2 (by decide)
#print axioms ex_e1211585426330
theorem ex_e1211585425646 : ¬ IsSelfInterpreter e1211585425646 := cutM13_0 (by decide)
#print axioms ex_e1211585425646
theorem ex_e1211585427854 : ¬ IsSelfInterpreter e1211585427854 := cutM13_0 (by decide)
#print axioms ex_e1211585427854
end Blc.Floor42.Grades263
