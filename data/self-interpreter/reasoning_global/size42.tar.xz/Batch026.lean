import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e379702041438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e379702041438 : Closed e379702041438 ∧ code e379702041438 = 4777748552542 := by decide
theorem cert_e379702041438 : check e379702041438 [] .sourceHead = true := by decide
def e379702041454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e379702041454 : Closed e379702041454 ∧ code e379702041454 = 4777748552558 := by decide
theorem cert_e379702041454 : check e379702041454 [] .sourceHead = true := by decide
def e379702041462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e379702041462 : Closed e379702041462 ∧ code e379702041462 = 4777748552566 := by decide
theorem cert_e379702041462 : check e379702041462 [] .sourceHead = true := by decide
def e379702041466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e379702041466 : Closed e379702041466 ∧ code e379702041466 = 4777748552570 := by decide
theorem cert_e379702041466 : check e379702041466 [] .sourceHead = true := by decide
def e379702041526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e379702041526 : Closed e379702041526 ∧ code e379702041526 = 4777748552630 := by decide
theorem cert_e379702041526 : check e379702041526 [] .sourceHead = true := by decide
def e379702041558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e379702041558 : Closed e379702041558 ∧ code e379702041558 = 4777748552662 := by decide
theorem cert_e379702041558 : check e379702041558 [] .sourceHead = true := by decide
def e379702041562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e379702041562 : Closed e379702041562 ∧ code e379702041562 = 4777748552666 := by decide
theorem cert_e379702041562 : check e379702041562 [] .sourceHead = true := by decide
def e379702041950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e379702041950 : Closed e379702041950 ∧ code e379702041950 = 4777748553054 := by decide
theorem cert_e379702041950 : check e379702041950 [] .sourceHead = true := by decide
def e379702041966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e379702041966 : Closed e379702041966 ∧ code e379702041966 = 4777748553070 := by decide
theorem cert_e379702041966 : check e379702041966 [] .sourceHead = true := by decide
def e379702041974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e379702041974 : Closed e379702041974 ∧ code e379702041974 = 4777748553078 := by decide
theorem cert_e379702041974 : check e379702041974 [] .sourceHead = true := by decide
def e379702041978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e379702041978 : Closed e379702041978 ∧ code e379702041978 = 4777748553082 := by decide
theorem cert_e379702041978 : check e379702041978 [] .sourceHead = true := by decide
def e379702042030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e379702042030 : Closed e379702042030 ∧ code e379702042030 = 4777748553134 := by decide
theorem cert_e379702042030 : check e379702042030 [] .sourceHead = true := by decide
def e379702042042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e379702042042 : Closed e379702042042 ∧ code e379702042042 = 4777748553146 := by decide
theorem cert_e379702042042 : check e379702042042 [] .sourceHead = true := by decide
def e379702042070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e379702042070 : Closed e379702042070 ∧ code e379702042070 = 4777748553174 := by decide
theorem cert_e379702042070 : check e379702042070 [] .sourceHead = true := by decide
def e379702042074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e379702042074 : Closed e379702042074 ∧ code e379702042074 = 4777748553178 := by decide
theorem cert_e379702042074 : check e379702042074 [] .sourceHead = true := by decide
def e379702042090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e379702042090 : Closed e379702042090 ∧ code e379702042090 = 4777748553194 := by decide
theorem cert_e379702042090 : check e379702042090 [] .sourceHead = true := by decide
def e379702042294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e379702042294 : Closed e379702042294 ∧ code e379702042294 = 4777748553398 := by decide
theorem cert_e379702042294 : check e379702042294 [] .sourceHead = true := by decide
def e379702042326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e379702042326 : Closed e379702042326 ∧ code e379702042326 = 4777748553430 := by decide
theorem cert_e379702042326 : check e379702042326 [] .sourceHead = true := by decide
def e379702042330 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e379702042330 : Closed e379702042330 ∧ code e379702042330 = 4777748553434 := by decide
theorem cert_e379702042330 : check e379702042330 [] .sourceHead = true := by decide
def e379702042454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e379702042454 : Closed e379702042454 ∧ code e379702042454 = 4777748553558 := by decide
theorem cert_e379702042454 : check e379702042454 [] .sourceHead = true := by decide
def e379702042458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e379702042458 : Closed e379702042458 ∧ code e379702042458 = 4777748553562 := by decide
theorem cert_e379702042458 : check e379702042458 [] .sourceHead = true := by decide
def e379702042474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e379702042474 : Closed e379702042474 ∧ code e379702042474 = 4777748553578 := by decide
theorem cert_e379702042474 : check e379702042474 [] .sourceHead = true := by decide
def e379702044382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e379702044382 : Closed e379702044382 ∧ code e379702044382 = 4777748555486 := by decide
theorem cert_e379702044382 : check e379702044382 [] .sourceHead = true := by decide
def e379702044406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e379702044406 : Closed e379702044406 ∧ code e379702044406 = 4777748555510 := by decide
theorem cert_e379702044406 : check e379702044406 [] .sourceHead = true := by decide
def e379702044510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e379702044510 : Closed e379702044510 ∧ code e379702044510 = 4777748555614 := by decide
theorem cert_e379702044510 : check e379702044510 [] .sourceHead = true := by decide
def e379702044526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e379702044526 : Closed e379702044526 ∧ code e379702044526 = 4777748555630 := by decide
theorem cert_e379702044526 : check e379702044526 [] .sourceHead = true := by decide
def e379702044534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e379702044534 : Closed e379702044534 ∧ code e379702044534 = 4777748555638 := by decide
theorem cert_e379702044534 : check e379702044534 [] .sourceHead = true := by decide
def e379702044538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e379702044538 : Closed e379702044538 ∧ code e379702044538 = 4777748555642 := by decide
theorem cert_e379702044538 : check e379702044538 [] .sourceHead = true := by decide
def e379702044598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e379702044598 : Closed e379702044598 ∧ code e379702044598 = 4777748555702 := by decide
theorem cert_e379702044598 : check e379702044598 [] .sourceHead = true := by decide
def e379702044630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e379702044630 : Closed e379702044630 ∧ code e379702044630 = 4777748555734 := by decide
theorem cert_e379702044630 : check e379702044630 [] .sourceHead = true := by decide
def e379702044634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e379702044634 : Closed e379702044634 ∧ code e379702044634 = 4777748555738 := by decide
theorem cert_e379702044634 : check e379702044634 [] .sourceHead = true := by decide
def e379702045150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e379702045150 : Closed e379702045150 ∧ code e379702045150 = 4777748556254 := by decide
theorem cert_e379702045150 : check e379702045150 [] .sourceHead = true := by decide
def e379702045174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e379702045174 : Closed e379702045174 ∧ code e379702045174 = 4777748556278 := by decide
theorem cert_e379702045174 : check e379702045174 [] .sourceHead = true := by decide
def e379702045918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e379702045918 : Closed e379702045918 ∧ code e379702045918 = 4777748557022 := by decide
theorem cert_e379702045918 : check e379702045918 [] .sourceHead = true := by decide
def e379702045934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e379702045934 : Closed e379702045934 ∧ code e379702045934 = 4777748557038 := by decide
theorem cert_e379702045934 : check e379702045934 [] .sourceHead = true := by decide
def e379702045942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e379702045942 : Closed e379702045942 ∧ code e379702045942 = 4777748557046 := by decide
theorem cert_e379702045942 : check e379702045942 [] .sourceHead = true := by decide
def e379702045946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e379702045946 : Closed e379702045946 ∧ code e379702045946 = 4777748557050 := by decide
theorem cert_e379702045946 : check e379702045946 [] .sourceHead = true := by decide
def e379702046326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e379702046326 : Closed e379702046326 ∧ code e379702046326 = 4777748557430 := by decide
theorem cert_e379702046326 : check e379702046326 [] .sourceHead = true := by decide
def e379702046518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e379702046518 : Closed e379702046518 ∧ code e379702046518 = 4777748557622 := by decide
theorem cert_e379702046518 : check e379702046518 [] .sourceHead = true := by decide
def e379702046522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e379702046522 : Closed e379702046522 ∧ code e379702046522 = 4777748557626 := by decide
theorem cert_e379702046522 : check e379702046522 [] .sourceHead = true := by decide
def e379702047582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e379702047582 : Closed e379702047582 ∧ code e379702047582 = 4777748558686 := by decide
theorem cert_e379702047582 : check e379702047582 [] .sourceHead = true := by decide
def e379702047598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e379702047598 : Closed e379702047598 ∧ code e379702047598 = 4777748558702 := by decide
theorem cert_e379702047598 : check e379702047598 [] .sourceHead = true := by decide
def e379702047606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e379702047606 : Closed e379702047606 ∧ code e379702047606 = 4777748558710 := by decide
theorem cert_e379702047606 : check e379702047606 [] .sourceHead = true := by decide
def e379702047610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e379702047610 : Closed e379702047610 ∧ code e379702047610 = 4777748558714 := by decide
theorem cert_e379702047610 : check e379702047610 [] .sourceHead = true := by decide
def e379702047662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e379702047662 : Closed e379702047662 ∧ code e379702047662 = 4777748558766 := by decide
theorem cert_e379702047662 : check e379702047662 [] .sourceHead = true := by decide
def e379702047674 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e379702047674 : Closed e379702047674 ∧ code e379702047674 = 4777748558778 := by decide
theorem cert_e379702047674 : check e379702047674 [] .sourceHead = true := by decide
def e379702047702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e379702047702 : Closed e379702047702 ∧ code e379702047702 = 4777748558806 := by decide
theorem cert_e379702047702 : check e379702047702 [] .sourceHead = true := by decide
def e379702047706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e379702047706 : Closed e379702047706 ∧ code e379702047706 = 4777748558810 := by decide
theorem cert_e379702047706 : check e379702047706 [] .sourceHead = true := by decide
def e379702047722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e379702047722 : Closed e379702047722 ∧ code e379702047722 = 4777748558826 := by decide
theorem cert_e379702047722 : check e379702047722 [] .sourceHead = true := by decide
def e379702047966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e379702047966 : Closed e379702047966 ∧ code e379702047966 = 4777748559070 := by decide
theorem cert_e379702047966 : check e379702047966 [] .sourceHead = true := by decide
def e379702047982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e379702047982 : Closed e379702047982 ∧ code e379702047982 = 4777748559086 := by decide
theorem cert_e379702047982 : check e379702047982 [] .sourceHead = true := by decide
def e379702047990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e379702047990 : Closed e379702047990 ∧ code e379702047990 = 4777748559094 := by decide
theorem cert_e379702047990 : check e379702047990 [] .sourceHead = true := by decide
def e379702047994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e379702047994 : Closed e379702047994 ∧ code e379702047994 = 4777748559098 := by decide
theorem cert_e379702047994 : check e379702047994 [] .sourceHead = true := by decide
def e379702048366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e379702048366 : Closed e379702048366 ∧ code e379702048366 = 4777748559470 := by decide
theorem cert_e379702048366 : check e379702048366 [] .sourceHead = true := by decide
def e379702048378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e379702048378 : Closed e379702048378 ∧ code e379702048378 = 4777748559482 := by decide
theorem cert_e379702048378 : check e379702048378 [] .sourceHead = true := by decide
def e379702048566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e379702048566 : Closed e379702048566 ∧ code e379702048566 = 4777748559670 := by decide
theorem cert_e379702048566 : check e379702048566 [] .sourceHead = true := by decide
def e379702048570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e379702048570 : Closed e379702048570 ∧ code e379702048570 = 4777748559674 := by decide
theorem cert_e379702048570 : check e379702048570 [] .sourceHead = true := by decide
def e379702048666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e379702048666 : Closed e379702048666 ∧ code e379702048666 = 4777748559770 := by decide
theorem cert_e379702048666 : check e379702048666 [] .sourceHead = true := by decide
def e379702049206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e379702049206 : Closed e379702049206 ∧ code e379702049206 = 4777748560310 := by decide
theorem cert_e379702049206 : check e379702049206 [] .sourceHead = true := by decide
def e379702049238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e379702049238 : Closed e379702049238 ∧ code e379702049238 = 4777748560342 := by decide
theorem cert_e379702049238 : check e379702049238 [] .sourceHead = true := by decide
def e379702049242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e379702049242 : Closed e379702049242 ∧ code e379702049242 = 4777748560346 := by decide
theorem cert_e379702049242 : check e379702049242 [] .sourceHead = true := by decide
def e379702049398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e379702049398 : Closed e379702049398 ∧ code e379702049398 = 4777748560502 := by decide
theorem cert_e379702049398 : check e379702049398 [] .sourceHead = true := by decide
def e379702049590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e379702049590 : Closed e379702049590 ∧ code e379702049590 = 4777748560694 := by decide
theorem cert_e379702049590 : check e379702049590 [] .sourceHead = true := by decide
def e379702049594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e379702049594 : Closed e379702049594 ∧ code e379702049594 = 4777748560698 := by decide
theorem cert_e379702049594 : check e379702049594 [] .sourceHead = true := by decide
def e379702050006 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e379702050006 : Closed e379702050006 ∧ code e379702050006 = 4777748561110 := by decide
theorem cert_e379702050006 : check e379702050006 [] .sourceHead = true := by decide
def e379702050010 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e379702050010 : Closed e379702050010 ∧ code e379702050010 = 4777748561114 := by decide
theorem cert_e379702050010 : check e379702050010 [] .sourceHead = true := by decide
def e379702050026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e379702050026 : Closed e379702050026 ∧ code e379702050026 = 4777748561130 := by decide
theorem cert_e379702050026 : check e379702050026 [] .sourceHead = true := by decide
def e379702050102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e379702050102 : Closed e379702050102 ∧ code e379702050102 = 4777748561206 := by decide
theorem cert_e379702050102 : check e379702050102 [] .sourceHead = true := by decide
def e379702050106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e379702050106 : Closed e379702050106 ∧ code e379702050106 = 4777748561210 := by decide
theorem cert_e379702050106 : check e379702050106 [] .sourceHead = true := by decide
def e379702050202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e379702050202 : Closed e379702050202 ∧ code e379702050202 = 4777748561306 := by decide
theorem cert_e379702050202 : check e379702050202 [] .sourceHead = true := by decide
def e379702056670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e379702056670 : Closed e379702056670 ∧ code e379702056670 = 4777748567774 := by decide
theorem cert_e379702056670 : check e379702056670 [] .sourceHead = true := by decide
def e379702056694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e379702056694 : Closed e379702056694 ∧ code e379702056694 = 4777748567798 := by decide
theorem cert_e379702056694 : check e379702056694 [] .sourceHead = true := by decide
def e379702056798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e379702056798 : Closed e379702056798 ∧ code e379702056798 = 4777748567902 := by decide
theorem cert_e379702056798 : check e379702056798 [] .sourceHead = true := by decide
def e379702056814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e379702056814 : Closed e379702056814 ∧ code e379702056814 = 4777748567918 := by decide
theorem cert_e379702056814 : check e379702056814 [] .sourceHead = true := by decide
def e379702056822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e379702056822 : Closed e379702056822 ∧ code e379702056822 = 4777748567926 := by decide
theorem cert_e379702056822 : check e379702056822 [] .sourceHead = true := by decide
def e379702056826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e379702056826 : Closed e379702056826 ∧ code e379702056826 = 4777748567930 := by decide
theorem cert_e379702056826 : check e379702056826 [] .sourceHead = true := by decide
def e379702056886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e379702056886 : Closed e379702056886 ∧ code e379702056886 = 4777748567990 := by decide
theorem cert_e379702056886 : check e379702056886 [] .sourceHead = true := by decide
def e379702056918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e379702056918 : Closed e379702056918 ∧ code e379702056918 = 4777748568022 := by decide
theorem cert_e379702056918 : check e379702056918 [] .sourceHead = true := by decide
def e379702056922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e379702056922 : Closed e379702056922 ∧ code e379702056922 = 4777748568026 := by decide
theorem cert_e379702056922 : check e379702056922 [] .sourceHead = true := by decide
def e379702057438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e379702057438 : Closed e379702057438 ∧ code e379702057438 = 4777748568542 := by decide
theorem cert_e379702057438 : check e379702057438 [] .sourceHead = true := by decide
def e379702057462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e379702057462 : Closed e379702057462 ∧ code e379702057462 = 4777748568566 := by decide
theorem cert_e379702057462 : check e379702057462 [] .sourceHead = true := by decide
def e379702058206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e379702058206 : Closed e379702058206 ∧ code e379702058206 = 4777748569310 := by decide
theorem cert_e379702058206 : check e379702058206 [] .sourceHead = true := by decide
def e379702058222 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e379702058222 : Closed e379702058222 ∧ code e379702058222 = 4777748569326 := by decide
theorem cert_e379702058222 : check e379702058222 [] .sourceHead = true := by decide
def e379702058230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e379702058230 : Closed e379702058230 ∧ code e379702058230 = 4777748569334 := by decide
theorem cert_e379702058230 : check e379702058230 [] .sourceHead = true := by decide
def e379702058234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e379702058234 : Closed e379702058234 ∧ code e379702058234 = 4777748569338 := by decide
theorem cert_e379702058234 : check e379702058234 [] .sourceHead = true := by decide
def e379702058614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e379702058614 : Closed e379702058614 ∧ code e379702058614 = 4777748569718 := by decide
theorem cert_e379702058614 : check e379702058614 [] .sourceHead = true := by decide
def e379702058806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702058806 : Closed e379702058806 ∧ code e379702058806 = 4777748569910 := by decide
theorem cert_e379702058806 : check e379702058806 [] .sourceHead = true := by decide
def e379702058810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702058810 : Closed e379702058810 ∧ code e379702058810 = 4777748569914 := by decide
theorem cert_e379702058810 : check e379702058810 [] .sourceHead = true := by decide
def e379702070110 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e379702070110 : Closed e379702070110 ∧ code e379702070110 = 4777748581214 := by decide
theorem cert_e379702070110 : check e379702070110 [] .sourceHead = true := by decide
def e379702070126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e379702070126 : Closed e379702070126 ∧ code e379702070126 = 4777748581230 := by decide
theorem cert_e379702070126 : check e379702070126 [] .sourceHead = true := by decide
def e379702070134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e379702070134 : Closed e379702070134 ∧ code e379702070134 = 4777748581238 := by decide
theorem cert_e379702070134 : check e379702070134 [] .sourceHead = true := by decide
def e379702070138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e379702070138 : Closed e379702070138 ∧ code e379702070138 = 4777748581242 := by decide
theorem cert_e379702070138 : check e379702070138 [] .sourceHead = true := by decide
def e379702070190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e379702070190 : Closed e379702070190 ∧ code e379702070190 = 4777748581294 := by decide
theorem cert_e379702070190 : check e379702070190 [] .sourceHead = true := by decide
def e379702070202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e379702070202 : Closed e379702070202 ∧ code e379702070202 = 4777748581306 := by decide
theorem cert_e379702070202 : check e379702070202 [] .sourceHead = true := by decide
def e379702070230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e379702070230 : Closed e379702070230 ∧ code e379702070230 = 4777748581334 := by decide
theorem cert_e379702070230 : check e379702070230 [] .sourceHead = true := by decide
def e379702070234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e379702070234 : Closed e379702070234 ∧ code e379702070234 = 4777748581338 := by decide
theorem cert_e379702070234 : check e379702070234 [] .sourceHead = true := by decide
def e379702070250 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e379702070250 : Closed e379702070250 ∧ code e379702070250 = 4777748581354 := by decide
theorem cert_e379702070250 : check e379702070250 [] .sourceHead = true := by decide
def e379702070494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e379702070494 : Closed e379702070494 ∧ code e379702070494 = 4777748581598 := by decide
theorem cert_e379702070494 : check e379702070494 [] .sourceHead = true := by decide
def e379702070510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e379702070510 : Closed e379702070510 ∧ code e379702070510 = 4777748581614 := by decide
theorem cert_e379702070510 : check e379702070510 [] .sourceHead = true := by decide
def e379702070518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e379702070518 : Closed e379702070518 ∧ code e379702070518 = 4777748581622 := by decide
theorem cert_e379702070518 : check e379702070518 [] .sourceHead = true := by decide
def e379702070522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e379702070522 : Closed e379702070522 ∧ code e379702070522 = 4777748581626 := by decide
theorem cert_e379702070522 : check e379702070522 [] .sourceHead = true := by decide
def e379702070894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e379702070894 : Closed e379702070894 ∧ code e379702070894 = 4777748581998 := by decide
theorem cert_e379702070894 : check e379702070894 [] .sourceHead = true := by decide
def e379702070906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e379702070906 : Closed e379702070906 ∧ code e379702070906 = 4777748582010 := by decide
theorem cert_e379702070906 : check e379702070906 [] .sourceHead = true := by decide
def e379702071094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702071094 : Closed e379702071094 ∧ code e379702071094 = 4777748582198 := by decide
theorem cert_e379702071094 : check e379702071094 [] .sourceHead = true := by decide
def e379702071098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702071098 : Closed e379702071098 ∧ code e379702071098 = 4777748582202 := by decide
theorem cert_e379702071098 : check e379702071098 [] .sourceHead = true := by decide
def e379702071194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e379702071194 : Closed e379702071194 ∧ code e379702071194 = 4777748582298 := by decide
theorem cert_e379702071194 : check e379702071194 [] .sourceHead = true := by decide
def e379702076854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e379702076854 : Closed e379702076854 ∧ code e379702076854 = 4777748587958 := by decide
theorem cert_e379702076854 : check e379702076854 [] .sourceHead = true := by decide
def e379702076886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e379702076886 : Closed e379702076886 ∧ code e379702076886 = 4777748587990 := by decide
theorem cert_e379702076886 : check e379702076886 [] .sourceHead = true := by decide
def e379702076890 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e379702076890 : Closed e379702076890 ∧ code e379702076890 = 4777748587994 := by decide
theorem cert_e379702076890 : check e379702076890 [] .sourceHead = true := by decide
def e379702077046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e379702077046 : Closed e379702077046 ∧ code e379702077046 = 4777748588150 := by decide
theorem cert_e379702077046 : check e379702077046 [] .sourceHead = true := by decide
def e379702077238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702077238 : Closed e379702077238 ∧ code e379702077238 = 4777748588342 := by decide
theorem cert_e379702077238 : check e379702077238 [] .sourceHead = true := by decide
def e379702077242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702077242 : Closed e379702077242 ∧ code e379702077242 = 4777748588346 := by decide
theorem cert_e379702077242 : check e379702077242 [] .sourceHead = true := by decide
def e379702080214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e379702080214 : Closed e379702080214 ∧ code e379702080214 = 4777748591318 := by decide
theorem cert_e379702080214 : check e379702080214 [] .sourceHead = true := by decide
def e379702080218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e379702080218 : Closed e379702080218 ∧ code e379702080218 = 4777748591322 := by decide
theorem cert_e379702080218 : check e379702080218 [] .sourceHead = true := by decide
def e379702080234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e379702080234 : Closed e379702080234 ∧ code e379702080234 = 4777748591338 := by decide
theorem cert_e379702080234 : check e379702080234 [] .sourceHead = true := by decide
def e379702080310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702080310 : Closed e379702080310 ∧ code e379702080310 = 4777748591414 := by decide
theorem cert_e379702080310 : check e379702080310 [] .sourceHead = true := by decide
def e379702080314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702080314 : Closed e379702080314 ∧ code e379702080314 = 4777748591418 := by decide
theorem cert_e379702080314 : check e379702080314 [] .sourceHead = true := by decide
def e379702080410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e379702080410 : Closed e379702080410 ∧ code e379702080410 = 4777748591514 := by decide
theorem cert_e379702080410 : check e379702080410 [] .sourceHead = true := by decide
def e379702305646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e379702305646 : Closed e379702305646 ∧ code e379702305646 = 4777748816750 := by decide
theorem cert_e379702305646 : check e379702305646 [] .sourceHead = true := by decide
def e379702305654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e379702305654 : Closed e379702305654 ∧ code e379702305654 = 4777748816758 := by decide
theorem cert_e379702305654 : check e379702305654 [] .sourceHead = true := by decide
def e379702305710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e379702305710 : Closed e379702305710 ∧ code e379702305710 = 4777748816814 := by decide
theorem cert_e379702305710 : check e379702305710 [] .sourceHead = true := by decide
def e379702305722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e379702305722 : Closed e379702305722 ∧ code e379702305722 = 4777748816826 := by decide
theorem cert_e379702305722 : check e379702305722 [] .sourceHead = true := by decide
def e379702305750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e379702305750 : Closed e379702305750 ∧ code e379702305750 = 4777748816854 := by decide
theorem cert_e379702305750 : check e379702305750 [] .sourceHead = true := by decide
def e379702305754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e379702305754 : Closed e379702305754 ∧ code e379702305754 = 4777748816858 := by decide
theorem cert_e379702305754 : check e379702305754 [] .sourceHead = true := by decide
def e379702307054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e379702307054 : Closed e379702307054 ∧ code e379702307054 = 4777748818158 := by decide
theorem cert_e379702307054 : check e379702307054 [] .sourceHead = true := by decide
def e379702307062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e379702307062 : Closed e379702307062 ∧ code e379702307062 = 4777748818166 := by decide
theorem cert_e379702307062 : check e379702307062 [] .sourceHead = true := by decide
def e379702307614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e379702307614 : Closed e379702307614 ∧ code e379702307614 = 4777748818718 := by decide
theorem cert_e379702307614 : check e379702307614 [] .sourceHead = true := by decide
def e379702307726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e379702307726 : Closed e379702307726 ∧ code e379702307726 = 4777748818830 := by decide
theorem cert_e379702307726 : check e379702307726 [] .sourceHead = true := by decide
def e379702307950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e379702307950 : Closed e379702307950 ∧ code e379702307950 = 4777748819054 := by decide
theorem cert_e379702307950 : check e379702307950 [] .sourceHead = true := by decide
def e379702307962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e379702307962 : Closed e379702307962 ∧ code e379702307962 = 4777748819066 := by decide
theorem cert_e379702307962 : check e379702307962 [] .sourceHead = true := by decide
def e379702308126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e379702308126 : Closed e379702308126 ∧ code e379702308126 = 4777748819230 := by decide
theorem cert_e379702308126 : check e379702308126 [] .sourceHead = true := by decide
def e379702308294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e379702308294 : Closed e379702308294 ∧ code e379702308294 = 4777748819398 := by decide
theorem cert_e379702308294 : check e379702308294 [] .sourceHead = true := by decide
def e379702308406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e379702308406 : Closed e379702308406 ∧ code e379702308406 = 4777748819510 := by decide
theorem cert_e379702308406 : check e379702308406 [] .sourceHead = true := by decide
def e379702308410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e379702308410 : Closed e379702308410 ∧ code e379702308410 = 4777748819514 := by decide
theorem cert_e379702308410 : check e379702308410 [] .sourceHead = true := by decide
def e379702308494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e379702308494 : Closed e379702308494 ∧ code e379702308494 = 4777748819598 := by decide
theorem cert_e379702308494 : check e379702308494 [] .sourceHead = true := by decide
def e379702308550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e379702308550 : Closed e379702308550 ∧ code e379702308550 = 4777748819654 := by decide
theorem cert_e379702308550 : check e379702308550 [] .sourceHead = true := by decide
def e379702309294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e379702309294 : Closed e379702309294 ∧ code e379702309294 = 4777748820398 := by decide
theorem cert_e379702309294 : check e379702309294 [] .sourceHead = true := by decide
def e379702309306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e379702309306 : Closed e379702309306 ∧ code e379702309306 = 4777748820410 := by decide
theorem cert_e379702309306 : check e379702309306 [] .sourceHead = true := by decide
def e379702309354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e379702309354 : Closed e379702309354 ∧ code e379702309354 = 4777748820458 := by decide
theorem cert_e379702309354 : check e379702309354 [] .sourceHead = true := by decide
def e379702309998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e379702309998 : Closed e379702309998 ∧ code e379702309998 = 4777748821102 := by decide
theorem cert_e379702309998 : check e379702309998 [] .sourceHead = true := by decide
def e379702310010 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e379702310010 : Closed e379702310010 ∧ code e379702310010 = 4777748821114 := by decide
theorem cert_e379702310010 : check e379702310010 [] .sourceHead = true := by decide
def e379702310174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e379702310174 : Closed e379702310174 ∧ code e379702310174 = 4777748821278 := by decide
theorem cert_e379702310174 : check e379702310174 [] .sourceHead = true := by decide
def e379702310342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e379702310342 : Closed e379702310342 ∧ code e379702310342 = 4777748821446 := by decide
theorem cert_e379702310342 : check e379702310342 [] .sourceHead = true := by decide
def e379702310682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e379702310682 : Closed e379702310682 ∧ code e379702310682 = 4777748821786 := by decide
theorem cert_e379702310682 : check e379702310682 [] .sourceHead = true := by decide
def e379702310726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e379702310726 : Closed e379702310726 ∧ code e379702310726 = 4777748821830 := by decide
theorem cert_e379702310726 : check e379702310726 [] .sourceHead = true := by decide
def e379702311126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e379702311126 : Closed e379702311126 ∧ code e379702311126 = 4777748822230 := by decide
theorem cert_e379702311126 : check e379702311126 [] .sourceHead = true := by decide
def e379702311130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e379702311130 : Closed e379702311130 ∧ code e379702311130 = 4777748822234 := by decide
theorem cert_e379702311130 : check e379702311130 [] .sourceHead = true := by decide
def e379702311146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e379702311146 : Closed e379702311146 ∧ code e379702311146 = 4777748822250 := by decide
theorem cert_e379702311146 : check e379702311146 [] .sourceHead = true := by decide
def e379702311478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e379702311478 : Closed e379702311478 ∧ code e379702311478 = 4777748822582 := by decide
theorem cert_e379702311478 : check e379702311478 [] .sourceHead = true := by decide
def e379702311482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e379702311482 : Closed e379702311482 ∧ code e379702311482 = 4777748822586 := by decide
theorem cert_e379702311482 : check e379702311482 [] .sourceHead = true := by decide
def e379702311566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e379702311566 : Closed e379702311566 ∧ code e379702311566 = 4777748822670 := by decide
theorem cert_e379702311566 : check e379702311566 [] .sourceHead = true := by decide
def e379702311622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e379702311622 : Closed e379702311622 ∧ code e379702311622 = 4777748822726 := by decide
theorem cert_e379702311622 : check e379702311622 [] .sourceHead = true := by decide
def e379702311706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e379702311706 : Closed e379702311706 ∧ code e379702311706 = 4777748822810 := by decide
theorem cert_e379702311706 : check e379702311706 [] .sourceHead = true := by decide
def e379702311750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e379702311750 : Closed e379702311750 ∧ code e379702311750 = 4777748822854 := by decide
theorem cert_e379702311750 : check e379702311750 [] .sourceHead = true := by decide
def e379702316270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e379702316270 : Closed e379702316270 ∧ code e379702316270 = 4777748827374 := by decide
theorem cert_e379702316270 : check e379702316270 [] .sourceHead = true := by decide
def e379702316278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e379702316278 : Closed e379702316278 ∧ code e379702316278 = 4777748827382 := by decide
theorem cert_e379702316278 : check e379702316278 [] .sourceHead = true := by decide
def e379702316654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e379702316654 : Closed e379702316654 ∧ code e379702316654 = 4777748827758 := by decide
theorem cert_e379702316654 : check e379702316654 [] .sourceHead = true := by decide
def e379702316666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e379702316666 : Closed e379702316666 ∧ code e379702316666 = 4777748827770 := by decide
theorem cert_e379702316666 : check e379702316666 [] .sourceHead = true := by decide
def e379702316854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e379702316854 : Closed e379702316854 ∧ code e379702316854 = 4777748827958 := by decide
theorem cert_e379702316854 : check e379702316854 [] .sourceHead = true := by decide
def e379702316858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e379702316858 : Closed e379702316858 ∧ code e379702316858 = 4777748827962 := by decide
theorem cert_e379702316858 : check e379702316858 [] .sourceHead = true := by decide
end Blc.Floor42
