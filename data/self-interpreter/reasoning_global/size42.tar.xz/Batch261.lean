import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211584966902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211584966902 : Closed e1211584966902 ∧ code e1211584966902 = 5609631478006 := by decide
private def t_e1211584966902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e1211584966902 : ¬ IsSelfInterpreter e1211584966902 :=
  wSource (t := t_e1211584966902) (replay_sound (ps := []) (t := e1211584966902) (by decide)) (by decide)
def e1211584967382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211584967382 : Closed e1211584967382 ∧ code e1211584967382 = 5609631478486 := by decide
private def t_e1211584967382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1211584967382 : ¬ IsSelfInterpreter e1211584967382 :=
  wSource (t := t_e1211584967382) (replay_sound (ps := []) (t := e1211584967382) (by decide)) (by decide)
def e1211584967386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211584967386 : Closed e1211584967386 ∧ code e1211584967386 = 5609631478490 := by decide
private def t_e1211584967386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e1211584967386 : ¬ IsSelfInterpreter e1211584967386 :=
  wSource (t := t_e1211584967386) (replay_sound (ps := []) (t := e1211584967386) (by decide)) (by decide)
def e1211584967402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211584967402 : Closed e1211584967402 ∧ code e1211584967402 = 5609631478506 := by decide
private def t_e1211584967402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e1211584967402 : ¬ IsSelfInterpreter e1211584967402 :=
  wSource (t := t_e1211584967402) (replay_sound (ps := []) (t := e1211584967402) (by decide)) (by decide)
def e1211584967430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584967430 : Closed e1211584967430 ∧ code e1211584967430 = 5609631478534 := by decide
private def t_e1211584967430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem cert_e1211584967430 : ¬ IsSelfInterpreter e1211584967430 :=
  wSource (t := t_e1211584967430) (replay_sound (ps := []) (t := e1211584967430) (by decide)) (by decide)
def e1211584967454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211584967454 : Closed e1211584967454 ∧ code e1211584967454 = 5609631478558 := by decide
private def t_e1211584967454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e1211584967454 : ¬ IsSelfInterpreter e1211584967454 :=
  wSource (t := t_e1211584967454) (replay_sound (ps := []) (t := e1211584967454) (by decide)) (by decide)
def e1211584967478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584967478 : Closed e1211584967478 ∧ code e1211584967478 = 5609631478582 := by decide
private def t_e1211584967478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211584967478 : ¬ IsSelfInterpreter e1211584967478 :=
  wSource (t := t_e1211584967478) (replay_sound (ps := []) (t := e1211584967478) (by decide)) (by decide)
def e1211584967482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584967482 : Closed e1211584967482 ∧ code e1211584967482 = 5609631478586 := by decide
private def t_e1211584967482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211584967482 : ¬ IsSelfInterpreter e1211584967482 :=
  wSource (t := t_e1211584967482) (replay_sound (ps := []) (t := e1211584967482) (by decide)) (by decide)
def e1211584967578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211584967578 : Closed e1211584967578 ∧ code e1211584967578 = 5609631478682 := by decide
private def t_e1211584967578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211584967578 : ¬ IsSelfInterpreter e1211584967578 :=
  wSource (t := t_e1211584967578) (replay_sound (ps := []) (t := e1211584967578) (by decide)) (by decide)
def e1211584967622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211584967622 : Closed e1211584967622 ∧ code e1211584967622 = 5609631478726 := by decide
private def t_e1211584967622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e1211584967622 : ¬ IsSelfInterpreter e1211584967622 :=
  wSource (t := t_e1211584967622) (replay_sound (ps := []) (t := e1211584967622) (by decide)) (by decide)
def e1211584970998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211584970998 : Closed e1211584970998 ∧ code e1211584970998 = 5609631482102 := by decide
theorem cert_e1211584970998 : check e1211584970998 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584971002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211584971002 : Closed e1211584971002 ∧ code e1211584971002 = 5609631482106 := by decide
theorem cert_e1211584971002 : check e1211584971002 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211584971574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584971574 : Closed e1211584971574 ∧ code e1211584971574 = 5609631482678 := by decide
theorem cert_e1211584971574 : check e1211584971574 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584971578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584971578 : Closed e1211584971578 ∧ code e1211584971578 = 5609631482682 := by decide
theorem cert_e1211584971578 : check e1211584971578 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584971662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211584971662 : Closed e1211584971662 ∧ code e1211584971662 = 5609631482766 := by decide
theorem cert_e1211584971662 : check e1211584971662 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584971718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211584971718 : Closed e1211584971718 ∧ code e1211584971718 = 5609631482822 := by decide
theorem cert_e1211584971718 : check e1211584971718 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211584972566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211584972566 : Closed e1211584972566 ∧ code e1211584972566 = 5609631483670 := by decide
theorem cert_e1211584972566 : check e1211584972566 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584972662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211584972662 : Closed e1211584972662 ∧ code e1211584972662 = 5609631483766 := by decide
theorem cert_e1211584972662 : check e1211584972662 [[],[],[],[],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584972682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211584972682 : Closed e1211584972682 ∧ code e1211584972682 = 5609631483786 := by decide
theorem cert_e1211584972682 : check e1211584972682 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211584972726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211584972726 : Closed e1211584972726 ∧ code e1211584972726 = 5609631483830 := by decide
theorem cert_e1211584972726 : check e1211584972726 [[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584972730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e1211584972730 : Closed e1211584972730 ∧ code e1211584972730 = 5609631483834 := by decide
private def t_e1211584972730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem cert_e1211584972730 : ¬ IsSelfInterpreter e1211584972730 :=
  wSource (t := t_e1211584972730) (replay_sound (ps := []) (t := e1211584972730) (by decide)) (by decide)
def e1211584973198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211584973198 : Closed e1211584973198 ∧ code e1211584973198 = 5609631484302 := by decide
theorem cert_e1211584973198 : check e1211584973198 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584973254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211584973254 : Closed e1211584973254 ∧ code e1211584973254 = 5609631484358 := by decide
theorem cert_e1211584973254 : check e1211584973254 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584973854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211584973854 : Closed e1211584973854 ∧ code e1211584973854 = 5609631484958 := by decide
theorem cert_e1211584973854 : check e1211584973854 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584974050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211584974050 : Closed e1211584974050 ∧ code e1211584974050 = 5609631485154 := by decide
theorem cert_e1211584974050 : check e1211584974050 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584974062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584974062 : Closed e1211584974062 ∧ code e1211584974062 = 5609631485166 := by decide
theorem cert_e1211584974062 : check e1211584974062 [[],[],[],[],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584974070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584974070 : Closed e1211584974070 ∧ code e1211584974070 = 5609631485174 := by decide
theorem cert_e1211584974070 : check e1211584974070 [[],[],[],[],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584974350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211584974350 : Closed e1211584974350 ∧ code e1211584974350 = 5609631485454 := by decide
theorem cert_e1211584974350 : check e1211584974350 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211584974434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211584974434 : Closed e1211584974434 ∧ code e1211584974434 = 5609631485538 := by decide
theorem cert_e1211584974434 : check e1211584974434 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211584974446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584974446 : Closed e1211584974446 ∧ code e1211584974446 = 5609631485550 := by decide
theorem cert_e1211584974446 : check e1211584974446 [[],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211584974458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584974458 : Closed e1211584974458 ∧ code e1211584974458 = 5609631485562 := by decide
theorem cert_e1211584974458 : check e1211584974458 [[],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211584974646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584974646 : Closed e1211584974646 ∧ code e1211584974646 = 5609631485750 := by decide
theorem cert_e1211584974646 : check e1211584974646 [[],[],[],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584974650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584974650 : Closed e1211584974650 ∧ code e1211584974650 = 5609631485754 := by decide
def e1211584976566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211584976566 : Closed e1211584976566 ∧ code e1211584976566 = 5609631487670 := by decide
theorem cert_e1211584976566 : check e1211584976566 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584976598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211584976598 : Closed e1211584976598 ∧ code e1211584976598 = 5609631487702 := by decide
theorem cert_e1211584976598 : check e1211584976598 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584976602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211584976602 : Closed e1211584976602 ∧ code e1211584976602 = 5609631487706 := by decide
theorem cert_e1211584976602 : check e1211584976602 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584976726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211584976726 : Closed e1211584976726 ∧ code e1211584976726 = 5609631487830 := by decide
theorem cert_e1211584976726 : check e1211584976726 [[],[],[],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584976730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211584976730 : Closed e1211584976730 ∧ code e1211584976730 = 5609631487834 := by decide
theorem cert_e1211584976730 : check e1211584976730 [[],[],[],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584976746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211584976746 : Closed e1211584976746 ∧ code e1211584976746 = 5609631487850 := by decide
private def t_e1211584976746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem cert_e1211584976746 : ¬ IsSelfInterpreter e1211584976746 :=
  wSource (t := t_e1211584976746) (replay_sound (ps := []) (t := e1211584976746) (by decide)) (by decide)
def e1211584976950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211584976950 : Closed e1211584976950 ∧ code e1211584976950 = 5609631488054 := by decide
theorem cert_e1211584976950 : check e1211584976950 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584977038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211584977038 : Closed e1211584977038 ∧ code e1211584977038 = 5609631488142 := by decide
theorem cert_e1211584977038 : check e1211584977038 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584977122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211584977122 : Closed e1211584977122 ∧ code e1211584977122 = 5609631488226 := by decide
theorem cert_e1211584977122 : check e1211584977122 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211584977134 : Closed e1211584977134 ∧ code e1211584977134 = 5609631488238 := by decide
theorem cert_e1211584977134 : check e1211584977134 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211584977142 : Closed e1211584977142 ∧ code e1211584977142 = 5609631488246 := by decide
theorem cert_e1211584977142 : check e1211584977142 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211584977334 : Closed e1211584977334 ∧ code e1211584977334 = 5609631488438 := by decide
theorem cert_e1211584977334 : check e1211584977334 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211584977366 : Closed e1211584977366 ∧ code e1211584977366 = 5609631488470 := by decide
theorem cert_e1211584977366 : check e1211584977366 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211584977370 : Closed e1211584977370 ∧ code e1211584977370 = 5609631488474 := by decide
theorem cert_e1211584977370 : check e1211584977370 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584977526 : Closed e1211584977526 ∧ code e1211584977526 = 5609631488630 := by decide
theorem cert_e1211584977526 : check e1211584977526 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584977670 : Closed e1211584977670 ∧ code e1211584977670 = 5609631488774 := by decide
theorem cert_e1211584977670 : check e1211584977670 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211584977694 : Closed e1211584977694 ∧ code e1211584977694 = 5609631488798 := by decide
theorem cert_e1211584977694 : check e1211584977694 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584977718 : Closed e1211584977718 ∧ code e1211584977718 = 5609631488822 := by decide
theorem cert_e1211584977718 : check e1211584977718 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584977722 : Closed e1211584977722 ∧ code e1211584977722 = 5609631488826 := by decide
theorem cert_e1211584977722 : check e1211584977722 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211584977806 : Closed e1211584977806 ∧ code e1211584977806 = 5609631488910 := by decide
theorem cert_e1211584977806 : check e1211584977806 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584977946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211584977946 : Closed e1211584977946 ∧ code e1211584977946 = 5609631489050 := by decide
theorem cert_e1211584977946 : check e1211584977946 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211584977990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211584977990 : Closed e1211584977990 ∧ code e1211584977990 = 5609631489094 := by decide
theorem cert_e1211584977990 : check e1211584977990 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211584978018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211584978018 : Closed e1211584978018 ∧ code e1211584978018 = 5609631489122 := by decide
theorem cert_e1211584978018 : check e1211584978018 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211584978030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211584978030 : Closed e1211584978030 ∧ code e1211584978030 = 5609631489134 := by decide
def e1211584978042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211584978042 : Closed e1211584978042 ∧ code e1211584978042 = 5609631489146 := by decide
def e1211584978134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211584978134 : Closed e1211584978134 ∧ code e1211584978134 = 5609631489238 := by decide
def e1211584978138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211584978138 : Closed e1211584978138 ∧ code e1211584978138 = 5609631489242 := by decide
def e1211584978154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211584978154 : Closed e1211584978154 ∧ code e1211584978154 = 5609631489258 := by decide
def e1211584978182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584978182 : Closed e1211584978182 ∧ code e1211584978182 = 5609631489286 := by decide
theorem cert_e1211584978182 : check e1211584978182 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584978206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211584978206 : Closed e1211584978206 ∧ code e1211584978206 = 5609631489310 := by decide
def e1211584978230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584978230 : Closed e1211584978230 ∧ code e1211584978230 = 5609631489334 := by decide
theorem cert_e1211584978230 : check e1211584978230 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584978234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584978234 : Closed e1211584978234 ∧ code e1211584978234 = 5609631489338 := by decide
theorem cert_e1211584978234 : check e1211584978234 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584978330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584978330 : Closed e1211584978330 ∧ code e1211584978330 = 5609631489434 := by decide
private def t_e1211584978330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584978330 : ¬ IsSelfInterpreter e1211584978330 :=
  wSource (t := t_e1211584978330) (replay_sound (ps := []) (t := e1211584978330) (by decide)) (by decide)
def e1211584978374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211584978374 : Closed e1211584978374 ∧ code e1211584978374 = 5609631489478 := by decide
private def t_e1211584978374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem cert_e1211584978374 : ¬ IsSelfInterpreter e1211584978374 :=
  wSource (t := t_e1211584978374) (replay_sound (ps := []) (t := e1211584978374) (by decide)) (by decide)
def e1211584978486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211584978486 : Closed e1211584978486 ∧ code e1211584978486 = 5609631489590 := by decide
theorem cert_e1211584978486 : check e1211584978486 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584978490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211584978490 : Closed e1211584978490 ∧ code e1211584978490 = 5609631489594 := by decide
def e1211584978574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211584978574 : Closed e1211584978574 ∧ code e1211584978574 = 5609631489678 := by decide
theorem cert_e1211584978574 : check e1211584978574 [[],[],[],[],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584978630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211584978630 : Closed e1211584978630 ∧ code e1211584978630 = 5609631489734 := by decide
private def t_e1211584978630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem cert_e1211584978630 : ¬ IsSelfInterpreter e1211584978630 :=
  wSource (t := t_e1211584978630) (replay_sound (ps := []) (t := e1211584978630) (by decide)) (by decide)
def e1211584979006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211584979006 : Closed e1211584979006 ∧ code e1211584979006 = 5609631490110 := by decide
theorem cert_e1211584979006 : check e1211584979006 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584979426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211584979426 : Closed e1211584979426 ∧ code e1211584979426 = 5609631490530 := by decide
theorem cert_e1211584979426 : check e1211584979426 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584979438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211584979438 : Closed e1211584979438 ∧ code e1211584979438 = 5609631490542 := by decide
theorem cert_e1211584979438 : check e1211584979438 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211584980406 : Closed e1211584980406 ∧ code e1211584980406 = 5609631491510 := by decide
theorem cert_e1211584980406 : check e1211584980406 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211584980438 : Closed e1211584980438 ∧ code e1211584980438 = 5609631491542 := by decide
theorem cert_e1211584980438 : check e1211584980438 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211584980442 : Closed e1211584980442 ∧ code e1211584980442 = 5609631491546 := by decide
theorem cert_e1211584980442 : check e1211584980442 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211584980598 : Closed e1211584980598 ∧ code e1211584980598 = 5609631491702 := by decide
theorem cert_e1211584980598 : check e1211584980598 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584980742 : Closed e1211584980742 ∧ code e1211584980742 = 5609631491846 := by decide
theorem cert_e1211584980742 : check e1211584980742 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211584980766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211584980766 : Closed e1211584980766 ∧ code e1211584980766 = 5609631491870 := by decide
theorem cert_e1211584980766 : check e1211584980766 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584980790 : Closed e1211584980790 ∧ code e1211584980790 = 5609631491894 := by decide
theorem cert_e1211584980790 : check e1211584980790 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584980794 : Closed e1211584980794 ∧ code e1211584980794 = 5609631491898 := by decide
theorem cert_e1211584980794 : check e1211584980794 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584980878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211584980878 : Closed e1211584980878 ∧ code e1211584980878 = 5609631491982 := by decide
theorem cert_e1211584980878 : check e1211584980878 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211584983070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211584983070 : Closed e1211584983070 ∧ code e1211584983070 = 5609631494174 := by decide
private def t_e1211584983070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))))))))
theorem cert_e1211584983070 : ¬ IsSelfInterpreter e1211584983070 :=
  wSource (t := t_e1211584983070) (replay_sound (ps := []) (t := e1211584983070) (by decide)) (by decide)
def e1211584983266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211584983266 : Closed e1211584983266 ∧ code e1211584983266 = 5609631494370 := by decide
private def t_e1211584983266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem cert_e1211584983266 : ¬ IsSelfInterpreter e1211584983266 :=
  wSource (t := t_e1211584983266) (replay_sound (ps := []) (t := e1211584983266) (by decide)) (by decide)
def e1211584983278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211584983278 : Closed e1211584983278 ∧ code e1211584983278 = 5609631494382 := by decide
private def t_e1211584983278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e1211584983278 : ¬ IsSelfInterpreter e1211584983278 :=
  wSource (t := t_e1211584983278) (replay_sound (ps := []) (t := e1211584983278) (by decide)) (by decide)
def e1211584983286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211584983286 : Closed e1211584983286 ∧ code e1211584983286 = 5609631494390 := by decide
private def t_e1211584983286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e1211584983286 : ¬ IsSelfInterpreter e1211584983286 :=
  wSource (t := t_e1211584983286) (replay_sound (ps := []) (t := e1211584983286) (by decide)) (by decide)
def e1211584983766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211584983766 : Closed e1211584983766 ∧ code e1211584983766 = 5609631494870 := by decide
private def t_e1211584983766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1211584983766 : ¬ IsSelfInterpreter e1211584983766 :=
  wSource (t := t_e1211584983766) (replay_sound (ps := []) (t := e1211584983766) (by decide)) (by decide)
def e1211584983770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211584983770 : Closed e1211584983770 ∧ code e1211584983770 = 5609631494874 := by decide
private def t_e1211584983770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e1211584983770 : ¬ IsSelfInterpreter e1211584983770 :=
  wSource (t := t_e1211584983770) (replay_sound (ps := []) (t := e1211584983770) (by decide)) (by decide)
def e1211584983786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211584983786 : Closed e1211584983786 ∧ code e1211584983786 = 5609631494890 := by decide
private def t_e1211584983786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e1211584983786 : ¬ IsSelfInterpreter e1211584983786 :=
  wSource (t := t_e1211584983786) (replay_sound (ps := []) (t := e1211584983786) (by decide)) (by decide)
def e1211584983814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584983814 : Closed e1211584983814 ∧ code e1211584983814 = 5609631494918 := by decide
private def t_e1211584983814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem cert_e1211584983814 : ¬ IsSelfInterpreter e1211584983814 :=
  wSource (t := t_e1211584983814) (replay_sound (ps := []) (t := e1211584983814) (by decide)) (by decide)
def e1211584983838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211584983838 : Closed e1211584983838 ∧ code e1211584983838 = 5609631494942 := by decide
private def t_e1211584983838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e1211584983838 : ¬ IsSelfInterpreter e1211584983838 :=
  wSource (t := t_e1211584983838) (replay_sound (ps := []) (t := e1211584983838) (by decide)) (by decide)
def e1211584983862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584983862 : Closed e1211584983862 ∧ code e1211584983862 = 5609631494966 := by decide
private def t_e1211584983862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211584983862 : ¬ IsSelfInterpreter e1211584983862 :=
  wSource (t := t_e1211584983862) (replay_sound (ps := []) (t := e1211584983862) (by decide)) (by decide)
def e1211584983866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584983866 : Closed e1211584983866 ∧ code e1211584983866 = 5609631494970 := by decide
private def t_e1211584983866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211584983866 : ¬ IsSelfInterpreter e1211584983866 :=
  wSource (t := t_e1211584983866) (replay_sound (ps := []) (t := e1211584983866) (by decide)) (by decide)
def e1211584983962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211584983962 : Closed e1211584983962 ∧ code e1211584983962 = 5609631495066 := by decide
private def t_e1211584983962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211584983962 : ¬ IsSelfInterpreter e1211584983962 :=
  wSource (t := t_e1211584983962) (replay_sound (ps := []) (t := e1211584983962) (by decide)) (by decide)
def e1211584984006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211584984006 : Closed e1211584984006 ∧ code e1211584984006 = 5609631495110 := by decide
private def t_e1211584984006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e1211584984006 : ¬ IsSelfInterpreter e1211584984006 :=
  wSource (t := t_e1211584984006) (replay_sound (ps := []) (t := e1211584984006) (by decide)) (by decide)
def e1211584985486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211584985486 : Closed e1211584985486 ∧ code e1211584985486 = 5609631496590 := by decide
private def t_e1211584985486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e1211584985486 : ¬ IsSelfInterpreter e1211584985486 :=
  wSource (t := t_e1211584985486) (replay_sound (ps := []) (t := e1211584985486) (by decide)) (by decide)
def e1211584985542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211584985542 : Closed e1211584985542 ∧ code e1211584985542 = 5609631496646 := by decide
private def t_e1211584985542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e1211584985542 : ¬ IsSelfInterpreter e1211584985542 :=
  wSource (t := t_e1211584985542) (replay_sound (ps := []) (t := e1211584985542) (by decide)) (by decide)
def e1211585026286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211585026286 : Closed e1211585026286 ∧ code e1211585026286 = 5609631537390 := by decide
theorem cert_e1211585026286 : check e1211585026286 [[],[],[],[]] .chain = true := by decide
def e1211585026294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211585026294 : Closed e1211585026294 ∧ code e1211585026294 = 5609631537398 := by decide
theorem cert_e1211585026294 : check e1211585026294 [[],[],[],[]] .chain = true := by decide
def e1211585026846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211585026846 : Closed e1211585026846 ∧ code e1211585026846 = 5609631537950 := by decide
theorem cert_e1211585026846 : check e1211585026846 [[],[],[],[]] .chain = true := by decide
def e1211585026958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211585026958 : Closed e1211585026958 ∧ code e1211585026958 = 5609631538062 := by decide
theorem cert_e1211585026958 : check e1211585026958 [[],[],[],[]] .chain = true := by decide
def e1211585027182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211585027182 : Closed e1211585027182 ∧ code e1211585027182 = 5609631538286 := by decide
theorem cert_e1211585027182 : check e1211585027182 [[],[],[],[]] .chain = true := by decide
def e1211585027194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211585027194 : Closed e1211585027194 ∧ code e1211585027194 = 5609631538298 := by decide
theorem cert_e1211585027194 : check e1211585027194 [[],[],[],[]] .chain = true := by decide
def e1211585027358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211585027358 : Closed e1211585027358 ∧ code e1211585027358 = 5609631538462 := by decide
theorem cert_e1211585027358 : check e1211585027358 [[],[],[],[]] .chain = true := by decide
def e1211585027526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211585027526 : Closed e1211585027526 ∧ code e1211585027526 = 5609631538630 := by decide
theorem cert_e1211585027526 : check e1211585027526 [[],[],[],[]] .chain = true := by decide
def e1211585027550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211585027550 : Closed e1211585027550 ∧ code e1211585027550 = 5609631538654 := by decide
theorem cert_e1211585027550 : check e1211585027550 [[],[],[],[]] .sourceHead = true := by decide
def e1211585027566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211585027566 : Closed e1211585027566 ∧ code e1211585027566 = 5609631538670 := by decide
theorem cert_e1211585027566 : check e1211585027566 [[],[],[],[]] .sourceHead = true := by decide
def e1211585027638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211585027638 : Closed e1211585027638 ∧ code e1211585027638 = 5609631538742 := by decide
theorem cert_e1211585027638 : check e1211585027638 [[],[],[],[]] .chain = true := by decide
def e1211585027642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211585027642 : Closed e1211585027642 ∧ code e1211585027642 = 5609631538746 := by decide
theorem cert_e1211585027642 : check e1211585027642 [[],[],[],[]] .chain = true := by decide
def e1211585027726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211585027726 : Closed e1211585027726 ∧ code e1211585027726 = 5609631538830 := by decide
theorem cert_e1211585027726 : check e1211585027726 [[],[],[],[]] .chain = true := by decide
def e1211585027782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211585027782 : Closed e1211585027782 ∧ code e1211585027782 = 5609631538886 := by decide
theorem cert_e1211585027782 : check e1211585027782 [[],[],[],[]] .chain = true := by decide
def e1211585027806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211585027806 : Closed e1211585027806 ∧ code e1211585027806 = 5609631538910 := by decide
theorem cert_e1211585027806 : check e1211585027806 [[],[],[],[]] .sourceHead = true := by decide
def e1211585027830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211585027830 : Closed e1211585027830 ∧ code e1211585027830 = 5609631538934 := by decide
theorem cert_e1211585027830 : check e1211585027830 [[],[],[],[]] .sourceHead = true := by decide
def e1211585027950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211585027950 : Closed e1211585027950 ∧ code e1211585027950 = 5609631539054 := by decide
theorem cert_e1211585027950 : check e1211585027950 [[],[],[],[]] .sourceHead = true := by decide
def e1211585027958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211585027958 : Closed e1211585027958 ∧ code e1211585027958 = 5609631539062 := by decide
theorem cert_e1211585027958 : check e1211585027958 [[],[],[],[]] .sourceHead = true := by decide
def e1211585029918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211585029918 : Closed e1211585029918 ∧ code e1211585029918 = 5609631541022 := by decide
theorem cert_e1211585029918 : check e1211585029918 [[],[],[],[]] .chain = true := by decide
def e1211585030030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211585030030 : Closed e1211585030030 ∧ code e1211585030030 = 5609631541134 := by decide
theorem cert_e1211585030030 : check e1211585030030 [[],[],[],[]] .chain = true := by decide
def e1211585032990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211585032990 : Closed e1211585032990 ∧ code e1211585032990 = 5609631544094 := by decide
theorem cert_e1211585032990 : check e1211585032990 [[],[],[],[]] .chain = true := by decide
def e1211585033158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211585033158 : Closed e1211585033158 ∧ code e1211585033158 = 5609631544262 := by decide
theorem cert_e1211585033158 : check e1211585033158 [[],[],[],[]] .chain = true := by decide
def e1211585033182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211585033182 : Closed e1211585033182 ∧ code e1211585033182 = 5609631544286 := by decide
theorem cert_e1211585033182 : check e1211585033182 [[],[],[],[]] .sourceHead = true := by decide
def e1211585033198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211585033198 : Closed e1211585033198 ∧ code e1211585033198 = 5609631544302 := by decide
theorem cert_e1211585033198 : check e1211585033198 [[],[],[],[]] .sourceHead = true := by decide
def e1211585034638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211585034638 : Closed e1211585034638 ∧ code e1211585034638 = 5609631545742 := by decide
theorem cert_e1211585034638 : check e1211585034638 [[],[],[],[]] .chain = true := by decide
def e1211585034694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211585034694 : Closed e1211585034694 ∧ code e1211585034694 = 5609631545798 := by decide
theorem cert_e1211585034694 : check e1211585034694 [[],[],[],[]] .chain = true := by decide
def e1211585034718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211585034718 : Closed e1211585034718 ∧ code e1211585034718 = 5609631545822 := by decide
theorem cert_e1211585034718 : check e1211585034718 [[],[],[],[]] .sourceHead = true := by decide
def e1211585034742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211585034742 : Closed e1211585034742 ∧ code e1211585034742 = 5609631545846 := by decide
theorem cert_e1211585034742 : check e1211585034742 [[],[],[],[]] .sourceHead = true := by decide
def e1211585035502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585035502 : Closed e1211585035502 ∧ code e1211585035502 = 5609631546606 := by decide
theorem cert_e1211585035502 : check e1211585035502 [[],[],[],[]] .sourceHead = true := by decide
def e1211585035510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585035510 : Closed e1211585035510 ∧ code e1211585035510 = 5609631546614 := by decide
theorem cert_e1211585035510 : check e1211585035510 [[],[],[],[]] .sourceHead = true := by decide
def e1211585092462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211585092462 : Closed e1211585092462 ∧ code e1211585092462 = 5609631603566 := by decide
theorem cert_e1211585092462 : check e1211585092462 [[],[],[],[]] .sourceHead = true := by decide
def e1211585092470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211585092470 : Closed e1211585092470 ∧ code e1211585092470 = 5609631603574 := by decide
theorem cert_e1211585092470 : check e1211585092470 [[],[],[],[]] .sourceHead = true := by decide
def e1211585092534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211585092534 : Closed e1211585092534 ∧ code e1211585092534 = 5609631603638 := by decide
theorem cert_e1211585092534 : check e1211585092534 [[],[],[],[]] .sourceHead = true := by decide
def e1211585092974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211585092974 : Closed e1211585092974 ∧ code e1211585092974 = 5609631604078 := by decide
theorem cert_e1211585092974 : check e1211585092974 [[],[],[],[]] .sourceHead = true := by decide
def e1211585092982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211585092982 : Closed e1211585092982 ∧ code e1211585092982 = 5609631604086 := by decide
theorem cert_e1211585092982 : check e1211585092982 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211585093038 : Closed e1211585093038 ∧ code e1211585093038 = 5609631604142 := by decide
theorem cert_e1211585093038 : check e1211585093038 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211585093050 : Closed e1211585093050 ∧ code e1211585093050 = 5609631604154 := by decide
theorem cert_e1211585093050 : check e1211585093050 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211585093078 : Closed e1211585093078 ∧ code e1211585093078 = 5609631604182 := by decide
theorem cert_e1211585093078 : check e1211585093078 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211585093082 : Closed e1211585093082 ∧ code e1211585093082 = 5609631604186 := by decide
theorem cert_e1211585093082 : check e1211585093082 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211585093302 : Closed e1211585093302 ∧ code e1211585093302 = 5609631604406 := by decide
theorem cert_e1211585093302 : check e1211585093302 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211585093334 : Closed e1211585093334 ∧ code e1211585093334 = 5609631604438 := by decide
theorem cert_e1211585093334 : check e1211585093334 [[],[],[],[]] .sourceHead = true := by decide
def e1211585093338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211585093338 : Closed e1211585093338 ∧ code e1211585093338 = 5609631604442 := by decide
theorem cert_e1211585093338 : check e1211585093338 [[],[],[],[]] .sourceHead = true := by decide
def e1211585095534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211585095534 : Closed e1211585095534 ∧ code e1211585095534 = 5609631606638 := by decide
theorem cert_e1211585095534 : check e1211585095534 [[],[],[],[]] .sourceHead = true := by decide
def e1211585095542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211585095542 : Closed e1211585095542 ∧ code e1211585095542 = 5609631606646 := by decide
theorem cert_e1211585095542 : check e1211585095542 [[],[],[],[]] .sourceHead = true := by decide
def e1211585095606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211585095606 : Closed e1211585095606 ∧ code e1211585095606 = 5609631606710 := by decide
theorem cert_e1211585095606 : check e1211585095606 [[],[],[],[]] .sourceHead = true := by decide
def e1211585096942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211585096942 : Closed e1211585096942 ∧ code e1211585096942 = 5609631608046 := by decide
theorem cert_e1211585096942 : check e1211585096942 [[],[],[],[]] .sourceHead = true := by decide
def e1211585096950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211585096950 : Closed e1211585096950 ∧ code e1211585096950 = 5609631608054 := by decide
theorem cert_e1211585096950 : check e1211585096950 [[],[],[],[]] .sourceHead = true := by decide
def e1211585097334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211585097334 : Closed e1211585097334 ∧ code e1211585097334 = 5609631608438 := by decide
theorem cert_e1211585097334 : check e1211585097334 [[],[],[],[]] .sourceHead = true := by decide
def e1211585097838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211585097838 : Closed e1211585097838 ∧ code e1211585097838 = 5609631608942 := by decide
theorem cert_e1211585097838 : check e1211585097838 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211585098014 : Closed e1211585098014 ∧ code e1211585098014 = 5609631609118 := by decide
theorem cert_e1211585098014 : check e1211585098014 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211585098210 : Closed e1211585098210 ∧ code e1211585098210 = 5609631609314 := by decide
theorem cert_e1211585098210 : check e1211585098210 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211585098222 : Closed e1211585098222 ∧ code e1211585098222 = 5609631609326 := by decide
theorem cert_e1211585098222 : check e1211585098222 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211585098606 : Closed e1211585098606 ∧ code e1211585098606 = 5609631609710 := by decide
theorem cert_e1211585098606 : check e1211585098606 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211585098614 : Closed e1211585098614 ∧ code e1211585098614 = 5609631609718 := by decide
theorem cert_e1211585098614 : check e1211585098614 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211585098670 : Closed e1211585098670 ∧ code e1211585098670 = 5609631609774 := by decide
theorem cert_e1211585098670 : check e1211585098670 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211585098682 : Closed e1211585098682 ∧ code e1211585098682 = 5609631609786 := by decide
theorem cert_e1211585098682 : check e1211585098682 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211585098710 : Closed e1211585098710 ∧ code e1211585098710 = 5609631609814 := by decide
theorem cert_e1211585098710 : check e1211585098710 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211585098714 : Closed e1211585098714 ∧ code e1211585098714 = 5609631609818 := by decide
theorem cert_e1211585098714 : check e1211585098714 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211585098990 : Closed e1211585098990 ∧ code e1211585098990 = 5609631610094 := by decide
theorem cert_e1211585098990 : check e1211585098990 [[],[],[],[]] .sourceHead = true := by decide
def e1211585098998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211585098998 : Closed e1211585098998 ∧ code e1211585098998 = 5609631610102 := by decide
theorem cert_e1211585098998 : check e1211585098998 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211585099374 : Closed e1211585099374 ∧ code e1211585099374 = 5609631610478 := by decide
theorem cert_e1211585099374 : check e1211585099374 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211585099386 : Closed e1211585099386 ∧ code e1211585099386 = 5609631610490 := by decide
theorem cert_e1211585099386 : check e1211585099386 [[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor42
