import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203441626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203441626 : Closed e1211203441626 ∧ code e1211203441626 = 5609249952730 := by decide
theorem cert_e1211203441626 : check e1211203441626 [[],[]] .chain = true := by decide
def e1211203441902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203441902 : Closed e1211203441902 ∧ code e1211203441902 = 5609249953006 := by decide
theorem cert_e1211203441902 : check e1211203441902 [[],[]] .chain = true := by decide
def e1211203441910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203441910 : Closed e1211203441910 ∧ code e1211203441910 = 5609249953014 := by decide
theorem cert_e1211203441910 : check e1211203441910 [[],[]] .chain = true := by decide
def e1211203442286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203442286 : Closed e1211203442286 ∧ code e1211203442286 = 5609249953390 := by decide
theorem cert_e1211203442286 : check e1211203442286 [[],[]] .chain = true := by decide
def e1211203442298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203442298 : Closed e1211203442298 ∧ code e1211203442298 = 5609249953402 := by decide
theorem cert_e1211203442298 : check e1211203442298 [[],[]] .chain = true := by decide
def e1211203442438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203442438 : Closed e1211203442438 ∧ code e1211203442438 = 5609249953542 := by decide
theorem cert_e1211203442438 : check e1211203442438 [[],[]] .chain = true := by decide
def e1211203442462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203442462 : Closed e1211203442462 ∧ code e1211203442462 = 5609249953566 := by decide
theorem cert_e1211203442462 : check e1211203442462 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203442486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203442486 : Closed e1211203442486 ∧ code e1211203442486 = 5609249953590 := by decide
theorem cert_e1211203442486 : check e1211203442486 [[],[]] .chain = true := by decide
def e1211203442490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203442490 : Closed e1211203442490 ∧ code e1211203442490 = 5609249953594 := by decide
theorem cert_e1211203442490 : check e1211203442490 [[],[]] .chain = true := by decide
def e1211203442734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203442734 : Closed e1211203442734 ∧ code e1211203442734 = 5609249953838 := by decide
theorem cert_e1211203442734 : check e1211203442734 [[],[]] .chain = true := by decide
def e1211203442926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203442926 : Closed e1211203442926 ∧ code e1211203442926 = 5609249954030 := by decide
theorem cert_e1211203442926 : check e1211203442926 [[],[]] .chain = true := by decide
def e1211203442934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203442934 : Closed e1211203442934 ∧ code e1211203442934 = 5609249954038 := by decide
theorem cert_e1211203442934 : check e1211203442934 [[],[]] .chain = true := by decide
def e1211203443118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203443118 : Closed e1211203443118 ∧ code e1211203443118 = 5609249954222 := by decide
theorem cert_e1211203443118 : check e1211203443118 [[],[]] .chain = true := by decide
def e1211203443130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203443130 : Closed e1211203443130 ∧ code e1211203443130 = 5609249954234 := by decide
theorem cert_e1211203443130 : check e1211203443130 [[],[]] .chain = true := by decide
def e1211203443178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203443178 : Closed e1211203443178 ∧ code e1211203443178 = 5609249954282 := by decide
theorem cert_e1211203443178 : check e1211203443178 [[],[]] .chain = true := by decide
def e1211203443310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203443310 : Closed e1211203443310 ∧ code e1211203443310 = 5609249954414 := by decide
theorem cert_e1211203443310 : check e1211203443310 [[],[]] .chain = true := by decide
def e1211203443322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203443322 : Closed e1211203443322 ∧ code e1211203443322 = 5609249954426 := by decide
theorem cert_e1211203443322 : check e1211203443322 [[],[]] .chain = true := by decide
def e1211203443486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203443486 : Closed e1211203443486 ∧ code e1211203443486 = 5609249954590 := by decide
theorem cert_e1211203443486 : check e1211203443486 [[],[]] .chain = true := by decide
def e1211203443586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203443586 : Closed e1211203443586 ∧ code e1211203443586 = 5609249954690 := by decide
theorem cert_e1211203443586 : check e1211203443586 [[],[]] .chain = true := by decide
def e1211203443598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203443598 : Closed e1211203443598 ∧ code e1211203443598 = 5609249954702 := by decide
theorem cert_e1211203443598 : check e1211203443598 [[],[]] .chain = true := by decide
def e1211203443610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203443610 : Closed e1211203443610 ∧ code e1211203443610 = 5609249954714 := by decide
theorem cert_e1211203443610 : check e1211203443610 [[],[]] .chain = true := by decide
def e1211203443734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203443734 : Closed e1211203443734 ∧ code e1211203443734 = 5609249954838 := by decide
theorem cert_e1211203443734 : check e1211203443734 [[],[]] .chain = true := by decide
def e1211203443738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203443738 : Closed e1211203443738 ∧ code e1211203443738 = 5609249954842 := by decide
theorem cert_e1211203443738 : check e1211203443738 [[],[]] .chain = true := by decide
def e1211203443782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203443782 : Closed e1211203443782 ∧ code e1211203443782 = 5609249954886 := by decide
theorem cert_e1211203443782 : check e1211203443782 [[],[]] .chain = true := by decide
def e1211203443810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203443810 : Closed e1211203443810 ∧ code e1211203443810 = 5609249954914 := by decide
theorem cert_e1211203443810 : check e1211203443810 [[],[]] .chain = true := by decide
def e1211203443822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203443822 : Closed e1211203443822 ∧ code e1211203443822 = 5609249954926 := by decide
theorem cert_e1211203443822 : check e1211203443822 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203443830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203443830 : Closed e1211203443830 ∧ code e1211203443830 = 5609249954934 := by decide
theorem cert_e1211203443830 : check e1211203443830 [[],[]] .chain = true := by decide
def e1211203443834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203443834 : Closed e1211203443834 ∧ code e1211203443834 = 5609249954938 := by decide
theorem cert_e1211203443834 : check e1211203443834 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203443926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203443926 : Closed e1211203443926 ∧ code e1211203443926 = 5609249955030 := by decide
theorem cert_e1211203443926 : check e1211203443926 [[],[]] .chain = true := by decide
def e1211203443930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203443930 : Closed e1211203443930 ∧ code e1211203443930 = 5609249955034 := by decide
theorem cert_e1211203443930 : check e1211203443930 [[],[]] .chain = true := by decide
def e1211203443946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203443946 : Closed e1211203443946 ∧ code e1211203443946 = 5609249955050 := by decide
theorem cert_e1211203443946 : check e1211203443946 [[],[]] .chain = true := by decide
def e1211203443974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203443974 : Closed e1211203443974 ∧ code e1211203443974 = 5609249955078 := by decide
theorem cert_e1211203443974 : check e1211203443974 [[],[]] .chain = true := by decide
def e1211203443998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203443998 : Closed e1211203443998 ∧ code e1211203443998 = 5609249955102 := by decide
theorem cert_e1211203443998 : check e1211203443998 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203444022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203444022 : Closed e1211203444022 ∧ code e1211203444022 = 5609249955126 := by decide
theorem cert_e1211203444022 : check e1211203444022 [[],[]] .chain = true := by decide
def e1211203444026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203444026 : Closed e1211203444026 ∧ code e1211203444026 = 5609249955130 := by decide
theorem cert_e1211203444026 : check e1211203444026 [[],[]] .chain = true := by decide
def e1211203444098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203444098 : Closed e1211203444098 ∧ code e1211203444098 = 5609249955202 := by decide
theorem cert_e1211203444098 : check e1211203444098 [[],[]] .chain = true := by decide
def e1211203444110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203444110 : Closed e1211203444110 ∧ code e1211203444110 = 5609249955214 := by decide
theorem cert_e1211203444110 : check e1211203444110 [[],[]] .chain = true := by decide
def e1211203444122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203444122 : Closed e1211203444122 ∧ code e1211203444122 = 5609249955226 := by decide
theorem cert_e1211203444122 : check e1211203444122 [[],[]] .chain = true := by decide
def e1211203444166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203444166 : Closed e1211203444166 ∧ code e1211203444166 = 5609249955270 := by decide
theorem cert_e1211203444166 : check e1211203444166 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203444918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 1))))))
theorem wire_e1211203444918 : Closed e1211203444918 ∧ code e1211203444918 = 5609249956022 := by decide
theorem cert_e1211203444918 : check e1211203444918 [[],[]] .chain = true := by decide
def e1211203444950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e1211203444950 : Closed e1211203444950 ∧ code e1211203444950 = 5609249956054 := by decide
theorem cert_e1211203444950 : check e1211203444950 [[],[]] .chain = true := by decide
def e1211203444954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e1211203444954 : Closed e1211203444954 ∧ code e1211203444954 = 5609249956058 := by decide
theorem cert_e1211203444954 : check e1211203444954 [[],[]] .chain = true := by decide
def e1211203445302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203445302 : Closed e1211203445302 ∧ code e1211203445302 = 5609249956406 := by decide
theorem cert_e1211203445302 : check e1211203445302 [[],[]] .chain = true := by decide
def e1211203445306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203445306 : Closed e1211203445306 ∧ code e1211203445306 = 5609249956410 := by decide
theorem cert_e1211203445306 : check e1211203445306 [[],[]] .chain = true := by decide
def e1211203445390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203445390 : Closed e1211203445390 ∧ code e1211203445390 = 5609249956494 := by decide
theorem cert_e1211203445390 : check e1211203445390 [[],[]] .chain = true := by decide
def e1211203445446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203445446 : Closed e1211203445446 ∧ code e1211203445446 = 5609249956550 := by decide
theorem cert_e1211203445446 : check e1211203445446 [[],[]] .chain = true := by decide
def e1211203445526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203445526 : Closed e1211203445526 ∧ code e1211203445526 = 5609249956630 := by decide
theorem cert_e1211203445526 : check e1211203445526 [[],[]] .chain = true := by decide
def e1211203445602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203445602 : Closed e1211203445602 ∧ code e1211203445602 = 5609249956706 := by decide
theorem cert_e1211203445602 : check e1211203445602 [[],[]] .chain = true := by decide
def e1211203445614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203445614 : Closed e1211203445614 ∧ code e1211203445614 = 5609249956718 := by decide
theorem cert_e1211203445614 : check e1211203445614 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203445622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203445622 : Closed e1211203445622 ∧ code e1211203445622 = 5609249956726 := by decide
theorem cert_e1211203445622 : check e1211203445622 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203445642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203445642 : Closed e1211203445642 ∧ code e1211203445642 = 5609249956746 := by decide
theorem cert_e1211203445642 : check e1211203445642 [[],[]] .chain = true := by decide
def e1211203445666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203445666 : Closed e1211203445666 ∧ code e1211203445666 = 5609249956770 := by decide
theorem cert_e1211203445666 : check e1211203445666 [[],[]] .chain = true := by decide
def e1211203445678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203445678 : Closed e1211203445678 ∧ code e1211203445678 = 5609249956782 := by decide
theorem cert_e1211203445678 : check e1211203445678 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203445686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e1211203445686 : Closed e1211203445686 ∧ code e1211203445686 = 5609249956790 := by decide
theorem cert_e1211203445686 : check e1211203445686 [[],[]] .chain = true := by decide
def e1211203445690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203445690 : Closed e1211203445690 ∧ code e1211203445690 = 5609249956794 := by decide
theorem cert_e1211203445690 : check e1211203445690 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203445718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203445718 : Closed e1211203445718 ∧ code e1211203445718 = 5609249956822 := by decide
theorem cert_e1211203445718 : check e1211203445718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203445722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203445722 : Closed e1211203445722 ∧ code e1211203445722 = 5609249956826 := by decide
theorem cert_e1211203445722 : check e1211203445722 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203446454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e1211203446454 : Closed e1211203446454 ∧ code e1211203446454 = 5609249957558 := by decide
theorem cert_e1211203446454 : check e1211203446454 [[],[]] .chain = true := by decide
def e1211203446486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203446486 : Closed e1211203446486 ∧ code e1211203446486 = 5609249957590 := by decide
theorem cert_e1211203446486 : check e1211203446486 [[],[]] .chain = true := by decide
def e1211203446490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203446490 : Closed e1211203446490 ∧ code e1211203446490 = 5609249957594 := by decide
theorem cert_e1211203446490 : check e1211203446490 [[],[]] .chain = true := by decide
def e1211203446614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203446614 : Closed e1211203446614 ∧ code e1211203446614 = 5609249957718 := by decide
theorem cert_e1211203446614 : check e1211203446614 [[],[]] .chain = true := by decide
def e1211203446618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203446618 : Closed e1211203446618 ∧ code e1211203446618 = 5609249957722 := by decide
theorem cert_e1211203446618 : check e1211203446618 [[],[]] .chain = true := by decide
def e1211203446634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203446634 : Closed e1211203446634 ∧ code e1211203446634 = 5609249957738 := by decide
theorem cert_e1211203446634 : check e1211203446634 [[],[]] .chain = true := by decide
def e1211203446838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203446838 : Closed e1211203446838 ∧ code e1211203446838 = 5609249957942 := by decide
theorem cert_e1211203446838 : check e1211203446838 [[],[]] .chain = true := by decide
def e1211203446926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203446926 : Closed e1211203446926 ∧ code e1211203446926 = 5609249958030 := by decide
theorem cert_e1211203446926 : check e1211203446926 [[],[]] .chain = true := by decide
def e1211203447010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203447010 : Closed e1211203447010 ∧ code e1211203447010 = 5609249958114 := by decide
theorem cert_e1211203447010 : check e1211203447010 [[],[]] .chain = true := by decide
def e1211203447022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203447022 : Closed e1211203447022 ∧ code e1211203447022 = 5609249958126 := by decide
theorem cert_e1211203447022 : check e1211203447022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203447030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203447030 : Closed e1211203447030 ∧ code e1211203447030 = 5609249958134 := by decide
theorem cert_e1211203447030 : check e1211203447030 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203447222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203447222 : Closed e1211203447222 ∧ code e1211203447222 = 5609249958326 := by decide
theorem cert_e1211203447222 : check e1211203447222 [[],[]] .chain = true := by decide
def e1211203447254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203447254 : Closed e1211203447254 ∧ code e1211203447254 = 5609249958358 := by decide
theorem cert_e1211203447254 : check e1211203447254 [[],[]] .chain = true := by decide
def e1211203447258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203447258 : Closed e1211203447258 ∧ code e1211203447258 = 5609249958362 := by decide
theorem cert_e1211203447258 : check e1211203447258 [[],[]] .chain = true := by decide
def e1211203447414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203447414 : Closed e1211203447414 ∧ code e1211203447414 = 5609249958518 := by decide
theorem cert_e1211203447414 : check e1211203447414 [[],[]] .chain = true := by decide
def e1211203447558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203447558 : Closed e1211203447558 ∧ code e1211203447558 = 5609249958662 := by decide
theorem cert_e1211203447558 : check e1211203447558 [[],[]] .chain = true := by decide
def e1211203447582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203447582 : Closed e1211203447582 ∧ code e1211203447582 = 5609249958686 := by decide
theorem cert_e1211203447582 : check e1211203447582 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203447606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203447606 : Closed e1211203447606 ∧ code e1211203447606 = 5609249958710 := by decide
theorem cert_e1211203447606 : check e1211203447606 [[],[]] .chain = true := by decide
def e1211203447610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203447610 : Closed e1211203447610 ∧ code e1211203447610 = 5609249958714 := by decide
theorem cert_e1211203447610 : check e1211203447610 [[],[]] .chain = true := by decide
def e1211203447694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203447694 : Closed e1211203447694 ∧ code e1211203447694 = 5609249958798 := by decide
theorem cert_e1211203447694 : check e1211203447694 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203447830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203447830 : Closed e1211203447830 ∧ code e1211203447830 = 5609249958934 := by decide
theorem cert_e1211203447830 : check e1211203447830 [[],[]] .chain = true := by decide
def e1211203447834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203447834 : Closed e1211203447834 ∧ code e1211203447834 = 5609249958938 := by decide
theorem cert_e1211203447834 : check e1211203447834 [[],[]] .chain = true := by decide
def e1211203447878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203447878 : Closed e1211203447878 ∧ code e1211203447878 = 5609249958982 := by decide
theorem cert_e1211203447878 : check e1211203447878 [[],[]] .chain = true := by decide
def e1211203447906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203447906 : Closed e1211203447906 ∧ code e1211203447906 = 5609249959010 := by decide
theorem cert_e1211203447906 : check e1211203447906 [[],[]] .chain = true := by decide
def e1211203447918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203447918 : Closed e1211203447918 ∧ code e1211203447918 = 5609249959022 := by decide
theorem cert_e1211203447918 : check e1211203447918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203447926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203447926 : Closed e1211203447926 ∧ code e1211203447926 = 5609249959030 := by decide
theorem cert_e1211203447926 : check e1211203447926 [[],[]] .chain = true := by decide
def e1211203447930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203447930 : Closed e1211203447930 ∧ code e1211203447930 = 5609249959034 := by decide
theorem cert_e1211203447930 : check e1211203447930 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203448022 : Closed e1211203448022 ∧ code e1211203448022 = 5609249959126 := by decide
theorem cert_e1211203448022 : check e1211203448022 [[],[]] .chain = true := by decide
def e1211203448026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203448026 : Closed e1211203448026 ∧ code e1211203448026 = 5609249959130 := by decide
theorem cert_e1211203448026 : check e1211203448026 [[],[]] .chain = true := by decide
def e1211203448042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203448042 : Closed e1211203448042 ∧ code e1211203448042 = 5609249959146 := by decide
theorem cert_e1211203448042 : check e1211203448042 [[],[]] .chain = true := by decide
def e1211203448070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203448070 : Closed e1211203448070 ∧ code e1211203448070 = 5609249959174 := by decide
theorem cert_e1211203448070 : check e1211203448070 [[],[]] .chain = true := by decide
def e1211203448094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203448094 : Closed e1211203448094 ∧ code e1211203448094 = 5609249959198 := by decide
theorem cert_e1211203448094 : check e1211203448094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203448118 : Closed e1211203448118 ∧ code e1211203448118 = 5609249959222 := by decide
theorem cert_e1211203448118 : check e1211203448118 [[],[]] .chain = true := by decide
def e1211203448122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203448122 : Closed e1211203448122 ∧ code e1211203448122 = 5609249959226 := by decide
theorem cert_e1211203448122 : check e1211203448122 [[],[]] .chain = true := by decide
def e1211203448194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203448194 : Closed e1211203448194 ∧ code e1211203448194 = 5609249959298 := by decide
theorem cert_e1211203448194 : check e1211203448194 [[],[]] .chain = true := by decide
def e1211203448206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203448206 : Closed e1211203448206 ∧ code e1211203448206 = 5609249959310 := by decide
theorem cert_e1211203448206 : check e1211203448206 [[],[]] .chain = true := by decide
def e1211203448218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203448218 : Closed e1211203448218 ∧ code e1211203448218 = 5609249959322 := by decide
theorem cert_e1211203448218 : check e1211203448218 [[],[]] .chain = true := by decide
def e1211203448262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203448262 : Closed e1211203448262 ∧ code e1211203448262 = 5609249959366 := by decide
theorem cert_e1211203448262 : check e1211203448262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203448374 : Closed e1211203448374 ∧ code e1211203448374 = 5609249959478 := by decide
theorem cert_e1211203448374 : check e1211203448374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203448378 : Closed e1211203448378 ∧ code e1211203448378 = 5609249959482 := by decide
theorem cert_e1211203448378 : check e1211203448378 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203448462 : Closed e1211203448462 ∧ code e1211203448462 = 5609249959566 := by decide
theorem cert_e1211203448462 : check e1211203448462 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203448518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203448518 : Closed e1211203448518 ∧ code e1211203448518 = 5609249959622 := by decide
theorem cert_e1211203448518 : check e1211203448518 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203453934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))) (.var 2))))))
theorem wire_e1211203453934 : Closed e1211203453934 ∧ code e1211203453934 = 5609249965038 := by decide
theorem cert_e1211203453934 : check e1211203453934 [[],[]] .chain = true := by decide
def e1211203453942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))) (.var 1))))))
theorem wire_e1211203453942 : Closed e1211203453942 ∧ code e1211203453942 = 5609249965046 := by decide
theorem cert_e1211203453942 : check e1211203453942 [[],[]] .chain = true := by decide
def e1211203456238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203456238 : Closed e1211203456238 ∧ code e1211203456238 = 5609249967342 := by decide
theorem cert_e1211203456238 : check e1211203456238 [[],[]] .chain = true := by decide
def e1211203456246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203456246 : Closed e1211203456246 ∧ code e1211203456246 = 5609249967350 := by decide
theorem cert_e1211203456246 : check e1211203456246 [[],[]] .chain = true := by decide
def e1211203456798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 3)))))))
theorem wire_e1211203456798 : Closed e1211203456798 ∧ code e1211203456798 = 5609249967902 := by decide
theorem cert_e1211203456798 : check e1211203456798 [[],[]] .chain = true := by decide
def e1211203456910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.lam (.var 2)))))))
theorem wire_e1211203456910 : Closed e1211203456910 ∧ code e1211203456910 = 5609249968014 := by decide
theorem cert_e1211203456910 : check e1211203456910 [[],[]] .chain = true := by decide
def e1211203460654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203460654 : Closed e1211203460654 ∧ code e1211203460654 = 5609249971758 := by decide
theorem cert_e1211203460654 : check e1211203460654 [[],[]] .chain = true := by decide
def e1211203460846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e1211203460846 : Closed e1211203460846 ∧ code e1211203460846 = 5609249971950 := by decide
theorem cert_e1211203460846 : check e1211203460846 [[],[]] .chain = true := by decide
def e1211203460854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e1211203460854 : Closed e1211203460854 ∧ code e1211203460854 = 5609249971958 := by decide
theorem cert_e1211203460854 : check e1211203460854 [[],[]] .chain = true := by decide
def e1211203460886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203460886 : Closed e1211203460886 ∧ code e1211203460886 = 5609249971990 := by decide
theorem cert_e1211203460886 : check e1211203460886 [[],[]] .chain = true := by decide
def e1211203460982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e1211203460982 : Closed e1211203460982 ∧ code e1211203460982 = 5609249972086 := by decide
theorem cert_e1211203460982 : check e1211203460982 [[],[]] .chain = true := by decide
def e1211203462942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203462942 : Closed e1211203462942 ∧ code e1211203462942 = 5609249974046 := by decide
theorem cert_e1211203462942 : check e1211203462942 [[],[]] .chain = true := by decide
def e1211203463054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203463054 : Closed e1211203463054 ∧ code e1211203463054 = 5609249974158 := by decide
theorem cert_e1211203463054 : check e1211203463054 [[],[]] .chain = true := by decide
def e1211203467326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 4))))))))
theorem wire_e1211203467326 : Closed e1211203467326 ∧ code e1211203467326 = 5609249978430 := by decide
theorem cert_e1211203467326 : check e1211203467326 [[],[]] .chain = true := by decide
def e1211203467746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203467746 : Closed e1211203467746 ∧ code e1211203467746 = 5609249978850 := by decide
theorem cert_e1211203467746 : check e1211203467746 [[],[]] .chain = true := by decide
def e1211203467758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203467758 : Closed e1211203467758 ∧ code e1211203467758 = 5609249978862 := by decide
theorem cert_e1211203467758 : check e1211203467758 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203468318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.lam (.var 3))))))))
theorem wire_e1211203468318 : Closed e1211203468318 ∧ code e1211203468318 = 5609249979422 := by decide
theorem cert_e1211203468318 : check e1211203468318 [[],[]] .chain = true := by decide
def e1211203468514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203468514 : Closed e1211203468514 ∧ code e1211203468514 = 5609249979618 := by decide
theorem cert_e1211203468514 : check e1211203468514 [[],[]] .chain = true := by decide
def e1211203468526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203468526 : Closed e1211203468526 ∧ code e1211203468526 = 5609249979630 := by decide
theorem cert_e1211203468526 : check e1211203468526 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203468534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203468534 : Closed e1211203468534 ∧ code e1211203468534 = 5609249979638 := by decide
theorem cert_e1211203468534 : check e1211203468534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203476334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1211203476334 : Closed e1211203476334 ∧ code e1211203476334 = 5609249987438 := by decide
theorem cert_e1211203476334 : check e1211203476334 [[],[]] .chain = true := by decide
def e1211203476342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1211203476342 : Closed e1211203476342 ∧ code e1211203476342 = 5609249987446 := by decide
theorem cert_e1211203476342 : check e1211203476342 [[],[]] .chain = true := by decide
def e1211203476406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1211203476406 : Closed e1211203476406 ∧ code e1211203476406 = 5609249987510 := by decide
theorem cert_e1211203476406 : check e1211203476406 [[],[]] .chain = true := by decide
def e1211203476846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211203476846 : Closed e1211203476846 ∧ code e1211203476846 = 5609249987950 := by decide
theorem cert_e1211203476846 : check e1211203476846 [[],[]] .chain = true := by decide
def e1211203476854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211203476854 : Closed e1211203476854 ∧ code e1211203476854 = 5609249987958 := by decide
theorem cert_e1211203476854 : check e1211203476854 [[],[]] .chain = true := by decide
def e1211203476910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211203476910 : Closed e1211203476910 ∧ code e1211203476910 = 5609249988014 := by decide
theorem cert_e1211203476910 : check e1211203476910 [[],[]] .chain = true := by decide
def e1211203476922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211203476922 : Closed e1211203476922 ∧ code e1211203476922 = 5609249988026 := by decide
theorem cert_e1211203476922 : check e1211203476922 [[],[]] .chain = true := by decide
def e1211203476950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211203476950 : Closed e1211203476950 ∧ code e1211203476950 = 5609249988054 := by decide
theorem cert_e1211203476950 : check e1211203476950 [[],[]] .chain = true := by decide
def e1211203476954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211203476954 : Closed e1211203476954 ∧ code e1211203476954 = 5609249988058 := by decide
theorem cert_e1211203476954 : check e1211203476954 [[],[]] .chain = true := by decide
def e1211203477174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211203477174 : Closed e1211203477174 ∧ code e1211203477174 = 5609249988278 := by decide
theorem cert_e1211203477174 : check e1211203477174 [[],[]] .chain = true := by decide
def e1211203477206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211203477206 : Closed e1211203477206 ∧ code e1211203477206 = 5609249988310 := by decide
theorem cert_e1211203477206 : check e1211203477206 [[],[]] .chain = true := by decide
def e1211203477210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211203477210 : Closed e1211203477210 ∧ code e1211203477210 = 5609249988314 := by decide
theorem cert_e1211203477210 : check e1211203477210 [[],[]] .chain = true := by decide
def e1211203479406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1211203479406 : Closed e1211203479406 ∧ code e1211203479406 = 5609249990510 := by decide
theorem cert_e1211203479406 : check e1211203479406 [[],[]] .chain = true := by decide
def e1211203479414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1211203479414 : Closed e1211203479414 ∧ code e1211203479414 = 5609249990518 := by decide
theorem cert_e1211203479414 : check e1211203479414 [[],[]] .chain = true := by decide
def e1211203479478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1211203479478 : Closed e1211203479478 ∧ code e1211203479478 = 5609249990582 := by decide
theorem cert_e1211203479478 : check e1211203479478 [[],[]] .chain = true := by decide
def e1211203480814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203480814 : Closed e1211203480814 ∧ code e1211203480814 = 5609249991918 := by decide
theorem cert_e1211203480814 : check e1211203480814 [[],[]] .chain = true := by decide
def e1211203480822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203480822 : Closed e1211203480822 ∧ code e1211203480822 = 5609249991926 := by decide
theorem cert_e1211203480822 : check e1211203480822 [[],[]] .chain = true := by decide
def e1211203481206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203481206 : Closed e1211203481206 ∧ code e1211203481206 = 5609249992310 := by decide
theorem cert_e1211203481206 : check e1211203481206 [[],[]] .chain = true := by decide
def e1211203481710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211203481710 : Closed e1211203481710 ∧ code e1211203481710 = 5609249992814 := by decide
theorem cert_e1211203481710 : check e1211203481710 [[],[]] .chain = true := by decide
def e1211203481886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211203481886 : Closed e1211203481886 ∧ code e1211203481886 = 5609249992990 := by decide
theorem cert_e1211203481886 : check e1211203481886 [[],[]] .chain = true := by decide
def e1211203482082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211203482082 : Closed e1211203482082 ∧ code e1211203482082 = 5609249993186 := by decide
theorem cert_e1211203482082 : check e1211203482082 [[],[]] .chain = true := by decide
def e1211203482094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211203482094 : Closed e1211203482094 ∧ code e1211203482094 = 5609249993198 := by decide
theorem cert_e1211203482094 : check e1211203482094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203482478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211203482478 : Closed e1211203482478 ∧ code e1211203482478 = 5609249993582 := by decide
theorem cert_e1211203482478 : check e1211203482478 [[],[]] .chain = true := by decide
def e1211203482486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211203482486 : Closed e1211203482486 ∧ code e1211203482486 = 5609249993590 := by decide
theorem cert_e1211203482486 : check e1211203482486 [[],[]] .chain = true := by decide
def e1211203482542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211203482542 : Closed e1211203482542 ∧ code e1211203482542 = 5609249993646 := by decide
theorem cert_e1211203482542 : check e1211203482542 [[],[]] .chain = true := by decide
def e1211203482554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211203482554 : Closed e1211203482554 ∧ code e1211203482554 = 5609249993658 := by decide
theorem cert_e1211203482554 : check e1211203482554 [[],[]] .chain = true := by decide
def e1211203482582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211203482582 : Closed e1211203482582 ∧ code e1211203482582 = 5609249993686 := by decide
theorem cert_e1211203482582 : check e1211203482582 [[],[]] .chain = true := by decide
def e1211203482586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211203482586 : Closed e1211203482586 ∧ code e1211203482586 = 5609249993690 := by decide
theorem cert_e1211203482586 : check e1211203482586 [[],[]] .chain = true := by decide
def e1211203482862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203482862 : Closed e1211203482862 ∧ code e1211203482862 = 5609249993966 := by decide
theorem cert_e1211203482862 : check e1211203482862 [[],[]] .chain = true := by decide
def e1211203482870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203482870 : Closed e1211203482870 ∧ code e1211203482870 = 5609249993974 := by decide
theorem cert_e1211203482870 : check e1211203482870 [[],[]] .chain = true := by decide
def e1211203483246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203483246 : Closed e1211203483246 ∧ code e1211203483246 = 5609249994350 := by decide
theorem cert_e1211203483246 : check e1211203483246 [[],[]] .chain = true := by decide
def e1211203483258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203483258 : Closed e1211203483258 ∧ code e1211203483258 = 5609249994362 := by decide
theorem cert_e1211203483258 : check e1211203483258 [[],[]] .chain = true := by decide
def e1211203483398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203483398 : Closed e1211203483398 ∧ code e1211203483398 = 5609249994502 := by decide
theorem cert_e1211203483398 : check e1211203483398 [[],[]] .chain = true := by decide
def e1211203483422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211203483422 : Closed e1211203483422 ∧ code e1211203483422 = 5609249994526 := by decide
theorem cert_e1211203483422 : check e1211203483422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203483446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203483446 : Closed e1211203483446 ∧ code e1211203483446 = 5609249994550 := by decide
theorem cert_e1211203483446 : check e1211203483446 [[],[]] .chain = true := by decide
def e1211203483450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203483450 : Closed e1211203483450 ∧ code e1211203483450 = 5609249994554 := by decide
theorem cert_e1211203483450 : check e1211203483450 [[],[]] .chain = true := by decide
def e1211203483702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211203483702 : Closed e1211203483702 ∧ code e1211203483702 = 5609249994806 := by decide
theorem cert_e1211203483702 : check e1211203483702 [[],[]] .chain = true := by decide
def e1211203483790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211203483790 : Closed e1211203483790 ∧ code e1211203483790 = 5609249994894 := by decide
theorem cert_e1211203483790 : check e1211203483790 [[],[]] .chain = true := by decide
def e1211203483874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211203483874 : Closed e1211203483874 ∧ code e1211203483874 = 5609249994978 := by decide
theorem cert_e1211203483874 : check e1211203483874 [[],[]] .chain = true := by decide
def e1211203483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203483886 : Closed e1211203483886 ∧ code e1211203483886 = 5609249994990 := by decide
theorem cert_e1211203483886 : check e1211203483886 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203483894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203483894 : Closed e1211203483894 ∧ code e1211203483894 = 5609249994998 := by decide
theorem cert_e1211203483894 : checkPay e1211203483894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor42
