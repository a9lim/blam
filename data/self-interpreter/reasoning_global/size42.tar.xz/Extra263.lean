import Batch263
import ExtraBase
namespace Blc.Floor42.Extra263
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211585420502 : Term := (.app (.lam (.lam (.var 1))) (.lam (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))
theorem ex_e1211585420502 : ¬ IsSelfInterpreter e1211585420502 := by
  intro he
  have hp := replay_sound (t := (.app e1211585420502 churchTrue)) (u := t_e1211585420502) (ps := [[.left],[.left],[.left],[.left],[],[.right,.left,.right],[],[.left,.left],[.left,.left,.under,.right,.left],[.left],[.left,.right],[.left],[.left,.under,.right,.left],[],[.right],[]]) (by decide)
  apply specialized_not_so he hp
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1))) (so_closed_lam (by decide) (SO.lam (g := (.app (.lam (.lam (.var 1))) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))) (r := (.var 0)) (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (SO.var 1))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211585420502
private def t_e1211585425654 : Term := (.lam (.lam (.app (.app (.app (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 7)))))))))))) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))
theorem ex_e1211585425654 : ¬ IsSelfInterpreter e1211585425654 := by
  intro he
  have hp := replay_sound (t := (call e1211585425654 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1211585425654) (ps := [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.right],[.left],[],[],[.left,.left],[.left],[.left,.right],[.left],[],[.right],[.right,.under],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1211585425654 (.var 0) = false) hz
#print axioms ex_e1211585425654
private def t_e1211585426206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))))))
theorem ex_e1211585426206 : ¬ IsSelfInterpreter e1211585426206 := by
  intro he
  have hp := replay_sound (t := (call e1211585426206 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1211585426206) (ps := [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.right],[.left,.right,.under],[.left,.right,.under,.under,.right,.left,.left],[.left,.right,.under,.under,.right,.left],[.left],[.left],[],[.right,.left],[.right],[.right],[.right,.under,.right,.left,.left]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := SelfintKnot.occ_betas_zero hr 0 (by decide)
  exact (by decide : ¬ occ 0 (.var 0) = 0) hz
#print axioms ex_e1211585426206
private def t_e1211585426230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem ex_e1211585426230 : ¬ IsSelfInterpreter e1211585426230 := by
  intro he
  have hp := replay_sound (t := (call e1211585426230 (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := t_e1211585426230) (ps := [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.right,.right],[.left],[.left,.left],[.left,.left,.under,.right],[.left],[.left],[.left,.under,.right],[],[.right],[.right,.left,.left],[.right,.left,.left,.left],[.right,.left,.left],[.right,.left],[.right],[.right,.left],[.right,.left,.left],[.right,.left],[.right],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := (.lam (.var 0))) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1211585426230 (.lam (.var 0)) = false) hz
#print axioms ex_e1211585426230
end Blc.Floor42.Extra263
