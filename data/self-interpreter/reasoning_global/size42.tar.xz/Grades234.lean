import Tables
import Batch234
namespace Blc.Floor42.Grades234
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211277294326 : ¬ IsSelfInterpreter e1211277294326 := cutM2_1 (by decide)
#print axioms ex_e1211277294326
theorem ex_e1211277293302 : ¬ IsSelfInterpreter e1211277293302 := cutM3_1 (by decide)
#print axioms ex_e1211277293302
theorem ex_e1211277293494 : ¬ IsSelfInterpreter e1211277293494 := cutM3_1 (by decide)
#print axioms ex_e1211277293494
theorem ex_e1211277295286 : ¬ IsSelfInterpreter e1211277295286 := cutM3_1 (by decide)
#print axioms ex_e1211277295286
end Blc.Floor42.Grades234
