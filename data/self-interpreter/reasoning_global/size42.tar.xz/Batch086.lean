import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202975109318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202975109318 : Closed e1202975109318 ∧ code e1202975109318 = 5601021620422 := by decide
theorem cert_e1202975109318 : check e1202975109318 [[]] .width = true := by decide
def e1202975116826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202975116826 : Closed e1202975116826 ∧ code e1202975116826 = 5601021627930 := by decide
theorem cert_e1202975116826 : check e1202975116826 [[]] .width = true := by decide
def e1202975125702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202975125702 : Closed e1202975125702 ∧ code e1202975125702 = 5601021636806 := by decide
theorem cert_e1202975125702 : check e1202975125702 [[]] .width = true := by decide
def e1202975408326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202975408326 : Closed e1202975408326 ∧ code e1202975408326 = 5601021919430 := by decide
theorem cert_e1202975408326 : check e1202975408326 [[]] .width = true := by decide
def e1202975408854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202975408854 : Closed e1202975408854 ∧ code e1202975408854 = 5601021919958 := by decide
theorem cert_e1202975408854 : check e1202975408854 [[]] .width = true := by decide
def e1202975408858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202975408858 : Closed e1202975408858 ∧ code e1202975408858 = 5601021919962 := by decide
theorem cert_e1202975408858 : check e1202975408858 [[]] .width = true := by decide
def e1202975408874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202975408874 : Closed e1202975408874 ∧ code e1202975408874 = 5601021919978 := by decide
theorem cert_e1202975408874 : check e1202975408874 [[]] .width = true := by decide
def e1202975408950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202975408950 : Closed e1202975408950 ∧ code e1202975408950 = 5601021920054 := by decide
theorem cert_e1202975408950 : check e1202975408950 [[]] .width = true := by decide
def e1202975408954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202975408954 : Closed e1202975408954 ∧ code e1202975408954 = 5601021920058 := by decide
theorem cert_e1202975408954 : check e1202975408954 [[]] .width = true := by decide
def e1202975409038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202975409038 : Closed e1202975409038 ∧ code e1202975409038 = 5601021920142 := by decide
theorem cert_e1202975409038 : check e1202975409038 [[]] .width = true := by decide
def e1202975409050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202975409050 : Closed e1202975409050 ∧ code e1202975409050 = 5601021920154 := by decide
theorem cert_e1202975409050 : check e1202975409050 [[]] .width = true := by decide
def e1202975410970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202975410970 : Closed e1202975410970 ∧ code e1202975410970 = 5601021922074 := by decide
theorem cert_e1202975410970 : check e1202975410970 [[]] .width = true := by decide
def e1202975411014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202975411014 : Closed e1202975411014 ∧ code e1202975411014 = 5601021922118 := by decide
theorem cert_e1202975411014 : check e1202975411014 [[]] .width = true := by decide
def e1202975411126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202975411126 : Closed e1202975411126 ∧ code e1202975411126 = 5601021922230 := by decide
theorem cert_e1202975411126 : check e1202975411126 [[]] .width = true := by decide
def e1202975411254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202975411254 : Closed e1202975411254 ∧ code e1202975411254 = 5601021922358 := by decide
theorem cert_e1202975411254 : check e1202975411254 [[]] .width = true := by decide
def e1202975411258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202975411258 : Closed e1202975411258 ∧ code e1202975411258 = 5601021922362 := by decide
theorem cert_e1202975411258 : check e1202975411258 [[]] .width = true := by decide
def e1202975411398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202975411398 : Closed e1202975411398 ∧ code e1202975411398 = 5601021922502 := by decide
theorem cert_e1202975411398 : check e1202975411398 [[]] .width = true := by decide
def e1202975411738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202975411738 : Closed e1202975411738 ∧ code e1202975411738 = 5601021922842 := by decide
theorem cert_e1202975411738 : check e1202975411738 [[]] .width = true := by decide
def e1202975411830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202975411830 : Closed e1202975411830 ∧ code e1202975411830 = 5601021922934 := by decide
theorem cert_e1202975411830 : check e1202975411830 [[]] .width = true := by decide
def e1202975419418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202975419418 : Closed e1202975419418 ∧ code e1202975419418 = 5601021930522 := by decide
theorem cert_e1202975419418 : check e1202975419418 [[]] .width = true := by decide
def e1202975419462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202975419462 : Closed e1202975419462 ∧ code e1202975419462 = 5601021930566 := by decide
theorem cert_e1202975419462 : check e1202975419462 [[]] .width = true := by decide
def e1202975419490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202975419490 : Closed e1202975419490 ∧ code e1202975419490 = 5601021930594 := by decide
theorem cert_e1202975419490 : check e1202975419490 [[]] .width = true := by decide
def e1202975419654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202975419654 : Closed e1202975419654 ∧ code e1202975419654 = 5601021930758 := by decide
theorem cert_e1202975419654 : check e1202975419654 [[]] .width = true := by decide
def e1202975420446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202975420446 : Closed e1202975420446 ∧ code e1202975420446 = 5601021931550 := by decide
theorem cert_e1202975420446 : check e1202975420446 [[]] .width = true := by decide
def e1202975420614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202975420614 : Closed e1202975420614 ∧ code e1202975420614 = 5601021931718 := by decide
theorem cert_e1202975420614 : check e1202975420614 [[]] .width = true := by decide
def e1202975420642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202975420642 : Closed e1202975420642 ∧ code e1202975420642 = 5601021931746 := by decide
theorem cert_e1202975420642 : check e1202975420642 [[]] .width = true := by decide
def e1202975421190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202975421190 : Closed e1202975421190 ∧ code e1202975421190 = 5601021932294 := by decide
theorem cert_e1202975421190 : check e1202975421190 [[]] .width = true := by decide
def e1202977206470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202977206470 : Closed e1202977206470 ∧ code e1202977206470 = 5601023717574 := by decide
theorem cert_e1202977206470 : check e1202977206470 [[]] .width = true := by decide
def e1202977617946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202977617946 : Closed e1202977617946 ∧ code e1202977617946 = 5601024129050 := by decide
theorem cert_e1202977617946 : check e1202977617946 [[]] .width = true := by decide
def e1202977683482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202977683482 : Closed e1202977683482 ∧ code e1202977683482 = 5601024194586 := by decide
theorem cert_e1202977683482 : check e1202977683482 [[]] .width = true := by decide
def e1202977992902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202977992902 : Closed e1202977992902 ∧ code e1202977992902 = 5601024504006 := by decide
theorem cert_e1202977992902 : check e1202977992902 [[]] .width = true := by decide
def e1202978017478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202978017478 : Closed e1202978017478 ∧ code e1202978017478 = 5601024528582 := by decide
theorem cert_e1202978017478 : check e1202978017478 [[]] .width = true := by decide
def e1202978353350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202978353350 : Closed e1202978353350 ∧ code e1202978353350 = 5601024864454 := by decide
theorem cert_e1202978353350 : check e1202978353350 [[]] .width = true := by decide
def e1202978404378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202978404378 : Closed e1202978404378 ∧ code e1202978404378 = 5601024915482 := by decide
theorem cert_e1202978404378 : check e1202978404378 [[]] .width = true := by decide
def e1202978416666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202978416666 : Closed e1202978416666 ∧ code e1202978416666 = 5601024927770 := by decide
theorem cert_e1202978416666 : check e1202978416666 [[]] .width = true := by decide
def e1202978418202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202978418202 : Closed e1202978418202 ∧ code e1202978418202 = 5601024929306 := by decide
theorem cert_e1202978418202 : check e1202978418202 [[]] .width = true := by decide
def e1202978521114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202978521114 : Closed e1202978521114 ∧ code e1202978521114 = 5601025032218 := by decide
theorem cert_e1202978521114 : check e1202978521114 [[]] .width = true := by decide
def e1202978521206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202978521206 : Closed e1202978521206 ∧ code e1202978521206 = 5601025032310 := by decide
theorem cert_e1202978521206 : check e1202978521206 [[]] .width = true := by decide
def e1202978521450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202978521450 : Closed e1202978521450 ∧ code e1202978521450 = 5601025032554 := by decide
theorem cert_e1202978521450 : check e1202978521450 [[]] .width = true := by decide
def e1202978521498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202978521498 : Closed e1202978521498 ∧ code e1202978521498 = 5601025032602 := by decide
theorem cert_e1202978521498 : check e1202978521498 [[]] .width = true := by decide
def e1202978522506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202978522506 : Closed e1202978522506 ∧ code e1202978522506 = 5601025033610 := by decide
theorem cert_e1202978522506 : check e1202978522506 [[]] .width = true := by decide
def e1202978522530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202978522530 : Closed e1202978522530 ∧ code e1202978522530 = 5601025033634 := by decide
theorem cert_e1202978522530 : check e1202978522530 [[]] .width = true := by decide
def e1202978522638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202978522638 : Closed e1202978522638 ∧ code e1202978522638 = 5601025033742 := by decide
theorem cert_e1202978522638 : check e1202978522638 [[]] .width = true := by decide
def e1202978522650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202978522650 : Closed e1202978522650 ∧ code e1202978522650 = 5601025033754 := by decide
theorem cert_e1202978522650 : check e1202978522650 [[]] .width = true := by decide
def e1202978522722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202978522722 : Closed e1202978522722 ∧ code e1202978522722 = 5601025033826 := by decide
theorem cert_e1202978522722 : check e1202978522722 [[]] .width = true := by decide
def e1202978697414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202978697414 : Closed e1202978697414 ∧ code e1202978697414 = 5601025208518 := by decide
theorem cert_e1202978697414 : check e1202978697414 [[]] .width = true := by decide
def e1202978713114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202978713114 : Closed e1202978713114 ∧ code e1202978713114 = 5601025224218 := by decide
theorem cert_e1202978713114 : check e1202978713114 [[]] .width = true := by decide
def e1202978716186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202978716186 : Closed e1202978716186 ∧ code e1202978716186 = 5601025227290 := by decide
theorem cert_e1202978716186 : check e1202978716186 [[]] .width = true := by decide
def e1202978717722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202978717722 : Closed e1202978717722 ∧ code e1202978717722 = 5601025228826 := by decide
theorem cert_e1202978717722 : check e1202978717722 [[]] .width = true := by decide
def e1202978717814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202978717814 : Closed e1202978717814 ∧ code e1202978717814 = 5601025228918 := by decide
theorem cert_e1202978717814 : check e1202978717814 [[]] .width = true := by decide
def e1202978718058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202978718058 : Closed e1202978718058 ∧ code e1202978718058 = 5601025229162 := by decide
theorem cert_e1202978718058 : check e1202978718058 [[]] .width = true := by decide
def e1202978718106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202978718106 : Closed e1202978718106 ∧ code e1202978718106 = 5601025229210 := by decide
theorem cert_e1202978718106 : check e1202978718106 [[]] .width = true := by decide
def e1202978719114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202978719114 : Closed e1202978719114 ∧ code e1202978719114 = 5601025230218 := by decide
theorem cert_e1202978719114 : check e1202978719114 [[]] .width = true := by decide
def e1202978719138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202978719138 : Closed e1202978719138 ∧ code e1202978719138 = 5601025230242 := by decide
theorem cert_e1202978719138 : check e1202978719138 [[]] .width = true := by decide
def e1202978719246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202978719246 : Closed e1202978719246 ∧ code e1202978719246 = 5601025230350 := by decide
theorem cert_e1202978719246 : check e1202978719246 [[]] .width = true := by decide
def e1202978719258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202978719258 : Closed e1202978719258 ∧ code e1202978719258 = 5601025230362 := by decide
theorem cert_e1202978719258 : check e1202978719258 [[]] .width = true := by decide
def e1202978719330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202978719330 : Closed e1202978719330 ∧ code e1202978719330 = 5601025230434 := by decide
theorem cert_e1202978719330 : check e1202978719330 [[]] .width = true := by decide
def e1202979958982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202979958982 : Closed e1202979958982 ∧ code e1202979958982 = 5601026470086 := by decide
theorem cert_e1202979958982 : check e1202979958982 [[]] .width = true := by decide
def e1202979977242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202979977242 : Closed e1202979977242 ∧ code e1202979977242 = 5601026488346 := by decide
theorem cert_e1202979977242 : check e1202979977242 [[]] .width = true := by decide
def e1202979991066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202979991066 : Closed e1202979991066 ∧ code e1202979991066 = 5601026502170 := by decide
theorem cert_e1202979991066 : check e1202979991066 [[]] .width = true := by decide
def e1202980241606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202980241606 : Closed e1202980241606 ∧ code e1202980241606 = 5601026752710 := by decide
theorem cert_e1202980241606 : check e1202980241606 [[]] .width = true := by decide
def e1202980315162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980315162 : Closed e1202980315162 ∧ code e1202980315162 = 5601026826266 := by decide
theorem cert_e1202980315162 : check e1202980315162 [[]] .width = true := by decide
def e1202980315254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980315254 : Closed e1202980315254 ∧ code e1202980315254 = 5601026826358 := by decide
theorem cert_e1202980315254 : check e1202980315254 [[]] .width = true := by decide
def e1202980315498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980315498 : Closed e1202980315498 ∧ code e1202980315498 = 5601026826602 := by decide
theorem cert_e1202980315498 : check e1202980315498 [[]] .width = true := by decide
def e1202980315546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980315546 : Closed e1202980315546 ∧ code e1202980315546 = 5601026826650 := by decide
theorem cert_e1202980315546 : check e1202980315546 [[]] .width = true := by decide
def e1202980327622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980327622 : Closed e1202980327622 ∧ code e1202980327622 = 5601026838726 := by decide
theorem cert_e1202980327622 : check e1202980327622 [[]] .width = true := by decide
def e1202980329498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202980329498 : Closed e1202980329498 ∧ code e1202980329498 = 5601026840602 := by decide
theorem cert_e1202980329498 : check e1202980329498 [[]] .width = true := by decide
def e1202980331034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202980331034 : Closed e1202980331034 ∧ code e1202980331034 = 5601026842138 := by decide
theorem cert_e1202980331034 : check e1202980331034 [[]] .width = true := by decide
def e1202980339910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202980339910 : Closed e1202980339910 ∧ code e1202980339910 = 5601026851014 := by decide
theorem cert_e1202980339910 : check e1202980339910 [[]] .width = true := by decide
def e1202980347930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980347930 : Closed e1202980347930 ∧ code e1202980347930 = 5601026859034 := by decide
theorem cert_e1202980347930 : check e1202980347930 [[]] .width = true := by decide
def e1202980348022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980348022 : Closed e1202980348022 ∧ code e1202980348022 = 5601026859126 := by decide
theorem cert_e1202980348022 : check e1202980348022 [[]] .width = true := by decide
def e1202980348266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980348266 : Closed e1202980348266 ∧ code e1202980348266 = 5601026859370 := by decide
theorem cert_e1202980348266 : check e1202980348266 [[]] .width = true := by decide
def e1202980348314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980348314 : Closed e1202980348314 ∧ code e1202980348314 = 5601026859418 := by decide
theorem cert_e1202980348314 : check e1202980348314 [[]] .width = true := by decide
def e1202980352198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980352198 : Closed e1202980352198 ∧ code e1202980352198 = 5601026863302 := by decide
theorem cert_e1202980352198 : check e1202980352198 [[]] .width = true := by decide
def e1202980577306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980577306 : Closed e1202980577306 ∧ code e1202980577306 = 5601027088410 := by decide
theorem cert_e1202980577306 : check e1202980577306 [[]] .width = true := by decide
def e1202980577398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980577398 : Closed e1202980577398 ∧ code e1202980577398 = 5601027088502 := by decide
theorem cert_e1202980577398 : check e1202980577398 [[]] .width = true := by decide
def e1202980577642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980577642 : Closed e1202980577642 ∧ code e1202980577642 = 5601027088746 := by decide
theorem cert_e1202980577642 : check e1202980577642 [[]] .width = true := by decide
def e1202980577690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980577690 : Closed e1202980577690 ∧ code e1202980577690 = 5601027088794 := by decide
theorem cert_e1202980577690 : check e1202980577690 [[]] .width = true := by decide
def e1202980626458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980626458 : Closed e1202980626458 ∧ code e1202980626458 = 5601027137562 := by decide
theorem cert_e1202980626458 : check e1202980626458 [[]] .width = true := by decide
def e1202980626550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980626550 : Closed e1202980626550 ∧ code e1202980626550 = 5601027137654 := by decide
private def t_e1202980626550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202980626550 : ¬ IsSelfInterpreter e1202980626550 :=
  wSource (t := t_e1202980626550) (replay_sound (ps := []) (t := e1202980626550) (by decide)) (by decide)
def e1202980626794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980626794 : Closed e1202980626794 ∧ code e1202980626794 = 5601027137898 := by decide
private def t_e1202980626794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202980626794 : ¬ IsSelfInterpreter e1202980626794 :=
  wSource (t := t_e1202980626794) (replay_sound (ps := []) (t := e1202980626794) (by decide)) (by decide)
def e1202980626842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980626842 : Closed e1202980626842 ∧ code e1202980626842 = 5601027137946 := by decide
private def t_e1202980626842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202980626842 : ¬ IsSelfInterpreter e1202980626842 :=
  wSource (t := t_e1202980626842) (replay_sound (ps := []) (t := e1202980626842) (by decide)) (by decide)
def e1202980671686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980671686 : Closed e1202980671686 ∧ code e1202980671686 = 5601027182790 := by decide
theorem cert_e1202980671686 : check e1202980671686 [[]] .width = true := by decide
def e1202980677658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202980677658 : Closed e1202980677658 ∧ code e1202980677658 = 5601027188762 := by decide
theorem cert_e1202980677658 : check e1202980677658 [[]] .width = true := by decide
def e1202980679194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202980679194 : Closed e1202980679194 ∧ code e1202980679194 = 5601027190298 := by decide
theorem cert_e1202980679194 : check e1202980679194 [[]] .width = true := by decide
def e1202980682266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202980682266 : Closed e1202980682266 ∧ code e1202980682266 = 5601027193370 := by decide
theorem cert_e1202980682266 : check e1202980682266 [[]] .width = true := by decide
def e1202980720838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980720838 : Closed e1202980720838 ∧ code e1202980720838 = 5601027231942 := by decide
theorem cert_e1202980720838 : check e1202980720838 [[]] .width = true := by decide
def e1202980722714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202980722714 : Closed e1202980722714 ∧ code e1202980722714 = 5601027233818 := by decide
theorem cert_e1202980722714 : check e1202980722714 [[]] .width = true := by decide
def e1202980724250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202980724250 : Closed e1202980724250 ∧ code e1202980724250 = 5601027235354 := by decide
theorem cert_e1202980724250 : check e1202980724250 [[]] .width = true := by decide
def e1202980733126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202980733126 : Closed e1202980733126 ∧ code e1202980733126 = 5601027244230 := by decide
theorem cert_e1202980733126 : check e1202980733126 [[]] .width = true := by decide
def e1202980741146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980741146 : Closed e1202980741146 ∧ code e1202980741146 = 5601027252250 := by decide
theorem cert_e1202980741146 : check e1202980741146 [[]] .width = true := by decide
def e1202980741238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980741238 : Closed e1202980741238 ∧ code e1202980741238 = 5601027252342 := by decide
theorem cert_e1202980741238 : check e1202980741238 [[]] .width = true := by decide
def e1202980741482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980741482 : Closed e1202980741482 ∧ code e1202980741482 = 5601027252586 := by decide
theorem cert_e1202980741482 : check e1202980741482 [[]] .width = true := by decide
def e1202980741530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980741530 : Closed e1202980741530 ∧ code e1202980741530 = 5601027252634 := by decide
theorem cert_e1202980741530 : check e1202980741530 [[]] .width = true := by decide
def e1202980745414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980745414 : Closed e1202980745414 ∧ code e1202980745414 = 5601027256518 := by decide
theorem cert_e1202980745414 : check e1202980745414 [[]] .width = true := by decide
def e1202980757530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202980757530 : Closed e1202980757530 ∧ code e1202980757530 = 5601027268634 := by decide
theorem cert_e1202980757530 : check e1202980757530 [[]] .width = true := by decide
def e1202980757622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202980757622 : Closed e1202980757622 ∧ code e1202980757622 = 5601027268726 := by decide
private def t_e1202980757622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202980757622 : ¬ IsSelfInterpreter e1202980757622 :=
  wSource (t := t_e1202980757622) (replay_sound (ps := []) (t := e1202980757622) (by decide)) (by decide)
def e1202980757866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202980757866 : Closed e1202980757866 ∧ code e1202980757866 = 5601027268970 := by decide
private def t_e1202980757866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202980757866 : ¬ IsSelfInterpreter e1202980757866 :=
  wSource (t := t_e1202980757866) (replay_sound (ps := []) (t := e1202980757866) (by decide)) (by decide)
def e1202980757914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202980757914 : Closed e1202980757914 ∧ code e1202980757914 = 5601027269018 := by decide
private def t_e1202980757914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202980757914 : ¬ IsSelfInterpreter e1202980757914 :=
  wSource (t := t_e1202980757914) (replay_sound (ps := []) (t := e1202980757914) (by decide)) (by decide)
def e1202980767258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202980767258 : Closed e1202980767258 ∧ code e1202980767258 = 5601027278362 := by decide
private def t_e1202980767258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202980767258 : ¬ IsSelfInterpreter e1202980767258 :=
  wSource (t := t_e1202980767258) (replay_sound (ps := []) (t := e1202980767258) (by decide)) (by decide)
def e1202980769990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202980769990 : Closed e1202980769990 ∧ code e1202980769990 = 5601027281094 := by decide
theorem cert_e1202980769990 : check e1202980769990 [[]] .width = true := by decide
def e1202981404698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202981404698 : Closed e1202981404698 ∧ code e1202981404698 = 5601027915802 := by decide
theorem cert_e1202981404698 : check e1202981404698 [[]] .width = true := by decide
def e1202981404790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202981404790 : Closed e1202981404790 ∧ code e1202981404790 = 5601027915894 := by decide
theorem cert_e1202981404790 : check e1202981404790 [[]] .width = true := by decide
def e1202981405034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202981405034 : Closed e1202981405034 ∧ code e1202981405034 = 5601027916138 := by decide
theorem cert_e1202981405034 : check e1202981405034 [[]] .width = true := by decide
def e1202981405082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202981405082 : Closed e1202981405082 ∧ code e1202981405082 = 5601027916186 := by decide
theorem cert_e1202981405082 : check e1202981405082 [[]] .width = true := by decide
def e1202981406090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202981406090 : Closed e1202981406090 ∧ code e1202981406090 = 5601027917194 := by decide
theorem cert_e1202981406090 : check e1202981406090 [[]] .width = true := by decide
def e1202981406114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202981406114 : Closed e1202981406114 ∧ code e1202981406114 = 5601027917218 := by decide
theorem cert_e1202981406114 : check e1202981406114 [[]] .width = true := by decide
def e1202981406222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202981406222 : Closed e1202981406222 ∧ code e1202981406222 = 5601027917326 := by decide
theorem cert_e1202981406222 : check e1202981406222 [[]] .width = true := by decide
def e1202981406234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202981406234 : Closed e1202981406234 ∧ code e1202981406234 = 5601027917338 := by decide
theorem cert_e1202981406234 : check e1202981406234 [[]] .width = true := by decide
def e1202981406306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202981406306 : Closed e1202981406306 ∧ code e1202981406306 = 5601027917410 := by decide
theorem cert_e1202981406306 : check e1202981406306 [[]] .width = true := by decide
def e1202981814470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202981814470 : Closed e1202981814470 ∧ code e1202981814470 = 5601028325574 := by decide
theorem cert_e1202981814470 : check e1202981814470 [[]] .width = true := by decide
def e1202981888026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202981888026 : Closed e1202981888026 ∧ code e1202981888026 = 5601028399130 := by decide
theorem cert_e1202981888026 : check e1202981888026 [[]] .width = true := by decide
def e1202981888118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202981888118 : Closed e1202981888118 ∧ code e1202981888118 = 5601028399222 := by decide
theorem cert_e1202981888118 : check e1202981888118 [[]] .width = true := by decide
def e1202981888362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202981888362 : Closed e1202981888362 ∧ code e1202981888362 = 5601028399466 := by decide
theorem cert_e1202981888362 : check e1202981888362 [[]] .width = true := by decide
def e1202981888410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202981888410 : Closed e1202981888410 ∧ code e1202981888410 = 5601028399514 := by decide
theorem cert_e1202981888410 : check e1202981888410 [[]] .width = true := by decide
def e1202981900486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202981900486 : Closed e1202981900486 ∧ code e1202981900486 = 5601028411590 := by decide
theorem cert_e1202981900486 : check e1202981900486 [[]] .width = true := by decide
def e1202981902362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202981902362 : Closed e1202981902362 ∧ code e1202981902362 = 5601028413466 := by decide
theorem cert_e1202981902362 : check e1202981902362 [[]] .width = true := by decide
def e1202981903898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202981903898 : Closed e1202981903898 ∧ code e1202981903898 = 5601028415002 := by decide
theorem cert_e1202981903898 : check e1202981903898 [[]] .width = true := by decide
def e1202981912774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202981912774 : Closed e1202981912774 ∧ code e1202981912774 = 5601028423878 := by decide
theorem cert_e1202981912774 : check e1202981912774 [[]] .width = true := by decide
def e1202981920794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202981920794 : Closed e1202981920794 ∧ code e1202981920794 = 5601028431898 := by decide
theorem cert_e1202981920794 : check e1202981920794 [[]] .width = true := by decide
def e1202981920886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202981920886 : Closed e1202981920886 ∧ code e1202981920886 = 5601028431990 := by decide
theorem cert_e1202981920886 : check e1202981920886 [[]] .width = true := by decide
def e1202981921130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202981921130 : Closed e1202981921130 ∧ code e1202981921130 = 5601028432234 := by decide
theorem cert_e1202981921130 : check e1202981921130 [[]] .width = true := by decide
def e1202981921178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202981921178 : Closed e1202981921178 ∧ code e1202981921178 = 5601028432282 := by decide
theorem cert_e1202981921178 : check e1202981921178 [[]] .width = true := by decide
def e1202981925062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202981925062 : Closed e1202981925062 ∧ code e1202981925062 = 5601028436166 := by decide
theorem cert_e1202981925062 : check e1202981925062 [[]] .width = true := by decide
def e1202982748358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202982748358 : Closed e1202982748358 ∧ code e1202982748358 = 5601029259462 := by decide
theorem cert_e1202982748358 : check e1202982748358 [[]] .width = true := by decide
def e1202982748886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202982748886 : Closed e1202982748886 ∧ code e1202982748886 = 5601029259990 := by decide
theorem cert_e1202982748886 : check e1202982748886 [[]] .width = true := by decide
def e1202982748890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202982748890 : Closed e1202982748890 ∧ code e1202982748890 = 5601029259994 := by decide
theorem cert_e1202982748890 : check e1202982748890 [[]] .width = true := by decide
def e1202982748906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202982748906 : Closed e1202982748906 ∧ code e1202982748906 = 5601029260010 := by decide
theorem cert_e1202982748906 : check e1202982748906 [[]] .width = true := by decide
def e1202982748982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202982748982 : Closed e1202982748982 ∧ code e1202982748982 = 5601029260086 := by decide
theorem cert_e1202982748982 : check e1202982748982 [[]] .width = true := by decide
def e1202982748986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202982748986 : Closed e1202982748986 ∧ code e1202982748986 = 5601029260090 := by decide
theorem cert_e1202982748986 : check e1202982748986 [[]] .width = true := by decide
def e1202982749070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202982749070 : Closed e1202982749070 ∧ code e1202982749070 = 5601029260174 := by decide
theorem cert_e1202982749070 : check e1202982749070 [[]] .width = true := by decide
def e1202982749082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202982749082 : Closed e1202982749082 ∧ code e1202982749082 = 5601029260186 := by decide
theorem cert_e1202982749082 : check e1202982749082 [[]] .width = true := by decide
def e1202982751002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202982751002 : Closed e1202982751002 ∧ code e1202982751002 = 5601029262106 := by decide
theorem cert_e1202982751002 : check e1202982751002 [[]] .width = true := by decide
def e1202982751046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202982751046 : Closed e1202982751046 ∧ code e1202982751046 = 5601029262150 := by decide
theorem cert_e1202982751046 : check e1202982751046 [[]] .width = true := by decide
def e1202982751158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202982751158 : Closed e1202982751158 ∧ code e1202982751158 = 5601029262262 := by decide
theorem cert_e1202982751158 : check e1202982751158 [[]] .width = true := by decide
def e1202982751286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202982751286 : Closed e1202982751286 ∧ code e1202982751286 = 5601029262390 := by decide
theorem cert_e1202982751286 : check e1202982751286 [[]] .width = true := by decide
def e1202982751290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202982751290 : Closed e1202982751290 ∧ code e1202982751290 = 5601029262394 := by decide
theorem cert_e1202982751290 : check e1202982751290 [[]] .width = true := by decide
def e1202982751430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202982751430 : Closed e1202982751430 ∧ code e1202982751430 = 5601029262534 := by decide
theorem cert_e1202982751430 : check e1202982751430 [[]] .width = true := by decide
def e1202982751770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202982751770 : Closed e1202982751770 ∧ code e1202982751770 = 5601029262874 := by decide
theorem cert_e1202982751770 : check e1202982751770 [[]] .width = true := by decide
def e1202982751862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202982751862 : Closed e1202982751862 ∧ code e1202982751862 = 5601029262966 := by decide
theorem cert_e1202982751862 : check e1202982751862 [[]] .width = true := by decide
def e1202982759450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202982759450 : Closed e1202982759450 ∧ code e1202982759450 = 5601029270554 := by decide
theorem cert_e1202982759450 : check e1202982759450 [[]] .width = true := by decide
def e1202982759494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202982759494 : Closed e1202982759494 ∧ code e1202982759494 = 5601029270598 := by decide
theorem cert_e1202982759494 : check e1202982759494 [[]] .width = true := by decide
def e1202982759522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202982759522 : Closed e1202982759522 ∧ code e1202982759522 = 5601029270626 := by decide
theorem cert_e1202982759522 : check e1202982759522 [[]] .width = true := by decide
def e1202982759686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202982759686 : Closed e1202982759686 ∧ code e1202982759686 = 5601029270790 := by decide
theorem cert_e1202982759686 : check e1202982759686 [[]] .width = true := by decide
def e1202982760478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202982760478 : Closed e1202982760478 ∧ code e1202982760478 = 5601029271582 := by decide
theorem cert_e1202982760478 : check e1202982760478 [[]] .width = true := by decide
def e1202982760646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202982760646 : Closed e1202982760646 ∧ code e1202982760646 = 5601029271750 := by decide
theorem cert_e1202982760646 : check e1202982760646 [[]] .width = true := by decide
def e1202982760674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202982760674 : Closed e1202982760674 ∧ code e1202982760674 = 5601029271778 := by decide
theorem cert_e1202982760674 : check e1202982760674 [[]] .width = true := by decide
def e1202982761222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202982761222 : Closed e1202982761222 ∧ code e1202982761222 = 5601029272326 := by decide
theorem cert_e1202982761222 : check e1202982761222 [[]] .width = true := by decide
def e1202983460890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202983460890 : Closed e1202983460890 ∧ code e1202983460890 = 5601029971994 := by decide
theorem cert_e1202983460890 : check e1202983460890 [[]] .width = true := by decide
def e1202983460982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202983460982 : Closed e1202983460982 ∧ code e1202983460982 = 5601029972086 := by decide
private def t_e1202983460982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202983460982 : ¬ IsSelfInterpreter e1202983460982 :=
  wSource (t := t_e1202983460982) (replay_sound (ps := []) (t := e1202983460982) (by decide)) (by decide)
def e1202983461226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202983461226 : Closed e1202983461226 ∧ code e1202983461226 = 5601029972330 := by decide
private def t_e1202983461226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202983461226 : ¬ IsSelfInterpreter e1202983461226 :=
  wSource (t := t_e1202983461226) (replay_sound (ps := []) (t := e1202983461226) (by decide)) (by decide)
def e1202983461274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202983461274 : Closed e1202983461274 ∧ code e1202983461274 = 5601029972378 := by decide
private def t_e1202983461274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202983461274 : ¬ IsSelfInterpreter e1202983461274 :=
  wSource (t := t_e1202983461274) (replay_sound (ps := []) (t := e1202983461274) (by decide)) (by decide)
def e1202983510042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202983510042 : Closed e1202983510042 ∧ code e1202983510042 = 5601030021146 := by decide
theorem cert_e1202983510042 : check e1202983510042 [[]] .width = true := by decide
def e1202983510134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202983510134 : Closed e1202983510134 ∧ code e1202983510134 = 5601030021238 := by decide
private def t_e1202983510134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202983510134 : ¬ IsSelfInterpreter e1202983510134 :=
  wSource (t := t_e1202983510134) (replay_sound (ps := []) (t := e1202983510134) (by decide)) (by decide)
def e1202983510378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202983510378 : Closed e1202983510378 ∧ code e1202983510378 = 5601030021482 := by decide
private def t_e1202983510378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202983510378 : ¬ IsSelfInterpreter e1202983510378 :=
  wSource (t := t_e1202983510378) (replay_sound (ps := []) (t := e1202983510378) (by decide)) (by decide)
def e1202983510426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202983510426 : Closed e1202983510426 ∧ code e1202983510426 = 5601030021530 := by decide
private def t_e1202983510426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202983510426 : ¬ IsSelfInterpreter e1202983510426 :=
  wSource (t := t_e1202983510426) (replay_sound (ps := []) (t := e1202983510426) (by decide)) (by decide)
def e1202984087750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202984087750 : Closed e1202984087750 ∧ code e1202984087750 = 5601030598854 := by decide
theorem cert_e1202984087750 : check e1202984087750 [[]] .width = true := by decide
def e1202984114202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202984114202 : Closed e1202984114202 ∧ code e1202984114202 = 5601030625306 := by decide
theorem cert_e1202984114202 : check e1202984114202 [[]] .width = true := by decide
def e1202984118298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202984118298 : Closed e1202984118298 ∧ code e1202984118298 = 5601030629402 := by decide
theorem cert_e1202984118298 : check e1202984118298 [[]] .width = true := by decide
def e1202984157210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202984157210 : Closed e1202984157210 ∧ code e1202984157210 = 5601030668314 := by decide
theorem cert_e1202984157210 : check e1202984157210 [[]] .width = true := by decide
end Blc.Floor42
