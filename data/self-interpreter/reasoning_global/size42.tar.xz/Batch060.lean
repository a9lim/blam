import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131189001502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1131189001502 : Closed e1131189001502 ∧ code e1131189001502 = 5529235512606 := by decide
theorem cert_e1131189001502 : check e1131189001502 [[],[.under]] .three = true := by decide
def e1131189001526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131189001526 : Closed e1131189001526 ∧ code e1131189001526 = 5529235512630 := by decide
theorem cert_e1131189001526 : check e1131189001526 [[],[.under]] .three = true := by decide
def e1131189001530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131189001530 : Closed e1131189001530 ∧ code e1131189001530 = 5529235512634 := by decide
theorem cert_e1131189001530 : check e1131189001530 [[],[.under]] .three = true := by decide
def e1131189001626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1131189001626 : Closed e1131189001626 ∧ code e1131189001626 = 5529235512730 := by decide
theorem cert_e1131189001626 : check e1131189001626 [[],[.under]] .three = true := by decide
def e1131189001670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1131189001670 : Closed e1131189001670 ∧ code e1131189001670 = 5529235512774 := by decide
theorem cert_e1131189001670 : check e1131189001670 [[],[.under]] .three = true := by decide
def e1131189001782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1131189001782 : Closed e1131189001782 ∧ code e1131189001782 = 5529235512886 := by decide
theorem cert_e1131189001782 : check e1131189001782 [[],[.under]] .three = true := by decide
def e1131189001786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1131189001786 : Closed e1131189001786 ∧ code e1131189001786 = 5529235512890 := by decide
theorem cert_e1131189001786 : check e1131189001786 [[],[.under]] .three = true := by decide
def e1131189001870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1131189001870 : Closed e1131189001870 ∧ code e1131189001870 = 5529235512974 := by decide
theorem cert_e1131189001870 : check e1131189001870 [[],[.under]] .three = true := by decide
def e1131189001926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1131189001926 : Closed e1131189001926 ∧ code e1131189001926 = 5529235513030 := by decide
theorem cert_e1131189001926 : check e1131189001926 [[],[.under]] .three = true := by decide
def e1131189002734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1131189002734 : Closed e1131189002734 ∧ code e1131189002734 = 5529235513838 := by decide
theorem cert_e1131189002734 : check e1131189002734 [[],[.under]] .three = true := by decide
def e1131189003702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1131189003702 : Closed e1131189003702 ∧ code e1131189003702 = 5529235514806 := by decide
theorem cert_e1131189003702 : check e1131189003702 [[],[.under]] .three = true := by decide
def e1131189003734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1131189003734 : Closed e1131189003734 ∧ code e1131189003734 = 5529235514838 := by decide
theorem cert_e1131189003734 : check e1131189003734 [[],[.under]] .three = true := by decide
def e1131189003738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1131189003738 : Closed e1131189003738 ∧ code e1131189003738 = 5529235514842 := by decide
theorem cert_e1131189003738 : check e1131189003738 [[],[.under]] .three = true := by decide
def e1131189003894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131189003894 : Closed e1131189003894 ∧ code e1131189003894 = 5529235514998 := by decide
theorem cert_e1131189003894 : check e1131189003894 [[],[.under]] .three = true := by decide
def e1131189004062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1131189004062 : Closed e1131189004062 ∧ code e1131189004062 = 5529235515166 := by decide
theorem cert_e1131189004062 : check e1131189004062 [[],[.under]] .three = true := by decide
def e1131189004086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131189004086 : Closed e1131189004086 ∧ code e1131189004086 = 5529235515190 := by decide
theorem cert_e1131189004086 : check e1131189004086 [[],[.under]] .three = true := by decide
def e1131189004090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131189004090 : Closed e1131189004090 ∧ code e1131189004090 = 5529235515194 := by decide
theorem cert_e1131189004090 : check e1131189004090 [[],[.under]] .three = true := by decide
def e1131189004174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1131189004174 : Closed e1131189004174 ∧ code e1131189004174 = 5529235515278 := by decide
theorem cert_e1131189004174 : check e1131189004174 [[],[.under]] .three = true := by decide
def e1131189006574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1131189006574 : Closed e1131189006574 ∧ code e1131189006574 = 5529235517678 := by decide
theorem cert_e1131189006574 : check e1131189006574 [[],[.under]] .three = true := by decide
def e1131189006582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1131189006582 : Closed e1131189006582 ∧ code e1131189006582 = 5529235517686 := by decide
theorem cert_e1131189006582 : check e1131189006582 [[],[.under]] .three = true := by decide
def e1131189007062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1131189007062 : Closed e1131189007062 ∧ code e1131189007062 = 5529235518166 := by decide
theorem cert_e1131189007062 : check e1131189007062 [[],[.under]] .three = true := by decide
def e1131189007066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1131189007066 : Closed e1131189007066 ∧ code e1131189007066 = 5529235518170 := by decide
theorem cert_e1131189007066 : check e1131189007066 [[],[.under]] .three = true := by decide
def e1131189007082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1131189007082 : Closed e1131189007082 ∧ code e1131189007082 = 5529235518186 := by decide
theorem cert_e1131189007082 : check e1131189007082 [[],[.under]] .three = true := by decide
def e1131189007134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1131189007134 : Closed e1131189007134 ∧ code e1131189007134 = 5529235518238 := by decide
theorem cert_e1131189007134 : check e1131189007134 [[],[.under]] .three = true := by decide
def e1131189007158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131189007158 : Closed e1131189007158 ∧ code e1131189007158 = 5529235518262 := by decide
theorem cert_e1131189007158 : check e1131189007158 [[],[.under]] .three = true := by decide
def e1131189007162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131189007162 : Closed e1131189007162 ∧ code e1131189007162 = 5529235518266 := by decide
theorem cert_e1131189007162 : check e1131189007162 [[],[.under]] .three = true := by decide
def e1131189007258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131189007258 : Closed e1131189007258 ∧ code e1131189007258 = 5529235518362 := by decide
theorem cert_e1131189007258 : check e1131189007258 [[],[.under]] .three = true := by decide
def e1131189007302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1131189007302 : Closed e1131189007302 ∧ code e1131189007302 = 5529235518406 := by decide
theorem cert_e1131189007302 : check e1131189007302 [[],[.under]] .three = true := by decide
def e1131189008782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1131189008782 : Closed e1131189008782 ∧ code e1131189008782 = 5529235519886 := by decide
theorem cert_e1131189008782 : check e1131189008782 [[],[.under]] .three = true := by decide
def e1131189008838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1131189008838 : Closed e1131189008838 ∧ code e1131189008838 = 5529235519942 := by decide
theorem cert_e1131189008838 : check e1131189008838 [[],[.under]] .three = true := by decide
def e1131192802166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1131192802166 : Closed e1131192802166 ∧ code e1131192802166 = 5529239313270 := by decide
theorem cert_e1131192802166 : check e1131192802166 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192802230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1131192802230 : Closed e1131192802230 ∧ code e1131192802230 = 5529239313334 := by decide
theorem cert_e1131192802230 : check e1131192802230 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1131192802678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1131192802678 : Closed e1131192802678 ∧ code e1131192802678 = 5529239313782 := by decide
theorem cert_e1131192802678 : check e1131192802678 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192802774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1131192802774 : Closed e1131192802774 ∧ code e1131192802774 = 5529239313878 := by decide
theorem cert_e1131192802774 : check e1131192802774 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192802998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1131192802998 : Closed e1131192802998 ∧ code e1131192802998 = 5529239314102 := by decide
theorem cert_e1131192802998 : check e1131192802998 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192803030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1131192803030 : Closed e1131192803030 ∧ code e1131192803030 = 5529239314134 := by decide
theorem cert_e1131192803030 : check e1131192803030 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192805238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1131192805238 : Closed e1131192805238 ∧ code e1131192805238 = 5529239316342 := by decide
theorem cert_e1131192805238 : check e1131192805238 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192805302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1131192805302 : Closed e1131192805302 ∧ code e1131192805302 = 5529239316406 := by decide
theorem cert_e1131192805302 : check e1131192805302 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192808310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1131192808310 : Closed e1131192808310 ∧ code e1131192808310 = 5529239319414 := by decide
theorem cert_e1131192808310 : check e1131192808310 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1131192808406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1131192808406 : Closed e1131192808406 ∧ code e1131192808406 = 5529239319510 := by decide
theorem cert_e1131192808406 : check e1131192808406 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1131192809910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1131192809910 : Closed e1131192809910 ∧ code e1131192809910 = 5529239321014 := by decide
theorem cert_e1131192809910 : check e1131192809910 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1131192809942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1131192809942 : Closed e1131192809942 ∧ code e1131192809942 = 5529239321046 := by decide
theorem cert_e1131192809942 : check e1131192809942 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e1131192978286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1131192978286 : Closed e1131192978286 ∧ code e1131192978286 = 5529239489390 := by decide
theorem cert_e1131192978286 : check e1131192978286 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192978294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1131192978294 : Closed e1131192978294 ∧ code e1131192978294 = 5529239489398 := by decide
theorem cert_e1131192978294 : check e1131192978294 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192978350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1131192978350 : Closed e1131192978350 ∧ code e1131192978350 = 5529239489454 := by decide
theorem cert_e1131192978350 : check e1131192978350 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left]] .identityHead = true := by decide
def e1131192978362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1131192978362 : Closed e1131192978362 ∧ code e1131192978362 = 5529239489466 := by decide
theorem cert_e1131192978362 : check e1131192978362 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1131192978390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1131192978390 : Closed e1131192978390 ∧ code e1131192978390 = 5529239489494 := by decide
theorem cert_e1131192978390 : check e1131192978390 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e1131192978394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1131192978394 : Closed e1131192978394 ∧ code e1131192978394 = 5529239489498 := by decide
theorem cert_e1131192978394 : check e1131192978394 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e1131192978670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1131192978670 : Closed e1131192978670 ∧ code e1131192978670 = 5529239489774 := by decide
theorem cert_e1131192978670 : check e1131192978670 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192978678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1131192978678 : Closed e1131192978678 ∧ code e1131192978678 = 5529239489782 := by decide
theorem cert_e1131192978678 : check e1131192978678 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131192979054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1131192979054 : Closed e1131192979054 ∧ code e1131192979054 = 5529239490158 := by decide
theorem cert_e1131192979054 : check e1131192979054 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1131192979066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1131192979066 : Closed e1131192979066 ∧ code e1131192979066 = 5529239490170 := by decide
theorem cert_e1131192979066 : check e1131192979066 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left]] .identityHead = true := by decide
def e1131192979254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1131192979254 : Closed e1131192979254 ∧ code e1131192979254 = 5529239490358 := by decide
theorem cert_e1131192979254 : check e1131192979254 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1131192979258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1131192979258 : Closed e1131192979258 ∧ code e1131192979258 = 5529239490362 := by decide
theorem cert_e1131192979258 : check e1131192979258 [[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.under]] .identityHead = true := by decide
def e1131193052602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1131193052602 : Closed e1131193052602 ∧ code e1131193052602 = 5529239563706 := by decide
theorem cert_e1131193052602 : check e1131193052602 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193052634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1131193052634 : Closed e1131193052634 ∧ code e1131193052634 = 5529239563738 := by decide
private def t_e1131193052634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem cert_e1131193052634 : ¬ IsSelfInterpreter e1131193052634 :=
  wSource (t := t_e1131193052634) (replay_sound (ps := []) (t := e1131193052634) (by decide)) (by decide)
def e1131193052858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1131193052858 : Closed e1131193052858 ∧ code e1131193052858 = 5529239563962 := by decide
theorem cert_e1131193052858 : check e1131193052858 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193052906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1131193052906 : Closed e1131193052906 ∧ code e1131193052906 = 5529239564010 := by decide
theorem cert_e1131193052906 : check e1131193052906 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1131193053018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1131193053018 : Closed e1131193053018 ∧ code e1131193053018 = 5529239564122 := by decide
private def t_e1131193053018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem cert_e1131193053018 : ¬ IsSelfInterpreter e1131193053018 :=
  wSource (t := t_e1131193053018) (replay_sound (ps := []) (t := e1131193053018) (by decide)) (by decide)
def e1131193053034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1131193053034 : Closed e1131193053034 ∧ code e1131193053034 = 5529239564138 := by decide
theorem cert_e1131193053034 : check e1131193053034 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193054138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1131193054138 : Closed e1131193054138 ∧ code e1131193054138 = 5529239565242 := by decide
theorem cert_e1131193054138 : check e1131193054138 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e1131193054170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1131193054170 : Closed e1131193054170 ∧ code e1131193054170 = 5529239565274 := by decide
theorem cert_e1131193054170 : check e1131193054170 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193055674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1131193055674 : Closed e1131193055674 ∧ code e1131193055674 = 5529239566778 := by decide
def e1131193055722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1131193055722 : Closed e1131193055722 ∧ code e1131193055722 = 5529239566826 := by decide
def e1131193056474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1131193056474 : Closed e1131193056474 ∧ code e1131193056474 = 5529239567578 := by decide
def e1131193056490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1131193056490 : Closed e1131193056490 ∧ code e1131193056490 = 5529239567594 := by decide
theorem cert_e1131193056490 : check e1131193056490 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1131193109358 : Closed e1131193109358 ∧ code e1131193109358 = 5529239620462 := by decide
theorem cert_e1131193109358 : check e1131193109358 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1131193109366 : Closed e1131193109366 ∧ code e1131193109366 = 5529239620470 := by decide
theorem cert_e1131193109366 : check e1131193109366 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1131193109422 : Closed e1131193109422 ∧ code e1131193109422 = 5529239620526 := by decide
theorem cert_e1131193109422 : check e1131193109422 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .identityHead = true := by decide
def e1131193109434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1131193109434 : Closed e1131193109434 ∧ code e1131193109434 = 5529239620538 := by decide
theorem cert_e1131193109434 : check e1131193109434 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1131193109462 : Closed e1131193109462 ∧ code e1131193109462 = 5529239620566 := by decide
theorem cert_e1131193109462 : check e1131193109462 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1131193109466 : Closed e1131193109466 ∧ code e1131193109466 = 5529239620570 := by decide
theorem cert_e1131193109466 : check e1131193109466 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1131193109742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1131193109742 : Closed e1131193109742 ∧ code e1131193109742 = 5529239620846 := by decide
theorem cert_e1131193109742 : check e1131193109742 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193109750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1131193109750 : Closed e1131193109750 ∧ code e1131193109750 = 5529239620854 := by decide
def e1131193110126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1131193110126 : Closed e1131193110126 ∧ code e1131193110126 = 5529239621230 := by decide
theorem cert_e1131193110126 : check e1131193110126 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193110138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1131193110138 : Closed e1131193110138 ∧ code e1131193110138 = 5529239621242 := by decide
theorem cert_e1131193110138 : check e1131193110138 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193110326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1131193110326 : Closed e1131193110326 ∧ code e1131193110326 = 5529239621430 := by decide
theorem cert_e1131193110326 : check e1131193110326 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193110330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1131193110330 : Closed e1131193110330 ∧ code e1131193110330 = 5529239621434 := by decide
theorem cert_e1131193110330 : check e1131193110330 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193308894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1131193308894 : Closed e1131193308894 ∧ code e1131193308894 = 5529239819998 := by decide
theorem cert_e1131193308894 : check e1131193308894 [[],[.under]] .smaller = true := by decide
def e1131193308918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1131193308918 : Closed e1131193308918 ∧ code e1131193308918 = 5529239820022 := by decide
theorem cert_e1131193308918 : check e1131193308918 [[],[.under]] .smaller = true := by decide
def e1131193309022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1131193309022 : Closed e1131193309022 ∧ code e1131193309022 = 5529239820126 := by decide
theorem cert_e1131193309022 : check e1131193309022 [[],[.under]] .smaller = true := by decide
def e1131193309050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1131193309050 : Closed e1131193309050 ∧ code e1131193309050 = 5529239820154 := by decide
theorem cert_e1131193309050 : check e1131193309050 [[],[.under]] .smaller = true := by decide
def e1131193309142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1131193309142 : Closed e1131193309142 ∧ code e1131193309142 = 5529239820246 := by decide
theorem cert_e1131193309142 : check e1131193309142 [[],[.under]] .smaller = true := by decide
def e1131193309146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1131193309146 : Closed e1131193309146 ∧ code e1131193309146 = 5529239820250 := by decide
theorem cert_e1131193309146 : check e1131193309146 [[],[.under]] .smaller = true := by decide
def e1131193309662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1131193309662 : Closed e1131193309662 ∧ code e1131193309662 = 5529239820766 := by decide
theorem cert_e1131193309662 : check e1131193309662 [[],[.under]] .smaller = true := by decide
def e1131193309686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1131193309686 : Closed e1131193309686 ∧ code e1131193309686 = 5529239820790 := by decide
theorem cert_e1131193309686 : check e1131193309686 [[],[.under]] .smaller = true := by decide
def e1131193310430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1131193310430 : Closed e1131193310430 ∧ code e1131193310430 = 5529239821534 := by decide
theorem cert_e1131193310430 : check e1131193310430 [[],[.under]] .smaller = true := by decide
def e1131193310458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1131193310458 : Closed e1131193310458 ∧ code e1131193310458 = 5529239821562 := by decide
theorem cert_e1131193310458 : check e1131193310458 [[],[.under]] .smaller = true := by decide
def e1131193311030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131193311030 : Closed e1131193311030 ∧ code e1131193311030 = 5529239822134 := by decide
theorem cert_e1131193311030 : check e1131193311030 [[],[.under]] .smaller = true := by decide
def e1131193311034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131193311034 : Closed e1131193311034 ∧ code e1131193311034 = 5529239822138 := by decide
theorem cert_e1131193311034 : check e1131193311034 [[],[.under]] .smaller = true := by decide
def e1131193325806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1131193325806 : Closed e1131193325806 ∧ code e1131193325806 = 5529239836910 := by decide
theorem cert_e1131193325806 : check e1131193325806 [[],[.under]] .smaller = true := by decide
def e1131193325814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1131193325814 : Closed e1131193325814 ∧ code e1131193325814 = 5529239836918 := by decide
theorem cert_e1131193325814 : check e1131193325814 [[],[.under]] .smaller = true := by decide
def e1131193326366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1131193326366 : Closed e1131193326366 ∧ code e1131193326366 = 5529239837470 := by decide
theorem cert_e1131193326366 : check e1131193326366 [[],[.under]] .smaller = true := by decide
def e1131193326478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1131193326478 : Closed e1131193326478 ∧ code e1131193326478 = 5529239837582 := by decide
theorem cert_e1131193326478 : check e1131193326478 [[],[.under]] .smaller = true := by decide
def e1131193326702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1131193326702 : Closed e1131193326702 ∧ code e1131193326702 = 5529239837806 := by decide
theorem cert_e1131193326702 : check e1131193326702 [[],[.under]] .smaller = true := by decide
def e1131193326714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1131193326714 : Closed e1131193326714 ∧ code e1131193326714 = 5529239837818 := by decide
theorem cert_e1131193326714 : check e1131193326714 [[],[.under]] .smaller = true := by decide
def e1131193326878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1131193326878 : Closed e1131193326878 ∧ code e1131193326878 = 5529239837982 := by decide
theorem cert_e1131193326878 : check e1131193326878 [[],[.under]] .smaller = true := by decide
def e1131193327046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1131193327046 : Closed e1131193327046 ∧ code e1131193327046 = 5529239838150 := by decide
theorem cert_e1131193327046 : check e1131193327046 [[],[.under]] .smaller = true := by decide
def e1131193327070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1131193327070 : Closed e1131193327070 ∧ code e1131193327070 = 5529239838174 := by decide
theorem cert_e1131193327070 : check e1131193327070 [[],[.under]] .chain = true := by decide
def e1131193327086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1131193327086 : Closed e1131193327086 ∧ code e1131193327086 = 5529239838190 := by decide
theorem cert_e1131193327086 : check e1131193327086 [[],[.under]] .chain = true := by decide
def e1131193327158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1131193327158 : Closed e1131193327158 ∧ code e1131193327158 = 5529239838262 := by decide
theorem cert_e1131193327158 : check e1131193327158 [[],[.under]] .smaller = true := by decide
def e1131193327162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1131193327162 : Closed e1131193327162 ∧ code e1131193327162 = 5529239838266 := by decide
theorem cert_e1131193327162 : check e1131193327162 [[],[.under]] .smaller = true := by decide
def e1131193327246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1131193327246 : Closed e1131193327246 ∧ code e1131193327246 = 5529239838350 := by decide
theorem cert_e1131193327246 : check e1131193327246 [[],[.under]] .smaller = true := by decide
def e1131193327302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1131193327302 : Closed e1131193327302 ∧ code e1131193327302 = 5529239838406 := by decide
theorem cert_e1131193327302 : check e1131193327302 [[],[.under]] .smaller = true := by decide
def e1131193327326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1131193327326 : Closed e1131193327326 ∧ code e1131193327326 = 5529239838430 := by decide
theorem cert_e1131193327326 : check e1131193327326 [[],[.under]] .chain = true := by decide
def e1131193327350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1131193327350 : Closed e1131193327350 ∧ code e1131193327350 = 5529239838454 := by decide
theorem cert_e1131193327350 : check e1131193327350 [[],[.under]] .chain = true := by decide
def e1131193327470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1131193327470 : Closed e1131193327470 ∧ code e1131193327470 = 5529239838574 := by decide
theorem cert_e1131193327470 : check e1131193327470 [[],[.under]] .chain = true := by decide
def e1131193327478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1131193327478 : Closed e1131193327478 ∧ code e1131193327478 = 5529239838582 := by decide
theorem cert_e1131193327478 : check e1131193327478 [[],[.under]] .chain = true := by decide
def e1131193329438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1131193329438 : Closed e1131193329438 ∧ code e1131193329438 = 5529239840542 := by decide
theorem cert_e1131193329438 : check e1131193329438 [[],[.under]] .smaller = true := by decide
def e1131193329550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1131193329550 : Closed e1131193329550 ∧ code e1131193329550 = 5529239840654 := by decide
theorem cert_e1131193329550 : check e1131193329550 [[],[.under]] .smaller = true := by decide
def e1131193332510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1131193332510 : Closed e1131193332510 ∧ code e1131193332510 = 5529239843614 := by decide
theorem cert_e1131193332510 : check e1131193332510 [[],[.under]] .smaller = true := by decide
def e1131193332678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1131193332678 : Closed e1131193332678 ∧ code e1131193332678 = 5529239843782 := by decide
theorem cert_e1131193332678 : check e1131193332678 [[],[.under]] .smaller = true := by decide
def e1131193332702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1131193332702 : Closed e1131193332702 ∧ code e1131193332702 = 5529239843806 := by decide
theorem cert_e1131193332702 : check e1131193332702 [[],[.under]] .chain = true := by decide
def e1131193332718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1131193332718 : Closed e1131193332718 ∧ code e1131193332718 = 5529239843822 := by decide
theorem cert_e1131193332718 : check e1131193332718 [[],[.under]] .chain = true := by decide
def e1131193334158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1131193334158 : Closed e1131193334158 ∧ code e1131193334158 = 5529239845262 := by decide
theorem cert_e1131193334158 : check e1131193334158 [[],[.under]] .smaller = true := by decide
def e1131193334214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1131193334214 : Closed e1131193334214 ∧ code e1131193334214 = 5529239845318 := by decide
theorem cert_e1131193334214 : check e1131193334214 [[],[.under]] .smaller = true := by decide
def e1131193334238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131193334238 : Closed e1131193334238 ∧ code e1131193334238 = 5529239845342 := by decide
theorem cert_e1131193334238 : check e1131193334238 [[],[.under]] .chain = true := by decide
def e1131193334262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131193334262 : Closed e1131193334262 ∧ code e1131193334262 = 5529239845366 := by decide
theorem cert_e1131193334262 : check e1131193334262 [[],[.under]] .chain = true := by decide
def e1131193335022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131193335022 : Closed e1131193335022 ∧ code e1131193335022 = 5529239846126 := by decide
theorem cert_e1131193335022 : check e1131193335022 [[],[.under]] .chain = true := by decide
def e1131193335030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131193335030 : Closed e1131193335030 ∧ code e1131193335030 = 5529239846134 := by decide
theorem cert_e1131193335030 : check e1131193335030 [[],[.under]] .chain = true := by decide
def e1131193391982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1131193391982 : Closed e1131193391982 ∧ code e1131193391982 = 5529239903086 := by decide
theorem cert_e1131193391982 : check e1131193391982 [[],[.under]] .chain = true := by decide
def e1131193391990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1131193391990 : Closed e1131193391990 ∧ code e1131193391990 = 5529239903094 := by decide
theorem cert_e1131193391990 : check e1131193391990 [[],[.under]] .chain = true := by decide
def e1131193392054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1131193392054 : Closed e1131193392054 ∧ code e1131193392054 = 5529239903158 := by decide
theorem cert_e1131193392054 : check e1131193392054 [[],[.under]] .chain = true := by decide
def e1131193392494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1131193392494 : Closed e1131193392494 ∧ code e1131193392494 = 5529239903598 := by decide
theorem cert_e1131193392494 : check e1131193392494 [[],[.under]] .chain = true := by decide
def e1131193392502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1131193392502 : Closed e1131193392502 ∧ code e1131193392502 = 5529239903606 := by decide
theorem cert_e1131193392502 : check e1131193392502 [[],[.under]] .chain = true := by decide
def e1131193392558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1131193392558 : Closed e1131193392558 ∧ code e1131193392558 = 5529239903662 := by decide
theorem cert_e1131193392558 : check e1131193392558 [[],[.under]] .chain = true := by decide
def e1131193392570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1131193392570 : Closed e1131193392570 ∧ code e1131193392570 = 5529239903674 := by decide
theorem cert_e1131193392570 : check e1131193392570 [[],[.under]] .chain = true := by decide
def e1131193392598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1131193392598 : Closed e1131193392598 ∧ code e1131193392598 = 5529239903702 := by decide
theorem cert_e1131193392598 : check e1131193392598 [[],[.under]] .chain = true := by decide
def e1131193392602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1131193392602 : Closed e1131193392602 ∧ code e1131193392602 = 5529239903706 := by decide
theorem cert_e1131193392602 : check e1131193392602 [[],[.under]] .chain = true := by decide
def e1131193392822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1131193392822 : Closed e1131193392822 ∧ code e1131193392822 = 5529239903926 := by decide
theorem cert_e1131193392822 : check e1131193392822 [[],[.under]] .chain = true := by decide
def e1131193392854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1131193392854 : Closed e1131193392854 ∧ code e1131193392854 = 5529239903958 := by decide
theorem cert_e1131193392854 : check e1131193392854 [[],[.under]] .chain = true := by decide
def e1131193392858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1131193392858 : Closed e1131193392858 ∧ code e1131193392858 = 5529239903962 := by decide
theorem cert_e1131193392858 : check e1131193392858 [[],[.under]] .chain = true := by decide
def e1131193395054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1131193395054 : Closed e1131193395054 ∧ code e1131193395054 = 5529239906158 := by decide
theorem cert_e1131193395054 : check e1131193395054 [[],[.under]] .chain = true := by decide
def e1131193395062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1131193395062 : Closed e1131193395062 ∧ code e1131193395062 = 5529239906166 := by decide
theorem cert_e1131193395062 : check e1131193395062 [[],[.under]] .chain = true := by decide
def e1131193395126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1131193395126 : Closed e1131193395126 ∧ code e1131193395126 = 5529239906230 := by decide
theorem cert_e1131193395126 : check e1131193395126 [[],[.under]] .chain = true := by decide
def e1131193396462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131193396462 : Closed e1131193396462 ∧ code e1131193396462 = 5529239907566 := by decide
theorem cert_e1131193396462 : check e1131193396462 [[],[.under]] .chain = true := by decide
def e1131193396470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131193396470 : Closed e1131193396470 ∧ code e1131193396470 = 5529239907574 := by decide
theorem cert_e1131193396470 : check e1131193396470 [[],[.under]] .chain = true := by decide
def e1131193396854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131193396854 : Closed e1131193396854 ∧ code e1131193396854 = 5529239907958 := by decide
theorem cert_e1131193396854 : check e1131193396854 [[],[.under]] .chain = true := by decide
def e1131193398126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1131193398126 : Closed e1131193398126 ∧ code e1131193398126 = 5529239909230 := by decide
theorem cert_e1131193398126 : check e1131193398126 [[],[.under]] .chain = true := by decide
def e1131193398134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1131193398134 : Closed e1131193398134 ∧ code e1131193398134 = 5529239909238 := by decide
theorem cert_e1131193398134 : check e1131193398134 [[],[.under]] .chain = true := by decide
def e1131193398190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1131193398190 : Closed e1131193398190 ∧ code e1131193398190 = 5529239909294 := by decide
theorem cert_e1131193398190 : check e1131193398190 [[],[.under]] .chain = true := by decide
def e1131193398202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1131193398202 : Closed e1131193398202 ∧ code e1131193398202 = 5529239909306 := by decide
theorem cert_e1131193398202 : check e1131193398202 [[],[.under]] .chain = true := by decide
def e1131193398230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1131193398230 : Closed e1131193398230 ∧ code e1131193398230 = 5529239909334 := by decide
theorem cert_e1131193398230 : check e1131193398230 [[],[.under]] .chain = true := by decide
def e1131193398234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1131193398234 : Closed e1131193398234 ∧ code e1131193398234 = 5529239909338 := by decide
theorem cert_e1131193398234 : check e1131193398234 [[],[.under]] .chain = true := by decide
def e1131193398510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131193398510 : Closed e1131193398510 ∧ code e1131193398510 = 5529239909614 := by decide
theorem cert_e1131193398510 : check e1131193398510 [[],[.under]] .chain = true := by decide
def e1131193398518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131193398518 : Closed e1131193398518 ∧ code e1131193398518 = 5529239909622 := by decide
theorem cert_e1131193398518 : check e1131193398518 [[],[.under]] .chain = true := by decide
def e1131193398894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131193398894 : Closed e1131193398894 ∧ code e1131193398894 = 5529239909998 := by decide
theorem cert_e1131193398894 : check e1131193398894 [[],[.under]] .chain = true := by decide
def e1131193398906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131193398906 : Closed e1131193398906 ∧ code e1131193398906 = 5529239910010 := by decide
theorem cert_e1131193398906 : check e1131193398906 [[],[.under]] .chain = true := by decide
def e1131193399094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131193399094 : Closed e1131193399094 ∧ code e1131193399094 = 5529239910198 := by decide
theorem cert_e1131193399094 : check e1131193399094 [[],[.under]] .chain = true := by decide
def e1131193399098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131193399098 : Closed e1131193399098 ∧ code e1131193399098 = 5529239910202 := by decide
theorem cert_e1131193399098 : check e1131193399098 [[],[.under]] .chain = true := by decide
def e1131193399734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1131193399734 : Closed e1131193399734 ∧ code e1131193399734 = 5529239910838 := by decide
theorem cert_e1131193399734 : check e1131193399734 [[],[.under]] .chain = true := by decide
def e1131193399766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1131193399766 : Closed e1131193399766 ∧ code e1131193399766 = 5529239910870 := by decide
theorem cert_e1131193399766 : check e1131193399766 [[],[.under]] .chain = true := by decide
def e1131193399770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1131193399770 : Closed e1131193399770 ∧ code e1131193399770 = 5529239910874 := by decide
theorem cert_e1131193399770 : check e1131193399770 [[],[.under]] .chain = true := by decide
def e1131193399926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131193399926 : Closed e1131193399926 ∧ code e1131193399926 = 5529239911030 := by decide
theorem cert_e1131193399926 : check e1131193399926 [[],[.under]] .chain = true := by decide
def e1131193400118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131193400118 : Closed e1131193400118 ∧ code e1131193400118 = 5529239911222 := by decide
theorem cert_e1131193400118 : check e1131193400118 [[],[.under]] .chain = true := by decide
def e1131193400122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131193400122 : Closed e1131193400122 ∧ code e1131193400122 = 5529239911226 := by decide
theorem cert_e1131193400122 : check e1131193400122 [[],[.under]] .chain = true := by decide
def e1131193407342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1131193407342 : Closed e1131193407342 ∧ code e1131193407342 = 5529239918446 := by decide
theorem cert_e1131193407342 : check e1131193407342 [[],[.under]] .chain = true := by decide
def e1131193407350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1131193407350 : Closed e1131193407350 ∧ code e1131193407350 = 5529239918454 := by decide
theorem cert_e1131193407350 : check e1131193407350 [[],[.under]] .chain = true := by decide
def e1131193407414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1131193407414 : Closed e1131193407414 ∧ code e1131193407414 = 5529239918518 := by decide
theorem cert_e1131193407414 : check e1131193407414 [[],[.under]] .chain = true := by decide
def e1131193408750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131193408750 : Closed e1131193408750 ∧ code e1131193408750 = 5529239919854 := by decide
theorem cert_e1131193408750 : check e1131193408750 [[],[.under]] .chain = true := by decide
end Blc.Floor42
