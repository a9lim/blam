import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e431241664374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e431241664374 : Closed e431241664374 ∧ code e431241664374 = 4829288175478 := by decide
theorem cert_e431241664374 : check e431241664374 [] .sourceHead = true := by decide
def e431241664378 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e431241664378 : Closed e431241664378 ∧ code e431241664378 = 4829288175482 := by decide
theorem cert_e431241664378 : check e431241664378 [] .sourceHead = true := by decide
def e431241664438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e431241664438 : Closed e431241664438 ∧ code e431241664438 = 4829288175542 := by decide
theorem cert_e431241664438 : check e431241664438 [] .sourceHead = true := by decide
def e431241664470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e431241664470 : Closed e431241664470 ∧ code e431241664470 = 4829288175574 := by decide
theorem cert_e431241664470 : check e431241664470 [] .sourceHead = true := by decide
def e431241664474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e431241664474 : Closed e431241664474 ∧ code e431241664474 = 4829288175578 := by decide
theorem cert_e431241664474 : check e431241664474 [] .sourceHead = true := by decide
def e431241664990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e431241664990 : Closed e431241664990 ∧ code e431241664990 = 4829288176094 := by decide
theorem cert_e431241664990 : check e431241664990 [] .sourceHead = true := by decide
def e431241665014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e431241665014 : Closed e431241665014 ∧ code e431241665014 = 4829288176118 := by decide
theorem cert_e431241665014 : check e431241665014 [] .sourceHead = true := by decide
def e431241665758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e431241665758 : Closed e431241665758 ∧ code e431241665758 = 4829288176862 := by decide
theorem cert_e431241665758 : check e431241665758 [] .sourceHead = true := by decide
def e431241665774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e431241665774 : Closed e431241665774 ∧ code e431241665774 = 4829288176878 := by decide
theorem cert_e431241665774 : check e431241665774 [] .sourceHead = true := by decide
def e431241665782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e431241665782 : Closed e431241665782 ∧ code e431241665782 = 4829288176886 := by decide
theorem cert_e431241665782 : check e431241665782 [] .sourceHead = true := by decide
def e431241665786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e431241665786 : Closed e431241665786 ∧ code e431241665786 = 4829288176890 := by decide
theorem cert_e431241665786 : check e431241665786 [] .sourceHead = true := by decide
def e431241666166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e431241666166 : Closed e431241666166 ∧ code e431241666166 = 4829288177270 := by decide
theorem cert_e431241666166 : check e431241666166 [] .sourceHead = true := by decide
def e431241666358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431241666358 : Closed e431241666358 ∧ code e431241666358 = 4829288177462 := by decide
theorem cert_e431241666358 : check e431241666358 [] .sourceHead = true := by decide
def e431241666362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431241666362 : Closed e431241666362 ∧ code e431241666362 = 4829288177466 := by decide
theorem cert_e431241666362 : check e431241666362 [] .sourceHead = true := by decide
def e431241677662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e431241677662 : Closed e431241677662 ∧ code e431241677662 = 4829288188766 := by decide
theorem cert_e431241677662 : check e431241677662 [] .sourceHead = true := by decide
def e431241677678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e431241677678 : Closed e431241677678 ∧ code e431241677678 = 4829288188782 := by decide
theorem cert_e431241677678 : check e431241677678 [] .sourceHead = true := by decide
def e431241677686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e431241677686 : Closed e431241677686 ∧ code e431241677686 = 4829288188790 := by decide
theorem cert_e431241677686 : check e431241677686 [] .sourceHead = true := by decide
def e431241677690 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e431241677690 : Closed e431241677690 ∧ code e431241677690 = 4829288188794 := by decide
theorem cert_e431241677690 : check e431241677690 [] .sourceHead = true := by decide
def e431241677742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e431241677742 : Closed e431241677742 ∧ code e431241677742 = 4829288188846 := by decide
theorem cert_e431241677742 : check e431241677742 [] .sourceHead = true := by decide
def e431241677754 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e431241677754 : Closed e431241677754 ∧ code e431241677754 = 4829288188858 := by decide
theorem cert_e431241677754 : check e431241677754 [] .sourceHead = true := by decide
def e431241677782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e431241677782 : Closed e431241677782 ∧ code e431241677782 = 4829288188886 := by decide
theorem cert_e431241677782 : check e431241677782 [] .sourceHead = true := by decide
def e431241677786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e431241677786 : Closed e431241677786 ∧ code e431241677786 = 4829288188890 := by decide
theorem cert_e431241677786 : check e431241677786 [] .sourceHead = true := by decide
def e431241677802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e431241677802 : Closed e431241677802 ∧ code e431241677802 = 4829288188906 := by decide
theorem cert_e431241677802 : check e431241677802 [] .sourceHead = true := by decide
def e431241678046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e431241678046 : Closed e431241678046 ∧ code e431241678046 = 4829288189150 := by decide
theorem cert_e431241678046 : check e431241678046 [] .sourceHead = true := by decide
def e431241678062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e431241678062 : Closed e431241678062 ∧ code e431241678062 = 4829288189166 := by decide
theorem cert_e431241678062 : check e431241678062 [] .sourceHead = true := by decide
def e431241678070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e431241678070 : Closed e431241678070 ∧ code e431241678070 = 4829288189174 := by decide
theorem cert_e431241678070 : check e431241678070 [] .sourceHead = true := by decide
def e431241678074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e431241678074 : Closed e431241678074 ∧ code e431241678074 = 4829288189178 := by decide
theorem cert_e431241678074 : check e431241678074 [] .sourceHead = true := by decide
def e431241678446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e431241678446 : Closed e431241678446 ∧ code e431241678446 = 4829288189550 := by decide
theorem cert_e431241678446 : check e431241678446 [] .sourceHead = true := by decide
def e431241678458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e431241678458 : Closed e431241678458 ∧ code e431241678458 = 4829288189562 := by decide
theorem cert_e431241678458 : check e431241678458 [] .sourceHead = true := by decide
def e431241678646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431241678646 : Closed e431241678646 ∧ code e431241678646 = 4829288189750 := by decide
theorem cert_e431241678646 : check e431241678646 [] .sourceHead = true := by decide
def e431241678650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431241678650 : Closed e431241678650 ∧ code e431241678650 = 4829288189754 := by decide
theorem cert_e431241678650 : check e431241678650 [] .sourceHead = true := by decide
def e431241678746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e431241678746 : Closed e431241678746 ∧ code e431241678746 = 4829288189850 := by decide
theorem cert_e431241678746 : check e431241678746 [] .sourceHead = true := by decide
def e431241684406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e431241684406 : Closed e431241684406 ∧ code e431241684406 = 4829288195510 := by decide
theorem cert_e431241684406 : check e431241684406 [] .sourceHead = true := by decide
def e431241684438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e431241684438 : Closed e431241684438 ∧ code e431241684438 = 4829288195542 := by decide
theorem cert_e431241684438 : check e431241684438 [] .sourceHead = true := by decide
def e431241684442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e431241684442 : Closed e431241684442 ∧ code e431241684442 = 4829288195546 := by decide
theorem cert_e431241684442 : check e431241684442 [] .sourceHead = true := by decide
def e431241684598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e431241684598 : Closed e431241684598 ∧ code e431241684598 = 4829288195702 := by decide
theorem cert_e431241684598 : check e431241684598 [] .sourceHead = true := by decide
def e431241684790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431241684790 : Closed e431241684790 ∧ code e431241684790 = 4829288195894 := by decide
theorem cert_e431241684790 : check e431241684790 [] .sourceHead = true := by decide
def e431241684794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431241684794 : Closed e431241684794 ∧ code e431241684794 = 4829288195898 := by decide
theorem cert_e431241684794 : check e431241684794 [] .sourceHead = true := by decide
def e431241687766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e431241687766 : Closed e431241687766 ∧ code e431241687766 = 4829288198870 := by decide
theorem cert_e431241687766 : check e431241687766 [] .sourceHead = true := by decide
def e431241687770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e431241687770 : Closed e431241687770 ∧ code e431241687770 = 4829288198874 := by decide
theorem cert_e431241687770 : check e431241687770 [] .sourceHead = true := by decide
def e431241687786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e431241687786 : Closed e431241687786 ∧ code e431241687786 = 4829288198890 := by decide
theorem cert_e431241687786 : check e431241687786 [] .sourceHead = true := by decide
def e431241687862 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431241687862 : Closed e431241687862 ∧ code e431241687862 = 4829288198966 := by decide
theorem cert_e431241687862 : check e431241687862 [] .sourceHead = true := by decide
def e431241687866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431241687866 : Closed e431241687866 ∧ code e431241687866 = 4829288198970 := by decide
theorem cert_e431241687866 : check e431241687866 [] .sourceHead = true := by decide
def e431241687962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e431241687962 : Closed e431241687962 ∧ code e431241687962 = 4829288199066 := by decide
theorem cert_e431241687962 : check e431241687962 [] .sourceHead = true := by decide
def e431241913198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e431241913198 : Closed e431241913198 ∧ code e431241913198 = 4829288424302 := by decide
theorem cert_e431241913198 : check e431241913198 [] .sourceHead = true := by decide
def e431241913206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e431241913206 : Closed e431241913206 ∧ code e431241913206 = 4829288424310 := by decide
theorem cert_e431241913206 : check e431241913206 [] .sourceHead = true := by decide
def e431241913262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e431241913262 : Closed e431241913262 ∧ code e431241913262 = 4829288424366 := by decide
theorem cert_e431241913262 : check e431241913262 [] .sourceHead = true := by decide
def e431241913274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e431241913274 : Closed e431241913274 ∧ code e431241913274 = 4829288424378 := by decide
theorem cert_e431241913274 : check e431241913274 [] .sourceHead = true := by decide
def e431241913302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e431241913302 : Closed e431241913302 ∧ code e431241913302 = 4829288424406 := by decide
theorem cert_e431241913302 : check e431241913302 [] .sourceHead = true := by decide
def e431241913306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e431241913306 : Closed e431241913306 ∧ code e431241913306 = 4829288424410 := by decide
theorem cert_e431241913306 : check e431241913306 [] .sourceHead = true := by decide
def e431241914606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e431241914606 : Closed e431241914606 ∧ code e431241914606 = 4829288425710 := by decide
theorem cert_e431241914606 : check e431241914606 [] .sourceHead = true := by decide
def e431241914614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e431241914614 : Closed e431241914614 ∧ code e431241914614 = 4829288425718 := by decide
theorem cert_e431241914614 : check e431241914614 [] .sourceHead = true := by decide
def e431241915166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e431241915166 : Closed e431241915166 ∧ code e431241915166 = 4829288426270 := by decide
theorem cert_e431241915166 : check e431241915166 [] .sourceHead = true := by decide
def e431241915278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e431241915278 : Closed e431241915278 ∧ code e431241915278 = 4829288426382 := by decide
theorem cert_e431241915278 : check e431241915278 [] .sourceHead = true := by decide
def e431241915502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e431241915502 : Closed e431241915502 ∧ code e431241915502 = 4829288426606 := by decide
theorem cert_e431241915502 : check e431241915502 [] .sourceHead = true := by decide
def e431241915514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e431241915514 : Closed e431241915514 ∧ code e431241915514 = 4829288426618 := by decide
theorem cert_e431241915514 : check e431241915514 [] .sourceHead = true := by decide
def e431241915678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e431241915678 : Closed e431241915678 ∧ code e431241915678 = 4829288426782 := by decide
theorem cert_e431241915678 : check e431241915678 [] .sourceHead = true := by decide
def e431241915846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e431241915846 : Closed e431241915846 ∧ code e431241915846 = 4829288426950 := by decide
theorem cert_e431241915846 : check e431241915846 [] .sourceHead = true := by decide
def e431241915958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e431241915958 : Closed e431241915958 ∧ code e431241915958 = 4829288427062 := by decide
theorem cert_e431241915958 : check e431241915958 [] .sourceHead = true := by decide
def e431241915962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e431241915962 : Closed e431241915962 ∧ code e431241915962 = 4829288427066 := by decide
theorem cert_e431241915962 : check e431241915962 [] .sourceHead = true := by decide
def e431241916046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e431241916046 : Closed e431241916046 ∧ code e431241916046 = 4829288427150 := by decide
theorem cert_e431241916046 : check e431241916046 [] .sourceHead = true := by decide
def e431241916102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e431241916102 : Closed e431241916102 ∧ code e431241916102 = 4829288427206 := by decide
theorem cert_e431241916102 : check e431241916102 [] .sourceHead = true := by decide
def e431241916846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e431241916846 : Closed e431241916846 ∧ code e431241916846 = 4829288427950 := by decide
theorem cert_e431241916846 : check e431241916846 [] .sourceHead = true := by decide
def e431241916858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e431241916858 : Closed e431241916858 ∧ code e431241916858 = 4829288427962 := by decide
theorem cert_e431241916858 : check e431241916858 [] .sourceHead = true := by decide
def e431241916906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e431241916906 : Closed e431241916906 ∧ code e431241916906 = 4829288428010 := by decide
theorem cert_e431241916906 : check e431241916906 [] .sourceHead = true := by decide
def e431241917550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e431241917550 : Closed e431241917550 ∧ code e431241917550 = 4829288428654 := by decide
theorem cert_e431241917550 : check e431241917550 [] .sourceHead = true := by decide
def e431241917562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e431241917562 : Closed e431241917562 ∧ code e431241917562 = 4829288428666 := by decide
theorem cert_e431241917562 : check e431241917562 [] .sourceHead = true := by decide
def e431241917726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e431241917726 : Closed e431241917726 ∧ code e431241917726 = 4829288428830 := by decide
theorem cert_e431241917726 : check e431241917726 [] .sourceHead = true := by decide
def e431241917894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e431241917894 : Closed e431241917894 ∧ code e431241917894 = 4829288428998 := by decide
theorem cert_e431241917894 : check e431241917894 [] .sourceHead = true := by decide
def e431241918234 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e431241918234 : Closed e431241918234 ∧ code e431241918234 = 4829288429338 := by decide
theorem cert_e431241918234 : check e431241918234 [] .sourceHead = true := by decide
def e431241918278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e431241918278 : Closed e431241918278 ∧ code e431241918278 = 4829288429382 := by decide
theorem cert_e431241918278 : check e431241918278 [] .sourceHead = true := by decide
def e431241918678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e431241918678 : Closed e431241918678 ∧ code e431241918678 = 4829288429782 := by decide
theorem cert_e431241918678 : check e431241918678 [] .sourceHead = true := by decide
def e431241918682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e431241918682 : Closed e431241918682 ∧ code e431241918682 = 4829288429786 := by decide
theorem cert_e431241918682 : check e431241918682 [] .sourceHead = true := by decide
def e431241918698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e431241918698 : Closed e431241918698 ∧ code e431241918698 = 4829288429802 := by decide
theorem cert_e431241918698 : check e431241918698 [] .sourceHead = true := by decide
def e431241919030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e431241919030 : Closed e431241919030 ∧ code e431241919030 = 4829288430134 := by decide
theorem cert_e431241919030 : check e431241919030 [] .sourceHead = true := by decide
def e431241919034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e431241919034 : Closed e431241919034 ∧ code e431241919034 = 4829288430138 := by decide
theorem cert_e431241919034 : check e431241919034 [] .sourceHead = true := by decide
def e431241919118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e431241919118 : Closed e431241919118 ∧ code e431241919118 = 4829288430222 := by decide
theorem cert_e431241919118 : check e431241919118 [] .sourceHead = true := by decide
def e431241919174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e431241919174 : Closed e431241919174 ∧ code e431241919174 = 4829288430278 := by decide
theorem cert_e431241919174 : check e431241919174 [] .sourceHead = true := by decide
def e431241919258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e431241919258 : Closed e431241919258 ∧ code e431241919258 = 4829288430362 := by decide
theorem cert_e431241919258 : check e431241919258 [] .sourceHead = true := by decide
def e431241919302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e431241919302 : Closed e431241919302 ∧ code e431241919302 = 4829288430406 := by decide
theorem cert_e431241919302 : check e431241919302 [] .sourceHead = true := by decide
def e431241923822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e431241923822 : Closed e431241923822 ∧ code e431241923822 = 4829288434926 := by decide
theorem cert_e431241923822 : check e431241923822 [] .sourceHead = true := by decide
def e431241923830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e431241923830 : Closed e431241923830 ∧ code e431241923830 = 4829288434934 := by decide
theorem cert_e431241923830 : check e431241923830 [] .sourceHead = true := by decide
def e431241924206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e431241924206 : Closed e431241924206 ∧ code e431241924206 = 4829288435310 := by decide
theorem cert_e431241924206 : check e431241924206 [] .sourceHead = true := by decide
def e431241924218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e431241924218 : Closed e431241924218 ∧ code e431241924218 = 4829288435322 := by decide
theorem cert_e431241924218 : check e431241924218 [] .sourceHead = true := by decide
def e431241924406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e431241924406 : Closed e431241924406 ∧ code e431241924406 = 4829288435510 := by decide
theorem cert_e431241924406 : check e431241924406 [] .sourceHead = true := by decide
def e431241924410 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e431241924410 : Closed e431241924410 ∧ code e431241924410 = 4829288435514 := by decide
theorem cert_e431241924410 : check e431241924410 [] .sourceHead = true := by decide
def e431241926894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e431241926894 : Closed e431241926894 ∧ code e431241926894 = 4829288437998 := by decide
theorem cert_e431241926894 : check e431241926894 [] .sourceHead = true := by decide
def e431241926902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e431241926902 : Closed e431241926902 ∧ code e431241926902 = 4829288438006 := by decide
theorem cert_e431241926902 : check e431241926902 [] .sourceHead = true := by decide
def e431241927454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e431241927454 : Closed e431241927454 ∧ code e431241927454 = 4829288438558 := by decide
theorem cert_e431241927454 : check e431241927454 [] .sourceHead = true := by decide
def e431241927566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e431241927566 : Closed e431241927566 ∧ code e431241927566 = 4829288438670 := by decide
theorem cert_e431241927566 : check e431241927566 [] .sourceHead = true := by decide
def e431241927790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e431241927790 : Closed e431241927790 ∧ code e431241927790 = 4829288438894 := by decide
theorem cert_e431241927790 : check e431241927790 [] .sourceHead = true := by decide
def e431241927802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e431241927802 : Closed e431241927802 ∧ code e431241927802 = 4829288438906 := by decide
theorem cert_e431241927802 : check e431241927802 [] .sourceHead = true := by decide
def e431241927966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e431241927966 : Closed e431241927966 ∧ code e431241927966 = 4829288439070 := by decide
theorem cert_e431241927966 : check e431241927966 [] .sourceHead = true := by decide
def e431241928134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e431241928134 : Closed e431241928134 ∧ code e431241928134 = 4829288439238 := by decide
theorem cert_e431241928134 : check e431241928134 [] .sourceHead = true := by decide
def e431241928246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e431241928246 : Closed e431241928246 ∧ code e431241928246 = 4829288439350 := by decide
theorem cert_e431241928246 : check e431241928246 [] .sourceHead = true := by decide
def e431241928250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e431241928250 : Closed e431241928250 ∧ code e431241928250 = 4829288439354 := by decide
theorem cert_e431241928250 : check e431241928250 [] .sourceHead = true := by decide
def e431241928334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e431241928334 : Closed e431241928334 ∧ code e431241928334 = 4829288439438 := by decide
theorem cert_e431241928334 : check e431241928334 [] .sourceHead = true := by decide
def e431241928390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e431241928390 : Closed e431241928390 ∧ code e431241928390 = 4829288439494 := by decide
theorem cert_e431241928390 : check e431241928390 [] .sourceHead = true := by decide
def e431241930526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e431241930526 : Closed e431241930526 ∧ code e431241930526 = 4829288441630 := by decide
theorem cert_e431241930526 : check e431241930526 [] .sourceHead = true := by decide
def e431241930638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e431241930638 : Closed e431241930638 ∧ code e431241930638 = 4829288441742 := by decide
theorem cert_e431241930638 : check e431241930638 [] .sourceHead = true := by decide
def e431241933598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e431241933598 : Closed e431241933598 ∧ code e431241933598 = 4829288444702 := by decide
theorem cert_e431241933598 : check e431241933598 [] .sourceHead = true := by decide
def e431241933766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e431241933766 : Closed e431241933766 ∧ code e431241933766 = 4829288444870 := by decide
theorem cert_e431241933766 : check e431241933766 [] .sourceHead = true := by decide
def e431241935246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e431241935246 : Closed e431241935246 ∧ code e431241935246 = 4829288446350 := by decide
theorem cert_e431241935246 : check e431241935246 [] .sourceHead = true := by decide
def e431241935302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e431241935302 : Closed e431241935302 ∧ code e431241935302 = 4829288446406 := by decide
theorem cert_e431241935302 : check e431241935302 [] .sourceHead = true := by decide
def e431241938542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e431241938542 : Closed e431241938542 ∧ code e431241938542 = 4829288449646 := by decide
theorem cert_e431241938542 : check e431241938542 [] .sourceHead = true := by decide
def e431241938554 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e431241938554 : Closed e431241938554 ∧ code e431241938554 = 4829288449658 := by decide
theorem cert_e431241938554 : check e431241938554 [] .sourceHead = true := by decide
def e431241938842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e431241938842 : Closed e431241938842 ∧ code e431241938842 = 4829288449946 := by decide
theorem cert_e431241938842 : check e431241938842 [] .sourceHead = true := by decide
def e431241940078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e431241940078 : Closed e431241940078 ∧ code e431241940078 = 4829288451182 := by decide
theorem cert_e431241940078 : check e431241940078 [] .sourceHead = true := by decide
def e431241940090 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e431241940090 : Closed e431241940090 ∧ code e431241940090 = 4829288451194 := by decide
theorem cert_e431241940090 : check e431241940090 [] .sourceHead = true := by decide
def e431241940254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e431241940254 : Closed e431241940254 ∧ code e431241940254 = 4829288451358 := by decide
theorem cert_e431241940254 : check e431241940254 [] .sourceHead = true := by decide
def e431241940422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e431241940422 : Closed e431241940422 ∧ code e431241940422 = 4829288451526 := by decide
theorem cert_e431241940422 : check e431241940422 [] .sourceHead = true := by decide
def e431241940762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e431241940762 : Closed e431241940762 ∧ code e431241940762 = 4829288451866 := by decide
theorem cert_e431241940762 : check e431241940762 [] .sourceHead = true := by decide
def e431241940806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e431241940806 : Closed e431241940806 ∧ code e431241940806 = 4829288451910 := by decide
theorem cert_e431241940806 : check e431241940806 [] .sourceHead = true := by decide
def e431241941790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e431241941790 : Closed e431241941790 ∧ code e431241941790 = 4829288452894 := by decide
theorem cert_e431241941790 : check e431241941790 [] .sourceHead = true := by decide
def e431241941958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e431241941958 : Closed e431241941958 ∧ code e431241941958 = 4829288453062 := by decide
theorem cert_e431241941958 : check e431241941958 [] .sourceHead = true := by decide
def e431241944262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e431241944262 : Closed e431241944262 ∧ code e431241944262 = 4829288455366 := by decide
theorem cert_e431241944262 : check e431241944262 [] .sourceHead = true := by decide
def e431241945910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e431241945910 : Closed e431241945910 ∧ code e431241945910 = 4829288457014 := by decide
theorem cert_e431241945910 : check e431241945910 [] .sourceHead = true := by decide
def e431241945914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e431241945914 : Closed e431241945914 ∧ code e431241945914 = 4829288457018 := by decide
theorem cert_e431241945914 : check e431241945914 [] .sourceHead = true := by decide
def e431241946010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e431241946010 : Closed e431241946010 ∧ code e431241946010 = 4829288457114 := by decide
theorem cert_e431241946010 : check e431241946010 [] .sourceHead = true := by decide
def e431241946678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e431241946678 : Closed e431241946678 ∧ code e431241946678 = 4829288457782 := by decide
theorem cert_e431241946678 : check e431241946678 [] .sourceHead = true := by decide
def e431241946682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e431241946682 : Closed e431241946682 ∧ code e431241946682 = 4829288457786 := by decide
theorem cert_e431241946682 : check e431241946682 [] .sourceHead = true := by decide
def e431241946766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e431241946766 : Closed e431241946766 ∧ code e431241946766 = 4829288457870 := by decide
theorem cert_e431241946766 : check e431241946766 [] .sourceHead = true := by decide
def e431241946822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e431241946822 : Closed e431241946822 ∧ code e431241946822 = 4829288457926 := by decide
theorem cert_e431241946822 : check e431241946822 [] .sourceHead = true := by decide
def e431241946906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e431241946906 : Closed e431241946906 ∧ code e431241946906 = 4829288458010 := by decide
theorem cert_e431241946906 : check e431241946906 [] .sourceHead = true := by decide
def e431241946950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e431241946950 : Closed e431241946950 ∧ code e431241946950 = 4829288458054 := by decide
theorem cert_e431241946950 : check e431241946950 [] .sourceHead = true := by decide
def e431241947534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e431241947534 : Closed e431241947534 ∧ code e431241947534 = 4829288458638 := by decide
theorem cert_e431241947534 : check e431241947534 [] .sourceHead = true := by decide
def e431241947590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e431241947590 : Closed e431241947590 ∧ code e431241947590 = 4829288458694 := by decide
theorem cert_e431241947590 : check e431241947590 [] .sourceHead = true := by decide
def e431241948358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e431241948358 : Closed e431241948358 ∧ code e431241948358 = 4829288459462 := by decide
theorem cert_e431241948358 : check e431241948358 [] .sourceHead = true := by decide
def e431241959134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e431241959134 : Closed e431241959134 ∧ code e431241959134 = 4829288470238 := by decide
theorem cert_e431241959134 : check e431241959134 [] .sourceHead = true := by decide
def e431241959158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e431241959158 : Closed e431241959158 ∧ code e431241959158 = 4829288470262 := by decide
theorem cert_e431241959158 : check e431241959158 [] .sourceHead = true := by decide
def e431241959262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e431241959262 : Closed e431241959262 ∧ code e431241959262 = 4829288470366 := by decide
theorem cert_e431241959262 : check e431241959262 [] .sourceHead = true := by decide
def e431241959290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e431241959290 : Closed e431241959290 ∧ code e431241959290 = 4829288470394 := by decide
theorem cert_e431241959290 : check e431241959290 [] .sourceHead = true := by decide
def e431241959382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e431241959382 : Closed e431241959382 ∧ code e431241959382 = 4829288470486 := by decide
theorem cert_e431241959382 : check e431241959382 [] .sourceHead = true := by decide
def e431241959386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e431241959386 : Closed e431241959386 ∧ code e431241959386 = 4829288470490 := by decide
theorem cert_e431241959386 : check e431241959386 [] .sourceHead = true := by decide
def e431241959902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e431241959902 : Closed e431241959902 ∧ code e431241959902 = 4829288471006 := by decide
theorem cert_e431241959902 : check e431241959902 [] .sourceHead = true := by decide
def e431241959926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e431241959926 : Closed e431241959926 ∧ code e431241959926 = 4829288471030 := by decide
theorem cert_e431241959926 : check e431241959926 [] .sourceHead = true := by decide
def e431241960670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e431241960670 : Closed e431241960670 ∧ code e431241960670 = 4829288471774 := by decide
theorem cert_e431241960670 : check e431241960670 [] .sourceHead = true := by decide
def e431241960698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e431241960698 : Closed e431241960698 ∧ code e431241960698 = 4829288471802 := by decide
theorem cert_e431241960698 : check e431241960698 [] .sourceHead = true := by decide
def e431241961270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431241961270 : Closed e431241961270 ∧ code e431241961270 = 4829288472374 := by decide
theorem cert_e431241961270 : check e431241961270 [] .sourceHead = true := by decide
def e431241961274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431241961274 : Closed e431241961274 ∧ code e431241961274 = 4829288472378 := by decide
theorem cert_e431241961274 : check e431241961274 [] .sourceHead = true := by decide
def e431241976046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e431241976046 : Closed e431241976046 ∧ code e431241976046 = 4829288487150 := by decide
theorem cert_e431241976046 : check e431241976046 [] .sourceHead = true := by decide
def e431241976054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e431241976054 : Closed e431241976054 ∧ code e431241976054 = 4829288487158 := by decide
theorem cert_e431241976054 : check e431241976054 [] .sourceHead = true := by decide
def e431241976606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e431241976606 : Closed e431241976606 ∧ code e431241976606 = 4829288487710 := by decide
theorem cert_e431241976606 : check e431241976606 [] .sourceHead = true := by decide
def e431241976718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e431241976718 : Closed e431241976718 ∧ code e431241976718 = 4829288487822 := by decide
theorem cert_e431241976718 : check e431241976718 [] .sourceHead = true := by decide
def e431241976942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e431241976942 : Closed e431241976942 ∧ code e431241976942 = 4829288488046 := by decide
theorem cert_e431241976942 : check e431241976942 [] .sourceHead = true := by decide
def e431241976954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e431241976954 : Closed e431241976954 ∧ code e431241976954 = 4829288488058 := by decide
theorem cert_e431241976954 : check e431241976954 [] .sourceHead = true := by decide
def e431241977118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e431241977118 : Closed e431241977118 ∧ code e431241977118 = 4829288488222 := by decide
theorem cert_e431241977118 : check e431241977118 [] .sourceHead = true := by decide
def e431241977286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e431241977286 : Closed e431241977286 ∧ code e431241977286 = 4829288488390 := by decide
theorem cert_e431241977286 : check e431241977286 [] .sourceHead = true := by decide
def e431241977398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e431241977398 : Closed e431241977398 ∧ code e431241977398 = 4829288488502 := by decide
theorem cert_e431241977398 : check e431241977398 [] .sourceHead = true := by decide
def e431241977402 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e431241977402 : Closed e431241977402 ∧ code e431241977402 = 4829288488506 := by decide
theorem cert_e431241977402 : check e431241977402 [] .sourceHead = true := by decide
def e431241977486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e431241977486 : Closed e431241977486 ∧ code e431241977486 = 4829288488590 := by decide
theorem cert_e431241977486 : check e431241977486 [] .sourceHead = true := by decide
def e431241977542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e431241977542 : Closed e431241977542 ∧ code e431241977542 = 4829288488646 := by decide
theorem cert_e431241977542 : check e431241977542 [] .sourceHead = true := by decide
def e431241979678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e431241979678 : Closed e431241979678 ∧ code e431241979678 = 4829288490782 := by decide
theorem cert_e431241979678 : check e431241979678 [] .sourceHead = true := by decide
def e431241979790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e431241979790 : Closed e431241979790 ∧ code e431241979790 = 4829288490894 := by decide
theorem cert_e431241979790 : check e431241979790 [] .sourceHead = true := by decide
def e431241982750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e431241982750 : Closed e431241982750 ∧ code e431241982750 = 4829288493854 := by decide
theorem cert_e431241982750 : check e431241982750 [] .sourceHead = true := by decide
def e431241982918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e431241982918 : Closed e431241982918 ∧ code e431241982918 = 4829288494022 := by decide
theorem cert_e431241982918 : check e431241982918 [] .sourceHead = true := by decide
def e431241984398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e431241984398 : Closed e431241984398 ∧ code e431241984398 = 4829288495502 := by decide
theorem cert_e431241984398 : check e431241984398 [] .sourceHead = true := by decide
def e431241984454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e431241984454 : Closed e431241984454 ∧ code e431241984454 = 4829288495558 := by decide
theorem cert_e431241984454 : check e431241984454 [] .sourceHead = true := by decide
def e431242021742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e431242021742 : Closed e431242021742 ∧ code e431242021742 = 4829288532846 := by decide
theorem cert_e431242021742 : check e431242021742 [] .sourceHead = true := by decide
def e431242021750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e431242021750 : Closed e431242021750 ∧ code e431242021750 = 4829288532854 := by decide
theorem cert_e431242021750 : check e431242021750 [] .sourceHead = true := by decide
end Blc.Floor42
