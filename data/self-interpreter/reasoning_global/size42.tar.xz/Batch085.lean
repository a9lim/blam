import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202958721050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202958721050 : Closed e1202958721050 ∧ code e1202958721050 = 5601005232154 := by decide
theorem cert_e1202958721050 : check e1202958721050 [[]] .width = true := by decide
def e1202958721142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202958721142 : Closed e1202958721142 ∧ code e1202958721142 = 5601005232246 := by decide
private def t_e1202958721142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202958721142 : ¬ IsSelfInterpreter e1202958721142 :=
  wSource (t := t_e1202958721142) (replay_sound (ps := []) (t := e1202958721142) (by decide)) (by decide)
def e1202958721386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202958721386 : Closed e1202958721386 ∧ code e1202958721386 = 5601005232490 := by decide
private def t_e1202958721386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202958721386 : ¬ IsSelfInterpreter e1202958721386 :=
  wSource (t := t_e1202958721386) (replay_sound (ps := []) (t := e1202958721386) (by decide)) (by decide)
def e1202958721434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202958721434 : Closed e1202958721434 ∧ code e1202958721434 = 5601005232538 := by decide
private def t_e1202958721434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202958721434 : ¬ IsSelfInterpreter e1202958721434 :=
  wSource (t := t_e1202958721434) (replay_sound (ps := []) (t := e1202958721434) (by decide)) (by decide)
def e1202958725318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958725318 : Closed e1202958725318 ∧ code e1202958725318 = 5601005236422 := by decide
theorem cert_e1202958725318 : check e1202958725318 [[]] .width = true := by decide
def e1202958737434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202958737434 : Closed e1202958737434 ∧ code e1202958737434 = 5601005248538 := by decide
theorem cert_e1202958737434 : check e1202958737434 [[]] .width = true := by decide
def e1202958737526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202958737526 : Closed e1202958737526 ∧ code e1202958737526 = 5601005248630 := by decide
private def t_e1202958737526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202958737526 : ¬ IsSelfInterpreter e1202958737526 :=
  wSource (t := t_e1202958737526) (replay_sound (ps := []) (t := e1202958737526) (by decide)) (by decide)
def e1202958737770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202958737770 : Closed e1202958737770 ∧ code e1202958737770 = 5601005248874 := by decide
private def t_e1202958737770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202958737770 : ¬ IsSelfInterpreter e1202958737770 :=
  wSource (t := t_e1202958737770) (replay_sound (ps := []) (t := e1202958737770) (by decide)) (by decide)
def e1202958737818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202958737818 : Closed e1202958737818 ∧ code e1202958737818 = 5601005248922 := by decide
private def t_e1202958737818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202958737818 : ¬ IsSelfInterpreter e1202958737818 :=
  wSource (t := t_e1202958737818) (replay_sound (ps := []) (t := e1202958737818) (by decide)) (by decide)
def e1202958747162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958747162 : Closed e1202958747162 ∧ code e1202958747162 = 5601005258266 := by decide
private def t_e1202958747162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958747162 : ¬ IsSelfInterpreter e1202958747162 :=
  wSource (t := t_e1202958747162) (replay_sound (ps := []) (t := e1202958747162) (by decide)) (by decide)
def e1202958749894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958749894 : Closed e1202958749894 ∧ code e1202958749894 = 5601005260998 := by decide
theorem cert_e1202958749894 : check e1202958749894 [[]] .width = true := by decide
def e1202958775834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958775834 : Closed e1202958775834 ∧ code e1202958775834 = 5601005286938 := by decide
private def t_e1202958775834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958775834 : ¬ IsSelfInterpreter e1202958775834 :=
  wSource (t := t_e1202958775834) (replay_sound (ps := []) (t := e1202958775834) (by decide)) (by decide)
def e1202958776858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958776858 : Closed e1202958776858 ∧ code e1202958776858 = 5601005287962 := by decide
private def t_e1202958776858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958776858 : ¬ IsSelfInterpreter e1202958776858 :=
  wSource (t := t_e1202958776858) (replay_sound (ps := []) (t := e1202958776858) (by decide)) (by decide)
def e1202958798362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958798362 : Closed e1202958798362 ∧ code e1202958798362 = 5601005309466 := by decide
private def t_e1202958798362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958798362 : ¬ IsSelfInterpreter e1202958798362 :=
  wSource (t := t_e1202958798362) (replay_sound (ps := []) (t := e1202958798362) (by decide)) (by decide)
def e1202958807238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958807238 : Closed e1202958807238 ∧ code e1202958807238 = 5601005318342 := by decide
theorem cert_e1202958807238 : check e1202958807238 [[]] .width = true := by decide
def e1202958812698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958812698 : Closed e1202958812698 ∧ code e1202958812698 = 5601005323802 := by decide
private def t_e1202958812698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958812698 : ¬ IsSelfInterpreter e1202958812698 :=
  wSource (t := t_e1202958812698) (replay_sound (ps := []) (t := e1202958812698) (by decide)) (by decide)
def e1202958815430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958815430 : Closed e1202958815430 ∧ code e1202958815430 = 5601005326534 := by decide
theorem cert_e1202958815430 : check e1202958815430 [[]] .width = true := by decide
def e1202960953542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202960953542 : Closed e1202960953542 ∧ code e1202960953542 = 5601007464646 := by decide
theorem cert_e1202960953542 : check e1202960953542 [[]] .width = true := by decide
def e1202961758234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202961758234 : Closed e1202961758234 ∧ code e1202961758234 = 5601008269338 := by decide
theorem cert_e1202961758234 : check e1202961758234 [[]] .width = true := by decide
def e1202961954842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202961954842 : Closed e1202961954842 ∧ code e1202961954842 = 5601008465946 := by decide
theorem cert_e1202961954842 : check e1202961954842 [[]] .width = true := by decide
def e1202962526406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202962526406 : Closed e1202962526406 ∧ code e1202962526406 = 5601009037510 := by decide
theorem cert_e1202962526406 : check e1202962526406 [[]] .width = true := by decide
def e1202962542790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202962542790 : Closed e1202962542790 ∧ code e1202962542790 = 5601009053894 := by decide
theorem cert_e1202962542790 : check e1202962542790 [[]] .width = true := by decide
def e1202963331098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202963331098 : Closed e1202963331098 ∧ code e1202963331098 = 5601009842202 := by decide
theorem cert_e1202963331098 : check e1202963331098 [[]] .width = true := by decide
def e1202963339290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202963339290 : Closed e1202963339290 ∧ code e1202963339290 = 5601009850394 := by decide
theorem cert_e1202963339290 : check e1202963339290 [[]] .width = true := by decide
def e1202963673286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202963673286 : Closed e1202963673286 ∧ code e1202963673286 = 5601010184390 := by decide
theorem cert_e1202963673286 : check e1202963673286 [[]] .width = true := by decide
def e1202963724314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202963724314 : Closed e1202963724314 ∧ code e1202963724314 = 5601010235418 := by decide
theorem cert_e1202963724314 : check e1202963724314 [[]] .width = true := by decide
def e1202963736602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202963736602 : Closed e1202963736602 ∧ code e1202963736602 = 5601010247706 := by decide
theorem cert_e1202963736602 : check e1202963736602 [[]] .width = true := by decide
def e1202963738138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202963738138 : Closed e1202963738138 ∧ code e1202963738138 = 5601010249242 := by decide
theorem cert_e1202963738138 : check e1202963738138 [[]] .width = true := by decide
def e1202963841050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202963841050 : Closed e1202963841050 ∧ code e1202963841050 = 5601010352154 := by decide
theorem cert_e1202963841050 : check e1202963841050 [[]] .width = true := by decide
def e1202963841142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202963841142 : Closed e1202963841142 ∧ code e1202963841142 = 5601010352246 := by decide
theorem cert_e1202963841142 : check e1202963841142 [[]] .width = true := by decide
def e1202963841386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202963841386 : Closed e1202963841386 ∧ code e1202963841386 = 5601010352490 := by decide
theorem cert_e1202963841386 : check e1202963841386 [[]] .width = true := by decide
def e1202963841434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202963841434 : Closed e1202963841434 ∧ code e1202963841434 = 5601010352538 := by decide
theorem cert_e1202963841434 : check e1202963841434 [[]] .width = true := by decide
def e1202963842442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202963842442 : Closed e1202963842442 ∧ code e1202963842442 = 5601010353546 := by decide
theorem cert_e1202963842442 : check e1202963842442 [[]] .width = true := by decide
def e1202963842466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202963842466 : Closed e1202963842466 ∧ code e1202963842466 = 5601010353570 := by decide
theorem cert_e1202963842466 : check e1202963842466 [[]] .width = true := by decide
def e1202963842574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202963842574 : Closed e1202963842574 ∧ code e1202963842574 = 5601010353678 := by decide
theorem cert_e1202963842574 : check e1202963842574 [[]] .width = true := by decide
def e1202963842586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202963842586 : Closed e1202963842586 ∧ code e1202963842586 = 5601010353690 := by decide
theorem cert_e1202963842586 : check e1202963842586 [[]] .width = true := by decide
def e1202963842658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202963842658 : Closed e1202963842658 ∧ code e1202963842658 = 5601010353762 := by decide
theorem cert_e1202963842658 : check e1202963842658 [[]] .width = true := by decide
def e1202963902662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202963902662 : Closed e1202963902662 ∧ code e1202963902662 = 5601010413766 := by decide
theorem cert_e1202963902662 : check e1202963902662 [[]] .width = true := by decide
def e1202963934746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202963934746 : Closed e1202963934746 ∧ code e1202963934746 = 5601010445850 := by decide
theorem cert_e1202963934746 : check e1202963934746 [[]] .width = true := by decide
def e1202963936794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202963936794 : Closed e1202963936794 ∧ code e1202963936794 = 5601010447898 := by decide
theorem cert_e1202963936794 : check e1202963936794 [[]] .width = true := by decide
def e1202963972122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202963972122 : Closed e1202963972122 ∧ code e1202963972122 = 5601010483226 := by decide
theorem cert_e1202963972122 : check e1202963972122 [[]] .width = true := by decide
def e1202963972214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202963972214 : Closed e1202963972214 ∧ code e1202963972214 = 5601010483318 := by decide
theorem cert_e1202963972214 : check e1202963972214 [[]] .width = true := by decide
def e1202963972458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202963972458 : Closed e1202963972458 ∧ code e1202963972458 = 5601010483562 := by decide
theorem cert_e1202963972458 : check e1202963972458 [[]] .width = true := by decide
def e1202963972506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202963972506 : Closed e1202963972506 ∧ code e1202963972506 = 5601010483610 := by decide
theorem cert_e1202963972506 : check e1202963972506 [[]] .width = true := by decide
def e1202963973514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202963973514 : Closed e1202963973514 ∧ code e1202963973514 = 5601010484618 := by decide
theorem cert_e1202963973514 : check e1202963973514 [[]] .width = true := by decide
def e1202963973538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202963973538 : Closed e1202963973538 ∧ code e1202963973538 = 5601010484642 := by decide
theorem cert_e1202963973538 : check e1202963973538 [[]] .width = true := by decide
def e1202963973646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202963973646 : Closed e1202963973646 ∧ code e1202963973646 = 5601010484750 := by decide
theorem cert_e1202963973646 : check e1202963973646 [[]] .width = true := by decide
def e1202963973658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202963973658 : Closed e1202963973658 ∧ code e1202963973658 = 5601010484762 := by decide
theorem cert_e1202963973658 : check e1202963973658 [[]] .width = true := by decide
def e1202963973730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202963973730 : Closed e1202963973730 ∧ code e1202963973730 = 5601010484834 := by decide
theorem cert_e1202963973730 : check e1202963973730 [[]] .width = true := by decide
def e1202966476826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202966476826 : Closed e1202966476826 ∧ code e1202966476826 = 5601012987930 := by decide
theorem cert_e1202966476826 : check e1202966476826 [[]] .width = true := by decide
def e1202967134406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202967134406 : Closed e1202967134406 ∧ code e1202967134406 = 5601013645510 := by decide
theorem cert_e1202967134406 : check e1202967134406 [[]] .width = true := by decide
def e1202967164954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967164954 : Closed e1202967164954 ∧ code e1202967164954 = 5601013676058 := by decide
theorem cert_e1202967164954 : check e1202967164954 [[]] .width = true := by decide
def e1202967199942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202967199942 : Closed e1202967199942 ∧ code e1202967199942 = 5601013711046 := by decide
theorem cert_e1202967199942 : check e1202967199942 [[]] .width = true := by decide
def e1202967376070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202967376070 : Closed e1202967376070 ∧ code e1202967376070 = 5601013887174 := by decide
theorem cert_e1202967376070 : check e1202967376070 [[]] .width = true := by decide
def e1202967394330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967394330 : Closed e1202967394330 ∧ code e1202967394330 = 5601013905434 := by decide
theorem cert_e1202967394330 : check e1202967394330 [[]] .width = true := by decide
def e1202967408154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202967408154 : Closed e1202967408154 ∧ code e1202967408154 = 5601013919258 := by decide
theorem cert_e1202967408154 : check e1202967408154 [[]] .width = true := by decide
def e1202967658694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202967658694 : Closed e1202967658694 ∧ code e1202967658694 = 5601014169798 := by decide
theorem cert_e1202967658694 : check e1202967658694 [[]] .width = true := by decide
def e1202967732250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202967732250 : Closed e1202967732250 ∧ code e1202967732250 = 5601014243354 := by decide
theorem cert_e1202967732250 : check e1202967732250 [[]] .width = true := by decide
def e1202967732342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202967732342 : Closed e1202967732342 ∧ code e1202967732342 = 5601014243446 := by decide
theorem cert_e1202967732342 : check e1202967732342 [[]] .width = true := by decide
def e1202967732586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202967732586 : Closed e1202967732586 ∧ code e1202967732586 = 5601014243690 := by decide
theorem cert_e1202967732586 : check e1202967732586 [[]] .width = true := by decide
def e1202967732634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202967732634 : Closed e1202967732634 ∧ code e1202967732634 = 5601014243738 := by decide
theorem cert_e1202967732634 : check e1202967732634 [[]] .width = true := by decide
def e1202967744710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202967744710 : Closed e1202967744710 ∧ code e1202967744710 = 5601014255814 := by decide
theorem cert_e1202967744710 : check e1202967744710 [[]] .width = true := by decide
def e1202967746586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967746586 : Closed e1202967746586 ∧ code e1202967746586 = 5601014257690 := by decide
theorem cert_e1202967746586 : check e1202967746586 [[]] .width = true := by decide
def e1202967748122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202967748122 : Closed e1202967748122 ∧ code e1202967748122 = 5601014259226 := by decide
theorem cert_e1202967748122 : check e1202967748122 [[]] .width = true := by decide
def e1202967756998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202967756998 : Closed e1202967756998 ∧ code e1202967756998 = 5601014268102 := by decide
theorem cert_e1202967756998 : check e1202967756998 [[]] .width = true := by decide
def e1202967765018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202967765018 : Closed e1202967765018 ∧ code e1202967765018 = 5601014276122 := by decide
theorem cert_e1202967765018 : check e1202967765018 [[]] .width = true := by decide
def e1202967765110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202967765110 : Closed e1202967765110 ∧ code e1202967765110 = 5601014276214 := by decide
theorem cert_e1202967765110 : check e1202967765110 [[]] .width = true := by decide
def e1202967765354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202967765354 : Closed e1202967765354 ∧ code e1202967765354 = 5601014276458 := by decide
theorem cert_e1202967765354 : check e1202967765354 [[]] .width = true := by decide
def e1202967765402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202967765402 : Closed e1202967765402 ∧ code e1202967765402 = 5601014276506 := by decide
theorem cert_e1202967765402 : check e1202967765402 [[]] .width = true := by decide
def e1202967769286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202967769286 : Closed e1202967769286 ∧ code e1202967769286 = 5601014280390 := by decide
theorem cert_e1202967769286 : check e1202967769286 [[]] .width = true := by decide
def e1202967851206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202967851206 : Closed e1202967851206 ∧ code e1202967851206 = 5601014362310 := by decide
theorem cert_e1202967851206 : check e1202967851206 [[]] .width = true := by decide
def e1202967861274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967861274 : Closed e1202967861274 ∧ code e1202967861274 = 5601014372378 := by decide
theorem cert_e1202967861274 : check e1202967861274 [[]] .width = true := by decide
def e1202967865370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967865370 : Closed e1202967865370 ∧ code e1202967865370 = 5601014376474 := by decide
theorem cert_e1202967865370 : check e1202967865370 [[]] .width = true := by decide
def e1202967866906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202967866906 : Closed e1202967866906 ∧ code e1202967866906 = 5601014378010 := by decide
theorem cert_e1202967866906 : check e1202967866906 [[]] .width = true := by decide
def e1202967868954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202967868954 : Closed e1202967868954 ∧ code e1202967868954 = 5601014380058 := by decide
theorem cert_e1202967868954 : check e1202967868954 [[]] .width = true := by decide
def e1202967951386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202967951386 : Closed e1202967951386 ∧ code e1202967951386 = 5601014462490 := by decide
theorem cert_e1202967951386 : check e1202967951386 [[]] .width = true := by decide
def e1202967986374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202967986374 : Closed e1202967986374 ∧ code e1202967986374 = 5601014497478 := by decide
theorem cert_e1202967986374 : check e1202967986374 [[]] .width = true := by decide
def e1202968006854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202968006854 : Closed e1202968006854 ∧ code e1202968006854 = 5601014517958 := by decide
theorem cert_e1202968006854 : check e1202968006854 [[]] .width = true := by decide
def e1202968008730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202968008730 : Closed e1202968008730 ∧ code e1202968008730 = 5601014519834 := by decide
theorem cert_e1202968008730 : check e1202968008730 [[]] .width = true := by decide
def e1202968010266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202968010266 : Closed e1202968010266 ∧ code e1202968010266 = 5601014521370 := by decide
theorem cert_e1202968010266 : check e1202968010266 [[]] .width = true := by decide
def e1202968019142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202968019142 : Closed e1202968019142 ∧ code e1202968019142 = 5601014530246 := by decide
theorem cert_e1202968019142 : check e1202968019142 [[]] .width = true := by decide
def e1202968027162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202968027162 : Closed e1202968027162 ∧ code e1202968027162 = 5601014538266 := by decide
theorem cert_e1202968027162 : check e1202968027162 [[]] .width = true := by decide
def e1202968027254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202968027254 : Closed e1202968027254 ∧ code e1202968027254 = 5601014538358 := by decide
theorem cert_e1202968027254 : check e1202968027254 [[]] .width = true := by decide
def e1202968027498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202968027498 : Closed e1202968027498 ∧ code e1202968027498 = 5601014538602 := by decide
theorem cert_e1202968027498 : check e1202968027498 [[]] .width = true := by decide
def e1202968027546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202968027546 : Closed e1202968027546 ∧ code e1202968027546 = 5601014538650 := by decide
theorem cert_e1202968027546 : check e1202968027546 [[]] .width = true := by decide
def e1202968031430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202968031430 : Closed e1202968031430 ∧ code e1202968031430 = 5601014542534 := by decide
theorem cert_e1202968031430 : check e1202968031430 [[]] .width = true := by decide
def e1202968038938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202968038938 : Closed e1202968038938 ∧ code e1202968038938 = 5601014550042 := by decide
theorem cert_e1202968038938 : check e1202968038938 [[]] .width = true := by decide
def e1202968047814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202968047814 : Closed e1202968047814 ∧ code e1202968047814 = 5601014558918 := by decide
theorem cert_e1202968047814 : check e1202968047814 [[]] .width = true := by decide
def e1202970280134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202970280134 : Closed e1202970280134 ∧ code e1202970280134 = 5601016791238 := by decide
theorem cert_e1202970280134 : check e1202970280134 [[]] .width = true := by decide
def e1202970310682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202970310682 : Closed e1202970310682 ∧ code e1202970310682 = 5601016821786 := by decide
theorem cert_e1202970310682 : check e1202970310682 [[]] .width = true := by decide
def e1202970345670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202970345670 : Closed e1202970345670 ∧ code e1202970345670 = 5601016856774 := by decide
theorem cert_e1202970345670 : check e1202970345670 [[]] .width = true := by decide
def e1202973016090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202973016090 : Closed e1202973016090 ∧ code e1202973016090 = 5601019527194 := by decide
theorem cert_e1202973016090 : check e1202973016090 [[]] .width = true := by decide
def e1202973016182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202973016182 : Closed e1202973016182 ∧ code e1202973016182 = 5601019527286 := by decide
theorem cert_e1202973016182 : check e1202973016182 [[]] .width = true := by decide
def e1202973016426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202973016426 : Closed e1202973016426 ∧ code e1202973016426 = 5601019527530 := by decide
theorem cert_e1202973016426 : check e1202973016426 [[]] .width = true := by decide
def e1202973016474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202973016474 : Closed e1202973016474 ∧ code e1202973016474 = 5601019527578 := by decide
theorem cert_e1202973016474 : check e1202973016474 [[]] .width = true := by decide
def e1202973017482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202973017482 : Closed e1202973017482 ∧ code e1202973017482 = 5601019528586 := by decide
theorem cert_e1202973017482 : check e1202973017482 [[]] .width = true := by decide
def e1202973017506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202973017506 : Closed e1202973017506 ∧ code e1202973017506 = 5601019528610 := by decide
theorem cert_e1202973017506 : check e1202973017506 [[]] .width = true := by decide
def e1202973017614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202973017614 : Closed e1202973017614 ∧ code e1202973017614 = 5601019528718 := by decide
theorem cert_e1202973017614 : check e1202973017614 [[]] .width = true := by decide
def e1202973017626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202973017626 : Closed e1202973017626 ∧ code e1202973017626 = 5601019528730 := by decide
theorem cert_e1202973017626 : check e1202973017626 [[]] .width = true := by decide
def e1202973017698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202973017698 : Closed e1202973017698 ∧ code e1202973017698 = 5601019528802 := by decide
theorem cert_e1202973017698 : check e1202973017698 [[]] .width = true := by decide
def e1202973425862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202973425862 : Closed e1202973425862 ∧ code e1202973425862 = 5601019936966 := by decide
theorem cert_e1202973425862 : check e1202973425862 [[]] .width = true := by decide
def e1202973499418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202973499418 : Closed e1202973499418 ∧ code e1202973499418 = 5601020010522 := by decide
theorem cert_e1202973499418 : check e1202973499418 [[]] .width = true := by decide
def e1202973499510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202973499510 : Closed e1202973499510 ∧ code e1202973499510 = 5601020010614 := by decide
theorem cert_e1202973499510 : check e1202973499510 [[]] .width = true := by decide
def e1202973499754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202973499754 : Closed e1202973499754 ∧ code e1202973499754 = 5601020010858 := by decide
theorem cert_e1202973499754 : check e1202973499754 [[]] .width = true := by decide
def e1202973499802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202973499802 : Closed e1202973499802 ∧ code e1202973499802 = 5601020010906 := by decide
theorem cert_e1202973499802 : check e1202973499802 [[]] .width = true := by decide
def e1202973511878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202973511878 : Closed e1202973511878 ∧ code e1202973511878 = 5601020022982 := by decide
theorem cert_e1202973511878 : check e1202973511878 [[]] .width = true := by decide
def e1202973513754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202973513754 : Closed e1202973513754 ∧ code e1202973513754 = 5601020024858 := by decide
theorem cert_e1202973513754 : check e1202973513754 [[]] .width = true := by decide
def e1202973515290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202973515290 : Closed e1202973515290 ∧ code e1202973515290 = 5601020026394 := by decide
theorem cert_e1202973515290 : check e1202973515290 [[]] .width = true := by decide
def e1202973524166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202973524166 : Closed e1202973524166 ∧ code e1202973524166 = 5601020035270 := by decide
theorem cert_e1202973524166 : check e1202973524166 [[]] .width = true := by decide
def e1202973532186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202973532186 : Closed e1202973532186 ∧ code e1202973532186 = 5601020043290 := by decide
theorem cert_e1202973532186 : check e1202973532186 [[]] .width = true := by decide
def e1202973532278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202973532278 : Closed e1202973532278 ∧ code e1202973532278 = 5601020043382 := by decide
theorem cert_e1202973532278 : check e1202973532278 [[]] .width = true := by decide
def e1202973532522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202973532522 : Closed e1202973532522 ∧ code e1202973532522 = 5601020043626 := by decide
theorem cert_e1202973532522 : check e1202973532522 [[]] .width = true := by decide
def e1202973532570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202973532570 : Closed e1202973532570 ∧ code e1202973532570 = 5601020043674 := by decide
theorem cert_e1202973532570 : check e1202973532570 [[]] .width = true := by decide
def e1202973536454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202973536454 : Closed e1202973536454 ∧ code e1202973536454 = 5601020047558 := by decide
theorem cert_e1202973536454 : check e1202973536454 [[]] .width = true := by decide
def e1202974359750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202974359750 : Closed e1202974359750 ∧ code e1202974359750 = 5601020870854 := by decide
theorem cert_e1202974359750 : check e1202974359750 [[]] .width = true := by decide
def e1202974360278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202974360278 : Closed e1202974360278 ∧ code e1202974360278 = 5601020871382 := by decide
theorem cert_e1202974360278 : check e1202974360278 [[]] .width = true := by decide
def e1202974360282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202974360282 : Closed e1202974360282 ∧ code e1202974360282 = 5601020871386 := by decide
theorem cert_e1202974360282 : check e1202974360282 [[]] .width = true := by decide
def e1202974360298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202974360298 : Closed e1202974360298 ∧ code e1202974360298 = 5601020871402 := by decide
theorem cert_e1202974360298 : check e1202974360298 [[]] .width = true := by decide
def e1202974360374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202974360374 : Closed e1202974360374 ∧ code e1202974360374 = 5601020871478 := by decide
theorem cert_e1202974360374 : check e1202974360374 [[]] .width = true := by decide
def e1202974360378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202974360378 : Closed e1202974360378 ∧ code e1202974360378 = 5601020871482 := by decide
theorem cert_e1202974360378 : check e1202974360378 [[]] .width = true := by decide
def e1202974360462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202974360462 : Closed e1202974360462 ∧ code e1202974360462 = 5601020871566 := by decide
theorem cert_e1202974360462 : check e1202974360462 [[]] .width = true := by decide
def e1202974360474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202974360474 : Closed e1202974360474 ∧ code e1202974360474 = 5601020871578 := by decide
theorem cert_e1202974360474 : check e1202974360474 [[]] .width = true := by decide
def e1202974362394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202974362394 : Closed e1202974362394 ∧ code e1202974362394 = 5601020873498 := by decide
theorem cert_e1202974362394 : check e1202974362394 [[]] .width = true := by decide
def e1202974362438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202974362438 : Closed e1202974362438 ∧ code e1202974362438 = 5601020873542 := by decide
theorem cert_e1202974362438 : check e1202974362438 [[]] .width = true := by decide
def e1202974362550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202974362550 : Closed e1202974362550 ∧ code e1202974362550 = 5601020873654 := by decide
theorem cert_e1202974362550 : check e1202974362550 [[]] .width = true := by decide
def e1202974362678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202974362678 : Closed e1202974362678 ∧ code e1202974362678 = 5601020873782 := by decide
theorem cert_e1202974362678 : check e1202974362678 [[]] .width = true := by decide
def e1202974362682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202974362682 : Closed e1202974362682 ∧ code e1202974362682 = 5601020873786 := by decide
theorem cert_e1202974362682 : check e1202974362682 [[]] .width = true := by decide
def e1202974362822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202974362822 : Closed e1202974362822 ∧ code e1202974362822 = 5601020873926 := by decide
theorem cert_e1202974362822 : check e1202974362822 [[]] .width = true := by decide
def e1202974363162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202974363162 : Closed e1202974363162 ∧ code e1202974363162 = 5601020874266 := by decide
theorem cert_e1202974363162 : check e1202974363162 [[]] .width = true := by decide
def e1202974363254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202974363254 : Closed e1202974363254 ∧ code e1202974363254 = 5601020874358 := by decide
theorem cert_e1202974363254 : check e1202974363254 [[]] .width = true := by decide
def e1202974370842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202974370842 : Closed e1202974370842 ∧ code e1202974370842 = 5601020881946 := by decide
theorem cert_e1202974370842 : check e1202974370842 [[]] .width = true := by decide
def e1202974370886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202974370886 : Closed e1202974370886 ∧ code e1202974370886 = 5601020881990 := by decide
theorem cert_e1202974370886 : check e1202974370886 [[]] .width = true := by decide
def e1202974370914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202974370914 : Closed e1202974370914 ∧ code e1202974370914 = 5601020882018 := by decide
theorem cert_e1202974370914 : check e1202974370914 [[]] .width = true := by decide
def e1202974371078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202974371078 : Closed e1202974371078 ∧ code e1202974371078 = 5601020882182 := by decide
theorem cert_e1202974371078 : check e1202974371078 [[]] .width = true := by decide
def e1202974371870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202974371870 : Closed e1202974371870 ∧ code e1202974371870 = 5601020882974 := by decide
theorem cert_e1202974371870 : check e1202974371870 [[]] .width = true := by decide
def e1202974372038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202974372038 : Closed e1202974372038 ∧ code e1202974372038 = 5601020883142 := by decide
theorem cert_e1202974372038 : check e1202974372038 [[]] .width = true := by decide
def e1202974372066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202974372066 : Closed e1202974372066 ∧ code e1202974372066 = 5601020883170 := by decide
theorem cert_e1202974372066 : check e1202974372066 [[]] .width = true := by decide
def e1202974372614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202974372614 : Closed e1202974372614 ∧ code e1202974372614 = 5601020883718 := by decide
theorem cert_e1202974372614 : check e1202974372614 [[]] .width = true := by decide
def e1202974683334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202974683334 : Closed e1202974683334 ∧ code e1202974683334 = 5601021194438 := by decide
theorem cert_e1202974683334 : check e1202974683334 [[]] .width = true := by decide
def e1202974734362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202974734362 : Closed e1202974734362 ∧ code e1202974734362 = 5601021245466 := by decide
theorem cert_e1202974734362 : check e1202974734362 [[]] .width = true := by decide
def e1202974746650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202974746650 : Closed e1202974746650 ∧ code e1202974746650 = 5601021257754 := by decide
theorem cert_e1202974746650 : check e1202974746650 [[]] .width = true := by decide
def e1202974851098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202974851098 : Closed e1202974851098 ∧ code e1202974851098 = 5601021362202 := by decide
theorem cert_e1202974851098 : check e1202974851098 [[]] .width = true := by decide
def e1202974851190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202974851190 : Closed e1202974851190 ∧ code e1202974851190 = 5601021362294 := by decide
theorem cert_e1202974851190 : check e1202974851190 [[]] .width = true := by decide
def e1202974851434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202974851434 : Closed e1202974851434 ∧ code e1202974851434 = 5601021362538 := by decide
theorem cert_e1202974851434 : check e1202974851434 [[]] .width = true := by decide
def e1202974851482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202974851482 : Closed e1202974851482 ∧ code e1202974851482 = 5601021362586 := by decide
theorem cert_e1202974851482 : check e1202974851482 [[]] .width = true := by decide
def e1202974852490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202974852490 : Closed e1202974852490 ∧ code e1202974852490 = 5601021363594 := by decide
theorem cert_e1202974852490 : check e1202974852490 [[]] .width = true := by decide
def e1202974852514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202974852514 : Closed e1202974852514 ∧ code e1202974852514 = 5601021363618 := by decide
theorem cert_e1202974852514 : check e1202974852514 [[]] .width = true := by decide
def e1202974852622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202974852622 : Closed e1202974852622 ∧ code e1202974852622 = 5601021363726 := by decide
theorem cert_e1202974852622 : check e1202974852622 [[]] .width = true := by decide
def e1202974852634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202974852634 : Closed e1202974852634 ∧ code e1202974852634 = 5601021363738 := by decide
theorem cert_e1202974852634 : check e1202974852634 [[]] .width = true := by decide
def e1202974852706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202974852706 : Closed e1202974852706 ∧ code e1202974852706 = 5601021363810 := by decide
theorem cert_e1202974852706 : check e1202974852706 [[]] .width = true := by decide
def e1202975029274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202975029274 : Closed e1202975029274 ∧ code e1202975029274 = 5601021540378 := by decide
theorem cert_e1202975029274 : check e1202975029274 [[]] .width = true := by decide
def e1202975064262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202975064262 : Closed e1202975064262 ∧ code e1202975064262 = 5601021575366 := by decide
theorem cert_e1202975064262 : check e1202975064262 [[]] .width = true := by decide
def e1202975084742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202975084742 : Closed e1202975084742 ∧ code e1202975084742 = 5601021595846 := by decide
theorem cert_e1202975084742 : check e1202975084742 [[]] .width = true := by decide
def e1202975086618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202975086618 : Closed e1202975086618 ∧ code e1202975086618 = 5601021597722 := by decide
theorem cert_e1202975086618 : check e1202975086618 [[]] .width = true := by decide
def e1202975088154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202975088154 : Closed e1202975088154 ∧ code e1202975088154 = 5601021599258 := by decide
theorem cert_e1202975088154 : check e1202975088154 [[]] .width = true := by decide
def e1202975097030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202975097030 : Closed e1202975097030 ∧ code e1202975097030 = 5601021608134 := by decide
theorem cert_e1202975097030 : check e1202975097030 [[]] .width = true := by decide
def e1202975105050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202975105050 : Closed e1202975105050 ∧ code e1202975105050 = 5601021616154 := by decide
theorem cert_e1202975105050 : check e1202975105050 [[]] .width = true := by decide
def e1202975105142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202975105142 : Closed e1202975105142 ∧ code e1202975105142 = 5601021616246 := by decide
theorem cert_e1202975105142 : check e1202975105142 [[]] .width = true := by decide
def e1202975105386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202975105386 : Closed e1202975105386 ∧ code e1202975105386 = 5601021616490 := by decide
theorem cert_e1202975105386 : check e1202975105386 [[]] .width = true := by decide
def e1202975105434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202975105434 : Closed e1202975105434 ∧ code e1202975105434 = 5601021616538 := by decide
theorem cert_e1202975105434 : check e1202975105434 [[]] .width = true := by decide
end Blc.Floor42
