import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202984157302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202984157302 : Closed e1202984157302 ∧ code e1202984157302 = 5601030668406 := by decide
theorem cert_e1202984157302 : check e1202984157302 [[]] .width = true := by decide
def e1202984157546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202984157546 : Closed e1202984157546 ∧ code e1202984157546 = 5601030668650 := by decide
theorem cert_e1202984157546 : check e1202984157546 [[]] .width = true := by decide
def e1202984157594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202984157594 : Closed e1202984157594 ∧ code e1202984157594 = 5601030668698 := by decide
theorem cert_e1202984157594 : check e1202984157594 [[]] .width = true := by decide
def e1202984158602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202984158602 : Closed e1202984158602 ∧ code e1202984158602 = 5601030669706 := by decide
theorem cert_e1202984158602 : check e1202984158602 [[]] .width = true := by decide
def e1202984158626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202984158626 : Closed e1202984158626 ∧ code e1202984158626 = 5601030669730 := by decide
private def t_e1202984158626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e1202984158626 : ¬ IsSelfInterpreter e1202984158626 :=
  wSource (t := t_e1202984158626) (replay_sound (ps := []) (t := e1202984158626) (by decide)) (by decide)
def e1202984158734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202984158734 : Closed e1202984158734 ∧ code e1202984158734 = 5601030669838 := by decide
theorem cert_e1202984158734 : check e1202984158734 [[]] .width = true := by decide
def e1202984158746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202984158746 : Closed e1202984158746 ∧ code e1202984158746 = 5601030669850 := by decide
private def t_e1202984158746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e1202984158746 : ¬ IsSelfInterpreter e1202984158746 :=
  wSource (t := t_e1202984158746) (replay_sound (ps := []) (t := e1202984158746) (by decide)) (by decide)
def e1202984158818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202984158818 : Closed e1202984158818 ∧ code e1202984158818 = 5601030669922 := by decide
theorem cert_e1202984158818 : check e1202984158818 [[]] .width = true := by decide
def e1202984259782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202984259782 : Closed e1202984259782 ∧ code e1202984259782 = 5601030770886 := by decide
theorem cert_e1202984259782 : check e1202984259782 [[]] .width = true := by decide
def e1202984261658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202984261658 : Closed e1202984261658 ∧ code e1202984261658 = 5601030772762 := by decide
theorem cert_e1202984261658 : check e1202984261658 [[]] .width = true := by decide
def e1202984263194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202984263194 : Closed e1202984263194 ∧ code e1202984263194 = 5601030774298 := by decide
private def t_e1202984263194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202984263194 : ¬ IsSelfInterpreter e1202984263194 :=
  wSource (t := t_e1202984263194) (replay_sound (ps := []) (t := e1202984263194) (by decide)) (by decide)
def e1202984272070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202984272070 : Closed e1202984272070 ∧ code e1202984272070 = 5601030783174 := by decide
theorem cert_e1202984272070 : check e1202984272070 [[]] .width = true := by decide
def e1202984280090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202984280090 : Closed e1202984280090 ∧ code e1202984280090 = 5601030791194 := by decide
theorem cert_e1202984280090 : check e1202984280090 [[]] .width = true := by decide
def e1202984280182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202984280182 : Closed e1202984280182 ∧ code e1202984280182 = 5601030791286 := by decide
private def t_e1202984280182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202984280182 : ¬ IsSelfInterpreter e1202984280182 :=
  wSource (t := t_e1202984280182) (replay_sound (ps := []) (t := e1202984280182) (by decide)) (by decide)
def e1202984280426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202984280426 : Closed e1202984280426 ∧ code e1202984280426 = 5601030791530 := by decide
private def t_e1202984280426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202984280426 : ¬ IsSelfInterpreter e1202984280426 :=
  wSource (t := t_e1202984280426) (replay_sound (ps := []) (t := e1202984280426) (by decide)) (by decide)
def e1202984280474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202984280474 : Closed e1202984280474 ∧ code e1202984280474 = 5601030791578 := by decide
private def t_e1202984280474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202984280474 : ¬ IsSelfInterpreter e1202984280474 :=
  wSource (t := t_e1202984280474) (replay_sound (ps := []) (t := e1202984280474) (by decide)) (by decide)
def e1202984284358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202984284358 : Closed e1202984284358 ∧ code e1202984284358 = 5601030795462 := by decide
theorem cert_e1202984284358 : check e1202984284358 [[]] .width = true := by decide
def e1202984296474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202984296474 : Closed e1202984296474 ∧ code e1202984296474 = 5601030807578 := by decide
theorem cert_e1202984296474 : check e1202984296474 [[]] .width = true := by decide
def e1202984296566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202984296566 : Closed e1202984296566 ∧ code e1202984296566 = 5601030807670 := by decide
private def t_e1202984296566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202984296566 : ¬ IsSelfInterpreter e1202984296566 :=
  wSource (t := t_e1202984296566) (replay_sound (ps := []) (t := e1202984296566) (by decide)) (by decide)
def e1202984296810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202984296810 : Closed e1202984296810 ∧ code e1202984296810 = 5601030807914 := by decide
private def t_e1202984296810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202984296810 : ¬ IsSelfInterpreter e1202984296810 :=
  wSource (t := t_e1202984296810) (replay_sound (ps := []) (t := e1202984296810) (by decide)) (by decide)
def e1202984296858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202984296858 : Closed e1202984296858 ∧ code e1202984296858 = 5601030807962 := by decide
private def t_e1202984296858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202984296858 : ¬ IsSelfInterpreter e1202984296858 :=
  wSource (t := t_e1202984296858) (replay_sound (ps := []) (t := e1202984296858) (by decide)) (by decide)
def e1202984306202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202984306202 : Closed e1202984306202 ∧ code e1202984306202 = 5601030817306 := by decide
private def t_e1202984306202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202984306202 : ¬ IsSelfInterpreter e1202984306202 :=
  wSource (t := t_e1202984306202) (replay_sound (ps := []) (t := e1202984306202) (by decide)) (by decide)
def e1202984308934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202984308934 : Closed e1202984308934 ∧ code e1202984308934 = 5601030820038 := by decide
theorem cert_e1202984308934 : check e1202984308934 [[]] .width = true := by decide
def e1202984321222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202984321222 : Closed e1202984321222 ∧ code e1202984321222 = 5601030832326 := by decide
theorem cert_e1202984321222 : check e1202984321222 [[]] .width = true := by decide
def e1202984321750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202984321750 : Closed e1202984321750 ∧ code e1202984321750 = 5601030832854 := by decide
theorem cert_e1202984321750 : check e1202984321750 [[]] .width = true := by decide
def e1202984321754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202984321754 : Closed e1202984321754 ∧ code e1202984321754 = 5601030832858 := by decide
theorem cert_e1202984321754 : check e1202984321754 [[]] .width = true := by decide
def e1202984321770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202984321770 : Closed e1202984321770 ∧ code e1202984321770 = 5601030832874 := by decide
theorem cert_e1202984321770 : check e1202984321770 [[]] .width = true := by decide
def e1202984321846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202984321846 : Closed e1202984321846 ∧ code e1202984321846 = 5601030832950 := by decide
theorem cert_e1202984321846 : check e1202984321846 [[]] .width = true := by decide
def e1202984321850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202984321850 : Closed e1202984321850 ∧ code e1202984321850 = 5601030832954 := by decide
theorem cert_e1202984321850 : check e1202984321850 [[]] .width = true := by decide
def e1202984321934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202984321934 : Closed e1202984321934 ∧ code e1202984321934 = 5601030833038 := by decide
theorem cert_e1202984321934 : check e1202984321934 [[]] .width = true := by decide
def e1202984321946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202984321946 : Closed e1202984321946 ∧ code e1202984321946 = 5601030833050 := by decide
theorem cert_e1202984321946 : check e1202984321946 [[]] .width = true := by decide
def e1202984323866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202984323866 : Closed e1202984323866 ∧ code e1202984323866 = 5601030834970 := by decide
theorem cert_e1202984323866 : check e1202984323866 [[]] .width = true := by decide
def e1202984323910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202984323910 : Closed e1202984323910 ∧ code e1202984323910 = 5601030835014 := by decide
theorem cert_e1202984323910 : check e1202984323910 [[]] .width = true := by decide
def e1202984324022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202984324022 : Closed e1202984324022 ∧ code e1202984324022 = 5601030835126 := by decide
private def t_e1202984324022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem cert_e1202984324022 : ¬ IsSelfInterpreter e1202984324022 :=
  wSource (t := t_e1202984324022) (replay_sound (ps := []) (t := e1202984324022) (by decide)) (by decide)
def e1202984324150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202984324150 : Closed e1202984324150 ∧ code e1202984324150 = 5601030835254 := by decide
theorem cert_e1202984324150 : check e1202984324150 [[]] .width = true := by decide
def e1202984324154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202984324154 : Closed e1202984324154 ∧ code e1202984324154 = 5601030835258 := by decide
theorem cert_e1202984324154 : check e1202984324154 [[]] .width = true := by decide
def e1202984324294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202984324294 : Closed e1202984324294 ∧ code e1202984324294 = 5601030835398 := by decide
theorem cert_e1202984324294 : check e1202984324294 [[]] .width = true := by decide
def e1202984324634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202984324634 : Closed e1202984324634 ∧ code e1202984324634 = 5601030835738 := by decide
private def t_e1202984324634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e1202984324634 : ¬ IsSelfInterpreter e1202984324634 :=
  wSource (t := t_e1202984324634) (replay_sound (ps := []) (t := e1202984324634) (by decide)) (by decide)
def e1202984324726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202984324726 : Closed e1202984324726 ∧ code e1202984324726 = 5601030835830 := by decide
private def t_e1202984324726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem cert_e1202984324726 : ¬ IsSelfInterpreter e1202984324726 :=
  wSource (t := t_e1202984324726) (replay_sound (ps := []) (t := e1202984324726) (by decide)) (by decide)
def e1202984332314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202984332314 : Closed e1202984332314 ∧ code e1202984332314 = 5601030843418 := by decide
theorem cert_e1202984332314 : check e1202984332314 [[]] .width = true := by decide
def e1202984332358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202984332358 : Closed e1202984332358 ∧ code e1202984332358 = 5601030843462 := by decide
theorem cert_e1202984332358 : check e1202984332358 [[]] .width = true := by decide
def e1202984332386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202984332386 : Closed e1202984332386 ∧ code e1202984332386 = 5601030843490 := by decide
theorem cert_e1202984332386 : check e1202984332386 [[]] .width = true := by decide
def e1202984332550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202984332550 : Closed e1202984332550 ∧ code e1202984332550 = 5601030843654 := by decide
private def t_e1202984332550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem cert_e1202984332550 : ¬ IsSelfInterpreter e1202984332550 :=
  wSource (t := t_e1202984332550) (replay_sound (ps := []) (t := e1202984332550) (by decide)) (by decide)
def e1202984333342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202984333342 : Closed e1202984333342 ∧ code e1202984333342 = 5601030844446 := by decide
theorem cert_e1202984333342 : check e1202984333342 [[]] .width = true := by decide
def e1202984333510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202984333510 : Closed e1202984333510 ∧ code e1202984333510 = 5601030844614 := by decide
theorem cert_e1202984333510 : check e1202984333510 [[]] .width = true := by decide
def e1202984333538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202984333538 : Closed e1202984333538 ∧ code e1202984333538 = 5601030844642 := by decide
theorem cert_e1202984333538 : check e1202984333538 [[]] .width = true := by decide
def e1202984334086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202984334086 : Closed e1202984334086 ∧ code e1202984334086 = 5601030845190 := by decide
theorem cert_e1202984334086 : check e1202984334086 [[]] .width = true := by decide
def e1202985349318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202985349318 : Closed e1202985349318 ∧ code e1202985349318 = 5601031860422 := by decide
theorem cert_e1202985349318 : check e1202985349318 [[]] .width = true := by decide
def e1202985357510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202985357510 : Closed e1202985357510 ∧ code e1202985357510 = 5601031868614 := by decide
theorem cert_e1202985357510 : check e1202985357510 [[]] .width = true := by decide
def e1202985555994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985555994 : Closed e1202985555994 ∧ code e1202985555994 = 5601032067098 := by decide
theorem cert_e1202985555994 : check e1202985555994 [[]] .width = true := by decide
def e1202985560090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985560090 : Closed e1202985560090 ∧ code e1202985560090 = 5601032071194 := by decide
theorem cert_e1202985560090 : check e1202985560090 [[]] .width = true := by decide
def e1202985588762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985588762 : Closed e1202985588762 ∧ code e1202985588762 = 5601032099866 := by decide
theorem cert_e1202985588762 : check e1202985588762 [[]] .width = true := by decide
def e1202985609242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985609242 : Closed e1202985609242 ∧ code e1202985609242 = 5601032120346 := by decide
theorem cert_e1202985609242 : check e1202985609242 [[]] .width = true := by decide
def e1202985742534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202985742534 : Closed e1202985742534 ∧ code e1202985742534 = 5601032253638 := by decide
theorem cert_e1202985742534 : check e1202985742534 [[]] .width = true := by decide
def e1202985750726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202985750726 : Closed e1202985750726 ∧ code e1202985750726 = 5601032261830 := by decide
theorem cert_e1202985750726 : check e1202985750726 [[]] .width = true := by decide
def e1202985922758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202985922758 : Closed e1202985922758 ∧ code e1202985922758 = 5601032433862 := by decide
theorem cert_e1202985922758 : check e1202985922758 [[]] .width = true := by decide
def e1202985949210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985949210 : Closed e1202985949210 ∧ code e1202985949210 = 5601032460314 := by decide
theorem cert_e1202985949210 : check e1202985949210 [[]] .width = true := by decide
def e1202985953306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202985953306 : Closed e1202985953306 ∧ code e1202985953306 = 5601032464410 := by decide
theorem cert_e1202985953306 : check e1202985953306 [[]] .width = true := by decide
def e1202985954842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202985954842 : Closed e1202985954842 ∧ code e1202985954842 = 5601032465946 := by decide
theorem cert_e1202985954842 : check e1202985954842 [[]] .width = true := by decide
def e1202985956890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202985956890 : Closed e1202985956890 ∧ code e1202985956890 = 5601032467994 := by decide
theorem cert_e1202985956890 : check e1202985956890 [[]] .width = true := by decide
def e1202985992218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202985992218 : Closed e1202985992218 ∧ code e1202985992218 = 5601032503322 := by decide
theorem cert_e1202985992218 : check e1202985992218 [[]] .width = true := by decide
def e1202985992310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202985992310 : Closed e1202985992310 ∧ code e1202985992310 = 5601032503414 := by decide
theorem cert_e1202985992310 : check e1202985992310 [[]] .width = true := by decide
def e1202985992554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202985992554 : Closed e1202985992554 ∧ code e1202985992554 = 5601032503658 := by decide
theorem cert_e1202985992554 : check e1202985992554 [[]] .width = true := by decide
def e1202985992602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202985992602 : Closed e1202985992602 ∧ code e1202985992602 = 5601032503706 := by decide
theorem cert_e1202985992602 : check e1202985992602 [[]] .width = true := by decide
def e1202985993610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202985993610 : Closed e1202985993610 ∧ code e1202985993610 = 5601032504714 := by decide
theorem cert_e1202985993610 : check e1202985993610 [[]] .width = true := by decide
def e1202985993634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202985993634 : Closed e1202985993634 ∧ code e1202985993634 = 5601032504738 := by decide
theorem cert_e1202985993634 : check e1202985993634 [[]] .width = true := by decide
def e1202985993742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202985993742 : Closed e1202985993742 ∧ code e1202985993742 = 5601032504846 := by decide
theorem cert_e1202985993742 : check e1202985993742 [[]] .width = true := by decide
def e1202985993754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202985993754 : Closed e1202985993754 ∧ code e1202985993754 = 5601032504858 := by decide
theorem cert_e1202985993754 : check e1202985993754 [[]] .width = true := by decide
def e1202985993826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202985993826 : Closed e1202985993826 ∧ code e1202985993826 = 5601032504930 := by decide
theorem cert_e1202985993826 : check e1202985993826 [[]] .width = true := by decide
def e1202986037446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986037446 : Closed e1202986037446 ∧ code e1202986037446 = 5601032548550 := by decide
theorem cert_e1202986037446 : check e1202986037446 [[]] .width = true := by decide
def e1202986051610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986051610 : Closed e1202986051610 ∧ code e1202986051610 = 5601032562714 := by decide
theorem cert_e1202986051610 : check e1202986051610 [[]] .width = true := by decide
def e1202986053146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986053146 : Closed e1202986053146 ∧ code e1202986053146 = 5601032564250 := by decide
theorem cert_e1202986053146 : check e1202986053146 [[]] .width = true := by decide
def e1202986056218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986056218 : Closed e1202986056218 ∧ code e1202986056218 = 5601032567322 := by decide
theorem cert_e1202986056218 : check e1202986056218 [[]] .width = true := by decide
def e1202986057754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202986057754 : Closed e1202986057754 ∧ code e1202986057754 = 5601032568858 := by decide
theorem cert_e1202986057754 : check e1202986057754 [[]] .width = true := by decide
def e1202986057846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202986057846 : Closed e1202986057846 ∧ code e1202986057846 = 5601032568950 := by decide
theorem cert_e1202986057846 : check e1202986057846 [[]] .width = true := by decide
def e1202986058090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202986058090 : Closed e1202986058090 ∧ code e1202986058090 = 5601032569194 := by decide
theorem cert_e1202986058090 : check e1202986058090 [[]] .width = true := by decide
def e1202986058138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202986058138 : Closed e1202986058138 ∧ code e1202986058138 = 5601032569242 := by decide
theorem cert_e1202986058138 : check e1202986058138 [[]] .width = true := by decide
def e1202986059146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202986059146 : Closed e1202986059146 ∧ code e1202986059146 = 5601032570250 := by decide
theorem cert_e1202986059146 : check e1202986059146 [[]] .width = true := by decide
def e1202986059170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202986059170 : Closed e1202986059170 ∧ code e1202986059170 = 5601032570274 := by decide
theorem cert_e1202986059170 : check e1202986059170 [[]] .width = true := by decide
def e1202986059278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202986059278 : Closed e1202986059278 ∧ code e1202986059278 = 5601032570382 := by decide
theorem cert_e1202986059278 : check e1202986059278 [[]] .width = true := by decide
def e1202986059290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202986059290 : Closed e1202986059290 ∧ code e1202986059290 = 5601032570394 := by decide
theorem cert_e1202986059290 : check e1202986059290 [[]] .width = true := by decide
def e1202986059362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202986059362 : Closed e1202986059362 ∧ code e1202986059362 = 5601032570466 := by decide
theorem cert_e1202986059362 : check e1202986059362 [[]] .width = true := by decide
def e1202986104346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986104346 : Closed e1202986104346 ∧ code e1202986104346 = 5601032615450 := by decide
theorem cert_e1202986104346 : check e1202986104346 [[]] .width = true := by decide
def e1202986105370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986105370 : Closed e1202986105370 ∧ code e1202986105370 = 5601032616474 := by decide
theorem cert_e1202986105370 : check e1202986105370 [[]] .width = true := by decide
def e1202986725574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986725574 : Closed e1202986725574 ∧ code e1202986725574 = 5601033236678 := by decide
theorem cert_e1202986725574 : check e1202986725574 [[]] .width = true := by decide
def e1202986735642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986735642 : Closed e1202986735642 ∧ code e1202986735642 = 5601033246746 := by decide
theorem cert_e1202986735642 : check e1202986735642 [[]] .width = true := by decide
def e1202986739738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986739738 : Closed e1202986739738 ∧ code e1202986739738 = 5601033250842 := by decide
theorem cert_e1202986739738 : check e1202986739738 [[]] .width = true := by decide
def e1202986741274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986741274 : Closed e1202986741274 ∧ code e1202986741274 = 5601033252378 := by decide
theorem cert_e1202986741274 : check e1202986741274 [[]] .width = true := by decide
def e1202986743322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986743322 : Closed e1202986743322 ∧ code e1202986743322 = 5601033254426 := by decide
theorem cert_e1202986743322 : check e1202986743322 [[]] .width = true := by decide
def e1202986825754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986825754 : Closed e1202986825754 ∧ code e1202986825754 = 5601033336858 := by decide
theorem cert_e1202986825754 : check e1202986825754 [[]] .width = true := by decide
def e1202986860742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202986860742 : Closed e1202986860742 ∧ code e1202986860742 = 5601033371846 := by decide
theorem cert_e1202986860742 : check e1202986860742 [[]] .width = true := by decide
def e1202986881222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986881222 : Closed e1202986881222 ∧ code e1202986881222 = 5601033392326 := by decide
theorem cert_e1202986881222 : check e1202986881222 [[]] .width = true := by decide
def e1202986883098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986883098 : Closed e1202986883098 ∧ code e1202986883098 = 5601033394202 := by decide
theorem cert_e1202986883098 : check e1202986883098 [[]] .width = true := by decide
def e1202986884634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986884634 : Closed e1202986884634 ∧ code e1202986884634 = 5601033395738 := by decide
theorem cert_e1202986884634 : check e1202986884634 [[]] .width = true := by decide
def e1202986893510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202986893510 : Closed e1202986893510 ∧ code e1202986893510 = 5601033404614 := by decide
theorem cert_e1202986893510 : check e1202986893510 [[]] .width = true := by decide
def e1202986901530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202986901530 : Closed e1202986901530 ∧ code e1202986901530 = 5601033412634 := by decide
theorem cert_e1202986901530 : check e1202986901530 [[]] .width = true := by decide
def e1202986901622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202986901622 : Closed e1202986901622 ∧ code e1202986901622 = 5601033412726 := by decide
theorem cert_e1202986901622 : check e1202986901622 [[]] .width = true := by decide
def e1202986901866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202986901866 : Closed e1202986901866 ∧ code e1202986901866 = 5601033412970 := by decide
theorem cert_e1202986901866 : check e1202986901866 [[]] .width = true := by decide
def e1202986901914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202986901914 : Closed e1202986901914 ∧ code e1202986901914 = 5601033413018 := by decide
theorem cert_e1202986901914 : check e1202986901914 [[]] .width = true := by decide
def e1202986905798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986905798 : Closed e1202986905798 ∧ code e1202986905798 = 5601033416902 := by decide
theorem cert_e1202986905798 : check e1202986905798 [[]] .width = true := by decide
def e1202986913306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986913306 : Closed e1202986913306 ∧ code e1202986913306 = 5601033424410 := by decide
theorem cert_e1202986913306 : check e1202986913306 [[]] .width = true := by decide
def e1202986922182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986922182 : Closed e1202986922182 ∧ code e1202986922182 = 5601033433286 := by decide
theorem cert_e1202986922182 : check e1202986922182 [[]] .width = true := by decide
def e1202986963142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202986963142 : Closed e1202986963142 ∧ code e1202986963142 = 5601033474246 := by decide
theorem cert_e1202986963142 : check e1202986963142 [[]] .width = true := by decide
def e1202986969114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202986969114 : Closed e1202986969114 ∧ code e1202986969114 = 5601033480218 := by decide
theorem cert_e1202986969114 : check e1202986969114 [[]] .width = true := by decide
def e1202986970650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986970650 : Closed e1202986970650 ∧ code e1202986970650 = 5601033481754 := by decide
theorem cert_e1202986970650 : check e1202986970650 [[]] .width = true := by decide
def e1202986973722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202986973722 : Closed e1202986973722 ∧ code e1202986973722 = 5601033484826 := by decide
theorem cert_e1202986973722 : check e1202986973722 [[]] .width = true := by decide
def e1202987012294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987012294 : Closed e1202987012294 ∧ code e1202987012294 = 5601033523398 := by decide
theorem cert_e1202987012294 : check e1202987012294 [[]] .width = true := by decide
def e1202987014170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202987014170 : Closed e1202987014170 ∧ code e1202987014170 = 5601033525274 := by decide
theorem cert_e1202987014170 : check e1202987014170 [[]] .width = true := by decide
def e1202987015706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987015706 : Closed e1202987015706 ∧ code e1202987015706 = 5601033526810 := by decide
theorem cert_e1202987015706 : check e1202987015706 [[]] .width = true := by decide
def e1202987024582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202987024582 : Closed e1202987024582 ∧ code e1202987024582 = 5601033535686 := by decide
theorem cert_e1202987024582 : check e1202987024582 [[]] .width = true := by decide
def e1202987032602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202987032602 : Closed e1202987032602 ∧ code e1202987032602 = 5601033543706 := by decide
theorem cert_e1202987032602 : check e1202987032602 [[]] .width = true := by decide
def e1202987032694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202987032694 : Closed e1202987032694 ∧ code e1202987032694 = 5601033543798 := by decide
theorem cert_e1202987032694 : check e1202987032694 [[]] .width = true := by decide
def e1202987032938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202987032938 : Closed e1202987032938 ∧ code e1202987032938 = 5601033544042 := by decide
theorem cert_e1202987032938 : check e1202987032938 [[]] .width = true := by decide
def e1202987032986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202987032986 : Closed e1202987032986 ∧ code e1202987032986 = 5601033544090 := by decide
theorem cert_e1202987032986 : check e1202987032986 [[]] .width = true := by decide
def e1202987036870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987036870 : Closed e1202987036870 ∧ code e1202987036870 = 5601033547974 := by decide
theorem cert_e1202987036870 : check e1202987036870 [[]] .width = true := by decide
def e1202987048986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202987048986 : Closed e1202987048986 ∧ code e1202987048986 = 5601033560090 := by decide
theorem cert_e1202987048986 : check e1202987048986 [[]] .width = true := by decide
def e1202987049078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202987049078 : Closed e1202987049078 ∧ code e1202987049078 = 5601033560182 := by decide
private def t_e1202987049078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202987049078 : ¬ IsSelfInterpreter e1202987049078 :=
  wSource (t := t_e1202987049078) (replay_sound (ps := []) (t := e1202987049078) (by decide)) (by decide)
def e1202987049322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202987049322 : Closed e1202987049322 ∧ code e1202987049322 = 5601033560426 := by decide
private def t_e1202987049322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202987049322 : ¬ IsSelfInterpreter e1202987049322 :=
  wSource (t := t_e1202987049322) (replay_sound (ps := []) (t := e1202987049322) (by decide)) (by decide)
def e1202987049370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202987049370 : Closed e1202987049370 ∧ code e1202987049370 = 5601033560474 := by decide
private def t_e1202987049370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202987049370 : ¬ IsSelfInterpreter e1202987049370 :=
  wSource (t := t_e1202987049370) (replay_sound (ps := []) (t := e1202987049370) (by decide)) (by decide)
def e1202987058714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987058714 : Closed e1202987058714 ∧ code e1202987058714 = 5601033569818 := by decide
private def t_e1202987058714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202987058714 : ¬ IsSelfInterpreter e1202987058714 :=
  wSource (t := t_e1202987058714) (replay_sound (ps := []) (t := e1202987058714) (by decide)) (by decide)
def e1202987061446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987061446 : Closed e1202987061446 ∧ code e1202987061446 = 5601033572550 := by decide
theorem cert_e1202987061446 : check e1202987061446 [[]] .width = true := by decide
def e1202987087386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987087386 : Closed e1202987087386 ∧ code e1202987087386 = 5601033598490 := by decide
theorem cert_e1202987087386 : check e1202987087386 [[]] .width = true := by decide
def e1202987088410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987088410 : Closed e1202987088410 ∧ code e1202987088410 = 5601033599514 := by decide
theorem cert_e1202987088410 : check e1202987088410 [[]] .width = true := by decide
def e1202987109914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987109914 : Closed e1202987109914 ∧ code e1202987109914 = 5601033621018 := by decide
theorem cert_e1202987109914 : check e1202987109914 [[]] .width = true := by decide
def e1202987118790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987118790 : Closed e1202987118790 ∧ code e1202987118790 = 5601033629894 := by decide
theorem cert_e1202987118790 : check e1202987118790 [[]] .width = true := by decide
def e1202987124250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987124250 : Closed e1202987124250 ∧ code e1202987124250 = 5601033635354 := by decide
private def t_e1202987124250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202987124250 : ¬ IsSelfInterpreter e1202987124250 :=
  wSource (t := t_e1202987124250) (replay_sound (ps := []) (t := e1202987124250) (by decide)) (by decide)
def e1202987126982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987126982 : Closed e1202987126982 ∧ code e1202987126982 = 5601033638086 := by decide
theorem cert_e1202987126982 : check e1202987126982 [[]] .width = true := by decide
def e1202987266246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987266246 : Closed e1202987266246 ∧ code e1202987266246 = 5601033777350 := by decide
theorem cert_e1202987266246 : check e1202987266246 [[]] .width = true := by decide
def e1202987317274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202987317274 : Closed e1202987317274 ∧ code e1202987317274 = 5601033828378 := by decide
theorem cert_e1202987317274 : check e1202987317274 [[]] .width = true := by decide
def e1202987329562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202987329562 : Closed e1202987329562 ∧ code e1202987329562 = 5601033840666 := by decide
theorem cert_e1202987329562 : check e1202987329562 [[]] .width = true := by decide
def e1202987434010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202987434010 : Closed e1202987434010 ∧ code e1202987434010 = 5601033945114 := by decide
theorem cert_e1202987434010 : check e1202987434010 [[]] .width = true := by decide
def e1202987434102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202987434102 : Closed e1202987434102 ∧ code e1202987434102 = 5601033945206 := by decide
theorem cert_e1202987434102 : check e1202987434102 [[]] .width = true := by decide
def e1202987434346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202987434346 : Closed e1202987434346 ∧ code e1202987434346 = 5601033945450 := by decide
theorem cert_e1202987434346 : check e1202987434346 [[]] .width = true := by decide
def e1202987434394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202987434394 : Closed e1202987434394 ∧ code e1202987434394 = 5601033945498 := by decide
theorem cert_e1202987434394 : check e1202987434394 [[]] .width = true := by decide
def e1202987435402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202987435402 : Closed e1202987435402 ∧ code e1202987435402 = 5601033946506 := by decide
theorem cert_e1202987435402 : check e1202987435402 [[]] .width = true := by decide
def e1202987435426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202987435426 : Closed e1202987435426 ∧ code e1202987435426 = 5601033946530 := by decide
theorem cert_e1202987435426 : check e1202987435426 [[]] .width = true := by decide
def e1202987435534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202987435534 : Closed e1202987435534 ∧ code e1202987435534 = 5601033946638 := by decide
theorem cert_e1202987435534 : check e1202987435534 [[]] .width = true := by decide
def e1202987435546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202987435546 : Closed e1202987435546 ∧ code e1202987435546 = 5601033946650 := by decide
theorem cert_e1202987435546 : check e1202987435546 [[]] .width = true := by decide
def e1202987435618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202987435618 : Closed e1202987435618 ∧ code e1202987435618 = 5601033946722 := by decide
theorem cert_e1202987435618 : check e1202987435618 [[]] .width = true := by decide
def e1202987612186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202987612186 : Closed e1202987612186 ∧ code e1202987612186 = 5601034123290 := by decide
theorem cert_e1202987612186 : check e1202987612186 [[]] .width = true := by decide
def e1202987647174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202987647174 : Closed e1202987647174 ∧ code e1202987647174 = 5601034158278 := by decide
theorem cert_e1202987647174 : check e1202987647174 [[]] .width = true := by decide
def e1202987667654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987667654 : Closed e1202987667654 ∧ code e1202987667654 = 5601034178758 := by decide
theorem cert_e1202987667654 : check e1202987667654 [[]] .width = true := by decide
def e1202987669530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202987669530 : Closed e1202987669530 ∧ code e1202987669530 = 5601034180634 := by decide
theorem cert_e1202987669530 : check e1202987669530 [[]] .width = true := by decide
def e1202987671066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987671066 : Closed e1202987671066 ∧ code e1202987671066 = 5601034182170 := by decide
theorem cert_e1202987671066 : check e1202987671066 [[]] .width = true := by decide
def e1202987679942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202987679942 : Closed e1202987679942 ∧ code e1202987679942 = 5601034191046 := by decide
theorem cert_e1202987679942 : check e1202987679942 [[]] .width = true := by decide
def e1202987687962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202987687962 : Closed e1202987687962 ∧ code e1202987687962 = 5601034199066 := by decide
theorem cert_e1202987687962 : check e1202987687962 [[]] .width = true := by decide
def e1202987688054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202987688054 : Closed e1202987688054 ∧ code e1202987688054 = 5601034199158 := by decide
theorem cert_e1202987688054 : check e1202987688054 [[]] .width = true := by decide
def e1202987688298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202987688298 : Closed e1202987688298 ∧ code e1202987688298 = 5601034199402 := by decide
theorem cert_e1202987688298 : check e1202987688298 [[]] .width = true := by decide
def e1202987688346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202987688346 : Closed e1202987688346 ∧ code e1202987688346 = 5601034199450 := by decide
theorem cert_e1202987688346 : check e1202987688346 [[]] .width = true := by decide
def e1202987692230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987692230 : Closed e1202987692230 ∧ code e1202987692230 = 5601034203334 := by decide
theorem cert_e1202987692230 : check e1202987692230 [[]] .width = true := by decide
def e1202987699738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202987699738 : Closed e1202987699738 ∧ code e1202987699738 = 5601034210842 := by decide
theorem cert_e1202987699738 : check e1202987699738 [[]] .width = true := by decide
def e1202987708614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202987708614 : Closed e1202987708614 ∧ code e1202987708614 = 5601034219718 := by decide
theorem cert_e1202987708614 : check e1202987708614 [[]] .width = true := by decide
def e1202987991238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202987991238 : Closed e1202987991238 ∧ code e1202987991238 = 5601034502342 := by decide
theorem cert_e1202987991238 : check e1202987991238 [[]] .width = true := by decide
def e1202987991766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202987991766 : Closed e1202987991766 ∧ code e1202987991766 = 5601034502870 := by decide
theorem cert_e1202987991766 : check e1202987991766 [[]] .width = true := by decide
def e1202987991770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202987991770 : Closed e1202987991770 ∧ code e1202987991770 = 5601034502874 := by decide
theorem cert_e1202987991770 : check e1202987991770 [[]] .width = true := by decide
def e1202987991786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202987991786 : Closed e1202987991786 ∧ code e1202987991786 = 5601034502890 := by decide
theorem cert_e1202987991786 : check e1202987991786 [[]] .width = true := by decide
def e1202987991862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202987991862 : Closed e1202987991862 ∧ code e1202987991862 = 5601034502966 := by decide
theorem cert_e1202987991862 : check e1202987991862 [[]] .width = true := by decide
def e1202987991866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202987991866 : Closed e1202987991866 ∧ code e1202987991866 = 5601034502970 := by decide
theorem cert_e1202987991866 : check e1202987991866 [[]] .width = true := by decide
def e1202987991950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202987991950 : Closed e1202987991950 ∧ code e1202987991950 = 5601034503054 := by decide
theorem cert_e1202987991950 : check e1202987991950 [[]] .width = true := by decide
def e1202987991962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202987991962 : Closed e1202987991962 ∧ code e1202987991962 = 5601034503066 := by decide
theorem cert_e1202987991962 : check e1202987991962 [[]] .width = true := by decide
end Blc.Floor42
