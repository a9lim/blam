import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211301170134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211301170134 : Closed e1211301170134 ∧ code e1211301170134 = 5609347681238 := by decide
theorem cert_e1211301170134 : check e1211301170134 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211301170138 : Closed e1211301170138 ∧ code e1211301170138 = 5609347681242 := by decide
theorem cert_e1211301170138 : check e1211301170138 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211301170414 : Closed e1211301170414 ∧ code e1211301170414 = 5609347681518 := by decide
theorem cert_e1211301170414 : check e1211301170414 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211301170422 : Closed e1211301170422 ∧ code e1211301170422 = 5609347681526 := by decide
theorem cert_e1211301170422 : check e1211301170422 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211301170798 : Closed e1211301170798 ∧ code e1211301170798 = 5609347681902 := by decide
theorem cert_e1211301170798 : check e1211301170798 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211301170810 : Closed e1211301170810 ∧ code e1211301170810 = 5609347681914 := by decide
theorem cert_e1211301170810 : check e1211301170810 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211301170998 : Closed e1211301170998 ∧ code e1211301170998 = 5609347682102 := by decide
theorem cert_e1211301170998 : check e1211301170998 [[],[],[.under]] .sourceHead = true := by decide
def e1211301171002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211301171002 : Closed e1211301171002 ∧ code e1211301171002 = 5609347682106 := by decide
theorem cert_e1211301171002 : check e1211301171002 [[],[],[.under]] .sourceHead = true := by decide
def e1211301375454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211301375454 : Closed e1211301375454 ∧ code e1211301375454 = 5609347886558 := by decide
theorem cert_e1211301375454 : checkPay e1211301375454 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301375470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211301375470 : Closed e1211301375470 ∧ code e1211301375470 = 5609347886574 := by decide
theorem cert_e1211301375470 : checkPay e1211301375470 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301375838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211301375838 : Closed e1211301375838 ∧ code e1211301375838 = 5609347886942 := by decide
theorem cert_e1211301375838 : checkPay e1211301375838 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301375866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211301375866 : Closed e1211301375866 ∧ code e1211301375866 = 5609347886970 := by decide
theorem cert_e1211301375866 : checkPay e1211301375866 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301375918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211301375918 : Closed e1211301375918 ∧ code e1211301375918 = 5609347887022 := by decide
theorem cert_e1211301375918 : checkPay e1211301375918 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.left],[.under,.under]] = true := by decide
def e1211301375930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211301375930 : Closed e1211301375930 ∧ code e1211301375930 = 5609347887034 := by decide
theorem cert_e1211301375930 : checkPay e1211301375930 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.left],[.under,.under]] = true := by decide
def e1211301376990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211301376990 : Closed e1211301376990 ∧ code e1211301376990 = 5609347888094 := by decide
theorem cert_e1211301376990 : checkPay e1211301376990 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301377006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211301377006 : Closed e1211301377006 ∧ code e1211301377006 = 5609347888110 := by decide
theorem cert_e1211301377006 : checkPay e1211301377006 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.right]] = true := by decide
def e1211301379294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211301379294 : Closed e1211301379294 ∧ code e1211301379294 = 5609347890398 := by decide
theorem cert_e1211301379294 : checkPay e1211301379294 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301379322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211301379322 : Closed e1211301379322 ∧ code e1211301379322 = 5609347890426 := by decide
theorem cert_e1211301379322 : checkPay e1211301379322 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.right]] = true := by decide
def e1211301379694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211301379694 : Closed e1211301379694 ∧ code e1211301379694 = 5609347890798 := by decide
theorem cert_e1211301379694 : checkPay e1211301379694 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e1211301379706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211301379706 : Closed e1211301379706 ∧ code e1211301379706 = 5609347890810 := by decide
theorem cert_e1211301379706 : checkPay e1211301379706 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e1211301408110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211301408110 : Closed e1211301408110 ∧ code e1211301408110 = 5609347919214 := by decide
theorem cert_e1211301408110 : checkPay e1211301408110 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211301408118 : Closed e1211301408118 ∧ code e1211301408118 = 5609347919222 := by decide
theorem cert_e1211301408118 : checkPay e1211301408118 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211301408174 : Closed e1211301408174 ∧ code e1211301408174 = 5609347919278 := by decide
theorem cert_e1211301408174 : checkPay e1211301408174 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211301408186 : Closed e1211301408186 ∧ code e1211301408186 = 5609347919290 := by decide
theorem cert_e1211301408186 : checkPay e1211301408186 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211301408214 : Closed e1211301408214 ∧ code e1211301408214 = 5609347919318 := by decide
theorem cert_e1211301408214 : checkPay e1211301408214 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211301408218 : Closed e1211301408218 ∧ code e1211301408218 = 5609347919322 := by decide
theorem cert_e1211301408218 : checkPay e1211301408218 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211301408430 : Closed e1211301408430 ∧ code e1211301408430 = 5609347919534 := by decide
theorem cert_e1211301408430 : checkPay e1211301408430 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211301408442 : Closed e1211301408442 ∧ code e1211301408442 = 5609347919546 := by decide
theorem cert_e1211301408442 : checkPay e1211301408442 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211301408490 : Closed e1211301408490 ∧ code e1211301408490 = 5609347919594 := by decide
theorem cert_e1211301408490 : checkPay e1211301408490 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301408598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211301408598 : Closed e1211301408598 ∧ code e1211301408598 = 5609347919702 := by decide
theorem cert_e1211301408598 : checkPay e1211301408598 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.left],[.under,.left]] = true := by decide
def e1211301408602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211301408602 : Closed e1211301408602 ∧ code e1211301408602 = 5609347919706 := by decide
theorem cert_e1211301408602 : checkPay e1211301408602 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.left],[.under,.left]] = true := by decide
def e1211301408618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211301408618 : Closed e1211301408618 ∧ code e1211301408618 = 5609347919722 := by decide
theorem cert_e1211301408618 : checkPay e1211301408618 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.left],[.under,.left]] = true := by decide
def e1211301409646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211301409646 : Closed e1211301409646 ∧ code e1211301409646 = 5609347920750 := by decide
theorem cert_e1211301409646 : checkPay e1211301409646 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301409654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211301409654 : Closed e1211301409654 ∧ code e1211301409654 = 5609347920758 := by decide
theorem cert_e1211301409654 : checkPay e1211301409654 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301409710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211301409710 : Closed e1211301409710 ∧ code e1211301409710 = 5609347920814 := by decide
theorem cert_e1211301409710 : checkPay e1211301409710 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301409722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211301409722 : Closed e1211301409722 ∧ code e1211301409722 = 5609347920826 := by decide
theorem cert_e1211301409722 : checkPay e1211301409722 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301409750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211301409750 : Closed e1211301409750 ∧ code e1211301409750 = 5609347920854 := by decide
theorem cert_e1211301409750 : checkPay e1211301409750 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.right]] = true := by decide
def e1211301409754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211301409754 : Closed e1211301409754 ∧ code e1211301409754 = 5609347920858 := by decide
theorem cert_e1211301409754 : checkPay e1211301409754 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.right]] = true := by decide
def e1211301410030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211301410030 : Closed e1211301410030 ∧ code e1211301410030 = 5609347921134 := by decide
theorem cert_e1211301410030 : checkPay e1211301410030 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301410038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211301410038 : Closed e1211301410038 ∧ code e1211301410038 = 5609347921142 := by decide
theorem cert_e1211301410038 : checkPay e1211301410038 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301410414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211301410414 : Closed e1211301410414 ∧ code e1211301410414 = 5609347921518 := by decide
theorem cert_e1211301410414 : checkPay e1211301410414 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301410426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211301410426 : Closed e1211301410426 ∧ code e1211301410426 = 5609347921530 := by decide
theorem cert_e1211301410426 : checkPay e1211301410426 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301410614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211301410614 : Closed e1211301410614 ∧ code e1211301410614 = 5609347921718 := by decide
theorem cert_e1211301410614 : checkPay e1211301410614 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301410618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211301410618 : Closed e1211301410618 ∧ code e1211301410618 = 5609347921722 := by decide
theorem cert_e1211301410618 : checkPay e1211301410618 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301411246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211301411246 : Closed e1211301411246 ∧ code e1211301411246 = 5609347922350 := by decide
theorem cert_e1211301411246 : checkPay e1211301411246 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301411258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211301411258 : Closed e1211301411258 ∧ code e1211301411258 = 5609347922362 := by decide
theorem cert_e1211301411258 : checkPay e1211301411258 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301411306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211301411306 : Closed e1211301411306 ∧ code e1211301411306 = 5609347922410 := by decide
theorem cert_e1211301411306 : checkPay e1211301411306 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left,.right]] = true := by decide
def e1211301411438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211301411438 : Closed e1211301411438 ∧ code e1211301411438 = 5609347922542 := by decide
theorem cert_e1211301411438 : checkPay e1211301411438 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301411450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211301411450 : Closed e1211301411450 ∧ code e1211301411450 = 5609347922554 := by decide
theorem cert_e1211301411450 : checkPay e1211301411450 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301411738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211301411738 : Closed e1211301411738 ∧ code e1211301411738 = 5609347922842 := by decide
theorem cert_e1211301411738 : checkPay e1211301411738 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301412054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211301412054 : Closed e1211301412054 ∧ code e1211301412054 = 5609347923158 := by decide
theorem cert_e1211301412054 : checkPay e1211301412054 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301412058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211301412058 : Closed e1211301412058 ∧ code e1211301412058 = 5609347923162 := by decide
theorem cert_e1211301412058 : checkPay e1211301412058 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301412074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211301412074 : Closed e1211301412074 ∧ code e1211301412074 = 5609347923178 := by decide
theorem cert_e1211301412074 : checkPay e1211301412074 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301412150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211301412150 : Closed e1211301412150 ∧ code e1211301412150 = 5609347923254 := by decide
theorem cert_e1211301412150 : checkPay e1211301412150 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301412154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211301412154 : Closed e1211301412154 ∧ code e1211301412154 = 5609347923258 := by decide
theorem cert_e1211301412154 : checkPay e1211301412154 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301412250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211301412250 : Closed e1211301412250 ∧ code e1211301412250 = 5609347923354 := by decide
theorem cert_e1211301412250 : checkPay e1211301412250 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e1211301413854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211301413854 : Closed e1211301413854 ∧ code e1211301413854 = 5609347924958 := by decide
theorem cert_e1211301413854 : checkPay e1211301413854 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301413870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211301413870 : Closed e1211301413870 ∧ code e1211301413870 = 5609347924974 := by decide
theorem cert_e1211301413870 : checkPay e1211301413870 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.under]] = true := by decide
def e1211301415790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211301415790 : Closed e1211301415790 ∧ code e1211301415790 = 5609347926894 := by decide
theorem cert_e1211301415790 : checkPay e1211301415790 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301415798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211301415798 : Closed e1211301415798 ∧ code e1211301415798 = 5609347926902 := by decide
theorem cert_e1211301415798 : checkPay e1211301415798 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301415854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211301415854 : Closed e1211301415854 ∧ code e1211301415854 = 5609347926958 := by decide
theorem cert_e1211301415854 : checkPay e1211301415854 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301415866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211301415866 : Closed e1211301415866 ∧ code e1211301415866 = 5609347926970 := by decide
theorem cert_e1211301415866 : checkPay e1211301415866 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301415894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211301415894 : Closed e1211301415894 ∧ code e1211301415894 = 5609347926998 := by decide
theorem cert_e1211301415894 : checkPay e1211301415894 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.left],[.under,.right]] = true := by decide
def e1211301415898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211301415898 : Closed e1211301415898 ∧ code e1211301415898 = 5609347927002 := by decide
theorem cert_e1211301415898 : checkPay e1211301415898 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.left],[.under,.right]] = true := by decide
def e1211301416174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211301416174 : Closed e1211301416174 ∧ code e1211301416174 = 5609347927278 := by decide
theorem cert_e1211301416174 : checkPay e1211301416174 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301416182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211301416182 : Closed e1211301416182 ∧ code e1211301416182 = 5609347927286 := by decide
theorem cert_e1211301416182 : checkPay e1211301416182 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.right]] = true := by decide
def e1211301416558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211301416558 : Closed e1211301416558 ∧ code e1211301416558 = 5609347927662 := by decide
theorem cert_e1211301416558 : checkPay e1211301416558 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301416570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211301416570 : Closed e1211301416570 ∧ code e1211301416570 = 5609347927674 := by decide
theorem cert_e1211301416570 : checkPay e1211301416570 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.right]] = true := by decide
def e1211301416758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211301416758 : Closed e1211301416758 ∧ code e1211301416758 = 5609347927862 := by decide
theorem cert_e1211301416758 : checkPay e1211301416758 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301416762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211301416762 : Closed e1211301416762 ∧ code e1211301416762 = 5609347927866 := by decide
theorem cert_e1211301416762 : checkPay e1211301416762 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301421534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211301421534 : Closed e1211301421534 ∧ code e1211301421534 = 5609347932638 := by decide
theorem cert_e1211301421534 : checkPay e1211301421534 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301421558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211301421558 : Closed e1211301421558 ∧ code e1211301421558 = 5609347932662 := by decide
theorem cert_e1211301421558 : checkPay e1211301421558 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.under]] = true := by decide
def e1211301422510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211301422510 : Closed e1211301422510 ∧ code e1211301422510 = 5609347933614 := by decide
theorem cert_e1211301422510 : checkPay e1211301422510 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301422522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211301422522 : Closed e1211301422522 ∧ code e1211301422522 = 5609347933626 := by decide
theorem cert_e1211301422522 : checkPay e1211301422522 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301422570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211301422570 : Closed e1211301422570 ∧ code e1211301422570 = 5609347933674 := by decide
theorem cert_e1211301422570 : checkPay e1211301422570 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.left],[.under,.right]] = true := by decide
def e1211301422702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211301422702 : Closed e1211301422702 ∧ code e1211301422702 = 5609347933806 := by decide
theorem cert_e1211301422702 : checkPay e1211301422702 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301422714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211301422714 : Closed e1211301422714 ∧ code e1211301422714 = 5609347933818 := by decide
theorem cert_e1211301422714 : checkPay e1211301422714 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right,.right]] = true := by decide
def e1211301423002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211301423002 : Closed e1211301423002 ∧ code e1211301423002 = 5609347934106 := by decide
theorem cert_e1211301423002 : checkPay e1211301423002 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1211301425390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211301425390 : Closed e1211301425390 ∧ code e1211301425390 = 5609347936494 := by decide
theorem cert_e1211301425390 : checkPay e1211301425390 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under],[.under,.under]] = true := by decide
def e1211301425398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211301425398 : Closed e1211301425398 ∧ code e1211301425398 = 5609347936502 := by decide
theorem cert_e1211301425398 : checkPay e1211301425398 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under],[.under,.under]] = true := by decide
def e1211301425878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211301425878 : Closed e1211301425878 ∧ code e1211301425878 = 5609347936982 := by decide
theorem cert_e1211301425878 : checkPay e1211301425878 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301425882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211301425882 : Closed e1211301425882 ∧ code e1211301425882 = 5609347936986 := by decide
theorem cert_e1211301425882 : checkPay e1211301425882 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301425898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211301425898 : Closed e1211301425898 ∧ code e1211301425898 = 5609347937002 := by decide
theorem cert_e1211301425898 : checkPay e1211301425898 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301425974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211301425974 : Closed e1211301425974 ∧ code e1211301425974 = 5609347937078 := by decide
theorem cert_e1211301425974 : checkPay e1211301425974 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301425978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211301425978 : Closed e1211301425978 ∧ code e1211301425978 = 5609347937082 := by decide
theorem cert_e1211301425978 : checkPay e1211301425978 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301426074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211301426074 : Closed e1211301426074 ∧ code e1211301426074 = 5609347937178 := by decide
theorem cert_e1211301426074 : checkPay e1211301426074 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211301563246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211301563246 : Closed e1211301563246 ∧ code e1211301563246 = 5609348074350 := by decide
theorem cert_e1211301563246 : checkPay e1211301563246 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301563254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211301563254 : Closed e1211301563254 ∧ code e1211301563254 = 5609348074358 := by decide
theorem cert_e1211301563254 : checkPay e1211301563254 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301563310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211301563310 : Closed e1211301563310 ∧ code e1211301563310 = 5609348074414 := by decide
theorem cert_e1211301563310 : checkPay e1211301563310 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301563322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211301563322 : Closed e1211301563322 ∧ code e1211301563322 = 5609348074426 := by decide
theorem cert_e1211301563322 : checkPay e1211301563322 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301563350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211301563350 : Closed e1211301563350 ∧ code e1211301563350 = 5609348074454 := by decide
theorem cert_e1211301563350 : checkPay e1211301563350 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under,.left],[.right,.under]] = true := by decide
def e1211301563354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211301563354 : Closed e1211301563354 ∧ code e1211301563354 = 5609348074458 := by decide
theorem cert_e1211301563354 : checkPay e1211301563354 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under,.left],[.right,.under]] = true := by decide
def e1211301563630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211301563630 : Closed e1211301563630 ∧ code e1211301563630 = 5609348074734 := by decide
theorem cert_e1211301563630 : checkPay e1211301563630 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301563638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211301563638 : Closed e1211301563638 ∧ code e1211301563638 = 5609348074742 := by decide
theorem cert_e1211301563638 : checkPay e1211301563638 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under,.right]] = true := by decide
def e1211301564014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211301564014 : Closed e1211301564014 ∧ code e1211301564014 = 5609348075118 := by decide
theorem cert_e1211301564014 : checkPay e1211301564014 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211301564026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211301564026 : Closed e1211301564026 ∧ code e1211301564026 = 5609348075130 := by decide
theorem cert_e1211301564026 : checkPay e1211301564026 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under,.right]] = true := by decide
def e1211301564214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211301564214 : Closed e1211301564214 ∧ code e1211301564214 = 5609348075318 := by decide
theorem cert_e1211301564214 : checkPay e1211301564214 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under]] = true := by decide
def e1211301564218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211301564218 : Closed e1211301564218 ∧ code e1211301564218 = 5609348075322 := by decide
theorem cert_e1211301564218 : checkPay e1211301564218 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right,.under]] = true := by decide
def e1211301893854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211301893854 : Closed e1211301893854 ∧ code e1211301893854 = 5609348404958 := by decide
theorem cert_e1211301893854 : check e1211301893854 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301893878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211301893878 : Closed e1211301893878 ∧ code e1211301893878 = 5609348404982 := by decide
theorem cert_e1211301893878 : check e1211301893878 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301893982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211301893982 : Closed e1211301893982 ∧ code e1211301893982 = 5609348405086 := by decide
theorem cert_e1211301893982 : check e1211301893982 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301894010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211301894010 : Closed e1211301894010 ∧ code e1211301894010 = 5609348405114 := by decide
private def t_e1211301894010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e1211301894010 : ¬ IsSelfInterpreter e1211301894010 :=
  wSource (t := t_e1211301894010) (replay_sound (ps := []) (t := e1211301894010) (by decide)) (by decide)
def e1211301894102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211301894102 : Closed e1211301894102 ∧ code e1211301894102 = 5609348405206 := by decide
theorem cert_e1211301894102 : check e1211301894102 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301894106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211301894106 : Closed e1211301894106 ∧ code e1211301894106 = 5609348405210 := by decide
private def t_e1211301894106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e1211301894106 : ¬ IsSelfInterpreter e1211301894106 :=
  wSource (t := t_e1211301894106) (replay_sound (ps := []) (t := e1211301894106) (by decide)) (by decide)
def e1211301894622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211301894622 : Closed e1211301894622 ∧ code e1211301894622 = 5609348405726 := by decide
theorem cert_e1211301894622 : check e1211301894622 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301894646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211301894646 : Closed e1211301894646 ∧ code e1211301894646 = 5609348405750 := by decide
theorem cert_e1211301894646 : check e1211301894646 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301895390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211301895390 : Closed e1211301895390 ∧ code e1211301895390 = 5609348406494 := by decide
theorem cert_e1211301895390 : check e1211301895390 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301895418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211301895418 : Closed e1211301895418 ∧ code e1211301895418 = 5609348406522 := by decide
theorem cert_e1211301895418 : check e1211301895418 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301895990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211301895990 : Closed e1211301895990 ∧ code e1211301895990 = 5609348407094 := by decide
theorem cert_e1211301895990 : check e1211301895990 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301895994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211301895994 : Closed e1211301895994 ∧ code e1211301895994 = 5609348407098 := by decide
theorem cert_e1211301895994 : check e1211301895994 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301910766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211301910766 : Closed e1211301910766 ∧ code e1211301910766 = 5609348421870 := by decide
theorem cert_e1211301910766 : check e1211301910766 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211301910774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211301910774 : Closed e1211301910774 ∧ code e1211301910774 = 5609348421878 := by decide
theorem cert_e1211301910774 : check e1211301910774 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211301911326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211301911326 : Closed e1211301911326 ∧ code e1211301911326 = 5609348422430 := by decide
theorem cert_e1211301911326 : check e1211301911326 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211301911438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211301911438 : Closed e1211301911438 ∧ code e1211301911438 = 5609348422542 := by decide
private def t_e1211301911438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e1211301911438 : ¬ IsSelfInterpreter e1211301911438 :=
  wSource (t := t_e1211301911438) (replay_sound (ps := []) (t := e1211301911438) (by decide)) (by decide)
def e1211301911662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211301911662 : Closed e1211301911662 ∧ code e1211301911662 = 5609348422766 := by decide
theorem cert_e1211301911662 : checkPay e1211301911662 [[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] 0 [[.under],[.under,.left,.right,.under,.under,.left,.left,.left],[.under,.left,.right,.under,.under,.left,.left],[.under,.left,.right,.under,.under,.left,.left],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.left],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.left,.left],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.left],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.right],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.right,.under],[.under,.left,.right,.under,.under,.left,.left,.left,.right,.under,.left,.right,.under,.under,.left,.right,.under,.left,.right,.under]] = true := by decide
def e1211301911674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211301911674 : Closed e1211301911674 ∧ code e1211301911674 = 5609348422778 := by decide
theorem cert_e1211301911674 : checkPay e1211301911674 [[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] 0 [] = true := by decide
def e1211301911838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211301911838 : Closed e1211301911838 ∧ code e1211301911838 = 5609348422942 := by decide
theorem cert_e1211301911838 : checkPay e1211301911838 [[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] 0 [[],[.left,.right,.under,.left,.left,.left],[.left,.right,.under,.left,.left],[.left,.right,.under,.left,.left],[.left,.right,.under,.left,.left,.left,.right],[.left,.right,.under,.left,.left,.left,.right,.left,.right,.under,.left],[.left,.right,.under,.left,.left,.left,.right,.left,.right,.under,.left,.left],[.left,.right,.under,.left,.left,.left,.right,.left,.right,.under,.left,.right,.under],[.left,.right,.under,.left,.left,.left,.right,.left,.right,.under,.left,.right,.under,.under],[.left,.right,.under,.left,.left,.left,.right,.left,.right,.under,.left,.right,.under,.under,.left,.right]] = true := by decide
def e1211301912006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211301912006 : Closed e1211301912006 ∧ code e1211301912006 = 5609348423110 := by decide
theorem cert_e1211301912006 : checkPay e1211301912006 [[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] 0 [] = true := by decide
def e1211301912118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211301912118 : Closed e1211301912118 ∧ code e1211301912118 = 5609348423222 := by decide
def e1211301912122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211301912122 : Closed e1211301912122 ∧ code e1211301912122 = 5609348423226 := by decide
theorem cert_e1211301912122 : check e1211301912122 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e1211301912206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211301912206 : Closed e1211301912206 ∧ code e1211301912206 = 5609348423310 := by decide
private def t_e1211301912206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e1211301912206 : ¬ IsSelfInterpreter e1211301912206 :=
  wSource (t := t_e1211301912206) (replay_sound (ps := []) (t := e1211301912206) (by decide)) (by decide)
def e1211301912262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211301912262 : Closed e1211301912262 ∧ code e1211301912262 = 5609348423366 := by decide
theorem cert_e1211301912262 : check e1211301912262 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211301914398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211301914398 : Closed e1211301914398 ∧ code e1211301914398 = 5609348425502 := by decide
theorem cert_e1211301914398 : check e1211301914398 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211301914510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211301914510 : Closed e1211301914510 ∧ code e1211301914510 = 5609348425614 := by decide
theorem cert_e1211301914510 : check e1211301914510 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1211301917470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211301917470 : Closed e1211301917470 ∧ code e1211301917470 = 5609348428574 := by decide
theorem cert_e1211301917470 : check e1211301917470 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211301917638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211301917638 : Closed e1211301917638 ∧ code e1211301917638 = 5609348428742 := by decide
theorem cert_e1211301917638 : check e1211301917638 [[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211301919118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211301919118 : Closed e1211301919118 ∧ code e1211301919118 = 5609348430222 := by decide
def e1211301919174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211301919174 : Closed e1211301919174 ∧ code e1211301919174 = 5609348430278 := by decide
def e1211475168110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211475168110 : Closed e1211475168110 ∧ code e1211475168110 = 5609521679214 := by decide
theorem cert_e1211475168110 : check e1211475168110 [[],[],[],[]] .sourceHead = true := by decide
def e1211475168118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211475168118 : Closed e1211475168118 ∧ code e1211475168118 = 5609521679222 := by decide
theorem cert_e1211475168118 : check e1211475168118 [[],[],[],[]] .sourceHead = true := by decide
def e1211475168174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211475168174 : Closed e1211475168174 ∧ code e1211475168174 = 5609521679278 := by decide
theorem cert_e1211475168174 : check e1211475168174 [[],[],[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1211475168186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211475168186 : Closed e1211475168186 ∧ code e1211475168186 = 5609521679290 := by decide
theorem cert_e1211475168186 : check e1211475168186 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211475168214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211475168214 : Closed e1211475168214 ∧ code e1211475168214 = 5609521679318 := by decide
theorem cert_e1211475168214 : check e1211475168214 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211475168218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211475168218 : Closed e1211475168218 ∧ code e1211475168218 = 5609521679322 := by decide
theorem cert_e1211475168218 : check e1211475168218 [[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211475168494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211475168494 : Closed e1211475168494 ∧ code e1211475168494 = 5609521679598 := by decide
theorem cert_e1211475168494 : check e1211475168494 [[],[],[],[]] .sourceHead = true := by decide
def e1211475168502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211475168502 : Closed e1211475168502 ∧ code e1211475168502 = 5609521679606 := by decide
theorem cert_e1211475168502 : check e1211475168502 [[],[],[],[]] .sourceHead = true := by decide
def e1211475168878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211475168878 : Closed e1211475168878 ∧ code e1211475168878 = 5609521679982 := by decide
theorem cert_e1211475168878 : check e1211475168878 [[],[],[],[],[.under]] .three = true := by decide
def e1211475168890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211475168890 : Closed e1211475168890 ∧ code e1211475168890 = 5609521679994 := by decide
theorem cert_e1211475168890 : check e1211475168890 [[],[],[],[],[.under]] .three = true := by decide
def e1211475169078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211475169078 : Closed e1211475169078 ∧ code e1211475169078 = 5609521680182 := by decide
theorem cert_e1211475169078 : checkPay e1211475169078 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[]] 0 [[.under,.under,.under],[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e1211475169082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211475169082 : Closed e1211475169082 ∧ code e1211475169082 = 5609521680186 := by decide
theorem cert_e1211475169082 : check e1211475169082 [[],[],[],[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211476481758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211476481758 : Closed e1211476481758 ∧ code e1211476481758 = 5609522992862 := by decide
theorem cert_e1211476481758 : check e1211476481758 [[],[],[],[]] .chain = true := by decide
def e1211476481782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211476481782 : Closed e1211476481782 ∧ code e1211476481782 = 5609522992886 := by decide
theorem cert_e1211476481782 : check e1211476481782 [[],[],[],[]] .chain = true := by decide
def e1211476481886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211476481886 : Closed e1211476481886 ∧ code e1211476481886 = 5609522992990 := by decide
theorem cert_e1211476481886 : check e1211476481886 [[],[],[],[]] .chain = true := by decide
def e1211476481914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211476481914 : Closed e1211476481914 ∧ code e1211476481914 = 5609522993018 := by decide
theorem cert_e1211476481914 : check e1211476481914 [[],[],[],[]] .chain = true := by decide
def e1211476482006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211476482006 : Closed e1211476482006 ∧ code e1211476482006 = 5609522993110 := by decide
theorem cert_e1211476482006 : check e1211476482006 [[],[],[],[]] .chain = true := by decide
def e1211476482010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211476482010 : Closed e1211476482010 ∧ code e1211476482010 = 5609522993114 := by decide
theorem cert_e1211476482010 : check e1211476482010 [[],[],[],[]] .chain = true := by decide
def e1211476482526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211476482526 : Closed e1211476482526 ∧ code e1211476482526 = 5609522993630 := by decide
theorem cert_e1211476482526 : check e1211476482526 [[],[],[],[]] .chain = true := by decide
def e1211476482550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211476482550 : Closed e1211476482550 ∧ code e1211476482550 = 5609522993654 := by decide
theorem cert_e1211476482550 : check e1211476482550 [[],[],[],[]] .chain = true := by decide
def e1211476483294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211476483294 : Closed e1211476483294 ∧ code e1211476483294 = 5609522994398 := by decide
theorem cert_e1211476483294 : check e1211476483294 [[],[],[],[]] .chain = true := by decide
def e1211476483322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211476483322 : Closed e1211476483322 ∧ code e1211476483322 = 5609522994426 := by decide
theorem cert_e1211476483322 : check e1211476483322 [[],[],[],[]] .chain = true := by decide
def e1211476483894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211476483894 : Closed e1211476483894 ∧ code e1211476483894 = 5609522994998 := by decide
theorem cert_e1211476483894 : check e1211476483894 [[],[],[],[]] .chain = true := by decide
def e1211476483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211476483898 : Closed e1211476483898 ∧ code e1211476483898 = 5609522995002 := by decide
theorem cert_e1211476483898 : check e1211476483898 [[],[],[],[]] .chain = true := by decide
def e1211476498670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211476498670 : Closed e1211476498670 ∧ code e1211476498670 = 5609523009774 := by decide
theorem cert_e1211476498670 : check e1211476498670 [[],[],[],[]] .sourceHead = true := by decide
def e1211476498678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211476498678 : Closed e1211476498678 ∧ code e1211476498678 = 5609523009782 := by decide
theorem cert_e1211476498678 : check e1211476498678 [[],[],[],[]] .sourceHead = true := by decide
def e1211476499230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211476499230 : Closed e1211476499230 ∧ code e1211476499230 = 5609523010334 := by decide
theorem cert_e1211476499230 : check e1211476499230 [[],[],[],[]] .sourceHead = true := by decide
def e1211476499342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211476499342 : Closed e1211476499342 ∧ code e1211476499342 = 5609523010446 := by decide
theorem cert_e1211476499342 : check e1211476499342 [[],[],[],[]] .sourceHead = true := by decide
def e1211476499566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211476499566 : Closed e1211476499566 ∧ code e1211476499566 = 5609523010670 := by decide
theorem cert_e1211476499566 : check e1211476499566 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e1211476499578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211476499578 : Closed e1211476499578 ∧ code e1211476499578 = 5609523010682 := by decide
theorem cert_e1211476499578 : check e1211476499578 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e1211476499742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211476499742 : Closed e1211476499742 ∧ code e1211476499742 = 5609523010846 := by decide
theorem cert_e1211476499742 : check e1211476499742 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211476499910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211476499910 : Closed e1211476499910 ∧ code e1211476499910 = 5609523011014 := by decide
private def t_e1211476499910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e1211476499910 : ¬ IsSelfInterpreter e1211476499910 :=
  wSource (t := t_e1211476499910) (replay_sound (ps := []) (t := e1211476499910) (by decide)) (by decide)
end Blc.Floor42
