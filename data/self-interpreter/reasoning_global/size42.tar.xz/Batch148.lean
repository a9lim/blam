import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186444002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186444002 : Closed e1211186444002 ∧ code e1211186444002 = 5609232955106 := by decide
theorem cert_e1211186444002 : check e1211186444002 [[],[]] .smaller = true := by decide
def e1211186444014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211186444014 : Closed e1211186444014 ∧ code e1211186444014 = 5609232955118 := by decide
theorem cert_e1211186444014 : check e1211186444014 [[],[]] .smaller = true := by decide
def e1211186444022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e1211186444022 : Closed e1211186444022 ∧ code e1211186444022 = 5609232955126 := by decide
theorem cert_e1211186444022 : check e1211186444022 [[],[]] .three = true := by decide
def e1211186444054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186444054 : Closed e1211186444054 ∧ code e1211186444054 = 5609232955158 := by decide
theorem cert_e1211186444054 : check e1211186444054 [[],[]] .smaller = true := by decide
def e1211186444058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186444058 : Closed e1211186444058 ∧ code e1211186444058 = 5609232955162 := by decide
theorem cert_e1211186444058 : check e1211186444058 [[],[]] .smaller = true := by decide
def e1211186444102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186444102 : Closed e1211186444102 ∧ code e1211186444102 = 5609232955206 := by decide
theorem cert_e1211186444102 : check e1211186444102 [[],[]] .smaller = true := by decide
def e1211186444126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e1211186444126 : Closed e1211186444126 ∧ code e1211186444126 = 5609232955230 := by decide
theorem cert_e1211186444126 : check e1211186444126 [[],[]] .three = true := by decide
def e1211186444130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186444130 : Closed e1211186444130 ∧ code e1211186444130 = 5609232955234 := by decide
theorem cert_e1211186444130 : check e1211186444130 [[],[]] .smaller = true := by decide
def e1211186444142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211186444142 : Closed e1211186444142 ∧ code e1211186444142 = 5609232955246 := by decide
theorem cert_e1211186444142 : check e1211186444142 [[],[]] .smaller = true := by decide
def e1211186444150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211186444150 : Closed e1211186444150 ∧ code e1211186444150 = 5609232955254 := by decide
theorem cert_e1211186444150 : check e1211186444150 [[],[]] .smaller = true := by decide
def e1211186444154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e1211186444154 : Closed e1211186444154 ∧ code e1211186444154 = 5609232955258 := by decide
theorem cert_e1211186444154 : check e1211186444154 [[],[]] .three = true := by decide
def e1211186444170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186444170 : Closed e1211186444170 ∧ code e1211186444170 = 5609232955274 := by decide
theorem cert_e1211186444170 : check e1211186444170 [[],[]] .three = true := by decide
def e1211186444194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186444194 : Closed e1211186444194 ∧ code e1211186444194 = 5609232955298 := by decide
theorem cert_e1211186444194 : check e1211186444194 [[],[]] .three = true := by decide
def e1211186444206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211186444206 : Closed e1211186444206 ∧ code e1211186444206 = 5609232955310 := by decide
theorem cert_e1211186444206 : check e1211186444206 [[],[]] .three = true := by decide
def e1211186444214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211186444214 : Closed e1211186444214 ∧ code e1211186444214 = 5609232955318 := by decide
theorem cert_e1211186444214 : check e1211186444214 [[],[]] .three = true := by decide
def e1211186444218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211186444218 : Closed e1211186444218 ∧ code e1211186444218 = 5609232955322 := by decide
theorem cert_e1211186444218 : check e1211186444218 [[],[]] .three = true := by decide
def e1211186444470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e1211186444470 : Closed e1211186444470 ∧ code e1211186444470 = 5609232955574 := by decide
theorem cert_e1211186444470 : check e1211186444470 [[],[]] .smaller = true := by decide
def e1211186444502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186444502 : Closed e1211186444502 ∧ code e1211186444502 = 5609232955606 := by decide
theorem cert_e1211186444502 : check e1211186444502 [[],[]] .smaller = true := by decide
def e1211186444506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186444506 : Closed e1211186444506 ∧ code e1211186444506 = 5609232955610 := by decide
theorem cert_e1211186444506 : check e1211186444506 [[],[]] .smaller = true := by decide
def e1211186444522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186444522 : Closed e1211186444522 ∧ code e1211186444522 = 5609232955626 := by decide
theorem cert_e1211186444522 : check e1211186444522 [[],[]] .smaller = true := by decide
def e1211186444854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186444854 : Closed e1211186444854 ∧ code e1211186444854 = 5609232955958 := by decide
theorem cert_e1211186444854 : check e1211186444854 [[],[]] .smaller = true := by decide
def e1211186444858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186444858 : Closed e1211186444858 ∧ code e1211186444858 = 5609232955962 := by decide
theorem cert_e1211186444858 : check e1211186444858 [[],[]] .smaller = true := by decide
def e1211186444942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186444942 : Closed e1211186444942 ∧ code e1211186444942 = 5609232956046 := by decide
theorem cert_e1211186444942 : check e1211186444942 [[],[]] .smaller = true := by decide
def e1211186444998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186444998 : Closed e1211186444998 ∧ code e1211186444998 = 5609232956102 := by decide
theorem cert_e1211186444998 : check e1211186444998 [[],[]] .smaller = true := by decide
def e1211186445022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e1211186445022 : Closed e1211186445022 ∧ code e1211186445022 = 5609232956126 := by decide
theorem cert_e1211186445022 : check e1211186445022 [[],[]] .three = true := by decide
def e1211186445046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e1211186445046 : Closed e1211186445046 ∧ code e1211186445046 = 5609232956150 := by decide
theorem cert_e1211186445046 : check e1211186445046 [[],[]] .three = true := by decide
def e1211186445078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186445078 : Closed e1211186445078 ∧ code e1211186445078 = 5609232956182 := by decide
theorem cert_e1211186445078 : check e1211186445078 [[],[]] .smaller = true := by decide
def e1211186445082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186445082 : Closed e1211186445082 ∧ code e1211186445082 = 5609232956186 := by decide
theorem cert_e1211186445082 : check e1211186445082 [[],[]] .smaller = true := by decide
def e1211186445126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186445126 : Closed e1211186445126 ∧ code e1211186445126 = 5609232956230 := by decide
theorem cert_e1211186445126 : check e1211186445126 [[],[]] .smaller = true := by decide
def e1211186445150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e1211186445150 : Closed e1211186445150 ∧ code e1211186445150 = 5609232956254 := by decide
theorem cert_e1211186445150 : check e1211186445150 [[],[]] .three = true := by decide
def e1211186445154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186445154 : Closed e1211186445154 ∧ code e1211186445154 = 5609232956258 := by decide
theorem cert_e1211186445154 : check e1211186445154 [[],[]] .smaller = true := by decide
def e1211186445166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211186445166 : Closed e1211186445166 ∧ code e1211186445166 = 5609232956270 := by decide
theorem cert_e1211186445166 : check e1211186445166 [[],[]] .smaller = true := by decide
def e1211186445174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211186445174 : Closed e1211186445174 ∧ code e1211186445174 = 5609232956278 := by decide
theorem cert_e1211186445174 : check e1211186445174 [[],[]] .smaller = true := by decide
def e1211186445178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e1211186445178 : Closed e1211186445178 ∧ code e1211186445178 = 5609232956282 := by decide
theorem cert_e1211186445178 : check e1211186445178 [[],[]] .three = true := by decide
def e1211186445238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211186445238 : Closed e1211186445238 ∧ code e1211186445238 = 5609232956342 := by decide
theorem cert_e1211186445238 : check e1211186445238 [[],[]] .smaller = true := by decide
def e1211186445270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211186445270 : Closed e1211186445270 ∧ code e1211186445270 = 5609232956374 := by decide
theorem cert_e1211186445270 : check e1211186445270 [[],[]] .three = true := by decide
def e1211186445274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211186445274 : Closed e1211186445274 ∧ code e1211186445274 = 5609232956378 := by decide
theorem cert_e1211186445274 : check e1211186445274 [[],[]] .three = true := by decide
def e1211186445398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186445398 : Closed e1211186445398 ∧ code e1211186445398 = 5609232956502 := by decide
theorem cert_e1211186445398 : check e1211186445398 [[],[]] .three = true := by decide
def e1211186445402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186445402 : Closed e1211186445402 ∧ code e1211186445402 = 5609232956506 := by decide
theorem cert_e1211186445402 : check e1211186445402 [[],[]] .three = true := by decide
def e1211186445590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186445590 : Closed e1211186445590 ∧ code e1211186445590 = 5609232956694 := by decide
theorem cert_e1211186445590 : check e1211186445590 [[],[]] .three = true := by decide
def e1211186445666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186445666 : Closed e1211186445666 ∧ code e1211186445666 = 5609232956770 := by decide
theorem cert_e1211186445666 : check e1211186445666 [[],[]] .three = true := by decide
def e1211186445678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186445678 : Closed e1211186445678 ∧ code e1211186445678 = 5609232956782 := by decide
theorem cert_e1211186445678 : check e1211186445678 [[],[]] .three = true := by decide
def e1211186445686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186445686 : Closed e1211186445686 ∧ code e1211186445686 = 5609232956790 := by decide
theorem cert_e1211186445686 : check e1211186445686 [[],[]] .three = true := by decide
def e1211186445706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186445706 : Closed e1211186445706 ∧ code e1211186445706 = 5609232956810 := by decide
theorem cert_e1211186445706 : check e1211186445706 [[],[]] .three = true := by decide
def e1211186445730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186445730 : Closed e1211186445730 ∧ code e1211186445730 = 5609232956834 := by decide
theorem cert_e1211186445730 : check e1211186445730 [[],[]] .three = true := by decide
def e1211186445742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186445742 : Closed e1211186445742 ∧ code e1211186445742 = 5609232956846 := by decide
theorem cert_e1211186445742 : check e1211186445742 [[],[]] .three = true := by decide
def e1211186445750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1211186445750 : Closed e1211186445750 ∧ code e1211186445750 = 5609232956854 := by decide
theorem cert_e1211186445750 : check e1211186445750 [[],[]] .three = true := by decide
def e1211186445754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186445754 : Closed e1211186445754 ∧ code e1211186445754 = 5609232956858 := by decide
theorem cert_e1211186445754 : check e1211186445754 [[],[]] .three = true := by decide
def e1211186445782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211186445782 : Closed e1211186445782 ∧ code e1211186445782 = 5609232956886 := by decide
theorem cert_e1211186445782 : check e1211186445782 [[],[]] .three = true := by decide
def e1211186445786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211186445786 : Closed e1211186445786 ∧ code e1211186445786 = 5609232956890 := by decide
theorem cert_e1211186445786 : check e1211186445786 [[],[]] .three = true := by decide
def e1211186447326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 3)))))))
theorem wire_e1211186447326 : Closed e1211186447326 ∧ code e1211186447326 = 5609232958430 := by decide
theorem cert_e1211186447326 : check e1211186447326 [[],[]] .three = true := by decide
def e1211186447350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 5)))) (.var 1)))))))
theorem wire_e1211186447350 : Closed e1211186447350 ∧ code e1211186447350 = 5609232958454 := by decide
theorem cert_e1211186447350 : check e1211186447350 [[],[]] .three = true := by decide
def e1211186448110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e1211186448110 : Closed e1211186448110 ∧ code e1211186448110 = 5609232959214 := by decide
theorem cert_e1211186448110 : check e1211186448110 [[],[]] .smaller = true := by decide
def e1211186448118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211186448118 : Closed e1211186448118 ∧ code e1211186448118 = 5609232959222 := by decide
theorem cert_e1211186448118 : check e1211186448118 [[],[]] .smaller = true := by decide
def e1211186448302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e1211186448302 : Closed e1211186448302 ∧ code e1211186448302 = 5609232959406 := by decide
theorem cert_e1211186448302 : check e1211186448302 [[],[]] .smaller = true := by decide
def e1211186448342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211186448342 : Closed e1211186448342 ∧ code e1211186448342 = 5609232959446 := by decide
theorem cert_e1211186448342 : check e1211186448342 [[],[]] .smaller = true := by decide
def e1211186448862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186448862 : Closed e1211186448862 ∧ code e1211186448862 = 5609232959966 := by decide
theorem cert_e1211186448862 : check e1211186448862 [[],[]] .three = true := by decide
def e1211186448886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186448886 : Closed e1211186448886 ∧ code e1211186448886 = 5609232959990 := by decide
theorem cert_e1211186448886 : check e1211186448886 [[],[]] .three = true := by decide
def e1211186449646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186449646 : Closed e1211186449646 ∧ code e1211186449646 = 5609232960750 := by decide
theorem cert_e1211186449646 : check e1211186449646 [[],[]] .smaller = true := by decide
def e1211186449654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186449654 : Closed e1211186449654 ∧ code e1211186449654 = 5609232960758 := by decide
theorem cert_e1211186449654 : check e1211186449654 [[],[]] .smaller = true := by decide
def e1211186449982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 4))))))))
theorem wire_e1211186449982 : Closed e1211186449982 ∧ code e1211186449982 = 5609232961086 := by decide
theorem cert_e1211186449982 : check e1211186449982 [[],[]] .three = true := by decide
def e1211186450030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186450030 : Closed e1211186450030 ∧ code e1211186450030 = 5609232961134 := by decide
theorem cert_e1211186450030 : check e1211186450030 [[],[]] .smaller = true := by decide
def e1211186450042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186450042 : Closed e1211186450042 ∧ code e1211186450042 = 5609232961146 := by decide
theorem cert_e1211186450042 : check e1211186450042 [[],[]] .smaller = true := by decide
def e1211186450230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186450230 : Closed e1211186450230 ∧ code e1211186450230 = 5609232961334 := by decide
theorem cert_e1211186450230 : check e1211186450230 [[],[]] .smaller = true := by decide
def e1211186450234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186450234 : Closed e1211186450234 ∧ code e1211186450234 = 5609232961338 := by decide
theorem cert_e1211186450234 : check e1211186450234 [[],[]] .smaller = true := by decide
def e1211186450318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.lam (.var 2))))))))
theorem wire_e1211186450318 : Closed e1211186450318 ∧ code e1211186450318 = 5609232961422 := by decide
theorem cert_e1211186450318 : check e1211186450318 [[],[]] .three = true := by decide
def e1211186452718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211186452718 : Closed e1211186452718 ∧ code e1211186452718 = 5609232963822 := by decide
theorem cert_e1211186452718 : check e1211186452718 [[],[]] .smaller = true := by decide
def e1211186452726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211186452726 : Closed e1211186452726 ∧ code e1211186452726 = 5609232963830 := by decide
theorem cert_e1211186452726 : check e1211186452726 [[],[]] .smaller = true := by decide
def e1211186453278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211186453278 : Closed e1211186453278 ∧ code e1211186453278 = 5609232964382 := by decide
theorem cert_e1211186453278 : check e1211186453278 [[],[]] .smaller = true := by decide
def e1211186453390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211186453390 : Closed e1211186453390 ∧ code e1211186453390 = 5609232964494 := by decide
theorem cert_e1211186453390 : check e1211186453390 [[],[]] .smaller = true := by decide
def e1211186453598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186453598 : Closed e1211186453598 ∧ code e1211186453598 = 5609232964702 := by decide
theorem cert_e1211186453598 : check e1211186453598 [[],[]] .three = true := by decide
def e1211186453614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186453614 : Closed e1211186453614 ∧ code e1211186453614 = 5609232964718 := by decide
theorem cert_e1211186453614 : check e1211186453614 [[],[]] .smaller = true := by decide
def e1211186453626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186453626 : Closed e1211186453626 ∧ code e1211186453626 = 5609232964730 := by decide
theorem cert_e1211186453626 : check e1211186453626 [[],[]] .smaller = true := by decide
def e1211186453790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186453790 : Closed e1211186453790 ∧ code e1211186453790 = 5609232964894 := by decide
theorem cert_e1211186453790 : check e1211186453790 [[],[]] .smaller = true := by decide
def e1211186453958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186453958 : Closed e1211186453958 ∧ code e1211186453958 = 5609232965062 := by decide
theorem cert_e1211186453958 : check e1211186453958 [[],[]] .smaller = true := by decide
def e1211186453982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e1211186453982 : Closed e1211186453982 ∧ code e1211186453982 = 5609232965086 := by decide
theorem cert_e1211186453982 : check e1211186453982 [[],[]] .three = true := by decide
def e1211186453986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186453986 : Closed e1211186453986 ∧ code e1211186453986 = 5609232965090 := by decide
theorem cert_e1211186453986 : check e1211186453986 [[],[]] .three = true := by decide
def e1211186453998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e1211186453998 : Closed e1211186453998 ∧ code e1211186453998 = 5609232965102 := by decide
theorem cert_e1211186453998 : check e1211186453998 [[],[]] .three = true := by decide
def e1211186454070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186454070 : Closed e1211186454070 ∧ code e1211186454070 = 5609232965174 := by decide
theorem cert_e1211186454070 : check e1211186454070 [[],[]] .smaller = true := by decide
def e1211186454074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186454074 : Closed e1211186454074 ∧ code e1211186454074 = 5609232965178 := by decide
theorem cert_e1211186454074 : check e1211186454074 [[],[]] .smaller = true := by decide
def e1211186454158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186454158 : Closed e1211186454158 ∧ code e1211186454158 = 5609232965262 := by decide
theorem cert_e1211186454158 : check e1211186454158 [[],[]] .smaller = true := by decide
def e1211186454214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186454214 : Closed e1211186454214 ∧ code e1211186454214 = 5609232965318 := by decide
theorem cert_e1211186454214 : check e1211186454214 [[],[]] .smaller = true := by decide
def e1211186454238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e1211186454238 : Closed e1211186454238 ∧ code e1211186454238 = 5609232965342 := by decide
theorem cert_e1211186454238 : check e1211186454238 [[],[]] .three = true := by decide
def e1211186454262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e1211186454262 : Closed e1211186454262 ∧ code e1211186454262 = 5609232965366 := by decide
theorem cert_e1211186454262 : check e1211186454262 [[],[]] .three = true := by decide
def e1211186454294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186454294 : Closed e1211186454294 ∧ code e1211186454294 = 5609232965398 := by decide
theorem cert_e1211186454294 : check e1211186454294 [[],[]] .three = true := by decide
def e1211186454370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186454370 : Closed e1211186454370 ∧ code e1211186454370 = 5609232965474 := by decide
theorem cert_e1211186454370 : check e1211186454370 [[],[]] .three = true := by decide
def e1211186454382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e1211186454382 : Closed e1211186454382 ∧ code e1211186454382 = 5609232965486 := by decide
theorem cert_e1211186454382 : check e1211186454382 [[],[]] .three = true := by decide
def e1211186454390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e1211186454390 : Closed e1211186454390 ∧ code e1211186454390 = 5609232965494 := by decide
theorem cert_e1211186454390 : check e1211186454390 [[],[]] .three = true := by decide
def e1211186456350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211186456350 : Closed e1211186456350 ∧ code e1211186456350 = 5609232967454 := by decide
theorem cert_e1211186456350 : check e1211186456350 [[],[]] .smaller = true := by decide
def e1211186456462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211186456462 : Closed e1211186456462 ∧ code e1211186456462 = 5609232967566 := by decide
theorem cert_e1211186456462 : check e1211186456462 [[],[]] .smaller = true := by decide
def e1211186458750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186458750 : Closed e1211186458750 ∧ code e1211186458750 = 5609232969854 := by decide
theorem cert_e1211186458750 : check e1211186458750 [[],[]] .three = true := by decide
def e1211186458846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186458846 : Closed e1211186458846 ∧ code e1211186458846 = 5609232969950 := by decide
theorem cert_e1211186458846 : check e1211186458846 [[],[]] .smaller = true := by decide
def e1211186458874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186458874 : Closed e1211186458874 ∧ code e1211186458874 = 5609232969978 := by decide
theorem cert_e1211186458874 : check e1211186458874 [[],[]] .smaller = true := by decide
def e1211186459422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186459422 : Closed e1211186459422 ∧ code e1211186459422 = 5609232970526 := by decide
theorem cert_e1211186459422 : check e1211186459422 [[],[]] .smaller = true := by decide
def e1211186459590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186459590 : Closed e1211186459590 ∧ code e1211186459590 = 5609232970694 := by decide
theorem cert_e1211186459590 : check e1211186459590 [[],[]] .smaller = true := by decide
def e1211186459614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186459614 : Closed e1211186459614 ∧ code e1211186459614 = 5609232970718 := by decide
theorem cert_e1211186459614 : check e1211186459614 [[],[]] .three = true := by decide
def e1211186459618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186459618 : Closed e1211186459618 ∧ code e1211186459618 = 5609232970722 := by decide
theorem cert_e1211186459618 : check e1211186459618 [[],[]] .three = true := by decide
def e1211186459630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186459630 : Closed e1211186459630 ∧ code e1211186459630 = 5609232970734 := by decide
theorem cert_e1211186459630 : check e1211186459630 [[],[]] .three = true := by decide
def e1211186460782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186460782 : Closed e1211186460782 ∧ code e1211186460782 = 5609232971886 := by decide
theorem cert_e1211186460782 : check e1211186460782 [[],[]] .smaller = true := by decide
def e1211186460794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186460794 : Closed e1211186460794 ∧ code e1211186460794 = 5609232971898 := by decide
theorem cert_e1211186460794 : check e1211186460794 [[],[]] .smaller = true := by decide
def e1211186461070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186461070 : Closed e1211186461070 ∧ code e1211186461070 = 5609232972174 := by decide
theorem cert_e1211186461070 : check e1211186461070 [[],[]] .smaller = true := by decide
def e1211186461126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186461126 : Closed e1211186461126 ∧ code e1211186461126 = 5609232972230 := by decide
theorem cert_e1211186461126 : check e1211186461126 [[],[]] .smaller = true := by decide
def e1211186461150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186461150 : Closed e1211186461150 ∧ code e1211186461150 = 5609232972254 := by decide
theorem cert_e1211186461150 : check e1211186461150 [[],[]] .three = true := by decide
def e1211186461174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186461174 : Closed e1211186461174 ∧ code e1211186461174 = 5609232972278 := by decide
theorem cert_e1211186461174 : check e1211186461174 [[],[]] .three = true := by decide
def e1211186461726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186461726 : Closed e1211186461726 ∧ code e1211186461726 = 5609232972830 := by decide
theorem cert_e1211186461726 : check e1211186461726 [[],[]] .three = true := by decide
def e1211186461922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186461922 : Closed e1211186461922 ∧ code e1211186461922 = 5609232973026 := by decide
theorem cert_e1211186461922 : check e1211186461922 [[],[]] .three = true := by decide
def e1211186461934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186461934 : Closed e1211186461934 ∧ code e1211186461934 = 5609232973038 := by decide
theorem cert_e1211186461934 : check e1211186461934 [[],[]] .three = true := by decide
def e1211186461942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186461942 : Closed e1211186461942 ∧ code e1211186461942 = 5609232973046 := by decide
theorem cert_e1211186461942 : check e1211186461942 [[],[]] .three = true := by decide
def e1211186463198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211186463198 : Closed e1211186463198 ∧ code e1211186463198 = 5609232974302 := by decide
theorem cert_e1211186463198 : check e1211186463198 [[],[]] .three = true := by decide
def e1211186463214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211186463214 : Closed e1211186463214 ∧ code e1211186463214 = 5609232974318 := by decide
theorem cert_e1211186463214 : check e1211186463214 [[],[]] .smaller = true := by decide
def e1211186463222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211186463222 : Closed e1211186463222 ∧ code e1211186463222 = 5609232974326 := by decide
theorem cert_e1211186463222 : check e1211186463222 [[],[]] .smaller = true := by decide
def e1211186463226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5)))) (.var 0)))))))
theorem wire_e1211186463226 : Closed e1211186463226 ∧ code e1211186463226 = 5609232974330 := by decide
theorem cert_e1211186463226 : check e1211186463226 [[],[]] .three = true := by decide
def e1211186463582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e1211186463582 : Closed e1211186463582 ∧ code e1211186463582 = 5609232974686 := by decide
theorem cert_e1211186463582 : check e1211186463582 [[],[]] .three = true := by decide
def e1211186463598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211186463598 : Closed e1211186463598 ∧ code e1211186463598 = 5609232974702 := by decide
theorem cert_e1211186463598 : check e1211186463598 [[],[]] .smaller = true := by decide
def e1211186463610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211186463610 : Closed e1211186463610 ∧ code e1211186463610 = 5609232974714 := by decide
theorem cert_e1211186463610 : check e1211186463610 [[],[]] .smaller = true := by decide
def e1211186463662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211186463662 : Closed e1211186463662 ∧ code e1211186463662 = 5609232974766 := by decide
theorem cert_e1211186463662 : check e1211186463662 [[],[]] .smaller = true := by decide
def e1211186463722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211186463722 : Closed e1211186463722 ∧ code e1211186463722 = 5609232974826 := by decide
theorem cert_e1211186463722 : check e1211186463722 [[],[]] .smaller = true := by decide
def e1211186463966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186463966 : Closed e1211186463966 ∧ code e1211186463966 = 5609232975070 := by decide
theorem cert_e1211186463966 : check e1211186463966 [[],[]] .three = true := by decide
def e1211186463982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186463982 : Closed e1211186463982 ∧ code e1211186463982 = 5609232975086 := by decide
theorem cert_e1211186463982 : check e1211186463982 [[],[]] .smaller = true := by decide
def e1211186463990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186463990 : Closed e1211186463990 ∧ code e1211186463990 = 5609232975094 := by decide
theorem cert_e1211186463990 : check e1211186463990 [[],[]] .smaller = true := by decide
def e1211186463994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186463994 : Closed e1211186463994 ∧ code e1211186463994 = 5609232975098 := by decide
theorem cert_e1211186463994 : check e1211186463994 [[],[]] .three = true := by decide
def e1211186464318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211186464318 : Closed e1211186464318 ∧ code e1211186464318 = 5609232975422 := by decide
theorem cert_e1211186464318 : check e1211186464318 [[],[]] .three = true := by decide
def e1211186464366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186464366 : Closed e1211186464366 ∧ code e1211186464366 = 5609232975470 := by decide
theorem cert_e1211186464366 : check e1211186464366 [[],[]] .smaller = true := by decide
def e1211186464378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186464378 : Closed e1211186464378 ∧ code e1211186464378 = 5609232975482 := by decide
theorem cert_e1211186464378 : check e1211186464378 [[],[]] .smaller = true := by decide
def e1211186464542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211186464542 : Closed e1211186464542 ∧ code e1211186464542 = 5609232975646 := by decide
theorem cert_e1211186464542 : check e1211186464542 [[],[]] .smaller = true := by decide
def e1211186464654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211186464654 : Closed e1211186464654 ∧ code e1211186464654 = 5609232975758 := by decide
theorem cert_e1211186464654 : check e1211186464654 [[],[]] .smaller = true := by decide
def e1211186464666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186464666 : Closed e1211186464666 ∧ code e1211186464666 = 5609232975770 := by decide
theorem cert_e1211186464666 : check e1211186464666 [[],[]] .smaller = true := by decide
def e1211186464710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.lam (.var 1))))))))
theorem wire_e1211186464710 : Closed e1211186464710 ∧ code e1211186464710 = 5609232975814 := by decide
theorem cert_e1211186464710 : check e1211186464710 [[],[]] .three = true := by decide
def e1211186464734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 3)))))))
theorem wire_e1211186464734 : Closed e1211186464734 ∧ code e1211186464734 = 5609232975838 := by decide
theorem cert_e1211186464734 : check e1211186464734 [[],[]] .three = true := by decide
def e1211186465886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186465886 : Closed e1211186465886 ∧ code e1211186465886 = 5609232976990 := by decide
theorem cert_e1211186465886 : check e1211186465886 [[],[]] .three = true := by decide
def e1211186465902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186465902 : Closed e1211186465902 ∧ code e1211186465902 = 5609232977006 := by decide
theorem cert_e1211186465902 : check e1211186465902 [[],[]] .smaller = true := by decide
def e1211186465914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186465914 : Closed e1211186465914 ∧ code e1211186465914 = 5609232977018 := by decide
theorem cert_e1211186465914 : check e1211186465914 [[],[]] .smaller = true := by decide
def e1211186466078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186466078 : Closed e1211186466078 ∧ code e1211186466078 = 5609232977182 := by decide
theorem cert_e1211186466078 : check e1211186466078 [[],[]] .smaller = true := by decide
def e1211186466246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186466246 : Closed e1211186466246 ∧ code e1211186466246 = 5609232977350 := by decide
theorem cert_e1211186466246 : check e1211186466246 [[],[]] .smaller = true := by decide
def e1211186466270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e1211186466270 : Closed e1211186466270 ∧ code e1211186466270 = 5609232977374 := by decide
theorem cert_e1211186466270 : check e1211186466270 [[],[]] .three = true := by decide
def e1211186466274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186466274 : Closed e1211186466274 ∧ code e1211186466274 = 5609232977378 := by decide
theorem cert_e1211186466274 : check e1211186466274 [[],[]] .three = true := by decide
def e1211186466286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e1211186466286 : Closed e1211186466286 ∧ code e1211186466286 = 5609232977390 := by decide
theorem cert_e1211186466286 : check e1211186466286 [[],[]] .three = true := by decide
def e1211186466350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186466350 : Closed e1211186466350 ∧ code e1211186466350 = 5609232977454 := by decide
theorem cert_e1211186466350 : check e1211186466350 [[],[]] .smaller = true := by decide
def e1211186466526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e1211186466526 : Closed e1211186466526 ∧ code e1211186466526 = 5609232977630 := by decide
theorem cert_e1211186466526 : check e1211186466526 [[],[]] .three = true := by decide
def e1211186466530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186466530 : Closed e1211186466530 ∧ code e1211186466530 = 5609232977634 := by decide
theorem cert_e1211186466530 : check e1211186466530 [[],[]] .smaller = true := by decide
def e1211186466542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e1211186466542 : Closed e1211186466542 ∧ code e1211186466542 = 5609232977646 := by decide
theorem cert_e1211186466542 : check e1211186466542 [[],[]] .smaller = true := by decide
def e1211186466550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e1211186466550 : Closed e1211186466550 ∧ code e1211186466550 = 5609232977654 := by decide
theorem cert_e1211186466550 : check e1211186466550 [[],[]] .three = true := by decide
def e1211186466582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186466582 : Closed e1211186466582 ∧ code e1211186466582 = 5609232977686 := by decide
theorem cert_e1211186466582 : check e1211186466582 [[],[]] .smaller = true := by decide
def e1211186466586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186466586 : Closed e1211186466586 ∧ code e1211186466586 = 5609232977690 := by decide
theorem cert_e1211186466586 : check e1211186466586 [[],[]] .smaller = true := by decide
def e1211186466630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186466630 : Closed e1211186466630 ∧ code e1211186466630 = 5609232977734 := by decide
theorem cert_e1211186466630 : check e1211186466630 [[],[]] .smaller = true := by decide
def e1211186466654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e1211186466654 : Closed e1211186466654 ∧ code e1211186466654 = 5609232977758 := by decide
theorem cert_e1211186466654 : check e1211186466654 [[],[]] .three = true := by decide
def e1211186466658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186466658 : Closed e1211186466658 ∧ code e1211186466658 = 5609232977762 := by decide
theorem cert_e1211186466658 : check e1211186466658 [[],[]] .smaller = true := by decide
def e1211186466670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e1211186466670 : Closed e1211186466670 ∧ code e1211186466670 = 5609232977774 := by decide
theorem cert_e1211186466670 : check e1211186466670 [[],[]] .smaller = true := by decide
def e1211186466678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e1211186466678 : Closed e1211186466678 ∧ code e1211186466678 = 5609232977782 := by decide
theorem cert_e1211186466678 : check e1211186466678 [[],[]] .smaller = true := by decide
def e1211186466682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e1211186466682 : Closed e1211186466682 ∧ code e1211186466682 = 5609232977786 := by decide
theorem cert_e1211186466682 : check e1211186466682 [[],[]] .three = true := by decide
def e1211186466698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186466698 : Closed e1211186466698 ∧ code e1211186466698 = 5609232977802 := by decide
theorem cert_e1211186466698 : check e1211186466698 [[],[]] .three = true := by decide
def e1211186466722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186466722 : Closed e1211186466722 ∧ code e1211186466722 = 5609232977826 := by decide
theorem cert_e1211186466722 : check e1211186466722 [[],[]] .three = true := by decide
def e1211186466734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e1211186466734 : Closed e1211186466734 ∧ code e1211186466734 = 5609232977838 := by decide
theorem cert_e1211186466734 : check e1211186466734 [[],[]] .three = true := by decide
def e1211186466742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e1211186466742 : Closed e1211186466742 ∧ code e1211186466742 = 5609232977846 := by decide
theorem cert_e1211186466742 : check e1211186466742 [[],[]] .three = true := by decide
def e1211186466746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e1211186466746 : Closed e1211186466746 ∧ code e1211186466746 = 5609232977850 := by decide
theorem cert_e1211186466746 : check e1211186466746 [[],[]] .three = true := by decide
def e1211186466942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186466942 : Closed e1211186466942 ∧ code e1211186466942 = 5609232978046 := by decide
theorem cert_e1211186466942 : check e1211186466942 [[],[]] .three = true := by decide
def e1211186467038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186467038 : Closed e1211186467038 ∧ code e1211186467038 = 5609232978142 := by decide
theorem cert_e1211186467038 : check e1211186467038 [[],[]] .smaller = true := by decide
def e1211186467066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186467066 : Closed e1211186467066 ∧ code e1211186467066 = 5609232978170 := by decide
theorem cert_e1211186467066 : check e1211186467066 [[],[]] .smaller = true := by decide
def e1211186467614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186467614 : Closed e1211186467614 ∧ code e1211186467614 = 5609232978718 := by decide
theorem cert_e1211186467614 : check e1211186467614 [[],[]] .smaller = true := by decide
def e1211186467782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186467782 : Closed e1211186467782 ∧ code e1211186467782 = 5609232978886 := by decide
theorem cert_e1211186467782 : check e1211186467782 [[],[]] .smaller = true := by decide
end Blc.Floor42
