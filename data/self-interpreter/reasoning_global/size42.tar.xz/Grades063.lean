import Tables
import Batch063
namespace Blc.Floor42.Grades063
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1194168769902 : ¬ IsSelfInterpreter e1194168769902 := cutM6_2 (by decide)
#print axioms ex_e1194168769902
end Blc.Floor42.Grades063
