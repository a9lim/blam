import Tables
import Batch060
namespace Blc.Floor42.Grades060
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1131193055674 : ¬ IsSelfInterpreter e1131193055674 := cutM13_0 (by decide)
#print axioms ex_e1131193055674
end Blc.Floor42.Grades060
