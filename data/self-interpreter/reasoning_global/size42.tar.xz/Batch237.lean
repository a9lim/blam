import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211281532854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e1211281532854 : Closed e1211281532854 ∧ code e1211281532854 = 5609328043958 := by decide
theorem cert_e1211281532854 : check e1211281532854 [[],[]] .smaller = true := by decide
def e1211281532886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e1211281532886 : Closed e1211281532886 ∧ code e1211281532886 = 5609328043990 := by decide
theorem cert_e1211281532886 : check e1211281532886 [[],[]] .smaller = true := by decide
def e1211281532890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e1211281532890 : Closed e1211281532890 ∧ code e1211281532890 = 5609328043994 := by decide
theorem cert_e1211281532890 : check e1211281532890 [[],[]] .smaller = true := by decide
def e1211281533406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211281533406 : Closed e1211281533406 ∧ code e1211281533406 = 5609328044510 := by decide
theorem cert_e1211281533406 : check e1211281533406 [[],[]] .smaller = true := by decide
def e1211281533430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211281533430 : Closed e1211281533430 ∧ code e1211281533430 = 5609328044534 := by decide
theorem cert_e1211281533430 : check e1211281533430 [[],[]] .smaller = true := by decide
def e1211281534174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281534174 : Closed e1211281534174 ∧ code e1211281534174 = 5609328045278 := by decide
theorem cert_e1211281534174 : check e1211281534174 [[],[]] .smaller = true := by decide
def e1211281534190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211281534190 : Closed e1211281534190 ∧ code e1211281534190 = 5609328045294 := by decide
theorem cert_e1211281534190 : check e1211281534190 [[],[]] .smaller = true := by decide
def e1211281534198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211281534198 : Closed e1211281534198 ∧ code e1211281534198 = 5609328045302 := by decide
theorem cert_e1211281534198 : check e1211281534198 [[],[]] .smaller = true := by decide
def e1211281534202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281534202 : Closed e1211281534202 ∧ code e1211281534202 = 5609328045306 := by decide
theorem cert_e1211281534202 : check e1211281534202 [[],[]] .smaller = true := by decide
def e1211281534526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4))))))))))
theorem wire_e1211281534526 : Closed e1211281534526 ∧ code e1211281534526 = 5609328045630 := by decide
theorem cert_e1211281534526 : check e1211281534526 [[],[]] .smaller = true := by decide
def e1211281534582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211281534582 : Closed e1211281534582 ∧ code e1211281534582 = 5609328045686 := by decide
theorem cert_e1211281534582 : check e1211281534582 [[],[]] .smaller = true := by decide
def e1211281534750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3))))))))))
theorem wire_e1211281534750 : Closed e1211281534750 ∧ code e1211281534750 = 5609328045854 := by decide
theorem cert_e1211281534750 : check e1211281534750 [[],[]] .smaller = true := by decide
def e1211281534774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281534774 : Closed e1211281534774 ∧ code e1211281534774 = 5609328045878 := by decide
theorem cert_e1211281534774 : check e1211281534774 [[],[]] .smaller = true := by decide
def e1211281534778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281534778 : Closed e1211281534778 ∧ code e1211281534778 = 5609328045882 := by decide
theorem cert_e1211281534778 : check e1211281534778 [[],[]] .smaller = true := by decide
def e1211281535838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211281535838 : Closed e1211281535838 ∧ code e1211281535838 = 5609328046942 := by decide
theorem cert_e1211281535838 : check e1211281535838 [[],[]] .smaller = true := by decide
def e1211281535854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211281535854 : Closed e1211281535854 ∧ code e1211281535854 = 5609328046958 := by decide
theorem cert_e1211281535854 : check e1211281535854 [[],[]] .smaller = true := by decide
def e1211281535862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211281535862 : Closed e1211281535862 ∧ code e1211281535862 = 5609328046966 := by decide
theorem cert_e1211281535862 : check e1211281535862 [[],[]] .smaller = true := by decide
def e1211281535866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211281535866 : Closed e1211281535866 ∧ code e1211281535866 = 5609328046970 := by decide
theorem cert_e1211281535866 : check e1211281535866 [[],[]] .smaller = true := by decide
def e1211281535918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211281535918 : Closed e1211281535918 ∧ code e1211281535918 = 5609328047022 := by decide
theorem cert_e1211281535918 : check e1211281535918 [[],[]] .smaller = true := by decide
def e1211281535930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211281535930 : Closed e1211281535930 ∧ code e1211281535930 = 5609328047034 := by decide
theorem cert_e1211281535930 : check e1211281535930 [[],[]] .smaller = true := by decide
def e1211281535958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211281535958 : Closed e1211281535958 ∧ code e1211281535958 = 5609328047062 := by decide
theorem cert_e1211281535958 : check e1211281535958 [[],[]] .smaller = true := by decide
def e1211281535962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211281535962 : Closed e1211281535962 ∧ code e1211281535962 = 5609328047066 := by decide
theorem cert_e1211281535962 : check e1211281535962 [[],[]] .smaller = true := by decide
def e1211281535978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211281535978 : Closed e1211281535978 ∧ code e1211281535978 = 5609328047082 := by decide
theorem cert_e1211281535978 : check e1211281535978 [[],[]] .smaller = true := by decide
def e1211281536222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281536222 : Closed e1211281536222 ∧ code e1211281536222 = 5609328047326 := by decide
theorem cert_e1211281536222 : check e1211281536222 [[],[]] .smaller = true := by decide
def e1211281536238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211281536238 : Closed e1211281536238 ∧ code e1211281536238 = 5609328047342 := by decide
theorem cert_e1211281536238 : check e1211281536238 [[],[]] .smaller = true := by decide
def e1211281536246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211281536246 : Closed e1211281536246 ∧ code e1211281536246 = 5609328047350 := by decide
theorem cert_e1211281536246 : check e1211281536246 [[],[]] .smaller = true := by decide
def e1211281536250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281536250 : Closed e1211281536250 ∧ code e1211281536250 = 5609328047354 := by decide
theorem cert_e1211281536250 : check e1211281536250 [[],[]] .smaller = true := by decide
def e1211281536622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211281536622 : Closed e1211281536622 ∧ code e1211281536622 = 5609328047726 := by decide
theorem cert_e1211281536622 : check e1211281536622 [[],[]] .smaller = true := by decide
def e1211281536634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211281536634 : Closed e1211281536634 ∧ code e1211281536634 = 5609328047738 := by decide
theorem cert_e1211281536634 : check e1211281536634 [[],[]] .smaller = true := by decide
def e1211281536822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281536822 : Closed e1211281536822 ∧ code e1211281536822 = 5609328047926 := by decide
theorem cert_e1211281536822 : check e1211281536822 [[],[]] .smaller = true := by decide
def e1211281536826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281536826 : Closed e1211281536826 ∧ code e1211281536826 = 5609328047930 := by decide
theorem cert_e1211281536826 : check e1211281536826 [[],[]] .smaller = true := by decide
def e1211281536922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211281536922 : Closed e1211281536922 ∧ code e1211281536922 = 5609328048026 := by decide
theorem cert_e1211281536922 : check e1211281536922 [[],[]] .smaller = true := by decide
def e1211281536958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 4)))))))))
theorem wire_e1211281536958 : Closed e1211281536958 ∧ code e1211281536958 = 5609328048062 := by decide
theorem cert_e1211281536958 : check e1211281536958 [[],[]] .chain = true := by decide
def e1211281536990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 3)))))))))
theorem wire_e1211281536990 : Closed e1211281536990 ∧ code e1211281536990 = 5609328048094 := by decide
theorem cert_e1211281536990 : check e1211281536990 [[],[]] .chain = true := by decide
def e1211281537246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211281537246 : Closed e1211281537246 ∧ code e1211281537246 = 5609328048350 := by decide
theorem cert_e1211281537246 : check e1211281537246 [[],[]] .smaller = true := by decide
def e1211281537274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211281537274 : Closed e1211281537274 ∧ code e1211281537274 = 5609328048378 := by decide
theorem cert_e1211281537274 : check e1211281537274 [[],[]] .smaller = true := by decide
def e1211281537462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211281537462 : Closed e1211281537462 ∧ code e1211281537462 = 5609328048566 := by decide
theorem cert_e1211281537462 : check e1211281537462 [[],[]] .smaller = true := by decide
def e1211281537494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211281537494 : Closed e1211281537494 ∧ code e1211281537494 = 5609328048598 := by decide
theorem cert_e1211281537494 : check e1211281537494 [[],[]] .smaller = true := by decide
def e1211281537498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211281537498 : Closed e1211281537498 ∧ code e1211281537498 = 5609328048602 := by decide
theorem cert_e1211281537498 : check e1211281537498 [[],[]] .smaller = true := by decide
def e1211281537598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211281537598 : Closed e1211281537598 ∧ code e1211281537598 = 5609328048702 := by decide
theorem cert_e1211281537598 : check e1211281537598 [[],[]] .smaller = true := by decide
def e1211281537654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211281537654 : Closed e1211281537654 ∧ code e1211281537654 = 5609328048758 := by decide
theorem cert_e1211281537654 : check e1211281537654 [[],[]] .smaller = true := by decide
def e1211281537846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281537846 : Closed e1211281537846 ∧ code e1211281537846 = 5609328048950 := by decide
theorem cert_e1211281537846 : check e1211281537846 [[],[]] .smaller = true := by decide
def e1211281537850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281537850 : Closed e1211281537850 ∧ code e1211281537850 = 5609328048954 := by decide
theorem cert_e1211281537850 : check e1211281537850 [[],[]] .smaller = true := by decide
def e1211281537990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211281537990 : Closed e1211281537990 ∧ code e1211281537990 = 5609328049094 := by decide
theorem cert_e1211281537990 : check e1211281537990 [[],[]] .smaller = true := by decide
def e1211281538158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211281538158 : Closed e1211281538158 ∧ code e1211281538158 = 5609328049262 := by decide
theorem cert_e1211281538158 : check e1211281538158 [[],[]] .smaller = true := by decide
def e1211281538170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211281538170 : Closed e1211281538170 ∧ code e1211281538170 = 5609328049274 := by decide
theorem cert_e1211281538170 : check e1211281538170 [[],[]] .smaller = true := by decide
def e1211281538262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211281538262 : Closed e1211281538262 ∧ code e1211281538262 = 5609328049366 := by decide
theorem cert_e1211281538262 : check e1211281538262 [[],[]] .smaller = true := by decide
def e1211281538266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211281538266 : Closed e1211281538266 ∧ code e1211281538266 = 5609328049370 := by decide
theorem cert_e1211281538266 : check e1211281538266 [[],[]] .smaller = true := by decide
def e1211281538282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211281538282 : Closed e1211281538282 ∧ code e1211281538282 = 5609328049386 := by decide
theorem cert_e1211281538282 : check e1211281538282 [[],[]] .smaller = true := by decide
def e1211281538334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211281538334 : Closed e1211281538334 ∧ code e1211281538334 = 5609328049438 := by decide
theorem cert_e1211281538334 : check e1211281538334 [[],[]] .smaller = true := by decide
def e1211281538358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281538358 : Closed e1211281538358 ∧ code e1211281538358 = 5609328049462 := by decide
theorem cert_e1211281538358 : check e1211281538358 [[],[]] .smaller = true := by decide
def e1211281538362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281538362 : Closed e1211281538362 ∧ code e1211281538362 = 5609328049466 := by decide
theorem cert_e1211281538362 : check e1211281538362 [[],[]] .smaller = true := by decide
def e1211281538458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211281538458 : Closed e1211281538458 ∧ code e1211281538458 = 5609328049562 := by decide
theorem cert_e1211281538458 : check e1211281538458 [[],[]] .smaller = true := by decide
def e1211281538494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 4)))))))))
theorem wire_e1211281538494 : Closed e1211281538494 ∧ code e1211281538494 = 5609328049598 := by decide
theorem cert_e1211281538494 : check e1211281538494 [[],[]] .chain = true := by decide
def e1211281538502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211281538502 : Closed e1211281538502 ∧ code e1211281538502 = 5609328049606 := by decide
theorem cert_e1211281538502 : check e1211281538502 [[],[]] .smaller = true := by decide
def e1211281538550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 1)))))))))
theorem wire_e1211281538550 : Closed e1211281538550 ∧ code e1211281538550 = 5609328049654 := by decide
theorem cert_e1211281538550 : check e1211281538550 [[],[]] .chain = true := by decide
def e1211281538782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 3)))))))))
theorem wire_e1211281538782 : Closed e1211281538782 ∧ code e1211281538782 = 5609328049886 := by decide
theorem cert_e1211281538782 : check e1211281538782 [[],[]] .chain = true := by decide
def e1211281538806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 1)))))))))
theorem wire_e1211281538806 : Closed e1211281538806 ∧ code e1211281538806 = 5609328049910 := by decide
theorem cert_e1211281538806 : check e1211281538806 [[],[]] .chain = true := by decide
def e1211281541054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211281541054 : Closed e1211281541054 ∧ code e1211281541054 = 5609328052158 := by decide
theorem cert_e1211281541054 : check e1211281541054 [[],[]] .smaller = true := by decide
def e1211281541102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211281541102 : Closed e1211281541102 ∧ code e1211281541102 = 5609328052206 := by decide
theorem cert_e1211281541102 : check e1211281541102 [[],[]] .smaller = true := by decide
def e1211281544926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211281544926 : Closed e1211281544926 ∧ code e1211281544926 = 5609328056030 := by decide
theorem cert_e1211281544926 : check e1211281544926 [[],[]] .smaller = true := by decide
def e1211281544950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211281544950 : Closed e1211281544950 ∧ code e1211281544950 = 5609328056054 := by decide
theorem cert_e1211281544950 : check e1211281544950 [[],[]] .smaller = true := by decide
def e1211281545054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211281545054 : Closed e1211281545054 ∧ code e1211281545054 = 5609328056158 := by decide
theorem cert_e1211281545054 : check e1211281545054 [[],[]] .smaller = true := by decide
def e1211281545070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211281545070 : Closed e1211281545070 ∧ code e1211281545070 = 5609328056174 := by decide
theorem cert_e1211281545070 : check e1211281545070 [[],[]] .smaller = true := by decide
def e1211281545078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211281545078 : Closed e1211281545078 ∧ code e1211281545078 = 5609328056182 := by decide
theorem cert_e1211281545078 : check e1211281545078 [[],[]] .smaller = true := by decide
def e1211281545082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211281545082 : Closed e1211281545082 ∧ code e1211281545082 = 5609328056186 := by decide
theorem cert_e1211281545082 : check e1211281545082 [[],[]] .smaller = true := by decide
def e1211281545142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211281545142 : Closed e1211281545142 ∧ code e1211281545142 = 5609328056246 := by decide
theorem cert_e1211281545142 : check e1211281545142 [[],[]] .smaller = true := by decide
def e1211281545174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211281545174 : Closed e1211281545174 ∧ code e1211281545174 = 5609328056278 := by decide
theorem cert_e1211281545174 : check e1211281545174 [[],[]] .smaller = true := by decide
def e1211281545178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211281545178 : Closed e1211281545178 ∧ code e1211281545178 = 5609328056282 := by decide
theorem cert_e1211281545178 : check e1211281545178 [[],[]] .smaller = true := by decide
def e1211281545694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211281545694 : Closed e1211281545694 ∧ code e1211281545694 = 5609328056798 := by decide
theorem cert_e1211281545694 : check e1211281545694 [[],[]] .smaller = true := by decide
def e1211281545718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211281545718 : Closed e1211281545718 ∧ code e1211281545718 = 5609328056822 := by decide
theorem cert_e1211281545718 : check e1211281545718 [[],[]] .smaller = true := by decide
def e1211281546462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211281546462 : Closed e1211281546462 ∧ code e1211281546462 = 5609328057566 := by decide
theorem cert_e1211281546462 : check e1211281546462 [[],[]] .smaller = true := by decide
def e1211281546478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211281546478 : Closed e1211281546478 ∧ code e1211281546478 = 5609328057582 := by decide
theorem cert_e1211281546478 : check e1211281546478 [[],[]] .smaller = true := by decide
def e1211281546486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211281546486 : Closed e1211281546486 ∧ code e1211281546486 = 5609328057590 := by decide
theorem cert_e1211281546486 : check e1211281546486 [[],[]] .smaller = true := by decide
def e1211281546490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211281546490 : Closed e1211281546490 ∧ code e1211281546490 = 5609328057594 := by decide
theorem cert_e1211281546490 : check e1211281546490 [[],[]] .smaller = true := by decide
def e1211281546814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211281546814 : Closed e1211281546814 ∧ code e1211281546814 = 5609328057918 := by decide
theorem cert_e1211281546814 : check e1211281546814 [[],[]] .smaller = true := by decide
def e1211281546870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211281546870 : Closed e1211281546870 ∧ code e1211281546870 = 5609328057974 := by decide
theorem cert_e1211281546870 : check e1211281546870 [[],[]] .smaller = true := by decide
def e1211281547038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211281547038 : Closed e1211281547038 ∧ code e1211281547038 = 5609328058142 := by decide
theorem cert_e1211281547038 : check e1211281547038 [[],[]] .smaller = true := by decide
def e1211281547062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281547062 : Closed e1211281547062 ∧ code e1211281547062 = 5609328058166 := by decide
theorem cert_e1211281547062 : check e1211281547062 [[],[]] .smaller = true := by decide
def e1211281547066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281547066 : Closed e1211281547066 ∧ code e1211281547066 = 5609328058170 := by decide
theorem cert_e1211281547066 : check e1211281547066 [[],[]] .smaller = true := by decide
def e1211281556414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211281556414 : Closed e1211281556414 ∧ code e1211281556414 = 5609328067518 := by decide
theorem cert_e1211281556414 : check e1211281556414 [[],[]] .smaller = true := by decide
def e1211281556470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211281556470 : Closed e1211281556470 ∧ code e1211281556470 = 5609328067574 := by decide
theorem cert_e1211281556470 : check e1211281556470 [[],[]] .smaller = true := by decide
def e1211281558366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211281558366 : Closed e1211281558366 ∧ code e1211281558366 = 5609328069470 := by decide
theorem cert_e1211281558366 : check e1211281558366 [[],[]] .smaller = true := by decide
def e1211281558382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211281558382 : Closed e1211281558382 ∧ code e1211281558382 = 5609328069486 := by decide
theorem cert_e1211281558382 : check e1211281558382 [[],[]] .smaller = true := by decide
def e1211281558390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211281558390 : Closed e1211281558390 ∧ code e1211281558390 = 5609328069494 := by decide
theorem cert_e1211281558390 : check e1211281558390 [[],[]] .smaller = true := by decide
def e1211281558394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211281558394 : Closed e1211281558394 ∧ code e1211281558394 = 5609328069498 := by decide
theorem cert_e1211281558394 : check e1211281558394 [[],[]] .smaller = true := by decide
def e1211281558446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211281558446 : Closed e1211281558446 ∧ code e1211281558446 = 5609328069550 := by decide
theorem cert_e1211281558446 : check e1211281558446 [[],[]] .smaller = true := by decide
def e1211281558458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211281558458 : Closed e1211281558458 ∧ code e1211281558458 = 5609328069562 := by decide
theorem cert_e1211281558458 : check e1211281558458 [[],[]] .smaller = true := by decide
def e1211281558486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211281558486 : Closed e1211281558486 ∧ code e1211281558486 = 5609328069590 := by decide
theorem cert_e1211281558486 : check e1211281558486 [[],[]] .smaller = true := by decide
def e1211281558490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211281558490 : Closed e1211281558490 ∧ code e1211281558490 = 5609328069594 := by decide
theorem cert_e1211281558490 : check e1211281558490 [[],[]] .smaller = true := by decide
def e1211281558506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211281558506 : Closed e1211281558506 ∧ code e1211281558506 = 5609328069610 := by decide
theorem cert_e1211281558506 : check e1211281558506 [[],[]] .smaller = true := by decide
def e1211281558750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211281558750 : Closed e1211281558750 ∧ code e1211281558750 = 5609328069854 := by decide
theorem cert_e1211281558750 : check e1211281558750 [[],[]] .smaller = true := by decide
def e1211281558766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211281558766 : Closed e1211281558766 ∧ code e1211281558766 = 5609328069870 := by decide
theorem cert_e1211281558766 : check e1211281558766 [[],[]] .smaller = true := by decide
def e1211281558774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211281558774 : Closed e1211281558774 ∧ code e1211281558774 = 5609328069878 := by decide
theorem cert_e1211281558774 : check e1211281558774 [[],[]] .smaller = true := by decide
def e1211281558778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211281558778 : Closed e1211281558778 ∧ code e1211281558778 = 5609328069882 := by decide
theorem cert_e1211281558778 : check e1211281558778 [[],[]] .smaller = true := by decide
def e1211281559150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211281559150 : Closed e1211281559150 ∧ code e1211281559150 = 5609328070254 := by decide
theorem cert_e1211281559150 : check e1211281559150 [[],[]] .smaller = true := by decide
def e1211281559162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211281559162 : Closed e1211281559162 ∧ code e1211281559162 = 5609328070266 := by decide
theorem cert_e1211281559162 : check e1211281559162 [[],[]] .smaller = true := by decide
def e1211281559350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281559350 : Closed e1211281559350 ∧ code e1211281559350 = 5609328070454 := by decide
theorem cert_e1211281559350 : check e1211281559350 [[],[]] .smaller = true := by decide
def e1211281559354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281559354 : Closed e1211281559354 ∧ code e1211281559354 = 5609328070458 := by decide
theorem cert_e1211281559354 : check e1211281559354 [[],[]] .smaller = true := by decide
def e1211281559450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211281559450 : Closed e1211281559450 ∧ code e1211281559450 = 5609328070554 := by decide
theorem cert_e1211281559450 : check e1211281559450 [[],[]] .smaller = true := by decide
def e1211281559486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 4))))))))))
theorem wire_e1211281559486 : Closed e1211281559486 ∧ code e1211281559486 = 5609328070590 := by decide
theorem cert_e1211281559486 : check e1211281559486 [[],[]] .chain = true := by decide
def e1211281559518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 3))))))))))
theorem wire_e1211281559518 : Closed e1211281559518 ∧ code e1211281559518 = 5609328070622 := by decide
theorem cert_e1211281559518 : check e1211281559518 [[],[]] .chain = true := by decide
def e1211281565110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211281565110 : Closed e1211281565110 ∧ code e1211281565110 = 5609328076214 := by decide
theorem cert_e1211281565110 : check e1211281565110 [[],[]] .smaller = true := by decide
def e1211281565142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211281565142 : Closed e1211281565142 ∧ code e1211281565142 = 5609328076246 := by decide
theorem cert_e1211281565142 : check e1211281565142 [[],[]] .smaller = true := by decide
def e1211281565146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211281565146 : Closed e1211281565146 ∧ code e1211281565146 = 5609328076250 := by decide
theorem cert_e1211281565146 : check e1211281565146 [[],[]] .smaller = true := by decide
def e1211281565246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211281565246 : Closed e1211281565246 ∧ code e1211281565246 = 5609328076350 := by decide
theorem cert_e1211281565246 : check e1211281565246 [[],[]] .smaller = true := by decide
def e1211281565302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211281565302 : Closed e1211281565302 ∧ code e1211281565302 = 5609328076406 := by decide
theorem cert_e1211281565302 : check e1211281565302 [[],[]] .smaller = true := by decide
def e1211281565494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281565494 : Closed e1211281565494 ∧ code e1211281565494 = 5609328076598 := by decide
theorem cert_e1211281565494 : check e1211281565494 [[],[]] .smaller = true := by decide
def e1211281565498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281565498 : Closed e1211281565498 ∧ code e1211281565498 = 5609328076602 := by decide
theorem cert_e1211281565498 : check e1211281565498 [[],[]] .smaller = true := by decide
def e1211281565638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211281565638 : Closed e1211281565638 ∧ code e1211281565638 = 5609328076742 := by decide
theorem cert_e1211281565638 : check e1211281565638 [[],[]] .smaller = true := by decide
def e1211281567982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211281567982 : Closed e1211281567982 ∧ code e1211281567982 = 5609328079086 := by decide
theorem cert_e1211281567982 : check e1211281567982 [[],[]] .smaller = true := by decide
def e1211281567990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211281567990 : Closed e1211281567990 ∧ code e1211281567990 = 5609328079094 := by decide
theorem cert_e1211281567990 : check e1211281567990 [[],[]] .smaller = true := by decide
def e1211281568470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211281568470 : Closed e1211281568470 ∧ code e1211281568470 = 5609328079574 := by decide
theorem cert_e1211281568470 : check e1211281568470 [[],[]] .smaller = true := by decide
def e1211281568474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211281568474 : Closed e1211281568474 ∧ code e1211281568474 = 5609328079578 := by decide
theorem cert_e1211281568474 : check e1211281568474 [[],[]] .smaller = true := by decide
def e1211281568490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211281568490 : Closed e1211281568490 ∧ code e1211281568490 = 5609328079594 := by decide
theorem cert_e1211281568490 : check e1211281568490 [[],[]] .smaller = true := by decide
def e1211281568542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211281568542 : Closed e1211281568542 ∧ code e1211281568542 = 5609328079646 := by decide
theorem cert_e1211281568542 : check e1211281568542 [[],[]] .smaller = true := by decide
def e1211281568566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281568566 : Closed e1211281568566 ∧ code e1211281568566 = 5609328079670 := by decide
theorem cert_e1211281568566 : check e1211281568566 [[],[]] .smaller = true := by decide
def e1211281568570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281568570 : Closed e1211281568570 ∧ code e1211281568570 = 5609328079674 := by decide
theorem cert_e1211281568570 : check e1211281568570 [[],[]] .smaller = true := by decide
def e1211281568666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211281568666 : Closed e1211281568666 ∧ code e1211281568666 = 5609328079770 := by decide
theorem cert_e1211281568666 : check e1211281568666 [[],[]] .smaller = true := by decide
def e1211281568702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211281568702 : Closed e1211281568702 ∧ code e1211281568702 = 5609328079806 := by decide
theorem cert_e1211281568702 : check e1211281568702 [[],[]] .chain = true := by decide
def e1211281568710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211281568710 : Closed e1211281568710 ∧ code e1211281568710 = 5609328079814 := by decide
theorem cert_e1211281568710 : check e1211281568710 [[],[]] .smaller = true := by decide
def e1211281568758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211281568758 : Closed e1211281568758 ∧ code e1211281568758 = 5609328079862 := by decide
theorem cert_e1211281568758 : check e1211281568758 [[],[]] .chain = true := by decide
def e1211281570270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211281570270 : Closed e1211281570270 ∧ code e1211281570270 = 5609328081374 := by decide
theorem cert_e1211281570270 : check e1211281570270 [[],[]] .chain = true := by decide
def e1211281570294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211281570294 : Closed e1211281570294 ∧ code e1211281570294 = 5609328081398 := by decide
theorem cert_e1211281570294 : check e1211281570294 [[],[]] .chain = true := by decide
def e1211281793902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211281793902 : Closed e1211281793902 ∧ code e1211281793902 = 5609328305006 := by decide
theorem cert_e1211281793902 : check e1211281793902 [[],[]] .smaller = true := by decide
def e1211281793910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211281793910 : Closed e1211281793910 ∧ code e1211281793910 = 5609328305014 := by decide
theorem cert_e1211281793910 : check e1211281793910 [[],[]] .smaller = true := by decide
def e1211281793966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e1211281793966 : Closed e1211281793966 ∧ code e1211281793966 = 5609328305070 := by decide
theorem cert_e1211281793966 : check e1211281793966 [[],[]] .smaller = true := by decide
def e1211281793978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e1211281793978 : Closed e1211281793978 ∧ code e1211281793978 = 5609328305082 := by decide
theorem cert_e1211281793978 : check e1211281793978 [[],[]] .smaller = true := by decide
def e1211281794006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211281794006 : Closed e1211281794006 ∧ code e1211281794006 = 5609328305110 := by decide
theorem cert_e1211281794006 : check e1211281794006 [[],[]] .smaller = true := by decide
def e1211281794010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211281794010 : Closed e1211281794010 ∧ code e1211281794010 = 5609328305114 := by decide
theorem cert_e1211281794010 : check e1211281794010 [[],[]] .smaller = true := by decide
def e1211281795310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211281795310 : Closed e1211281795310 ∧ code e1211281795310 = 5609328306414 := by decide
theorem cert_e1211281795310 : check e1211281795310 [[],[]] .smaller = true := by decide
def e1211281795318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211281795318 : Closed e1211281795318 ∧ code e1211281795318 = 5609328306422 := by decide
theorem cert_e1211281795318 : check e1211281795318 [[],[]] .smaller = true := by decide
def e1211281795870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211281795870 : Closed e1211281795870 ∧ code e1211281795870 = 5609328306974 := by decide
theorem cert_e1211281795870 : check e1211281795870 [[],[]] .smaller = true := by decide
def e1211281795982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211281795982 : Closed e1211281795982 ∧ code e1211281795982 = 5609328307086 := by decide
theorem cert_e1211281795982 : check e1211281795982 [[],[]] .smaller = true := by decide
def e1211281796206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211281796206 : Closed e1211281796206 ∧ code e1211281796206 = 5609328307310 := by decide
theorem cert_e1211281796206 : check e1211281796206 [[],[]] .smaller = true := by decide
def e1211281796218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211281796218 : Closed e1211281796218 ∧ code e1211281796218 = 5609328307322 := by decide
theorem cert_e1211281796218 : check e1211281796218 [[],[]] .smaller = true := by decide
def e1211281796382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211281796382 : Closed e1211281796382 ∧ code e1211281796382 = 5609328307486 := by decide
theorem cert_e1211281796382 : check e1211281796382 [[],[]] .smaller = true := by decide
def e1211281796550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211281796550 : Closed e1211281796550 ∧ code e1211281796550 = 5609328307654 := by decide
theorem cert_e1211281796550 : check e1211281796550 [[],[]] .smaller = true := by decide
def e1211281796574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e1211281796574 : Closed e1211281796574 ∧ code e1211281796574 = 5609328307678 := by decide
theorem cert_e1211281796574 : check e1211281796574 [[],[]] .chain = true := by decide
def e1211281796590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e1211281796590 : Closed e1211281796590 ∧ code e1211281796590 = 5609328307694 := by decide
theorem cert_e1211281796590 : check e1211281796590 [[],[]] .chain = true := by decide
def e1211281796662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211281796662 : Closed e1211281796662 ∧ code e1211281796662 = 5609328307766 := by decide
theorem cert_e1211281796662 : check e1211281796662 [[],[]] .smaller = true := by decide
def e1211281796666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211281796666 : Closed e1211281796666 ∧ code e1211281796666 = 5609328307770 := by decide
theorem cert_e1211281796666 : check e1211281796666 [[],[]] .smaller = true := by decide
def e1211281796750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211281796750 : Closed e1211281796750 ∧ code e1211281796750 = 5609328307854 := by decide
theorem cert_e1211281796750 : check e1211281796750 [[],[]] .smaller = true := by decide
def e1211281796806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211281796806 : Closed e1211281796806 ∧ code e1211281796806 = 5609328307910 := by decide
theorem cert_e1211281796806 : check e1211281796806 [[],[]] .smaller = true := by decide
def e1211281796830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e1211281796830 : Closed e1211281796830 ∧ code e1211281796830 = 5609328307934 := by decide
theorem cert_e1211281796830 : check e1211281796830 [[],[]] .chain = true := by decide
def e1211281796854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e1211281796854 : Closed e1211281796854 ∧ code e1211281796854 = 5609328307958 := by decide
theorem cert_e1211281796854 : check e1211281796854 [[],[]] .chain = true := by decide
def e1211281796974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e1211281796974 : Closed e1211281796974 ∧ code e1211281796974 = 5609328308078 := by decide
theorem cert_e1211281796974 : check e1211281796974 [[],[]] .chain = true := by decide
def e1211281796982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e1211281796982 : Closed e1211281796982 ∧ code e1211281796982 = 5609328308086 := by decide
theorem cert_e1211281796982 : check e1211281796982 [[],[]] .chain = true := by decide
def e1211281797550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211281797550 : Closed e1211281797550 ∧ code e1211281797550 = 5609328308654 := by decide
theorem cert_e1211281797550 : check e1211281797550 [[],[]] .smaller = true := by decide
def e1211281797562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211281797562 : Closed e1211281797562 ∧ code e1211281797562 = 5609328308666 := by decide
theorem cert_e1211281797562 : check e1211281797562 [[],[]] .smaller = true := by decide
def e1211281797610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211281797610 : Closed e1211281797610 ∧ code e1211281797610 = 5609328308714 := by decide
theorem cert_e1211281797610 : check e1211281797610 [[],[]] .smaller = true := by decide
def e1211281798254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211281798254 : Closed e1211281798254 ∧ code e1211281798254 = 5609328309358 := by decide
theorem cert_e1211281798254 : check e1211281798254 [[],[]] .smaller = true := by decide
def e1211281798266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211281798266 : Closed e1211281798266 ∧ code e1211281798266 = 5609328309370 := by decide
theorem cert_e1211281798266 : check e1211281798266 [[],[]] .smaller = true := by decide
def e1211281798430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211281798430 : Closed e1211281798430 ∧ code e1211281798430 = 5609328309534 := by decide
theorem cert_e1211281798430 : check e1211281798430 [[],[]] .smaller = true := by decide
def e1211281798598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211281798598 : Closed e1211281798598 ∧ code e1211281798598 = 5609328309702 := by decide
theorem cert_e1211281798598 : check e1211281798598 [[],[]] .smaller = true := by decide
def e1211281798622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211281798622 : Closed e1211281798622 ∧ code e1211281798622 = 5609328309726 := by decide
theorem cert_e1211281798622 : check e1211281798622 [[],[]] .chain = true := by decide
def e1211281798638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211281798638 : Closed e1211281798638 ∧ code e1211281798638 = 5609328309742 := by decide
theorem cert_e1211281798638 : check e1211281798638 [[],[]] .chain = true := by decide
def e1211281798938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211281798938 : Closed e1211281798938 ∧ code e1211281798938 = 5609328310042 := by decide
theorem cert_e1211281798938 : check e1211281798938 [[],[]] .smaller = true := by decide
def e1211281798982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211281798982 : Closed e1211281798982 ∧ code e1211281798982 = 5609328310086 := by decide
theorem cert_e1211281798982 : check e1211281798982 [[],[]] .smaller = true := by decide
def e1211281799006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211281799006 : Closed e1211281799006 ∧ code e1211281799006 = 5609328310110 := by decide
theorem cert_e1211281799006 : check e1211281799006 [[],[]] .chain = true := by decide
end Blc.Floor42
