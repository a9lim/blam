import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188962878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211188962878 : Closed e1211188962878 ∧ code e1211188962878 = 5609235473982 := by decide
theorem cert_e1211188962878 : check e1211188962878 [[],[]] .three = true := by decide
def e1211188962914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188962914 : Closed e1211188962914 ∧ code e1211188962914 = 5609235474018 := by decide
theorem cert_e1211188962914 : check e1211188962914 [[],[]] .three = true := by decide
def e1211188962926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188962926 : Closed e1211188962926 ∧ code e1211188962926 = 5609235474030 := by decide
theorem cert_e1211188962926 : check e1211188962926 [[],[]] .three = true := by decide
def e1211188962934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188962934 : Closed e1211188962934 ∧ code e1211188962934 = 5609235474038 := by decide
theorem cert_e1211188962934 : check e1211188962934 [[],[]] .three = true := by decide
def e1211188962938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188962938 : Closed e1211188962938 ∧ code e1211188962938 = 5609235474042 := by decide
theorem cert_e1211188962938 : check e1211188962938 [[],[]] .three = true := by decide
def e1211188963102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211188963102 : Closed e1211188963102 ∧ code e1211188963102 = 5609235474206 := by decide
theorem cert_e1211188963102 : check e1211188963102 [[],[]] .three = true := by decide
def e1211188963126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188963126 : Closed e1211188963126 ∧ code e1211188963126 = 5609235474230 := by decide
theorem cert_e1211188963126 : check e1211188963126 [[],[]] .three = true := by decide
def e1211188963130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188963130 : Closed e1211188963130 ∧ code e1211188963130 = 5609235474234 := by decide
theorem cert_e1211188963130 : check e1211188963130 [[],[]] .three = true := by decide
def e1211188963214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211188963214 : Closed e1211188963214 ∧ code e1211188963214 = 5609235474318 := by decide
theorem cert_e1211188963214 : check e1211188963214 [[],[]] .three = true := by decide
def e1211188963226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188963226 : Closed e1211188963226 ∧ code e1211188963226 = 5609235474330 := by decide
theorem cert_e1211188963226 : check e1211188963226 [[],[]] .three = true := by decide
def e1211188963270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211188963270 : Closed e1211188963270 ∧ code e1211188963270 = 5609235474374 := by decide
theorem cert_e1211188963270 : check e1211188963270 [[],[]] .three = true := by decide
def e1211188966102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211188966102 : Closed e1211188966102 ∧ code e1211188966102 = 5609235477206 := by decide
theorem cert_e1211188966102 : check e1211188966102 [[],[]] .three = true := by decide
def e1211188966106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211188966106 : Closed e1211188966106 ∧ code e1211188966106 = 5609235477210 := by decide
theorem cert_e1211188966106 : check e1211188966106 [[],[]] .three = true := by decide
def e1211188966122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211188966122 : Closed e1211188966122 ∧ code e1211188966122 = 5609235477226 := by decide
theorem cert_e1211188966122 : check e1211188966122 [[],[]] .three = true := by decide
def e1211188966174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211188966174 : Closed e1211188966174 ∧ code e1211188966174 = 5609235477278 := by decide
theorem cert_e1211188966174 : check e1211188966174 [[],[]] .three = true := by decide
def e1211188966198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188966198 : Closed e1211188966198 ∧ code e1211188966198 = 5609235477302 := by decide
theorem cert_e1211188966198 : check e1211188966198 [[],[]] .three = true := by decide
def e1211188966202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188966202 : Closed e1211188966202 ∧ code e1211188966202 = 5609235477306 := by decide
theorem cert_e1211188966202 : check e1211188966202 [[],[]] .three = true := by decide
def e1211188966286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211188966286 : Closed e1211188966286 ∧ code e1211188966286 = 5609235477390 := by decide
theorem cert_e1211188966286 : check e1211188966286 [[],[]] .three = true := by decide
def e1211188966298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188966298 : Closed e1211188966298 ∧ code e1211188966298 = 5609235477402 := by decide
theorem cert_e1211188966298 : check e1211188966298 [[],[]] .three = true := by decide
def e1211188966342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211188966342 : Closed e1211188966342 ∧ code e1211188966342 = 5609235477446 := by decide
theorem cert_e1211188966342 : check e1211188966342 [[],[]] .three = true := by decide
def e1211188967822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211188967822 : Closed e1211188967822 ∧ code e1211188967822 = 5609235478926 := by decide
theorem cert_e1211188967822 : check e1211188967822 [[],[]] .three = true := by decide
def e1211188967878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211188967878 : Closed e1211188967878 ∧ code e1211188967878 = 5609235478982 := by decide
theorem cert_e1211188967878 : check e1211188967878 [[],[]] .three = true := by decide
def e1211199179630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211199179630 : Closed e1211199179630 ∧ code e1211199179630 = 5609245690734 := by decide
theorem cert_e1211199179630 : check e1211199179630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211199179638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211199179638 : Closed e1211199179638 ∧ code e1211199179638 = 5609245690742 := by decide
theorem cert_e1211199179638 : check e1211199179638 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e1211199179694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211199179694 : Closed e1211199179694 ∧ code e1211199179694 = 5609245690798 := by decide
theorem cert_e1211199179694 : check e1211199179694 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199179706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211199179706 : Closed e1211199179706 ∧ code e1211199179706 = 5609245690810 := by decide
theorem cert_e1211199179706 : check e1211199179706 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199179734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211199179734 : Closed e1211199179734 ∧ code e1211199179734 = 5609245690838 := by decide
theorem cert_e1211199179734 : check e1211199179734 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211199179738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211199179738 : Closed e1211199179738 ∧ code e1211199179738 = 5609245690842 := by decide
theorem cert_e1211199179738 : check e1211199179738 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211199180014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211199180014 : Closed e1211199180014 ∧ code e1211199180014 = 5609245691118 := by decide
theorem cert_e1211199180014 : check e1211199180014 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1211199180022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211199180022 : Closed e1211199180022 ∧ code e1211199180022 = 5609245691126 := by decide
theorem cert_e1211199180022 : check e1211199180022 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211199180398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211199180398 : Closed e1211199180398 ∧ code e1211199180398 = 5609245691502 := by decide
theorem cert_e1211199180398 : checkPay e1211199180398 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under],[.under,.left],[.under,.right,.under]] = true := by decide
def e1211199180410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211199180410 : Closed e1211199180410 ∧ code e1211199180410 = 5609245691514 := by decide
theorem cert_e1211199180410 : checkPay e1211199180410 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right],[.under,.under,.right,.under,.right]] = true := by decide
def e1211199180598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211199180598 : Closed e1211199180598 ∧ code e1211199180598 = 5609245691702 := by decide
theorem cert_e1211199180598 : check e1211199180598 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211199180602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211199180602 : Closed e1211199180602 ∧ code e1211199180602 = 5609245691706 := by decide
theorem cert_e1211199180602 : check e1211199180602 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211199264478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211199264478 : Closed e1211199264478 ∧ code e1211199264478 = 5609245775582 := by decide
theorem cert_e1211199264478 : check e1211199264478 [[.left,.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under],[.under],[.under,.left]] .identityHead = true := by decide
def e1211199264502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211199264502 : Closed e1211199264502 ∧ code e1211199264502 = 5609245775606 := by decide
private def t_e1211199264502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e1211199264502 : ¬ IsSelfInterpreter e1211199264502 :=
  wSource (t := t_e1211199264502) (replay_sound (ps := []) (t := e1211199264502) (by decide)) (by decide)
def e1211199264606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211199264606 : Closed e1211199264606 ∧ code e1211199264606 = 5609245775710 := by decide
theorem cert_e1211199264606 : check e1211199264606 [[.left,.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under],[.under,.under]] .identityHead = true := by decide
def e1211199264634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211199264634 : Closed e1211199264634 ∧ code e1211199264634 = 5609245775738 := by decide
theorem cert_e1211199264634 : check e1211199264634 [[.left,.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1211199264726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211199264726 : Closed e1211199264726 ∧ code e1211199264726 = 5609245775830 := by decide
private def t_e1211199264726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e1211199264726 : ¬ IsSelfInterpreter e1211199264726 :=
  wSource (t := t_e1211199264726) (replay_sound (ps := []) (t := e1211199264726) (by decide)) (by decide)
def e1211199264730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211199264730 : Closed e1211199264730 ∧ code e1211199264730 = 5609245775834 := by decide
theorem cert_e1211199264730 : check e1211199264730 [[],[],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211199265246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211199265246 : Closed e1211199265246 ∧ code e1211199265246 = 5609245776350 := by decide
theorem cert_e1211199265246 : check e1211199265246 [[.left,.left],[.left,.left],[.left],[],[],[],[],[.left],[.left,.left],[.left],[],[],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e1211199265270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211199265270 : Closed e1211199265270 ∧ code e1211199265270 = 5609245776374 := by decide
theorem cert_e1211199265270 : check e1211199265270 [[],[],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211199266014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211199266014 : Closed e1211199266014 ∧ code e1211199266014 = 5609245777118 := by decide
theorem cert_e1211199266014 : check e1211199266014 [[.left,.left],[.left,.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211199266042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211199266042 : Closed e1211199266042 ∧ code e1211199266042 = 5609245777146 := by decide
def e1211199266614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211199266614 : Closed e1211199266614 ∧ code e1211199266614 = 5609245777718 := by decide
theorem cert_e1211199266614 : check e1211199266614 [[],[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211199266618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211199266618 : Closed e1211199266618 ∧ code e1211199266618 = 5609245777722 := by decide
theorem cert_e1211199266618 : check e1211199266618 [[],[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211199281390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211199281390 : Closed e1211199281390 ∧ code e1211199281390 = 5609245792494 := by decide
theorem cert_e1211199281390 : check e1211199281390 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211199281398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211199281398 : Closed e1211199281398 ∧ code e1211199281398 = 5609245792502 := by decide
theorem cert_e1211199281398 : check e1211199281398 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211199281950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211199281950 : Closed e1211199281950 ∧ code e1211199281950 = 5609245793054 := by decide
theorem cert_e1211199281950 : check e1211199281950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211199282062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211199282062 : Closed e1211199282062 ∧ code e1211199282062 = 5609245793166 := by decide
theorem cert_e1211199282062 : check e1211199282062 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211199282286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211199282286 : Closed e1211199282286 ∧ code e1211199282286 = 5609245793390 := by decide
theorem cert_e1211199282286 : check e1211199282286 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199282298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211199282298 : Closed e1211199282298 ∧ code e1211199282298 = 5609245793402 := by decide
theorem cert_e1211199282298 : check e1211199282298 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199282462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211199282462 : Closed e1211199282462 ∧ code e1211199282462 = 5609245793566 := by decide
theorem cert_e1211199282462 : check e1211199282462 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199282630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211199282630 : Closed e1211199282630 ∧ code e1211199282630 = 5609245793734 := by decide
theorem cert_e1211199282630 : check e1211199282630 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1211199282742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211199282742 : Closed e1211199282742 ∧ code e1211199282742 = 5609245793846 := by decide
theorem cert_e1211199282742 : check e1211199282742 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211199282746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211199282746 : Closed e1211199282746 ∧ code e1211199282746 = 5609245793850 := by decide
theorem cert_e1211199282746 : checkPay e1211199282746 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left]] 0 [[.left],[],[.under],[.under,.left,.left],[.under,.right,.left]] = true := by decide
def e1211199282830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211199282830 : Closed e1211199282830 ∧ code e1211199282830 = 5609245793934 := by decide
theorem cert_e1211199282830 : check e1211199282830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211199282886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211199282886 : Closed e1211199282886 ∧ code e1211199282886 = 5609245793990 := by decide
theorem cert_e1211199282886 : check e1211199282886 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211199285022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211199285022 : Closed e1211199285022 ∧ code e1211199285022 = 5609245796126 := by decide
theorem cert_e1211199285022 : check e1211199285022 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1211199285134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211199285134 : Closed e1211199285134 ∧ code e1211199285134 = 5609245796238 := by decide
theorem cert_e1211199285134 : check e1211199285134 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211199288094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211199288094 : Closed e1211199288094 ∧ code e1211199288094 = 5609245799198 := by decide
theorem cert_e1211199288094 : checkPay e1211199288094 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under,.under]] = true := by decide
def e1211199288262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211199288262 : Closed e1211199288262 ∧ code e1211199288262 = 5609245799366 := by decide
theorem cert_e1211199288262 : checkPay e1211199288262 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right],[.under,.under,.right,.right]] = true := by decide
def e1211199289742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211199289742 : Closed e1211199289742 ∧ code e1211199289742 = 5609245800846 := by decide
theorem cert_e1211199289742 : check e1211199289742 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211199289798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211199289798 : Closed e1211199289798 ∧ code e1211199289798 = 5609245800902 := by decide
theorem cert_e1211199289798 : check e1211199289798 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211202155374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211202155374 : Closed e1211202155374 ∧ code e1211202155374 = 5609248666478 := by decide
theorem cert_e1211202155374 : check e1211202155374 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211202155382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211202155382 : Closed e1211202155382 ∧ code e1211202155382 = 5609248666486 := by decide
def e1211202155438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211202155438 : Closed e1211202155438 ∧ code e1211202155438 = 5609248666542 := by decide
theorem cert_e1211202155438 : check e1211202155438 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211202155450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211202155450 : Closed e1211202155450 ∧ code e1211202155450 = 5609248666554 := by decide
theorem cert_e1211202155450 : check e1211202155450 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1211202155478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211202155478 : Closed e1211202155478 ∧ code e1211202155478 = 5609248666582 := by decide
theorem cert_e1211202155478 : check e1211202155478 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211202155482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211202155482 : Closed e1211202155482 ∧ code e1211202155482 = 5609248666586 := by decide
theorem cert_e1211202155482 : check e1211202155482 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211202181358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211202181358 : Closed e1211202181358 ∧ code e1211202181358 = 5609248692462 := by decide
theorem cert_e1211202181358 : check e1211202181358 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211202181366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211202181366 : Closed e1211202181366 ∧ code e1211202181366 = 5609248692470 := by decide
theorem cert_e1211202181366 : check e1211202181366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211202182030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211202182030 : Closed e1211202182030 ∧ code e1211202182030 = 5609248693134 := by decide
theorem cert_e1211202182030 : check e1211202182030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211202182254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211202182254 : Closed e1211202182254 ∧ code e1211202182254 = 5609248693358 := by decide
theorem cert_e1211202182254 : check e1211202182254 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211202182266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211202182266 : Closed e1211202182266 ∧ code e1211202182266 = 5609248693370 := by decide
theorem cert_e1211202182266 : check e1211202182266 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1211202182598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211202182598 : Closed e1211202182598 ∧ code e1211202182598 = 5609248693702 := by decide
theorem cert_e1211202182598 : check e1211202182598 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1211202182710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211202182710 : Closed e1211202182710 ∧ code e1211202182710 = 5609248693814 := by decide
theorem cert_e1211202182710 : check e1211202182710 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211202182714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211202182714 : Closed e1211202182714 ∧ code e1211202182714 = 5609248693818 := by decide
theorem cert_e1211202182714 : check e1211202182714 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211202182798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211202182798 : Closed e1211202182798 ∧ code e1211202182798 = 5609248693902 := by decide
theorem cert_e1211202182798 : check e1211202182798 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211202182854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211202182854 : Closed e1211202182854 ∧ code e1211202182854 = 5609248693958 := by decide
theorem cert_e1211202182854 : check e1211202182854 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211203169134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1211203169134 : Closed e1211203169134 ∧ code e1211203169134 = 5609249680238 := by decide
theorem cert_e1211203169134 : check e1211203169134 [[],[]] .chain = true := by decide
def e1211203169142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1211203169142 : Closed e1211203169142 ∧ code e1211203169142 = 5609249680246 := by decide
theorem cert_e1211203169142 : check e1211203169142 [[],[]] .chain = true := by decide
def e1211203169206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1211203169206 : Closed e1211203169206 ∧ code e1211203169206 = 5609249680310 := by decide
theorem cert_e1211203169206 : check e1211203169206 [[],[]] .chain = true := by decide
def e1211203169646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203169646 : Closed e1211203169646 ∧ code e1211203169646 = 5609249680750 := by decide
theorem cert_e1211203169646 : check e1211203169646 [[],[]] .chain = true := by decide
def e1211203169654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203169654 : Closed e1211203169654 ∧ code e1211203169654 = 5609249680758 := by decide
theorem cert_e1211203169654 : check e1211203169654 [[],[]] .chain = true := by decide
def e1211203169710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203169710 : Closed e1211203169710 ∧ code e1211203169710 = 5609249680814 := by decide
theorem cert_e1211203169710 : check e1211203169710 [[],[]] .chain = true := by decide
def e1211203169722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203169722 : Closed e1211203169722 ∧ code e1211203169722 = 5609249680826 := by decide
theorem cert_e1211203169722 : check e1211203169722 [[],[]] .chain = true := by decide
def e1211203169750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203169750 : Closed e1211203169750 ∧ code e1211203169750 = 5609249680854 := by decide
theorem cert_e1211203169750 : check e1211203169750 [[],[]] .chain = true := by decide
def e1211203169754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203169754 : Closed e1211203169754 ∧ code e1211203169754 = 5609249680858 := by decide
theorem cert_e1211203169754 : check e1211203169754 [[],[]] .chain = true := by decide
def e1211203169974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203169974 : Closed e1211203169974 ∧ code e1211203169974 = 5609249681078 := by decide
theorem cert_e1211203169974 : check e1211203169974 [[],[]] .chain = true := by decide
def e1211203170006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203170006 : Closed e1211203170006 ∧ code e1211203170006 = 5609249681110 := by decide
theorem cert_e1211203170006 : check e1211203170006 [[],[]] .chain = true := by decide
def e1211203170010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203170010 : Closed e1211203170010 ∧ code e1211203170010 = 5609249681114 := by decide
theorem cert_e1211203170010 : check e1211203170010 [[],[]] .chain = true := by decide
def e1211203171694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203171694 : Closed e1211203171694 ∧ code e1211203171694 = 5609249682798 := by decide
theorem cert_e1211203171694 : check e1211203171694 [[],[]] .chain = true := by decide
def e1211203171702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203171702 : Closed e1211203171702 ∧ code e1211203171702 = 5609249682806 := by decide
theorem cert_e1211203171702 : check e1211203171702 [[],[]] .chain = true := by decide
def e1211203171758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203171758 : Closed e1211203171758 ∧ code e1211203171758 = 5609249682862 := by decide
theorem cert_e1211203171758 : check e1211203171758 [[],[]] .chain = true := by decide
def e1211203171770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203171770 : Closed e1211203171770 ∧ code e1211203171770 = 5609249682874 := by decide
theorem cert_e1211203171770 : check e1211203171770 [[],[]] .chain = true := by decide
def e1211203171798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203171798 : Closed e1211203171798 ∧ code e1211203171798 = 5609249682902 := by decide
theorem cert_e1211203171798 : check e1211203171798 [[],[]] .chain = true := by decide
def e1211203171802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203171802 : Closed e1211203171802 ∧ code e1211203171802 = 5609249682906 := by decide
theorem cert_e1211203171802 : check e1211203171802 [[],[]] .chain = true := by decide
def e1211203172014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203172014 : Closed e1211203172014 ∧ code e1211203172014 = 5609249683118 := by decide
theorem cert_e1211203172014 : check e1211203172014 [[],[]] .chain = true := by decide
def e1211203172026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203172026 : Closed e1211203172026 ∧ code e1211203172026 = 5609249683130 := by decide
theorem cert_e1211203172026 : check e1211203172026 [[],[]] .chain = true := by decide
def e1211203172074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203172074 : Closed e1211203172074 ∧ code e1211203172074 = 5609249683178 := by decide
theorem cert_e1211203172074 : check e1211203172074 [[],[]] .chain = true := by decide
def e1211203172182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203172182 : Closed e1211203172182 ∧ code e1211203172182 = 5609249683286 := by decide
theorem cert_e1211203172182 : check e1211203172182 [[],[]] .chain = true := by decide
def e1211203172186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203172186 : Closed e1211203172186 ∧ code e1211203172186 = 5609249683290 := by decide
theorem cert_e1211203172186 : check e1211203172186 [[],[]] .chain = true := by decide
def e1211203172202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203172202 : Closed e1211203172202 ∧ code e1211203172202 = 5609249683306 := by decide
theorem cert_e1211203172202 : check e1211203172202 [[],[]] .chain = true := by decide
def e1211203173046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203173046 : Closed e1211203173046 ∧ code e1211203173046 = 5609249684150 := by decide
theorem cert_e1211203173046 : check e1211203173046 [[],[]] .chain = true := by decide
def e1211203173078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203173078 : Closed e1211203173078 ∧ code e1211203173078 = 5609249684182 := by decide
theorem cert_e1211203173078 : check e1211203173078 [[],[]] .chain = true := by decide
def e1211203173082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203173082 : Closed e1211203173082 ∧ code e1211203173082 = 5609249684186 := by decide
theorem cert_e1211203173082 : check e1211203173082 [[],[]] .chain = true := by decide
def e1211203173206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203173206 : Closed e1211203173206 ∧ code e1211203173206 = 5609249684310 := by decide
theorem cert_e1211203173206 : check e1211203173206 [[],[]] .chain = true := by decide
def e1211203173210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203173210 : Closed e1211203173210 ∧ code e1211203173210 = 5609249684314 := by decide
theorem cert_e1211203173210 : check e1211203173210 [[],[]] .chain = true := by decide
def e1211203173226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203173226 : Closed e1211203173226 ∧ code e1211203173226 = 5609249684330 := by decide
theorem cert_e1211203173226 : check e1211203173226 [[],[]] .chain = true := by decide
def e1211203179886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203179886 : Closed e1211203179886 ∧ code e1211203179886 = 5609249690990 := by decide
theorem cert_e1211203179886 : check e1211203179886 [[],[]] .chain = true := by decide
def e1211203179894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203179894 : Closed e1211203179894 ∧ code e1211203179894 = 5609249690998 := by decide
theorem cert_e1211203179894 : check e1211203179894 [[],[]] .chain = true := by decide
def e1211203179950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203179950 : Closed e1211203179950 ∧ code e1211203179950 = 5609249691054 := by decide
theorem cert_e1211203179950 : check e1211203179950 [[],[]] .chain = true := by decide
def e1211203179962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203179962 : Closed e1211203179962 ∧ code e1211203179962 = 5609249691066 := by decide
theorem cert_e1211203179962 : check e1211203179962 [[],[]] .chain = true := by decide
def e1211203179990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203179990 : Closed e1211203179990 ∧ code e1211203179990 = 5609249691094 := by decide
theorem cert_e1211203179990 : check e1211203179990 [[],[]] .chain = true := by decide
def e1211203179994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203179994 : Closed e1211203179994 ∧ code e1211203179994 = 5609249691098 := by decide
theorem cert_e1211203179994 : check e1211203179994 [[],[]] .chain = true := by decide
def e1211203180206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203180206 : Closed e1211203180206 ∧ code e1211203180206 = 5609249691310 := by decide
theorem cert_e1211203180206 : check e1211203180206 [[],[]] .chain = true := by decide
def e1211203180218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203180218 : Closed e1211203180218 ∧ code e1211203180218 = 5609249691322 := by decide
theorem cert_e1211203180218 : check e1211203180218 [[],[]] .chain = true := by decide
def e1211203180266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203180266 : Closed e1211203180266 ∧ code e1211203180266 = 5609249691370 := by decide
theorem cert_e1211203180266 : check e1211203180266 [[],[]] .chain = true := by decide
def e1211203180374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203180374 : Closed e1211203180374 ∧ code e1211203180374 = 5609249691478 := by decide
theorem cert_e1211203180374 : check e1211203180374 [[],[]] .chain = true := by decide
def e1211203180378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203180378 : Closed e1211203180378 ∧ code e1211203180378 = 5609249691482 := by decide
theorem cert_e1211203180378 : check e1211203180378 [[],[]] .chain = true := by decide
def e1211203180394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203180394 : Closed e1211203180394 ∧ code e1211203180394 = 5609249691498 := by decide
theorem cert_e1211203180394 : check e1211203180394 [[],[]] .chain = true := by decide
def e1211203181230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203181230 : Closed e1211203181230 ∧ code e1211203181230 = 5609249692334 := by decide
theorem cert_e1211203181230 : check e1211203181230 [[],[]] .chain = true := by decide
def e1211203181242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203181242 : Closed e1211203181242 ∧ code e1211203181242 = 5609249692346 := by decide
theorem cert_e1211203181242 : check e1211203181242 [[],[]] .chain = true := by decide
def e1211203181290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203181290 : Closed e1211203181290 ∧ code e1211203181290 = 5609249692394 := by decide
theorem cert_e1211203181290 : check e1211203181290 [[],[]] .chain = true := by decide
def e1211203181482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203181482 : Closed e1211203181482 ∧ code e1211203181482 = 5609249692586 := by decide
theorem cert_e1211203181482 : check e1211203181482 [[],[]] .chain = true := by decide
def e1211203181910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203181910 : Closed e1211203181910 ∧ code e1211203181910 = 5609249693014 := by decide
theorem cert_e1211203181910 : check e1211203181910 [[],[]] .chain = true := by decide
def e1211203181914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203181914 : Closed e1211203181914 ∧ code e1211203181914 = 5609249693018 := by decide
theorem cert_e1211203181914 : check e1211203181914 [[],[]] .chain = true := by decide
def e1211203181930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203181930 : Closed e1211203181930 ∧ code e1211203181930 = 5609249693034 := by decide
theorem cert_e1211203181930 : check e1211203181930 [[],[]] .chain = true := by decide
def e1211203181994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203181994 : Closed e1211203181994 ∧ code e1211203181994 = 5609249693098 := by decide
theorem cert_e1211203181994 : check e1211203181994 [[],[]] .chain = true := by decide
def e1211203185334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203185334 : Closed e1211203185334 ∧ code e1211203185334 = 5609249696438 := by decide
theorem cert_e1211203185334 : check e1211203185334 [[],[]] .chain = true := by decide
def e1211203185366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203185366 : Closed e1211203185366 ∧ code e1211203185366 = 5609249696470 := by decide
theorem cert_e1211203185366 : check e1211203185366 [[],[]] .chain = true := by decide
def e1211203185370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203185370 : Closed e1211203185370 ∧ code e1211203185370 = 5609249696474 := by decide
theorem cert_e1211203185370 : check e1211203185370 [[],[]] .chain = true := by decide
def e1211203185494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203185494 : Closed e1211203185494 ∧ code e1211203185494 = 5609249696598 := by decide
theorem cert_e1211203185494 : check e1211203185494 [[],[]] .chain = true := by decide
def e1211203185498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203185498 : Closed e1211203185498 ∧ code e1211203185498 = 5609249696602 := by decide
theorem cert_e1211203185498 : check e1211203185498 [[],[]] .chain = true := by decide
def e1211203185514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203185514 : Closed e1211203185514 ∧ code e1211203185514 = 5609249696618 := by decide
theorem cert_e1211203185514 : check e1211203185514 [[],[]] .chain = true := by decide
def e1211203186006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203186006 : Closed e1211203186006 ∧ code e1211203186006 = 5609249697110 := by decide
theorem cert_e1211203186006 : check e1211203186006 [[],[]] .chain = true := by decide
def e1211203186010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203186010 : Closed e1211203186010 ∧ code e1211203186010 = 5609249697114 := by decide
theorem cert_e1211203186010 : check e1211203186010 [[],[]] .chain = true := by decide
def e1211203186026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203186026 : Closed e1211203186026 ∧ code e1211203186026 = 5609249697130 := by decide
theorem cert_e1211203186026 : check e1211203186026 [[],[]] .chain = true := by decide
def e1211203186090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203186090 : Closed e1211203186090 ∧ code e1211203186090 = 5609249697194 := by decide
theorem cert_e1211203186090 : check e1211203186090 [[],[]] .chain = true := by decide
def e1211203193710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1211203193710 : Closed e1211203193710 ∧ code e1211203193710 = 5609249704814 := by decide
theorem cert_e1211203193710 : check e1211203193710 [[],[]] .chain = true := by decide
def e1211203193718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1211203193718 : Closed e1211203193718 ∧ code e1211203193718 = 5609249704822 := by decide
theorem cert_e1211203193718 : check e1211203193718 [[],[]] .chain = true := by decide
def e1211203193782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1211203193782 : Closed e1211203193782 ∧ code e1211203193782 = 5609249704886 := by decide
theorem cert_e1211203193782 : check e1211203193782 [[],[]] .chain = true := by decide
def e1211203194222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203194222 : Closed e1211203194222 ∧ code e1211203194222 = 5609249705326 := by decide
theorem cert_e1211203194222 : check e1211203194222 [[],[]] .chain = true := by decide
def e1211203194230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203194230 : Closed e1211203194230 ∧ code e1211203194230 = 5609249705334 := by decide
theorem cert_e1211203194230 : check e1211203194230 [[],[]] .chain = true := by decide
def e1211203194286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203194286 : Closed e1211203194286 ∧ code e1211203194286 = 5609249705390 := by decide
theorem cert_e1211203194286 : check e1211203194286 [[],[]] .chain = true := by decide
def e1211203194298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203194298 : Closed e1211203194298 ∧ code e1211203194298 = 5609249705402 := by decide
theorem cert_e1211203194298 : check e1211203194298 [[],[]] .chain = true := by decide
def e1211203194326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203194326 : Closed e1211203194326 ∧ code e1211203194326 = 5609249705430 := by decide
theorem cert_e1211203194326 : check e1211203194326 [[],[]] .chain = true := by decide
def e1211203194330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203194330 : Closed e1211203194330 ∧ code e1211203194330 = 5609249705434 := by decide
theorem cert_e1211203194330 : check e1211203194330 [[],[]] .chain = true := by decide
def e1211203199854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203199854 : Closed e1211203199854 ∧ code e1211203199854 = 5609249710958 := by decide
theorem cert_e1211203199854 : check e1211203199854 [[],[]] .chain = true := by decide
def e1211203199862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203199862 : Closed e1211203199862 ∧ code e1211203199862 = 5609249710966 := by decide
theorem cert_e1211203199862 : check e1211203199862 [[],[]] .chain = true := by decide
def e1211203199918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1211203199918 : Closed e1211203199918 ∧ code e1211203199918 = 5609249711022 := by decide
theorem cert_e1211203199918 : check e1211203199918 [[],[]] .chain = true := by decide
def e1211203199930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1211203199930 : Closed e1211203199930 ∧ code e1211203199930 = 5609249711034 := by decide
theorem cert_e1211203199930 : check e1211203199930 [[],[]] .chain = true := by decide
def e1211203199958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1211203199958 : Closed e1211203199958 ∧ code e1211203199958 = 5609249711062 := by decide
theorem cert_e1211203199958 : check e1211203199958 [[],[]] .chain = true := by decide
def e1211203199962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1211203199962 : Closed e1211203199962 ∧ code e1211203199962 = 5609249711066 := by decide
theorem cert_e1211203199962 : check e1211203199962 [[],[]] .chain = true := by decide
def e1211203201262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203201262 : Closed e1211203201262 ∧ code e1211203201262 = 5609249712366 := by decide
theorem cert_e1211203201262 : check e1211203201262 [[],[]] .chain = true := by decide
def e1211203201270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203201270 : Closed e1211203201270 ∧ code e1211203201270 = 5609249712374 := by decide
theorem cert_e1211203201270 : check e1211203201270 [[],[]] .chain = true := by decide
def e1211203201822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203201822 : Closed e1211203201822 ∧ code e1211203201822 = 5609249712926 := by decide
theorem cert_e1211203201822 : check e1211203201822 [[],[]] .chain = true := by decide
def e1211203201934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203201934 : Closed e1211203201934 ∧ code e1211203201934 = 5609249713038 := by decide
theorem cert_e1211203201934 : check e1211203201934 [[],[]] .chain = true := by decide
def e1211203202158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203202158 : Closed e1211203202158 ∧ code e1211203202158 = 5609249713262 := by decide
theorem cert_e1211203202158 : check e1211203202158 [[],[]] .chain = true := by decide
end Blc.Floor42
