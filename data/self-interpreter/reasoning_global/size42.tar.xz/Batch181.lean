import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203383510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203383510 : Closed e1211203383510 ∧ code e1211203383510 = 5609249894614 := by decide
theorem cert_e1211203383510 : check e1211203383510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203383606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203383606 : Closed e1211203383606 ∧ code e1211203383606 = 5609249894710 := by decide
theorem cert_e1211203383606 : check e1211203383606 [[],[]] .chain = true := by decide
def e1211203383610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203383610 : Closed e1211203383610 ∧ code e1211203383610 = 5609249894714 := by decide
theorem cert_e1211203383610 : check e1211203383610 [[],[]] .chain = true := by decide
def e1211203383694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203383694 : Closed e1211203383694 ∧ code e1211203383694 = 5609249894798 := by decide
theorem cert_e1211203383694 : check e1211203383694 [[],[]] .chain = true := by decide
def e1211203383750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203383750 : Closed e1211203383750 ∧ code e1211203383750 = 5609249894854 := by decide
theorem cert_e1211203383750 : check e1211203383750 [[],[]] .chain = true := by decide
def e1211203384086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203384086 : Closed e1211203384086 ∧ code e1211203384086 = 5609249895190 := by decide
theorem cert_e1211203384086 : check e1211203384086 [[],[]] .chain = true := by decide
def e1211203384162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203384162 : Closed e1211203384162 ∧ code e1211203384162 = 5609249895266 := by decide
theorem cert_e1211203384162 : check e1211203384162 [[],[]] .chain = true := by decide
def e1211203384174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203384174 : Closed e1211203384174 ∧ code e1211203384174 = 5609249895278 := by decide
theorem cert_e1211203384174 : check e1211203384174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203384182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203384182 : Closed e1211203384182 ∧ code e1211203384182 = 5609249895286 := by decide
theorem cert_e1211203384182 : check e1211203384182 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203384202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203384202 : Closed e1211203384202 ∧ code e1211203384202 = 5609249895306 := by decide
theorem cert_e1211203384202 : check e1211203384202 [[],[]] .chain = true := by decide
def e1211203384226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203384226 : Closed e1211203384226 ∧ code e1211203384226 = 5609249895330 := by decide
theorem cert_e1211203384226 : check e1211203384226 [[],[]] .chain = true := by decide
def e1211203384238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203384238 : Closed e1211203384238 ∧ code e1211203384238 = 5609249895342 := by decide
theorem cert_e1211203384238 : check e1211203384238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203384246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e1211203384246 : Closed e1211203384246 ∧ code e1211203384246 = 5609249895350 := by decide
theorem cert_e1211203384246 : check e1211203384246 [[],[]] .chain = true := by decide
def e1211203384250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203384250 : Closed e1211203384250 ∧ code e1211203384250 = 5609249895354 := by decide
theorem cert_e1211203384250 : check e1211203384250 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203384278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203384278 : Closed e1211203384278 ∧ code e1211203384278 = 5609249895382 := by decide
theorem cert_e1211203384278 : check e1211203384278 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203384282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203384282 : Closed e1211203384282 ∧ code e1211203384282 = 5609249895386 := by decide
theorem cert_e1211203384282 : check e1211203384282 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203384350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e1211203384350 : Closed e1211203384350 ∧ code e1211203384350 = 5609249895454 := by decide
theorem cert_e1211203384350 : check e1211203384350 [[],[]] .chain = true := by decide
def e1211203384546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203384546 : Closed e1211203384546 ∧ code e1211203384546 = 5609249895650 := by decide
theorem cert_e1211203384546 : check e1211203384546 [[],[]] .chain = true := by decide
def e1211203384558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203384558 : Closed e1211203384558 ∧ code e1211203384558 = 5609249895662 := by decide
theorem cert_e1211203384558 : check e1211203384558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203384566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203384566 : Closed e1211203384566 ∧ code e1211203384566 = 5609249895670 := by decide
def e1211203384846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203384846 : Closed e1211203384846 ∧ code e1211203384846 = 5609249895950 := by decide
theorem cert_e1211203384846 : check e1211203384846 [[],[]] .chain = true := by decide
def e1211203384858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203384858 : Closed e1211203384858 ∧ code e1211203384858 = 5609249895962 := by decide
theorem cert_e1211203384858 : check e1211203384858 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203384930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203384930 : Closed e1211203384930 ∧ code e1211203384930 = 5609249896034 := by decide
theorem cert_e1211203384930 : check e1211203384930 [[],[]] .chain = true := by decide
def e1211203384942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203384942 : Closed e1211203384942 ∧ code e1211203384942 = 5609249896046 := by decide
theorem cert_e1211203384942 : check e1211203384942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203384950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203384950 : Closed e1211203384950 ∧ code e1211203384950 = 5609249896054 := by decide
theorem cert_e1211203384950 : check e1211203384950 [[],[]] .chain = true := by decide
def e1211203384954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203384954 : Closed e1211203384954 ∧ code e1211203384954 = 5609249896058 := by decide
theorem cert_e1211203384954 : check e1211203384954 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203385142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203385142 : Closed e1211203385142 ∧ code e1211203385142 = 5609249896246 := by decide
theorem cert_e1211203385142 : check e1211203385142 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203385146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203385146 : Closed e1211203385146 ∧ code e1211203385146 = 5609249896250 := by decide
theorem cert_e1211203385146 : check e1211203385146 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203414894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203414894 : Closed e1211203414894 ∧ code e1211203414894 = 5609249925998 := by decide
theorem cert_e1211203414894 : check e1211203414894 [[],[]] .chain = true := by decide
def e1211203414902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203414902 : Closed e1211203414902 ∧ code e1211203414902 = 5609249926006 := by decide
theorem cert_e1211203414902 : check e1211203414902 [[],[]] .chain = true := by decide
def e1211203414966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1211203414966 : Closed e1211203414966 ∧ code e1211203414966 = 5609249926070 := by decide
theorem cert_e1211203414966 : check e1211203414966 [[],[]] .chain = true := by decide
def e1211203415406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203415406 : Closed e1211203415406 ∧ code e1211203415406 = 5609249926510 := by decide
theorem cert_e1211203415406 : check e1211203415406 [[],[]] .chain = true := by decide
def e1211203415414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203415414 : Closed e1211203415414 ∧ code e1211203415414 = 5609249926518 := by decide
theorem cert_e1211203415414 : check e1211203415414 [[],[]] .chain = true := by decide
def e1211203415470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203415470 : Closed e1211203415470 ∧ code e1211203415470 = 5609249926574 := by decide
theorem cert_e1211203415470 : check e1211203415470 [[],[]] .chain = true := by decide
def e1211203415482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203415482 : Closed e1211203415482 ∧ code e1211203415482 = 5609249926586 := by decide
theorem cert_e1211203415482 : check e1211203415482 [[],[]] .chain = true := by decide
def e1211203415510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203415510 : Closed e1211203415510 ∧ code e1211203415510 = 5609249926614 := by decide
theorem cert_e1211203415510 : check e1211203415510 [[],[]] .chain = true := by decide
def e1211203415514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203415514 : Closed e1211203415514 ∧ code e1211203415514 = 5609249926618 := by decide
theorem cert_e1211203415514 : check e1211203415514 [[],[]] .chain = true := by decide
def e1211203415734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203415734 : Closed e1211203415734 ∧ code e1211203415734 = 5609249926838 := by decide
theorem cert_e1211203415734 : check e1211203415734 [[],[]] .chain = true := by decide
def e1211203415766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203415766 : Closed e1211203415766 ∧ code e1211203415766 = 5609249926870 := by decide
theorem cert_e1211203415766 : check e1211203415766 [[],[]] .chain = true := by decide
def e1211203415770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203415770 : Closed e1211203415770 ∧ code e1211203415770 = 5609249926874 := by decide
theorem cert_e1211203415770 : check e1211203415770 [[],[]] .chain = true := by decide
def e1211203417454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203417454 : Closed e1211203417454 ∧ code e1211203417454 = 5609249928558 := by decide
theorem cert_e1211203417454 : check e1211203417454 [[],[]] .chain = true := by decide
def e1211203417462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203417462 : Closed e1211203417462 ∧ code e1211203417462 = 5609249928566 := by decide
theorem cert_e1211203417462 : check e1211203417462 [[],[]] .chain = true := by decide
def e1211203417518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203417518 : Closed e1211203417518 ∧ code e1211203417518 = 5609249928622 := by decide
theorem cert_e1211203417518 : check e1211203417518 [[],[]] .chain = true := by decide
def e1211203417530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203417530 : Closed e1211203417530 ∧ code e1211203417530 = 5609249928634 := by decide
theorem cert_e1211203417530 : check e1211203417530 [[],[]] .chain = true := by decide
def e1211203417558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203417558 : Closed e1211203417558 ∧ code e1211203417558 = 5609249928662 := by decide
theorem cert_e1211203417558 : check e1211203417558 [[],[]] .chain = true := by decide
def e1211203417562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203417562 : Closed e1211203417562 ∧ code e1211203417562 = 5609249928666 := by decide
theorem cert_e1211203417562 : check e1211203417562 [[],[]] .chain = true := by decide
def e1211203417774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203417774 : Closed e1211203417774 ∧ code e1211203417774 = 5609249928878 := by decide
theorem cert_e1211203417774 : check e1211203417774 [[],[]] .chain = true := by decide
def e1211203417786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203417786 : Closed e1211203417786 ∧ code e1211203417786 = 5609249928890 := by decide
theorem cert_e1211203417786 : check e1211203417786 [[],[]] .chain = true := by decide
def e1211203417834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203417834 : Closed e1211203417834 ∧ code e1211203417834 = 5609249928938 := by decide
theorem cert_e1211203417834 : check e1211203417834 [[],[]] .chain = true := by decide
def e1211203417942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203417942 : Closed e1211203417942 ∧ code e1211203417942 = 5609249929046 := by decide
theorem cert_e1211203417942 : check e1211203417942 [[],[]] .chain = true := by decide
def e1211203417946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203417946 : Closed e1211203417946 ∧ code e1211203417946 = 5609249929050 := by decide
theorem cert_e1211203417946 : check e1211203417946 [[],[]] .chain = true := by decide
def e1211203417962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203417962 : Closed e1211203417962 ∧ code e1211203417962 = 5609249929066 := by decide
theorem cert_e1211203417962 : check e1211203417962 [[],[]] .chain = true := by decide
def e1211203418806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203418806 : Closed e1211203418806 ∧ code e1211203418806 = 5609249929910 := by decide
theorem cert_e1211203418806 : check e1211203418806 [[],[]] .chain = true := by decide
def e1211203418838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203418838 : Closed e1211203418838 ∧ code e1211203418838 = 5609249929942 := by decide
theorem cert_e1211203418838 : check e1211203418838 [[],[]] .chain = true := by decide
def e1211203418842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203418842 : Closed e1211203418842 ∧ code e1211203418842 = 5609249929946 := by decide
theorem cert_e1211203418842 : check e1211203418842 [[],[]] .chain = true := by decide
def e1211203418966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203418966 : Closed e1211203418966 ∧ code e1211203418966 = 5609249930070 := by decide
theorem cert_e1211203418966 : check e1211203418966 [[],[]] .chain = true := by decide
def e1211203418970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203418970 : Closed e1211203418970 ∧ code e1211203418970 = 5609249930074 := by decide
theorem cert_e1211203418970 : check e1211203418970 [[],[]] .chain = true := by decide
def e1211203418986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203418986 : Closed e1211203418986 ∧ code e1211203418986 = 5609249930090 := by decide
theorem cert_e1211203418986 : check e1211203418986 [[],[]] .chain = true := by decide
def e1211203421038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e1211203421038 : Closed e1211203421038 ∧ code e1211203421038 = 5609249932142 := by decide
theorem cert_e1211203421038 : check e1211203421038 [[],[]] .chain = true := by decide
def e1211203421046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e1211203421046 : Closed e1211203421046 ∧ code e1211203421046 = 5609249932150 := by decide
theorem cert_e1211203421046 : check e1211203421046 [[],[]] .chain = true := by decide
def e1211203422446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203422446 : Closed e1211203422446 ∧ code e1211203422446 = 5609249933550 := by decide
theorem cert_e1211203422446 : check e1211203422446 [[],[]] .chain = true := by decide
def e1211203422454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203422454 : Closed e1211203422454 ∧ code e1211203422454 = 5609249933558 := by decide
theorem cert_e1211203422454 : check e1211203422454 [[],[]] .chain = true := by decide
def e1211203423006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203423006 : Closed e1211203423006 ∧ code e1211203423006 = 5609249934110 := by decide
theorem cert_e1211203423006 : check e1211203423006 [[],[]] .chain = true := by decide
def e1211203423118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203423118 : Closed e1211203423118 ∧ code e1211203423118 = 5609249934222 := by decide
theorem cert_e1211203423118 : check e1211203423118 [[],[]] .chain = true := by decide
def e1211203423790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203423790 : Closed e1211203423790 ∧ code e1211203423790 = 5609249934894 := by decide
theorem cert_e1211203423790 : check e1211203423790 [[],[]] .chain = true := by decide
def e1211203423970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203423970 : Closed e1211203423970 ∧ code e1211203423970 = 5609249935074 := by decide
theorem cert_e1211203423970 : check e1211203423970 [[],[]] .chain = true := by decide
def e1211203423982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e1211203423982 : Closed e1211203423982 ∧ code e1211203423982 = 5609249935086 := by decide
theorem cert_e1211203423982 : check e1211203423982 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203424022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203424022 : Closed e1211203424022 ∧ code e1211203424022 = 5609249935126 := by decide
theorem cert_e1211203424022 : check e1211203424022 [[],[]] .chain = true := by decide
def e1211203424098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203424098 : Closed e1211203424098 ∧ code e1211203424098 = 5609249935202 := by decide
theorem cert_e1211203424098 : check e1211203424098 [[],[]] .chain = true := by decide
def e1211203424110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e1211203424110 : Closed e1211203424110 ∧ code e1211203424110 = 5609249935214 := by decide
theorem cert_e1211203424110 : check e1211203424110 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203424118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e1211203424118 : Closed e1211203424118 ∧ code e1211203424118 = 5609249935222 := by decide
theorem cert_e1211203424118 : check e1211203424118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203427182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203427182 : Closed e1211203427182 ∧ code e1211203427182 = 5609249938286 := by decide
theorem cert_e1211203427182 : check e1211203427182 [[],[]] .chain = true := by decide
def e1211203427190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203427190 : Closed e1211203427190 ∧ code e1211203427190 = 5609249938294 := by decide
theorem cert_e1211203427190 : check e1211203427190 [[],[]] .chain = true := by decide
def e1211203427254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e1211203427254 : Closed e1211203427254 ∧ code e1211203427254 = 5609249938358 := by decide
theorem cert_e1211203427254 : check e1211203427254 [[],[]] .chain = true := by decide
def e1211203427694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203427694 : Closed e1211203427694 ∧ code e1211203427694 = 5609249938798 := by decide
theorem cert_e1211203427694 : check e1211203427694 [[],[]] .chain = true := by decide
def e1211203427702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203427702 : Closed e1211203427702 ∧ code e1211203427702 = 5609249938806 := by decide
theorem cert_e1211203427702 : check e1211203427702 [[],[]] .chain = true := by decide
def e1211203427758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203427758 : Closed e1211203427758 ∧ code e1211203427758 = 5609249938862 := by decide
theorem cert_e1211203427758 : check e1211203427758 [[],[]] .chain = true := by decide
def e1211203427770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203427770 : Closed e1211203427770 ∧ code e1211203427770 = 5609249938874 := by decide
theorem cert_e1211203427770 : check e1211203427770 [[],[]] .chain = true := by decide
def e1211203427798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203427798 : Closed e1211203427798 ∧ code e1211203427798 = 5609249938902 := by decide
theorem cert_e1211203427798 : check e1211203427798 [[],[]] .chain = true := by decide
def e1211203427802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203427802 : Closed e1211203427802 ∧ code e1211203427802 = 5609249938906 := by decide
theorem cert_e1211203427802 : check e1211203427802 [[],[]] .chain = true := by decide
def e1211203428022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e1211203428022 : Closed e1211203428022 ∧ code e1211203428022 = 5609249939126 := by decide
theorem cert_e1211203428022 : check e1211203428022 [[],[]] .chain = true := by decide
def e1211203428054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203428054 : Closed e1211203428054 ∧ code e1211203428054 = 5609249939158 := by decide
theorem cert_e1211203428054 : check e1211203428054 [[],[]] .chain = true := by decide
def e1211203428058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203428058 : Closed e1211203428058 ∧ code e1211203428058 = 5609249939162 := by decide
theorem cert_e1211203428058 : check e1211203428058 [[],[]] .chain = true := by decide
def e1211203430254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1211203430254 : Closed e1211203430254 ∧ code e1211203430254 = 5609249941358 := by decide
theorem cert_e1211203430254 : check e1211203430254 [[],[]] .chain = true := by decide
def e1211203430262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1211203430262 : Closed e1211203430262 ∧ code e1211203430262 = 5609249941366 := by decide
theorem cert_e1211203430262 : check e1211203430262 [[],[]] .chain = true := by decide
def e1211203430326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1211203430326 : Closed e1211203430326 ∧ code e1211203430326 = 5609249941430 := by decide
theorem cert_e1211203430326 : check e1211203430326 [[],[]] .chain = true := by decide
def e1211203431662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203431662 : Closed e1211203431662 ∧ code e1211203431662 = 5609249942766 := by decide
theorem cert_e1211203431662 : check e1211203431662 [[],[]] .chain = true := by decide
def e1211203431670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203431670 : Closed e1211203431670 ∧ code e1211203431670 = 5609249942774 := by decide
theorem cert_e1211203431670 : check e1211203431670 [[],[]] .chain = true := by decide
def e1211203432054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203432054 : Closed e1211203432054 ∧ code e1211203432054 = 5609249943158 := by decide
theorem cert_e1211203432054 : check e1211203432054 [[],[]] .chain = true := by decide
def e1211203432558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203432558 : Closed e1211203432558 ∧ code e1211203432558 = 5609249943662 := by decide
theorem cert_e1211203432558 : check e1211203432558 [[],[]] .chain = true := by decide
def e1211203432734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203432734 : Closed e1211203432734 ∧ code e1211203432734 = 5609249943838 := by decide
theorem cert_e1211203432734 : check e1211203432734 [[],[]] .chain = true := by decide
def e1211203432930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203432930 : Closed e1211203432930 ∧ code e1211203432930 = 5609249944034 := by decide
theorem cert_e1211203432930 : check e1211203432930 [[],[]] .chain = true := by decide
def e1211203432942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203432942 : Closed e1211203432942 ∧ code e1211203432942 = 5609249944046 := by decide
theorem cert_e1211203432942 : check e1211203432942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203433326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203433326 : Closed e1211203433326 ∧ code e1211203433326 = 5609249944430 := by decide
theorem cert_e1211203433326 : check e1211203433326 [[],[]] .chain = true := by decide
def e1211203433334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203433334 : Closed e1211203433334 ∧ code e1211203433334 = 5609249944438 := by decide
theorem cert_e1211203433334 : check e1211203433334 [[],[]] .chain = true := by decide
def e1211203433390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203433390 : Closed e1211203433390 ∧ code e1211203433390 = 5609249944494 := by decide
theorem cert_e1211203433390 : check e1211203433390 [[],[]] .chain = true := by decide
def e1211203433402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203433402 : Closed e1211203433402 ∧ code e1211203433402 = 5609249944506 := by decide
theorem cert_e1211203433402 : check e1211203433402 [[],[]] .chain = true := by decide
def e1211203433430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203433430 : Closed e1211203433430 ∧ code e1211203433430 = 5609249944534 := by decide
theorem cert_e1211203433430 : check e1211203433430 [[],[]] .chain = true := by decide
def e1211203433434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203433434 : Closed e1211203433434 ∧ code e1211203433434 = 5609249944538 := by decide
theorem cert_e1211203433434 : check e1211203433434 [[],[]] .chain = true := by decide
def e1211203433710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203433710 : Closed e1211203433710 ∧ code e1211203433710 = 5609249944814 := by decide
theorem cert_e1211203433710 : check e1211203433710 [[],[]] .chain = true := by decide
def e1211203433718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203433718 : Closed e1211203433718 ∧ code e1211203433718 = 5609249944822 := by decide
theorem cert_e1211203433718 : check e1211203433718 [[],[]] .chain = true := by decide
def e1211203434094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203434094 : Closed e1211203434094 ∧ code e1211203434094 = 5609249945198 := by decide
theorem cert_e1211203434094 : check e1211203434094 [[],[]] .chain = true := by decide
def e1211203434106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203434106 : Closed e1211203434106 ∧ code e1211203434106 = 5609249945210 := by decide
theorem cert_e1211203434106 : check e1211203434106 [[],[]] .chain = true := by decide
def e1211203434246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203434246 : Closed e1211203434246 ∧ code e1211203434246 = 5609249945350 := by decide
theorem cert_e1211203434246 : check e1211203434246 [[],[]] .chain = true := by decide
def e1211203434270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203434270 : Closed e1211203434270 ∧ code e1211203434270 = 5609249945374 := by decide
theorem cert_e1211203434270 : check e1211203434270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203434294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203434294 : Closed e1211203434294 ∧ code e1211203434294 = 5609249945398 := by decide
theorem cert_e1211203434294 : check e1211203434294 [[],[]] .chain = true := by decide
def e1211203434298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203434298 : Closed e1211203434298 ∧ code e1211203434298 = 5609249945402 := by decide
theorem cert_e1211203434298 : check e1211203434298 [[],[]] .chain = true := by decide
def e1211203434550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203434550 : Closed e1211203434550 ∧ code e1211203434550 = 5609249945654 := by decide
theorem cert_e1211203434550 : check e1211203434550 [[],[]] .chain = true := by decide
def e1211203434638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203434638 : Closed e1211203434638 ∧ code e1211203434638 = 5609249945742 := by decide
theorem cert_e1211203434638 : check e1211203434638 [[],[]] .chain = true := by decide
def e1211203434722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203434722 : Closed e1211203434722 ∧ code e1211203434722 = 5609249945826 := by decide
theorem cert_e1211203434722 : check e1211203434722 [[],[]] .chain = true := by decide
def e1211203434734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203434734 : Closed e1211203434734 ∧ code e1211203434734 = 5609249945838 := by decide
theorem cert_e1211203434734 : check e1211203434734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203434742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203434742 : Closed e1211203434742 ∧ code e1211203434742 = 5609249945846 := by decide
theorem cert_e1211203434742 : checkPay e1211203434742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211203434934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203434934 : Closed e1211203434934 ∧ code e1211203434934 = 5609249946038 := by decide
theorem cert_e1211203434934 : check e1211203434934 [[],[]] .chain = true := by decide
def e1211203434966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203434966 : Closed e1211203434966 ∧ code e1211203434966 = 5609249946070 := by decide
theorem cert_e1211203434966 : check e1211203434966 [[],[]] .chain = true := by decide
def e1211203434970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203434970 : Closed e1211203434970 ∧ code e1211203434970 = 5609249946074 := by decide
theorem cert_e1211203434970 : check e1211203434970 [[],[]] .chain = true := by decide
def e1211203435126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203435126 : Closed e1211203435126 ∧ code e1211203435126 = 5609249946230 := by decide
theorem cert_e1211203435126 : check e1211203435126 [[],[]] .chain = true := by decide
def e1211203435270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203435270 : Closed e1211203435270 ∧ code e1211203435270 = 5609249946374 := by decide
theorem cert_e1211203435270 : check e1211203435270 [[],[]] .chain = true := by decide
def e1211203435294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203435294 : Closed e1211203435294 ∧ code e1211203435294 = 5609249946398 := by decide
theorem cert_e1211203435294 : check e1211203435294 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203435318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203435318 : Closed e1211203435318 ∧ code e1211203435318 = 5609249946422 := by decide
theorem cert_e1211203435318 : check e1211203435318 [[],[]] .chain = true := by decide
def e1211203435322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203435322 : Closed e1211203435322 ∧ code e1211203435322 = 5609249946426 := by decide
theorem cert_e1211203435322 : check e1211203435322 [[],[]] .chain = true := by decide
def e1211203435406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203435406 : Closed e1211203435406 ∧ code e1211203435406 = 5609249946510 := by decide
theorem cert_e1211203435406 : check e1211203435406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203436910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e1211203436910 : Closed e1211203436910 ∧ code e1211203436910 = 5609249948014 := by decide
theorem cert_e1211203436910 : check e1211203436910 [[],[]] .chain = true := by decide
def e1211203436918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e1211203436918 : Closed e1211203436918 ∧ code e1211203436918 = 5609249948022 := by decide
theorem cert_e1211203436918 : check e1211203436918 [[],[]] .chain = true := by decide
def e1211203436974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e1211203436974 : Closed e1211203436974 ∧ code e1211203436974 = 5609249948078 := by decide
theorem cert_e1211203436974 : check e1211203436974 [[],[]] .chain = true := by decide
def e1211203436986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e1211203436986 : Closed e1211203436986 ∧ code e1211203436986 = 5609249948090 := by decide
theorem cert_e1211203436986 : check e1211203436986 [[],[]] .chain = true := by decide
def e1211203437678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203437678 : Closed e1211203437678 ∧ code e1211203437678 = 5609249948782 := by decide
theorem cert_e1211203437678 : check e1211203437678 [[],[]] .chain = true := by decide
def e1211203437690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203437690 : Closed e1211203437690 ∧ code e1211203437690 = 5609249948794 := by decide
theorem cert_e1211203437690 : check e1211203437690 [[],[]] .chain = true := by decide
def e1211203437854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203437854 : Closed e1211203437854 ∧ code e1211203437854 = 5609249948958 := by decide
theorem cert_e1211203437854 : check e1211203437854 [[],[]] .chain = true := by decide
def e1211203438022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203438022 : Closed e1211203438022 ∧ code e1211203438022 = 5609249949126 := by decide
theorem cert_e1211203438022 : check e1211203438022 [[],[]] .chain = true := by decide
def e1211203438126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203438126 : Closed e1211203438126 ∧ code e1211203438126 = 5609249949230 := by decide
theorem cert_e1211203438126 : check e1211203438126 [[],[]] .chain = true := by decide
def e1211203438306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203438306 : Closed e1211203438306 ∧ code e1211203438306 = 5609249949410 := by decide
theorem cert_e1211203438306 : check e1211203438306 [[],[]] .chain = true := by decide
def e1211203438318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e1211203438318 : Closed e1211203438318 ∧ code e1211203438318 = 5609249949422 := by decide
theorem cert_e1211203438318 : check e1211203438318 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203438446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e1211203438446 : Closed e1211203438446 ∧ code e1211203438446 = 5609249949550 := by decide
theorem cert_e1211203438446 : check e1211203438446 [[],[]] .chain = true := by decide
def e1211203438454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e1211203438454 : Closed e1211203438454 ∧ code e1211203438454 = 5609249949558 := by decide
theorem cert_e1211203438454 : check e1211203438454 [[],[]] .chain = true := by decide
def e1211203438474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203438474 : Closed e1211203438474 ∧ code e1211203438474 = 5609249949578 := by decide
theorem cert_e1211203438474 : check e1211203438474 [[],[]] .chain = true := by decide
def e1211203438498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203438498 : Closed e1211203438498 ∧ code e1211203438498 = 5609249949602 := by decide
theorem cert_e1211203438498 : check e1211203438498 [[],[]] .chain = true := by decide
def e1211203438510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e1211203438510 : Closed e1211203438510 ∧ code e1211203438510 = 5609249949614 := by decide
theorem cert_e1211203438510 : check e1211203438510 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203438518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e1211203438518 : Closed e1211203438518 ∧ code e1211203438518 = 5609249949622 := by decide
theorem cert_e1211203438518 : check e1211203438518 [[],[]] .chain = true := by decide
def e1211203438522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e1211203438522 : Closed e1211203438522 ∧ code e1211203438522 = 5609249949626 := by decide
theorem cert_e1211203438522 : check e1211203438522 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203439982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203439982 : Closed e1211203439982 ∧ code e1211203439982 = 5609249951086 := by decide
theorem cert_e1211203439982 : check e1211203439982 [[],[]] .chain = true := by decide
def e1211203439990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203439990 : Closed e1211203439990 ∧ code e1211203439990 = 5609249951094 := by decide
theorem cert_e1211203439990 : check e1211203439990 [[],[]] .chain = true := by decide
def e1211203440046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203440046 : Closed e1211203440046 ∧ code e1211203440046 = 5609249951150 := by decide
theorem cert_e1211203440046 : check e1211203440046 [[],[]] .chain = true := by decide
def e1211203440058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203440058 : Closed e1211203440058 ∧ code e1211203440058 = 5609249951162 := by decide
theorem cert_e1211203440058 : check e1211203440058 [[],[]] .chain = true := by decide
def e1211203440086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203440086 : Closed e1211203440086 ∧ code e1211203440086 = 5609249951190 := by decide
theorem cert_e1211203440086 : check e1211203440086 [[],[]] .chain = true := by decide
def e1211203440090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203440090 : Closed e1211203440090 ∧ code e1211203440090 = 5609249951194 := by decide
theorem cert_e1211203440090 : check e1211203440090 [[],[]] .chain = true := by decide
def e1211203440302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203440302 : Closed e1211203440302 ∧ code e1211203440302 = 5609249951406 := by decide
theorem cert_e1211203440302 : check e1211203440302 [[],[]] .chain = true := by decide
def e1211203440314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203440314 : Closed e1211203440314 ∧ code e1211203440314 = 5609249951418 := by decide
theorem cert_e1211203440314 : check e1211203440314 [[],[]] .chain = true := by decide
def e1211203440362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203440362 : Closed e1211203440362 ∧ code e1211203440362 = 5609249951466 := by decide
theorem cert_e1211203440362 : check e1211203440362 [[],[]] .chain = true := by decide
def e1211203440470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203440470 : Closed e1211203440470 ∧ code e1211203440470 = 5609249951574 := by decide
theorem cert_e1211203440470 : check e1211203440470 [[],[]] .chain = true := by decide
def e1211203440474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203440474 : Closed e1211203440474 ∧ code e1211203440474 = 5609249951578 := by decide
theorem cert_e1211203440474 : check e1211203440474 [[],[]] .chain = true := by decide
def e1211203440490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203440490 : Closed e1211203440490 ∧ code e1211203440490 = 5609249951594 := by decide
theorem cert_e1211203440490 : check e1211203440490 [[],[]] .chain = true := by decide
def e1211203440750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203440750 : Closed e1211203440750 ∧ code e1211203440750 = 5609249951854 := by decide
theorem cert_e1211203440750 : check e1211203440750 [[],[]] .chain = true := by decide
def e1211203440926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203440926 : Closed e1211203440926 ∧ code e1211203440926 = 5609249952030 := by decide
theorem cert_e1211203440926 : check e1211203440926 [[],[]] .chain = true := by decide
def e1211203441122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203441122 : Closed e1211203441122 ∧ code e1211203441122 = 5609249952226 := by decide
theorem cert_e1211203441122 : check e1211203441122 [[],[]] .chain = true := by decide
def e1211203441134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203441134 : Closed e1211203441134 ∧ code e1211203441134 = 5609249952238 := by decide
theorem cert_e1211203441134 : check e1211203441134 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203441518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203441518 : Closed e1211203441518 ∧ code e1211203441518 = 5609249952622 := by decide
theorem cert_e1211203441518 : check e1211203441518 [[],[]] .chain = true := by decide
def e1211203441526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203441526 : Closed e1211203441526 ∧ code e1211203441526 = 5609249952630 := by decide
theorem cert_e1211203441526 : check e1211203441526 [[],[]] .chain = true := by decide
def e1211203441582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203441582 : Closed e1211203441582 ∧ code e1211203441582 = 5609249952686 := by decide
theorem cert_e1211203441582 : check e1211203441582 [[],[]] .chain = true := by decide
def e1211203441594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203441594 : Closed e1211203441594 ∧ code e1211203441594 = 5609249952698 := by decide
theorem cert_e1211203441594 : check e1211203441594 [[],[]] .chain = true := by decide
def e1211203441622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203441622 : Closed e1211203441622 ∧ code e1211203441622 = 5609249952726 := by decide
theorem cert_e1211203441622 : check e1211203441622 [[],[]] .chain = true := by decide
end Blc.Floor42
