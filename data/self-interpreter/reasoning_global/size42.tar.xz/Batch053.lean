import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1130482464366 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130482464366 : Closed e1130482464366 ∧ code e1130482464366 = 5528528975470 := by decide
theorem cert_e1130482464366 : check e1130482464366 [[],[.under]] .three = true := by decide
def e1130482464378 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130482464378 : Closed e1130482464378 ∧ code e1130482464378 = 5528528975482 := by decide
theorem cert_e1130482464378 : check e1130482464378 [[],[.under]] .three = true := by decide
def e1130482464566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130482464566 : Closed e1130482464566 ∧ code e1130482464566 = 5528528975670 := by decide
theorem cert_e1130482464566 : check e1130482464566 [[],[.under]] .three = true := by decide
def e1130482464570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130482464570 : Closed e1130482464570 ∧ code e1130482464570 = 5528528975674 := by decide
theorem cert_e1130482464570 : check e1130482464570 [[],[.under]] .three = true := by decide
def e1130482465206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1130482465206 : Closed e1130482465206 ∧ code e1130482465206 = 5528528976310 := by decide
theorem cert_e1130482465206 : check e1130482465206 [[],[.under]] .three = true := by decide
def e1130482465238 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1130482465238 : Closed e1130482465238 ∧ code e1130482465238 = 5528528976342 := by decide
theorem cert_e1130482465238 : check e1130482465238 [[],[.under]] .three = true := by decide
def e1130482465242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1130482465242 : Closed e1130482465242 ∧ code e1130482465242 = 5528528976346 := by decide
theorem cert_e1130482465242 : check e1130482465242 [[],[.under]] .three = true := by decide
def e1130482465398 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1130482465398 : Closed e1130482465398 ∧ code e1130482465398 = 5528528976502 := by decide
theorem cert_e1130482465398 : check e1130482465398 [[],[.under]] .three = true := by decide
def e1130482465590 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130482465590 : Closed e1130482465590 ∧ code e1130482465590 = 5528528976694 := by decide
theorem cert_e1130482465590 : check e1130482465590 [[],[.under]] .three = true := by decide
def e1130482465594 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130482465594 : Closed e1130482465594 ∧ code e1130482465594 = 5528528976698 := by decide
theorem cert_e1130482465594 : check e1130482465594 [[],[.under]] .three = true := by decide
def e1130482472814 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1130482472814 : Closed e1130482472814 ∧ code e1130482472814 = 5528528983918 := by decide
theorem cert_e1130482472814 : check e1130482472814 [[],[.under]] .three = true := by decide
def e1130482472822 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1130482472822 : Closed e1130482472822 ∧ code e1130482472822 = 5528528983926 := by decide
theorem cert_e1130482472822 : check e1130482472822 [[],[.under]] .three = true := by decide
def e1130482472886 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1130482472886 : Closed e1130482472886 ∧ code e1130482472886 = 5528528983990 := by decide
theorem cert_e1130482472886 : check e1130482472886 [[],[.under]] .three = true := by decide
def e1130482474222 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1130482474222 : Closed e1130482474222 ∧ code e1130482474222 = 5528528985326 := by decide
theorem cert_e1130482474222 : check e1130482474222 [[],[.under]] .three = true := by decide
def e1130482474230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1130482474230 : Closed e1130482474230 ∧ code e1130482474230 = 5528528985334 := by decide
theorem cert_e1130482474230 : check e1130482474230 [[],[.under]] .three = true := by decide
def e1130482474614 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1130482474614 : Closed e1130482474614 ∧ code e1130482474614 = 5528528985718 := by decide
theorem cert_e1130482474614 : check e1130482474614 [[],[.under]] .three = true := by decide
def e1130482486126 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130482486126 : Closed e1130482486126 ∧ code e1130482486126 = 5528528997230 := by decide
theorem cert_e1130482486126 : check e1130482486126 [[],[.under]] .three = true := by decide
def e1130482486134 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130482486134 : Closed e1130482486134 ∧ code e1130482486134 = 5528528997238 := by decide
theorem cert_e1130482486134 : check e1130482486134 [[],[.under]] .three = true := by decide
def e1130482486190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130482486190 : Closed e1130482486190 ∧ code e1130482486190 = 5528528997294 := by decide
theorem cert_e1130482486190 : check e1130482486190 [[],[.under]] .three = true := by decide
def e1130482486202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130482486202 : Closed e1130482486202 ∧ code e1130482486202 = 5528528997306 := by decide
theorem cert_e1130482486202 : check e1130482486202 [[],[.under]] .three = true := by decide
def e1130482486230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130482486230 : Closed e1130482486230 ∧ code e1130482486230 = 5528528997334 := by decide
theorem cert_e1130482486230 : check e1130482486230 [[],[.under]] .three = true := by decide
def e1130482486234 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130482486234 : Closed e1130482486234 ∧ code e1130482486234 = 5528528997338 := by decide
theorem cert_e1130482486234 : check e1130482486234 [[],[.under]] .three = true := by decide
def e1130482486510 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130482486510 : Closed e1130482486510 ∧ code e1130482486510 = 5528528997614 := by decide
theorem cert_e1130482486510 : check e1130482486510 [[],[.under]] .three = true := by decide
def e1130482486518 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130482486518 : Closed e1130482486518 ∧ code e1130482486518 = 5528528997622 := by decide
theorem cert_e1130482486518 : check e1130482486518 [[],[.under]] .three = true := by decide
def e1130482486894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130482486894 : Closed e1130482486894 ∧ code e1130482486894 = 5528528997998 := by decide
theorem cert_e1130482486894 : check e1130482486894 [[],[.under]] .three = true := by decide
def e1130482486906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130482486906 : Closed e1130482486906 ∧ code e1130482486906 = 5528528998010 := by decide
theorem cert_e1130482486906 : check e1130482486906 [[],[.under]] .three = true := by decide
def e1130482487094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130482487094 : Closed e1130482487094 ∧ code e1130482487094 = 5528528998198 := by decide
theorem cert_e1130482487094 : check e1130482487094 [[],[.under]] .three = true := by decide
def e1130482487098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130482487098 : Closed e1130482487098 ∧ code e1130482487098 = 5528528998202 := by decide
theorem cert_e1130482487098 : check e1130482487098 [[],[.under]] .three = true := by decide
def e1130482492854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1130482492854 : Closed e1130482492854 ∧ code e1130482492854 = 5528529003958 := by decide
theorem cert_e1130482492854 : check e1130482492854 [[],[.under]] .three = true := by decide
def e1130482492886 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1130482492886 : Closed e1130482492886 ∧ code e1130482492886 = 5528529003990 := by decide
theorem cert_e1130482492886 : check e1130482492886 [[],[.under]] .three = true := by decide
def e1130482492890 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1130482492890 : Closed e1130482492890 ∧ code e1130482492890 = 5528529003994 := by decide
theorem cert_e1130482492890 : check e1130482492890 [[],[.under]] .three = true := by decide
def e1130482493046 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1130482493046 : Closed e1130482493046 ∧ code e1130482493046 = 5528529004150 := by decide
theorem cert_e1130482493046 : check e1130482493046 [[],[.under]] .three = true := by decide
def e1130482493238 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1130482493238 : Closed e1130482493238 ∧ code e1130482493238 = 5528529004342 := by decide
theorem cert_e1130482493238 : check e1130482493238 [[],[.under]] .three = true := by decide
def e1130482493242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1130482493242 : Closed e1130482493242 ∧ code e1130482493242 = 5528529004346 := by decide
theorem cert_e1130482493242 : check e1130482493242 [[],[.under]] .three = true := by decide
def e1130482830190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130482830190 : Closed e1130482830190 ∧ code e1130482830190 = 5528529341294 := by decide
theorem cert_e1130482830190 : checkPay e1130482830190 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130482830198 : Closed e1130482830198 ∧ code e1130482830198 = 5528529341302 := by decide
theorem cert_e1130482830198 : checkPay e1130482830198 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130482830254 : Closed e1130482830254 ∧ code e1130482830254 = 5528529341358 := by decide
theorem cert_e1130482830254 : checkPay e1130482830254 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130482830266 : Closed e1130482830266 ∧ code e1130482830266 = 5528529341370 := by decide
theorem cert_e1130482830266 : checkPay e1130482830266 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830294 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130482830294 : Closed e1130482830294 ∧ code e1130482830294 = 5528529341398 := by decide
theorem cert_e1130482830294 : checkPay e1130482830294 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130482830298 : Closed e1130482830298 ∧ code e1130482830298 = 5528529341402 := by decide
theorem cert_e1130482830298 : checkPay e1130482830298 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830574 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130482830574 : Closed e1130482830574 ∧ code e1130482830574 = 5528529341678 := by decide
theorem cert_e1130482830574 : checkPay e1130482830574 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830582 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130482830582 : Closed e1130482830582 ∧ code e1130482830582 = 5528529341686 := by decide
theorem cert_e1130482830582 : checkPay e1130482830582 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130482830958 : Closed e1130482830958 ∧ code e1130482830958 = 5528529342062 := by decide
theorem cert_e1130482830958 : checkPay e1130482830958 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482830970 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130482830970 : Closed e1130482830970 ∧ code e1130482830970 = 5528529342074 := by decide
theorem cert_e1130482830970 : checkPay e1130482830970 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482831158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130482831158 : Closed e1130482831158 ∧ code e1130482831158 = 5528529342262 := by decide
theorem cert_e1130482831158 : checkPay e1130482831158 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130482831162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130482831162 : Closed e1130482831162 ∧ code e1130482831162 = 5528529342266 := by decide
theorem cert_e1130482831162 : checkPay e1130482831162 [[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1130517421594 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517421594 : Closed e1130517421594 ∧ code e1130517421594 = 5528563932698 := by decide
theorem cert_e1130517421594 : check e1130517421594 [[]] .width = true := by decide
def e1130517427738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517427738 : Closed e1130517427738 ∧ code e1130517427738 = 5528563938842 := by decide
theorem cert_e1130517427738 : check e1130517427738 [[]] .width = true := by decide
def e1130517454362 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517454362 : Closed e1130517454362 ∧ code e1130517454362 = 5528563965466 := by decide
theorem cert_e1130517454362 : check e1130517454362 [[]] .width = true := by decide
def e1130517461530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517461530 : Closed e1130517461530 ∧ code e1130517461530 = 5528563972634 := by decide
private def t_e1130517461530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1130517461530 : ¬ IsSelfInterpreter e1130517461530 :=
  wSource (t := t_e1130517461530) (replay_sound (ps := []) (t := e1130517461530) (by decide)) (by decide)
def e1130517485082 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517485082 : Closed e1130517485082 ∧ code e1130517485082 = 5528563996186 := by decide
theorem cert_e1130517485082 : check e1130517485082 [[]] .width = true := by decide
def e1130517486106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517486106 : Closed e1130517486106 ∧ code e1130517486106 = 5528563997210 := by decide
private def t_e1130517486106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1130517486106 : ¬ IsSelfInterpreter e1130517486106 :=
  wSource (t := t_e1130517486106) (replay_sound (ps := []) (t := e1130517486106) (by decide)) (by decide)
def e1130517618202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517618202 : Closed e1130517618202 ∧ code e1130517618202 = 5528564129306 := by decide
theorem cert_e1130517618202 : check e1130517618202 [[]] .width = true := by decide
def e1130517624346 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517624346 : Closed e1130517624346 ∧ code e1130517624346 = 5528564135450 := by decide
theorem cert_e1130517624346 : check e1130517624346 [[]] .width = true := by decide
def e1130517814810 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517814810 : Closed e1130517814810 ∧ code e1130517814810 = 5528564325914 := by decide
theorem cert_e1130517814810 : check e1130517814810 [[]] .width = true := by decide
def e1130517821978 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517821978 : Closed e1130517821978 ∧ code e1130517821978 = 5528564333082 := by decide
theorem cert_e1130517821978 : check e1130517821978 [[]] .width = true := by decide
def e1130517968410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517968410 : Closed e1130517968410 ∧ code e1130517968410 = 5528564479514 := by decide
theorem cert_e1130517968410 : check e1130517968410 [[]] .width = true := by decide
def e1130517969434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130517969434 : Closed e1130517969434 ∧ code e1130517969434 = 5528564480538 := by decide
theorem cert_e1130517969434 : check e1130517969434 [[]] .width = true := by decide
def e1130521751066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521751066 : Closed e1130521751066 ∧ code e1130521751066 = 5528568262170 := by decide
theorem cert_e1130521751066 : check e1130521751066 [[]] .width = true := by decide
def e1130521753114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521753114 : Closed e1130521753114 ∧ code e1130521753114 = 5528568264218 := by decide
theorem cert_e1130521753114 : check e1130521753114 [[]] .width = true := by decide
def e1130521894426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521894426 : Closed e1130521894426 ∧ code e1130521894426 = 5528568405530 := by decide
theorem cert_e1130521894426 : check e1130521894426 [[]] .width = true := by decide
def e1130521915590 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130521915590 : Closed e1130521915590 ∧ code e1130521915590 = 5528568426694 := by decide
theorem cert_e1130521915590 : check e1130521915590 [[]] .width = true := by decide
def e1130521923098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521923098 : Closed e1130521923098 ∧ code e1130521923098 = 5528568434202 := by decide
private def t_e1130521923098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1130521923098 : ¬ IsSelfInterpreter e1130521923098 :=
  wSource (t := t_e1130521923098) (replay_sound (ps := []) (t := e1130521923098) (by decide)) (by decide)
def e1130521931974 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130521931974 : Closed e1130521931974 ∧ code e1130521931974 = 5528568443078 := by decide
theorem cert_e1130521931974 : check e1130521931974 [[]] .width = true := by decide
def e1130521980442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521980442 : Closed e1130521980442 ∧ code e1130521980442 = 5528568491546 := by decide
theorem cert_e1130521980442 : check e1130521980442 [[]] .width = true := by decide
def e1130521983514 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130521983514 : Closed e1130521983514 ∧ code e1130521983514 = 5528568494618 := by decide
theorem cert_e1130521983514 : check e1130521983514 [[]] .width = true := by decide
def e1130522025498 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522025498 : Closed e1130522025498 ∧ code e1130522025498 = 5528568536602 := by decide
theorem cert_e1130522025498 : check e1130522025498 [[]] .width = true := by decide
def e1130522046662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522046662 : Closed e1130522046662 ∧ code e1130522046662 = 5528568557766 := by decide
theorem cert_e1130522046662 : check e1130522046662 [[]] .width = true := by decide
def e1130522068506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522068506 : Closed e1130522068506 ∧ code e1130522068506 = 5528568579610 := by decide
theorem cert_e1130522068506 : check e1130522068506 [[]] .width = true := by decide
def e1130522071238 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522071238 : Closed e1130522071238 ∧ code e1130522071238 = 5528568582342 := by decide
theorem cert_e1130522071238 : check e1130522071238 [[]] .width = true := by decide
def e1130522097178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522097178 : Closed e1130522097178 ∧ code e1130522097178 = 5528568608282 := by decide
theorem cert_e1130522097178 : check e1130522097178 [[]] .width = true := by decide
def e1130522098202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522098202 : Closed e1130522098202 ∧ code e1130522098202 = 5528568609306 := by decide
theorem cert_e1130522098202 : check e1130522098202 [[]] .width = true := by decide
def e1130522119706 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522119706 : Closed e1130522119706 ∧ code e1130522119706 = 5528568630810 := by decide
private def t_e1130522119706 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1130522119706 : ¬ IsSelfInterpreter e1130522119706 :=
  wSource (t := t_e1130522119706) (replay_sound (ps := []) (t := e1130522119706) (by decide)) (by decide)
def e1130522128582 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522128582 : Closed e1130522128582 ∧ code e1130522128582 = 5528568639686 := by decide
theorem cert_e1130522128582 : check e1130522128582 [[]] .width = true := by decide
def e1130522134042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522134042 : Closed e1130522134042 ∧ code e1130522134042 = 5528568645146 := by decide
theorem cert_e1130522134042 : check e1130522134042 [[]] .width = true := by decide
def e1130522136774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522136774 : Closed e1130522136774 ∧ code e1130522136774 = 5528568647878 := by decide
theorem cert_e1130522136774 : check e1130522136774 [[]] .width = true := by decide
def e1130522680858 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522680858 : Closed e1130522680858 ∧ code e1130522680858 = 5528569191962 := by decide
theorem cert_e1130522680858 : check e1130522680858 [[]] .width = true := by decide
def e1130522702022 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522702022 : Closed e1130522702022 ∧ code e1130522702022 = 5528569213126 := by decide
theorem cert_e1130522702022 : check e1130522702022 [[]] .width = true := by decide
def e1130522709530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130522709530 : Closed e1130522709530 ∧ code e1130522709530 = 5528569220634 := by decide
theorem cert_e1130522709530 : check e1130522709530 [[]] .width = true := by decide
def e1130522718406 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130522718406 : Closed e1130522718406 ∧ code e1130522718406 = 5528569229510 := by decide
theorem cert_e1130522718406 : check e1130522718406 [[]] .width = true := by decide
def e1130523467290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130523467290 : Closed e1130523467290 ∧ code e1130523467290 = 5528569978394 := by decide
theorem cert_e1130523467290 : check e1130523467290 [[]] .width = true := by decide
def e1130523488454 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130523488454 : Closed e1130523488454 ∧ code e1130523488454 = 5528569999558 := by decide
theorem cert_e1130523488454 : check e1130523488454 [[]] .width = true := by decide
def e1130523510298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130523510298 : Closed e1130523510298 ∧ code e1130523510298 = 5528570021402 := by decide
theorem cert_e1130523510298 : check e1130523510298 [[]] .width = true := by decide
def e1130523513030 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130523513030 : Closed e1130523513030 ∧ code e1130523513030 = 5528570024134 := by decide
theorem cert_e1130523513030 : check e1130523513030 [[]] .width = true := by decide
def e1130523889178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130523889178 : Closed e1130523889178 ∧ code e1130523889178 = 5528570400282 := by decide
theorem cert_e1130523889178 : check e1130523889178 [[]] .width = true := by decide
def e1130523898054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130523898054 : Closed e1130523898054 ∧ code e1130523898054 = 5528570409158 := by decide
theorem cert_e1130523898054 : check e1130523898054 [[]] .width = true := by decide
def e1130523903514 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1130523903514 : Closed e1130523903514 ∧ code e1130523903514 = 5528570414618 := by decide
theorem cert_e1130523903514 : check e1130523903514 [[]] .width = true := by decide
def e1130523906246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1130523906246 : Closed e1130523906246 ∧ code e1130523906246 = 5528570417350 := by decide
theorem cert_e1130523906246 : check e1130523906246 [[]] .width = true := by decide
def e1130549566318 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1130549566318 : Closed e1130549566318 ∧ code e1130549566318 = 5528596077422 := by decide
theorem cert_e1130549566318 : check e1130549566318 [[],[.under]] .three = true := by decide
def e1130549566326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1130549566326 : Closed e1130549566326 ∧ code e1130549566326 = 5528596077430 := by decide
theorem cert_e1130549566326 : check e1130549566326 [[],[.under]] .three = true := by decide
def e1130549566390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1130549566390 : Closed e1130549566390 ∧ code e1130549566390 = 5528596077494 := by decide
theorem cert_e1130549566390 : check e1130549566390 [[],[.under]] .three = true := by decide
def e1130549566830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1130549566830 : Closed e1130549566830 ∧ code e1130549566830 = 5528596077934 := by decide
theorem cert_e1130549566830 : check e1130549566830 [[],[.under]] .three = true := by decide
def e1130549566838 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1130549566838 : Closed e1130549566838 ∧ code e1130549566838 = 5528596077942 := by decide
theorem cert_e1130549566838 : check e1130549566838 [[],[.under]] .three = true := by decide
def e1130549566894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1130549566894 : Closed e1130549566894 ∧ code e1130549566894 = 5528596077998 := by decide
theorem cert_e1130549566894 : check e1130549566894 [[],[.under]] .three = true := by decide
def e1130549566906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1130549566906 : Closed e1130549566906 ∧ code e1130549566906 = 5528596078010 := by decide
theorem cert_e1130549566906 : check e1130549566906 [[],[.under]] .three = true := by decide
def e1130549566934 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1130549566934 : Closed e1130549566934 ∧ code e1130549566934 = 5528596078038 := by decide
theorem cert_e1130549566934 : check e1130549566934 [[],[.under]] .three = true := by decide
def e1130549566938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1130549566938 : Closed e1130549566938 ∧ code e1130549566938 = 5528596078042 := by decide
theorem cert_e1130549566938 : check e1130549566938 [[],[.under]] .three = true := by decide
def e1130549567158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1130549567158 : Closed e1130549567158 ∧ code e1130549567158 = 5528596078262 := by decide
theorem cert_e1130549567158 : check e1130549567158 [[],[.under]] .three = true := by decide
def e1130549567190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1130549567190 : Closed e1130549567190 ∧ code e1130549567190 = 5528596078294 := by decide
theorem cert_e1130549567190 : check e1130549567190 [[],[.under]] .three = true := by decide
def e1130549567194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1130549567194 : Closed e1130549567194 ∧ code e1130549567194 = 5528596078298 := by decide
theorem cert_e1130549567194 : check e1130549567194 [[],[.under]] .three = true := by decide
def e1130549569390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1130549569390 : Closed e1130549569390 ∧ code e1130549569390 = 5528596080494 := by decide
theorem cert_e1130549569390 : check e1130549569390 [[],[.under]] .three = true := by decide
def e1130549569398 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1130549569398 : Closed e1130549569398 ∧ code e1130549569398 = 5528596080502 := by decide
theorem cert_e1130549569398 : check e1130549569398 [[],[.under]] .three = true := by decide
def e1130549569462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1130549569462 : Closed e1130549569462 ∧ code e1130549569462 = 5528596080566 := by decide
theorem cert_e1130549569462 : check e1130549569462 [[],[.under]] .three = true := by decide
def e1130549570798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130549570798 : Closed e1130549570798 ∧ code e1130549570798 = 5528596081902 := by decide
theorem cert_e1130549570798 : check e1130549570798 [[],[.under]] .three = true := by decide
def e1130549570806 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130549570806 : Closed e1130549570806 ∧ code e1130549570806 = 5528596081910 := by decide
theorem cert_e1130549570806 : check e1130549570806 [[],[.under]] .three = true := by decide
def e1130549571190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1130549571190 : Closed e1130549571190 ∧ code e1130549571190 = 5528596082294 := by decide
theorem cert_e1130549571190 : check e1130549571190 [[],[.under]] .three = true := by decide
def e1130549572462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1130549572462 : Closed e1130549572462 ∧ code e1130549572462 = 5528596083566 := by decide
theorem cert_e1130549572462 : check e1130549572462 [[],[.under]] .three = true := by decide
def e1130549572470 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1130549572470 : Closed e1130549572470 ∧ code e1130549572470 = 5528596083574 := by decide
theorem cert_e1130549572470 : check e1130549572470 [[],[.under]] .three = true := by decide
def e1130549572526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1130549572526 : Closed e1130549572526 ∧ code e1130549572526 = 5528596083630 := by decide
theorem cert_e1130549572526 : check e1130549572526 [[],[.under]] .three = true := by decide
def e1130549572538 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1130549572538 : Closed e1130549572538 ∧ code e1130549572538 = 5528596083642 := by decide
theorem cert_e1130549572538 : check e1130549572538 [[],[.under]] .three = true := by decide
def e1130549572566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1130549572566 : Closed e1130549572566 ∧ code e1130549572566 = 5528596083670 := by decide
theorem cert_e1130549572566 : check e1130549572566 [[],[.under]] .three = true := by decide
def e1130549572570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1130549572570 : Closed e1130549572570 ∧ code e1130549572570 = 5528596083674 := by decide
theorem cert_e1130549572570 : check e1130549572570 [[],[.under]] .three = true := by decide
def e1130549572846 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130549572846 : Closed e1130549572846 ∧ code e1130549572846 = 5528596083950 := by decide
theorem cert_e1130549572846 : check e1130549572846 [[],[.under]] .three = true := by decide
def e1130549572854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130549572854 : Closed e1130549572854 ∧ code e1130549572854 = 5528596083958 := by decide
theorem cert_e1130549572854 : check e1130549572854 [[],[.under]] .three = true := by decide
def e1130549573230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130549573230 : Closed e1130549573230 ∧ code e1130549573230 = 5528596084334 := by decide
theorem cert_e1130549573230 : check e1130549573230 [[],[.under]] .three = true := by decide
def e1130549573242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130549573242 : Closed e1130549573242 ∧ code e1130549573242 = 5528596084346 := by decide
theorem cert_e1130549573242 : check e1130549573242 [[],[.under]] .three = true := by decide
def e1130549573430 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130549573430 : Closed e1130549573430 ∧ code e1130549573430 = 5528596084534 := by decide
theorem cert_e1130549573430 : check e1130549573430 [[],[.under]] .three = true := by decide
def e1130549573434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130549573434 : Closed e1130549573434 ∧ code e1130549573434 = 5528596084538 := by decide
theorem cert_e1130549573434 : check e1130549573434 [[],[.under]] .three = true := by decide
def e1130549574070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1130549574070 : Closed e1130549574070 ∧ code e1130549574070 = 5528596085174 := by decide
theorem cert_e1130549574070 : check e1130549574070 [[],[.under]] .three = true := by decide
def e1130549574102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1130549574102 : Closed e1130549574102 ∧ code e1130549574102 = 5528596085206 := by decide
theorem cert_e1130549574102 : check e1130549574102 [[],[.under]] .three = true := by decide
def e1130549574106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1130549574106 : Closed e1130549574106 ∧ code e1130549574106 = 5528596085210 := by decide
theorem cert_e1130549574106 : check e1130549574106 [[],[.under]] .three = true := by decide
def e1130549574262 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1130549574262 : Closed e1130549574262 ∧ code e1130549574262 = 5528596085366 := by decide
theorem cert_e1130549574262 : check e1130549574262 [[],[.under]] .three = true := by decide
def e1130549574454 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130549574454 : Closed e1130549574454 ∧ code e1130549574454 = 5528596085558 := by decide
theorem cert_e1130549574454 : check e1130549574454 [[],[.under]] .three = true := by decide
def e1130549574458 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130549574458 : Closed e1130549574458 ∧ code e1130549574458 = 5528596085562 := by decide
theorem cert_e1130549574458 : check e1130549574458 [[],[.under]] .three = true := by decide
def e1130549581678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1130549581678 : Closed e1130549581678 ∧ code e1130549581678 = 5528596092782 := by decide
theorem cert_e1130549581678 : check e1130549581678 [[],[.under]] .three = true := by decide
def e1130549581686 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1130549581686 : Closed e1130549581686 ∧ code e1130549581686 = 5528596092790 := by decide
theorem cert_e1130549581686 : check e1130549581686 [[],[.under]] .three = true := by decide
def e1130549581750 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1130549581750 : Closed e1130549581750 ∧ code e1130549581750 = 5528596092854 := by decide
theorem cert_e1130549581750 : check e1130549581750 [[],[.under]] .three = true := by decide
def e1130549583086 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1130549583086 : Closed e1130549583086 ∧ code e1130549583086 = 5528596094190 := by decide
theorem cert_e1130549583086 : check e1130549583086 [[],[.under]] .three = true := by decide
def e1130549583094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1130549583094 : Closed e1130549583094 ∧ code e1130549583094 = 5528596094198 := by decide
theorem cert_e1130549583094 : check e1130549583094 [[],[.under]] .three = true := by decide
def e1130549583478 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1130549583478 : Closed e1130549583478 ∧ code e1130549583478 = 5528596094582 := by decide
theorem cert_e1130549583478 : check e1130549583478 [[],[.under]] .three = true := by decide
def e1130549594990 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130549594990 : Closed e1130549594990 ∧ code e1130549594990 = 5528596106094 := by decide
theorem cert_e1130549594990 : check e1130549594990 [[],[.under]] .three = true := by decide
def e1130549594998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130549594998 : Closed e1130549594998 ∧ code e1130549594998 = 5528596106102 := by decide
theorem cert_e1130549594998 : check e1130549594998 [[],[.under]] .three = true := by decide
def e1130549595054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130549595054 : Closed e1130549595054 ∧ code e1130549595054 = 5528596106158 := by decide
theorem cert_e1130549595054 : check e1130549595054 [[],[.under]] .three = true := by decide
def e1130549595066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130549595066 : Closed e1130549595066 ∧ code e1130549595066 = 5528596106170 := by decide
theorem cert_e1130549595066 : check e1130549595066 [[],[.under]] .three = true := by decide
def e1130549595094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130549595094 : Closed e1130549595094 ∧ code e1130549595094 = 5528596106198 := by decide
theorem cert_e1130549595094 : check e1130549595094 [[],[.under]] .three = true := by decide
def e1130549595098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130549595098 : Closed e1130549595098 ∧ code e1130549595098 = 5528596106202 := by decide
theorem cert_e1130549595098 : check e1130549595098 [[],[.under]] .three = true := by decide
def e1130549595374 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130549595374 : Closed e1130549595374 ∧ code e1130549595374 = 5528596106478 := by decide
theorem cert_e1130549595374 : check e1130549595374 [[],[.under]] .three = true := by decide
def e1130549595382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130549595382 : Closed e1130549595382 ∧ code e1130549595382 = 5528596106486 := by decide
theorem cert_e1130549595382 : check e1130549595382 [[],[.under]] .three = true := by decide
def e1130549595758 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130549595758 : Closed e1130549595758 ∧ code e1130549595758 = 5528596106862 := by decide
theorem cert_e1130549595758 : check e1130549595758 [[],[.under]] .three = true := by decide
def e1130549595770 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130549595770 : Closed e1130549595770 ∧ code e1130549595770 = 5528596106874 := by decide
theorem cert_e1130549595770 : check e1130549595770 [[],[.under]] .three = true := by decide
def e1130549595958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130549595958 : Closed e1130549595958 ∧ code e1130549595958 = 5528596107062 := by decide
theorem cert_e1130549595958 : check e1130549595958 [[],[.under]] .three = true := by decide
def e1130549595962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130549595962 : Closed e1130549595962 ∧ code e1130549595962 = 5528596107066 := by decide
theorem cert_e1130549595962 : check e1130549595962 [[],[.under]] .three = true := by decide
def e1130549601718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1130549601718 : Closed e1130549601718 ∧ code e1130549601718 = 5528596112822 := by decide
theorem cert_e1130549601718 : check e1130549601718 [[],[.under]] .three = true := by decide
def e1130549601750 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1130549601750 : Closed e1130549601750 ∧ code e1130549601750 = 5528596112854 := by decide
theorem cert_e1130549601750 : check e1130549601750 [[],[.under]] .three = true := by decide
def e1130549601754 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1130549601754 : Closed e1130549601754 ∧ code e1130549601754 = 5528596112858 := by decide
theorem cert_e1130549601754 : check e1130549601754 [[],[.under]] .three = true := by decide
def e1130549601910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1130549601910 : Closed e1130549601910 ∧ code e1130549601910 = 5528596113014 := by decide
theorem cert_e1130549601910 : check e1130549601910 [[],[.under]] .three = true := by decide
def e1130549602102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1130549602102 : Closed e1130549602102 ∧ code e1130549602102 = 5528596113206 := by decide
theorem cert_e1130549602102 : check e1130549602102 [[],[.under]] .three = true := by decide
def e1130549602106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1130549602106 : Closed e1130549602106 ∧ code e1130549602106 = 5528596113210 := by decide
theorem cert_e1130549602106 : check e1130549602106 [[],[.under]] .three = true := by decide
def e1130549939054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130549939054 : Closed e1130549939054 ∧ code e1130549939054 = 5528596450158 := by decide
theorem cert_e1130549939054 : check e1130549939054 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939062 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130549939062 : Closed e1130549939062 ∧ code e1130549939062 = 5528596450166 := by decide
theorem cert_e1130549939062 : check e1130549939062 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939118 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130549939118 : Closed e1130549939118 ∧ code e1130549939118 = 5528596450222 := by decide
theorem cert_e1130549939118 : check e1130549939118 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130549939130 : Closed e1130549939130 ∧ code e1130549939130 = 5528596450234 := by decide
theorem cert_e1130549939130 : check e1130549939130 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130549939158 : Closed e1130549939158 ∧ code e1130549939158 = 5528596450262 := by decide
theorem cert_e1130549939158 : check e1130549939158 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130549939162 : Closed e1130549939162 ∧ code e1130549939162 = 5528596450266 := by decide
theorem cert_e1130549939162 : check e1130549939162 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130549939438 : Closed e1130549939438 ∧ code e1130549939438 = 5528596450542 := by decide
theorem cert_e1130549939438 : check e1130549939438 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939446 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130549939446 : Closed e1130549939446 ∧ code e1130549939446 = 5528596450550 := by decide
theorem cert_e1130549939446 : check e1130549939446 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939822 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130549939822 : Closed e1130549939822 ∧ code e1130549939822 = 5528596450926 := by decide
theorem cert_e1130549939822 : check e1130549939822 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549939834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130549939834 : Closed e1130549939834 ∧ code e1130549939834 = 5528596450938 := by decide
theorem cert_e1130549939834 : check e1130549939834 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549940022 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130549940022 : Closed e1130549940022 ∧ code e1130549940022 = 5528596451126 := by decide
theorem cert_e1130549940022 : check e1130549940022 [[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1130549940026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130549940026 : Closed e1130549940026 ∧ code e1130549940026 = 5528596451130 := by decide
theorem cert_e1130549940026 : check e1130549940026 [[],[.under],[.under,.under,.left]] .chain = true := by decide
end Blc.Floor42
