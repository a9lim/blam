import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211187164138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211187164138 : Closed e1211187164138 ∧ code e1211187164138 = 5609233675242 := by decide
theorem cert_e1211187164138 : check e1211187164138 [[],[]] .smaller = true := by decide
def e1211187164286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e1211187164286 : Closed e1211187164286 ∧ code e1211187164286 = 5609233675390 := by decide
theorem cert_e1211187164286 : check e1211187164286 [[],[]] .three = true := by decide
def e1211187164382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187164382 : Closed e1211187164382 ∧ code e1211187164382 = 5609233675486 := by decide
theorem cert_e1211187164382 : check e1211187164382 [[],[]] .smaller = true := by decide
def e1211187164398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187164398 : Closed e1211187164398 ∧ code e1211187164398 = 5609233675502 := by decide
theorem cert_e1211187164398 : check e1211187164398 [[],[]] .smaller = true := by decide
def e1211187164406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187164406 : Closed e1211187164406 ∧ code e1211187164406 = 5609233675510 := by decide
theorem cert_e1211187164406 : check e1211187164406 [[],[]] .smaller = true := by decide
def e1211187164410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187164410 : Closed e1211187164410 ∧ code e1211187164410 = 5609233675514 := by decide
theorem cert_e1211187164410 : check e1211187164410 [[],[]] .smaller = true := by decide
def e1211187164782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211187164782 : Closed e1211187164782 ∧ code e1211187164782 = 5609233675886 := by decide
theorem cert_e1211187164782 : check e1211187164782 [[],[]] .smaller = true := by decide
def e1211187164794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211187164794 : Closed e1211187164794 ∧ code e1211187164794 = 5609233675898 := by decide
theorem cert_e1211187164794 : check e1211187164794 [[],[]] .smaller = true := by decide
def e1211187164982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187164982 : Closed e1211187164982 ∧ code e1211187164982 = 5609233676086 := by decide
theorem cert_e1211187164982 : check e1211187164982 [[],[]] .smaller = true := by decide
def e1211187164986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187164986 : Closed e1211187164986 ∧ code e1211187164986 = 5609233676090 := by decide
theorem cert_e1211187164986 : check e1211187164986 [[],[]] .smaller = true := by decide
def e1211187165082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187165082 : Closed e1211187165082 ∧ code e1211187165082 = 5609233676186 := by decide
theorem cert_e1211187165082 : check e1211187165082 [[],[]] .smaller = true := by decide
def e1211187165118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 4)))))))))
theorem wire_e1211187165118 : Closed e1211187165118 ∧ code e1211187165118 = 5609233676222 := by decide
theorem cert_e1211187165118 : check e1211187165118 [[],[]] .three = true := by decide
def e1211187165126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e1211187165126 : Closed e1211187165126 ∧ code e1211187165126 = 5609233676230 := by decide
theorem cert_e1211187165126 : check e1211187165126 [[],[]] .three = true := by decide
def e1211187165150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 3)))))))))
theorem wire_e1211187165150 : Closed e1211187165150 ∧ code e1211187165150 = 5609233676254 := by decide
theorem cert_e1211187165150 : check e1211187165150 [[],[]] .three = true := by decide
def e1211187165622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211187165622 : Closed e1211187165622 ∧ code e1211187165622 = 5609233676726 := by decide
theorem cert_e1211187165622 : check e1211187165622 [[],[]] .smaller = true := by decide
def e1211187165654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211187165654 : Closed e1211187165654 ∧ code e1211187165654 = 5609233676758 := by decide
theorem cert_e1211187165654 : check e1211187165654 [[],[]] .smaller = true := by decide
def e1211187165658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211187165658 : Closed e1211187165658 ∧ code e1211187165658 = 5609233676762 := by decide
theorem cert_e1211187165658 : check e1211187165658 [[],[]] .smaller = true := by decide
def e1211187165814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211187165814 : Closed e1211187165814 ∧ code e1211187165814 = 5609233676918 := by decide
theorem cert_e1211187165814 : check e1211187165814 [[],[]] .smaller = true := by decide
def e1211187166006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187166006 : Closed e1211187166006 ∧ code e1211187166006 = 5609233677110 := by decide
theorem cert_e1211187166006 : check e1211187166006 [[],[]] .smaller = true := by decide
def e1211187166010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187166010 : Closed e1211187166010 ∧ code e1211187166010 = 5609233677114 := by decide
theorem cert_e1211187166010 : check e1211187166010 [[],[]] .smaller = true := by decide
def e1211187166142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 4)))))))))
theorem wire_e1211187166142 : Closed e1211187166142 ∧ code e1211187166142 = 5609233677246 := by decide
theorem cert_e1211187166142 : check e1211187166142 [[],[]] .three = true := by decide
def e1211187166174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 3)))))))))
theorem wire_e1211187166174 : Closed e1211187166174 ∧ code e1211187166174 = 5609233677278 := by decide
theorem cert_e1211187166174 : check e1211187166174 [[],[]] .smaller = true := by decide
def e1211187166190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 4)) (.var 2)))))))))
theorem wire_e1211187166190 : Closed e1211187166190 ∧ code e1211187166190 = 5609233677294 := by decide
theorem cert_e1211187166190 : check e1211187166190 [[],[]] .three = true := by decide
def e1211187166422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211187166422 : Closed e1211187166422 ∧ code e1211187166422 = 5609233677526 := by decide
theorem cert_e1211187166422 : check e1211187166422 [[],[]] .smaller = true := by decide
def e1211187166426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211187166426 : Closed e1211187166426 ∧ code e1211187166426 = 5609233677530 := by decide
theorem cert_e1211187166426 : check e1211187166426 [[],[]] .smaller = true := by decide
def e1211187166442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211187166442 : Closed e1211187166442 ∧ code e1211187166442 = 5609233677546 := by decide
theorem cert_e1211187166442 : check e1211187166442 [[],[]] .smaller = true := by decide
def e1211187166518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187166518 : Closed e1211187166518 ∧ code e1211187166518 = 5609233677622 := by decide
theorem cert_e1211187166518 : check e1211187166518 [[],[]] .smaller = true := by decide
def e1211187166522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187166522 : Closed e1211187166522 ∧ code e1211187166522 = 5609233677626 := by decide
theorem cert_e1211187166522 : check e1211187166522 [[],[]] .smaller = true := by decide
def e1211187166618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187166618 : Closed e1211187166618 ∧ code e1211187166618 = 5609233677722 := by decide
theorem cert_e1211187166618 : check e1211187166618 [[],[]] .smaller = true := by decide
def e1211187166654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 4)))))))))
theorem wire_e1211187166654 : Closed e1211187166654 ∧ code e1211187166654 = 5609233677758 := by decide
theorem cert_e1211187166654 : check e1211187166654 [[],[]] .three = true := by decide
def e1211187166686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 3)))))))))
theorem wire_e1211187166686 : Closed e1211187166686 ∧ code e1211187166686 = 5609233677790 := by decide
theorem cert_e1211187166686 : check e1211187166686 [[],[]] .smaller = true := by decide
def e1211187166702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 3)) (.var 2)))))))))
theorem wire_e1211187166702 : Closed e1211187166702 ∧ code e1211187166702 = 5609233677806 := by decide
theorem cert_e1211187166702 : check e1211187166702 [[],[]] .smaller = true := by decide
def e1211187166710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 4)) (.var 1)))))))))
theorem wire_e1211187166710 : Closed e1211187166710 ∧ code e1211187166710 = 5609233677814 := by decide
theorem cert_e1211187166710 : check e1211187166710 [[],[]] .three = true := by decide
def e1211187166774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211187166774 : Closed e1211187166774 ∧ code e1211187166774 = 5609233677878 := by decide
theorem cert_e1211187166774 : check e1211187166774 [[],[]] .three = true := by decide
def e1211187166778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211187166778 : Closed e1211187166778 ∧ code e1211187166778 = 5609233677882 := by decide
theorem cert_e1211187166778 : check e1211187166778 [[],[]] .three = true := by decide
def e1211187166862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211187166862 : Closed e1211187166862 ∧ code e1211187166862 = 5609233677966 := by decide
theorem cert_e1211187166862 : check e1211187166862 [[],[]] .three = true := by decide
def e1211187166918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211187166918 : Closed e1211187166918 ∧ code e1211187166918 = 5609233678022 := by decide
theorem cert_e1211187166918 : check e1211187166918 [[],[]] .three = true := by decide
def e1211187166942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 3)))))))))
theorem wire_e1211187166942 : Closed e1211187166942 ∧ code e1211187166942 = 5609233678046 := by decide
theorem cert_e1211187166942 : check e1211187166942 [[],[]] .three = true := by decide
def e1211187166958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 2)) (.var 2)))))))))
theorem wire_e1211187166958 : Closed e1211187166958 ∧ code e1211187166958 = 5609233678062 := by decide
theorem cert_e1211187166958 : check e1211187166958 [[],[]] .three = true := by decide
def e1211187166966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 3)) (.var 1)))))))))
theorem wire_e1211187166966 : Closed e1211187166966 ∧ code e1211187166966 = 5609233678070 := by decide
theorem cert_e1211187166966 : check e1211187166966 [[],[]] .three = true := by decide
def e1211187169214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211187169214 : Closed e1211187169214 ∧ code e1211187169214 = 5609233680318 := by decide
theorem cert_e1211187169214 : check e1211187169214 [[],[]] .smaller = true := by decide
def e1211187169262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211187169262 : Closed e1211187169262 ∧ code e1211187169262 = 5609233680366 := by decide
theorem cert_e1211187169262 : check e1211187169262 [[],[]] .smaller = true := by decide
def e1211187173086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211187173086 : Closed e1211187173086 ∧ code e1211187173086 = 5609233684190 := by decide
theorem cert_e1211187173086 : check e1211187173086 [[],[]] .smaller = true := by decide
def e1211187173110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211187173110 : Closed e1211187173110 ∧ code e1211187173110 = 5609233684214 := by decide
theorem cert_e1211187173110 : check e1211187173110 [[],[]] .smaller = true := by decide
def e1211187173214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211187173214 : Closed e1211187173214 ∧ code e1211187173214 = 5609233684318 := by decide
theorem cert_e1211187173214 : check e1211187173214 [[],[]] .smaller = true := by decide
def e1211187173230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211187173230 : Closed e1211187173230 ∧ code e1211187173230 = 5609233684334 := by decide
theorem cert_e1211187173230 : check e1211187173230 [[],[]] .smaller = true := by decide
def e1211187173238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211187173238 : Closed e1211187173238 ∧ code e1211187173238 = 5609233684342 := by decide
theorem cert_e1211187173238 : check e1211187173238 [[],[]] .smaller = true := by decide
def e1211187173242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211187173242 : Closed e1211187173242 ∧ code e1211187173242 = 5609233684346 := by decide
theorem cert_e1211187173242 : check e1211187173242 [[],[]] .smaller = true := by decide
def e1211187173302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211187173302 : Closed e1211187173302 ∧ code e1211187173302 = 5609233684406 := by decide
theorem cert_e1211187173302 : check e1211187173302 [[],[]] .smaller = true := by decide
def e1211187173334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211187173334 : Closed e1211187173334 ∧ code e1211187173334 = 5609233684438 := by decide
theorem cert_e1211187173334 : check e1211187173334 [[],[]] .smaller = true := by decide
def e1211187173338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211187173338 : Closed e1211187173338 ∧ code e1211187173338 = 5609233684442 := by decide
theorem cert_e1211187173338 : check e1211187173338 [[],[]] .smaller = true := by decide
def e1211187173854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211187173854 : Closed e1211187173854 ∧ code e1211187173854 = 5609233684958 := by decide
theorem cert_e1211187173854 : check e1211187173854 [[],[]] .smaller = true := by decide
def e1211187173878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211187173878 : Closed e1211187173878 ∧ code e1211187173878 = 5609233684982 := by decide
theorem cert_e1211187173878 : check e1211187173878 [[],[]] .smaller = true := by decide
def e1211187174526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e1211187174526 : Closed e1211187174526 ∧ code e1211187174526 = 5609233685630 := by decide
theorem cert_e1211187174526 : check e1211187174526 [[],[]] .three = true := by decide
def e1211187174622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187174622 : Closed e1211187174622 ∧ code e1211187174622 = 5609233685726 := by decide
theorem cert_e1211187174622 : check e1211187174622 [[],[]] .smaller = true := by decide
def e1211187174638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211187174638 : Closed e1211187174638 ∧ code e1211187174638 = 5609233685742 := by decide
theorem cert_e1211187174638 : check e1211187174638 [[],[]] .smaller = true := by decide
def e1211187174646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211187174646 : Closed e1211187174646 ∧ code e1211187174646 = 5609233685750 := by decide
theorem cert_e1211187174646 : check e1211187174646 [[],[]] .smaller = true := by decide
def e1211187174650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187174650 : Closed e1211187174650 ∧ code e1211187174650 = 5609233685754 := by decide
theorem cert_e1211187174650 : check e1211187174650 [[],[]] .smaller = true := by decide
def e1211187175030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211187175030 : Closed e1211187175030 ∧ code e1211187175030 = 5609233686134 := by decide
theorem cert_e1211187175030 : check e1211187175030 [[],[]] .smaller = true := by decide
def e1211187175222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187175222 : Closed e1211187175222 ∧ code e1211187175222 = 5609233686326 := by decide
theorem cert_e1211187175222 : check e1211187175222 [[],[]] .smaller = true := by decide
def e1211187175226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187175226 : Closed e1211187175226 ∧ code e1211187175226 = 5609233686330 := by decide
theorem cert_e1211187175226 : check e1211187175226 [[],[]] .smaller = true := by decide
def e1211187175310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e1211187175310 : Closed e1211187175310 ∧ code e1211187175310 = 5609233686414 := by decide
theorem cert_e1211187175310 : check e1211187175310 [[],[]] .three = true := by decide
def e1211187184574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211187184574 : Closed e1211187184574 ∧ code e1211187184574 = 5609233695678 := by decide
theorem cert_e1211187184574 : check e1211187184574 [[],[]] .smaller = true := by decide
def e1211187184630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211187184630 : Closed e1211187184630 ∧ code e1211187184630 = 5609233695734 := by decide
theorem cert_e1211187184630 : check e1211187184630 [[],[]] .smaller = true := by decide
def e1211187186526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211187186526 : Closed e1211187186526 ∧ code e1211187186526 = 5609233697630 := by decide
theorem cert_e1211187186526 : check e1211187186526 [[],[]] .smaller = true := by decide
def e1211187186542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211187186542 : Closed e1211187186542 ∧ code e1211187186542 = 5609233697646 := by decide
theorem cert_e1211187186542 : check e1211187186542 [[],[]] .smaller = true := by decide
def e1211187186550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211187186550 : Closed e1211187186550 ∧ code e1211187186550 = 5609233697654 := by decide
theorem cert_e1211187186550 : check e1211187186550 [[],[]] .smaller = true := by decide
def e1211187186554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211187186554 : Closed e1211187186554 ∧ code e1211187186554 = 5609233697658 := by decide
theorem cert_e1211187186554 : check e1211187186554 [[],[]] .smaller = true := by decide
def e1211187186606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211187186606 : Closed e1211187186606 ∧ code e1211187186606 = 5609233697710 := by decide
theorem cert_e1211187186606 : check e1211187186606 [[],[]] .smaller = true := by decide
def e1211187186618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211187186618 : Closed e1211187186618 ∧ code e1211187186618 = 5609233697722 := by decide
theorem cert_e1211187186618 : check e1211187186618 [[],[]] .smaller = true := by decide
def e1211187186646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211187186646 : Closed e1211187186646 ∧ code e1211187186646 = 5609233697750 := by decide
theorem cert_e1211187186646 : check e1211187186646 [[],[]] .smaller = true := by decide
def e1211187186650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211187186650 : Closed e1211187186650 ∧ code e1211187186650 = 5609233697754 := by decide
theorem cert_e1211187186650 : check e1211187186650 [[],[]] .smaller = true := by decide
def e1211187186666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211187186666 : Closed e1211187186666 ∧ code e1211187186666 = 5609233697770 := by decide
theorem cert_e1211187186666 : check e1211187186666 [[],[]] .smaller = true := by decide
def e1211187186814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e1211187186814 : Closed e1211187186814 ∧ code e1211187186814 = 5609233697918 := by decide
theorem cert_e1211187186814 : check e1211187186814 [[],[]] .three = true := by decide
def e1211187186910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187186910 : Closed e1211187186910 ∧ code e1211187186910 = 5609233698014 := by decide
theorem cert_e1211187186910 : check e1211187186910 [[],[]] .smaller = true := by decide
def e1211187186926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211187186926 : Closed e1211187186926 ∧ code e1211187186926 = 5609233698030 := by decide
theorem cert_e1211187186926 : check e1211187186926 [[],[]] .smaller = true := by decide
def e1211187186934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211187186934 : Closed e1211187186934 ∧ code e1211187186934 = 5609233698038 := by decide
theorem cert_e1211187186934 : check e1211187186934 [[],[]] .smaller = true := by decide
def e1211187186938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187186938 : Closed e1211187186938 ∧ code e1211187186938 = 5609233698042 := by decide
theorem cert_e1211187186938 : check e1211187186938 [[],[]] .smaller = true := by decide
def e1211187187310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187187310 : Closed e1211187187310 ∧ code e1211187187310 = 5609233698414 := by decide
theorem cert_e1211187187310 : check e1211187187310 [[],[]] .smaller = true := by decide
def e1211187187322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187187322 : Closed e1211187187322 ∧ code e1211187187322 = 5609233698426 := by decide
theorem cert_e1211187187322 : check e1211187187322 [[],[]] .smaller = true := by decide
def e1211187187510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187187510 : Closed e1211187187510 ∧ code e1211187187510 = 5609233698614 := by decide
theorem cert_e1211187187510 : check e1211187187510 [[],[]] .smaller = true := by decide
def e1211187187514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187187514 : Closed e1211187187514 ∧ code e1211187187514 = 5609233698618 := by decide
theorem cert_e1211187187514 : check e1211187187514 [[],[]] .smaller = true := by decide
def e1211187187610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187187610 : Closed e1211187187610 ∧ code e1211187187610 = 5609233698714 := by decide
theorem cert_e1211187187610 : check e1211187187610 [[],[]] .smaller = true := by decide
def e1211187187646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 4))))))))))
theorem wire_e1211187187646 : Closed e1211187187646 ∧ code e1211187187646 = 5609233698750 := by decide
theorem cert_e1211187187646 : check e1211187187646 [[],[]] .three = true := by decide
def e1211187187654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e1211187187654 : Closed e1211187187654 ∧ code e1211187187654 = 5609233698758 := by decide
theorem cert_e1211187187654 : check e1211187187654 [[],[]] .three = true := by decide
def e1211187187678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 3))))))))))
theorem wire_e1211187187678 : Closed e1211187187678 ∧ code e1211187187678 = 5609233698782 := by decide
theorem cert_e1211187187678 : check e1211187187678 [[],[]] .three = true := by decide
def e1211187193270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211187193270 : Closed e1211187193270 ∧ code e1211187193270 = 5609233704374 := by decide
theorem cert_e1211187193270 : check e1211187193270 [[],[]] .smaller = true := by decide
def e1211187193302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211187193302 : Closed e1211187193302 ∧ code e1211187193302 = 5609233704406 := by decide
theorem cert_e1211187193302 : check e1211187193302 [[],[]] .smaller = true := by decide
def e1211187193306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211187193306 : Closed e1211187193306 ∧ code e1211187193306 = 5609233704410 := by decide
theorem cert_e1211187193306 : check e1211187193306 [[],[]] .smaller = true := by decide
def e1211187193462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211187193462 : Closed e1211187193462 ∧ code e1211187193462 = 5609233704566 := by decide
theorem cert_e1211187193462 : check e1211187193462 [[],[]] .smaller = true := by decide
def e1211187193654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187193654 : Closed e1211187193654 ∧ code e1211187193654 = 5609233704758 := by decide
theorem cert_e1211187193654 : check e1211187193654 [[],[]] .smaller = true := by decide
def e1211187193658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187193658 : Closed e1211187193658 ∧ code e1211187193658 = 5609233704762 := by decide
theorem cert_e1211187193658 : check e1211187193658 [[],[]] .smaller = true := by decide
def e1211187193790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211187193790 : Closed e1211187193790 ∧ code e1211187193790 = 5609233704894 := by decide
theorem cert_e1211187193790 : check e1211187193790 [[],[]] .three = true := by decide
def e1211187193822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 3))))))))))
theorem wire_e1211187193822 : Closed e1211187193822 ∧ code e1211187193822 = 5609233704926 := by decide
theorem cert_e1211187193822 : check e1211187193822 [[],[]] .smaller = true := by decide
def e1211187193838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211187193838 : Closed e1211187193838 ∧ code e1211187193838 = 5609233704942 := by decide
theorem cert_e1211187193838 : check e1211187193838 [[],[]] .three = true := by decide
def e1211187196142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211187196142 : Closed e1211187196142 ∧ code e1211187196142 = 5609233707246 := by decide
theorem cert_e1211187196142 : check e1211187196142 [[],[]] .smaller = true := by decide
def e1211187196150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211187196150 : Closed e1211187196150 ∧ code e1211187196150 = 5609233707254 := by decide
theorem cert_e1211187196150 : check e1211187196150 [[],[]] .smaller = true := by decide
def e1211187196630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211187196630 : Closed e1211187196630 ∧ code e1211187196630 = 5609233707734 := by decide
theorem cert_e1211187196630 : check e1211187196630 [[],[]] .smaller = true := by decide
def e1211187196634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211187196634 : Closed e1211187196634 ∧ code e1211187196634 = 5609233707738 := by decide
theorem cert_e1211187196634 : check e1211187196634 [[],[]] .smaller = true := by decide
def e1211187196650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211187196650 : Closed e1211187196650 ∧ code e1211187196650 = 5609233707754 := by decide
theorem cert_e1211187196650 : check e1211187196650 [[],[]] .smaller = true := by decide
def e1211187196726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187196726 : Closed e1211187196726 ∧ code e1211187196726 = 5609233707830 := by decide
theorem cert_e1211187196726 : check e1211187196726 [[],[]] .smaller = true := by decide
def e1211187196730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187196730 : Closed e1211187196730 ∧ code e1211187196730 = 5609233707834 := by decide
theorem cert_e1211187196730 : check e1211187196730 [[],[]] .smaller = true := by decide
def e1211187196826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187196826 : Closed e1211187196826 ∧ code e1211187196826 = 5609233707930 := by decide
theorem cert_e1211187196826 : check e1211187196826 [[],[]] .smaller = true := by decide
def e1211187196862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211187196862 : Closed e1211187196862 ∧ code e1211187196862 = 5609233707966 := by decide
theorem cert_e1211187196862 : check e1211187196862 [[],[]] .three = true := by decide
def e1211187196894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211187196894 : Closed e1211187196894 ∧ code e1211187196894 = 5609233707998 := by decide
theorem cert_e1211187196894 : check e1211187196894 [[],[]] .smaller = true := by decide
def e1211187196910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211187196910 : Closed e1211187196910 ∧ code e1211187196910 = 5609233708014 := by decide
theorem cert_e1211187196910 : check e1211187196910 [[],[]] .smaller = true := by decide
def e1211187196918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211187196918 : Closed e1211187196918 ∧ code e1211187196918 = 5609233708022 := by decide
theorem cert_e1211187196918 : check e1211187196918 [[],[]] .three = true := by decide
def e1211187198350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211187198350 : Closed e1211187198350 ∧ code e1211187198350 = 5609233709454 := by decide
theorem cert_e1211187198350 : check e1211187198350 [[],[]] .three = true := by decide
def e1211187198406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211187198406 : Closed e1211187198406 ∧ code e1211187198406 = 5609233709510 := by decide
theorem cert_e1211187198406 : check e1211187198406 [[],[]] .three = true := by decide
def e1211187198430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211187198430 : Closed e1211187198430 ∧ code e1211187198430 = 5609233709534 := by decide
theorem cert_e1211187198430 : check e1211187198430 [[],[]] .three = true := by decide
def e1211187198446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211187198446 : Closed e1211187198446 ∧ code e1211187198446 = 5609233709550 := by decide
theorem cert_e1211187198446 : check e1211187198446 [[],[]] .three = true := by decide
def e1211187198454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211187198454 : Closed e1211187198454 ∧ code e1211187198454 = 5609233709558 := by decide
theorem cert_e1211187198454 : check e1211187198454 [[],[]] .three = true := by decide
def e1211187358174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211187358174 : Closed e1211187358174 ∧ code e1211187358174 = 5609233869278 := by decide
theorem cert_e1211187358174 : check e1211187358174 [[],[]] .three = true := by decide
def e1211187358198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211187358198 : Closed e1211187358198 ∧ code e1211187358198 = 5609233869302 := by decide
theorem cert_e1211187358198 : check e1211187358198 [[],[]] .three = true := by decide
def e1211187421918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e1211187421918 : Closed e1211187421918 ∧ code e1211187421918 = 5609233933022 := by decide
theorem cert_e1211187421918 : check e1211187421918 [[],[]] .three = true := by decide
def e1211187421942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e1211187421942 : Closed e1211187421942 ∧ code e1211187421942 = 5609233933046 := by decide
theorem cert_e1211187421942 : check e1211187421942 [[],[]] .three = true := by decide
def e1211187422062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211187422062 : Closed e1211187422062 ∧ code e1211187422062 = 5609233933166 := by decide
theorem cert_e1211187422062 : check e1211187422062 [[],[]] .smaller = true := by decide
def e1211187422070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211187422070 : Closed e1211187422070 ∧ code e1211187422070 = 5609233933174 := by decide
theorem cert_e1211187422070 : check e1211187422070 [[],[]] .smaller = true := by decide
def e1211187422126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e1211187422126 : Closed e1211187422126 ∧ code e1211187422126 = 5609233933230 := by decide
theorem cert_e1211187422126 : check e1211187422126 [[],[]] .smaller = true := by decide
def e1211187422138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e1211187422138 : Closed e1211187422138 ∧ code e1211187422138 = 5609233933242 := by decide
theorem cert_e1211187422138 : check e1211187422138 [[],[]] .smaller = true := by decide
def e1211187422166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211187422166 : Closed e1211187422166 ∧ code e1211187422166 = 5609233933270 := by decide
theorem cert_e1211187422166 : check e1211187422166 [[],[]] .smaller = true := by decide
def e1211187422170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211187422170 : Closed e1211187422170 ∧ code e1211187422170 = 5609233933274 := by decide
theorem cert_e1211187422170 : check e1211187422170 [[],[]] .smaller = true := by decide
def e1211187423470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211187423470 : Closed e1211187423470 ∧ code e1211187423470 = 5609233934574 := by decide
theorem cert_e1211187423470 : check e1211187423470 [[],[]] .smaller = true := by decide
def e1211187423478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211187423478 : Closed e1211187423478 ∧ code e1211187423478 = 5609233934582 := by decide
theorem cert_e1211187423478 : check e1211187423478 [[],[]] .smaller = true := by decide
def e1211187424030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211187424030 : Closed e1211187424030 ∧ code e1211187424030 = 5609233935134 := by decide
theorem cert_e1211187424030 : check e1211187424030 [[],[]] .smaller = true := by decide
def e1211187424142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211187424142 : Closed e1211187424142 ∧ code e1211187424142 = 5609233935246 := by decide
theorem cert_e1211187424142 : check e1211187424142 [[],[]] .smaller = true := by decide
def e1211187424350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211187424350 : Closed e1211187424350 ∧ code e1211187424350 = 5609233935454 := by decide
theorem cert_e1211187424350 : check e1211187424350 [[],[]] .three = true := by decide
def e1211187424366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211187424366 : Closed e1211187424366 ∧ code e1211187424366 = 5609233935470 := by decide
theorem cert_e1211187424366 : check e1211187424366 [[],[]] .smaller = true := by decide
def e1211187424378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211187424378 : Closed e1211187424378 ∧ code e1211187424378 = 5609233935482 := by decide
theorem cert_e1211187424378 : check e1211187424378 [[],[]] .smaller = true := by decide
def e1211187424542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211187424542 : Closed e1211187424542 ∧ code e1211187424542 = 5609233935646 := by decide
theorem cert_e1211187424542 : check e1211187424542 [[],[]] .smaller = true := by decide
def e1211187424710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211187424710 : Closed e1211187424710 ∧ code e1211187424710 = 5609233935814 := by decide
theorem cert_e1211187424710 : check e1211187424710 [[],[]] .smaller = true := by decide
def e1211187424734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e1211187424734 : Closed e1211187424734 ∧ code e1211187424734 = 5609233935838 := by decide
theorem cert_e1211187424734 : check e1211187424734 [[],[]] .three = true := by decide
def e1211187424738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211187424738 : Closed e1211187424738 ∧ code e1211187424738 = 5609233935842 := by decide
theorem cert_e1211187424738 : check e1211187424738 [[],[]] .three = true := by decide
def e1211187424750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e1211187424750 : Closed e1211187424750 ∧ code e1211187424750 = 5609233935854 := by decide
theorem cert_e1211187424750 : check e1211187424750 [[],[]] .three = true := by decide
def e1211187424822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211187424822 : Closed e1211187424822 ∧ code e1211187424822 = 5609233935926 := by decide
theorem cert_e1211187424822 : check e1211187424822 [[],[]] .smaller = true := by decide
def e1211187424826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211187424826 : Closed e1211187424826 ∧ code e1211187424826 = 5609233935930 := by decide
theorem cert_e1211187424826 : check e1211187424826 [[],[]] .smaller = true := by decide
def e1211187424910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211187424910 : Closed e1211187424910 ∧ code e1211187424910 = 5609233936014 := by decide
theorem cert_e1211187424910 : check e1211187424910 [[],[]] .smaller = true := by decide
def e1211187424966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211187424966 : Closed e1211187424966 ∧ code e1211187424966 = 5609233936070 := by decide
theorem cert_e1211187424966 : check e1211187424966 [[],[]] .smaller = true := by decide
def e1211187424990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e1211187424990 : Closed e1211187424990 ∧ code e1211187424990 = 5609233936094 := by decide
theorem cert_e1211187424990 : check e1211187424990 [[],[]] .three = true := by decide
def e1211187425014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e1211187425014 : Closed e1211187425014 ∧ code e1211187425014 = 5609233936118 := by decide
theorem cert_e1211187425014 : check e1211187425014 [[],[]] .three = true := by decide
def e1211187425046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211187425046 : Closed e1211187425046 ∧ code e1211187425046 = 5609233936150 := by decide
theorem cert_e1211187425046 : check e1211187425046 [[],[]] .three = true := by decide
def e1211187425122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211187425122 : Closed e1211187425122 ∧ code e1211187425122 = 5609233936226 := by decide
theorem cert_e1211187425122 : check e1211187425122 [[],[]] .three = true := by decide
def e1211187425134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e1211187425134 : Closed e1211187425134 ∧ code e1211187425134 = 5609233936238 := by decide
theorem cert_e1211187425134 : check e1211187425134 [[],[]] .three = true := by decide
def e1211187425142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e1211187425142 : Closed e1211187425142 ∧ code e1211187425142 = 5609233936246 := by decide
theorem cert_e1211187425142 : check e1211187425142 [[],[]] .three = true := by decide
def e1211187425630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211187425630 : Closed e1211187425630 ∧ code e1211187425630 = 5609233936734 := by decide
theorem cert_e1211187425630 : check e1211187425630 [[],[]] .three = true := by decide
def e1211187425646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e1211187425646 : Closed e1211187425646 ∧ code e1211187425646 = 5609233936750 := by decide
theorem cert_e1211187425646 : check e1211187425646 [[],[]] .smaller = true := by decide
def e1211187425654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e1211187425654 : Closed e1211187425654 ∧ code e1211187425654 = 5609233936758 := by decide
theorem cert_e1211187425654 : check e1211187425654 [[],[]] .smaller = true := by decide
def e1211187425658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211187425658 : Closed e1211187425658 ∧ code e1211187425658 = 5609233936762 := by decide
theorem cert_e1211187425658 : check e1211187425658 [[],[]] .three = true := by decide
def e1211187425710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211187425710 : Closed e1211187425710 ∧ code e1211187425710 = 5609233936814 := by decide
theorem cert_e1211187425710 : check e1211187425710 [[],[]] .smaller = true := by decide
def e1211187425722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211187425722 : Closed e1211187425722 ∧ code e1211187425722 = 5609233936826 := by decide
theorem cert_e1211187425722 : check e1211187425722 [[],[]] .smaller = true := by decide
def e1211187425770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211187425770 : Closed e1211187425770 ∧ code e1211187425770 = 5609233936874 := by decide
theorem cert_e1211187425770 : check e1211187425770 [[],[]] .smaller = true := by decide
def e1211187426398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211187426398 : Closed e1211187426398 ∧ code e1211187426398 = 5609233937502 := by decide
theorem cert_e1211187426398 : check e1211187426398 [[],[]] .three = true := by decide
def e1211187426414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211187426414 : Closed e1211187426414 ∧ code e1211187426414 = 5609233937518 := by decide
theorem cert_e1211187426414 : check e1211187426414 [[],[]] .smaller = true := by decide
def e1211187426426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211187426426 : Closed e1211187426426 ∧ code e1211187426426 = 5609233937530 := by decide
theorem cert_e1211187426426 : check e1211187426426 [[],[]] .smaller = true := by decide
def e1211187426590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211187426590 : Closed e1211187426590 ∧ code e1211187426590 = 5609233937694 := by decide
theorem cert_e1211187426590 : check e1211187426590 [[],[]] .smaller = true := by decide
def e1211187426758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211187426758 : Closed e1211187426758 ∧ code e1211187426758 = 5609233937862 := by decide
theorem cert_e1211187426758 : check e1211187426758 [[],[]] .smaller = true := by decide
def e1211187426782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211187426782 : Closed e1211187426782 ∧ code e1211187426782 = 5609233937886 := by decide
theorem cert_e1211187426782 : check e1211187426782 [[],[]] .three = true := by decide
def e1211187426786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211187426786 : Closed e1211187426786 ∧ code e1211187426786 = 5609233937890 := by decide
theorem cert_e1211187426786 : check e1211187426786 [[],[]] .three = true := by decide
def e1211187426798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211187426798 : Closed e1211187426798 ∧ code e1211187426798 = 5609233937902 := by decide
theorem cert_e1211187426798 : check e1211187426798 [[],[]] .three = true := by decide
def e1211187426862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211187426862 : Closed e1211187426862 ∧ code e1211187426862 = 5609233937966 := by decide
theorem cert_e1211187426862 : check e1211187426862 [[],[]] .smaller = true := by decide
end Blc.Floor42
