import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1402308294498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308294498 : Closed e1402308294498 ∧ code e1402308294498 = 5800354805602 := by decide
theorem cert_e1402308294498 : check e1402308294498 [[.left],[.left]] .smaller = true := by decide
def e1402308294562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308294562 : Closed e1402308294562 ∧ code e1402308294562 = 5800354805666 := by decide
theorem cert_e1402308294562 : check e1402308294562 [[.left],[.left]] .chain = true := by decide
def e1402308295522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308295522 : Closed e1402308295522 ∧ code e1402308295522 = 5800354806626 := by decide
theorem cert_e1402308295522 : check e1402308295522 [[.left],[.left]] .smaller = true := by decide
def e1402308296034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308296034 : Closed e1402308296034 ∧ code e1402308296034 = 5800354807138 := by decide
theorem cert_e1402308296034 : check e1402308296034 [[.left],[.left]] .chain = true := by decide
def e1402308296098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308296098 : Closed e1402308296098 ∧ code e1402308296098 = 5800354807202 := by decide
theorem cert_e1402308296098 : check e1402308296098 [[.left],[.left]] .chain = true := by decide
def e1402308304354 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308304354 : Closed e1402308304354 ∧ code e1402308304354 = 5800354815458 := by decide
theorem cert_e1402308304354 : check e1402308304354 [[.left],[.left]] .chain = true := by decide
def e1402308304738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308304738 : Closed e1402308304738 ∧ code e1402308304738 = 5800354815842 := by decide
theorem cert_e1402308304738 : check e1402308304738 [[.left],[.left]] .chain = true := by decide
def e1402308316642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308316642 : Closed e1402308316642 ∧ code e1402308316642 = 5800354827746 := by decide
theorem cert_e1402308316642 : check e1402308316642 [[.left],[.left]] .chain = true := by decide
def e1402308316898 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308316898 : Closed e1402308316898 ∧ code e1402308316898 = 5800354828002 := by decide
theorem cert_e1402308316898 : check e1402308316898 [[.left],[.left]] .smaller = true := by decide
def e1402308317026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308317026 : Closed e1402308317026 ∧ code e1402308317026 = 5800354828130 := by decide
theorem cert_e1402308317026 : check e1402308317026 [[.left],[.left]] .smaller = true := by decide
def e1402308317090 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308317090 : Closed e1402308317090 ∧ code e1402308317090 = 5800354828194 := by decide
theorem cert_e1402308317090 : check e1402308317090 [[.left],[.left]] .chain = true := by decide
def e1402308320794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308320794 : Closed e1402308320794 ∧ code e1402308320794 = 5800354831898 := by decide
theorem cert_e1402308320794 : check e1402308320794 [[.left]] .chain = true := by decide
def e1402308323170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308323170 : Closed e1402308323170 ∧ code e1402308323170 = 5800354834274 := by decide
theorem cert_e1402308323170 : check e1402308323170 [[.left],[.left]] .smaller = true := by decide
def e1402308326242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308326242 : Closed e1402308326242 ∧ code e1402308326242 = 5800354837346 := by decide
theorem cert_e1402308326242 : check e1402308326242 [[.left],[.left]] .chain = true := by decide
def e1402308326306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308326306 : Closed e1402308326306 ∧ code e1402308326306 = 5800354837410 := by decide
theorem cert_e1402308326306 : check e1402308326306 [[.left],[.left]] .chain = true := by decide
def e1402308326938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308326938 : Closed e1402308326938 ∧ code e1402308326938 = 5800354838042 := by decide
theorem cert_e1402308326938 : check e1402308326938 [[.left]] .chain = true := by decide
def e1402308343266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308343266 : Closed e1402308343266 ∧ code e1402308343266 = 5800354854370 := by decide
theorem cert_e1402308343266 : check e1402308343266 [[.left],[.left]] .chain = true := by decide
def e1402308343522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308343522 : Closed e1402308343522 ∧ code e1402308343522 = 5800354854626 := by decide
theorem cert_e1402308343522 : check e1402308343522 [[.left],[.left]] .smaller = true := by decide
def e1402308343650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308343650 : Closed e1402308343650 ∧ code e1402308343650 = 5800354854754 := by decide
theorem cert_e1402308343650 : check e1402308343650 [[.left],[.left]] .smaller = true := by decide
def e1402308343714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308343714 : Closed e1402308343714 ∧ code e1402308343714 = 5800354854818 := by decide
theorem cert_e1402308343714 : check e1402308343714 [[.left],[.left]] .chain = true := by decide
def e1402308344546 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308344546 : Closed e1402308344546 ∧ code e1402308344546 = 5800354855650 := by decide
theorem cert_e1402308344546 : check e1402308344546 [[.left],[.left]] .smaller = true := by decide
def e1402308344738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308344738 : Closed e1402308344738 ∧ code e1402308344738 = 5800354855842 := by decide
theorem cert_e1402308344738 : check e1402308344738 [[.left],[.left]] .smaller = true := by decide
def e1402308345186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308345186 : Closed e1402308345186 ∧ code e1402308345186 = 5800354856290 := by decide
theorem cert_e1402308345186 : check e1402308345186 [[.left],[.left]] .smaller = true := by decide
def e1402308345250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308345250 : Closed e1402308345250 ∧ code e1402308345250 = 5800354856354 := by decide
theorem cert_e1402308345250 : check e1402308345250 [[.left],[.left]] .smaller = true := by decide
def e1402308345506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308345506 : Closed e1402308345506 ∧ code e1402308345506 = 5800354856610 := by decide
theorem cert_e1402308345506 : check e1402308345506 [[.left],[.left]] .chain = true := by decide
def e1402308349410 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308349410 : Closed e1402308349410 ∧ code e1402308349410 = 5800354860514 := by decide
theorem cert_e1402308349410 : check e1402308349410 [[.left],[.left]] .chain = true := by decide
def e1402308349666 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308349666 : Closed e1402308349666 ∧ code e1402308349666 = 5800354860770 := by decide
theorem cert_e1402308349666 : check e1402308349666 [[.left],[.left]] .smaller = true := by decide
def e1402308349794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308349794 : Closed e1402308349794 ∧ code e1402308349794 = 5800354860898 := by decide
theorem cert_e1402308349794 : check e1402308349794 [[.left],[.left]] .smaller = true := by decide
def e1402308349858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308349858 : Closed e1402308349858 ∧ code e1402308349858 = 5800354860962 := by decide
theorem cert_e1402308349858 : check e1402308349858 [[.left],[.left]] .chain = true := by decide
def e1402308353562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308353562 : Closed e1402308353562 ∧ code e1402308353562 = 5800354864666 := by decide
theorem cert_e1402308353562 : check e1402308353562 [[.left]] .chain = true := by decide
def e1402308355810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308355810 : Closed e1402308355810 ∧ code e1402308355810 = 5800354866914 := by decide
theorem cert_e1402308355810 : check e1402308355810 [[.left],[.left]] .smaller = true := by decide
def e1402308356002 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308356002 : Closed e1402308356002 ∧ code e1402308356002 = 5800354867106 := by decide
theorem cert_e1402308356002 : check e1402308356002 [[.left],[.left]] .smaller = true := by decide
def e1402308359010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308359010 : Closed e1402308359010 ∧ code e1402308359010 = 5800354870114 := by decide
theorem cert_e1402308359010 : check e1402308359010 [[.left],[.left]] .smaller = true := by decide
def e1402308359074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308359074 : Closed e1402308359074 ∧ code e1402308359074 = 5800354870178 := by decide
theorem cert_e1402308359074 : check e1402308359074 [[.left],[.left]] .smaller = true := by decide
def e1402308360610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308360610 : Closed e1402308360610 ∧ code e1402308360610 = 5800354871714 := by decide
theorem cert_e1402308360610 : check e1402308360610 [[.left],[.left]] .chain = true := by decide
def e1402308360730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308360730 : Closed e1402308360730 ∧ code e1402308360730 = 5800354871834 := by decide
theorem cert_e1402308360730 : check e1402308360730 [[.left]] .chain = true := by decide
def e1402308369250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308369250 : Closed e1402308369250 ∧ code e1402308369250 = 5800354880354 := by decide
theorem cert_e1402308369250 : check e1402308369250 [[.left],[.left]] .smaller = true := by decide
def e1402308369762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308369762 : Closed e1402308369762 ∧ code e1402308369762 = 5800354880866 := by decide
theorem cert_e1402308369762 : check e1402308369762 [[.left],[.left]] .smaller = true := by decide
def e1402308369826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308369826 : Closed e1402308369826 ∧ code e1402308369826 = 5800354880930 := by decide
theorem cert_e1402308369826 : check e1402308369826 [[.left],[.left]] .smaller = true := by decide
def e1402308372322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308372322 : Closed e1402308372322 ∧ code e1402308372322 = 5800354883426 := by decide
theorem cert_e1402308372322 : check e1402308372322 [[.left],[.left]] .smaller = true := by decide
def e1402308375394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308375394 : Closed e1402308375394 ∧ code e1402308375394 = 5800354886498 := by decide
theorem cert_e1402308375394 : check e1402308375394 [[.left],[.left]] .smaller = true := by decide
def e1402308375458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308375458 : Closed e1402308375458 ∧ code e1402308375458 = 5800354886562 := by decide
theorem cert_e1402308375458 : check e1402308375458 [[.left],[.left]] .smaller = true := by decide
def e1402308382050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308382050 : Closed e1402308382050 ∧ code e1402308382050 = 5800354893154 := by decide
theorem cert_e1402308382050 : check e1402308382050 [[.left],[.left]] .chain = true := by decide
def e1402308382114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308382114 : Closed e1402308382114 ∧ code e1402308382114 = 5800354893218 := by decide
theorem cert_e1402308382114 : check e1402308382114 [[.left],[.left]] .chain = true := by decide
def e1402308382370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308382370 : Closed e1402308382370 ∧ code e1402308382370 = 5800354893474 := by decide
theorem cert_e1402308382370 : check e1402308382370 [[.left],[.left]] .chain = true := by decide
def e1402308383586 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308383586 : Closed e1402308383586 ∧ code e1402308383586 = 5800354894690 := by decide
theorem cert_e1402308383586 : check e1402308383586 [[.left],[.left]] .chain = true := by decide
def e1402308383650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308383650 : Closed e1402308383650 ∧ code e1402308383650 = 5800354894754 := by decide
theorem cert_e1402308383650 : check e1402308383650 [[.left],[.left]] .chain = true := by decide
def e1402308384282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308384282 : Closed e1402308384282 ∧ code e1402308384282 = 5800354895386 := by decide
theorem cert_e1402308384282 : check e1402308384282 [[.left]] .chain = true := by decide
def e1402308385186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308385186 : Closed e1402308385186 ∧ code e1402308385186 = 5800354896290 := by decide
theorem cert_e1402308385186 : check e1402308385186 [[.left],[.left]] .chain = true := by decide
def e1402308385306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308385306 : Closed e1402308385306 ∧ code e1402308385306 = 5800354896410 := by decide
theorem cert_e1402308385306 : check e1402308385306 [[.left]] .chain = true := by decide
def e1402308488674 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308488674 : Closed e1402308488674 ∧ code e1402308488674 = 5800354999778 := by decide
theorem cert_e1402308488674 : check e1402308488674 [[.left],[.left]] .chain = true := by decide
def e1402308489058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308489058 : Closed e1402308489058 ∧ code e1402308489058 = 5800355000162 := by decide
theorem cert_e1402308489058 : check e1402308489058 [[.left],[.left]] .chain = true := by decide
def e1402308490722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308490722 : Closed e1402308490722 ∧ code e1402308490722 = 5800355001826 := by decide
theorem cert_e1402308490722 : check e1402308490722 [[.left],[.left]] .chain = true := by decide
def e1402308490978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308490978 : Closed e1402308490978 ∧ code e1402308490978 = 5800355002082 := by decide
theorem cert_e1402308490978 : check e1402308490978 [[.left],[.left]] .smaller = true := by decide
def e1402308491106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308491106 : Closed e1402308491106 ∧ code e1402308491106 = 5800355002210 := by decide
theorem cert_e1402308491106 : check e1402308491106 [[.left],[.left]] .smaller = true := by decide
def e1402308491170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308491170 : Closed e1402308491170 ∧ code e1402308491170 = 5800355002274 := by decide
theorem cert_e1402308491170 : check e1402308491170 [[.left],[.left]] .chain = true := by decide
def e1402308492130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308492130 : Closed e1402308492130 ∧ code e1402308492130 = 5800355003234 := by decide
theorem cert_e1402308492130 : check e1402308492130 [[.left],[.left]] .smaller = true := by decide
def e1402308492642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308492642 : Closed e1402308492642 ∧ code e1402308492642 = 5800355003746 := by decide
theorem cert_e1402308492642 : check e1402308492642 [[.left],[.left]] .chain = true := by decide
def e1402308492706 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308492706 : Closed e1402308492706 ∧ code e1402308492706 = 5800355003810 := by decide
theorem cert_e1402308492706 : check e1402308492706 [[.left],[.left]] .chain = true := by decide
def e1402308500962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402308500962 : Closed e1402308500962 ∧ code e1402308500962 = 5800355012066 := by decide
theorem cert_e1402308500962 : check e1402308500962 [[.left],[.left]] .chain = true := by decide
def e1402308501346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308501346 : Closed e1402308501346 ∧ code e1402308501346 = 5800355012450 := by decide
theorem cert_e1402308501346 : check e1402308501346 [[.left],[.left]] .chain = true := by decide
def e1402308513250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402308513250 : Closed e1402308513250 ∧ code e1402308513250 = 5800355024354 := by decide
theorem cert_e1402308513250 : check e1402308513250 [[.left],[.left]] .chain = true := by decide
def e1402308513506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402308513506 : Closed e1402308513506 ∧ code e1402308513506 = 5800355024610 := by decide
theorem cert_e1402308513506 : check e1402308513506 [[.left],[.left]] .smaller = true := by decide
def e1402308513634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308513634 : Closed e1402308513634 ∧ code e1402308513634 = 5800355024738 := by decide
theorem cert_e1402308513634 : check e1402308513634 [[.left],[.left]] .smaller = true := by decide
def e1402308513698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308513698 : Closed e1402308513698 ∧ code e1402308513698 = 5800355024802 := by decide
theorem cert_e1402308513698 : check e1402308513698 [[.left],[.left]] .chain = true := by decide
def e1402308517402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308517402 : Closed e1402308517402 ∧ code e1402308517402 = 5800355028506 := by decide
theorem cert_e1402308517402 : check e1402308517402 [[.left]] .chain = true := by decide
def e1402308519778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308519778 : Closed e1402308519778 ∧ code e1402308519778 = 5800355030882 := by decide
theorem cert_e1402308519778 : check e1402308519778 [[.left],[.left]] .smaller = true := by decide
def e1402308522850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308522850 : Closed e1402308522850 ∧ code e1402308522850 = 5800355033954 := by decide
theorem cert_e1402308522850 : check e1402308522850 [[.left],[.left]] .chain = true := by decide
def e1402308522914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308522914 : Closed e1402308522914 ∧ code e1402308522914 = 5800355034018 := by decide
theorem cert_e1402308522914 : check e1402308522914 [[.left],[.left]] .chain = true := by decide
def e1402308523546 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308523546 : Closed e1402308523546 ∧ code e1402308523546 = 5800355034650 := by decide
theorem cert_e1402308523546 : check e1402308523546 [[.left]] .chain = true := by decide
def e1402308703714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402308703714 : Closed e1402308703714 ∧ code e1402308703714 = 5800355214818 := by decide
theorem cert_e1402308703714 : check e1402308703714 [[.left],[.left]] .chain = true := by decide
def e1402308703970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308703970 : Closed e1402308703970 ∧ code e1402308703970 = 5800355215074 := by decide
theorem cert_e1402308703970 : check e1402308703970 [[.left],[.left]] .smaller = true := by decide
def e1402308704098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308704098 : Closed e1402308704098 ∧ code e1402308704098 = 5800355215202 := by decide
theorem cert_e1402308704098 : check e1402308704098 [[.left],[.left]] .smaller = true := by decide
def e1402308704162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308704162 : Closed e1402308704162 ∧ code e1402308704162 = 5800355215266 := by decide
theorem cert_e1402308704162 : check e1402308704162 [[.left],[.left]] .chain = true := by decide
def e1402308704994 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402308704994 : Closed e1402308704994 ∧ code e1402308704994 = 5800355216098 := by decide
theorem cert_e1402308704994 : check e1402308704994 [[.left],[.left]] .smaller = true := by decide
def e1402308705186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308705186 : Closed e1402308705186 ∧ code e1402308705186 = 5800355216290 := by decide
theorem cert_e1402308705186 : check e1402308705186 [[.left],[.left]] .smaller = true := by decide
def e1402308705634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308705634 : Closed e1402308705634 ∧ code e1402308705634 = 5800355216738 := by decide
theorem cert_e1402308705634 : check e1402308705634 [[.left],[.left]] .smaller = true := by decide
def e1402308705698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308705698 : Closed e1402308705698 ∧ code e1402308705698 = 5800355216802 := by decide
theorem cert_e1402308705698 : check e1402308705698 [[.left],[.left]] .smaller = true := by decide
def e1402308705954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308705954 : Closed e1402308705954 ∧ code e1402308705954 = 5800355217058 := by decide
theorem cert_e1402308705954 : check e1402308705954 [[.left],[.left]] .chain = true := by decide
def e1402308709858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402308709858 : Closed e1402308709858 ∧ code e1402308709858 = 5800355220962 := by decide
theorem cert_e1402308709858 : check e1402308709858 [[.left],[.left]] .chain = true := by decide
def e1402308710114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402308710114 : Closed e1402308710114 ∧ code e1402308710114 = 5800355221218 := by decide
theorem cert_e1402308710114 : check e1402308710114 [[.left],[.left]] .smaller = true := by decide
def e1402308710242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308710242 : Closed e1402308710242 ∧ code e1402308710242 = 5800355221346 := by decide
theorem cert_e1402308710242 : check e1402308710242 [[.left],[.left]] .smaller = true := by decide
def e1402308710306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308710306 : Closed e1402308710306 ∧ code e1402308710306 = 5800355221410 := by decide
theorem cert_e1402308710306 : check e1402308710306 [[.left],[.left]] .chain = true := by decide
def e1402308714010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308714010 : Closed e1402308714010 ∧ code e1402308714010 = 5800355225114 := by decide
theorem cert_e1402308714010 : check e1402308714010 [[.left]] .chain = true := by decide
def e1402308716258 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402308716258 : Closed e1402308716258 ∧ code e1402308716258 = 5800355227362 := by decide
theorem cert_e1402308716258 : check e1402308716258 [[.left],[.left]] .smaller = true := by decide
def e1402308716450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308716450 : Closed e1402308716450 ∧ code e1402308716450 = 5800355227554 := by decide
theorem cert_e1402308716450 : check e1402308716450 [[.left],[.left]] .smaller = true := by decide
def e1402308719458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308719458 : Closed e1402308719458 ∧ code e1402308719458 = 5800355230562 := by decide
theorem cert_e1402308719458 : check e1402308719458 [[.left],[.left]] .smaller = true := by decide
def e1402308719522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308719522 : Closed e1402308719522 ∧ code e1402308719522 = 5800355230626 := by decide
theorem cert_e1402308719522 : check e1402308719522 [[.left],[.left]] .smaller = true := by decide
def e1402308721058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308721058 : Closed e1402308721058 ∧ code e1402308721058 = 5800355232162 := by decide
theorem cert_e1402308721058 : check e1402308721058 [[.left],[.left]] .chain = true := by decide
def e1402308721178 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308721178 : Closed e1402308721178 ∧ code e1402308721178 = 5800355232282 := by decide
theorem cert_e1402308721178 : check e1402308721178 [[.left]] .chain = true := by decide
def e1402308811618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308811618 : Closed e1402308811618 ∧ code e1402308811618 = 5800355322722 := by decide
theorem cert_e1402308811618 : check e1402308811618 [[.left],[.left]] .smaller = true := by decide
def e1402308812130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308812130 : Closed e1402308812130 ∧ code e1402308812130 = 5800355323234 := by decide
theorem cert_e1402308812130 : check e1402308812130 [[.left],[.left]] .smaller = true := by decide
def e1402308812194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308812194 : Closed e1402308812194 ∧ code e1402308812194 = 5800355323298 := by decide
theorem cert_e1402308812194 : check e1402308812194 [[.left],[.left]] .smaller = true := by decide
def e1402308814690 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308814690 : Closed e1402308814690 ∧ code e1402308814690 = 5800355325794 := by decide
theorem cert_e1402308814690 : check e1402308814690 [[.left],[.left]] .smaller = true := by decide
def e1402308817762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308817762 : Closed e1402308817762 ∧ code e1402308817762 = 5800355328866 := by decide
theorem cert_e1402308817762 : check e1402308817762 [[.left],[.left]] .smaller = true := by decide
def e1402308817826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308817826 : Closed e1402308817826 ∧ code e1402308817826 = 5800355328930 := by decide
theorem cert_e1402308817826 : check e1402308817826 [[.left],[.left]] .smaller = true := by decide
def e1402308865378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402308865378 : Closed e1402308865378 ∧ code e1402308865378 = 5800355376482 := by decide
theorem cert_e1402308865378 : check e1402308865378 [[.left],[.left]] .chain = true := by decide
def e1402308865442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308865442 : Closed e1402308865442 ∧ code e1402308865442 = 5800355376546 := by decide
theorem cert_e1402308865442 : check e1402308865442 [[.left],[.left]] .chain = true := by decide
def e1402308865698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402308865698 : Closed e1402308865698 ∧ code e1402308865698 = 5800355376802 := by decide
theorem cert_e1402308865698 : check e1402308865698 [[.left],[.left]] .chain = true := by decide
def e1402308866914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402308866914 : Closed e1402308866914 ∧ code e1402308866914 = 5800355378018 := by decide
theorem cert_e1402308866914 : check e1402308866914 [[.left],[.left]] .chain = true := by decide
def e1402308866978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308866978 : Closed e1402308866978 ∧ code e1402308866978 = 5800355378082 := by decide
theorem cert_e1402308866978 : check e1402308866978 [[.left],[.left]] .chain = true := by decide
def e1402308867610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308867610 : Closed e1402308867610 ∧ code e1402308867610 = 5800355378714 := by decide
theorem cert_e1402308867610 : check e1402308867610 [[.left]] .chain = true := by decide
def e1402308868514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402308868514 : Closed e1402308868514 ∧ code e1402308868514 = 5800355379618 := by decide
theorem cert_e1402308868514 : check e1402308868514 [[.left],[.left]] .chain = true := by decide
def e1402308868634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402308868634 : Closed e1402308868634 ∧ code e1402308868634 = 5800355379738 := by decide
theorem cert_e1402308868634 : check e1402308868634 [[.left]] .chain = true := by decide
def e1402312472290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312472290 : Closed e1402312472290 ∧ code e1402312472290 = 5800358983394 := by decide
theorem cert_e1402312472290 : check e1402312472290 [[.left],[.left]] .chain = true := by decide
def e1402312472418 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312472418 : Closed e1402312472418 ∧ code e1402312472418 = 5800358983522 := by decide
theorem cert_e1402312472418 : check e1402312472418 [[.left],[.left]] .chain = true := by decide
def e1402312473314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312473314 : Closed e1402312473314 ∧ code e1402312473314 = 5800358984418 := by decide
theorem cert_e1402312473314 : check e1402312473314 [[.left],[.left]] .chain = true := by decide
def e1402312473506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312473506 : Closed e1402312473506 ∧ code e1402312473506 = 5800358984610 := by decide
theorem cert_e1402312473506 : check e1402312473506 [[.left],[.left]] .chain = true := by decide
def e1402312473954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312473954 : Closed e1402312473954 ∧ code e1402312473954 = 5800358985058 := by decide
theorem cert_e1402312473954 : check e1402312473954 [[.left],[.left]] .chain = true := by decide
def e1402312474018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312474018 : Closed e1402312474018 ∧ code e1402312474018 = 5800358985122 := by decide
theorem cert_e1402312474018 : check e1402312474018 [[.left],[.left]] .chain = true := by decide
def e1402312494818 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312494818 : Closed e1402312494818 ∧ code e1402312494818 = 5800359005922 := by decide
theorem cert_e1402312494818 : check e1402312494818 [[.left],[.left]] .chain = true := by decide
def e1402312494946 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312494946 : Closed e1402312494946 ∧ code e1402312494946 = 5800359006050 := by decide
theorem cert_e1402312494946 : check e1402312494946 [[.left],[.left]] .chain = true := by decide
def e1402312503778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312503778 : Closed e1402312503778 ∧ code e1402312503778 = 5800359014882 := by decide
theorem cert_e1402312503778 : check e1402312503778 [[.left],[.left]] .chain = true := by decide
def e1402312505094 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312505094 : Closed e1402312505094 ∧ code e1402312505094 = 5800359016198 := by decide
theorem cert_e1402312505094 : check e1402312505094 [[.left],[.left]] .chain = true := by decide
def e1402312505570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312505570 : Closed e1402312505570 ∧ code e1402312505570 = 5800359016674 := by decide
theorem cert_e1402312505570 : check e1402312505570 [[.left],[.left]] .chain = true := by decide
def e1402312506118 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312506118 : Closed e1402312506118 ∧ code e1402312506118 = 5800359017222 := by decide
theorem cert_e1402312506118 : check e1402312506118 [[.left],[.left]] .chain = true := by decide
def e1402312509154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312509154 : Closed e1402312509154 ∧ code e1402312509154 = 5800359020258 := by decide
theorem cert_e1402312509154 : check e1402312509154 [[.left],[.left]] .chain = true := by decide
def e1402312509346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312509346 : Closed e1402312509346 ∧ code e1402312509346 = 5800359020450 := by decide
theorem cert_e1402312509346 : check e1402312509346 [[.left],[.left]] .chain = true := by decide
def e1402312511970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312511970 : Closed e1402312511970 ∧ code e1402312511970 = 5800359023074 := by decide
theorem cert_e1402312511970 : check e1402312511970 [[.left],[.left]] .chain = true := by decide
def e1402312513286 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312513286 : Closed e1402312513286 ∧ code e1402312513286 = 5800359024390 := by decide
theorem cert_e1402312513286 : check e1402312513286 [[.left],[.left]] .chain = true := by decide
def e1402312514434 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312514434 : Closed e1402312514434 ∧ code e1402312514434 = 5800359025538 := by decide
theorem cert_e1402312514434 : check e1402312514434 [[.left],[.left]] .chain = true := by decide
def e1402312514658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312514658 : Closed e1402312514658 ∧ code e1402312514658 = 5800359025762 := by decide
theorem cert_e1402312514658 : check e1402312514658 [[.left],[.left]] .chain = true := by decide
def e1402312514822 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312514822 : Closed e1402312514822 ∧ code e1402312514822 = 5800359025926 := by decide
theorem cert_e1402312514822 : check e1402312514822 [[.left],[.left]] .chain = true := by decide
def e1402312514946 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312514946 : Closed e1402312514946 ∧ code e1402312514946 = 5800359026050 := by decide
theorem cert_e1402312514946 : check e1402312514946 [[.left],[.left]] .chain = true := by decide
def e1402312516450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312516450 : Closed e1402312516450 ∧ code e1402312516450 = 5800359027554 := by decide
theorem cert_e1402312516450 : check e1402312516450 [[.left],[.left]] .chain = true := by decide
def e1402312516514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312516514 : Closed e1402312516514 ∧ code e1402312516514 = 5800359027618 := by decide
theorem cert_e1402312516514 : check e1402312516514 [[.left],[.left]] .chain = true := by decide
def e1402312517858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312517858 : Closed e1402312517858 ∧ code e1402312517858 = 5800359028962 := by decide
theorem cert_e1402312517858 : check e1402312517858 [[.left],[.left]] .chain = true := by decide
def e1402312518406 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312518406 : Closed e1402312518406 ∧ code e1402312518406 = 5800359029510 := by decide
theorem cert_e1402312518406 : check e1402312518406 [[.left],[.left]] .chain = true := by decide
def e1402312518754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312518754 : Closed e1402312518754 ∧ code e1402312518754 = 5800359029858 := by decide
theorem cert_e1402312518754 : check e1402312518754 [[.left],[.left]] .chain = true := by decide
def e1402312518918 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312518918 : Closed e1402312518918 ∧ code e1402312518918 = 5800359030022 := by decide
theorem cert_e1402312518918 : check e1402312518918 [[.left],[.left]] .chain = true := by decide
def e1402312519042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312519042 : Closed e1402312519042 ∧ code e1402312519042 = 5800359030146 := by decide
theorem cert_e1402312519042 : check e1402312519042 [[.left],[.left]] .chain = true := by decide
def e1402312530658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312530658 : Closed e1402312530658 ∧ code e1402312530658 = 5800359041762 := by decide
theorem cert_e1402312530658 : check e1402312530658 [[.left],[.left]] .chain = true := by decide
def e1402312530850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312530850 : Closed e1402312530850 ∧ code e1402312530850 = 5800359041954 := by decide
theorem cert_e1402312530850 : check e1402312530850 [[.left],[.left]] .chain = true := by decide
def e1402312531618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312531618 : Closed e1402312531618 ∧ code e1402312531618 = 5800359042722 := by decide
theorem cert_e1402312531618 : check e1402312531618 [[.left],[.left]] .chain = true := by decide
def e1402312541922 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312541922 : Closed e1402312541922 ∧ code e1402312541922 = 5800359053026 := by decide
theorem cert_e1402312541922 : check e1402312541922 [[.left],[.left]] .chain = true := by decide
def e1402312542114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312542114 : Closed e1402312542114 ∧ code e1402312542114 = 5800359053218 := by decide
theorem cert_e1402312542114 : check e1402312542114 [[.left],[.left]] .chain = true := by decide
def e1402312544738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312544738 : Closed e1402312544738 ∧ code e1402312544738 = 5800359055842 := by decide
theorem cert_e1402312544738 : check e1402312544738 [[.left],[.left]] .chain = true := by decide
def e1402312546054 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312546054 : Closed e1402312546054 ∧ code e1402312546054 = 5800359057158 := by decide
theorem cert_e1402312546054 : check e1402312546054 [[.left],[.left]] .chain = true := by decide
def e1402312547202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312547202 : Closed e1402312547202 ∧ code e1402312547202 = 5800359058306 := by decide
theorem cert_e1402312547202 : check e1402312547202 [[.left],[.left]] .chain = true := by decide
def e1402312547426 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312547426 : Closed e1402312547426 ∧ code e1402312547426 = 5800359058530 := by decide
theorem cert_e1402312547426 : check e1402312547426 [[.left],[.left]] .chain = true := by decide
def e1402312547590 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312547590 : Closed e1402312547590 ∧ code e1402312547590 = 5800359058694 := by decide
theorem cert_e1402312547590 : check e1402312547590 [[.left],[.left]] .chain = true := by decide
def e1402312547714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312547714 : Closed e1402312547714 ∧ code e1402312547714 = 5800359058818 := by decide
theorem cert_e1402312547714 : check e1402312547714 [[.left],[.left]] .chain = true := by decide
def e1402312551298 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312551298 : Closed e1402312551298 ∧ code e1402312551298 = 5800359062402 := by decide
theorem cert_e1402312551298 : check e1402312551298 [[.left],[.left]] .chain = true := by decide
def e1402312552066 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312552066 : Closed e1402312552066 ∧ code e1402312552066 = 5800359063170 := by decide
theorem cert_e1402312552066 : check e1402312552066 [[.left],[.left]] .chain = true := by decide
def e1402312552866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312552866 : Closed e1402312552866 ∧ code e1402312552866 = 5800359063970 := by decide
theorem cert_e1402312552866 : check e1402312552866 [[.left],[.left]] .chain = true := by decide
def e1402312553570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312553570 : Closed e1402312553570 ∧ code e1402312553570 = 5800359064674 := by decide
theorem cert_e1402312553570 : check e1402312553570 [[.left],[.left]] .chain = true := by decide
def e1402312553734 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312553734 : Closed e1402312553734 ∧ code e1402312553734 = 5800359064838 := by decide
theorem cert_e1402312553734 : check e1402312553734 [[.left],[.left]] .chain = true := by decide
def e1402312553858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312553858 : Closed e1402312553858 ∧ code e1402312553858 = 5800359064962 := by decide
theorem cert_e1402312553858 : check e1402312553858 [[.left],[.left]] .chain = true := by decide
def e1402312554114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312554114 : Closed e1402312554114 ∧ code e1402312554114 = 5800359065218 := by decide
theorem cert_e1402312554114 : check e1402312554114 [[.left],[.left]] .chain = true := by decide
def e1402312559970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312559970 : Closed e1402312559970 ∧ code e1402312559970 = 5800359071074 := by decide
theorem cert_e1402312559970 : check e1402312559970 [[.left],[.left]] .chain = true := by decide
def e1402312560034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312560034 : Closed e1402312560034 ∧ code e1402312560034 = 5800359071138 := by decide
theorem cert_e1402312560034 : check e1402312560034 [[.left],[.left]] .chain = true := by decide
def e1402312560290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312560290 : Closed e1402312560290 ∧ code e1402312560290 = 5800359071394 := by decide
theorem cert_e1402312560290 : check e1402312560290 [[.left],[.left]] .chain = true := by decide
def e1402312565602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312565602 : Closed e1402312565602 ∧ code e1402312565602 = 5800359076706 := by decide
theorem cert_e1402312565602 : check e1402312565602 [[.left],[.left]] .chain = true := by decide
def e1402312565666 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312565666 : Closed e1402312565666 ∧ code e1402312565666 = 5800359076770 := by decide
theorem cert_e1402312565666 : check e1402312565666 [[.left],[.left]] .chain = true := by decide
def e1402312567010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312567010 : Closed e1402312567010 ∧ code e1402312567010 = 5800359078114 := by decide
theorem cert_e1402312567010 : check e1402312567010 [[.left],[.left]] .chain = true := by decide
def e1402312567558 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312567558 : Closed e1402312567558 ∧ code e1402312567558 = 5800359078662 := by decide
theorem cert_e1402312567558 : check e1402312567558 [[.left],[.left]] .chain = true := by decide
def e1402312567906 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312567906 : Closed e1402312567906 ∧ code e1402312567906 = 5800359079010 := by decide
theorem cert_e1402312567906 : check e1402312567906 [[.left],[.left]] .chain = true := by decide
def e1402312568070 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312568070 : Closed e1402312568070 ∧ code e1402312568070 = 5800359079174 := by decide
theorem cert_e1402312568070 : check e1402312568070 [[.left],[.left]] .chain = true := by decide
def e1402312568194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312568194 : Closed e1402312568194 ∧ code e1402312568194 = 5800359079298 := by decide
theorem cert_e1402312568194 : check e1402312568194 [[.left],[.left]] .chain = true := by decide
def e1402312569250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312569250 : Closed e1402312569250 ∧ code e1402312569250 = 5800359080354 := by decide
theorem cert_e1402312569250 : check e1402312569250 [[.left],[.left]] .chain = true := by decide
end Blc.Floor42
