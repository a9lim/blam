import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1203531964046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1203531964046 : Closed e1203531964046 ∧ code e1203531964046 = 5601578475150 := by decide
theorem cert_e1203531964046 : check e1203531964046 [[],[]] .chain = true := by decide
def e1203531964102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1203531964102 : Closed e1203531964102 ∧ code e1203531964102 = 5601578475206 := by decide
theorem cert_e1203531964102 : check e1203531964102 [[],[]] .chain = true := by decide
def e1203531966238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1203531966238 : Closed e1203531966238 ∧ code e1203531966238 = 5601578477342 := by decide
theorem cert_e1203531966238 : check e1203531966238 [[],[]] .chain = true := by decide
def e1203531966350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1203531966350 : Closed e1203531966350 ∧ code e1203531966350 = 5601578477454 := by decide
theorem cert_e1203531966350 : check e1203531966350 [[],[]] .chain = true := by decide
def e1203531969310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1203531969310 : Closed e1203531969310 ∧ code e1203531969310 = 5601578480414 := by decide
theorem cert_e1203531969310 : check e1203531969310 [[],[]] .chain = true := by decide
def e1203531969478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1203531969478 : Closed e1203531969478 ∧ code e1203531969478 = 5601578480582 := by decide
theorem cert_e1203531969478 : check e1203531969478 [[],[]] .chain = true := by decide
def e1203531970958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1203531970958 : Closed e1203531970958 ∧ code e1203531970958 = 5601578482062 := by decide
theorem cert_e1203531970958 : check e1203531970958 [[],[]] .chain = true := by decide
def e1203531971014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1203531971014 : Closed e1203531971014 ∧ code e1203531971014 = 5601578482118 := by decide
theorem cert_e1203531971014 : check e1203531971014 [[],[]] .chain = true := by decide
def e1203536664286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1203536664286 : Closed e1203536664286 ∧ code e1203536664286 = 5601583175390 := by decide
theorem cert_e1203536664286 : check e1203536664286 [[],[],[]] .smaller = true := by decide
def e1203536664310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1203536664310 : Closed e1203536664310 ∧ code e1203536664310 = 5601583175414 := by decide
theorem cert_e1203536664310 : check e1203536664310 [[],[],[]] .smaller = true := by decide
def e1203536664414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1203536664414 : Closed e1203536664414 ∧ code e1203536664414 = 5601583175518 := by decide
theorem cert_e1203536664414 : check e1203536664414 [[],[],[]] .smaller = true := by decide
def e1203536664442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1203536664442 : Closed e1203536664442 ∧ code e1203536664442 = 5601583175546 := by decide
theorem cert_e1203536664442 : check e1203536664442 [[],[],[]] .smaller = true := by decide
def e1203536664534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1203536664534 : Closed e1203536664534 ∧ code e1203536664534 = 5601583175638 := by decide
theorem cert_e1203536664534 : check e1203536664534 [[],[],[]] .smaller = true := by decide
def e1203536664538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1203536664538 : Closed e1203536664538 ∧ code e1203536664538 = 5601583175642 := by decide
theorem cert_e1203536664538 : check e1203536664538 [[],[],[]] .smaller = true := by decide
def e1203536665054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1203536665054 : Closed e1203536665054 ∧ code e1203536665054 = 5601583176158 := by decide
theorem cert_e1203536665054 : check e1203536665054 [[],[],[]] .smaller = true := by decide
def e1203536665078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1203536665078 : Closed e1203536665078 ∧ code e1203536665078 = 5601583176182 := by decide
theorem cert_e1203536665078 : check e1203536665078 [[],[],[]] .smaller = true := by decide
def e1203536665822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1203536665822 : Closed e1203536665822 ∧ code e1203536665822 = 5601583176926 := by decide
theorem cert_e1203536665822 : check e1203536665822 [[],[],[]] .smaller = true := by decide
def e1203536665850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1203536665850 : Closed e1203536665850 ∧ code e1203536665850 = 5601583176954 := by decide
theorem cert_e1203536665850 : check e1203536665850 [[],[],[]] .smaller = true := by decide
def e1203536666422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203536666422 : Closed e1203536666422 ∧ code e1203536666422 = 5601583177526 := by decide
theorem cert_e1203536666422 : check e1203536666422 [[],[],[]] .smaller = true := by decide
def e1203536666426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203536666426 : Closed e1203536666426 ∧ code e1203536666426 = 5601583177530 := by decide
theorem cert_e1203536666426 : check e1203536666426 [[],[],[]] .smaller = true := by decide
def e1203536681198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1203536681198 : Closed e1203536681198 ∧ code e1203536681198 = 5601583192302 := by decide
theorem cert_e1203536681198 : check e1203536681198 [[],[],[]] .smaller = true := by decide
def e1203536681206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1203536681206 : Closed e1203536681206 ∧ code e1203536681206 = 5601583192310 := by decide
theorem cert_e1203536681206 : check e1203536681206 [[],[],[]] .smaller = true := by decide
def e1203536681758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1203536681758 : Closed e1203536681758 ∧ code e1203536681758 = 5601583192862 := by decide
theorem cert_e1203536681758 : check e1203536681758 [[],[],[]] .smaller = true := by decide
def e1203536681870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1203536681870 : Closed e1203536681870 ∧ code e1203536681870 = 5601583192974 := by decide
theorem cert_e1203536681870 : check e1203536681870 [[],[],[]] .smaller = true := by decide
def e1203536682094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1203536682094 : Closed e1203536682094 ∧ code e1203536682094 = 5601583193198 := by decide
theorem cert_e1203536682094 : check e1203536682094 [[],[],[]] .smaller = true := by decide
def e1203536682106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1203536682106 : Closed e1203536682106 ∧ code e1203536682106 = 5601583193210 := by decide
theorem cert_e1203536682106 : check e1203536682106 [[],[],[]] .smaller = true := by decide
def e1203536682270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1203536682270 : Closed e1203536682270 ∧ code e1203536682270 = 5601583193374 := by decide
theorem cert_e1203536682270 : check e1203536682270 [[],[],[]] .smaller = true := by decide
def e1203536682438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1203536682438 : Closed e1203536682438 ∧ code e1203536682438 = 5601583193542 := by decide
theorem cert_e1203536682438 : check e1203536682438 [[],[],[]] .smaller = true := by decide
def e1203536682550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1203536682550 : Closed e1203536682550 ∧ code e1203536682550 = 5601583193654 := by decide
theorem cert_e1203536682550 : check e1203536682550 [[],[],[]] .smaller = true := by decide
def e1203536682554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1203536682554 : Closed e1203536682554 ∧ code e1203536682554 = 5601583193658 := by decide
theorem cert_e1203536682554 : check e1203536682554 [[],[],[]] .smaller = true := by decide
def e1203536682638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1203536682638 : Closed e1203536682638 ∧ code e1203536682638 = 5601583193742 := by decide
theorem cert_e1203536682638 : check e1203536682638 [[],[],[]] .smaller = true := by decide
def e1203536682694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1203536682694 : Closed e1203536682694 ∧ code e1203536682694 = 5601583193798 := by decide
theorem cert_e1203536682694 : check e1203536682694 [[],[],[]] .smaller = true := by decide
def e1203536684830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1203536684830 : Closed e1203536684830 ∧ code e1203536684830 = 5601583195934 := by decide
theorem cert_e1203536684830 : check e1203536684830 [[],[],[]] .smaller = true := by decide
def e1203536684942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1203536684942 : Closed e1203536684942 ∧ code e1203536684942 = 5601583196046 := by decide
theorem cert_e1203536684942 : check e1203536684942 [[],[],[]] .smaller = true := by decide
def e1203536687902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1203536687902 : Closed e1203536687902 ∧ code e1203536687902 = 5601583199006 := by decide
theorem cert_e1203536687902 : check e1203536687902 [[],[],[]] .smaller = true := by decide
def e1203536688070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1203536688070 : Closed e1203536688070 ∧ code e1203536688070 = 5601583199174 := by decide
theorem cert_e1203536688070 : check e1203536688070 [[],[],[]] .smaller = true := by decide
def e1203536689550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1203536689550 : Closed e1203536689550 ∧ code e1203536689550 = 5601583200654 := by decide
theorem cert_e1203536689550 : check e1203536689550 [[],[],[]] .smaller = true := by decide
def e1203536689606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1203536689606 : Closed e1203536689606 ∧ code e1203536689606 = 5601583200710 := by decide
theorem cert_e1203536689606 : check e1203536689606 [[],[],[]] .smaller = true := by decide
def e1204073231898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073231898 : Closed e1204073231898 ∧ code e1204073231898 = 5602119743002 := by decide
private def t_e1204073231898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073231898 : ¬ IsSelfInterpreter e1204073231898 :=
  wSource (t := t_e1204073231898) (replay_sound (ps := []) (t := e1204073231898) (by decide)) (by decide)
def e1204073248282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073248282 : Closed e1204073248282 ∧ code e1204073248282 = 5602119759386 := by decide
private def t_e1204073248282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073248282 : ¬ IsSelfInterpreter e1204073248282 :=
  wSource (t := t_e1204073248282) (replay_sound (ps := []) (t := e1204073248282) (by decide)) (by decide)
def e1204073362970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073362970 : Closed e1204073362970 ∧ code e1204073362970 = 5602119874074 := by decide
private def t_e1204073362970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073362970 : ¬ IsSelfInterpreter e1204073362970 :=
  wSource (t := t_e1204073362970) (replay_sound (ps := []) (t := e1204073362970) (by decide)) (by decide)
def e1204073387546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073387546 : Closed e1204073387546 ∧ code e1204073387546 = 5602119898650 := by decide
private def t_e1204073387546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073387546 : ¬ IsSelfInterpreter e1204073387546 :=
  wSource (t := t_e1204073387546) (replay_sound (ps := []) (t := e1204073387546) (by decide)) (by decide)
def e1204073444890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073444890 : Closed e1204073444890 ∧ code e1204073444890 = 5602119955994 := by decide
private def t_e1204073444890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073444890 : ¬ IsSelfInterpreter e1204073444890 :=
  wSource (t := t_e1204073444890) (replay_sound (ps := []) (t := e1204073444890) (by decide)) (by decide)
def e1204073453082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204073453082 : Closed e1204073453082 ∧ code e1204073453082 = 5602119964186 := by decide
private def t_e1204073453082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204073453082 : ¬ IsSelfInterpreter e1204073453082 :=
  wSource (t := t_e1204073453082) (replay_sound (ps := []) (t := e1204073453082) (by decide)) (by decide)
def e1204074018330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204074018330 : Closed e1204074018330 ∧ code e1204074018330 = 5602120529434 := by decide
private def t_e1204074018330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204074018330 : ¬ IsSelfInterpreter e1204074018330 :=
  wSource (t := t_e1204074018330) (replay_sound (ps := []) (t := e1204074018330) (by decide)) (by decide)
def e1204074034714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204074034714 : Closed e1204074034714 ∧ code e1204074034714 = 5602120545818 := by decide
private def t_e1204074034714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204074034714 : ¬ IsSelfInterpreter e1204074034714 :=
  wSource (t := t_e1204074034714) (replay_sound (ps := []) (t := e1204074034714) (by decide)) (by decide)
def e1204074804762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204074804762 : Closed e1204074804762 ∧ code e1204074804762 = 5602121315866 := by decide
private def t_e1204074804762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204074804762 : ¬ IsSelfInterpreter e1204074804762 :=
  wSource (t := t_e1204074804762) (replay_sound (ps := []) (t := e1204074804762) (by decide)) (by decide)
def e1204074829338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204074829338 : Closed e1204074829338 ∧ code e1204074829338 = 5602121340442 := by decide
private def t_e1204074829338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204074829338 : ¬ IsSelfInterpreter e1204074829338 :=
  wSource (t := t_e1204074829338) (replay_sound (ps := []) (t := e1204074829338) (by decide)) (by decide)
def e1204075214362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204075214362 : Closed e1204075214362 ∧ code e1204075214362 = 5602121725466 := by decide
private def t_e1204075214362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204075214362 : ¬ IsSelfInterpreter e1204075214362 :=
  wSource (t := t_e1204075214362) (replay_sound (ps := []) (t := e1204075214362) (by decide)) (by decide)
def e1204075222554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204075222554 : Closed e1204075222554 ∧ code e1204075222554 = 5602121733658 := by decide
private def t_e1204075222554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204075222554 : ¬ IsSelfInterpreter e1204075222554 :=
  wSource (t := t_e1204075222554) (replay_sound (ps := []) (t := e1204075222554) (by decide)) (by decide)
def e1204118318618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118318618 : Closed e1204118318618 ∧ code e1204118318618 = 5602164829722 := by decide
private def t_e1204118318618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118318618 : ¬ IsSelfInterpreter e1204118318618 :=
  wSource (t := t_e1204118318618) (replay_sound (ps := []) (t := e1204118318618) (by decide)) (by decide)
def e1204118320666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118320666 : Closed e1204118320666 ∧ code e1204118320666 = 5602164831770 := by decide
private def t_e1204118320666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118320666 : ¬ IsSelfInterpreter e1204118320666 :=
  wSource (t := t_e1204118320666) (replay_sound (ps := []) (t := e1204118320666) (by decide)) (by decide)
def e1204118335002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118335002 : Closed e1204118335002 ∧ code e1204118335002 = 5602164846106 := by decide
private def t_e1204118335002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118335002 : ¬ IsSelfInterpreter e1204118335002 :=
  wSource (t := t_e1204118335002) (replay_sound (ps := []) (t := e1204118335002) (by decide)) (by decide)
def e1204118338074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118338074 : Closed e1204118338074 ∧ code e1204118338074 = 5602164849178 := by decide
private def t_e1204118338074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118338074 : ¬ IsSelfInterpreter e1204118338074 :=
  wSource (t := t_e1204118338074) (replay_sound (ps := []) (t := e1204118338074) (by decide)) (by decide)
def e1204118345242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118345242 : Closed e1204118345242 ∧ code e1204118345242 = 5602164856346 := by decide
private def t_e1204118345242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118345242 : ¬ IsSelfInterpreter e1204118345242 :=
  wSource (t := t_e1204118345242) (replay_sound (ps := []) (t := e1204118345242) (by decide)) (by decide)
def e1204118346266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118346266 : Closed e1204118346266 ∧ code e1204118346266 = 5602164857370 := by decide
private def t_e1204118346266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118346266 : ¬ IsSelfInterpreter e1204118346266 :=
  wSource (t := t_e1204118346266) (replay_sound (ps := []) (t := e1204118346266) (by decide)) (by decide)
def e1204118416922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118416922 : Closed e1204118416922 ∧ code e1204118416922 = 5602164928026 := by decide
private def t_e1204118416922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118416922 : ¬ IsSelfInterpreter e1204118416922 :=
  wSource (t := t_e1204118416922) (replay_sound (ps := []) (t := e1204118416922) (by decide)) (by decide)
def e1204118418970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118418970 : Closed e1204118418970 ∧ code e1204118418970 = 5602164930074 := by decide
private def t_e1204118418970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118418970 : ¬ IsSelfInterpreter e1204118418970 :=
  wSource (t := t_e1204118418970) (replay_sound (ps := []) (t := e1204118418970) (by decide)) (by decide)
def e1204118515226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118515226 : Closed e1204118515226 ∧ code e1204118515226 = 5602165026330 := by decide
private def t_e1204118515226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118515226 : ¬ IsSelfInterpreter e1204118515226 :=
  wSource (t := t_e1204118515226) (replay_sound (ps := []) (t := e1204118515226) (by decide)) (by decide)
def e1204118518298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118518298 : Closed e1204118518298 ∧ code e1204118518298 = 5602165029402 := by decide
private def t_e1204118518298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118518298 : ¬ IsSelfInterpreter e1204118518298 :=
  wSource (t := t_e1204118518298) (replay_sound (ps := []) (t := e1204118518298) (by decide)) (by decide)
def e1204118566426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118566426 : Closed e1204118566426 ∧ code e1204118566426 = 5602165077530 := by decide
private def t_e1204118566426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118566426 : ¬ IsSelfInterpreter e1204118566426 :=
  wSource (t := t_e1204118566426) (replay_sound (ps := []) (t := e1204118566426) (by decide)) (by decide)
def e1204118567450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204118567450 : Closed e1204118567450 ∧ code e1204118567450 = 5602165078554 := by decide
private def t_e1204118567450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204118567450 : ¬ IsSelfInterpreter e1204118567450 :=
  wSource (t := t_e1204118567450) (replay_sound (ps := []) (t := e1204118567450) (by decide)) (by decide)
def e1204137343514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137343514 : Closed e1204137343514 ∧ code e1204137343514 = 5602183854618 := by decide
private def t_e1204137343514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137343514 : ¬ IsSelfInterpreter e1204137343514 :=
  wSource (t := t_e1204137343514) (replay_sound (ps := []) (t := e1204137343514) (by decide)) (by decide)
def e1204137351706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137351706 : Closed e1204137351706 ∧ code e1204137351706 = 5602183862810 := by decide
private def t_e1204137351706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137351706 : ¬ IsSelfInterpreter e1204137351706 :=
  wSource (t := t_e1204137351706) (replay_sound (ps := []) (t := e1204137351706) (by decide)) (by decide)
def e1204137409050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137409050 : Closed e1204137409050 ∧ code e1204137409050 = 5602183920154 := by decide
private def t_e1204137409050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137409050 : ¬ IsSelfInterpreter e1204137409050 :=
  wSource (t := t_e1204137409050) (replay_sound (ps := []) (t := e1204137409050) (by decide)) (by decide)
def e1204137421338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137421338 : Closed e1204137421338 ∧ code e1204137421338 = 5602183932442 := by decide
private def t_e1204137421338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137421338 : ¬ IsSelfInterpreter e1204137421338 :=
  wSource (t := t_e1204137421338) (replay_sound (ps := []) (t := e1204137421338) (by decide)) (by decide)
def e1204137450010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137450010 : Closed e1204137450010 ∧ code e1204137450010 = 5602183961114 := by decide
private def t_e1204137450010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137450010 : ¬ IsSelfInterpreter e1204137450010 :=
  wSource (t := t_e1204137450010) (replay_sound (ps := []) (t := e1204137450010) (by decide)) (by decide)
def e1204137454106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137454106 : Closed e1204137454106 ∧ code e1204137454106 = 5602183965210 := by decide
private def t_e1204137454106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137454106 : ¬ IsSelfInterpreter e1204137454106 :=
  wSource (t := t_e1204137454106) (replay_sound (ps := []) (t := e1204137454106) (by decide)) (by decide)
def e1204137736730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137736730 : Closed e1204137736730 ∧ code e1204137736730 = 5602184247834 := by decide
private def t_e1204137736730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137736730 : ¬ IsSelfInterpreter e1204137736730 :=
  wSource (t := t_e1204137736730) (replay_sound (ps := []) (t := e1204137736730) (by decide)) (by decide)
def e1204137744922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204137744922 : Closed e1204137744922 ∧ code e1204137744922 = 5602184256026 := by decide
private def t_e1204137744922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204137744922 : ¬ IsSelfInterpreter e1204137744922 :=
  wSource (t := t_e1204137744922) (replay_sound (ps := []) (t := e1204137744922) (by decide)) (by decide)
def e1204138129946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204138129946 : Closed e1204138129946 ∧ code e1204138129946 = 5602184641050 := by decide
private def t_e1204138129946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204138129946 : ¬ IsSelfInterpreter e1204138129946 :=
  wSource (t := t_e1204138129946) (replay_sound (ps := []) (t := e1204138129946) (by decide)) (by decide)
def e1204138142234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204138142234 : Closed e1204138142234 ∧ code e1204138142234 = 5602184653338 := by decide
private def t_e1204138142234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204138142234 : ¬ IsSelfInterpreter e1204138142234 :=
  wSource (t := t_e1204138142234) (replay_sound (ps := []) (t := e1204138142234) (by decide)) (by decide)
def e1204138334746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204138334746 : Closed e1204138334746 ∧ code e1204138334746 = 5602184845850 := by decide
private def t_e1204138334746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204138334746 : ¬ IsSelfInterpreter e1204138334746 :=
  wSource (t := t_e1204138334746) (replay_sound (ps := []) (t := e1204138334746) (by decide)) (by decide)
def e1204138338842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204138338842 : Closed e1204138338842 ∧ code e1204138338842 = 5602184849946 := by decide
private def t_e1204138338842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204138338842 : ¬ IsSelfInterpreter e1204138338842 :=
  wSource (t := t_e1204138338842) (replay_sound (ps := []) (t := e1204138338842) (by decide)) (by decide)
def e1204151873050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151873050 : Closed e1204151873050 ∧ code e1204151873050 = 5602198384154 := by decide
private def t_e1204151873050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151873050 : ¬ IsSelfInterpreter e1204151873050 :=
  wSource (t := t_e1204151873050) (replay_sound (ps := []) (t := e1204151873050) (by decide)) (by decide)
def e1204151875098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151875098 : Closed e1204151875098 ∧ code e1204151875098 = 5602198386202 := by decide
private def t_e1204151875098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151875098 : ¬ IsSelfInterpreter e1204151875098 :=
  wSource (t := t_e1204151875098) (replay_sound (ps := []) (t := e1204151875098) (by decide)) (by decide)
def e1204151889434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151889434 : Closed e1204151889434 ∧ code e1204151889434 = 5602198400538 := by decide
private def t_e1204151889434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151889434 : ¬ IsSelfInterpreter e1204151889434 :=
  wSource (t := t_e1204151889434) (replay_sound (ps := []) (t := e1204151889434) (by decide)) (by decide)
def e1204151892506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151892506 : Closed e1204151892506 ∧ code e1204151892506 = 5602198403610 := by decide
private def t_e1204151892506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151892506 : ¬ IsSelfInterpreter e1204151892506 :=
  wSource (t := t_e1204151892506) (replay_sound (ps := []) (t := e1204151892506) (by decide)) (by decide)
def e1204151899674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151899674 : Closed e1204151899674 ∧ code e1204151899674 = 5602198410778 := by decide
private def t_e1204151899674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151899674 : ¬ IsSelfInterpreter e1204151899674 :=
  wSource (t := t_e1204151899674) (replay_sound (ps := []) (t := e1204151899674) (by decide)) (by decide)
def e1204151900698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151900698 : Closed e1204151900698 ∧ code e1204151900698 = 5602198411802 := by decide
private def t_e1204151900698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151900698 : ¬ IsSelfInterpreter e1204151900698 :=
  wSource (t := t_e1204151900698) (replay_sound (ps := []) (t := e1204151900698) (by decide)) (by decide)
def e1204151971354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151971354 : Closed e1204151971354 ∧ code e1204151971354 = 5602198482458 := by decide
private def t_e1204151971354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151971354 : ¬ IsSelfInterpreter e1204151971354 :=
  wSource (t := t_e1204151971354) (replay_sound (ps := []) (t := e1204151971354) (by decide)) (by decide)
def e1204151973402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204151973402 : Closed e1204151973402 ∧ code e1204151973402 = 5602198484506 := by decide
private def t_e1204151973402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204151973402 : ¬ IsSelfInterpreter e1204151973402 :=
  wSource (t := t_e1204151973402) (replay_sound (ps := []) (t := e1204151973402) (by decide)) (by decide)
def e1204152069658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204152069658 : Closed e1204152069658 ∧ code e1204152069658 = 5602198580762 := by decide
private def t_e1204152069658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204152069658 : ¬ IsSelfInterpreter e1204152069658 :=
  wSource (t := t_e1204152069658) (replay_sound (ps := []) (t := e1204152069658) (by decide)) (by decide)
def e1204152072730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204152072730 : Closed e1204152072730 ∧ code e1204152072730 = 5602198583834 := by decide
private def t_e1204152072730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204152072730 : ¬ IsSelfInterpreter e1204152072730 :=
  wSource (t := t_e1204152072730) (replay_sound (ps := []) (t := e1204152072730) (by decide)) (by decide)
def e1204152120858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204152120858 : Closed e1204152120858 ∧ code e1204152120858 = 5602198631962 := by decide
private def t_e1204152120858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204152120858 : ¬ IsSelfInterpreter e1204152120858 :=
  wSource (t := t_e1204152120858) (replay_sound (ps := []) (t := e1204152120858) (by decide)) (by decide)
def e1204152121882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204152121882 : Closed e1204152121882 ∧ code e1204152121882 = 5602198632986 := by decide
private def t_e1204152121882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204152121882 : ¬ IsSelfInterpreter e1204152121882 :=
  wSource (t := t_e1204152121882) (replay_sound (ps := []) (t := e1204152121882) (by decide)) (by decide)
def e1204224768026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204224768026 : Closed e1204224768026 ∧ code e1204224768026 = 5602271279130 := by decide
theorem cert_e1204224768026 : check e1204224768026 [[]] .width = true := by decide
def e1204225425606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204225425606 : Closed e1204225425606 ∧ code e1204225425606 = 5602271936710 := by decide
theorem cert_e1204225425606 : check e1204225425606 [[]] .width = true := by decide
def e1204225456154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204225456154 : Closed e1204225456154 ∧ code e1204225456154 = 5602271967258 := by decide
theorem cert_e1204225456154 : check e1204225456154 [[]] .width = true := by decide
def e1204225491142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204225491142 : Closed e1204225491142 ∧ code e1204225491142 = 5602272002246 := by decide
theorem cert_e1204225491142 : check e1204225491142 [[]] .width = true := by decide
def e1204225685530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204225685530 : Closed e1204225685530 ∧ code e1204225685530 = 5602272196634 := by decide
theorem cert_e1204225685530 : check e1204225685530 [[]] .width = true := by decide
def e1204225949894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204225949894 : Closed e1204225949894 ∧ code e1204225949894 = 5602272460998 := by decide
theorem cert_e1204225949894 : check e1204225949894 [[]] .width = true := by decide
def e1204226037786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204226037786 : Closed e1204226037786 ∧ code e1204226037786 = 5602272548890 := by decide
theorem cert_e1204226037786 : check e1204226037786 [[]] .width = true := by decide
def e1204226048198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204226048198 : Closed e1204226048198 ∧ code e1204226048198 = 5602272559302 := by decide
theorem cert_e1204226048198 : check e1204226048198 [[]] .width = true := by decide
def e1204226152474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204226152474 : Closed e1204226152474 ∧ code e1204226152474 = 5602272663578 := by decide
theorem cert_e1204226152474 : check e1204226152474 [[]] .width = true := by decide
def e1204226156570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204226156570 : Closed e1204226156570 ∧ code e1204226156570 = 5602272667674 := by decide
theorem cert_e1204226156570 : check e1204226156570 [[]] .width = true := by decide
def e1204226242586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204226242586 : Closed e1204226242586 ∧ code e1204226242586 = 5602272753690 := by decide
theorem cert_e1204226242586 : check e1204226242586 [[]] .width = true := by decide
def e1204226277574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204226277574 : Closed e1204226277574 ∧ code e1204226277574 = 5602272788678 := by decide
theorem cert_e1204226277574 : check e1204226277574 [[]] .width = true := by decide
def e1204226299930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204226299930 : Closed e1204226299930 ∧ code e1204226299930 = 5602272811034 := by decide
theorem cert_e1204226299930 : check e1204226299930 [[]] .width = true := by decide
def e1204226310342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204226310342 : Closed e1204226310342 ∧ code e1204226310342 = 5602272821446 := by decide
theorem cert_e1204226310342 : check e1204226310342 [[]] .width = true := by decide
def e1204228571334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204228571334 : Closed e1204228571334 ∧ code e1204228571334 = 5602275082438 := by decide
theorem cert_e1204228571334 : check e1204228571334 [[]] .width = true := by decide
def e1204228601882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204228601882 : Closed e1204228601882 ∧ code e1204228601882 = 5602275112986 := by decide
theorem cert_e1204228601882 : check e1204228601882 [[]] .width = true := by decide
def e1204228636870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204228636870 : Closed e1204228636870 ∧ code e1204228636870 = 5602275147974 := by decide
theorem cert_e1204228636870 : check e1204228636870 [[]] .width = true := by decide
def e1204231717062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204231717062 : Closed e1204231717062 ∧ code e1204231717062 = 5602278228166 := by decide
theorem cert_e1204231717062 : check e1204231717062 [[]] .width = true := by decide
def e1204231804954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204231804954 : Closed e1204231804954 ∧ code e1204231804954 = 5602278316058 := by decide
theorem cert_e1204231804954 : check e1204231804954 [[]] .width = true := by decide
def e1204231815366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204231815366 : Closed e1204231815366 ∧ code e1204231815366 = 5602278326470 := by decide
theorem cert_e1204231815366 : check e1204231815366 [[]] .width = true := by decide
def e1204233320474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204233320474 : Closed e1204233320474 ∧ code e1204233320474 = 5602279831578 := by decide
theorem cert_e1204233320474 : check e1204233320474 [[]] .width = true := by decide
def e1204233355462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204233355462 : Closed e1204233355462 ∧ code e1204233355462 = 5602279866566 := by decide
theorem cert_e1204233355462 : check e1204233355462 [[]] .width = true := by decide
def e1204233377818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204233377818 : Closed e1204233377818 ∧ code e1204233377818 = 5602279888922 := by decide
theorem cert_e1204233377818 : check e1204233377818 [[]] .width = true := by decide
def e1204233388230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1204233388230 : Closed e1204233388230 ∧ code e1204233388230 = 5602279899334 := by decide
theorem cert_e1204233388230 : check e1204233388230 [[]] .width = true := by decide
def e1204319645210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319645210 : Closed e1204319645210 ∧ code e1204319645210 = 5602366156314 := by decide
private def t_e1204319645210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319645210 : ¬ IsSelfInterpreter e1204319645210 :=
  wSource (t := t_e1204319645210) (replay_sound (ps := []) (t := e1204319645210) (by decide)) (by decide)
def e1204319647258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319647258 : Closed e1204319647258 ∧ code e1204319647258 = 5602366158362 := by decide
private def t_e1204319647258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319647258 : ¬ IsSelfInterpreter e1204319647258 :=
  wSource (t := t_e1204319647258) (replay_sound (ps := []) (t := e1204319647258) (by decide)) (by decide)
def e1204319661594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319661594 : Closed e1204319661594 ∧ code e1204319661594 = 5602366172698 := by decide
private def t_e1204319661594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319661594 : ¬ IsSelfInterpreter e1204319661594 :=
  wSource (t := t_e1204319661594) (replay_sound (ps := []) (t := e1204319661594) (by decide)) (by decide)
def e1204319664666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319664666 : Closed e1204319664666 ∧ code e1204319664666 = 5602366175770 := by decide
private def t_e1204319664666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319664666 : ¬ IsSelfInterpreter e1204319664666 :=
  wSource (t := t_e1204319664666) (replay_sound (ps := []) (t := e1204319664666) (by decide)) (by decide)
def e1204319671834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319671834 : Closed e1204319671834 ∧ code e1204319671834 = 5602366182938 := by decide
private def t_e1204319671834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319671834 : ¬ IsSelfInterpreter e1204319671834 :=
  wSource (t := t_e1204319671834) (replay_sound (ps := []) (t := e1204319671834) (by decide)) (by decide)
def e1204319672858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319672858 : Closed e1204319672858 ∧ code e1204319672858 = 5602366183962 := by decide
private def t_e1204319672858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319672858 : ¬ IsSelfInterpreter e1204319672858 :=
  wSource (t := t_e1204319672858) (replay_sound (ps := []) (t := e1204319672858) (by decide)) (by decide)
def e1204319743514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319743514 : Closed e1204319743514 ∧ code e1204319743514 = 5602366254618 := by decide
private def t_e1204319743514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319743514 : ¬ IsSelfInterpreter e1204319743514 :=
  wSource (t := t_e1204319743514) (replay_sound (ps := []) (t := e1204319743514) (by decide)) (by decide)
def e1204319745562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319745562 : Closed e1204319745562 ∧ code e1204319745562 = 5602366256666 := by decide
private def t_e1204319745562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319745562 : ¬ IsSelfInterpreter e1204319745562 :=
  wSource (t := t_e1204319745562) (replay_sound (ps := []) (t := e1204319745562) (by decide)) (by decide)
def e1204319841818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319841818 : Closed e1204319841818 ∧ code e1204319841818 = 5602366352922 := by decide
private def t_e1204319841818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319841818 : ¬ IsSelfInterpreter e1204319841818 :=
  wSource (t := t_e1204319841818) (replay_sound (ps := []) (t := e1204319841818) (by decide)) (by decide)
def e1204319844890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319844890 : Closed e1204319844890 ∧ code e1204319844890 = 5602366355994 := by decide
private def t_e1204319844890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319844890 : ¬ IsSelfInterpreter e1204319844890 :=
  wSource (t := t_e1204319844890) (replay_sound (ps := []) (t := e1204319844890) (by decide)) (by decide)
def e1204319893018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319893018 : Closed e1204319893018 ∧ code e1204319893018 = 5602366404122 := by decide
private def t_e1204319893018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319893018 : ¬ IsSelfInterpreter e1204319893018 :=
  wSource (t := t_e1204319893018) (replay_sound (ps := []) (t := e1204319893018) (by decide)) (by decide)
def e1204319894042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204319894042 : Closed e1204319894042 ∧ code e1204319894042 = 5602366405146 := by decide
private def t_e1204319894042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204319894042 : ¬ IsSelfInterpreter e1204319894042 :=
  wSource (t := t_e1204319894042) (replay_sound (ps := []) (t := e1204319894042) (by decide)) (by decide)
def e1204402826606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1204402826606 : Closed e1204402826606 ∧ code e1204402826606 = 5602449337710 := by decide
theorem cert_e1204402826606 : check e1204402826606 [[],[]] .smaller = true := by decide
def e1204402826614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1204402826614 : Closed e1204402826614 ∧ code e1204402826614 = 5602449337718 := by decide
theorem cert_e1204402826614 : check e1204402826614 [[],[]] .smaller = true := by decide
def e1204402826670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1204402826670 : Closed e1204402826670 ∧ code e1204402826670 = 5602449337774 := by decide
theorem cert_e1204402826670 : check e1204402826670 [[],[]] .smaller = true := by decide
def e1204402826682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1204402826682 : Closed e1204402826682 ∧ code e1204402826682 = 5602449337786 := by decide
theorem cert_e1204402826682 : check e1204402826682 [[],[]] .smaller = true := by decide
def e1204402826710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1204402826710 : Closed e1204402826710 ∧ code e1204402826710 = 5602449337814 := by decide
theorem cert_e1204402826710 : check e1204402826710 [[],[]] .smaller = true := by decide
def e1204402826714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1204402826714 : Closed e1204402826714 ∧ code e1204402826714 = 5602449337818 := by decide
theorem cert_e1204402826714 : check e1204402826714 [[],[]] .smaller = true := by decide
def e1204402826926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1204402826926 : Closed e1204402826926 ∧ code e1204402826926 = 5602449338030 := by decide
theorem cert_e1204402826926 : check e1204402826926 [[],[]] .smaller = true := by decide
def e1204402826938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1204402826938 : Closed e1204402826938 ∧ code e1204402826938 = 5602449338042 := by decide
theorem cert_e1204402826938 : check e1204402826938 [[],[]] .smaller = true := by decide
def e1204402826986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1204402826986 : Closed e1204402826986 ∧ code e1204402826986 = 5602449338090 := by decide
theorem cert_e1204402826986 : check e1204402826986 [[],[]] .smaller = true := by decide
def e1204402827094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1204402827094 : Closed e1204402827094 ∧ code e1204402827094 = 5602449338198 := by decide
theorem cert_e1204402827094 : check e1204402827094 [[],[]] .smaller = true := by decide
def e1204402827098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1204402827098 : Closed e1204402827098 ∧ code e1204402827098 = 5602449338202 := by decide
theorem cert_e1204402827098 : check e1204402827098 [[],[]] .smaller = true := by decide
def e1204402827114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1204402827114 : Closed e1204402827114 ∧ code e1204402827114 = 5602449338218 := by decide
theorem cert_e1204402827114 : check e1204402827114 [[],[]] .smaller = true := by decide
def e1204402828142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1204402828142 : Closed e1204402828142 ∧ code e1204402828142 = 5602449339246 := by decide
theorem cert_e1204402828142 : check e1204402828142 [[],[]] .smaller = true := by decide
def e1204402828150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1204402828150 : Closed e1204402828150 ∧ code e1204402828150 = 5602449339254 := by decide
theorem cert_e1204402828150 : check e1204402828150 [[],[]] .smaller = true := by decide
def e1204402828206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1204402828206 : Closed e1204402828206 ∧ code e1204402828206 = 5602449339310 := by decide
theorem cert_e1204402828206 : check e1204402828206 [[],[]] .smaller = true := by decide
def e1204402828218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1204402828218 : Closed e1204402828218 ∧ code e1204402828218 = 5602449339322 := by decide
theorem cert_e1204402828218 : check e1204402828218 [[],[]] .smaller = true := by decide
def e1204402828246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1204402828246 : Closed e1204402828246 ∧ code e1204402828246 = 5602449339350 := by decide
theorem cert_e1204402828246 : check e1204402828246 [[],[]] .smaller = true := by decide
def e1204402828250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1204402828250 : Closed e1204402828250 ∧ code e1204402828250 = 5602449339354 := by decide
theorem cert_e1204402828250 : check e1204402828250 [[],[]] .smaller = true := by decide
def e1204402828526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1204402828526 : Closed e1204402828526 ∧ code e1204402828526 = 5602449339630 := by decide
theorem cert_e1204402828526 : check e1204402828526 [[],[]] .smaller = true := by decide
def e1204402828534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1204402828534 : Closed e1204402828534 ∧ code e1204402828534 = 5602449339638 := by decide
theorem cert_e1204402828534 : check e1204402828534 [[],[]] .smaller = true := by decide
def e1204402828910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1204402828910 : Closed e1204402828910 ∧ code e1204402828910 = 5602449340014 := by decide
theorem cert_e1204402828910 : check e1204402828910 [[],[]] .smaller = true := by decide
def e1204402828922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1204402828922 : Closed e1204402828922 ∧ code e1204402828922 = 5602449340026 := by decide
theorem cert_e1204402828922 : check e1204402828922 [[],[]] .smaller = true := by decide
def e1204402829110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1204402829110 : Closed e1204402829110 ∧ code e1204402829110 = 5602449340214 := by decide
theorem cert_e1204402829110 : check e1204402829110 [[],[]] .smaller = true := by decide
def e1204402829114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1204402829114 : Closed e1204402829114 ∧ code e1204402829114 = 5602449340218 := by decide
theorem cert_e1204402829114 : check e1204402829114 [[],[]] .smaller = true := by decide
def e1204402829742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1204402829742 : Closed e1204402829742 ∧ code e1204402829742 = 5602449340846 := by decide
theorem cert_e1204402829742 : check e1204402829742 [[],[]] .smaller = true := by decide
def e1204402829754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1204402829754 : Closed e1204402829754 ∧ code e1204402829754 = 5602449340858 := by decide
theorem cert_e1204402829754 : check e1204402829754 [[],[]] .smaller = true := by decide
def e1204402829802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1204402829802 : Closed e1204402829802 ∧ code e1204402829802 = 5602449340906 := by decide
theorem cert_e1204402829802 : check e1204402829802 [[],[]] .smaller = true := by decide
def e1204402829934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1204402829934 : Closed e1204402829934 ∧ code e1204402829934 = 5602449341038 := by decide
theorem cert_e1204402829934 : check e1204402829934 [[],[]] .smaller = true := by decide
def e1204402829946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1204402829946 : Closed e1204402829946 ∧ code e1204402829946 = 5602449341050 := by decide
theorem cert_e1204402829946 : check e1204402829946 [[],[]] .smaller = true := by decide
def e1204402830234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1204402830234 : Closed e1204402830234 ∧ code e1204402830234 = 5602449341338 := by decide
theorem cert_e1204402830234 : check e1204402830234 [[],[]] .smaller = true := by decide
def e1204402830550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1204402830550 : Closed e1204402830550 ∧ code e1204402830550 = 5602449341654 := by decide
theorem cert_e1204402830550 : check e1204402830550 [[],[]] .smaller = true := by decide
def e1204402830554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1204402830554 : Closed e1204402830554 ∧ code e1204402830554 = 5602449341658 := by decide
theorem cert_e1204402830554 : check e1204402830554 [[],[]] .smaller = true := by decide
def e1204402830570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1204402830570 : Closed e1204402830570 ∧ code e1204402830570 = 5602449341674 := by decide
theorem cert_e1204402830570 : check e1204402830570 [[],[]] .smaller = true := by decide
def e1204402830646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1204402830646 : Closed e1204402830646 ∧ code e1204402830646 = 5602449341750 := by decide
theorem cert_e1204402830646 : check e1204402830646 [[],[]] .smaller = true := by decide
def e1204402830650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1204402830650 : Closed e1204402830650 ∧ code e1204402830650 = 5602449341754 := by decide
theorem cert_e1204402830650 : check e1204402830650 [[],[]] .smaller = true := by decide
def e1204402830746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1204402830746 : Closed e1204402830746 ∧ code e1204402830746 = 5602449341850 := by decide
theorem cert_e1204402830746 : check e1204402830746 [[],[]] .smaller = true := by decide
def e1204402834286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204402834286 : Closed e1204402834286 ∧ code e1204402834286 = 5602449345390 := by decide
theorem cert_e1204402834286 : check e1204402834286 [[],[]] .smaller = true := by decide
def e1204402834294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204402834294 : Closed e1204402834294 ∧ code e1204402834294 = 5602449345398 := by decide
theorem cert_e1204402834294 : check e1204402834294 [[],[]] .smaller = true := by decide
end Blc.Floor42
