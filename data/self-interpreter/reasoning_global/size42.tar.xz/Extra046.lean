import Batch046
import ExtraBase
namespace Blc.Floor42.Extra046
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1124661464302 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem ex_e1124661464302 : ¬ IsSelfInterpreter e1124661464302 := by
  intro he
  have hp := replay_sound (t := e1124661464302) (u := t_e1124661464302) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1124661464302
private def t_e1124661464310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1124661464310 : ¬ IsSelfInterpreter e1124661464310 := by
  intro he
  have hp := replay_sound (t := e1124661464310) (u := t_e1124661464310) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1124661464310
private def t_e1124661464886 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem ex_e1124661464886 : ¬ IsSelfInterpreter e1124661464886 := by
  intro he
  have hp := replay_sound (t := e1124661464886) (u := t_e1124661464886) (ps := [[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) h
#print axioms ex_e1124661464886
private def t_e1124661464890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem ex_e1124661464890 : ¬ IsSelfInterpreter e1124661464890 := by
  intro he
  have hp := replay_sound (t := e1124661464890) (u := t_e1124661464890) (ps := [[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) h
#print axioms ex_e1124661464890
end Blc.Floor42.Extra046
