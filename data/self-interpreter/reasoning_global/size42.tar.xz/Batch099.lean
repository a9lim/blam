import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812280558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205812280558 : Closed e1205812280558 ∧ code e1205812280558 = 5603858791662 := by decide
theorem cert_e1205812280558 : check e1205812280558 [[],[]] .smaller = true := by decide
def e1205812280566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205812280566 : Closed e1205812280566 ∧ code e1205812280566 = 5603858791670 := by decide
theorem cert_e1205812280566 : check e1205812280566 [[],[]] .smaller = true := by decide
def e1205812280570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205812280570 : Closed e1205812280570 ∧ code e1205812280570 = 5603858791674 := by decide
theorem cert_e1205812280570 : check e1205812280570 [[],[]] .smaller = true := by decide
def e1205812280942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812280942 : Closed e1205812280942 ∧ code e1205812280942 = 5603858792046 := by decide
theorem cert_e1205812280942 : check e1205812280942 [[],[]] .smaller = true := by decide
def e1205812280950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1205812280950 : Closed e1205812280950 ∧ code e1205812280950 = 5603858792054 := by decide
theorem cert_e1205812280950 : check e1205812280950 [[],[]] .smaller = true := by decide
def e1205812280954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812280954 : Closed e1205812280954 ∧ code e1205812280954 = 5603858792058 := by decide
theorem cert_e1205812280954 : check e1205812280954 [[],[]] .smaller = true := by decide
def e1205812281142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812281142 : Closed e1205812281142 ∧ code e1205812281142 = 5603858792246 := by decide
theorem cert_e1205812281142 : check e1205812281142 [[],[]] .three = true := by decide
def e1205812281146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812281146 : Closed e1205812281146 ∧ code e1205812281146 = 5603858792250 := by decide
theorem cert_e1205812281146 : check e1205812281146 [[],[]] .three = true := by decide
def e1205812303550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e1205812303550 : Closed e1205812303550 ∧ code e1205812303550 = 5603858814654 := by decide
theorem cert_e1205812303550 : check e1205812303550 [[],[]] .three = true := by decide
def e1205812303582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1205812303582 : Closed e1205812303582 ∧ code e1205812303582 = 5603858814686 := by decide
theorem cert_e1205812303582 : check e1205812303582 [[],[]] .smaller = true := by decide
def e1205812303598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1205812303598 : Closed e1205812303598 ∧ code e1205812303598 = 5603858814702 := by decide
theorem cert_e1205812303598 : check e1205812303598 [[],[]] .smaller = true := by decide
def e1205812303606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1205812303606 : Closed e1205812303606 ∧ code e1205812303606 = 5603858814710 := by decide
theorem cert_e1205812303606 : check e1205812303606 [[],[]] .smaller = true := by decide
def e1205812303610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e1205812303610 : Closed e1205812303610 ∧ code e1205812303610 = 5603858814714 := by decide
theorem cert_e1205812303610 : check e1205812303610 [[],[]] .three = true := by decide
def e1205812303710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1205812303710 : Closed e1205812303710 ∧ code e1205812303710 = 5603858814814 := by decide
theorem cert_e1205812303710 : check e1205812303710 [[],[]] .smaller = true := by decide
def e1205812303738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1205812303738 : Closed e1205812303738 ∧ code e1205812303738 = 5603858814842 := by decide
theorem cert_e1205812303738 : check e1205812303738 [[],[]] .smaller = true := by decide
def e1205812303790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1205812303790 : Closed e1205812303790 ∧ code e1205812303790 = 5603858814894 := by decide
theorem cert_e1205812303790 : check e1205812303790 [[],[]] .smaller = true := by decide
def e1205812303802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1205812303802 : Closed e1205812303802 ∧ code e1205812303802 = 5603858814906 := by decide
theorem cert_e1205812303802 : check e1205812303802 [[],[]] .smaller = true := by decide
def e1205812303830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1205812303830 : Closed e1205812303830 ∧ code e1205812303830 = 5603858814934 := by decide
theorem cert_e1205812303830 : check e1205812303830 [[],[]] .smaller = true := by decide
def e1205812303834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1205812303834 : Closed e1205812303834 ∧ code e1205812303834 = 5603858814938 := by decide
theorem cert_e1205812303834 : check e1205812303834 [[],[]] .smaller = true := by decide
def e1205812303850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e1205812303850 : Closed e1205812303850 ∧ code e1205812303850 = 5603858814954 := by decide
theorem cert_e1205812303850 : check e1205812303850 [[],[]] .three = true := by decide
def e1205812304318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e1205812304318 : Closed e1205812304318 ∧ code e1205812304318 = 5603858815422 := by decide
theorem cert_e1205812304318 : check e1205812304318 [[],[]] .three = true := by decide
def e1205812304350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1205812304350 : Closed e1205812304350 ∧ code e1205812304350 = 5603858815454 := by decide
theorem cert_e1205812304350 : check e1205812304350 [[],[]] .smaller = true := by decide
def e1205812304366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1205812304366 : Closed e1205812304366 ∧ code e1205812304366 = 5603858815470 := by decide
theorem cert_e1205812304366 : check e1205812304366 [[],[]] .smaller = true := by decide
def e1205812304374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1205812304374 : Closed e1205812304374 ∧ code e1205812304374 = 5603858815478 := by decide
theorem cert_e1205812304374 : check e1205812304374 [[],[]] .smaller = true := by decide
def e1205812304378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e1205812304378 : Closed e1205812304378 ∧ code e1205812304378 = 5603858815482 := by decide
theorem cert_e1205812304378 : check e1205812304378 [[],[]] .three = true := by decide
def e1205812305118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205812305118 : Closed e1205812305118 ∧ code e1205812305118 = 5603858816222 := by decide
theorem cert_e1205812305118 : check e1205812305118 [[],[]] .smaller = true := by decide
def e1205812305146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205812305146 : Closed e1205812305146 ∧ code e1205812305146 = 5603858816250 := by decide
theorem cert_e1205812305146 : check e1205812305146 [[],[]] .smaller = true := by decide
def e1205812305518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812305518 : Closed e1205812305518 ∧ code e1205812305518 = 5603858816622 := by decide
theorem cert_e1205812305518 : check e1205812305518 [[],[]] .smaller = true := by decide
def e1205812305530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812305530 : Closed e1205812305530 ∧ code e1205812305530 = 5603858816634 := by decide
theorem cert_e1205812305530 : check e1205812305530 [[],[]] .smaller = true := by decide
def e1205812305718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812305718 : Closed e1205812305718 ∧ code e1205812305718 = 5603858816822 := by decide
theorem cert_e1205812305718 : check e1205812305718 [[],[]] .smaller = true := by decide
def e1205812305722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812305722 : Closed e1205812305722 ∧ code e1205812305722 = 5603858816826 := by decide
theorem cert_e1205812305722 : check e1205812305722 [[],[]] .smaller = true := by decide
def e1205812305818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812305818 : Closed e1205812305818 ∧ code e1205812305818 = 5603858816922 := by decide
theorem cert_e1205812305818 : check e1205812305818 [[],[]] .three = true := by decide
def e1205812317022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1205812317022 : Closed e1205812317022 ∧ code e1205812317022 = 5603858828126 := by decide
theorem cert_e1205812317022 : check e1205812317022 [[],[]] .smaller = true := by decide
def e1205812317038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205812317038 : Closed e1205812317038 ∧ code e1205812317038 = 5603858828142 := by decide
theorem cert_e1205812317038 : check e1205812317038 [[],[]] .smaller = true := by decide
def e1205812317046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205812317046 : Closed e1205812317046 ∧ code e1205812317046 = 5603858828150 := by decide
theorem cert_e1205812317046 : check e1205812317046 [[],[]] .smaller = true := by decide
def e1205812317050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1205812317050 : Closed e1205812317050 ∧ code e1205812317050 = 5603858828154 := by decide
theorem cert_e1205812317050 : check e1205812317050 [[],[]] .smaller = true := by decide
def e1205812317102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205812317102 : Closed e1205812317102 ∧ code e1205812317102 = 5603858828206 := by decide
theorem cert_e1205812317102 : check e1205812317102 [[],[]] .smaller = true := by decide
def e1205812317114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205812317114 : Closed e1205812317114 ∧ code e1205812317114 = 5603858828218 := by decide
theorem cert_e1205812317114 : check e1205812317114 [[],[]] .smaller = true := by decide
def e1205812317142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205812317142 : Closed e1205812317142 ∧ code e1205812317142 = 5603858828246 := by decide
theorem cert_e1205812317142 : check e1205812317142 [[],[]] .smaller = true := by decide
def e1205812317146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205812317146 : Closed e1205812317146 ∧ code e1205812317146 = 5603858828250 := by decide
theorem cert_e1205812317146 : check e1205812317146 [[],[]] .smaller = true := by decide
def e1205812317162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1205812317162 : Closed e1205812317162 ∧ code e1205812317162 = 5603858828266 := by decide
theorem cert_e1205812317162 : check e1205812317162 [[],[]] .smaller = true := by decide
def e1205812317406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205812317406 : Closed e1205812317406 ∧ code e1205812317406 = 5603858828510 := by decide
theorem cert_e1205812317406 : check e1205812317406 [[],[]] .smaller = true := by decide
def e1205812317422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205812317422 : Closed e1205812317422 ∧ code e1205812317422 = 5603858828526 := by decide
theorem cert_e1205812317422 : check e1205812317422 [[],[]] .smaller = true := by decide
def e1205812317430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205812317430 : Closed e1205812317430 ∧ code e1205812317430 = 5603858828534 := by decide
theorem cert_e1205812317430 : check e1205812317430 [[],[]] .smaller = true := by decide
def e1205812317434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205812317434 : Closed e1205812317434 ∧ code e1205812317434 = 5603858828538 := by decide
theorem cert_e1205812317434 : check e1205812317434 [[],[]] .smaller = true := by decide
def e1205812317806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812317806 : Closed e1205812317806 ∧ code e1205812317806 = 5603858828910 := by decide
theorem cert_e1205812317806 : check e1205812317806 [[],[]] .smaller = true := by decide
def e1205812317818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812317818 : Closed e1205812317818 ∧ code e1205812317818 = 5603858828922 := by decide
theorem cert_e1205812317818 : check e1205812317818 [[],[]] .smaller = true := by decide
def e1205812318006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812318006 : Closed e1205812318006 ∧ code e1205812318006 = 5603858829110 := by decide
theorem cert_e1205812318006 : check e1205812318006 [[],[]] .smaller = true := by decide
def e1205812318010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812318010 : Closed e1205812318010 ∧ code e1205812318010 = 5603858829114 := by decide
theorem cert_e1205812318010 : check e1205812318010 [[],[]] .smaller = true := by decide
def e1205812318106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812318106 : Closed e1205812318106 ∧ code e1205812318106 = 5603858829210 := by decide
theorem cert_e1205812318106 : check e1205812318106 [[],[]] .smaller = true := by decide
def e1205812323758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205812323758 : Closed e1205812323758 ∧ code e1205812323758 = 5603858834862 := by decide
theorem cert_e1205812323758 : check e1205812323758 [[],[]] .smaller = true := by decide
def e1205812323766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1205812323766 : Closed e1205812323766 ∧ code e1205812323766 = 5603858834870 := by decide
theorem cert_e1205812323766 : check e1205812323766 [[],[]] .smaller = true := by decide
def e1205812323770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205812323770 : Closed e1205812323770 ∧ code e1205812323770 = 5603858834874 := by decide
theorem cert_e1205812323770 : check e1205812323770 [[],[]] .smaller = true := by decide
def e1205812323798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1205812323798 : Closed e1205812323798 ∧ code e1205812323798 = 5603858834902 := by decide
theorem cert_e1205812323798 : check e1205812323798 [[],[]] .smaller = true := by decide
def e1205812323802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1205812323802 : Closed e1205812323802 ∧ code e1205812323802 = 5603858834906 := by decide
theorem cert_e1205812323802 : check e1205812323802 [[],[]] .smaller = true := by decide
def e1205812323818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205812323818 : Closed e1205812323818 ∧ code e1205812323818 = 5603858834922 := by decide
theorem cert_e1205812323818 : check e1205812323818 [[],[]] .smaller = true := by decide
def e1205812323950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812323950 : Closed e1205812323950 ∧ code e1205812323950 = 5603858835054 := by decide
theorem cert_e1205812323950 : check e1205812323950 [[],[]] .smaller = true := by decide
def e1205812323958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1205812323958 : Closed e1205812323958 ∧ code e1205812323958 = 5603858835062 := by decide
theorem cert_e1205812323958 : check e1205812323958 [[],[]] .smaller = true := by decide
def e1205812323962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812323962 : Closed e1205812323962 ∧ code e1205812323962 = 5603858835066 := by decide
theorem cert_e1205812323962 : check e1205812323962 [[],[]] .smaller = true := by decide
def e1205812324150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812324150 : Closed e1205812324150 ∧ code e1205812324150 = 5603858835254 := by decide
theorem cert_e1205812324150 : check e1205812324150 [[],[]] .smaller = true := by decide
def e1205812324154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812324154 : Closed e1205812324154 ∧ code e1205812324154 = 5603858835258 := by decide
theorem cert_e1205812324154 : check e1205812324154 [[],[]] .smaller = true := by decide
def e1205812324250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812324250 : Closed e1205812324250 ∧ code e1205812324250 = 5603858835354 := by decide
theorem cert_e1205812324250 : check e1205812324250 [[],[]] .smaller = true := by decide
def e1205812327126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205812327126 : Closed e1205812327126 ∧ code e1205812327126 = 5603858838230 := by decide
theorem cert_e1205812327126 : check e1205812327126 [[],[]] .three = true := by decide
def e1205812327130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205812327130 : Closed e1205812327130 ∧ code e1205812327130 = 5603858838234 := by decide
theorem cert_e1205812327130 : check e1205812327130 [[],[]] .three = true := by decide
def e1205812327146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205812327146 : Closed e1205812327146 ∧ code e1205812327146 = 5603858838250 := by decide
theorem cert_e1205812327146 : check e1205812327146 [[],[]] .three = true := by decide
def e1205812327222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812327222 : Closed e1205812327222 ∧ code e1205812327222 = 5603858838326 := by decide
theorem cert_e1205812327222 : check e1205812327222 [[],[]] .three = true := by decide
def e1205812327226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812327226 : Closed e1205812327226 ∧ code e1205812327226 = 5603858838330 := by decide
theorem cert_e1205812327226 : check e1205812327226 [[],[]] .three = true := by decide
def e1205812327322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812327322 : Closed e1205812327322 ∧ code e1205812327322 = 5603858838426 := by decide
theorem cert_e1205812327322 : check e1205812327322 [[],[]] .three = true := by decide
def e1205812770158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205812770158 : Closed e1205812770158 ∧ code e1205812770158 = 5603859281262 := by decide
theorem cert_e1205812770158 : check e1205812770158 [[],[]] .smaller = true := by decide
def e1205812770166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205812770166 : Closed e1205812770166 ∧ code e1205812770166 = 5603859281270 := by decide
theorem cert_e1205812770166 : check e1205812770166 [[],[]] .smaller = true := by decide
def e1205812770222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205812770222 : Closed e1205812770222 ∧ code e1205812770222 = 5603859281326 := by decide
theorem cert_e1205812770222 : check e1205812770222 [[],[]] .smaller = true := by decide
def e1205812770234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205812770234 : Closed e1205812770234 ∧ code e1205812770234 = 5603859281338 := by decide
theorem cert_e1205812770234 : check e1205812770234 [[],[]] .smaller = true := by decide
def e1205812770262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205812770262 : Closed e1205812770262 ∧ code e1205812770262 = 5603859281366 := by decide
theorem cert_e1205812770262 : check e1205812770262 [[],[]] .smaller = true := by decide
def e1205812770266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205812770266 : Closed e1205812770266 ∧ code e1205812770266 = 5603859281370 := by decide
theorem cert_e1205812770266 : check e1205812770266 [[],[]] .smaller = true := by decide
def e1205812770478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1205812770478 : Closed e1205812770478 ∧ code e1205812770478 = 5603859281582 := by decide
theorem cert_e1205812770478 : check e1205812770478 [[],[]] .smaller = true := by decide
def e1205812770490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1205812770490 : Closed e1205812770490 ∧ code e1205812770490 = 5603859281594 := by decide
theorem cert_e1205812770490 : check e1205812770490 [[],[]] .smaller = true := by decide
def e1205812770538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1205812770538 : Closed e1205812770538 ∧ code e1205812770538 = 5603859281642 := by decide
theorem cert_e1205812770538 : check e1205812770538 [[],[]] .smaller = true := by decide
def e1205812770646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1205812770646 : Closed e1205812770646 ∧ code e1205812770646 = 5603859281750 := by decide
theorem cert_e1205812770646 : check e1205812770646 [[],[]] .smaller = true := by decide
def e1205812770650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1205812770650 : Closed e1205812770650 ∧ code e1205812770650 = 5603859281754 := by decide
theorem cert_e1205812770650 : check e1205812770650 [[],[]] .smaller = true := by decide
def e1205812770666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1205812770666 : Closed e1205812770666 ∧ code e1205812770666 = 5603859281770 := by decide
theorem cert_e1205812770666 : check e1205812770666 [[],[]] .smaller = true := by decide
def e1205812771502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1205812771502 : Closed e1205812771502 ∧ code e1205812771502 = 5603859282606 := by decide
theorem cert_e1205812771502 : check e1205812771502 [[],[]] .smaller = true := by decide
def e1205812771514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1205812771514 : Closed e1205812771514 ∧ code e1205812771514 = 5603859282618 := by decide
theorem cert_e1205812771514 : check e1205812771514 [[],[]] .smaller = true := by decide
def e1205812771562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1205812771562 : Closed e1205812771562 ∧ code e1205812771562 = 5603859282666 := by decide
theorem cert_e1205812771562 : check e1205812771562 [[],[]] .smaller = true := by decide
def e1205812771754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1205812771754 : Closed e1205812771754 ∧ code e1205812771754 = 5603859282858 := by decide
theorem cert_e1205812771754 : check e1205812771754 [[],[]] .smaller = true := by decide
def e1205812772182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1205812772182 : Closed e1205812772182 ∧ code e1205812772182 = 5603859283286 := by decide
theorem cert_e1205812772182 : check e1205812772182 [[],[]] .smaller = true := by decide
def e1205812772186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1205812772186 : Closed e1205812772186 ∧ code e1205812772186 = 5603859283290 := by decide
theorem cert_e1205812772186 : check e1205812772186 [[],[]] .smaller = true := by decide
def e1205812772202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1205812772202 : Closed e1205812772202 ∧ code e1205812772202 = 5603859283306 := by decide
theorem cert_e1205812772202 : check e1205812772202 [[],[]] .smaller = true := by decide
def e1205812772266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1205812772266 : Closed e1205812772266 ∧ code e1205812772266 = 5603859283370 := by decide
theorem cert_e1205812772266 : check e1205812772266 [[],[]] .smaller = true := by decide
def e1205812774622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e1205812774622 : Closed e1205812774622 ∧ code e1205812774622 = 5603859285726 := by decide
theorem cert_e1205812774622 : check e1205812774622 [[],[]] .three = true := by decide
def e1205812774646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e1205812774646 : Closed e1205812774646 ∧ code e1205812774646 = 5603859285750 := by decide
theorem cert_e1205812774646 : check e1205812774646 [[],[]] .three = true := by decide
def e1205812774750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e1205812774750 : Closed e1205812774750 ∧ code e1205812774750 = 5603859285854 := by decide
theorem cert_e1205812774750 : check e1205812774750 [[],[]] .three = true := by decide
def e1205812774766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1205812774766 : Closed e1205812774766 ∧ code e1205812774766 = 5603859285870 := by decide
theorem cert_e1205812774766 : check e1205812774766 [[],[]] .smaller = true := by decide
def e1205812774774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1205812774774 : Closed e1205812774774 ∧ code e1205812774774 = 5603859285878 := by decide
theorem cert_e1205812774774 : check e1205812774774 [[],[]] .smaller = true := by decide
def e1205812774778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e1205812774778 : Closed e1205812774778 ∧ code e1205812774778 = 5603859285882 := by decide
theorem cert_e1205812774778 : check e1205812774778 [[],[]] .three = true := by decide
def e1205812774838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1205812774838 : Closed e1205812774838 ∧ code e1205812774838 = 5603859285942 := by decide
theorem cert_e1205812774838 : check e1205812774838 [[],[]] .smaller = true := by decide
def e1205812774870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e1205812774870 : Closed e1205812774870 ∧ code e1205812774870 = 5603859285974 := by decide
theorem cert_e1205812774870 : check e1205812774870 [[],[]] .three = true := by decide
def e1205812774874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e1205812774874 : Closed e1205812774874 ∧ code e1205812774874 = 5603859285978 := by decide
theorem cert_e1205812774874 : check e1205812774874 [[],[]] .three = true := by decide
def e1205812776302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1205812776302 : Closed e1205812776302 ∧ code e1205812776302 = 5603859287406 := by decide
theorem cert_e1205812776302 : check e1205812776302 [[],[]] .smaller = true := by decide
def e1205812776310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1205812776310 : Closed e1205812776310 ∧ code e1205812776310 = 5603859287414 := by decide
theorem cert_e1205812776310 : check e1205812776310 [[],[]] .smaller = true := by decide
def e1205812776366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1205812776366 : Closed e1205812776366 ∧ code e1205812776366 = 5603859287470 := by decide
theorem cert_e1205812776366 : check e1205812776366 [[],[]] .smaller = true := by decide
def e1205812776378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1205812776378 : Closed e1205812776378 ∧ code e1205812776378 = 5603859287482 := by decide
theorem cert_e1205812776378 : check e1205812776378 [[],[]] .smaller = true := by decide
def e1205812776406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1205812776406 : Closed e1205812776406 ∧ code e1205812776406 = 5603859287510 := by decide
theorem cert_e1205812776406 : check e1205812776406 [[],[]] .smaller = true := by decide
def e1205812776410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1205812776410 : Closed e1205812776410 ∧ code e1205812776410 = 5603859287514 := by decide
theorem cert_e1205812776410 : check e1205812776410 [[],[]] .smaller = true := by decide
def e1205812776622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205812776622 : Closed e1205812776622 ∧ code e1205812776622 = 5603859287726 := by decide
theorem cert_e1205812776622 : check e1205812776622 [[],[]] .smaller = true := by decide
def e1205812776634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205812776634 : Closed e1205812776634 ∧ code e1205812776634 = 5603859287738 := by decide
theorem cert_e1205812776634 : check e1205812776634 [[],[]] .smaller = true := by decide
def e1205812776682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1205812776682 : Closed e1205812776682 ∧ code e1205812776682 = 5603859287786 := by decide
theorem cert_e1205812776682 : check e1205812776682 [[],[]] .smaller = true := by decide
def e1205812776790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205812776790 : Closed e1205812776790 ∧ code e1205812776790 = 5603859287894 := by decide
theorem cert_e1205812776790 : check e1205812776790 [[],[]] .smaller = true := by decide
def e1205812776794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205812776794 : Closed e1205812776794 ∧ code e1205812776794 = 5603859287898 := by decide
theorem cert_e1205812776794 : check e1205812776794 [[],[]] .smaller = true := by decide
def e1205812776810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1205812776810 : Closed e1205812776810 ∧ code e1205812776810 = 5603859287914 := by decide
theorem cert_e1205812776810 : check e1205812776810 [[],[]] .smaller = true := by decide
def e1205812777438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1205812777438 : Closed e1205812777438 ∧ code e1205812777438 = 5603859288542 := by decide
theorem cert_e1205812777438 : check e1205812777438 [[],[]] .three = true := by decide
def e1205812777462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1205812777462 : Closed e1205812777462 ∧ code e1205812777462 = 5603859288566 := by decide
theorem cert_e1205812777462 : check e1205812777462 [[],[]] .three = true := by decide
def e1205812777838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205812777838 : Closed e1205812777838 ∧ code e1205812777838 = 5603859288942 := by decide
theorem cert_e1205812777838 : check e1205812777838 [[],[]] .smaller = true := by decide
def e1205812777846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205812777846 : Closed e1205812777846 ∧ code e1205812777846 = 5603859288950 := by decide
theorem cert_e1205812777846 : check e1205812777846 [[],[]] .smaller = true := by decide
def e1205812777902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205812777902 : Closed e1205812777902 ∧ code e1205812777902 = 5603859289006 := by decide
theorem cert_e1205812777902 : check e1205812777902 [[],[]] .smaller = true := by decide
def e1205812777914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205812777914 : Closed e1205812777914 ∧ code e1205812777914 = 5603859289018 := by decide
theorem cert_e1205812777914 : check e1205812777914 [[],[]] .smaller = true := by decide
def e1205812777942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205812777942 : Closed e1205812777942 ∧ code e1205812777942 = 5603859289046 := by decide
theorem cert_e1205812777942 : check e1205812777942 [[],[]] .smaller = true := by decide
def e1205812777946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205812777946 : Closed e1205812777946 ∧ code e1205812777946 = 5603859289050 := by decide
theorem cert_e1205812777946 : check e1205812777946 [[],[]] .smaller = true := by decide
def e1205812778222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812778222 : Closed e1205812778222 ∧ code e1205812778222 = 5603859289326 := by decide
theorem cert_e1205812778222 : check e1205812778222 [[],[]] .smaller = true := by decide
def e1205812778230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812778230 : Closed e1205812778230 ∧ code e1205812778230 = 5603859289334 := by decide
theorem cert_e1205812778230 : check e1205812778230 [[],[]] .smaller = true := by decide
def e1205812778558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1205812778558 : Closed e1205812778558 ∧ code e1205812778558 = 5603859289662 := by decide
theorem cert_e1205812778558 : check e1205812778558 [[],[]] .three = true := by decide
def e1205812778606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812778606 : Closed e1205812778606 ∧ code e1205812778606 = 5603859289710 := by decide
theorem cert_e1205812778606 : check e1205812778606 [[],[]] .smaller = true := by decide
def e1205812778618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812778618 : Closed e1205812778618 ∧ code e1205812778618 = 5603859289722 := by decide
theorem cert_e1205812778618 : check e1205812778618 [[],[]] .smaller = true := by decide
def e1205812778806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812778806 : Closed e1205812778806 ∧ code e1205812778806 = 5603859289910 := by decide
theorem cert_e1205812778806 : check e1205812778806 [[],[]] .smaller = true := by decide
def e1205812778810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812778810 : Closed e1205812778810 ∧ code e1205812778810 = 5603859289914 := by decide
theorem cert_e1205812778810 : check e1205812778810 [[],[]] .smaller = true := by decide
def e1205812778894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1205812778894 : Closed e1205812778894 ∧ code e1205812778894 = 5603859289998 := by decide
theorem cert_e1205812778894 : check e1205812778894 [[],[]] .three = true := by decide
def e1205812779230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1205812779230 : Closed e1205812779230 ∧ code e1205812779230 = 5603859290334 := by decide
theorem cert_e1205812779230 : check e1205812779230 [[],[]] .three = true := by decide
def e1205812779246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1205812779246 : Closed e1205812779246 ∧ code e1205812779246 = 5603859290350 := by decide
theorem cert_e1205812779246 : check e1205812779246 [[],[]] .smaller = true := by decide
def e1205812779254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1205812779254 : Closed e1205812779254 ∧ code e1205812779254 = 5603859290358 := by decide
theorem cert_e1205812779254 : check e1205812779254 [[],[]] .smaller = true := by decide
def e1205812779258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1205812779258 : Closed e1205812779258 ∧ code e1205812779258 = 5603859290362 := by decide
theorem cert_e1205812779258 : check e1205812779258 [[],[]] .three = true := by decide
def e1205812779438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1205812779438 : Closed e1205812779438 ∧ code e1205812779438 = 5603859290542 := by decide
theorem cert_e1205812779438 : check e1205812779438 [[],[]] .smaller = true := by decide
def e1205812779450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1205812779450 : Closed e1205812779450 ∧ code e1205812779450 = 5603859290554 := by decide
theorem cert_e1205812779450 : check e1205812779450 [[],[]] .smaller = true := by decide
def e1205812779498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1205812779498 : Closed e1205812779498 ∧ code e1205812779498 = 5603859290602 := by decide
theorem cert_e1205812779498 : check e1205812779498 [[],[]] .smaller = true := by decide
def e1205812779582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1205812779582 : Closed e1205812779582 ∧ code e1205812779582 = 5603859290686 := by decide
theorem cert_e1205812779582 : check e1205812779582 [[],[]] .three = true := by decide
def e1205812779630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812779630 : Closed e1205812779630 ∧ code e1205812779630 = 5603859290734 := by decide
theorem cert_e1205812779630 : check e1205812779630 [[],[]] .smaller = true := by decide
def e1205812779642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812779642 : Closed e1205812779642 ∧ code e1205812779642 = 5603859290746 := by decide
theorem cert_e1205812779642 : check e1205812779642 [[],[]] .smaller = true := by decide
def e1205812779806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1205812779806 : Closed e1205812779806 ∧ code e1205812779806 = 5603859290910 := by decide
theorem cert_e1205812779806 : check e1205812779806 [[],[]] .smaller = true := by decide
def e1205812779918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1205812779918 : Closed e1205812779918 ∧ code e1205812779918 = 5603859291022 := by decide
theorem cert_e1205812779918 : check e1205812779918 [[],[]] .smaller = true := by decide
def e1205812779930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812779930 : Closed e1205812779930 ∧ code e1205812779930 = 5603859291034 := by decide
theorem cert_e1205812779930 : check e1205812779930 [[],[]] .smaller = true := by decide
def e1205812779974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1205812779974 : Closed e1205812779974 ∧ code e1205812779974 = 5603859291078 := by decide
theorem cert_e1205812779974 : check e1205812779974 [[],[]] .three = true := by decide
def e1205812779998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e1205812779998 : Closed e1205812779998 ∧ code e1205812779998 = 5603859291102 := by decide
theorem cert_e1205812779998 : check e1205812779998 [[],[]] .three = true := by decide
def e1205812780150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1205812780150 : Closed e1205812780150 ∧ code e1205812780150 = 5603859291254 := by decide
theorem cert_e1205812780150 : check e1205812780150 [[],[]] .smaller = true := by decide
def e1205812780246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1205812780246 : Closed e1205812780246 ∧ code e1205812780246 = 5603859291350 := by decide
theorem cert_e1205812780246 : check e1205812780246 [[],[]] .smaller = true := by decide
def e1205812780250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1205812780250 : Closed e1205812780250 ∧ code e1205812780250 = 5603859291354 := by decide
theorem cert_e1205812780250 : check e1205812780250 [[],[]] .smaller = true := by decide
def e1205812780266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1205812780266 : Closed e1205812780266 ∧ code e1205812780266 = 5603859291370 := by decide
theorem cert_e1205812780266 : check e1205812780266 [[],[]] .smaller = true := by decide
def e1205812780342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812780342 : Closed e1205812780342 ∧ code e1205812780342 = 5603859291446 := by decide
theorem cert_e1205812780342 : check e1205812780342 [[],[]] .smaller = true := by decide
def e1205812780346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812780346 : Closed e1205812780346 ∧ code e1205812780346 = 5603859291450 := by decide
theorem cert_e1205812780346 : check e1205812780346 [[],[]] .smaller = true := by decide
def e1205812780430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1205812780430 : Closed e1205812780430 ∧ code e1205812780430 = 5603859291534 := by decide
theorem cert_e1205812780430 : check e1205812780430 [[],[]] .smaller = true := by decide
def e1205812780442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812780442 : Closed e1205812780442 ∧ code e1205812780442 = 5603859291546 := by decide
theorem cert_e1205812780442 : check e1205812780442 [[],[]] .smaller = true := by decide
def e1205812780510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e1205812780510 : Closed e1205812780510 ∧ code e1205812780510 = 5603859291614 := by decide
theorem cert_e1205812780510 : check e1205812780510 [[],[]] .three = true := by decide
def e1205812780526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e1205812780526 : Closed e1205812780526 ∧ code e1205812780526 = 5603859291630 := by decide
theorem cert_e1205812780526 : check e1205812780526 [[],[]] .three = true := by decide
def e1205812780598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1205812780598 : Closed e1205812780598 ∧ code e1205812780598 = 5603859291702 := by decide
theorem cert_e1205812780598 : check e1205812780598 [[],[]] .three = true := by decide
def e1205812780602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1205812780602 : Closed e1205812780602 ∧ code e1205812780602 = 5603859291706 := by decide
theorem cert_e1205812780602 : check e1205812780602 [[],[]] .three = true := by decide
def e1205812780686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1205812780686 : Closed e1205812780686 ∧ code e1205812780686 = 5603859291790 := by decide
theorem cert_e1205812780686 : check e1205812780686 [[],[]] .three = true := by decide
def e1205812780742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1205812780742 : Closed e1205812780742 ∧ code e1205812780742 = 5603859291846 := by decide
theorem cert_e1205812780742 : check e1205812780742 [[],[]] .three = true := by decide
def e1205812780766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e1205812780766 : Closed e1205812780766 ∧ code e1205812780766 = 5603859291870 := by decide
theorem cert_e1205812780766 : check e1205812780766 [[],[]] .three = true := by decide
def e1205812780782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e1205812780782 : Closed e1205812780782 ∧ code e1205812780782 = 5603859291886 := by decide
theorem cert_e1205812780782 : check e1205812780782 [[],[]] .three = true := by decide
def e1205812780790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e1205812780790 : Closed e1205812780790 ∧ code e1205812780790 = 5603859291894 := by decide
theorem cert_e1205812780790 : check e1205812780790 [[],[]] .three = true := by decide
def e1205812781918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e1205812781918 : Closed e1205812781918 ∧ code e1205812781918 = 5603859293022 := by decide
theorem cert_e1205812781918 : check e1205812781918 [[],[]] .three = true := by decide
def e1205812781934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1205812781934 : Closed e1205812781934 ∧ code e1205812781934 = 5603859293038 := by decide
theorem cert_e1205812781934 : check e1205812781934 [[],[]] .smaller = true := by decide
def e1205812781942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1205812781942 : Closed e1205812781942 ∧ code e1205812781942 = 5603859293046 := by decide
theorem cert_e1205812781942 : check e1205812781942 [[],[]] .smaller = true := by decide
end Blc.Floor42
