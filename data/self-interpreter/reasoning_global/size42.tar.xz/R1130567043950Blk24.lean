import R1130567043950Data
namespace Certgen.R1130567043950
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl288 : FloorIndex.rangeOK validState 288 5 = true := by decide +kernel
end Certgen.R1130567043950
