import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205627098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211205627098 : Closed e1211205627098 ∧ code e1211205627098 = 5609252138202 := by decide
theorem cert_e1211205627098 : check e1211205627098 [[],[]] .chain = true := by decide
def e1211205627114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211205627114 : Closed e1211205627114 ∧ code e1211205627114 = 5609252138218 := by decide
theorem cert_e1211205627114 : check e1211205627114 [[],[]] .chain = true := by decide
def e1211205627142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205627142 : Closed e1211205627142 ∧ code e1211205627142 = 5609252138246 := by decide
theorem cert_e1211205627142 : check e1211205627142 [[],[]] .chain = true := by decide
def e1211205627166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211205627166 : Closed e1211205627166 ∧ code e1211205627166 = 5609252138270 := by decide
theorem cert_e1211205627166 : check e1211205627166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205627190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205627190 : Closed e1211205627190 ∧ code e1211205627190 = 5609252138294 := by decide
theorem cert_e1211205627190 : check e1211205627190 [[],[]] .chain = true := by decide
def e1211205627194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205627194 : Closed e1211205627194 ∧ code e1211205627194 = 5609252138298 := by decide
theorem cert_e1211205627194 : check e1211205627194 [[],[]] .chain = true := by decide
def e1211205627266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205627266 : Closed e1211205627266 ∧ code e1211205627266 = 5609252138370 := by decide
theorem cert_e1211205627266 : check e1211205627266 [[],[]] .chain = true := by decide
def e1211205627278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211205627278 : Closed e1211205627278 ∧ code e1211205627278 = 5609252138382 := by decide
theorem cert_e1211205627278 : check e1211205627278 [[],[]] .chain = true := by decide
def e1211205627290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205627290 : Closed e1211205627290 ∧ code e1211205627290 = 5609252138394 := by decide
theorem cert_e1211205627290 : check e1211205627290 [[],[]] .chain = true := by decide
def e1211205627334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211205627334 : Closed e1211205627334 ∧ code e1211205627334 = 5609252138438 := by decide
theorem cert_e1211205627334 : check e1211205627334 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205627402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211205627402 : Closed e1211205627402 ∧ code e1211205627402 = 5609252138506 := by decide
theorem cert_e1211205627402 : check e1211205627402 [[],[]] .chain = true := by decide
def e1211205627446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205627446 : Closed e1211205627446 ∧ code e1211205627446 = 5609252138550 := by decide
theorem cert_e1211205627446 : check e1211205627446 [[],[]] .chain = true := by decide
def e1211205627450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205627450 : Closed e1211205627450 ∧ code e1211205627450 = 5609252138554 := by decide
theorem cert_e1211205627450 : check e1211205627450 [[],[]] .chain = true := by decide
def e1211205627498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211205627498 : Closed e1211205627498 ∧ code e1211205627498 = 5609252138602 := by decide
theorem cert_e1211205627498 : check e1211205627498 [[],[]] .chain = true := by decide
def e1211205627522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205627522 : Closed e1211205627522 ∧ code e1211205627522 = 5609252138626 := by decide
theorem cert_e1211205627522 : check e1211205627522 [[],[]] .chain = true := by decide
def e1211205627534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205627534 : Closed e1211205627534 ∧ code e1211205627534 = 5609252138638 := by decide
theorem cert_e1211205627534 : check e1211205627534 [[],[]] .chain = true := by decide
def e1211205627546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205627546 : Closed e1211205627546 ∧ code e1211205627546 = 5609252138650 := by decide
theorem cert_e1211205627546 : check e1211205627546 [[],[]] .chain = true := by decide
def e1211205627590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205627590 : Closed e1211205627590 ∧ code e1211205627590 = 5609252138694 := by decide
theorem cert_e1211205627590 : check e1211205627590 [[],[]] .chain = true := by decide
def e1211205627674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211205627674 : Closed e1211205627674 ∧ code e1211205627674 = 5609252138778 := by decide
theorem cert_e1211205627674 : check e1211205627674 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205627718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211205627718 : Closed e1211205627718 ∧ code e1211205627718 = 5609252138822 := by decide
theorem cert_e1211205627718 : check e1211205627718 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205627934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211205627934 : Closed e1211205627934 ∧ code e1211205627934 = 5609252139038 := by decide
theorem cert_e1211205627934 : check e1211205627934 [[],[]] .chain = true := by decide
def e1211205628102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211205628102 : Closed e1211205628102 ∧ code e1211205628102 = 5609252139206 := by decide
theorem cert_e1211205628102 : check e1211205628102 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205628126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205628126 : Closed e1211205628126 ∧ code e1211205628126 = 5609252139230 := by decide
theorem cert_e1211205628126 : check e1211205628126 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205628130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211205628130 : Closed e1211205628130 ∧ code e1211205628130 = 5609252139234 := by decide
theorem cert_e1211205628130 : check e1211205628130 [[],[]] .chain = true := by decide
def e1211205628142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205628142 : Closed e1211205628142 ∧ code e1211205628142 = 5609252139246 := by decide
theorem cert_e1211205628142 : check e1211205628142 [[],[]] .chain = true := by decide
def e1211205628150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205628150 : Closed e1211205628150 ∧ code e1211205628150 = 5609252139254 := by decide
theorem cert_e1211205628150 : check e1211205628150 [[],[]] .chain = true := by decide
def e1211205628154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205628154 : Closed e1211205628154 ∧ code e1211205628154 = 5609252139258 := by decide
theorem cert_e1211205628154 : check e1211205628154 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205628630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211205628630 : Closed e1211205628630 ∧ code e1211205628630 = 5609252139734 := by decide
theorem cert_e1211205628630 : check e1211205628630 [[],[]] .chain = true := by decide
def e1211205628634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211205628634 : Closed e1211205628634 ∧ code e1211205628634 = 5609252139738 := by decide
theorem cert_e1211205628634 : check e1211205628634 [[],[]] .chain = true := by decide
def e1211205628650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211205628650 : Closed e1211205628650 ∧ code e1211205628650 = 5609252139754 := by decide
theorem cert_e1211205628650 : check e1211205628650 [[],[]] .chain = true := by decide
def e1211205628678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205628678 : Closed e1211205628678 ∧ code e1211205628678 = 5609252139782 := by decide
theorem cert_e1211205628678 : check e1211205628678 [[],[]] .chain = true := by decide
def e1211205628702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211205628702 : Closed e1211205628702 ∧ code e1211205628702 = 5609252139806 := by decide
theorem cert_e1211205628702 : check e1211205628702 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205628726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205628726 : Closed e1211205628726 ∧ code e1211205628726 = 5609252139830 := by decide
theorem cert_e1211205628726 : check e1211205628726 [[],[]] .chain = true := by decide
def e1211205628730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205628730 : Closed e1211205628730 ∧ code e1211205628730 = 5609252139834 := by decide
theorem cert_e1211205628730 : check e1211205628730 [[],[]] .chain = true := by decide
def e1211205628802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205628802 : Closed e1211205628802 ∧ code e1211205628802 = 5609252139906 := by decide
theorem cert_e1211205628802 : check e1211205628802 [[],[]] .chain = true := by decide
def e1211205628814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211205628814 : Closed e1211205628814 ∧ code e1211205628814 = 5609252139918 := by decide
theorem cert_e1211205628814 : check e1211205628814 [[],[]] .chain = true := by decide
def e1211205628826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205628826 : Closed e1211205628826 ∧ code e1211205628826 = 5609252139930 := by decide
theorem cert_e1211205628826 : check e1211205628826 [[],[]] .chain = true := by decide
def e1211205628870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211205628870 : Closed e1211205628870 ∧ code e1211205628870 = 5609252139974 := by decide
theorem cert_e1211205628870 : check e1211205628870 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205630070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205630070 : Closed e1211205630070 ∧ code e1211205630070 = 5609252141174 := by decide
theorem cert_e1211205630070 : check e1211205630070 [[],[]] .chain = true := by decide
def e1211205630314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211205630314 : Closed e1211205630314 ∧ code e1211205630314 = 5609252141418 := by decide
theorem cert_e1211205630314 : check e1211205630314 [[],[]] .chain = true := by decide
def e1211205630338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205630338 : Closed e1211205630338 ∧ code e1211205630338 = 5609252141442 := by decide
theorem cert_e1211205630338 : check e1211205630338 [[],[]] .chain = true := by decide
def e1211205630350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205630350 : Closed e1211205630350 ∧ code e1211205630350 = 5609252141454 := by decide
theorem cert_e1211205630350 : check e1211205630350 [[],[]] .chain = true := by decide
def e1211205630362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205630362 : Closed e1211205630362 ∧ code e1211205630362 = 5609252141466 := by decide
theorem cert_e1211205630362 : check e1211205630362 [[],[]] .chain = true := by decide
def e1211205630406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205630406 : Closed e1211205630406 ∧ code e1211205630406 = 5609252141510 := by decide
theorem cert_e1211205630406 : check e1211205630406 [[],[]] .chain = true := by decide
def e1211205631030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205631030 : Closed e1211205631030 ∧ code e1211205631030 = 5609252142134 := by decide
theorem cert_e1211205631030 : check e1211205631030 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205631034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205631034 : Closed e1211205631034 ∧ code e1211205631034 = 5609252142138 := by decide
theorem cert_e1211205631034 : check e1211205631034 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205631174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205631174 : Closed e1211205631174 ∧ code e1211205631174 = 5609252142278 := by decide
theorem cert_e1211205631174 : check e1211205631174 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205650206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211205650206 : Closed e1211205650206 ∧ code e1211205650206 = 5609252161310 := by decide
private def t_e1211205650206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem cert_e1211205650206 : ¬ IsSelfInterpreter e1211205650206 :=
  wSource (t := t_e1211205650206) (replay_sound (ps := []) (t := e1211205650206) (by decide)) (by decide)
def e1211205650318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211205650318 : Closed e1211205650318 ∧ code e1211205650318 = 5609252161422 := by decide
private def t_e1211205650318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem cert_e1211205650318 : ¬ IsSelfInterpreter e1211205650318 :=
  wSource (t := t_e1211205650318) (replay_sound (ps := []) (t := e1211205650318) (by decide)) (by decide)
def e1211205654070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205654070 : Closed e1211205654070 ∧ code e1211205654070 = 5609252165174 := by decide
private def t_e1211205654070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem cert_e1211205654070 : ¬ IsSelfInterpreter e1211205654070 :=
  wSource (t := t_e1211205654070) (replay_sound (ps := []) (t := e1211205654070) (by decide)) (by decide)
def e1211205654074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205654074 : Closed e1211205654074 ∧ code e1211205654074 = 5609252165178 := by decide
private def t_e1211205654074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem cert_e1211205654074 : ¬ IsSelfInterpreter e1211205654074 :=
  wSource (t := t_e1211205654074) (replay_sound (ps := []) (t := e1211205654074) (by decide)) (by decide)
def e1211205654158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205654158 : Closed e1211205654158 ∧ code e1211205654158 = 5609252165262 := by decide
private def t_e1211205654158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem cert_e1211205654158 : ¬ IsSelfInterpreter e1211205654158 :=
  wSource (t := t_e1211205654158) (replay_sound (ps := []) (t := e1211205654158) (by decide)) (by decide)
def e1211205654214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205654214 : Closed e1211205654214 ∧ code e1211205654214 = 5609252165318 := by decide
private def t_e1211205654214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1211205654214 : ¬ IsSelfInterpreter e1211205654214 :=
  wSource (t := t_e1211205654214) (replay_sound (ps := []) (t := e1211205654214) (by decide)) (by decide)
def e1211205654298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211205654298 : Closed e1211205654298 ∧ code e1211205654298 = 5609252165402 := by decide
private def t_e1211205654298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem cert_e1211205654298 : ¬ IsSelfInterpreter e1211205654298 :=
  wSource (t := t_e1211205654298) (replay_sound (ps := []) (t := e1211205654298) (by decide)) (by decide)
def e1211205654342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211205654342 : Closed e1211205654342 ∧ code e1211205654342 = 5609252165446 := by decide
private def t_e1211205654342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem cert_e1211205654342 : ¬ IsSelfInterpreter e1211205654342 :=
  wSource (t := t_e1211205654342) (replay_sound (ps := []) (t := e1211205654342) (by decide)) (by decide)
def e1211205654638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205654638 : Closed e1211205654638 ∧ code e1211205654638 = 5609252165742 := by decide
private def t_e1211205654638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem cert_e1211205654638 : ¬ IsSelfInterpreter e1211205654638 :=
  wSource (t := t_e1211205654638) (replay_sound (ps := []) (t := e1211205654638) (by decide)) (by decide)
def e1211205654650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205654650 : Closed e1211205654650 ∧ code e1211205654650 = 5609252165754 := by decide
private def t_e1211205654650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem cert_e1211205654650 : ¬ IsSelfInterpreter e1211205654650 :=
  wSource (t := t_e1211205654650) (replay_sound (ps := []) (t := e1211205654650) (by decide)) (by decide)
def e1211205654926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205654926 : Closed e1211205654926 ∧ code e1211205654926 = 5609252166030 := by decide
private def t_e1211205654926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e1211205654926 : ¬ IsSelfInterpreter e1211205654926 :=
  wSource (t := t_e1211205654926) (replay_sound (ps := []) (t := e1211205654926) (by decide)) (by decide)
def e1211205654982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205654982 : Closed e1211205654982 ∧ code e1211205654982 = 5609252166086 := by decide
private def t_e1211205654982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e1211205654982 : ¬ IsSelfInterpreter e1211205654982 :=
  wSource (t := t_e1211205654982) (replay_sound (ps := []) (t := e1211205654982) (by decide)) (by decide)
def e1211205655606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205655606 : Closed e1211205655606 ∧ code e1211205655606 = 5609252166710 := by decide
private def t_e1211205655606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem cert_e1211205655606 : ¬ IsSelfInterpreter e1211205655606 :=
  wSource (t := t_e1211205655606) (replay_sound (ps := []) (t := e1211205655606) (by decide)) (by decide)
def e1211205655610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205655610 : Closed e1211205655610 ∧ code e1211205655610 = 5609252166714 := by decide
private def t_e1211205655610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem cert_e1211205655610 : ¬ IsSelfInterpreter e1211205655610 :=
  wSource (t := t_e1211205655610) (replay_sound (ps := []) (t := e1211205655610) (by decide)) (by decide)
def e1211205655750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205655750 : Closed e1211205655750 ∧ code e1211205655750 = 5609252166854 := by decide
private def t_e1211205655750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem cert_e1211205655750 : ¬ IsSelfInterpreter e1211205655750 :=
  wSource (t := t_e1211205655750) (replay_sound (ps := []) (t := e1211205655750) (by decide)) (by decide)
def e1211205967326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e1211205967326 : Closed e1211205967326 ∧ code e1211205967326 = 5609252478430 := by decide
theorem cert_e1211205967326 : check e1211205967326 [[],[]] .smaller = true := by decide
def e1211205967342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e1211205967342 : Closed e1211205967342 ∧ code e1211205967342 = 5609252478446 := by decide
theorem cert_e1211205967342 : check e1211205967342 [[],[]] .smaller = true := by decide
def e1211205967582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e1211205967582 : Closed e1211205967582 ∧ code e1211205967582 = 5609252478686 := by decide
theorem cert_e1211205967582 : check e1211205967582 [[],[]] .smaller = true := by decide
def e1211205967606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e1211205967606 : Closed e1211205967606 ∧ code e1211205967606 = 5609252478710 := by decide
theorem cert_e1211205967606 : check e1211205967606 [[],[]] .smaller = true := by decide
def e1211205967726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e1211205967726 : Closed e1211205967726 ∧ code e1211205967726 = 5609252478830 := by decide
theorem cert_e1211205967726 : check e1211205967726 [[],[]] .smaller = true := by decide
def e1211205967734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e1211205967734 : Closed e1211205967734 ∧ code e1211205967734 = 5609252478838 := by decide
theorem cert_e1211205967734 : check e1211205967734 [[],[]] .smaller = true := by decide
def e1211205972958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211205972958 : Closed e1211205972958 ∧ code e1211205972958 = 5609252484062 := by decide
theorem cert_e1211205972958 : check e1211205972958 [[],[]] .smaller = true := by decide
def e1211205972974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211205972974 : Closed e1211205972974 ∧ code e1211205972974 = 5609252484078 := by decide
theorem cert_e1211205972974 : check e1211205972974 [[],[]] .smaller = true := by decide
def e1211205974494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211205974494 : Closed e1211205974494 ∧ code e1211205974494 = 5609252485598 := by decide
theorem cert_e1211205974494 : check e1211205974494 [[],[]] .smaller = true := by decide
def e1211205974518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211205974518 : Closed e1211205974518 ∧ code e1211205974518 = 5609252485622 := by decide
theorem cert_e1211205974518 : check e1211205974518 [[],[]] .smaller = true := by decide
def e1211205975278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211205975278 : Closed e1211205975278 ∧ code e1211205975278 = 5609252486382 := by decide
theorem cert_e1211205975278 : check e1211205975278 [[],[]] .smaller = true := by decide
def e1211205975286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211205975286 : Closed e1211205975286 ∧ code e1211205975286 = 5609252486390 := by decide
theorem cert_e1211205975286 : check e1211205975286 [[],[]] .smaller = true := by decide
def e1211206032094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e1211206032094 : Closed e1211206032094 ∧ code e1211206032094 = 5609252543198 := by decide
theorem cert_e1211206032094 : check e1211206032094 [[],[]] .smaller = true := by decide
def e1211206032118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e1211206032118 : Closed e1211206032118 ∧ code e1211206032118 = 5609252543222 := by decide
theorem cert_e1211206032118 : check e1211206032118 [[],[]] .smaller = true := by decide
def e1211206032222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e1211206032222 : Closed e1211206032222 ∧ code e1211206032222 = 5609252543326 := by decide
theorem cert_e1211206032222 : check e1211206032222 [[],[]] .smaller = true := by decide
def e1211206032238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e1211206032238 : Closed e1211206032238 ∧ code e1211206032238 = 5609252543342 := by decide
theorem cert_e1211206032238 : check e1211206032238 [[],[]] .smaller = true := by decide
def e1211206032246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e1211206032246 : Closed e1211206032246 ∧ code e1211206032246 = 5609252543350 := by decide
theorem cert_e1211206032246 : check e1211206032246 [[],[]] .smaller = true := by decide
def e1211206032250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e1211206032250 : Closed e1211206032250 ∧ code e1211206032250 = 5609252543354 := by decide
theorem cert_e1211206032250 : check e1211206032250 [[],[]] .smaller = true := by decide
def e1211206032310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e1211206032310 : Closed e1211206032310 ∧ code e1211206032310 = 5609252543414 := by decide
theorem cert_e1211206032310 : check e1211206032310 [[],[]] .smaller = true := by decide
def e1211206032342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e1211206032342 : Closed e1211206032342 ∧ code e1211206032342 = 5609252543446 := by decide
theorem cert_e1211206032342 : check e1211206032342 [[],[]] .smaller = true := by decide
def e1211206032346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e1211206032346 : Closed e1211206032346 ∧ code e1211206032346 = 5609252543450 := by decide
theorem cert_e1211206032346 : check e1211206032346 [[],[]] .smaller = true := by decide
def e1211206032734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211206032734 : Closed e1211206032734 ∧ code e1211206032734 = 5609252543838 := by decide
theorem cert_e1211206032734 : check e1211206032734 [[],[]] .smaller = true := by decide
def e1211206032750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211206032750 : Closed e1211206032750 ∧ code e1211206032750 = 5609252543854 := by decide
theorem cert_e1211206032750 : check e1211206032750 [[],[]] .smaller = true := by decide
def e1211206032758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211206032758 : Closed e1211206032758 ∧ code e1211206032758 = 5609252543862 := by decide
theorem cert_e1211206032758 : check e1211206032758 [[],[]] .smaller = true := by decide
def e1211206032762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211206032762 : Closed e1211206032762 ∧ code e1211206032762 = 5609252543866 := by decide
theorem cert_e1211206032762 : check e1211206032762 [[],[]] .smaller = true := by decide
def e1211206032814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211206032814 : Closed e1211206032814 ∧ code e1211206032814 = 5609252543918 := by decide
theorem cert_e1211206032814 : check e1211206032814 [[],[]] .smaller = true := by decide
def e1211206032826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211206032826 : Closed e1211206032826 ∧ code e1211206032826 = 5609252543930 := by decide
theorem cert_e1211206032826 : check e1211206032826 [[],[]] .smaller = true := by decide
def e1211206032854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211206032854 : Closed e1211206032854 ∧ code e1211206032854 = 5609252543958 := by decide
theorem cert_e1211206032854 : check e1211206032854 [[],[]] .smaller = true := by decide
def e1211206032858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211206032858 : Closed e1211206032858 ∧ code e1211206032858 = 5609252543962 := by decide
theorem cert_e1211206032858 : check e1211206032858 [[],[]] .smaller = true := by decide
def e1211206032874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211206032874 : Closed e1211206032874 ∧ code e1211206032874 = 5609252543978 := by decide
theorem cert_e1211206032874 : check e1211206032874 [[],[]] .smaller = true := by decide
def e1211206033078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211206033078 : Closed e1211206033078 ∧ code e1211206033078 = 5609252544182 := by decide
theorem cert_e1211206033078 : check e1211206033078 [[],[]] .smaller = true := by decide
def e1211206033110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211206033110 : Closed e1211206033110 ∧ code e1211206033110 = 5609252544214 := by decide
theorem cert_e1211206033110 : check e1211206033110 [[],[]] .smaller = true := by decide
def e1211206033114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211206033114 : Closed e1211206033114 ∧ code e1211206033114 = 5609252544218 := by decide
theorem cert_e1211206033114 : check e1211206033114 [[],[]] .smaller = true := by decide
def e1211206033238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211206033238 : Closed e1211206033238 ∧ code e1211206033238 = 5609252544342 := by decide
theorem cert_e1211206033238 : check e1211206033238 [[],[]] .smaller = true := by decide
def e1211206033242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211206033242 : Closed e1211206033242 ∧ code e1211206033242 = 5609252544346 := by decide
theorem cert_e1211206033242 : check e1211206033242 [[],[]] .smaller = true := by decide
def e1211206033258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211206033258 : Closed e1211206033258 ∧ code e1211206033258 = 5609252544362 := by decide
theorem cert_e1211206033258 : check e1211206033258 [[],[]] .smaller = true := by decide
def e1211206034398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3)))))))))
theorem wire_e1211206034398 : Closed e1211206034398 ∧ code e1211206034398 = 5609252545502 := by decide
theorem cert_e1211206034398 : check e1211206034398 [[],[]] .smaller = true := by decide
def e1211206034414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2)))))))))
theorem wire_e1211206034414 : Closed e1211206034414 ∧ code e1211206034414 = 5609252545518 := by decide
theorem cert_e1211206034414 : check e1211206034414 [[],[]] .smaller = true := by decide
def e1211206035166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e1211206035166 : Closed e1211206035166 ∧ code e1211206035166 = 5609252546270 := by decide
theorem cert_e1211206035166 : check e1211206035166 [[],[]] .smaller = true := by decide
def e1211206035190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e1211206035190 : Closed e1211206035190 ∧ code e1211206035190 = 5609252546294 := by decide
theorem cert_e1211206035190 : check e1211206035190 [[],[]] .smaller = true := by decide
def e1211206035294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e1211206035294 : Closed e1211206035294 ∧ code e1211206035294 = 5609252546398 := by decide
theorem cert_e1211206035294 : check e1211206035294 [[],[]] .smaller = true := by decide
def e1211206035310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e1211206035310 : Closed e1211206035310 ∧ code e1211206035310 = 5609252546414 := by decide
theorem cert_e1211206035310 : check e1211206035310 [[],[]] .smaller = true := by decide
def e1211206035318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e1211206035318 : Closed e1211206035318 ∧ code e1211206035318 = 5609252546422 := by decide
theorem cert_e1211206035318 : check e1211206035318 [[],[]] .smaller = true := by decide
def e1211206035322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e1211206035322 : Closed e1211206035322 ∧ code e1211206035322 = 5609252546426 := by decide
theorem cert_e1211206035322 : check e1211206035322 [[],[]] .smaller = true := by decide
def e1211206035382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e1211206035382 : Closed e1211206035382 ∧ code e1211206035382 = 5609252546486 := by decide
theorem cert_e1211206035382 : check e1211206035382 [[],[]] .smaller = true := by decide
def e1211206035414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e1211206035414 : Closed e1211206035414 ∧ code e1211206035414 = 5609252546518 := by decide
theorem cert_e1211206035414 : check e1211206035414 [[],[]] .smaller = true := by decide
def e1211206035418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e1211206035418 : Closed e1211206035418 ∧ code e1211206035418 = 5609252546522 := by decide
theorem cert_e1211206035418 : check e1211206035418 [[],[]] .smaller = true := by decide
def e1211206035934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211206035934 : Closed e1211206035934 ∧ code e1211206035934 = 5609252547038 := by decide
theorem cert_e1211206035934 : check e1211206035934 [[],[]] .smaller = true := by decide
def e1211206035958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211206035958 : Closed e1211206035958 ∧ code e1211206035958 = 5609252547062 := by decide
theorem cert_e1211206035958 : check e1211206035958 [[],[]] .smaller = true := by decide
def e1211206036702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206036702 : Closed e1211206036702 ∧ code e1211206036702 = 5609252547806 := by decide
theorem cert_e1211206036702 : check e1211206036702 [[],[]] .smaller = true := by decide
def e1211206036718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211206036718 : Closed e1211206036718 ∧ code e1211206036718 = 5609252547822 := by decide
theorem cert_e1211206036718 : check e1211206036718 [[],[]] .smaller = true := by decide
def e1211206036726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211206036726 : Closed e1211206036726 ∧ code e1211206036726 = 5609252547830 := by decide
theorem cert_e1211206036726 : check e1211206036726 [[],[]] .smaller = true := by decide
def e1211206036730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206036730 : Closed e1211206036730 ∧ code e1211206036730 = 5609252547834 := by decide
theorem cert_e1211206036730 : check e1211206036730 [[],[]] .smaller = true := by decide
def e1211206037054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4))))))))))
theorem wire_e1211206037054 : Closed e1211206037054 ∧ code e1211206037054 = 5609252548158 := by decide
theorem cert_e1211206037054 : check e1211206037054 [[],[]] .smaller = true := by decide
def e1211206037110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211206037110 : Closed e1211206037110 ∧ code e1211206037110 = 5609252548214 := by decide
theorem cert_e1211206037110 : check e1211206037110 [[],[]] .smaller = true := by decide
def e1211206037278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3))))))))))
theorem wire_e1211206037278 : Closed e1211206037278 ∧ code e1211206037278 = 5609252548382 := by decide
theorem cert_e1211206037278 : check e1211206037278 [[],[]] .smaller = true := by decide
def e1211206037302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206037302 : Closed e1211206037302 ∧ code e1211206037302 = 5609252548406 := by decide
theorem cert_e1211206037302 : check e1211206037302 [[],[]] .smaller = true := by decide
def e1211206037306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206037306 : Closed e1211206037306 ∧ code e1211206037306 = 5609252548410 := by decide
theorem cert_e1211206037306 : check e1211206037306 [[],[]] .smaller = true := by decide
def e1211206038366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211206038366 : Closed e1211206038366 ∧ code e1211206038366 = 5609252549470 := by decide
theorem cert_e1211206038366 : check e1211206038366 [[],[]] .smaller = true := by decide
def e1211206038382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211206038382 : Closed e1211206038382 ∧ code e1211206038382 = 5609252549486 := by decide
theorem cert_e1211206038382 : check e1211206038382 [[],[]] .smaller = true := by decide
def e1211206038390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211206038390 : Closed e1211206038390 ∧ code e1211206038390 = 5609252549494 := by decide
theorem cert_e1211206038390 : check e1211206038390 [[],[]] .smaller = true := by decide
def e1211206038394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211206038394 : Closed e1211206038394 ∧ code e1211206038394 = 5609252549498 := by decide
theorem cert_e1211206038394 : check e1211206038394 [[],[]] .smaller = true := by decide
def e1211206038446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211206038446 : Closed e1211206038446 ∧ code e1211206038446 = 5609252549550 := by decide
theorem cert_e1211206038446 : check e1211206038446 [[],[]] .smaller = true := by decide
def e1211206038458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211206038458 : Closed e1211206038458 ∧ code e1211206038458 = 5609252549562 := by decide
theorem cert_e1211206038458 : check e1211206038458 [[],[]] .smaller = true := by decide
def e1211206038486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211206038486 : Closed e1211206038486 ∧ code e1211206038486 = 5609252549590 := by decide
theorem cert_e1211206038486 : check e1211206038486 [[],[]] .smaller = true := by decide
def e1211206038490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211206038490 : Closed e1211206038490 ∧ code e1211206038490 = 5609252549594 := by decide
theorem cert_e1211206038490 : check e1211206038490 [[],[]] .smaller = true := by decide
def e1211206038506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211206038506 : Closed e1211206038506 ∧ code e1211206038506 = 5609252549610 := by decide
theorem cert_e1211206038506 : check e1211206038506 [[],[]] .smaller = true := by decide
def e1211206038750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206038750 : Closed e1211206038750 ∧ code e1211206038750 = 5609252549854 := by decide
theorem cert_e1211206038750 : check e1211206038750 [[],[]] .smaller = true := by decide
def e1211206038766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211206038766 : Closed e1211206038766 ∧ code e1211206038766 = 5609252549870 := by decide
theorem cert_e1211206038766 : check e1211206038766 [[],[]] .smaller = true := by decide
def e1211206038774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211206038774 : Closed e1211206038774 ∧ code e1211206038774 = 5609252549878 := by decide
theorem cert_e1211206038774 : check e1211206038774 [[],[]] .smaller = true := by decide
def e1211206038778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206038778 : Closed e1211206038778 ∧ code e1211206038778 = 5609252549882 := by decide
theorem cert_e1211206038778 : check e1211206038778 [[],[]] .smaller = true := by decide
def e1211206039150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211206039150 : Closed e1211206039150 ∧ code e1211206039150 = 5609252550254 := by decide
theorem cert_e1211206039150 : check e1211206039150 [[],[]] .smaller = true := by decide
def e1211206039162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211206039162 : Closed e1211206039162 ∧ code e1211206039162 = 5609252550266 := by decide
theorem cert_e1211206039162 : check e1211206039162 [[],[]] .smaller = true := by decide
def e1211206039350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206039350 : Closed e1211206039350 ∧ code e1211206039350 = 5609252550454 := by decide
theorem cert_e1211206039350 : check e1211206039350 [[],[]] .smaller = true := by decide
def e1211206039354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206039354 : Closed e1211206039354 ∧ code e1211206039354 = 5609252550458 := by decide
theorem cert_e1211206039354 : check e1211206039354 [[],[]] .smaller = true := by decide
def e1211206039450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211206039450 : Closed e1211206039450 ∧ code e1211206039450 = 5609252550554 := by decide
theorem cert_e1211206039450 : check e1211206039450 [[],[]] .smaller = true := by decide
def e1211206039774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211206039774 : Closed e1211206039774 ∧ code e1211206039774 = 5609252550878 := by decide
theorem cert_e1211206039774 : check e1211206039774 [[],[]] .smaller = true := by decide
def e1211206039802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211206039802 : Closed e1211206039802 ∧ code e1211206039802 = 5609252550906 := by decide
theorem cert_e1211206039802 : check e1211206039802 [[],[]] .smaller = true := by decide
def e1211206039990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211206039990 : Closed e1211206039990 ∧ code e1211206039990 = 5609252551094 := by decide
theorem cert_e1211206039990 : check e1211206039990 [[],[]] .smaller = true := by decide
def e1211206040022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211206040022 : Closed e1211206040022 ∧ code e1211206040022 = 5609252551126 := by decide
theorem cert_e1211206040022 : check e1211206040022 [[],[]] .smaller = true := by decide
def e1211206040026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211206040026 : Closed e1211206040026 ∧ code e1211206040026 = 5609252551130 := by decide
theorem cert_e1211206040026 : check e1211206040026 [[],[]] .smaller = true := by decide
def e1211206040126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211206040126 : Closed e1211206040126 ∧ code e1211206040126 = 5609252551230 := by decide
theorem cert_e1211206040126 : check e1211206040126 [[],[]] .smaller = true := by decide
def e1211206040182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211206040182 : Closed e1211206040182 ∧ code e1211206040182 = 5609252551286 := by decide
theorem cert_e1211206040182 : check e1211206040182 [[],[]] .smaller = true := by decide
def e1211206040374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206040374 : Closed e1211206040374 ∧ code e1211206040374 = 5609252551478 := by decide
theorem cert_e1211206040374 : check e1211206040374 [[],[]] .smaller = true := by decide
def e1211206040378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206040378 : Closed e1211206040378 ∧ code e1211206040378 = 5609252551482 := by decide
theorem cert_e1211206040378 : check e1211206040378 [[],[]] .smaller = true := by decide
def e1211206040518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211206040518 : Closed e1211206040518 ∧ code e1211206040518 = 5609252551622 := by decide
theorem cert_e1211206040518 : check e1211206040518 [[],[]] .smaller = true := by decide
def e1211206040686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211206040686 : Closed e1211206040686 ∧ code e1211206040686 = 5609252551790 := by decide
theorem cert_e1211206040686 : check e1211206040686 [[],[]] .smaller = true := by decide
def e1211206040698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211206040698 : Closed e1211206040698 ∧ code e1211206040698 = 5609252551802 := by decide
theorem cert_e1211206040698 : check e1211206040698 [[],[]] .smaller = true := by decide
def e1211206040790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211206040790 : Closed e1211206040790 ∧ code e1211206040790 = 5609252551894 := by decide
theorem cert_e1211206040790 : check e1211206040790 [[],[]] .smaller = true := by decide
def e1211206040794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211206040794 : Closed e1211206040794 ∧ code e1211206040794 = 5609252551898 := by decide
theorem cert_e1211206040794 : check e1211206040794 [[],[]] .smaller = true := by decide
def e1211206040810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211206040810 : Closed e1211206040810 ∧ code e1211206040810 = 5609252551914 := by decide
theorem cert_e1211206040810 : check e1211206040810 [[],[]] .smaller = true := by decide
def e1211206040862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211206040862 : Closed e1211206040862 ∧ code e1211206040862 = 5609252551966 := by decide
theorem cert_e1211206040862 : check e1211206040862 [[],[]] .smaller = true := by decide
def e1211206040886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206040886 : Closed e1211206040886 ∧ code e1211206040886 = 5609252551990 := by decide
theorem cert_e1211206040886 : check e1211206040886 [[],[]] .smaller = true := by decide
def e1211206040890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206040890 : Closed e1211206040890 ∧ code e1211206040890 = 5609252551994 := by decide
theorem cert_e1211206040890 : check e1211206040890 [[],[]] .smaller = true := by decide
def e1211206040986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211206040986 : Closed e1211206040986 ∧ code e1211206040986 = 5609252552090 := by decide
theorem cert_e1211206040986 : check e1211206040986 [[],[]] .smaller = true := by decide
def e1211206041030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211206041030 : Closed e1211206041030 ∧ code e1211206041030 = 5609252552134 := by decide
theorem cert_e1211206041030 : check e1211206041030 [[],[]] .smaller = true := by decide
def e1211206047454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211206047454 : Closed e1211206047454 ∧ code e1211206047454 = 5609252558558 := by decide
theorem cert_e1211206047454 : check e1211206047454 [[],[]] .smaller = true := by decide
def e1211206047478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211206047478 : Closed e1211206047478 ∧ code e1211206047478 = 5609252558582 := by decide
theorem cert_e1211206047478 : check e1211206047478 [[],[]] .smaller = true := by decide
end Blc.Floor42
