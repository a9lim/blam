import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815113786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e1205815113786 : Closed e1205815113786 ∧ code e1205815113786 = 5603861624890 := by decide
theorem cert_e1205815113786 : check e1205815113786 [[],[]] .chain = true := by decide
def e1205815113834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e1205815113834 : Closed e1205815113834 ∧ code e1205815113834 = 5603861624938 := by decide
theorem cert_e1205815113834 : checkPay e1205815113834 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815113882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815113882 : Closed e1205815113882 ∧ code e1205815113882 = 5603861624986 := by decide
theorem cert_e1205815113882 : check e1205815113882 [[],[]] .chain = true := by decide
def e1205815113926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1205815113926 : Closed e1205815113926 ∧ code e1205815113926 = 5603861625030 := by decide
theorem cert_e1205815113926 : check e1205815113926 [[],[]] .chain = true := by decide
def e1205815114122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815114122 : Closed e1205815114122 ∧ code e1205815114122 = 5603861625226 := by decide
theorem cert_e1205815114122 : check e1205815114122 [[],[]] .chain = true := by decide
def e1205815114146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815114146 : Closed e1205815114146 ∧ code e1205815114146 = 5603861625250 := by decide
theorem cert_e1205815114146 : check e1205815114146 [[],[]] .chain = true := by decide
def e1205815114158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1205815114158 : Closed e1205815114158 ∧ code e1205815114158 = 5603861625262 := by decide
theorem cert_e1205815114158 : checkPay e1205815114158 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1205815114166 : Closed e1205815114166 ∧ code e1205815114166 = 5603861625270 := by decide
theorem cert_e1205815114166 : check e1205815114166 [[],[]] .chain = true := by decide
def e1205815114170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1205815114170 : Closed e1205815114170 ∧ code e1205815114170 = 5603861625274 := by decide
theorem cert_e1205815114170 : checkPay e1205815114170 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1205815114198 : Closed e1205815114198 ∧ code e1205815114198 = 5603861625302 := by decide
theorem cert_e1205815114198 : check e1205815114198 [[],[]] .chain = true := by decide
def e1205815114202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1205815114202 : Closed e1205815114202 ∧ code e1205815114202 = 5603861625306 := by decide
theorem cert_e1205815114202 : check e1205815114202 [[],[]] .chain = true := by decide
def e1205815114218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1205815114218 : Closed e1205815114218 ∧ code e1205815114218 = 5603861625322 := by decide
theorem cert_e1205815114218 : checkPay e1205815114218 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815114254 : Closed e1205815114254 ∧ code e1205815114254 = 5603861625358 := by decide
theorem cert_e1205815114254 : check e1205815114254 [[],[]] .chain = true := by decide
def e1205815114266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815114266 : Closed e1205815114266 ∧ code e1205815114266 = 5603861625370 := by decide
theorem cert_e1205815114266 : checkPay e1205815114266 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815114338 : Closed e1205815114338 ∧ code e1205815114338 = 5603861625442 := by decide
theorem cert_e1205815114338 : check e1205815114338 [[],[]] .chain = true := by decide
def e1205815114350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815114350 : Closed e1205815114350 ∧ code e1205815114350 = 5603861625454 := by decide
theorem cert_e1205815114350 : checkPay e1205815114350 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815114358 : Closed e1205815114358 ∧ code e1205815114358 = 5603861625462 := by decide
theorem cert_e1205815114358 : check e1205815114358 [[],[]] .chain = true := by decide
def e1205815114362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815114362 : Closed e1205815114362 ∧ code e1205815114362 = 5603861625466 := by decide
theorem cert_e1205815114362 : checkPay e1205815114362 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815114550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815114550 : Closed e1205815114550 ∧ code e1205815114550 = 5603861625654 := by decide
theorem cert_e1205815114550 : check e1205815114550 [[],[]] .chain = true := by decide
def e1205815114554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815114554 : Closed e1205815114554 ∧ code e1205815114554 = 5603861625658 := by decide
theorem cert_e1205815114554 : check e1205815114554 [[],[]] .chain = true := by decide
def e1205815114650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815114650 : Closed e1205815114650 ∧ code e1205815114650 = 5603861625754 := by decide
theorem cert_e1205815114650 : checkPay e1205815114650 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815117790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e1205815117790 : Closed e1205815117790 ∧ code e1205815117790 = 5603861628894 := by decide
theorem cert_e1205815117790 : checkPay e1205815117790 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815121454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815121454 : Closed e1205815121454 ∧ code e1205815121454 = 5603861632558 := by decide
theorem cert_e1205815121454 : check e1205815121454 [[],[]] .chain = true := by decide
def e1205815121634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815121634 : Closed e1205815121634 ∧ code e1205815121634 = 5603861632738 := by decide
theorem cert_e1205815121634 : check e1205815121634 [[],[]] .chain = true := by decide
def e1205815121646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1205815121646 : Closed e1205815121646 ∧ code e1205815121646 = 5603861632750 := by decide
theorem cert_e1205815121646 : checkPay e1205815121646 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815121774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1205815121774 : Closed e1205815121774 ∧ code e1205815121774 = 5603861632878 := by decide
theorem cert_e1205815121774 : check e1205815121774 [[],[]] .chain = true := by decide
def e1205815121782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1205815121782 : Closed e1205815121782 ∧ code e1205815121782 = 5603861632886 := by decide
theorem cert_e1205815121782 : check e1205815121782 [[],[]] .chain = true := by decide
def e1205815121802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815121802 : Closed e1205815121802 ∧ code e1205815121802 = 5603861632906 := by decide
theorem cert_e1205815121802 : check e1205815121802 [[],[]] .chain = true := by decide
def e1205815121826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815121826 : Closed e1205815121826 ∧ code e1205815121826 = 5603861632930 := by decide
theorem cert_e1205815121826 : check e1205815121826 [[],[]] .chain = true := by decide
def e1205815121838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1205815121838 : Closed e1205815121838 ∧ code e1205815121838 = 5603861632942 := by decide
theorem cert_e1205815121838 : checkPay e1205815121838 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815121846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1205815121846 : Closed e1205815121846 ∧ code e1205815121846 = 5603861632950 := by decide
theorem cert_e1205815121846 : check e1205815121846 [[],[]] .chain = true := by decide
def e1205815121850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1205815121850 : Closed e1205815121850 ∧ code e1205815121850 = 5603861632954 := by decide
theorem cert_e1205815121850 : checkPay e1205815121850 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815121982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815121982 : Closed e1205815121982 ∧ code e1205815121982 = 5603861633086 := by decide
theorem cert_e1205815121982 : check e1205815121982 [[],[]] .chain = true := by decide
def e1205815122402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815122402 : Closed e1205815122402 ∧ code e1205815122402 = 5603861633506 := by decide
theorem cert_e1205815122402 : check e1205815122402 [[],[]] .chain = true := by decide
def e1205815122414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815122414 : Closed e1205815122414 ∧ code e1205815122414 = 5603861633518 := by decide
theorem cert_e1205815122414 : checkPay e1205815122414 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815123182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815123182 : Closed e1205815123182 ∧ code e1205815123182 = 5603861634286 := by decide
theorem cert_e1205815123182 : check e1205815123182 [[],[]] .chain = true := by decide
def e1205815123190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815123190 : Closed e1205815123190 ∧ code e1205815123190 = 5603861634294 := by decide
theorem cert_e1205815123190 : check e1205815123190 [[],[]] .chain = true := by decide
def e1205815123470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815123470 : Closed e1205815123470 ∧ code e1205815123470 = 5603861634574 := by decide
theorem cert_e1205815123470 : check e1205815123470 [[],[]] .chain = true := by decide
def e1205815123482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815123482 : Closed e1205815123482 ∧ code e1205815123482 = 5603861634586 := by decide
theorem cert_e1205815123482 : checkPay e1205815123482 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815123554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815123554 : Closed e1205815123554 ∧ code e1205815123554 = 5603861634658 := by decide
theorem cert_e1205815123554 : check e1205815123554 [[],[]] .chain = true := by decide
def e1205815123566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815123566 : Closed e1205815123566 ∧ code e1205815123566 = 5603861634670 := by decide
theorem cert_e1205815123566 : checkPay e1205815123566 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815123574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815123574 : Closed e1205815123574 ∧ code e1205815123574 = 5603861634678 := by decide
theorem cert_e1205815123574 : check e1205815123574 [[],[]] .chain = true := by decide
def e1205815123578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815123578 : Closed e1205815123578 ∧ code e1205815123578 = 5603861634682 := by decide
theorem cert_e1205815123578 : checkPay e1205815123578 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815135086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205815135086 : Closed e1205815135086 ∧ code e1205815135086 = 5603861646190 := by decide
theorem cert_e1205815135086 : check e1205815135086 [[],[]] .chain = true := by decide
def e1205815135094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205815135094 : Closed e1205815135094 ∧ code e1205815135094 = 5603861646198 := by decide
theorem cert_e1205815135094 : check e1205815135094 [[],[]] .chain = true := by decide
def e1205815135150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205815135150 : Closed e1205815135150 ∧ code e1205815135150 = 5603861646254 := by decide
theorem cert_e1205815135150 : check e1205815135150 [[],[]] .chain = true := by decide
def e1205815135162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205815135162 : Closed e1205815135162 ∧ code e1205815135162 = 5603861646266 := by decide
theorem cert_e1205815135162 : check e1205815135162 [[],[]] .chain = true := by decide
def e1205815135190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205815135190 : Closed e1205815135190 ∧ code e1205815135190 = 5603861646294 := by decide
theorem cert_e1205815135190 : check e1205815135190 [[],[]] .chain = true := by decide
def e1205815135194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205815135194 : Closed e1205815135194 ∧ code e1205815135194 = 5603861646298 := by decide
theorem cert_e1205815135194 : check e1205815135194 [[],[]] .chain = true := by decide
def e1205815135470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815135470 : Closed e1205815135470 ∧ code e1205815135470 = 5603861646574 := by decide
theorem cert_e1205815135470 : check e1205815135470 [[],[]] .chain = true := by decide
def e1205815135478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815135478 : Closed e1205815135478 ∧ code e1205815135478 = 5603861646582 := by decide
theorem cert_e1205815135478 : check e1205815135478 [[],[]] .chain = true := by decide
def e1205815135854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815135854 : Closed e1205815135854 ∧ code e1205815135854 = 5603861646958 := by decide
theorem cert_e1205815135854 : check e1205815135854 [[],[]] .chain = true := by decide
def e1205815135866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815135866 : Closed e1205815135866 ∧ code e1205815135866 = 5603861646970 := by decide
theorem cert_e1205815135866 : check e1205815135866 [[],[]] .chain = true := by decide
def e1205815136054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815136054 : Closed e1205815136054 ∧ code e1205815136054 = 5603861647158 := by decide
theorem cert_e1205815136054 : check e1205815136054 [[],[]] .chain = true := by decide
def e1205815136058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815136058 : Closed e1205815136058 ∧ code e1205815136058 = 5603861647162 := by decide
theorem cert_e1205815136058 : check e1205815136058 [[],[]] .chain = true := by decide
def e1205815140830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1205815140830 : Closed e1205815140830 ∧ code e1205815140830 = 5603861651934 := by decide
theorem cert_e1205815140830 : checkPay e1205815140830 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815140854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1205815140854 : Closed e1205815140854 ∧ code e1205815140854 = 5603861651958 := by decide
theorem cert_e1205815140854 : checkPay e1205815140854 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815141770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815141770 : Closed e1205815141770 ∧ code e1205815141770 = 5603861652874 := by decide
theorem cert_e1205815141770 : check e1205815141770 [[],[]] .chain = true := by decide
def e1205815141794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815141794 : Closed e1205815141794 ∧ code e1205815141794 = 5603861652898 := by decide
theorem cert_e1205815141794 : check e1205815141794 [[],[]] .chain = true := by decide
def e1205815141806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1205815141806 : Closed e1205815141806 ∧ code e1205815141806 = 5603861652910 := by decide
theorem cert_e1205815141806 : checkPay e1205815141806 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815141814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1205815141814 : Closed e1205815141814 ∧ code e1205815141814 = 5603861652918 := by decide
theorem cert_e1205815141814 : check e1205815141814 [[],[]] .chain = true := by decide
def e1205815141818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1205815141818 : Closed e1205815141818 ∧ code e1205815141818 = 5603861652922 := by decide
theorem cert_e1205815141818 : checkPay e1205815141818 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815141846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1205815141846 : Closed e1205815141846 ∧ code e1205815141846 = 5603861652950 := by decide
theorem cert_e1205815141846 : check e1205815141846 [[],[]] .chain = true := by decide
def e1205815141850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1205815141850 : Closed e1205815141850 ∧ code e1205815141850 = 5603861652954 := by decide
theorem cert_e1205815141850 : check e1205815141850 [[],[]] .chain = true := by decide
def e1205815141866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1205815141866 : Closed e1205815141866 ∧ code e1205815141866 = 5603861652970 := by decide
theorem cert_e1205815141866 : checkPay e1205815141866 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815141902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815141902 : Closed e1205815141902 ∧ code e1205815141902 = 5603861653006 := by decide
theorem cert_e1205815141902 : check e1205815141902 [[],[]] .chain = true := by decide
def e1205815141914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815141914 : Closed e1205815141914 ∧ code e1205815141914 = 5603861653018 := by decide
theorem cert_e1205815141914 : checkPay e1205815141914 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815141986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815141986 : Closed e1205815141986 ∧ code e1205815141986 = 5603861653090 := by decide
theorem cert_e1205815141986 : check e1205815141986 [[],[]] .chain = true := by decide
def e1205815141998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815141998 : Closed e1205815141998 ∧ code e1205815141998 = 5603861653102 := by decide
theorem cert_e1205815141998 : checkPay e1205815141998 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815142006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815142006 : Closed e1205815142006 ∧ code e1205815142006 = 5603861653110 := by decide
theorem cert_e1205815142006 : check e1205815142006 [[],[]] .chain = true := by decide
def e1205815142010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815142010 : Closed e1205815142010 ∧ code e1205815142010 = 5603861653114 := by decide
theorem cert_e1205815142010 : checkPay e1205815142010 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815142198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815142198 : Closed e1205815142198 ∧ code e1205815142198 = 5603861653302 := by decide
theorem cert_e1205815142198 : check e1205815142198 [[],[]] .chain = true := by decide
def e1205815142202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815142202 : Closed e1205815142202 ∧ code e1205815142202 = 5603861653306 := by decide
theorem cert_e1205815142202 : check e1205815142202 [[],[]] .chain = true := by decide
def e1205815142298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815142298 : Closed e1205815142298 ∧ code e1205815142298 = 5603861653402 := by decide
theorem cert_e1205815142298 : checkPay e1205815142298 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815150390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815150390 : Closed e1205815150390 ∧ code e1205815150390 = 5603861661494 := by decide
theorem cert_e1205815150390 : check e1205815150390 [[],[]] .chain = true := by decide
def e1205815150394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815150394 : Closed e1205815150394 ∧ code e1205815150394 = 5603861661498 := by decide
theorem cert_e1205815150394 : check e1205815150394 [[],[]] .chain = true := by decide
def e1205815150490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815150490 : Closed e1205815150490 ∧ code e1205815150490 = 5603861661594 := by decide
theorem cert_e1205815150490 : check e1205815150490 [[],[]] .chain = true := by decide
def e1205815151926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815151926 : Closed e1205815151926 ∧ code e1205815151926 = 5603861663030 := by decide
theorem cert_e1205815151926 : check e1205815151926 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815151930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815151930 : Closed e1205815151930 ∧ code e1205815151930 = 5603861663034 := by decide
theorem cert_e1205815151930 : check e1205815151930 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815152366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1205815152366 : Closed e1205815152366 ∧ code e1205815152366 = 5603861663470 := by decide
theorem cert_e1205815152366 : check e1205815152366 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815152374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1205815152374 : Closed e1205815152374 ∧ code e1205815152374 = 5603861663478 := by decide
theorem cert_e1205815152374 : check e1205815152374 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815152494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1205815152494 : Closed e1205815152494 ∧ code e1205815152494 = 5603861663598 := by decide
theorem cert_e1205815152494 : check e1205815152494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815152506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1205815152506 : Closed e1205815152506 ∧ code e1205815152506 = 5603861663610 := by decide
theorem cert_e1205815152506 : check e1205815152506 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815152566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1205815152566 : Closed e1205815152566 ∧ code e1205815152566 = 5603861663670 := by decide
theorem cert_e1205815152566 : check e1205815152566 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815152570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1205815152570 : Closed e1205815152570 ∧ code e1205815152570 = 5603861663674 := by decide
theorem cert_e1205815152570 : check e1205815152570 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815153366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1205815153366 : Closed e1205815153366 ∧ code e1205815153366 = 5603861664470 := by decide
theorem cert_e1205815153366 : check e1205815153366 [[],[]] .chain = true := by decide
def e1205815153370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1205815153370 : Closed e1205815153370 ∧ code e1205815153370 = 5603861664474 := by decide
theorem cert_e1205815153370 : check e1205815153370 [[],[]] .chain = true := by decide
def e1205815153386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1205815153386 : Closed e1205815153386 ∧ code e1205815153386 = 5603861664490 := by decide
theorem cert_e1205815153386 : check e1205815153386 [[],[]] .chain = true := by decide
def e1205815153462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815153462 : Closed e1205815153462 ∧ code e1205815153462 = 5603861664566 := by decide
theorem cert_e1205815153462 : check e1205815153462 [[],[]] .chain = true := by decide
def e1205815153466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815153466 : Closed e1205815153466 ∧ code e1205815153466 = 5603861664570 := by decide
theorem cert_e1205815153466 : check e1205815153466 [[],[]] .chain = true := by decide
def e1205815153562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815153562 : Closed e1205815153562 ∧ code e1205815153562 = 5603861664666 := by decide
theorem cert_e1205815153562 : check e1205815153562 [[],[]] .chain = true := by decide
def e1205815155086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1205815155086 : Closed e1205815155086 ∧ code e1205815155086 = 5603861666190 := by decide
theorem cert_e1205815155086 : check e1205815155086 [[],[]] .chain = true := by decide
def e1205815155142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1205815155142 : Closed e1205815155142 ∧ code e1205815155142 = 5603861666246 := by decide
theorem cert_e1205815155142 : check e1205815155142 [[],[]] .chain = true := by decide
def e1205815155910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1205815155910 : Closed e1205815155910 ∧ code e1205815155910 = 5603861667014 := by decide
theorem cert_e1205815155910 : check e1205815155910 [[],[]] .chain = true := by decide
def e1205815159894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1205815159894 : Closed e1205815159894 ∧ code e1205815159894 = 5603861670998 := by decide
theorem cert_e1205815159894 : check e1205815159894 [[],[]] .chain = true := by decide
def e1205815159898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1205815159898 : Closed e1205815159898 ∧ code e1205815159898 = 5603861671002 := by decide
theorem cert_e1205815159898 : check e1205815159898 [[],[]] .chain = true := by decide
def e1205815160086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205815160086 : Closed e1205815160086 ∧ code e1205815160086 = 5603861671190 := by decide
theorem cert_e1205815160086 : check e1205815160086 [[],[]] .chain = true := by decide
def e1205815160162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205815160162 : Closed e1205815160162 ∧ code e1205815160162 = 5603861671266 := by decide
theorem cert_e1205815160162 : check e1205815160162 [[],[]] .chain = true := by decide
def e1205815160174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1205815160174 : Closed e1205815160174 ∧ code e1205815160174 = 5603861671278 := by decide
theorem cert_e1205815160174 : check e1205815160174 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815160182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1205815160182 : Closed e1205815160182 ∧ code e1205815160182 = 5603861671286 := by decide
theorem cert_e1205815160182 : check e1205815160182 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205815160202 : Closed e1205815160202 ∧ code e1205815160202 = 5603861671306 := by decide
theorem cert_e1205815160202 : check e1205815160202 [[],[]] .chain = true := by decide
def e1205815160226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205815160226 : Closed e1205815160226 ∧ code e1205815160226 = 5603861671330 := by decide
theorem cert_e1205815160226 : check e1205815160226 [[],[]] .chain = true := by decide
def e1205815160238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1205815160238 : Closed e1205815160238 ∧ code e1205815160238 = 5603861671342 := by decide
theorem cert_e1205815160238 : check e1205815160238 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815160246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e1205815160246 : Closed e1205815160246 ∧ code e1205815160246 = 5603861671350 := by decide
theorem cert_e1205815160246 : check e1205815160246 [[],[]] .chain = true := by decide
def e1205815160250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1205815160250 : Closed e1205815160250 ∧ code e1205815160250 = 5603861671354 := by decide
theorem cert_e1205815160250 : check e1205815160250 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1205815160278 : Closed e1205815160278 ∧ code e1205815160278 = 5603861671382 := by decide
theorem cert_e1205815160278 : check e1205815160278 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1205815160282 : Closed e1205815160282 ∧ code e1205815160282 = 5603861671386 := by decide
theorem cert_e1205815160282 : check e1205815160282 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e1205815160362 : Closed e1205815160362 ∧ code e1205815160362 = 5603861671466 := by decide
theorem cert_e1205815160362 : check e1205815160362 [[],[]] .chain = true := by decide
def e1205815160458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205815160458 : Closed e1205815160458 ∧ code e1205815160458 = 5603861671562 := by decide
theorem cert_e1205815160458 : check e1205815160458 [[],[]] .chain = true := by decide
def e1205815160482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205815160482 : Closed e1205815160482 ∧ code e1205815160482 = 5603861671586 := by decide
theorem cert_e1205815160482 : check e1205815160482 [[],[]] .chain = true := by decide
def e1205815160494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1205815160494 : Closed e1205815160494 ∧ code e1205815160494 = 5603861671598 := by decide
theorem cert_e1205815160494 : check e1205815160494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815160502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1205815160502 : Closed e1205815160502 ∧ code e1205815160502 = 5603861671606 := by decide
theorem cert_e1205815160502 : check e1205815160502 [[],[]] .chain = true := by decide
def e1205815160506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1205815160506 : Closed e1205815160506 ∧ code e1205815160506 = 5603861671610 := by decide
theorem cert_e1205815160506 : check e1205815160506 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1205815160534 : Closed e1205815160534 ∧ code e1205815160534 = 5603861671638 := by decide
theorem cert_e1205815160534 : check e1205815160534 [[],[]] .chain = true := by decide
def e1205815160538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1205815160538 : Closed e1205815160538 ∧ code e1205815160538 = 5603861671642 := by decide
theorem cert_e1205815160538 : check e1205815160538 [[],[]] .chain = true := by decide
def e1205815160554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1205815160554 : Closed e1205815160554 ∧ code e1205815160554 = 5603861671658 := by decide
theorem cert_e1205815160554 : check e1205815160554 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1205815160662 : Closed e1205815160662 ∧ code e1205815160662 = 5603861671766 := by decide
theorem cert_e1205815160662 : check e1205815160662 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1205815160666 : Closed e1205815160666 ∧ code e1205815160666 = 5603861671770 := by decide
theorem cert_e1205815160666 : check e1205815160666 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1205815160682 : Closed e1205815160682 ∧ code e1205815160682 = 5603861671786 := by decide
theorem cert_e1205815160682 : check e1205815160682 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815160950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e1205815160950 : Closed e1205815160950 ∧ code e1205815160950 = 5603861672054 := by decide
theorem cert_e1205815160950 : check e1205815160950 [[],[]] .chain = true := by decide
def e1205815160954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e1205815160954 : Closed e1205815160954 ∧ code e1205815160954 = 5603861672058 := by decide
theorem cert_e1205815160954 : check e1205815160954 [[],[]] .chain = true := by decide
def e1205815161046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1205815161046 : Closed e1205815161046 ∧ code e1205815161046 = 5603861672150 := by decide
theorem cert_e1205815161046 : check e1205815161046 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815161142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815161142 : Closed e1205815161142 ∧ code e1205815161142 = 5603861672246 := by decide
theorem cert_e1205815161142 : check e1205815161142 [[],[]] .chain = true := by decide
def e1205815161146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815161146 : Closed e1205815161146 ∧ code e1205815161146 = 5603861672250 := by decide
theorem cert_e1205815161146 : check e1205815161146 [[],[]] .chain = true := by decide
def e1205815161230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1205815161230 : Closed e1205815161230 ∧ code e1205815161230 = 5603861672334 := by decide
theorem cert_e1205815161230 : check e1205815161230 [[],[]] .chain = true := by decide
def e1205815161286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1205815161286 : Closed e1205815161286 ∧ code e1205815161286 = 5603861672390 := by decide
theorem cert_e1205815161286 : check e1205815161286 [[],[]] .chain = true := by decide
def e1205815161622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1205815161622 : Closed e1205815161622 ∧ code e1205815161622 = 5603861672726 := by decide
theorem cert_e1205815161622 : check e1205815161622 [[],[]] .chain = true := by decide
def e1205815161698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1205815161698 : Closed e1205815161698 ∧ code e1205815161698 = 5603861672802 := by decide
theorem cert_e1205815161698 : check e1205815161698 [[],[]] .chain = true := by decide
def e1205815161710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1205815161710 : Closed e1205815161710 ∧ code e1205815161710 = 5603861672814 := by decide
theorem cert_e1205815161710 : check e1205815161710 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815161718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1205815161718 : Closed e1205815161718 ∧ code e1205815161718 = 5603861672822 := by decide
theorem cert_e1205815161718 : check e1205815161718 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815161738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815161738 : Closed e1205815161738 ∧ code e1205815161738 = 5603861672842 := by decide
theorem cert_e1205815161738 : check e1205815161738 [[],[]] .chain = true := by decide
def e1205815161762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815161762 : Closed e1205815161762 ∧ code e1205815161762 = 5603861672866 := by decide
theorem cert_e1205815161762 : check e1205815161762 [[],[]] .chain = true := by decide
def e1205815161774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1205815161774 : Closed e1205815161774 ∧ code e1205815161774 = 5603861672878 := by decide
theorem cert_e1205815161774 : check e1205815161774 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815161782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e1205815161782 : Closed e1205815161782 ∧ code e1205815161782 = 5603861672886 := by decide
theorem cert_e1205815161782 : check e1205815161782 [[],[]] .chain = true := by decide
def e1205815161786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1205815161786 : Closed e1205815161786 ∧ code e1205815161786 = 5603861672890 := by decide
theorem cert_e1205815161786 : check e1205815161786 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815161814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1205815161814 : Closed e1205815161814 ∧ code e1205815161814 = 5603861672918 := by decide
theorem cert_e1205815161814 : check e1205815161814 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815161818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1205815161818 : Closed e1205815161818 ∧ code e1205815161818 = 5603861672922 := by decide
theorem cert_e1205815161818 : check e1205815161818 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815161886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e1205815161886 : Closed e1205815161886 ∧ code e1205815161886 = 5603861672990 := by decide
theorem cert_e1205815161886 : check e1205815161886 [[],[]] .chain = true := by decide
def e1205815162082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205815162082 : Closed e1205815162082 ∧ code e1205815162082 = 5603861673186 := by decide
theorem cert_e1205815162082 : check e1205815162082 [[],[]] .chain = true := by decide
def e1205815162094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815162094 : Closed e1205815162094 ∧ code e1205815162094 = 5603861673198 := by decide
theorem cert_e1205815162094 : check e1205815162094 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815162102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815162102 : Closed e1205815162102 ∧ code e1205815162102 = 5603861673206 := by decide
theorem cert_e1205815162102 : check e1205815162102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815162382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815162382 : Closed e1205815162382 ∧ code e1205815162382 = 5603861673486 := by decide
theorem cert_e1205815162382 : check e1205815162382 [[],[]] .chain = true := by decide
def e1205815162394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815162394 : Closed e1205815162394 ∧ code e1205815162394 = 5603861673498 := by decide
theorem cert_e1205815162394 : check e1205815162394 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1205815162466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815162466 : Closed e1205815162466 ∧ code e1205815162466 = 5603861673570 := by decide
theorem cert_e1205815162466 : check e1205815162466 [[],[]] .chain = true := by decide
def e1205815162478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815162478 : Closed e1205815162478 ∧ code e1205815162478 = 5603861673582 := by decide
theorem cert_e1205815162478 : check e1205815162478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815162486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815162486 : Closed e1205815162486 ∧ code e1205815162486 = 5603861673590 := by decide
theorem cert_e1205815162486 : check e1205815162486 [[],[]] .chain = true := by decide
def e1205815162490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815162490 : Closed e1205815162490 ∧ code e1205815162490 = 5603861673594 := by decide
theorem cert_e1205815162490 : check e1205815162490 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815162678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815162678 : Closed e1205815162678 ∧ code e1205815162678 = 5603861673782 := by decide
theorem cert_e1205815162678 : check e1205815162678 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815162682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815162682 : Closed e1205815162682 ∧ code e1205815162682 = 5603861673786 := by decide
theorem cert_e1205815162682 : check e1205815162682 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815162938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e1205815162938 : Closed e1205815162938 ∧ code e1205815162938 = 5603861674042 := by decide
theorem cert_e1205815162938 : check e1205815162938 [[],[]] .chain = true := by decide
def e1205815162986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e1205815162986 : Closed e1205815162986 ∧ code e1205815162986 = 5603861674090 := by decide
theorem cert_e1205815162986 : check e1205815162986 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815163034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815163034 : Closed e1205815163034 ∧ code e1205815163034 = 5603861674138 := by decide
theorem cert_e1205815163034 : check e1205815163034 [[],[]] .chain = true := by decide
def e1205815163078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1205815163078 : Closed e1205815163078 ∧ code e1205815163078 = 5603861674182 := by decide
theorem cert_e1205815163078 : check e1205815163078 [[],[]] .chain = true := by decide
def e1205815163274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815163274 : Closed e1205815163274 ∧ code e1205815163274 = 5603861674378 := by decide
theorem cert_e1205815163274 : check e1205815163274 [[],[]] .chain = true := by decide
def e1205815163298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815163298 : Closed e1205815163298 ∧ code e1205815163298 = 5603861674402 := by decide
theorem cert_e1205815163298 : check e1205815163298 [[],[]] .chain = true := by decide
def e1205815163310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1205815163310 : Closed e1205815163310 ∧ code e1205815163310 = 5603861674414 := by decide
theorem cert_e1205815163310 : check e1205815163310 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815163318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1205815163318 : Closed e1205815163318 ∧ code e1205815163318 = 5603861674422 := by decide
theorem cert_e1205815163318 : check e1205815163318 [[],[]] .chain = true := by decide
def e1205815163322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1205815163322 : Closed e1205815163322 ∧ code e1205815163322 = 5603861674426 := by decide
theorem cert_e1205815163322 : check e1205815163322 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815163350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1205815163350 : Closed e1205815163350 ∧ code e1205815163350 = 5603861674454 := by decide
theorem cert_e1205815163350 : check e1205815163350 [[],[]] .chain = true := by decide
def e1205815163354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1205815163354 : Closed e1205815163354 ∧ code e1205815163354 = 5603861674458 := by decide
theorem cert_e1205815163354 : check e1205815163354 [[],[]] .chain = true := by decide
end Blc.Floor42
