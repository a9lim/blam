import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302802729390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302802729390 : Closed e302802729390 ∧ code e302802729390 = 4700849240494 := by decide
theorem cert_e302802729390 : check e302802729390 [[.under],[.under]] .three = true := by decide
def e302802729402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302802729402 : Closed e302802729402 ∧ code e302802729402 = 4700849240506 := by decide
theorem cert_e302802729402 : check e302802729402 [[.under],[.under]] .three = true := by decide
def e302802729450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302802729450 : Closed e302802729450 ∧ code e302802729450 = 4700849240554 := by decide
theorem cert_e302802729450 : check e302802729450 [[.under],[.under]] .three = true := by decide
def e302802729582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802729582 : Closed e302802729582 ∧ code e302802729582 = 4700849240686 := by decide
theorem cert_e302802729582 : check e302802729582 [[.under],[.under]] .three = true := by decide
def e302802729594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802729594 : Closed e302802729594 ∧ code e302802729594 = 4700849240698 := by decide
theorem cert_e302802729594 : check e302802729594 [[.under],[.under]] .three = true := by decide
def e302802729882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302802729882 : Closed e302802729882 ∧ code e302802729882 = 4700849240986 := by decide
theorem cert_e302802729882 : check e302802729882 [[.under],[.under]] .three = true := by decide
def e302802742750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302802742750 : Closed e302802742750 ∧ code e302802742750 = 4700849253854 := by decide
theorem cert_e302802742750 : check e302802742750 [[.under],[.under]] .three = true := by decide
def e302802742766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302802742766 : Closed e302802742766 ∧ code e302802742766 = 4700849253870 := by decide
theorem cert_e302802742766 : check e302802742766 [[.under],[.under]] .three = true := by decide
def e302802743134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302802743134 : Closed e302802743134 ∧ code e302802743134 = 4700849254238 := by decide
theorem cert_e302802743134 : check e302802743134 [[.under],[.under]] .three = true := by decide
def e302802743162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302802743162 : Closed e302802743162 ∧ code e302802743162 = 4700849254266 := by decide
theorem cert_e302802743162 : check e302802743162 [[.under],[.under]] .three = true := by decide
def e302802743214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302802743214 : Closed e302802743214 ∧ code e302802743214 = 4700849254318 := by decide
theorem cert_e302802743214 : check e302802743214 [[.under],[.under]] .three = true := by decide
def e302802743226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302802743226 : Closed e302802743226 ∧ code e302802743226 = 4700849254330 := by decide
theorem cert_e302802743226 : check e302802743226 [[.under],[.under]] .three = true := by decide
def e302802744286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302802744286 : Closed e302802744286 ∧ code e302802744286 = 4700849255390 := by decide
theorem cert_e302802744286 : check e302802744286 [[.under],[.under]] .three = true := by decide
def e302802744302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302802744302 : Closed e302802744302 ∧ code e302802744302 = 4700849255406 := by decide
theorem cert_e302802744302 : check e302802744302 [[.under],[.under]] .three = true := by decide
def e302802746590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302802746590 : Closed e302802746590 ∧ code e302802746590 = 4700849257694 := by decide
theorem cert_e302802746590 : check e302802746590 [[.under],[.under]] .three = true := by decide
def e302802746618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302802746618 : Closed e302802746618 ∧ code e302802746618 = 4700849257722 := by decide
theorem cert_e302802746618 : check e302802746618 [[.under],[.under]] .three = true := by decide
def e302802746990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802746990 : Closed e302802746990 ∧ code e302802746990 = 4700849258094 := by decide
theorem cert_e302802746990 : check e302802746990 [[.under],[.under]] .three = true := by decide
def e302802747002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802747002 : Closed e302802747002 ∧ code e302802747002 = 4700849258106 := by decide
theorem cert_e302802747002 : check e302802747002 [[.under],[.under]] .three = true := by decide
def e302802783070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302802783070 : Closed e302802783070 ∧ code e302802783070 = 4700849294174 := by decide
theorem cert_e302802783070 : check e302802783070 [[.under],[.under]] .three = true := by decide
def e302802783098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302802783098 : Closed e302802783098 ∧ code e302802783098 = 4700849294202 := by decide
theorem cert_e302802783098 : check e302802783098 [[.under],[.under]] .three = true := by decide
def e302802783210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302802783210 : Closed e302802783210 ∧ code e302802783210 = 4700849294314 := by decide
theorem cert_e302802783210 : check e302802783210 [[.under],[.under]] .three = true := by decide
def e302802783454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302802783454 : Closed e302802783454 ∧ code e302802783454 = 4700849294558 := by decide
theorem cert_e302802783454 : check e302802783454 [[.under],[.under]] .three = true := by decide
def e302802783482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302802783482 : Closed e302802783482 ∧ code e302802783482 = 4700849294586 := by decide
theorem cert_e302802783482 : check e302802783482 [[.under],[.under]] .three = true := by decide
def e302802784154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802784154 : Closed e302802784154 ∧ code e302802784154 = 4700849295258 := by decide
theorem cert_e302802784154 : check e302802784154 [[.under],[.under]] .three = true := by decide
def e302802789806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302802789806 : Closed e302802789806 ∧ code e302802789806 = 4700849300910 := by decide
theorem cert_e302802789806 : check e302802789806 [[.under],[.under]] .three = true := by decide
def e302802789818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302802789818 : Closed e302802789818 ∧ code e302802789818 = 4700849300922 := by decide
theorem cert_e302802789818 : check e302802789818 [[.under],[.under]] .three = true := by decide
def e302802789866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302802789866 : Closed e302802789866 ∧ code e302802789866 = 4700849300970 := by decide
theorem cert_e302802789866 : check e302802789866 [[.under],[.under]] .three = true := by decide
def e302802789998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802789998 : Closed e302802789998 ∧ code e302802789998 = 4700849301102 := by decide
theorem cert_e302802789998 : check e302802789998 [[.under],[.under]] .three = true := by decide
def e302802790010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802790010 : Closed e302802790010 ∧ code e302802790010 = 4700849301114 := by decide
theorem cert_e302802790010 : check e302802790010 [[.under],[.under]] .three = true := by decide
def e302802790298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802790298 : Closed e302802790298 ∧ code e302802790298 = 4700849301402 := by decide
theorem cert_e302802790298 : check e302802790298 [[.under],[.under]] .three = true := by decide
def e302803147486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302803147486 : Closed e302803147486 ∧ code e302803147486 = 4700849658590 := by decide
theorem cert_e302803147486 : check e302803147486 [[.under],[.under]] .three = true := by decide
def e302803147510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302803147510 : Closed e302803147510 ∧ code e302803147510 = 4700849658614 := by decide
theorem cert_e302803147510 : check e302803147510 [[.under],[.under]] .three = true := by decide
def e302803147614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302803147614 : Closed e302803147614 ∧ code e302803147614 = 4700849658718 := by decide
theorem cert_e302803147614 : check e302803147614 [[.under],[.under]] .three = true := by decide
def e302803147642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302803147642 : Closed e302803147642 ∧ code e302803147642 = 4700849658746 := by decide
theorem cert_e302803147642 : check e302803147642 [[.under],[.under]] .three = true := by decide
def e302803147734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302803147734 : Closed e302803147734 ∧ code e302803147734 = 4700849658838 := by decide
theorem cert_e302803147734 : check e302803147734 [[.under],[.under]] .three = true := by decide
def e302803147738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302803147738 : Closed e302803147738 ∧ code e302803147738 = 4700849658842 := by decide
theorem cert_e302803147738 : check e302803147738 [[.under],[.under]] .three = true := by decide
def e302803148126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302803148126 : Closed e302803148126 ∧ code e302803148126 = 4700849659230 := by decide
theorem cert_e302803148126 : check e302803148126 [[.under],[.under]] .three = true := by decide
def e302803148154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302803148154 : Closed e302803148154 ∧ code e302803148154 = 4700849659258 := by decide
theorem cert_e302803148154 : check e302803148154 [[.under],[.under]] .three = true := by decide
def e302803148266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302803148266 : Closed e302803148266 ∧ code e302803148266 = 4700849659370 := by decide
theorem cert_e302803148266 : check e302803148266 [[.under],[.under]] .three = true := by decide
def e302803148630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302803148630 : Closed e302803148630 ∧ code e302803148630 = 4700849659734 := by decide
theorem cert_e302803148630 : check e302803148630 [[.under],[.under]] .three = true := by decide
def e302803148634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302803148634 : Closed e302803148634 ∧ code e302803148634 = 4700849659738 := by decide
theorem cert_e302803148634 : check e302803148634 [[.under],[.under]] .three = true := by decide
def e302803148650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302803148650 : Closed e302803148650 ∧ code e302803148650 = 4700849659754 := by decide
theorem cert_e302803148650 : check e302803148650 [[.under],[.under]] .three = true := by decide
def e302803150558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302803150558 : Closed e302803150558 ∧ code e302803150558 = 4700849661662 := by decide
theorem cert_e302803150558 : check e302803150558 [[.under],[.under]] .three = true := by decide
def e302803150582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302803150582 : Closed e302803150582 ∧ code e302803150582 = 4700849661686 := by decide
theorem cert_e302803150582 : check e302803150582 [[.under],[.under]] .three = true := by decide
def e302803150686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302803150686 : Closed e302803150686 ∧ code e302803150686 = 4700849661790 := by decide
theorem cert_e302803150686 : check e302803150686 [[.under],[.under]] .three = true := by decide
def e302803150714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302803150714 : Closed e302803150714 ∧ code e302803150714 = 4700849661818 := by decide
theorem cert_e302803150714 : check e302803150714 [[.under],[.under]] .three = true := by decide
def e302803150806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302803150806 : Closed e302803150806 ∧ code e302803150806 = 4700849661910 := by decide
theorem cert_e302803150806 : check e302803150806 [[.under],[.under]] .three = true := by decide
def e302803150810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302803150810 : Closed e302803150810 ∧ code e302803150810 = 4700849661914 := by decide
theorem cert_e302803150810 : check e302803150810 [[.under],[.under]] .three = true := by decide
def e302803151326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302803151326 : Closed e302803151326 ∧ code e302803151326 = 4700849662430 := by decide
theorem cert_e302803151326 : check e302803151326 [[.under],[.under]] .three = true := by decide
def e302803151350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302803151350 : Closed e302803151350 ∧ code e302803151350 = 4700849662454 := by decide
theorem cert_e302803151350 : check e302803151350 [[.under],[.under]] .three = true := by decide
def e302803152094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302803152094 : Closed e302803152094 ∧ code e302803152094 = 4700849663198 := by decide
theorem cert_e302803152094 : check e302803152094 [[.under],[.under]] .three = true := by decide
def e302803152122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302803152122 : Closed e302803152122 ∧ code e302803152122 = 4700849663226 := by decide
theorem cert_e302803152122 : check e302803152122 [[.under],[.under]] .three = true := by decide
def e302803152694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803152694 : Closed e302803152694 ∧ code e302803152694 = 4700849663798 := by decide
theorem cert_e302803152694 : check e302803152694 [[.under],[.under]] .three = true := by decide
def e302803152698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803152698 : Closed e302803152698 ∧ code e302803152698 = 4700849663802 := by decide
theorem cert_e302803152698 : check e302803152698 [[.under],[.under]] .three = true := by decide
def e302803153758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302803153758 : Closed e302803153758 ∧ code e302803153758 = 4700849664862 := by decide
theorem cert_e302803153758 : check e302803153758 [[.under],[.under]] .three = true := by decide
def e302803153786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302803153786 : Closed e302803153786 ∧ code e302803153786 = 4700849664890 := by decide
theorem cert_e302803153786 : check e302803153786 [[.under],[.under]] .three = true := by decide
def e302803153898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302803153898 : Closed e302803153898 ∧ code e302803153898 = 4700849665002 := by decide
theorem cert_e302803153898 : check e302803153898 [[.under],[.under]] .three = true := by decide
def e302803154142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302803154142 : Closed e302803154142 ∧ code e302803154142 = 4700849665246 := by decide
theorem cert_e302803154142 : check e302803154142 [[.under],[.under]] .three = true := by decide
def e302803154170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302803154170 : Closed e302803154170 ∧ code e302803154170 = 4700849665274 := by decide
theorem cert_e302803154170 : check e302803154170 [[.under],[.under]] .three = true := by decide
def e302803154842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302803154842 : Closed e302803154842 ∧ code e302803154842 = 4700849665946 := by decide
theorem cert_e302803154842 : check e302803154842 [[.under],[.under]] .three = true := by decide
def e302803156182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302803156182 : Closed e302803156182 ∧ code e302803156182 = 4700849667286 := by decide
theorem cert_e302803156182 : check e302803156182 [[.under],[.under]] .three = true := by decide
def e302803156186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302803156186 : Closed e302803156186 ∧ code e302803156186 = 4700849667290 := by decide
theorem cert_e302803156186 : check e302803156186 [[.under],[.under]] .three = true := by decide
def e302803156202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302803156202 : Closed e302803156202 ∧ code e302803156202 = 4700849667306 := by decide
theorem cert_e302803156202 : check e302803156202 [[.under],[.under]] .three = true := by decide
def e302803156278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803156278 : Closed e302803156278 ∧ code e302803156278 = 4700849667382 := by decide
theorem cert_e302803156278 : check e302803156278 [[.under],[.under]] .three = true := by decide
def e302803156282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803156282 : Closed e302803156282 ∧ code e302803156282 = 4700849667386 := by decide
theorem cert_e302803156282 : check e302803156282 [[.under],[.under]] .three = true := by decide
def e302803156378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302803156378 : Closed e302803156378 ∧ code e302803156378 = 4700849667482 := by decide
theorem cert_e302803156378 : check e302803156378 [[.under],[.under]] .three = true := by decide
def e302803162846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302803162846 : Closed e302803162846 ∧ code e302803162846 = 4700849673950 := by decide
theorem cert_e302803162846 : check e302803162846 [[.under],[.under]] .three = true := by decide
def e302803162870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302803162870 : Closed e302803162870 ∧ code e302803162870 = 4700849673974 := by decide
theorem cert_e302803162870 : check e302803162870 [[.under],[.under]] .three = true := by decide
def e302803162974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302803162974 : Closed e302803162974 ∧ code e302803162974 = 4700849674078 := by decide
theorem cert_e302803162974 : check e302803162974 [[.under],[.under]] .three = true := by decide
def e302803163002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302803163002 : Closed e302803163002 ∧ code e302803163002 = 4700849674106 := by decide
theorem cert_e302803163002 : check e302803163002 [[.under],[.under]] .three = true := by decide
def e302803163094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302803163094 : Closed e302803163094 ∧ code e302803163094 = 4700849674198 := by decide
theorem cert_e302803163094 : check e302803163094 [[.under],[.under]] .three = true := by decide
def e302803163098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302803163098 : Closed e302803163098 ∧ code e302803163098 = 4700849674202 := by decide
theorem cert_e302803163098 : check e302803163098 [[.under],[.under]] .three = true := by decide
def e302803163614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302803163614 : Closed e302803163614 ∧ code e302803163614 = 4700849674718 := by decide
theorem cert_e302803163614 : check e302803163614 [[.under],[.under]] .three = true := by decide
def e302803163638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302803163638 : Closed e302803163638 ∧ code e302803163638 = 4700849674742 := by decide
theorem cert_e302803163638 : check e302803163638 [[.under],[.under]] .three = true := by decide
def e302803164382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302803164382 : Closed e302803164382 ∧ code e302803164382 = 4700849675486 := by decide
theorem cert_e302803164382 : check e302803164382 [[.under],[.under]] .three = true := by decide
def e302803164410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302803164410 : Closed e302803164410 ∧ code e302803164410 = 4700849675514 := by decide
theorem cert_e302803164410 : check e302803164410 [[.under],[.under]] .three = true := by decide
def e302803164982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302803164982 : Closed e302803164982 ∧ code e302803164982 = 4700849676086 := by decide
theorem cert_e302803164982 : check e302803164982 [[.under],[.under]] .three = true := by decide
def e302803164986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302803164986 : Closed e302803164986 ∧ code e302803164986 = 4700849676090 := by decide
theorem cert_e302803164986 : check e302803164986 [[.under],[.under]] .three = true := by decide
def e302803176286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302803176286 : Closed e302803176286 ∧ code e302803176286 = 4700849687390 := by decide
theorem cert_e302803176286 : check e302803176286 [[.under],[.under]] .three = true := by decide
def e302803176314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302803176314 : Closed e302803176314 ∧ code e302803176314 = 4700849687418 := by decide
theorem cert_e302803176314 : check e302803176314 [[.under],[.under]] .three = true := by decide
def e302803176426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302803176426 : Closed e302803176426 ∧ code e302803176426 = 4700849687530 := by decide
theorem cert_e302803176426 : check e302803176426 [[.under],[.under]] .three = true := by decide
def e302803176670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302803176670 : Closed e302803176670 ∧ code e302803176670 = 4700849687774 := by decide
theorem cert_e302803176670 : check e302803176670 [[.under],[.under]] .three = true := by decide
def e302803176698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302803176698 : Closed e302803176698 ∧ code e302803176698 = 4700849687802 := by decide
theorem cert_e302803176698 : check e302803176698 [[.under],[.under]] .three = true := by decide
def e302803177370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803177370 : Closed e302803177370 ∧ code e302803177370 = 4700849688474 := by decide
theorem cert_e302803177370 : check e302803177370 [[.under],[.under]] .three = true := by decide
def e302803186390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302803186390 : Closed e302803186390 ∧ code e302803186390 = 4700849697494 := by decide
theorem cert_e302803186390 : check e302803186390 [[.under],[.under]] .three = true := by decide
def e302803186394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302803186394 : Closed e302803186394 ∧ code e302803186394 = 4700849697498 := by decide
theorem cert_e302803186394 : check e302803186394 [[.under],[.under]] .three = true := by decide
def e302803186410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302803186410 : Closed e302803186410 ∧ code e302803186410 = 4700849697514 := by decide
theorem cert_e302803186410 : check e302803186410 [[.under],[.under]] .three = true := by decide
def e302803186486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302803186486 : Closed e302803186486 ∧ code e302803186486 = 4700849697590 := by decide
theorem cert_e302803186486 : check e302803186486 [[.under],[.under]] .three = true := by decide
def e302803186490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302803186490 : Closed e302803186490 ∧ code e302803186490 = 4700849697594 := by decide
theorem cert_e302803186490 : check e302803186490 [[.under],[.under]] .three = true := by decide
def e302803186586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803186586 : Closed e302803186586 ∧ code e302803186586 = 4700849697690 := by decide
theorem cert_e302803186586 : check e302803186586 [[.under],[.under]] .three = true := by decide
def e302803365230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302803365230 : Closed e302803365230 ∧ code e302803365230 = 4700849876334 := by decide
theorem cert_e302803365230 : check e302803365230 [[.under],[.under]] .three = true := by decide
def e302803365238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302803365238 : Closed e302803365238 ∧ code e302803365238 = 4700849876342 := by decide
theorem cert_e302803365238 : check e302803365238 [[.under],[.under]] .three = true := by decide
def e302803365294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302803365294 : Closed e302803365294 ∧ code e302803365294 = 4700849876398 := by decide
theorem cert_e302803365294 : check e302803365294 [[.under],[.under]] .three = true := by decide
def e302803365306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302803365306 : Closed e302803365306 ∧ code e302803365306 = 4700849876410 := by decide
theorem cert_e302803365306 : check e302803365306 [[.under],[.under]] .three = true := by decide
def e302803365334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302803365334 : Closed e302803365334 ∧ code e302803365334 = 4700849876438 := by decide
theorem cert_e302803365334 : check e302803365334 [[.under],[.under]] .three = true := by decide
def e302803365338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302803365338 : Closed e302803365338 ∧ code e302803365338 = 4700849876442 := by decide
theorem cert_e302803365338 : check e302803365338 [[.under],[.under]] .three = true := by decide
def e302803365550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302803365550 : Closed e302803365550 ∧ code e302803365550 = 4700849876654 := by decide
theorem cert_e302803365550 : check e302803365550 [[.under],[.under]] .three = true := by decide
def e302803365562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302803365562 : Closed e302803365562 ∧ code e302803365562 = 4700849876666 := by decide
theorem cert_e302803365562 : check e302803365562 [[.under],[.under]] .three = true := by decide
def e302803365610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302803365610 : Closed e302803365610 ∧ code e302803365610 = 4700849876714 := by decide
theorem cert_e302803365610 : check e302803365610 [[.under],[.under]] .three = true := by decide
def e302803365718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302803365718 : Closed e302803365718 ∧ code e302803365718 = 4700849876822 := by decide
theorem cert_e302803365718 : check e302803365718 [[.under],[.under]] .three = true := by decide
def e302803365722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302803365722 : Closed e302803365722 ∧ code e302803365722 = 4700849876826 := by decide
theorem cert_e302803365722 : check e302803365722 [[.under],[.under]] .three = true := by decide
def e302803365738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302803365738 : Closed e302803365738 ∧ code e302803365738 = 4700849876842 := by decide
theorem cert_e302803365738 : check e302803365738 [[.under],[.under]] .three = true := by decide
def e302803366766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302803366766 : Closed e302803366766 ∧ code e302803366766 = 4700849877870 := by decide
theorem cert_e302803366766 : check e302803366766 [[.under],[.under]] .three = true := by decide
def e302803366774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302803366774 : Closed e302803366774 ∧ code e302803366774 = 4700849877878 := by decide
theorem cert_e302803366774 : check e302803366774 [[.under],[.under]] .three = true := by decide
def e302803366830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302803366830 : Closed e302803366830 ∧ code e302803366830 = 4700849877934 := by decide
theorem cert_e302803366830 : check e302803366830 [[.under],[.under]] .three = true := by decide
def e302803366842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302803366842 : Closed e302803366842 ∧ code e302803366842 = 4700849877946 := by decide
theorem cert_e302803366842 : check e302803366842 [[.under],[.under]] .three = true := by decide
def e302803366870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302803366870 : Closed e302803366870 ∧ code e302803366870 = 4700849877974 := by decide
theorem cert_e302803366870 : check e302803366870 [[.under],[.under]] .three = true := by decide
def e302803366874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302803366874 : Closed e302803366874 ∧ code e302803366874 = 4700849877978 := by decide
theorem cert_e302803366874 : check e302803366874 [[.under],[.under]] .three = true := by decide
def e302803367150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302803367150 : Closed e302803367150 ∧ code e302803367150 = 4700849878254 := by decide
theorem cert_e302803367150 : check e302803367150 [[.under],[.under]] .three = true := by decide
def e302803367158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302803367158 : Closed e302803367158 ∧ code e302803367158 = 4700849878262 := by decide
theorem cert_e302803367158 : check e302803367158 [[.under],[.under]] .three = true := by decide
def e302803367534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302803367534 : Closed e302803367534 ∧ code e302803367534 = 4700849878638 := by decide
theorem cert_e302803367534 : check e302803367534 [[.under],[.under]] .three = true := by decide
def e302803367546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302803367546 : Closed e302803367546 ∧ code e302803367546 = 4700849878650 := by decide
theorem cert_e302803367546 : check e302803367546 [[.under],[.under]] .three = true := by decide
def e302803367734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803367734 : Closed e302803367734 ∧ code e302803367734 = 4700849878838 := by decide
theorem cert_e302803367734 : check e302803367734 [[.under],[.under]] .three = true := by decide
def e302803367738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803367738 : Closed e302803367738 ∧ code e302803367738 = 4700849878842 := by decide
theorem cert_e302803367738 : check e302803367738 [[.under],[.under]] .three = true := by decide
def e302803368366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302803368366 : Closed e302803368366 ∧ code e302803368366 = 4700849879470 := by decide
theorem cert_e302803368366 : check e302803368366 [[.under],[.under]] .three = true := by decide
def e302803368378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302803368378 : Closed e302803368378 ∧ code e302803368378 = 4700849879482 := by decide
theorem cert_e302803368378 : check e302803368378 [[.under],[.under]] .three = true := by decide
def e302803368426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302803368426 : Closed e302803368426 ∧ code e302803368426 = 4700849879530 := by decide
theorem cert_e302803368426 : check e302803368426 [[.under],[.under]] .three = true := by decide
def e302803368558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302803368558 : Closed e302803368558 ∧ code e302803368558 = 4700849879662 := by decide
theorem cert_e302803368558 : check e302803368558 [[.under],[.under]] .three = true := by decide
def e302803368570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302803368570 : Closed e302803368570 ∧ code e302803368570 = 4700849879674 := by decide
theorem cert_e302803368570 : check e302803368570 [[.under],[.under]] .three = true := by decide
def e302803368858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302803368858 : Closed e302803368858 ∧ code e302803368858 = 4700849879962 := by decide
theorem cert_e302803368858 : check e302803368858 [[.under],[.under]] .three = true := by decide
def e302803369174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302803369174 : Closed e302803369174 ∧ code e302803369174 = 4700849880278 := by decide
theorem cert_e302803369174 : check e302803369174 [[.under],[.under]] .three = true := by decide
def e302803369178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302803369178 : Closed e302803369178 ∧ code e302803369178 = 4700849880282 := by decide
theorem cert_e302803369178 : check e302803369178 [[.under],[.under]] .three = true := by decide
def e302803369194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302803369194 : Closed e302803369194 ∧ code e302803369194 = 4700849880298 := by decide
theorem cert_e302803369194 : check e302803369194 [[.under],[.under]] .three = true := by decide
def e302803369270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803369270 : Closed e302803369270 ∧ code e302803369270 = 4700849880374 := by decide
theorem cert_e302803369270 : check e302803369270 [[.under],[.under]] .three = true := by decide
def e302803369274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803369274 : Closed e302803369274 ∧ code e302803369274 = 4700849880378 := by decide
theorem cert_e302803369274 : check e302803369274 [[.under],[.under]] .three = true := by decide
def e302803369370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302803369370 : Closed e302803369370 ∧ code e302803369370 = 4700849880474 := by decide
theorem cert_e302803369370 : check e302803369370 [[.under],[.under]] .three = true := by decide
def e302803372910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302803372910 : Closed e302803372910 ∧ code e302803372910 = 4700849884014 := by decide
theorem cert_e302803372910 : check e302803372910 [[.under],[.under]] .three = true := by decide
def e302803372918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302803372918 : Closed e302803372918 ∧ code e302803372918 = 4700849884022 := by decide
theorem cert_e302803372918 : check e302803372918 [[.under],[.under]] .three = true := by decide
def e302803372974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302803372974 : Closed e302803372974 ∧ code e302803372974 = 4700849884078 := by decide
theorem cert_e302803372974 : check e302803372974 [[.under],[.under]] .three = true := by decide
def e302803372986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302803372986 : Closed e302803372986 ∧ code e302803372986 = 4700849884090 := by decide
theorem cert_e302803372986 : check e302803372986 [[.under],[.under]] .three = true := by decide
def e302803373014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302803373014 : Closed e302803373014 ∧ code e302803373014 = 4700849884118 := by decide
theorem cert_e302803373014 : check e302803373014 [[.under],[.under]] .three = true := by decide
def e302803373018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302803373018 : Closed e302803373018 ∧ code e302803373018 = 4700849884122 := by decide
theorem cert_e302803373018 : check e302803373018 [[.under],[.under]] .three = true := by decide
def e302803373294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302803373294 : Closed e302803373294 ∧ code e302803373294 = 4700849884398 := by decide
theorem cert_e302803373294 : check e302803373294 [[.under],[.under]] .three = true := by decide
def e302803373302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302803373302 : Closed e302803373302 ∧ code e302803373302 = 4700849884406 := by decide
theorem cert_e302803373302 : check e302803373302 [[.under],[.under]] .three = true := by decide
def e302803373678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302803373678 : Closed e302803373678 ∧ code e302803373678 = 4700849884782 := by decide
theorem cert_e302803373678 : check e302803373678 [[.under],[.under]] .three = true := by decide
def e302803373690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302803373690 : Closed e302803373690 ∧ code e302803373690 = 4700849884794 := by decide
theorem cert_e302803373690 : check e302803373690 [[.under],[.under]] .three = true := by decide
def e302803373878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302803373878 : Closed e302803373878 ∧ code e302803373878 = 4700849884982 := by decide
theorem cert_e302803373878 : check e302803373878 [[.under],[.under]] .three = true := by decide
def e302803373882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302803373882 : Closed e302803373882 ∧ code e302803373882 = 4700849884986 := by decide
theorem cert_e302803373882 : check e302803373882 [[.under],[.under]] .three = true := by decide
def e302803379630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302803379630 : Closed e302803379630 ∧ code e302803379630 = 4700849890734 := by decide
theorem cert_e302803379630 : check e302803379630 [[.under],[.under]] .three = true := by decide
def e302803379642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302803379642 : Closed e302803379642 ∧ code e302803379642 = 4700849890746 := by decide
theorem cert_e302803379642 : check e302803379642 [[.under],[.under]] .three = true := by decide
def e302803379690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302803379690 : Closed e302803379690 ∧ code e302803379690 = 4700849890794 := by decide
theorem cert_e302803379690 : check e302803379690 [[.under],[.under]] .three = true := by decide
def e302803379822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302803379822 : Closed e302803379822 ∧ code e302803379822 = 4700849890926 := by decide
theorem cert_e302803379822 : check e302803379822 [[.under],[.under]] .three = true := by decide
def e302803379834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302803379834 : Closed e302803379834 ∧ code e302803379834 = 4700849890938 := by decide
theorem cert_e302803379834 : check e302803379834 [[.under],[.under]] .three = true := by decide
def e302803380122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803380122 : Closed e302803380122 ∧ code e302803380122 = 4700849891226 := by decide
theorem cert_e302803380122 : check e302803380122 [[.under],[.under]] .three = true := by decide
def e302803382998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302803382998 : Closed e302803382998 ∧ code e302803382998 = 4700849894102 := by decide
theorem cert_e302803382998 : check e302803382998 [[.under],[.under]] .three = true := by decide
def e302803383002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302803383002 : Closed e302803383002 ∧ code e302803383002 = 4700849894106 := by decide
theorem cert_e302803383002 : check e302803383002 [[.under],[.under]] .three = true := by decide
def e302803383018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302803383018 : Closed e302803383018 ∧ code e302803383018 = 4700849894122 := by decide
theorem cert_e302803383018 : check e302803383018 [[.under],[.under]] .three = true := by decide
def e302803383094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302803383094 : Closed e302803383094 ∧ code e302803383094 = 4700849894198 := by decide
theorem cert_e302803383094 : check e302803383094 [[.under],[.under]] .three = true := by decide
def e302803383098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302803383098 : Closed e302803383098 ∧ code e302803383098 = 4700849894202 := by decide
theorem cert_e302803383098 : check e302803383098 [[.under],[.under]] .three = true := by decide
def e302803383194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803383194 : Closed e302803383194 ∧ code e302803383194 = 4700849894298 := by decide
theorem cert_e302803383194 : check e302803383194 [[.under],[.under]] .three = true := by decide
def e302819358446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e302819358446 : Closed e302819358446 ∧ code e302819358446 = 4700865869550 := by decide
theorem cert_e302819358446 : check e302819358446 [[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302819358574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e302819358574 : Closed e302819358574 ∧ code e302819358574 = 4700865869678 := by decide
private def t_e302819358574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem cert_e302819358574 : ¬ IsSelfInterpreter e302819358574 :=
  wSource (t := t_e302819358574) (replay_sound (ps := []) (t := e302819358574) (by decide)) (by decide)
def e302819359470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e302819359470 : Closed e302819359470 ∧ code e302819359470 = 4700865870574 := by decide
theorem cert_e302819359470 : check e302819359470 [[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302819359662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e302819359662 : Closed e302819359662 ∧ code e302819359662 = 4700865870766 := by decide
theorem cert_e302819359662 : check e302819359662 [[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302819360110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e302819360110 : Closed e302819360110 ∧ code e302819360110 = 4700865871214 := by decide
private def t_e302819360110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem cert_e302819360110 : ¬ IsSelfInterpreter e302819360110 :=
  wSource (t := t_e302819360110) (replay_sound (ps := []) (t := e302819360110) (by decide)) (by decide)
def e302819360174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e302819360174 : Closed e302819360174 ∧ code e302819360174 = 4700865871278 := by decide
theorem cert_e302819360174 : check e302819360174 [[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302819364590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e302819364590 : Closed e302819364590 ∧ code e302819364590 = 4700865875694 := by decide
theorem cert_e302819364590 : check e302819364590 [[.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302819364718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e302819364718 : Closed e302819364718 ∧ code e302819364718 = 4700865875822 := by decide
theorem cert_e302819364718 : check e302819364718 [[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302819370734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e302819370734 : Closed e302819370734 ∧ code e302819370734 = 4700865881838 := by decide
theorem cert_e302819370734 : check e302819370734 [[.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302819370926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e302819370926 : Closed e302819370926 ∧ code e302819370926 = 4700865882030 := by decide
theorem cert_e302819370926 : check e302819370926 [[.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
end Blc.Floor42
