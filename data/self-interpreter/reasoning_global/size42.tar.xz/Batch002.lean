import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e276916028138 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276916028138 : Closed e276916028138 ∧ code e276916028138 = 4674962539242 := by decide
theorem cert_e276916028138 : check e276916028138 [[.under]] .three = true := by decide
def e276916028214 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276916028214 : Closed e276916028214 ∧ code e276916028214 = 4674962539318 := by decide
theorem cert_e276916028214 : check e276916028214 [[.under]] .three = true := by decide
def e276916028218 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276916028218 : Closed e276916028218 ∧ code e276916028218 = 4674962539322 := by decide
theorem cert_e276916028218 : check e276916028218 [[.under]] .three = true := by decide
def e276916028314 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276916028314 : Closed e276916028314 ∧ code e276916028314 = 4674962539418 := by decide
theorem cert_e276916028314 : check e276916028314 [[.under]] .three = true := by decide
def e276918289110 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276918289110 : Closed e276918289110 ∧ code e276918289110 = 4674964800214 := by decide
theorem cert_e276918289110 : check e276918289110 [[.under]] .three = true := by decide
def e276918289114 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276918289114 : Closed e276918289114 ∧ code e276918289114 = 4674964800218 := by decide
theorem cert_e276918289114 : check e276918289114 [[.under]] .three = true := by decide
def e276918289130 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276918289130 : Closed e276918289130 ∧ code e276918289130 = 4674964800234 := by decide
theorem cert_e276918289130 : check e276918289130 [[.under]] .three = true := by decide
def e276918289206 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276918289206 : Closed e276918289206 ∧ code e276918289206 = 4674964800310 := by decide
theorem cert_e276918289206 : check e276918289206 [[.under]] .three = true := by decide
def e276918289210 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276918289210 : Closed e276918289210 ∧ code e276918289210 = 4674964800314 := by decide
theorem cert_e276918289210 : check e276918289210 [[.under]] .three = true := by decide
def e276918289306 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276918289306 : Closed e276918289306 ∧ code e276918289306 = 4674964800410 := by decide
theorem cert_e276918289306 : check e276918289306 [[.under]] .three = true := by decide
def e276918354646 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276918354646 : Closed e276918354646 ∧ code e276918354646 = 4674964865750 := by decide
theorem cert_e276918354646 : check e276918354646 [[.under]] .three = true := by decide
def e276918354650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276918354650 : Closed e276918354650 ∧ code e276918354650 = 4674964865754 := by decide
theorem cert_e276918354650 : check e276918354650 [[.under]] .three = true := by decide
def e276918354666 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276918354666 : Closed e276918354666 ∧ code e276918354666 = 4674964865770 := by decide
theorem cert_e276918354666 : check e276918354666 [[.under]] .three = true := by decide
def e276918354742 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276918354742 : Closed e276918354742 ∧ code e276918354742 = 4674964865846 := by decide
theorem cert_e276918354742 : check e276918354742 [[.under]] .three = true := by decide
def e276918354746 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276918354746 : Closed e276918354746 ∧ code e276918354746 = 4674964865850 := by decide
theorem cert_e276918354746 : check e276918354746 [[.under]] .three = true := by decide
def e276918354842 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276918354842 : Closed e276918354842 ∧ code e276918354842 = 4674964865946 := by decide
theorem cert_e276918354842 : check e276918354842 [[.under]] .three = true := by decide
def e276921434838 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276921434838 : Closed e276921434838 ∧ code e276921434838 = 4674967945942 := by decide
theorem cert_e276921434838 : check e276921434838 [[.under]] .three = true := by decide
def e276921434842 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276921434842 : Closed e276921434842 ∧ code e276921434842 = 4674967945946 := by decide
theorem cert_e276921434842 : check e276921434842 [[.under]] .three = true := by decide
def e276921434858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276921434858 : Closed e276921434858 ∧ code e276921434858 = 4674967945962 := by decide
theorem cert_e276921434858 : check e276921434858 [[.under]] .three = true := by decide
def e276921434934 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276921434934 : Closed e276921434934 ∧ code e276921434934 = 4674967946038 := by decide
theorem cert_e276921434934 : check e276921434934 [[.under]] .three = true := by decide
def e276921434938 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276921434938 : Closed e276921434938 ∧ code e276921434938 = 4674967946042 := by decide
theorem cert_e276921434938 : check e276921434938 [[.under]] .three = true := by decide
def e276921435034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276921435034 : Closed e276921435034 ∧ code e276921435034 = 4674967946138 := by decide
theorem cert_e276921435034 : check e276921435034 [[.under]] .three = true := by decide
def e276921533142 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276921533142 : Closed e276921533142 ∧ code e276921533142 = 4674968044246 := by decide
theorem cert_e276921533142 : check e276921533142 [[.under]] .three = true := by decide
def e276921533146 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276921533146 : Closed e276921533146 ∧ code e276921533146 = 4674968044250 := by decide
theorem cert_e276921533146 : check e276921533146 [[.under]] .three = true := by decide
def e276921533162 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276921533162 : Closed e276921533162 ∧ code e276921533162 = 4674968044266 := by decide
theorem cert_e276921533162 : check e276921533162 [[.under]] .three = true := by decide
def e276921533238 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276921533238 : Closed e276921533238 ∧ code e276921533238 = 4674968044342 := by decide
theorem cert_e276921533238 : check e276921533238 [[.under]] .three = true := by decide
def e276921533242 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276921533242 : Closed e276921533242 ∧ code e276921533242 = 4674968044346 := by decide
theorem cert_e276921533242 : check e276921533242 [[.under]] .three = true := by decide
def e276921533338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276921533338 : Closed e276921533338 ∧ code e276921533338 = 4674968044442 := by decide
theorem cert_e276921533338 : check e276921533338 [[.under]] .three = true := by decide
def e276923073238 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276923073238 : Closed e276923073238 ∧ code e276923073238 = 4674969584342 := by decide
theorem cert_e276923073238 : check e276923073238 [[.under]] .three = true := by decide
def e276923073242 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276923073242 : Closed e276923073242 ∧ code e276923073242 = 4674969584346 := by decide
theorem cert_e276923073242 : check e276923073242 [[.under]] .three = true := by decide
def e276923073258 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276923073258 : Closed e276923073258 ∧ code e276923073258 = 4674969584362 := by decide
theorem cert_e276923073258 : check e276923073258 [[.under]] .three = true := by decide
def e276923073334 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276923073334 : Closed e276923073334 ∧ code e276923073334 = 4674969584438 := by decide
theorem cert_e276923073334 : check e276923073334 [[.under]] .three = true := by decide
def e276923073338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276923073338 : Closed e276923073338 ∧ code e276923073338 = 4674969584442 := by decide
theorem cert_e276923073338 : check e276923073338 [[.under]] .three = true := by decide
def e276923073434 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276923073434 : Closed e276923073434 ∧ code e276923073434 = 4674969584538 := by decide
theorem cert_e276923073434 : check e276923073434 [[.under]] .three = true := by decide
def e276923106006 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276923106006 : Closed e276923106006 ∧ code e276923106006 = 4674969617110 := by decide
theorem cert_e276923106006 : check e276923106006 [[.under]] .three = true := by decide
def e276923106010 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276923106010 : Closed e276923106010 ∧ code e276923106010 = 4674969617114 := by decide
theorem cert_e276923106010 : check e276923106010 [[.under]] .three = true := by decide
def e276923106026 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276923106026 : Closed e276923106026 ∧ code e276923106026 = 4674969617130 := by decide
theorem cert_e276923106026 : check e276923106026 [[.under]] .three = true := by decide
def e276923106102 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276923106102 : Closed e276923106102 ∧ code e276923106102 = 4674969617206 := by decide
theorem cert_e276923106102 : check e276923106102 [[.under]] .three = true := by decide
def e276923106106 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276923106106 : Closed e276923106106 ∧ code e276923106106 = 4674969617210 := by decide
theorem cert_e276923106106 : check e276923106106 [[.under]] .three = true := by decide
def e276923106202 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276923106202 : Closed e276923106202 ∧ code e276923106202 = 4674969617306 := by decide
theorem cert_e276923106202 : check e276923106202 [[.under]] .three = true := by decide
def e282442045466 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282442045466 : Closed e282442045466 ∧ code e282442045466 = 4680488556570 := by decide
theorem cert_e282442045466 : check e282442045466 [[.under]] .width = true := by decide
def e282442176538 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282442176538 : Closed e282442176538 ∧ code e282442176538 = 4680488687642 := by decide
theorem cert_e282442176538 : check e282442176538 [[.under]] .width = true := by decide
def e282443094042 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443094042 : Closed e282443094042 ∧ code e282443094042 = 4680489605146 := by decide
theorem cert_e282443094042 : check e282443094042 [[.under]] .width = true := by decide
def e282443290650 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443290650 : Closed e282443290650 ∧ code e282443290650 = 4680489801754 := by decide
theorem cert_e282443290650 : check e282443290650 [[.under]] .width = true := by decide
def e282443749402 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443749402 : Closed e282443749402 ∧ code e282443749402 = 4680490260506 := by decide
theorem cert_e282443749402 : check e282443749402 [[.under]] .width = true := by decide
def e282443814938 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443814938 : Closed e282443814938 ∧ code e282443814938 = 4680490326042 := by decide
theorem cert_e282443814938 : check e282443814938 [[.under]] .width = true := by decide
def e282448336922 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282448336922 : Closed e282448336922 ∧ code e282448336922 = 4680494848026 := by decide
theorem cert_e282448336922 : check e282448336922 [[.under]] .width = true := by decide
def e282448467994 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282448467994 : Closed e282448467994 ∧ code e282448467994 = 4680494979098 := by decide
theorem cert_e282448467994 : check e282448467994 [[.under]] .width = true := by decide
def e282454628378 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282454628378 : Closed e282454628378 ∧ code e282454628378 = 4680501139482 := by decide
theorem cert_e282454628378 : check e282454628378 [[.under]] .width = true := by decide
def e282454824986 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282454824986 : Closed e282454824986 ∧ code e282454824986 = 4680501336090 := by decide
theorem cert_e282454824986 : check e282454824986 [[.under]] .width = true := by decide
def e282457905178 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282457905178 : Closed e282457905178 ∧ code e282457905178 = 4680504416282 := by decide
theorem cert_e282457905178 : check e282457905178 [[.under]] .width = true := by decide
def e282457970714 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282457970714 : Closed e282457970714 ∧ code e282457970714 = 4680504481818 := by decide
theorem cert_e282457970714 : check e282457970714 [[.under]] .width = true := by decide
def e299238468974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e299238468974 : Closed e299238468974 ∧ code e299238468974 = 4697284980078 := by decide
theorem cert_e299238468974 : check e299238468974 [[.under],[.under,.left]] .smaller = true := by decide
def e299238468982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e299238468982 : Closed e299238468982 ∧ code e299238468982 = 4697284980086 := by decide
theorem cert_e299238468982 : check e299238468982 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e299238469038 : Closed e299238469038 ∧ code e299238469038 = 4697284980142 := by decide
theorem cert_e299238469038 : check e299238469038 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e299238469050 : Closed e299238469050 ∧ code e299238469050 = 4697284980154 := by decide
theorem cert_e299238469050 : check e299238469050 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e299238469078 : Closed e299238469078 ∧ code e299238469078 = 4697284980182 := by decide
theorem cert_e299238469078 : check e299238469078 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e299238469082 : Closed e299238469082 ∧ code e299238469082 = 4697284980186 := by decide
theorem cert_e299238469082 : check e299238469082 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e299238469294 : Closed e299238469294 ∧ code e299238469294 = 4697284980398 := by decide
theorem cert_e299238469294 : check e299238469294 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e299238469306 : Closed e299238469306 ∧ code e299238469306 = 4697284980410 := by decide
theorem cert_e299238469306 : check e299238469306 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469354 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e299238469354 : Closed e299238469354 ∧ code e299238469354 = 4697284980458 := by decide
theorem cert_e299238469354 : check e299238469354 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e299238469462 : Closed e299238469462 ∧ code e299238469462 = 4697284980566 := by decide
theorem cert_e299238469462 : check e299238469462 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469466 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e299238469466 : Closed e299238469466 ∧ code e299238469466 = 4697284980570 := by decide
theorem cert_e299238469466 : check e299238469466 [[.under],[.under,.left]] .smaller = true := by decide
def e299238469482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e299238469482 : Closed e299238469482 ∧ code e299238469482 = 4697284980586 := by decide
theorem cert_e299238469482 : check e299238469482 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e299238470510 : Closed e299238470510 ∧ code e299238470510 = 4697284981614 := by decide
theorem cert_e299238470510 : check e299238470510 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e299238470518 : Closed e299238470518 ∧ code e299238470518 = 4697284981622 := by decide
theorem cert_e299238470518 : check e299238470518 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e299238470574 : Closed e299238470574 ∧ code e299238470574 = 4697284981678 := by decide
theorem cert_e299238470574 : check e299238470574 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e299238470586 : Closed e299238470586 ∧ code e299238470586 = 4697284981690 := by decide
theorem cert_e299238470586 : check e299238470586 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e299238470614 : Closed e299238470614 ∧ code e299238470614 = 4697284981718 := by decide
theorem cert_e299238470614 : check e299238470614 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e299238470618 : Closed e299238470618 ∧ code e299238470618 = 4697284981722 := by decide
theorem cert_e299238470618 : check e299238470618 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e299238470894 : Closed e299238470894 ∧ code e299238470894 = 4697284981998 := by decide
theorem cert_e299238470894 : check e299238470894 [[.under],[.under,.left]] .smaller = true := by decide
def e299238470902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e299238470902 : Closed e299238470902 ∧ code e299238470902 = 4697284982006 := by decide
theorem cert_e299238470902 : check e299238470902 [[.under],[.under,.left]] .smaller = true := by decide
def e299238471278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299238471278 : Closed e299238471278 ∧ code e299238471278 = 4697284982382 := by decide
theorem cert_e299238471278 : check e299238471278 [[.under],[.under,.left]] .smaller = true := by decide
def e299238471290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299238471290 : Closed e299238471290 ∧ code e299238471290 = 4697284982394 := by decide
theorem cert_e299238471290 : check e299238471290 [[.under],[.under,.left]] .smaller = true := by decide
def e299238471478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299238471478 : Closed e299238471478 ∧ code e299238471478 = 4697284982582 := by decide
theorem cert_e299238471478 : check e299238471478 [[.under],[.under,.left]] .smaller = true := by decide
def e299238471482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299238471482 : Closed e299238471482 ∧ code e299238471482 = 4697284982586 := by decide
theorem cert_e299238471482 : check e299238471482 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e299238472110 : Closed e299238472110 ∧ code e299238472110 = 4697284983214 := by decide
theorem cert_e299238472110 : check e299238472110 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e299238472122 : Closed e299238472122 ∧ code e299238472122 = 4697284983226 := by decide
theorem cert_e299238472122 : check e299238472122 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e299238472170 : Closed e299238472170 ∧ code e299238472170 = 4697284983274 := by decide
theorem cert_e299238472170 : check e299238472170 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299238472302 : Closed e299238472302 ∧ code e299238472302 = 4697284983406 := by decide
theorem cert_e299238472302 : check e299238472302 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299238472314 : Closed e299238472314 ∧ code e299238472314 = 4697284983418 := by decide
theorem cert_e299238472314 : check e299238472314 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472602 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299238472602 : Closed e299238472602 ∧ code e299238472602 = 4697284983706 := by decide
theorem cert_e299238472602 : check e299238472602 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e299238472918 : Closed e299238472918 ∧ code e299238472918 = 4697284984022 := by decide
theorem cert_e299238472918 : check e299238472918 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472922 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e299238472922 : Closed e299238472922 ∧ code e299238472922 = 4697284984026 := by decide
theorem cert_e299238472922 : check e299238472922 [[.under],[.under,.left]] .smaller = true := by decide
def e299238472938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e299238472938 : Closed e299238472938 ∧ code e299238472938 = 4697284984042 := by decide
theorem cert_e299238472938 : check e299238472938 [[.under],[.under,.left]] .smaller = true := by decide
def e299238473014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299238473014 : Closed e299238473014 ∧ code e299238473014 = 4697284984118 := by decide
theorem cert_e299238473014 : check e299238473014 [[.under],[.under,.left]] .smaller = true := by decide
def e299238473018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299238473018 : Closed e299238473018 ∧ code e299238473018 = 4697284984122 := by decide
theorem cert_e299238473018 : check e299238473018 [[.under],[.under,.left]] .smaller = true := by decide
def e299238473114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299238473114 : Closed e299238473114 ∧ code e299238473114 = 4697284984218 := by decide
theorem cert_e299238473114 : check e299238473114 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299238476654 : Closed e299238476654 ∧ code e299238476654 = 4697284987758 := by decide
theorem cert_e299238476654 : check e299238476654 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299238476662 : Closed e299238476662 ∧ code e299238476662 = 4697284987766 := by decide
theorem cert_e299238476662 : check e299238476662 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476718 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299238476718 : Closed e299238476718 ∧ code e299238476718 = 4697284987822 := by decide
theorem cert_e299238476718 : check e299238476718 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299238476730 : Closed e299238476730 ∧ code e299238476730 = 4697284987834 := by decide
theorem cert_e299238476730 : check e299238476730 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299238476758 : Closed e299238476758 ∧ code e299238476758 = 4697284987862 := by decide
theorem cert_e299238476758 : check e299238476758 [[.under],[.under,.left]] .smaller = true := by decide
def e299238476762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299238476762 : Closed e299238476762 ∧ code e299238476762 = 4697284987866 := by decide
theorem cert_e299238476762 : check e299238476762 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299238477038 : Closed e299238477038 ∧ code e299238477038 = 4697284988142 := by decide
theorem cert_e299238477038 : check e299238477038 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299238477046 : Closed e299238477046 ∧ code e299238477046 = 4697284988150 := by decide
theorem cert_e299238477046 : check e299238477046 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299238477422 : Closed e299238477422 ∧ code e299238477422 = 4697284988526 := by decide
theorem cert_e299238477422 : check e299238477422 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299238477434 : Closed e299238477434 ∧ code e299238477434 = 4697284988538 := by decide
theorem cert_e299238477434 : check e299238477434 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299238477622 : Closed e299238477622 ∧ code e299238477622 = 4697284988726 := by decide
theorem cert_e299238477622 : check e299238477622 [[.under],[.under,.left]] .smaller = true := by decide
def e299238477626 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299238477626 : Closed e299238477626 ∧ code e299238477626 = 4697284988730 := by decide
theorem cert_e299238477626 : check e299238477626 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e299238483374 : Closed e299238483374 ∧ code e299238483374 = 4697284994478 := by decide
theorem cert_e299238483374 : check e299238483374 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e299238483386 : Closed e299238483386 ∧ code e299238483386 = 4697284994490 := by decide
theorem cert_e299238483386 : check e299238483386 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e299238483434 : Closed e299238483434 ∧ code e299238483434 = 4697284994538 := by decide
theorem cert_e299238483434 : check e299238483434 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e299238483566 : Closed e299238483566 ∧ code e299238483566 = 4697284994670 := by decide
theorem cert_e299238483566 : check e299238483566 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e299238483578 : Closed e299238483578 ∧ code e299238483578 = 4697284994682 := by decide
theorem cert_e299238483578 : check e299238483578 [[.under],[.under,.left]] .smaller = true := by decide
def e299238483866 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e299238483866 : Closed e299238483866 ∧ code e299238483866 = 4697284994970 := by decide
theorem cert_e299238483866 : check e299238483866 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e299238486742 : Closed e299238486742 ∧ code e299238486742 = 4697284997846 := by decide
theorem cert_e299238486742 : check e299238486742 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e299238486746 : Closed e299238486746 ∧ code e299238486746 = 4697284997850 := by decide
theorem cert_e299238486746 : check e299238486746 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e299238486762 : Closed e299238486762 ∧ code e299238486762 = 4697284997866 := by decide
theorem cert_e299238486762 : check e299238486762 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e299238486838 : Closed e299238486838 ∧ code e299238486838 = 4697284997942 := by decide
theorem cert_e299238486838 : check e299238486838 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e299238486842 : Closed e299238486842 ∧ code e299238486842 = 4697284997946 := by decide
theorem cert_e299238486842 : check e299238486842 [[.under],[.under,.left]] .smaller = true := by decide
def e299238486938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e299238486938 : Closed e299238486938 ∧ code e299238486938 = 4697284998042 := by decide
theorem cert_e299238486938 : check e299238486938 [[.under],[.under,.left]] .smaller = true := by decide
def e299238602478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e299238602478 : Closed e299238602478 ∧ code e299238602478 = 4697285113582 := by decide
theorem cert_e299238602478 : check e299238602478 [[.left],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e299238602606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e299238602606 : Closed e299238602606 ∧ code e299238602606 = 4697285113710 := by decide
theorem cert_e299238602606 : check e299238602606 [[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e299238602614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e299238602614 : Closed e299238602614 ∧ code e299238602614 = 4697285113718 := by decide
theorem cert_e299238602614 : check e299238602614 [[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e299238603502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e299238603502 : Closed e299238603502 ∧ code e299238603502 = 4697285114606 := by decide
theorem cert_e299238603502 : check e299238603502 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238603694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e299238603694 : Closed e299238603694 ∧ code e299238603694 = 4697285114798 := by decide
theorem cert_e299238603694 : check e299238603694 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238603706 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e299238603706 : Closed e299238603706 ∧ code e299238603706 = 4697285114810 := by decide
theorem cert_e299238603706 : check e299238603706 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238604142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e299238604142 : Closed e299238604142 ∧ code e299238604142 = 4697285115246 := by decide
theorem cert_e299238604142 : check e299238604142 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e299238604150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e299238604150 : Closed e299238604150 ∧ code e299238604150 = 4697285115254 := by decide
theorem cert_e299238604150 : check e299238604150 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e299238604206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e299238604206 : Closed e299238604206 ∧ code e299238604206 = 4697285115310 := by decide
theorem cert_e299238604206 : check e299238604206 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e299238604218 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e299238604218 : Closed e299238604218 ∧ code e299238604218 = 4697285115322 := by decide
theorem cert_e299238604218 : check e299238604218 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e299238604246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e299238604246 : Closed e299238604246 ∧ code e299238604246 = 4697285115350 := by decide
private def t_e299238604246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e299238604246 : ¬ IsSelfInterpreter e299238604246 :=
  wSource (t := t_e299238604246) (replay_sound (ps := []) (t := e299238604246) (by decide)) (by decide)
def e299238604250 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e299238604250 : Closed e299238604250 ∧ code e299238604250 = 4697285115354 := by decide
private def t_e299238604250 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e299238604250 : ¬ IsSelfInterpreter e299238604250 :=
  wSource (t := t_e299238604250) (replay_sound (ps := []) (t := e299238604250) (by decide)) (by decide)
def e299238608622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e299238608622 : Closed e299238608622 ∧ code e299238608622 = 4697285119726 := by decide
theorem cert_e299238608622 : check e299238608622 [[.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e299238608750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e299238608750 : Closed e299238608750 ∧ code e299238608750 = 4697285119854 := by decide
theorem cert_e299238608750 : check e299238608750 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e299238608758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e299238608758 : Closed e299238608758 ∧ code e299238608758 = 4697285119862 := by decide
theorem cert_e299238608758 : check e299238608758 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e299238611438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e299238611438 : Closed e299238611438 ∧ code e299238611438 = 4697285122542 := by decide
theorem cert_e299238611438 : check e299238611438 [[.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e299238612206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e299238612206 : Closed e299238612206 ∧ code e299238612206 = 4697285123310 := by decide
theorem cert_e299238612206 : check e299238612206 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e299238612214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e299238612214 : Closed e299238612214 ∧ code e299238612214 = 4697285123318 := by decide
theorem cert_e299238612214 : check e299238612214 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e299238614766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e299238614766 : Closed e299238614766 ∧ code e299238614766 = 4697285125870 := by decide
theorem cert_e299238614766 : checkPay e299238614766 [[.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e299238614958 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e299238614958 : Closed e299238614958 ∧ code e299238614958 = 4697285126062 := by decide
theorem cert_e299238614958 : checkPay e299238614958 [[.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e299238614970 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e299238614970 : Closed e299238614970 ∧ code e299238614970 = 4697285126074 := by decide
theorem cert_e299238614970 : checkPay e299238614970 [[.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e299238615534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e299238615534 : Closed e299238615534 ∧ code e299238615534 = 4697285126638 := by decide
theorem cert_e299238615534 : checkPay e299238615534 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e299238616686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e299238616686 : Closed e299238616686 ∧ code e299238616686 = 4697285127790 := by decide
theorem cert_e299238616686 : checkPay e299238616686 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e299238616698 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e299238616698 : Closed e299238616698 ∧ code e299238616698 = 4697285127802 := by decide
theorem cert_e299238616698 : checkPay e299238616698 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e299238617966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e299238617966 : Closed e299238617966 ∧ code e299238617966 = 4697285129070 := by decide
theorem cert_e299238617966 : check e299238617966 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238617974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e299238617974 : Closed e299238617974 ∧ code e299238617974 = 4697285129078 := by decide
theorem cert_e299238617974 : check e299238617974 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e299238618030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e299238618030 : Closed e299238618030 ∧ code e299238618030 = 4697285129134 := by decide
theorem cert_e299238618030 : check e299238618030 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238618042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e299238618042 : Closed e299238618042 ∧ code e299238618042 = 4697285129146 := by decide
theorem cert_e299238618042 : check e299238618042 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e299238618070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e299238618070 : Closed e299238618070 ∧ code e299238618070 = 4697285129174 := by decide
theorem cert_e299238618070 : check e299238618070 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e299238618074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e299238618074 : Closed e299238618074 ∧ code e299238618074 = 4697285129178 := by decide
theorem cert_e299238618074 : check e299238618074 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e299238618350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e299238618350 : Closed e299238618350 ∧ code e299238618350 = 4697285129454 := by decide
theorem cert_e299238618350 : check e299238618350 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238618358 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e299238618358 : Closed e299238618358 ∧ code e299238618358 = 4697285129462 := by decide
theorem cert_e299238618358 : check e299238618358 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238618734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e299238618734 : Closed e299238618734 ∧ code e299238618734 = 4697285129838 := by decide
theorem cert_e299238618734 : check e299238618734 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238618746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e299238618746 : Closed e299238618746 ∧ code e299238618746 = 4697285129850 := by decide
theorem cert_e299238618746 : check e299238618746 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e299238618934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e299238618934 : Closed e299238618934 ∧ code e299238618934 = 4697285130038 := by decide
private def t_e299238618934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e299238618934 : ¬ IsSelfInterpreter e299238618934 :=
  wSource (t := t_e299238618934) (replay_sound (ps := []) (t := e299238618934) (by decide)) (by decide)
def e299238618938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e299238618938 : Closed e299238618938 ∧ code e299238618938 = 4697285130042 := by decide
private def t_e299238618938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e299238618938 : ¬ IsSelfInterpreter e299238618938 :=
  wSource (t := t_e299238618938) (replay_sound (ps := []) (t := e299238618938) (by decide)) (by decide)
def e299238624110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299238624110 : Closed e299238624110 ∧ code e299238624110 = 4697285135214 := by decide
theorem cert_e299238624110 : check e299238624110 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299238624118 : Closed e299238624118 ∧ code e299238624118 = 4697285135222 := by decide
theorem cert_e299238624118 : check e299238624118 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299238624174 : Closed e299238624174 ∧ code e299238624174 = 4697285135278 := by decide
theorem cert_e299238624174 : check e299238624174 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299238624186 : Closed e299238624186 ∧ code e299238624186 = 4697285135290 := by decide
theorem cert_e299238624186 : check e299238624186 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299238624214 : Closed e299238624214 ∧ code e299238624214 = 4697285135318 := by decide
theorem cert_e299238624214 : check e299238624214 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624218 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299238624218 : Closed e299238624218 ∧ code e299238624218 = 4697285135322 := by decide
theorem cert_e299238624218 : check e299238624218 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299238624494 : Closed e299238624494 ∧ code e299238624494 = 4697285135598 := by decide
theorem cert_e299238624494 : check e299238624494 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299238624502 : Closed e299238624502 ∧ code e299238624502 = 4697285135606 := by decide
theorem cert_e299238624502 : check e299238624502 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299238624878 : Closed e299238624878 ∧ code e299238624878 = 4697285135982 := by decide
theorem cert_e299238624878 : check e299238624878 [[.under],[.under,.left]] .smaller = true := by decide
def e299238624890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299238624890 : Closed e299238624890 ∧ code e299238624890 = 4697285135994 := by decide
theorem cert_e299238624890 : check e299238624890 [[.under],[.under,.left]] .smaller = true := by decide
def e299238625078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299238625078 : Closed e299238625078 ∧ code e299238625078 = 4697285136182 := by decide
theorem cert_e299238625078 : check e299238625078 [[.under],[.under,.left]] .smaller = true := by decide
def e299238625082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299238625082 : Closed e299238625082 ∧ code e299238625082 = 4697285136186 := by decide
theorem cert_e299238625082 : check e299238625082 [[.under],[.under,.left]] .smaller = true := by decide
end Blc.Floor42
