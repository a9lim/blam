import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131212273262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131212273262 : Closed e1131212273262 ∧ code e1131212273262 = 5529258784366 := by decide
private def t_e1131212273262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e1131212273262 : ¬ IsSelfInterpreter e1131212273262 :=
  wSource (t := t_e1131212273262) (replay_sound (ps := []) (t := e1131212273262) (by decide)) (by decide)
def e1131212273274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131212273274 : Closed e1131212273274 ∧ code e1131212273274 = 5529258784378 := by decide
private def t_e1131212273274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e1131212273274 : ¬ IsSelfInterpreter e1131212273274 :=
  wSource (t := t_e1131212273274) (replay_sound (ps := []) (t := e1131212273274) (by decide)) (by decide)
def e1131212273462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131212273462 : Closed e1131212273462 ∧ code e1131212273462 = 5529258784566 := by decide
private def t_e1131212273462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1131212273462 : ¬ IsSelfInterpreter e1131212273462 :=
  wSource (t := t_e1131212273462) (replay_sound (ps := []) (t := e1131212273462) (by decide)) (by decide)
def e1131212273466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131212273466 : Closed e1131212273466 ∧ code e1131212273466 = 5529258784570 := by decide
private def t_e1131212273466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1131212273466 : ¬ IsSelfInterpreter e1131212273466 :=
  wSource (t := t_e1131212273466) (replay_sound (ps := []) (t := e1131212273466) (by decide)) (by decide)
def e1131212274102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1131212274102 : Closed e1131212274102 ∧ code e1131212274102 = 5529258785206 := by decide
theorem cert_e1131212274102 : check e1131212274102 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.under,.under,.under,.left],[.under,.under,.under],[.under,.under,.under,.left]] .identityHead = true := by decide
def e1131212274134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1131212274134 : Closed e1131212274134 ∧ code e1131212274134 = 5529258785238 := by decide
def e1131212274138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1131212274138 : Closed e1131212274138 ∧ code e1131212274138 = 5529258785242 := by decide
private def t_e1131212274138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem cert_e1131212274138 : ¬ IsSelfInterpreter e1131212274138 :=
  wSource (t := t_e1131212274138) (replay_sound (ps := []) (t := e1131212274138) (by decide)) (by decide)
def e1131212274294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131212274294 : Closed e1131212274294 ∧ code e1131212274294 = 5529258785398 := by decide
def e1131212274486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131212274486 : Closed e1131212274486 ∧ code e1131212274486 = 5529258785590 := by decide
private def t_e1131212274486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem cert_e1131212274486 : ¬ IsSelfInterpreter e1131212274486 :=
  wSource (t := t_e1131212274486) (replay_sound (ps := []) (t := e1131212274486) (by decide)) (by decide)
def e1131212274490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131212274490 : Closed e1131212274490 ∧ code e1131212274490 = 5529258785594 := by decide
private def t_e1131212274490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem cert_e1131212274490 : ¬ IsSelfInterpreter e1131212274490 :=
  wSource (t := t_e1131212274490) (replay_sound (ps := []) (t := e1131212274490) (by decide)) (by decide)
def e1131212281710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1131212281710 : Closed e1131212281710 ∧ code e1131212281710 = 5529258792814 := by decide
def e1131212281718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1131212281718 : Closed e1131212281718 ∧ code e1131212281718 = 5529258792822 := by decide
def e1131212281782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1131212281782 : Closed e1131212281782 ∧ code e1131212281782 = 5529258792886 := by decide
def e1131212283118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131212283118 : Closed e1131212283118 ∧ code e1131212283118 = 5529258794222 := by decide
def e1131212283126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131212283126 : Closed e1131212283126 ∧ code e1131212283126 = 5529258794230 := by decide
def e1131212283510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131212283510 : Closed e1131212283510 ∧ code e1131212283510 = 5529258794614 := by decide
def e1131212295022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131212295022 : Closed e1131212295022 ∧ code e1131212295022 = 5529258806126 := by decide
theorem cert_e1131212295022 : check e1131212295022 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131212295030 : Closed e1131212295030 ∧ code e1131212295030 = 5529258806134 := by decide
theorem cert_e1131212295030 : check e1131212295030 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131212295086 : Closed e1131212295086 ∧ code e1131212295086 = 5529258806190 := by decide
theorem cert_e1131212295086 : check e1131212295086 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131212295098 : Closed e1131212295098 ∧ code e1131212295098 = 5529258806202 := by decide
private def t_e1131212295098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1131212295098 : ¬ IsSelfInterpreter e1131212295098 :=
  wSource (t := t_e1131212295098) (replay_sound (ps := []) (t := e1131212295098) (by decide)) (by decide)
def e1131212295126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131212295126 : Closed e1131212295126 ∧ code e1131212295126 = 5529258806230 := by decide
theorem cert_e1131212295126 : check e1131212295126 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131212295130 : Closed e1131212295130 ∧ code e1131212295130 = 5529258806234 := by decide
private def t_e1131212295130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1131212295130 : ¬ IsSelfInterpreter e1131212295130 :=
  wSource (t := t_e1131212295130) (replay_sound (ps := []) (t := e1131212295130) (by decide)) (by decide)
def e1131212295406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131212295406 : Closed e1131212295406 ∧ code e1131212295406 = 5529258806510 := by decide
theorem cert_e1131212295406 : check e1131212295406 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131212295414 : Closed e1131212295414 ∧ code e1131212295414 = 5529258806518 := by decide
theorem cert_e1131212295414 : check e1131212295414 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131212295790 : Closed e1131212295790 ∧ code e1131212295790 = 5529258806894 := by decide
theorem cert_e1131212295790 : check e1131212295790 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131212295802 : Closed e1131212295802 ∧ code e1131212295802 = 5529258806906 := by decide
theorem cert_e1131212295802 : check e1131212295802 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131212295990 : Closed e1131212295990 ∧ code e1131212295990 = 5529258807094 := by decide
theorem cert_e1131212295990 : check e1131212295990 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212295994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131212295994 : Closed e1131212295994 ∧ code e1131212295994 = 5529258807098 := by decide
theorem cert_e1131212295994 : check e1131212295994 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1131212301750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1131212301750 : Closed e1131212301750 ∧ code e1131212301750 = 5529258812854 := by decide
def e1131212301782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1131212301782 : Closed e1131212301782 ∧ code e1131212301782 = 5529258812886 := by decide
def e1131212301786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1131212301786 : Closed e1131212301786 ∧ code e1131212301786 = 5529258812890 := by decide
private def t_e1131212301786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem cert_e1131212301786 : ¬ IsSelfInterpreter e1131212301786 :=
  wSource (t := t_e1131212301786) (replay_sound (ps := []) (t := e1131212301786) (by decide)) (by decide)
def e1131212301942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131212301942 : Closed e1131212301942 ∧ code e1131212301942 = 5529258813046 := by decide
def e1131212302134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131212302134 : Closed e1131212302134 ∧ code e1131212302134 = 5529258813238 := by decide
theorem cert_e1131212302134 : check e1131212302134 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1131212302138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131212302138 : Closed e1131212302138 ∧ code e1131212302138 = 5529258813242 := by decide
theorem cert_e1131212302138 : check e1131212302138 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1131212639086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131212639086 : Closed e1131212639086 ∧ code e1131212639086 = 5529259150190 := by decide
private def t_e1131212639086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1131212639086 : ¬ IsSelfInterpreter e1131212639086 :=
  wSource (t := t_e1131212639086) (replay_sound (ps := []) (t := e1131212639086) (by decide)) (by decide)
def e1131212639094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131212639094 : Closed e1131212639094 ∧ code e1131212639094 = 5529259150198 := by decide
private def t_e1131212639094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1131212639094 : ¬ IsSelfInterpreter e1131212639094 :=
  wSource (t := t_e1131212639094) (replay_sound (ps := []) (t := e1131212639094) (by decide)) (by decide)
def e1131212639150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131212639150 : Closed e1131212639150 ∧ code e1131212639150 = 5529259150254 := by decide
private def t_e1131212639150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1131212639150 : ¬ IsSelfInterpreter e1131212639150 :=
  wSource (t := t_e1131212639150) (replay_sound (ps := []) (t := e1131212639150) (by decide)) (by decide)
def e1131212639162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131212639162 : Closed e1131212639162 ∧ code e1131212639162 = 5529259150266 := by decide
private def t_e1131212639162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1131212639162 : ¬ IsSelfInterpreter e1131212639162 :=
  wSource (t := t_e1131212639162) (replay_sound (ps := []) (t := e1131212639162) (by decide)) (by decide)
def e1131212639190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131212639190 : Closed e1131212639190 ∧ code e1131212639190 = 5529259150294 := by decide
private def t_e1131212639190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1131212639190 : ¬ IsSelfInterpreter e1131212639190 :=
  wSource (t := t_e1131212639190) (replay_sound (ps := []) (t := e1131212639190) (by decide)) (by decide)
def e1131212639194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131212639194 : Closed e1131212639194 ∧ code e1131212639194 = 5529259150298 := by decide
private def t_e1131212639194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1131212639194 : ¬ IsSelfInterpreter e1131212639194 :=
  wSource (t := t_e1131212639194) (replay_sound (ps := []) (t := e1131212639194) (by decide)) (by decide)
def e1131212639470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131212639470 : Closed e1131212639470 ∧ code e1131212639470 = 5529259150574 := by decide
private def t_e1131212639470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1131212639470 : ¬ IsSelfInterpreter e1131212639470 :=
  wSource (t := t_e1131212639470) (replay_sound (ps := []) (t := e1131212639470) (by decide)) (by decide)
def e1131212639478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131212639478 : Closed e1131212639478 ∧ code e1131212639478 = 5529259150582 := by decide
private def t_e1131212639478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1131212639478 : ¬ IsSelfInterpreter e1131212639478 :=
  wSource (t := t_e1131212639478) (replay_sound (ps := []) (t := e1131212639478) (by decide)) (by decide)
def e1131212639854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131212639854 : Closed e1131212639854 ∧ code e1131212639854 = 5529259150958 := by decide
private def t_e1131212639854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1131212639854 : ¬ IsSelfInterpreter e1131212639854 :=
  wSource (t := t_e1131212639854) (replay_sound (ps := []) (t := e1131212639854) (by decide)) (by decide)
def e1131212639866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131212639866 : Closed e1131212639866 ∧ code e1131212639866 = 5529259150970 := by decide
private def t_e1131212639866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1131212639866 : ¬ IsSelfInterpreter e1131212639866 :=
  wSource (t := t_e1131212639866) (replay_sound (ps := []) (t := e1131212639866) (by decide)) (by decide)
def e1131212640054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131212640054 : Closed e1131212640054 ∧ code e1131212640054 = 5529259151158 := by decide
private def t_e1131212640054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1131212640054 : ¬ IsSelfInterpreter e1131212640054 :=
  wSource (t := t_e1131212640054) (replay_sound (ps := []) (t := e1131212640054) (by decide)) (by decide)
def e1131212640058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131212640058 : Closed e1131212640058 ∧ code e1131212640058 = 5529259151162 := by decide
private def t_e1131212640058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1131212640058 : ¬ IsSelfInterpreter e1131212640058 :=
  wSource (t := t_e1131212640058) (replay_sound (ps := []) (t := e1131212640058) (by decide)) (by decide)
def e1192558156654 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1192558156654 : Closed e1192558156654 ∧ code e1192558156654 = 5590604667758 := by decide
def e1192558156662 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1192558156662 : Closed e1192558156662 ∧ code e1192558156662 = 5590604667766 := by decide
def e1192558156726 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1192558156726 : Closed e1192558156726 ∧ code e1192558156726 = 5590604667830 := by decide
def e1192558157166 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1192558157166 : Closed e1192558157166 ∧ code e1192558157166 = 5590604668270 := by decide
def e1192558157174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1192558157174 : Closed e1192558157174 ∧ code e1192558157174 = 5590604668278 := by decide
def e1192558157230 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1192558157230 : Closed e1192558157230 ∧ code e1192558157230 = 5590604668334 := by decide
def e1192558157242 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1192558157242 : Closed e1192558157242 ∧ code e1192558157242 = 5590604668346 := by decide
def e1192558157270 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1192558157270 : Closed e1192558157270 ∧ code e1192558157270 = 5590604668374 := by decide
def e1192558157274 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1192558157274 : Closed e1192558157274 ∧ code e1192558157274 = 5590604668378 := by decide
def e1192558157494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1192558157494 : Closed e1192558157494 ∧ code e1192558157494 = 5590604668598 := by decide
def e1192558157526 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1192558157526 : Closed e1192558157526 ∧ code e1192558157526 = 5590604668630 := by decide
def e1192558157530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1192558157530 : Closed e1192558157530 ∧ code e1192558157530 = 5590604668634 := by decide
def e1192558159726 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1192558159726 : Closed e1192558159726 ∧ code e1192558159726 = 5590604670830 := by decide
theorem cert_e1192558159726 : check e1192558159726 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558159734 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1192558159734 : Closed e1192558159734 ∧ code e1192558159734 = 5590604670838 := by decide
theorem cert_e1192558159734 : check e1192558159734 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558159798 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1192558159798 : Closed e1192558159798 ∧ code e1192558159798 = 5590604670902 := by decide
theorem cert_e1192558159798 : check e1192558159798 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558161134 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1192558161134 : Closed e1192558161134 ∧ code e1192558161134 = 5590604672238 := by decide
theorem cert_e1192558161134 : check e1192558161134 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558161142 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1192558161142 : Closed e1192558161142 ∧ code e1192558161142 = 5590604672246 := by decide
theorem cert_e1192558161142 : check e1192558161142 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558161526 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1192558161526 : Closed e1192558161526 ∧ code e1192558161526 = 5590604672630 := by decide
theorem cert_e1192558161526 : check e1192558161526 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1192558162798 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1192558162798 : Closed e1192558162798 ∧ code e1192558162798 = 5590604673902 := by decide
theorem cert_e1192558162798 : checkPay e1192558162798 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1192558162806 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1192558162806 : Closed e1192558162806 ∧ code e1192558162806 = 5590604673910 := by decide
theorem cert_e1192558162806 : check e1192558162806 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558162862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1192558162862 : Closed e1192558162862 ∧ code e1192558162862 = 5590604673966 := by decide
theorem cert_e1192558162862 : check e1192558162862 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left,.left]] .identityHead = true := by decide
def e1192558162874 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1192558162874 : Closed e1192558162874 ∧ code e1192558162874 = 5590604673978 := by decide
theorem cert_e1192558162874 : checkPay e1192558162874 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e1192558162902 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1192558162902 : Closed e1192558162902 ∧ code e1192558162902 = 5590604674006 := by decide
theorem cert_e1192558162902 : check e1192558162902 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558162906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1192558162906 : Closed e1192558162906 ∧ code e1192558162906 = 5590604674010 := by decide
theorem cert_e1192558162906 : checkPay e1192558162906 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1192558163182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1192558163182 : Closed e1192558163182 ∧ code e1192558163182 = 5590604674286 := by decide
theorem cert_e1192558163182 : check e1192558163182 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1192558163190 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1192558163190 : Closed e1192558163190 ∧ code e1192558163190 = 5590604674294 := by decide
theorem cert_e1192558163190 : check e1192558163190 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1192558163566 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1192558163566 : Closed e1192558163566 ∧ code e1192558163566 = 5590604674670 := by decide
def e1192558163578 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1192558163578 : Closed e1192558163578 ∧ code e1192558163578 = 5590604674682 := by decide
def e1192558163766 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1192558163766 : Closed e1192558163766 ∧ code e1192558163766 = 5590604674870 := by decide
theorem cert_e1192558163766 : check e1192558163766 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1192558163770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1192558163770 : Closed e1192558163770 ∧ code e1192558163770 = 5590604674874 := by decide
theorem cert_e1192558163770 : check e1192558163770 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558164406 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1192558164406 : Closed e1192558164406 ∧ code e1192558164406 = 5590604675510 := by decide
theorem cert_e1192558164406 : check e1192558164406 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1192558164438 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1192558164438 : Closed e1192558164438 ∧ code e1192558164438 = 5590604675542 := by decide
theorem cert_e1192558164438 : check e1192558164438 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1192558164442 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1192558164442 : Closed e1192558164442 ∧ code e1192558164442 = 5590604675546 := by decide
def e1192558164598 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1192558164598 : Closed e1192558164598 ∧ code e1192558164598 = 5590604675702 := by decide
theorem cert_e1192558164598 : checkPay e1192558164598 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1192558164790 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1192558164790 : Closed e1192558164790 ∧ code e1192558164790 = 5590604675894 := by decide
theorem cert_e1192558164790 : check e1192558164790 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558164794 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1192558164794 : Closed e1192558164794 ∧ code e1192558164794 = 5590604675898 := by decide
theorem cert_e1192558164794 : check e1192558164794 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558172014 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1192558172014 : Closed e1192558172014 ∧ code e1192558172014 = 5590604683118 := by decide
theorem cert_e1192558172014 : check e1192558172014 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1192558172022 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1192558172022 : Closed e1192558172022 ∧ code e1192558172022 = 5590604683126 := by decide
theorem cert_e1192558172022 : check e1192558172022 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1192558172086 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1192558172086 : Closed e1192558172086 ∧ code e1192558172086 = 5590604683190 := by decide
theorem cert_e1192558172086 : check e1192558172086 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1192558173422 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1192558173422 : Closed e1192558173422 ∧ code e1192558173422 = 5590604684526 := by decide
theorem cert_e1192558173422 : check e1192558173422 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1192558173430 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1192558173430 : Closed e1192558173430 ∧ code e1192558173430 = 5590604684534 := by decide
theorem cert_e1192558173430 : check e1192558173430 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1192558173814 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1192558173814 : Closed e1192558173814 ∧ code e1192558173814 = 5590604684918 := by decide
theorem cert_e1192558173814 : check e1192558173814 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1192558185326 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1192558185326 : Closed e1192558185326 ∧ code e1192558185326 = 5590604696430 := by decide
theorem cert_e1192558185326 : check e1192558185326 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185334 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1192558185334 : Closed e1192558185334 ∧ code e1192558185334 = 5590604696438 := by decide
theorem cert_e1192558185334 : check e1192558185334 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185390 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1192558185390 : Closed e1192558185390 ∧ code e1192558185390 = 5590604696494 := by decide
theorem cert_e1192558185390 : check e1192558185390 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1192558185402 : Closed e1192558185402 ∧ code e1192558185402 = 5590604696506 := by decide
theorem cert_e1192558185402 : check e1192558185402 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185430 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1192558185430 : Closed e1192558185430 ∧ code e1192558185430 = 5590604696534 := by decide
theorem cert_e1192558185430 : check e1192558185430 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185434 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1192558185434 : Closed e1192558185434 ∧ code e1192558185434 = 5590604696538 := by decide
theorem cert_e1192558185434 : check e1192558185434 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185710 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1192558185710 : Closed e1192558185710 ∧ code e1192558185710 = 5590604696814 := by decide
theorem cert_e1192558185710 : check e1192558185710 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558185718 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1192558185718 : Closed e1192558185718 ∧ code e1192558185718 = 5590604696822 := by decide
theorem cert_e1192558185718 : check e1192558185718 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558186094 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1192558186094 : Closed e1192558186094 ∧ code e1192558186094 = 5590604697198 := by decide
theorem cert_e1192558186094 : check e1192558186094 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558186106 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1192558186106 : Closed e1192558186106 ∧ code e1192558186106 = 5590604697210 := by decide
theorem cert_e1192558186106 : check e1192558186106 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558186294 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1192558186294 : Closed e1192558186294 ∧ code e1192558186294 = 5590604697398 := by decide
theorem cert_e1192558186294 : check e1192558186294 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558186298 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1192558186298 : Closed e1192558186298 ∧ code e1192558186298 = 5590604697402 := by decide
theorem cert_e1192558186298 : check e1192558186298 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1192558192054 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1192558192054 : Closed e1192558192054 ∧ code e1192558192054 = 5590604703158 := by decide
theorem cert_e1192558192054 : check e1192558192054 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1192558192086 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1192558192086 : Closed e1192558192086 ∧ code e1192558192086 = 5590604703190 := by decide
theorem cert_e1192558192086 : check e1192558192086 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1192558192090 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1192558192090 : Closed e1192558192090 ∧ code e1192558192090 = 5590604703194 := by decide
theorem cert_e1192558192090 : check e1192558192090 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1192558192246 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1192558192246 : Closed e1192558192246 ∧ code e1192558192246 = 5590604703350 := by decide
theorem cert_e1192558192246 : check e1192558192246 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558192438 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1192558192438 : Closed e1192558192438 ∧ code e1192558192438 = 5590604703542 := by decide
theorem cert_e1192558192438 : check e1192558192438 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558192442 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1192558192442 : Closed e1192558192442 ∧ code e1192558192442 = 5590604703546 := by decide
theorem cert_e1192558192442 : check e1192558192442 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1192558529390 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1192558529390 : Closed e1192558529390 ∧ code e1192558529390 = 5590605040494 := by decide
def e1192558529398 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1192558529398 : Closed e1192558529398 ∧ code e1192558529398 = 5590605040502 := by decide
private def t_e1192558529398 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1192558529398 : ¬ IsSelfInterpreter e1192558529398 :=
  wSource (t := t_e1192558529398) (replay_sound (ps := []) (t := e1192558529398) (by decide)) (by decide)
def e1192558529454 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1192558529454 : Closed e1192558529454 ∧ code e1192558529454 = 5590605040558 := by decide
def e1192558529466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1192558529466 : Closed e1192558529466 ∧ code e1192558529466 = 5590605040570 := by decide
def e1192558529494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1192558529494 : Closed e1192558529494 ∧ code e1192558529494 = 5590605040598 := by decide
private def t_e1192558529494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1192558529494 : ¬ IsSelfInterpreter e1192558529494 :=
  wSource (t := t_e1192558529494) (replay_sound (ps := []) (t := e1192558529494) (by decide)) (by decide)
def e1192558529498 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1192558529498 : Closed e1192558529498 ∧ code e1192558529498 = 5590605040602 := by decide
def e1192558529774 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1192558529774 : Closed e1192558529774 ∧ code e1192558529774 = 5590605040878 := by decide
def e1192558529782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1192558529782 : Closed e1192558529782 ∧ code e1192558529782 = 5590605040886 := by decide
def e1192558530158 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1192558530158 : Closed e1192558530158 ∧ code e1192558530158 = 5590605041262 := by decide
def e1192558530170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1192558530170 : Closed e1192558530170 ∧ code e1192558530170 = 5590605041274 := by decide
def e1192558530358 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1192558530358 : Closed e1192558530358 ∧ code e1192558530358 = 5590605041462 := by decide
def e1192558530362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1192558530362 : Closed e1192558530362 ∧ code e1192558530362 = 5590605041466 := by decide
def e1194006903322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194006903322 : Closed e1194006903322 ∧ code e1194006903322 = 5592053414426 := by decide
theorem cert_e1194006903322 : check e1194006903322 [[],[.left]] .chain = true := by decide
def e1194006927898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194006927898 : Closed e1194006927898 ∧ code e1194006927898 = 5592053439002 := by decide
theorem cert_e1194006927898 : check e1194006927898 [[],[.left]] .chain = true := by decide
def e1194007034394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007034394 : Closed e1194007034394 ∧ code e1194007034394 = 5592053545498 := by decide
theorem cert_e1194007034394 : check e1194007034394 [[],[.left]] .chain = true := by decide
def e1194007063066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007063066 : Closed e1194007063066 ∧ code e1194007063066 = 5592053574170 := by decide
theorem cert_e1194007063066 : check e1194007063066 [[],[.left]] .chain = true := by decide
def e1194007157274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007157274 : Closed e1194007157274 ∧ code e1194007157274 = 5592053668378 := by decide
theorem cert_e1194007157274 : check e1194007157274 [[],[.left]] .chain = true := by decide
def e1194007161370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007161370 : Closed e1194007161370 ∧ code e1194007161370 = 5592053672474 := by decide
theorem cert_e1194007161370 : check e1194007161370 [[],[.left]] .chain = true := by decide
def e1194007689754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007689754 : Closed e1194007689754 ∧ code e1194007689754 = 5592054200858 := by decide
theorem cert_e1194007689754 : check e1194007689754 [[],[.left]] .chain = true := by decide
def e1194007714330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194007714330 : Closed e1194007714330 ∧ code e1194007714330 = 5592054225434 := by decide
theorem cert_e1194007714330 : check e1194007714330 [[],[.left]] .chain = true := by decide
def e1194008476186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194008476186 : Closed e1194008476186 ∧ code e1194008476186 = 5592054987290 := by decide
theorem cert_e1194008476186 : check e1194008476186 [[],[.left]] .chain = true := by decide
def e1194008504858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194008504858 : Closed e1194008504858 ∧ code e1194008504858 = 5592055015962 := by decide
theorem cert_e1194008504858 : check e1194008504858 [[],[.left]] .chain = true := by decide
def e1194009090586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194009090586 : Closed e1194009090586 ∧ code e1194009090586 = 5592055601690 := by decide
theorem cert_e1194009090586 : check e1194009090586 [[],[.left]] .chain = true := by decide
def e1194009094682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194009094682 : Closed e1194009094682 ∧ code e1194009094682 = 5592055605786 := by decide
theorem cert_e1194009094682 : check e1194009094682 [[],[.left]] .chain = true := by decide
def e1194024221210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194024221210 : Closed e1194024221210 ∧ code e1194024221210 = 5592070732314 := by decide
theorem cert_e1194024221210 : check e1194024221210 [[],[.left]] .chain = true := by decide
def e1194024229402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194024229402 : Closed e1194024229402 ∧ code e1194024229402 = 5592070740506 := by decide
theorem cert_e1194024229402 : check e1194024229402 [[],[.left]] .chain = true := by decide
def e1194024794650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194024794650 : Closed e1194024794650 ∧ code e1194024794650 = 5592071305754 := by decide
theorem cert_e1194024794650 : check e1194024794650 [[],[.left]] .chain = true := by decide
def e1194024882374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194024882374 : Closed e1194024882374 ∧ code e1194024882374 = 5592071393478 := by decide
theorem cert_e1194024882374 : check e1194024882374 [[],[.left]] .chain = true := by decide
def e1194024888346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194024888346 : Closed e1194024888346 ∧ code e1194024888346 = 5592071399450 := by decide
theorem cert_e1194024888346 : check e1194024888346 [[]] .width = true := by decide
def e1194024909338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194024909338 : Closed e1194024909338 ∧ code e1194024909338 = 5592071420442 := by decide
theorem cert_e1194024909338 : check e1194024909338 [[],[.left]] .chain = true := by decide
def e1194024947910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194024947910 : Closed e1194024947910 ∧ code e1194024947910 = 5592071459014 := by decide
theorem cert_e1194024947910 : check e1194024947910 [[],[.left]] .chain = true := by decide
def e1194024986650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194024986650 : Closed e1194024986650 ∧ code e1194024986650 = 5592071497754 := by decide
theorem cert_e1194024986650 : check e1194024986650 [[]] .width = true := by decide
def e1194025138714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025138714 : Closed e1194025138714 ∧ code e1194025138714 = 5592071649818 := by decide
theorem cert_e1194025138714 : check e1194025138714 [[],[.left]] .chain = true := by decide
def e1194025151002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025151002 : Closed e1194025151002 ∧ code e1194025151002 = 5592071662106 := by decide
theorem cert_e1194025151002 : check e1194025151002 [[],[.left]] .chain = true := by decide
def e1194025318938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025318938 : Closed e1194025318938 ∧ code e1194025318938 = 5592071830042 := by decide
theorem cert_e1194025318938 : check e1194025318938 [[],[.left]] .chain = true := by decide
def e1194025406662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194025406662 : Closed e1194025406662 ∧ code e1194025406662 = 5592071917766 := by decide
theorem cert_e1194025406662 : check e1194025406662 [[],[.left]] .chain = true := by decide
def e1194025412634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194025412634 : Closed e1194025412634 ∧ code e1194025412634 = 5592071923738 := by decide
theorem cert_e1194025412634 : check e1194025412634 [[]] .width = true := by decide
def e1194025490970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025490970 : Closed e1194025490970 ∧ code e1194025490970 = 5592072002074 := by decide
theorem cert_e1194025490970 : check e1194025490970 [[],[.left]] .chain = true := by decide
def e1194025504966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194025504966 : Closed e1194025504966 ∧ code e1194025504966 = 5592072016070 := by decide
theorem cert_e1194025504966 : check e1194025504966 [[],[.left]] .chain = true := by decide
def e1194025515546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025515546 : Closed e1194025515546 ∧ code e1194025515546 = 5592072026650 := by decide
theorem cert_e1194025515546 : check e1194025515546 [[]] .width = true := by decide
def e1194025527322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194025527322 : Closed e1194025527322 ∧ code e1194025527322 = 5592072038426 := by decide
theorem cert_e1194025527322 : check e1194025527322 [[]] .width = true := by decide
def e1194025531930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025531930 : Closed e1194025531930 ∧ code e1194025531930 = 5592072043034 := by decide
theorem cert_e1194025531930 : check e1194025531930 [[]] .width = true := by decide
def e1194025605658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025605658 : Closed e1194025605658 ∧ code e1194025605658 = 5592072116762 := by decide
theorem cert_e1194025605658 : check e1194025605658 [[],[.left]] .chain = true := by decide
def e1194025609754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025609754 : Closed e1194025609754 ∧ code e1194025609754 = 5592072120858 := by decide
theorem cert_e1194025609754 : check e1194025609754 [[],[.left]] .chain = true := by decide
def e1194025695770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025695770 : Closed e1194025695770 ∧ code e1194025695770 = 5592072206874 := by decide
theorem cert_e1194025695770 : check e1194025695770 [[],[.left]] .chain = true := by decide
def e1194025734342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194025734342 : Closed e1194025734342 ∧ code e1194025734342 = 5592072245446 := by decide
theorem cert_e1194025734342 : check e1194025734342 [[],[.left]] .chain = true := by decide
def e1194025753114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025753114 : Closed e1194025753114 ∧ code e1194025753114 = 5592072264218 := by decide
theorem cert_e1194025753114 : check e1194025753114 [[],[.left]] .chain = true := by decide
def e1194025767110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194025767110 : Closed e1194025767110 ∧ code e1194025767110 = 5592072278214 := by decide
theorem cert_e1194025767110 : check e1194025767110 [[],[.left]] .chain = true := by decide
def e1194025777690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025777690 : Closed e1194025777690 ∧ code e1194025777690 = 5592072288794 := by decide
theorem cert_e1194025777690 : check e1194025777690 [[]] .width = true := by decide
def e1194025802266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025802266 : Closed e1194025802266 ∧ code e1194025802266 = 5592072313370 := by decide
private def t_e1194025802266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194025802266 : ¬ IsSelfInterpreter e1194025802266 :=
  wSource (t := t_e1194025802266) (replay_sound (ps := []) (t := e1194025802266) (by decide)) (by decide)
def e1194025904154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194025904154 : Closed e1194025904154 ∧ code e1194025904154 = 5592072415258 := by decide
theorem cert_e1194025904154 : check e1194025904154 [[]] .width = true := by decide
def e1194025920538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194025920538 : Closed e1194025920538 ∧ code e1194025920538 = 5592072431642 := by decide
theorem cert_e1194025920538 : check e1194025920538 [[]] .width = true := by decide
def e1194025925146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025925146 : Closed e1194025925146 ∧ code e1194025925146 = 5592072436250 := by decide
theorem cert_e1194025925146 : check e1194025925146 [[]] .width = true := by decide
def e1194025933338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194025933338 : Closed e1194025933338 ∧ code e1194025933338 = 5592072444442 := by decide
private def t_e1194025933338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194025933338 : ¬ IsSelfInterpreter e1194025933338 :=
  wSource (t := t_e1194025933338) (replay_sound (ps := []) (t := e1194025933338) (by decide)) (by decide)
end Blc.Floor42
