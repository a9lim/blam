import Batch117
import ExtraBase
namespace Blc.Floor42.Extra117
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1205858217706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem ex_e1205858217706 : ¬ IsSelfInterpreter e1205858217706 := by
  intro he
  have hp := replay_sound (t := e1205858217706) (u := t_e1205858217706) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))) (SO.var 0))))
#print axioms ex_e1205858217706
private def t_e1205858217834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem ex_e1205858217834 : ¬ IsSelfInterpreter e1205858217834 := by
  intro he
  have hp := replay_sound (t := e1205858217834) (u := t_e1205858217834) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))) (SO.var 0))))
#print axioms ex_e1205858217834
private def t_e1205858218938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem ex_e1205858218938 : ¬ IsSelfInterpreter e1205858218938 := by
  intro he
  have hp := replay_sound (t := e1205858218938) (u := t_e1205858218938) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))) (SO.var 0))))
#print axioms ex_e1205858218938
private def t_e1205858218970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem ex_e1205858218970 : ¬ IsSelfInterpreter e1205858218970 := by
  intro he
  have hp := replay_sound (t := e1205858218970) (u := t_e1205858218970) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))) (SO.var 0))))
#print axioms ex_e1205858218970
private def t_e1205858470874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1205858470874 : ¬ IsSelfInterpreter e1205858470874 := by
  intro he
  have hp := replay_sound (t := e1205858470874) (u := t_e1205858470874) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.var 0))) (SO.lam (g := (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1205858470874
end Blc.Floor42.Extra117
