import Batch250
import ExtraBase
namespace Blc.Floor42.Extra250
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211298978414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem ex_e1211298978414 : ¬ IsSelfInterpreter e1211298978414 := by
  intro he
  have hp := replay_sound (t := (.app e1211298978414 churchTrue)) (u := t_e1211298978414) (ps := [[.left],[.left],[],[.right,.under,.left],[.right,.under],[]]) (by decide)
  apply specialized_not_so he hp
  exact (so_closed_lam (by decide) (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (SO.lam (g := (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211298978414
private def t_e1211298978426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.var 0))))))
theorem ex_e1211298978426 : ¬ IsSelfInterpreter e1211298978426 := by
  intro he
  have hp := replay_sound (t := (.app e1211298978426 churchTrue)) (u := t_e1211298978426) (ps := [[.left],[.left],[],[.right,.under,.left],[.right,.under],[]]) (by decide)
  apply specialized_not_so he hp
  exact (so_closed_lam (by decide) (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (SO.lam (g := (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.var 0)))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211298978426
private def t_e1211299052954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem ex_e1211299052954 : ¬ IsSelfInterpreter e1211299052954 := by
  intro he
  have hp := replay_sound (t := e1211299052954) (u := t_e1211299052954) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.app (SO.var 0) (SO.var 0)))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299052954
end Blc.Floor42.Extra250
