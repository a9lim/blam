import Tables
import Batch177
namespace Blc.Floor42.Grades177
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211203249114 : ¬ IsSelfInterpreter e1211203249114 := cutM5_2 (by decide)
#print axioms ex_e1211203249114
theorem ex_e1211203251854 : ¬ IsSelfInterpreter e1211203251854 := cutM5_2 (by decide)
#print axioms ex_e1211203251854
end Blc.Floor42.Grades177
