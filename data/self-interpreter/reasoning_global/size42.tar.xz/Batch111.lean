import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815276250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205815276250 : Closed e1205815276250 ∧ code e1205815276250 = 5603861787354 := by decide
theorem cert_e1205815276250 : check e1205815276250 [[],[]] .smaller = true := by decide
def e1205815276266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205815276266 : Closed e1205815276266 ∧ code e1205815276266 = 5603861787370 := by decide
theorem cert_e1205815276266 : check e1205815276266 [[],[]] .smaller = true := by decide
def e1205815276342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205815276342 : Closed e1205815276342 ∧ code e1205815276342 = 5603861787446 := by decide
theorem cert_e1205815276342 : check e1205815276342 [[],[]] .smaller = true := by decide
def e1205815276346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205815276346 : Closed e1205815276346 ∧ code e1205815276346 = 5603861787450 := by decide
theorem cert_e1205815276346 : check e1205815276346 [[],[]] .smaller = true := by decide
def e1205815276442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815276442 : Closed e1205815276442 ∧ code e1205815276442 = 5603861787546 := by decide
theorem cert_e1205815276442 : check e1205815276442 [[],[]] .smaller = true := by decide
def e1205815276510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205815276510 : Closed e1205815276510 ∧ code e1205815276510 = 5603861787614 := by decide
theorem cert_e1205815276510 : check e1205815276510 [[],[]] .chain = true := by decide
def e1205815276526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205815276526 : Closed e1205815276526 ∧ code e1205815276526 = 5603861787630 := by decide
theorem cert_e1205815276526 : check e1205815276526 [[],[]] .chain = true := by decide
def e1205815277966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205815277966 : Closed e1205815277966 ∧ code e1205815277966 = 5603861789070 := by decide
theorem cert_e1205815277966 : check e1205815277966 [[],[]] .chain = true := by decide
def e1205815278022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205815278022 : Closed e1205815278022 ∧ code e1205815278022 = 5603861789126 := by decide
theorem cert_e1205815278022 : check e1205815278022 [[],[]] .chain = true := by decide
def e1205815278062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205815278062 : Closed e1205815278062 ∧ code e1205815278062 = 5603861789166 := by decide
theorem cert_e1205815278062 : check e1205815278062 [[],[]] .chain = true := by decide
def e1205815358702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815358702 : Closed e1205815358702 ∧ code e1205815358702 = 5603861869806 := by decide
theorem cert_e1205815358702 : check e1205815358702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1205815358710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815358710 : Closed e1205815358710 ∧ code e1205815358710 = 5603861869814 := by decide
theorem cert_e1205815358710 : check e1205815358710 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815390574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1205815390574 : Closed e1205815390574 ∧ code e1205815390574 = 5603861901678 := by decide
theorem cert_e1205815390574 : check e1205815390574 [[],[]] .chain = true := by decide
def e1205815390582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1205815390582 : Closed e1205815390582 ∧ code e1205815390582 = 5603861901686 := by decide
theorem cert_e1205815390582 : check e1205815390582 [[],[]] .chain = true := by decide
def e1205815391790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815391790 : Closed e1205815391790 ∧ code e1205815391790 = 5603861902894 := by decide
theorem cert_e1205815391790 : check e1205815391790 [[],[]] .chain = true := by decide
def e1205815391970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815391970 : Closed e1205815391970 ∧ code e1205815391970 = 5603861903074 := by decide
theorem cert_e1205815391970 : check e1205815391970 [[],[]] .chain = true := by decide
def e1205815391982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e1205815391982 : Closed e1205815391982 ∧ code e1205815391982 = 5603861903086 := by decide
theorem cert_e1205815391982 : check e1205815391982 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815392022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205815392022 : Closed e1205815392022 ∧ code e1205815392022 = 5603861903126 := by decide
theorem cert_e1205815392022 : check e1205815392022 [[],[]] .chain = true := by decide
def e1205815392098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205815392098 : Closed e1205815392098 ∧ code e1205815392098 = 5603861903202 := by decide
theorem cert_e1205815392098 : check e1205815392098 [[],[]] .chain = true := by decide
def e1205815392110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e1205815392110 : Closed e1205815392110 ∧ code e1205815392110 = 5603861903214 := by decide
theorem cert_e1205815392110 : check e1205815392110 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815392118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e1205815392118 : Closed e1205815392118 ∧ code e1205815392118 = 5603861903222 := by decide
theorem cert_e1205815392118 : check e1205815392118 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1205815392430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205815392430 : Closed e1205815392430 ∧ code e1205815392430 = 5603861903534 := by decide
theorem cert_e1205815392430 : check e1205815392430 [[],[]] .chain = true := by decide
def e1205815392442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205815392442 : Closed e1205815392442 ∧ code e1205815392442 = 5603861903546 := by decide
theorem cert_e1205815392442 : check e1205815392442 [[],[]] .chain = true := by decide
def e1205815392814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815392814 : Closed e1205815392814 ∧ code e1205815392814 = 5603861903918 := by decide
theorem cert_e1205815392814 : check e1205815392814 [[],[]] .chain = true := by decide
def e1205815392994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815392994 : Closed e1205815392994 ∧ code e1205815392994 = 5603861904098 := by decide
theorem cert_e1205815392994 : check e1205815392994 [[],[]] .chain = true := by decide
def e1205815393006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1205815393006 : Closed e1205815393006 ∧ code e1205815393006 = 5603861904110 := by decide
theorem cert_e1205815393006 : check e1205815393006 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815393134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1205815393134 : Closed e1205815393134 ∧ code e1205815393134 = 5603861904238 := by decide
theorem cert_e1205815393134 : check e1205815393134 [[],[]] .chain = true := by decide
def e1205815393142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1205815393142 : Closed e1205815393142 ∧ code e1205815393142 = 5603861904246 := by decide
theorem cert_e1205815393142 : check e1205815393142 [[],[]] .chain = true := by decide
def e1205815393162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815393162 : Closed e1205815393162 ∧ code e1205815393162 = 5603861904266 := by decide
theorem cert_e1205815393162 : check e1205815393162 [[],[]] .chain = true := by decide
def e1205815393186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815393186 : Closed e1205815393186 ∧ code e1205815393186 = 5603861904290 := by decide
theorem cert_e1205815393186 : check e1205815393186 [[],[]] .chain = true := by decide
def e1205815393198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1205815393198 : Closed e1205815393198 ∧ code e1205815393198 = 5603861904302 := by decide
theorem cert_e1205815393198 : check e1205815393198 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815393206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1205815393206 : Closed e1205815393206 ∧ code e1205815393206 = 5603861904310 := by decide
theorem cert_e1205815393206 : check e1205815393206 [[],[]] .chain = true := by decide
def e1205815393210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1205815393210 : Closed e1205815393210 ∧ code e1205815393210 = 5603861904314 := by decide
theorem cert_e1205815393210 : check e1205815393210 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815393366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205815393366 : Closed e1205815393366 ∧ code e1205815393366 = 5603861904470 := by decide
theorem cert_e1205815393366 : check e1205815393366 [[],[]] .chain = true := by decide
def e1205815393370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205815393370 : Closed e1205815393370 ∧ code e1205815393370 = 5603861904474 := by decide
theorem cert_e1205815393370 : check e1205815393370 [[],[]] .chain = true := by decide
def e1205815393558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205815393558 : Closed e1205815393558 ∧ code e1205815393558 = 5603861904662 := by decide
theorem cert_e1205815393558 : check e1205815393558 [[],[]] .chain = true := by decide
def e1205815393634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205815393634 : Closed e1205815393634 ∧ code e1205815393634 = 5603861904738 := by decide
theorem cert_e1205815393634 : check e1205815393634 [[],[]] .chain = true := by decide
def e1205815393646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205815393646 : Closed e1205815393646 ∧ code e1205815393646 = 5603861904750 := by decide
theorem cert_e1205815393646 : check e1205815393646 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1205815393654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205815393654 : Closed e1205815393654 ∧ code e1205815393654 = 5603861904758 := by decide
theorem cert_e1205815393654 : check e1205815393654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815393674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815393674 : Closed e1205815393674 ∧ code e1205815393674 = 5603861904778 := by decide
theorem cert_e1205815393674 : check e1205815393674 [[],[]] .chain = true := by decide
def e1205815393698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815393698 : Closed e1205815393698 ∧ code e1205815393698 = 5603861904802 := by decide
theorem cert_e1205815393698 : check e1205815393698 [[],[]] .chain = true := by decide
def e1205815393710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205815393710 : Closed e1205815393710 ∧ code e1205815393710 = 5603861904814 := by decide
theorem cert_e1205815393710 : check e1205815393710 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815393718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e1205815393718 : Closed e1205815393718 ∧ code e1205815393718 = 5603861904822 := by decide
theorem cert_e1205815393718 : check e1205815393718 [[],[]] .chain = true := by decide
def e1205815393722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205815393722 : Closed e1205815393722 ∧ code e1205815393722 = 5603861904826 := by decide
theorem cert_e1205815393722 : check e1205815393722 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815393750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205815393750 : Closed e1205815393750 ∧ code e1205815393750 = 5603861904854 := by decide
theorem cert_e1205815393750 : checkPay e1205815393750 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815393754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205815393754 : Closed e1205815393754 ∧ code e1205815393754 = 5603861904858 := by decide
theorem cert_e1205815393754 : check e1205815393754 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1205815394798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1205815394798 : Closed e1205815394798 ∧ code e1205815394798 = 5603861905902 := by decide
theorem cert_e1205815394798 : check e1205815394798 [[],[]] .chain = true := by decide
def e1205815394806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1205815394806 : Closed e1205815394806 ∧ code e1205815394806 = 5603861905910 := by decide
theorem cert_e1205815394806 : check e1205815394806 [[],[]] .chain = true := by decide
def e1205815395566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815395566 : Closed e1205815395566 ∧ code e1205815395566 = 5603861906670 := by decide
theorem cert_e1205815395566 : check e1205815395566 [[],[]] .chain = true := by decide
def e1205815395574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815395574 : Closed e1205815395574 ∧ code e1205815395574 = 5603861906678 := by decide
theorem cert_e1205815395574 : check e1205815395574 [[],[]] .chain = true := by decide
def e1205815396126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e1205815396126 : Closed e1205815396126 ∧ code e1205815396126 = 5603861907230 := by decide
theorem cert_e1205815396126 : check e1205815396126 [[],[]] .chain = true := by decide
def e1205815396238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e1205815396238 : Closed e1205815396238 ∧ code e1205815396238 = 5603861907342 := by decide
theorem cert_e1205815396238 : check e1205815396238 [[],[]] .chain = true := by decide
def e1205815397934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205815397934 : Closed e1205815397934 ∧ code e1205815397934 = 5603861909038 := by decide
theorem cert_e1205815397934 : check e1205815397934 [[],[]] .chain = true := by decide
def e1205815398114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205815398114 : Closed e1205815398114 ∧ code e1205815398114 = 5603861909218 := by decide
theorem cert_e1205815398114 : check e1205815398114 [[],[]] .chain = true := by decide
def e1205815398126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e1205815398126 : Closed e1205815398126 ∧ code e1205815398126 = 5603861909230 := by decide
theorem cert_e1205815398126 : check e1205815398126 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205815398166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205815398166 : Closed e1205815398166 ∧ code e1205815398166 = 5603861909270 := by decide
theorem cert_e1205815398166 : check e1205815398166 [[],[]] .chain = true := by decide
def e1205815398242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205815398242 : Closed e1205815398242 ∧ code e1205815398242 = 5603861909346 := by decide
theorem cert_e1205815398242 : check e1205815398242 [[],[]] .chain = true := by decide
def e1205815398254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e1205815398254 : Closed e1205815398254 ∧ code e1205815398254 = 5603861909358 := by decide
theorem cert_e1205815398254 : check e1205815398254 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815398262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e1205815398262 : Closed e1205815398262 ∧ code e1205815398262 = 5603861909366 := by decide
theorem cert_e1205815398262 : check e1205815398262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1205815400510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815400510 : Closed e1205815400510 ∧ code e1205815400510 = 5603861911614 := by decide
theorem cert_e1205815400510 : check e1205815400510 [[],[]] .chain = true := by decide
def e1205815400930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815400930 : Closed e1205815400930 ∧ code e1205815400930 = 5603861912034 := by decide
theorem cert_e1205815400930 : check e1205815400930 [[],[]] .chain = true := by decide
def e1205815400942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815400942 : Closed e1205815400942 ∧ code e1205815400942 = 5603861912046 := by decide
theorem cert_e1205815400942 : check e1205815400942 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205815401502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205815401502 : Closed e1205815401502 ∧ code e1205815401502 = 5603861912606 := by decide
theorem cert_e1205815401502 : check e1205815401502 [[],[]] .chain = true := by decide
def e1205815401698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205815401698 : Closed e1205815401698 ∧ code e1205815401698 = 5603861912802 := by decide
theorem cert_e1205815401698 : check e1205815401698 [[],[]] .chain = true := by decide
def e1205815401710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815401710 : Closed e1205815401710 ∧ code e1205815401710 = 5603861912814 := by decide
theorem cert_e1205815401710 : check e1205815401710 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815401718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815401718 : Closed e1205815401718 ∧ code e1205815401718 = 5603861912822 := by decide
theorem cert_e1205815401718 : check e1205815401718 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815402734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205815402734 : Closed e1205815402734 ∧ code e1205815402734 = 5603861913838 := by decide
theorem cert_e1205815402734 : check e1205815402734 [[],[]] .chain = true := by decide
def e1205815402746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205815402746 : Closed e1205815402746 ∧ code e1205815402746 = 5603861913850 := by decide
theorem cert_e1205815402746 : check e1205815402746 [[],[]] .chain = true := by decide
def e1205815402926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1205815402926 : Closed e1205815402926 ∧ code e1205815402926 = 5603861914030 := by decide
theorem cert_e1205815402926 : check e1205815402926 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815403118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815403118 : Closed e1205815403118 ∧ code e1205815403118 = 5603861914222 := by decide
theorem cert_e1205815403118 : check e1205815403118 [[],[]] .chain = true := by decide
def e1205815403130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815403130 : Closed e1205815403130 ∧ code e1205815403130 = 5603861914234 := by decide
theorem cert_e1205815403130 : check e1205815403130 [[],[]] .chain = true := by decide
def e1205815403294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205815403294 : Closed e1205815403294 ∧ code e1205815403294 = 5603861914398 := by decide
theorem cert_e1205815403294 : check e1205815403294 [[],[]] .chain = true := by decide
def e1205815403462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205815403462 : Closed e1205815403462 ∧ code e1205815403462 = 5603861914566 := by decide
theorem cert_e1205815403462 : check e1205815403462 [[],[]] .chain = true := by decide
def e1205815404078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205815404078 : Closed e1205815404078 ∧ code e1205815404078 = 5603861915182 := by decide
theorem cert_e1205815404078 : check e1205815404078 [[],[]] .chain = true := by decide
def e1205815404258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205815404258 : Closed e1205815404258 ∧ code e1205815404258 = 5603861915362 := by decide
theorem cert_e1205815404258 : check e1205815404258 [[],[]] .chain = true := by decide
def e1205815404270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1205815404270 : Closed e1205815404270 ∧ code e1205815404270 = 5603861915374 := by decide
theorem cert_e1205815404270 : check e1205815404270 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815404398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1205815404398 : Closed e1205815404398 ∧ code e1205815404398 = 5603861915502 := by decide
theorem cert_e1205815404398 : check e1205815404398 [[],[]] .chain = true := by decide
def e1205815404406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1205815404406 : Closed e1205815404406 ∧ code e1205815404406 = 5603861915510 := by decide
theorem cert_e1205815404406 : check e1205815404406 [[],[]] .chain = true := by decide
def e1205815404426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205815404426 : Closed e1205815404426 ∧ code e1205815404426 = 5603861915530 := by decide
theorem cert_e1205815404426 : check e1205815404426 [[],[]] .chain = true := by decide
def e1205815404450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205815404450 : Closed e1205815404450 ∧ code e1205815404450 = 5603861915554 := by decide
theorem cert_e1205815404450 : check e1205815404450 [[],[]] .chain = true := by decide
def e1205815404462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1205815404462 : Closed e1205815404462 ∧ code e1205815404462 = 5603861915566 := by decide
theorem cert_e1205815404462 : check e1205815404462 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815404470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1205815404470 : Closed e1205815404470 ∧ code e1205815404470 = 5603861915574 := by decide
theorem cert_e1205815404470 : check e1205815404470 [[],[]] .chain = true := by decide
def e1205815404474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1205815404474 : Closed e1205815404474 ∧ code e1205815404474 = 5603861915578 := by decide
theorem cert_e1205815404474 : check e1205815404474 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815404606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815404606 : Closed e1205815404606 ∧ code e1205815404606 = 5603861915710 := by decide
theorem cert_e1205815404606 : check e1205815404606 [[],[]] .chain = true := by decide
def e1205815405026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815405026 : Closed e1205815405026 ∧ code e1205815405026 = 5603861916130 := by decide
theorem cert_e1205815405026 : check e1205815405026 [[],[]] .chain = true := by decide
def e1205815405038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815405038 : Closed e1205815405038 ∧ code e1205815405038 = 5603861916142 := by decide
theorem cert_e1205815405038 : check e1205815405038 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815405806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815405806 : Closed e1205815405806 ∧ code e1205815405806 = 5603861916910 := by decide
theorem cert_e1205815405806 : check e1205815405806 [[],[]] .chain = true := by decide
def e1205815405814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815405814 : Closed e1205815405814 ∧ code e1205815405814 = 5603861916918 := by decide
theorem cert_e1205815405814 : check e1205815405814 [[],[]] .chain = true := by decide
def e1205815406094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815406094 : Closed e1205815406094 ∧ code e1205815406094 = 5603861917198 := by decide
theorem cert_e1205815406094 : check e1205815406094 [[],[]] .chain = true := by decide
def e1205815406106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815406106 : Closed e1205815406106 ∧ code e1205815406106 = 5603861917210 := by decide
theorem cert_e1205815406106 : check e1205815406106 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815406178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815406178 : Closed e1205815406178 ∧ code e1205815406178 = 5603861917282 := by decide
theorem cert_e1205815406178 : check e1205815406178 [[],[]] .chain = true := by decide
def e1205815406190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815406190 : Closed e1205815406190 ∧ code e1205815406190 = 5603861917294 := by decide
theorem cert_e1205815406190 : check e1205815406190 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815406198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815406198 : Closed e1205815406198 ∧ code e1205815406198 = 5603861917302 := by decide
theorem cert_e1205815406198 : check e1205815406198 [[],[]] .chain = true := by decide
def e1205815406202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815406202 : Closed e1205815406202 ∧ code e1205815406202 = 5603861917306 := by decide
theorem cert_e1205815406202 : check e1205815406202 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815406710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205815406710 : Closed e1205815406710 ∧ code e1205815406710 = 5603861917814 := by decide
theorem cert_e1205815406710 : check e1205815406710 [[],[]] .chain = true := by decide
def e1205815406714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1205815406714 : Closed e1205815406714 ∧ code e1205815406714 = 5603861917818 := by decide
theorem cert_e1205815406714 : check e1205815406714 [[],[]] .chain = true := by decide
def e1205815406806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1205815406806 : Closed e1205815406806 ∧ code e1205815406806 = 5603861917910 := by decide
theorem cert_e1205815406806 : check e1205815406806 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815406902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815406902 : Closed e1205815406902 ∧ code e1205815406902 = 5603861918006 := by decide
theorem cert_e1205815406902 : check e1205815406902 [[],[]] .chain = true := by decide
def e1205815406906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815406906 : Closed e1205815406906 ∧ code e1205815406906 = 5603861918010 := by decide
theorem cert_e1205815406906 : check e1205815406906 [[],[]] .chain = true := by decide
def e1205815406990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205815406990 : Closed e1205815406990 ∧ code e1205815406990 = 5603861918094 := by decide
theorem cert_e1205815406990 : check e1205815406990 [[],[]] .chain = true := by decide
def e1205815407046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1205815407046 : Closed e1205815407046 ∧ code e1205815407046 = 5603861918150 := by decide
theorem cert_e1205815407046 : check e1205815407046 [[],[]] .chain = true := by decide
def e1205815407382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205815407382 : Closed e1205815407382 ∧ code e1205815407382 = 5603861918486 := by decide
theorem cert_e1205815407382 : check e1205815407382 [[],[]] .chain = true := by decide
def e1205815407458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205815407458 : Closed e1205815407458 ∧ code e1205815407458 = 5603861918562 := by decide
theorem cert_e1205815407458 : check e1205815407458 [[],[]] .chain = true := by decide
def e1205815407470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205815407470 : Closed e1205815407470 ∧ code e1205815407470 = 5603861918574 := by decide
theorem cert_e1205815407470 : check e1205815407470 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815407478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205815407478 : Closed e1205815407478 ∧ code e1205815407478 = 5603861918582 := by decide
theorem cert_e1205815407478 : check e1205815407478 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815407498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205815407498 : Closed e1205815407498 ∧ code e1205815407498 = 5603861918602 := by decide
theorem cert_e1205815407498 : check e1205815407498 [[],[]] .chain = true := by decide
def e1205815407522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205815407522 : Closed e1205815407522 ∧ code e1205815407522 = 5603861918626 := by decide
theorem cert_e1205815407522 : check e1205815407522 [[],[]] .chain = true := by decide
def e1205815407534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205815407534 : Closed e1205815407534 ∧ code e1205815407534 = 5603861918638 := by decide
theorem cert_e1205815407534 : check e1205815407534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815407542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e1205815407542 : Closed e1205815407542 ∧ code e1205815407542 = 5603861918646 := by decide
theorem cert_e1205815407542 : check e1205815407542 [[],[]] .chain = true := by decide
def e1205815407546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205815407546 : Closed e1205815407546 ∧ code e1205815407546 = 5603861918650 := by decide
theorem cert_e1205815407546 : check e1205815407546 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815407574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205815407574 : Closed e1205815407574 ∧ code e1205815407574 = 5603861918678 := by decide
theorem cert_e1205815407574 : check e1205815407574 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815407578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205815407578 : Closed e1205815407578 ∧ code e1205815407578 = 5603861918682 := by decide
theorem cert_e1205815407578 : check e1205815407578 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815407646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205815407646 : Closed e1205815407646 ∧ code e1205815407646 = 5603861918750 := by decide
theorem cert_e1205815407646 : check e1205815407646 [[],[]] .chain = true := by decide
def e1205815407842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205815407842 : Closed e1205815407842 ∧ code e1205815407842 = 5603861918946 := by decide
theorem cert_e1205815407842 : check e1205815407842 [[],[]] .chain = true := by decide
def e1205815407854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815407854 : Closed e1205815407854 ∧ code e1205815407854 = 5603861918958 := by decide
theorem cert_e1205815407854 : check e1205815407854 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815407862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815407862 : Closed e1205815407862 ∧ code e1205815407862 = 5603861918966 := by decide
theorem cert_e1205815407862 : check e1205815407862 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1205815408142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815408142 : Closed e1205815408142 ∧ code e1205815408142 = 5603861919246 := by decide
theorem cert_e1205815408142 : check e1205815408142 [[],[]] .chain = true := by decide
def e1205815408154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815408154 : Closed e1205815408154 ∧ code e1205815408154 = 5603861919258 := by decide
theorem cert_e1205815408154 : check e1205815408154 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815408226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815408226 : Closed e1205815408226 ∧ code e1205815408226 = 5603861919330 := by decide
theorem cert_e1205815408226 : check e1205815408226 [[],[]] .chain = true := by decide
def e1205815408238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815408238 : Closed e1205815408238 ∧ code e1205815408238 = 5603861919342 := by decide
theorem cert_e1205815408238 : check e1205815408238 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815408246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815408246 : Closed e1205815408246 ∧ code e1205815408246 = 5603861919350 := by decide
theorem cert_e1205815408246 : check e1205815408246 [[],[]] .chain = true := by decide
def e1205815408250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815408250 : Closed e1205815408250 ∧ code e1205815408250 = 5603861919354 := by decide
theorem cert_e1205815408250 : check e1205815408250 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815408438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815408438 : Closed e1205815408438 ∧ code e1205815408438 = 5603861919542 := by decide
theorem cert_e1205815408438 : check e1205815408438 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815408442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815408442 : Closed e1205815408442 ∧ code e1205815408442 = 5603861919546 := by decide
theorem cert_e1205815408442 : check e1205815408442 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815413614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205815413614 : Closed e1205815413614 ∧ code e1205815413614 = 5603861924718 := by decide
theorem cert_e1205815413614 : check e1205815413614 [[],[]] .smaller = true := by decide
def e1205815413622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205815413622 : Closed e1205815413622 ∧ code e1205815413622 = 5603861924726 := by decide
theorem cert_e1205815413622 : check e1205815413622 [[],[]] .smaller = true := by decide
def e1205815413678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205815413678 : Closed e1205815413678 ∧ code e1205815413678 = 5603861924782 := by decide
theorem cert_e1205815413678 : check e1205815413678 [[],[]] .smaller = true := by decide
def e1205815413690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205815413690 : Closed e1205815413690 ∧ code e1205815413690 = 5603861924794 := by decide
theorem cert_e1205815413690 : check e1205815413690 [[],[]] .smaller = true := by decide
def e1205815413718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205815413718 : Closed e1205815413718 ∧ code e1205815413718 = 5603861924822 := by decide
theorem cert_e1205815413718 : check e1205815413718 [[],[]] .smaller = true := by decide
def e1205815413722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205815413722 : Closed e1205815413722 ∧ code e1205815413722 = 5603861924826 := by decide
theorem cert_e1205815413722 : check e1205815413722 [[],[]] .smaller = true := by decide
def e1205815413998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205815413998 : Closed e1205815413998 ∧ code e1205815413998 = 5603861925102 := by decide
theorem cert_e1205815413998 : check e1205815413998 [[],[]] .smaller = true := by decide
def e1205815414006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205815414006 : Closed e1205815414006 ∧ code e1205815414006 = 5603861925110 := by decide
theorem cert_e1205815414006 : check e1205815414006 [[],[]] .smaller = true := by decide
def e1205815414382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205815414382 : Closed e1205815414382 ∧ code e1205815414382 = 5603861925486 := by decide
theorem cert_e1205815414382 : check e1205815414382 [[],[]] .smaller = true := by decide
def e1205815414394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205815414394 : Closed e1205815414394 ∧ code e1205815414394 = 5603861925498 := by decide
theorem cert_e1205815414394 : check e1205815414394 [[],[]] .smaller = true := by decide
def e1205815414582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205815414582 : Closed e1205815414582 ∧ code e1205815414582 = 5603861925686 := by decide
theorem cert_e1205815414582 : check e1205815414582 [[],[]] .smaller = true := by decide
def e1205815414586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205815414586 : Closed e1205815414586 ∧ code e1205815414586 = 5603861925690 := by decide
theorem cert_e1205815414586 : check e1205815414586 [[],[]] .smaller = true := by decide
def e1205815422510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205815422510 : Closed e1205815422510 ∧ code e1205815422510 = 5603861933614 := by decide
theorem cert_e1205815422510 : check e1205815422510 [[],[]] .chain = true := by decide
def e1205815422690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205815422690 : Closed e1205815422690 ∧ code e1205815422690 = 5603861933794 := by decide
theorem cert_e1205815422690 : check e1205815422690 [[],[]] .chain = true := by decide
def e1205815422702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1205815422702 : Closed e1205815422702 ∧ code e1205815422702 = 5603861933806 := by decide
theorem cert_e1205815422702 : check e1205815422702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1205815422742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205815422742 : Closed e1205815422742 ∧ code e1205815422742 = 5603861933846 := by decide
theorem cert_e1205815422742 : check e1205815422742 [[],[]] .chain = true := by decide
def e1205815422818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205815422818 : Closed e1205815422818 ∧ code e1205815422818 = 5603861933922 := by decide
theorem cert_e1205815422818 : check e1205815422818 [[],[]] .chain = true := by decide
def e1205815422830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1205815422830 : Closed e1205815422830 ∧ code e1205815422830 = 5603861933934 := by decide
theorem cert_e1205815422830 : check e1205815422830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815422838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1205815422838 : Closed e1205815422838 ∧ code e1205815422838 = 5603861933942 := by decide
theorem cert_e1205815422838 : check e1205815422838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815425086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e1205815425086 : Closed e1205815425086 ∧ code e1205815425086 = 5603861936190 := by decide
theorem cert_e1205815425086 : check e1205815425086 [[],[]] .chain = true := by decide
def e1205815425506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205815425506 : Closed e1205815425506 ∧ code e1205815425506 = 5603861936610 := by decide
theorem cert_e1205815425506 : check e1205815425506 [[],[]] .chain = true := by decide
def e1205815425518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205815425518 : Closed e1205815425518 ∧ code e1205815425518 = 5603861936622 := by decide
theorem cert_e1205815425518 : check e1205815425518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1205815426078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e1205815426078 : Closed e1205815426078 ∧ code e1205815426078 = 5603861937182 := by decide
theorem cert_e1205815426078 : check e1205815426078 [[],[]] .chain = true := by decide
def e1205815426274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205815426274 : Closed e1205815426274 ∧ code e1205815426274 = 5603861937378 := by decide
theorem cert_e1205815426274 : check e1205815426274 [[],[]] .chain = true := by decide
def e1205815426286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815426286 : Closed e1205815426286 ∧ code e1205815426286 = 5603861937390 := by decide
theorem cert_e1205815426286 : check e1205815426286 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1205815426294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815426294 : Closed e1205815426294 ∧ code e1205815426294 = 5603861937398 := by decide
theorem cert_e1205815426294 : check e1205815426294 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.under],[.under,.under]] .identityHead = true := by decide
def e1205815445470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e1205815445470 : Closed e1205815445470 ∧ code e1205815445470 = 5603861956574 := by decide
theorem cert_e1205815445470 : check e1205815445470 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815449134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205815449134 : Closed e1205815449134 ∧ code e1205815449134 = 5603861960238 := by decide
theorem cert_e1205815449134 : check e1205815449134 [[],[]] .chain = true := by decide
def e1205815449314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205815449314 : Closed e1205815449314 ∧ code e1205815449314 = 5603861960418 := by decide
theorem cert_e1205815449314 : check e1205815449314 [[],[]] .chain = true := by decide
def e1205815449326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1205815449326 : Closed e1205815449326 ∧ code e1205815449326 = 5603861960430 := by decide
theorem cert_e1205815449326 : check e1205815449326 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815449454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1205815449454 : Closed e1205815449454 ∧ code e1205815449454 = 5603861960558 := by decide
theorem cert_e1205815449454 : check e1205815449454 [[],[]] .chain = true := by decide
def e1205815449462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1205815449462 : Closed e1205815449462 ∧ code e1205815449462 = 5603861960566 := by decide
theorem cert_e1205815449462 : check e1205815449462 [[],[]] .chain = true := by decide
def e1205815449482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205815449482 : Closed e1205815449482 ∧ code e1205815449482 = 5603861960586 := by decide
theorem cert_e1205815449482 : check e1205815449482 [[],[]] .chain = true := by decide
def e1205815449506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205815449506 : Closed e1205815449506 ∧ code e1205815449506 = 5603861960610 := by decide
theorem cert_e1205815449506 : check e1205815449506 [[],[]] .chain = true := by decide
def e1205815449518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1205815449518 : Closed e1205815449518 ∧ code e1205815449518 = 5603861960622 := by decide
theorem cert_e1205815449518 : check e1205815449518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815449526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1205815449526 : Closed e1205815449526 ∧ code e1205815449526 = 5603861960630 := by decide
theorem cert_e1205815449526 : check e1205815449526 [[],[]] .chain = true := by decide
end Blc.Floor42
