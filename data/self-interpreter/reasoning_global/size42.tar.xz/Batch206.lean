import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205478298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205478298 : Closed e1211205478298 ∧ code e1211205478298 = 5609251989402 := by decide
theorem cert_e1211205478298 : check e1211205478298 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205480686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211205480686 : Closed e1211205480686 ∧ code e1211205480686 = 5609251991790 := by decide
theorem cert_e1211205480686 : check e1211205480686 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205480694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211205480694 : Closed e1211205480694 ∧ code e1211205480694 = 5609251991798 := by decide
theorem cert_e1211205480694 : check e1211205480694 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205481174 : Closed e1211205481174 ∧ code e1211205481174 = 5609251992278 := by decide
theorem cert_e1211205481174 : check e1211205481174 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205481178 : Closed e1211205481178 ∧ code e1211205481178 = 5609251992282 := by decide
theorem cert_e1211205481178 : check e1211205481178 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205481194 : Closed e1211205481194 ∧ code e1211205481194 = 5609251992298 := by decide
theorem cert_e1211205481194 : check e1211205481194 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205481270 : Closed e1211205481270 ∧ code e1211205481270 = 5609251992374 := by decide
theorem cert_e1211205481270 : check e1211205481270 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205481274 : Closed e1211205481274 ∧ code e1211205481274 = 5609251992378 := by decide
theorem cert_e1211205481274 : check e1211205481274 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205481370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205481370 : Closed e1211205481370 ∧ code e1211205481370 = 5609251992474 := by decide
theorem cert_e1211205481370 : check e1211205481370 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205507766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211205507766 : Closed e1211205507766 ∧ code e1211205507766 = 5609252018870 := by decide
theorem cert_e1211205507766 : check e1211205507766 [[],[]] .chain = true := by decide
def e1211205507798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211205507798 : Closed e1211205507798 ∧ code e1211205507798 = 5609252018902 := by decide
theorem cert_e1211205507798 : check e1211205507798 [[],[]] .chain = true := by decide
def e1211205507802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211205507802 : Closed e1211205507802 ∧ code e1211205507802 = 5609252018906 := by decide
theorem cert_e1211205507802 : check e1211205507802 [[],[]] .chain = true := by decide
def e1211205507926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211205507926 : Closed e1211205507926 ∧ code e1211205507926 = 5609252019030 := by decide
theorem cert_e1211205507926 : check e1211205507926 [[],[]] .chain = true := by decide
def e1211205507930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211205507930 : Closed e1211205507930 ∧ code e1211205507930 = 5609252019034 := by decide
theorem cert_e1211205507930 : check e1211205507930 [[],[]] .chain = true := by decide
def e1211205507946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211205507946 : Closed e1211205507946 ∧ code e1211205507946 = 5609252019050 := by decide
theorem cert_e1211205507946 : check e1211205507946 [[],[]] .chain = true := by decide
def e1211205508438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211205508438 : Closed e1211205508438 ∧ code e1211205508438 = 5609252019542 := by decide
theorem cert_e1211205508438 : check e1211205508438 [[],[]] .chain = true := by decide
def e1211205508442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211205508442 : Closed e1211205508442 ∧ code e1211205508442 = 5609252019546 := by decide
theorem cert_e1211205508442 : check e1211205508442 [[],[]] .chain = true := by decide
def e1211205508458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211205508458 : Closed e1211205508458 ∧ code e1211205508458 = 5609252019562 := by decide
theorem cert_e1211205508458 : check e1211205508458 [[],[]] .chain = true := by decide
def e1211205508522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211205508522 : Closed e1211205508522 ∧ code e1211205508522 = 5609252019626 := by decide
theorem cert_e1211205508522 : check e1211205508522 [[],[]] .chain = true := by decide
def e1211205509302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 1))))))
theorem wire_e1211205509302 : Closed e1211205509302 ∧ code e1211205509302 = 5609252020406 := by decide
theorem cert_e1211205509302 : check e1211205509302 [[],[]] .chain = true := by decide
def e1211205509334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.var 1))))))
theorem wire_e1211205509334 : Closed e1211205509334 ∧ code e1211205509334 = 5609252020438 := by decide
theorem cert_e1211205509334 : check e1211205509334 [[],[]] .chain = true := by decide
def e1211205509338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))) (.var 0))))))
theorem wire_e1211205509338 : Closed e1211205509338 ∧ code e1211205509338 = 5609252020442 := by decide
theorem cert_e1211205509338 : check e1211205509338 [[],[]] .chain = true := by decide
def e1211205509686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205509686 : Closed e1211205509686 ∧ code e1211205509686 = 5609252020790 := by decide
theorem cert_e1211205509686 : check e1211205509686 [[],[]] .chain = true := by decide
def e1211205509690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205509690 : Closed e1211205509690 ∧ code e1211205509690 = 5609252020794 := by decide
theorem cert_e1211205509690 : check e1211205509690 [[],[]] .chain = true := by decide
def e1211205509774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205509774 : Closed e1211205509774 ∧ code e1211205509774 = 5609252020878 := by decide
theorem cert_e1211205509774 : check e1211205509774 [[],[]] .chain = true := by decide
def e1211205509830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205509830 : Closed e1211205509830 ∧ code e1211205509830 = 5609252020934 := by decide
theorem cert_e1211205509830 : check e1211205509830 [[],[]] .chain = true := by decide
def e1211205509910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211205509910 : Closed e1211205509910 ∧ code e1211205509910 = 5609252021014 := by decide
theorem cert_e1211205509910 : check e1211205509910 [[],[]] .chain = true := by decide
def e1211205509986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211205509986 : Closed e1211205509986 ∧ code e1211205509986 = 5609252021090 := by decide
theorem cert_e1211205509986 : check e1211205509986 [[],[]] .chain = true := by decide
def e1211205509998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e1211205509998 : Closed e1211205509998 ∧ code e1211205509998 = 5609252021102 := by decide
theorem cert_e1211205509998 : check e1211205509998 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e1211205510006 : Closed e1211205510006 ∧ code e1211205510006 = 5609252021110 := by decide
theorem cert_e1211205510006 : check e1211205510006 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211205510026 : Closed e1211205510026 ∧ code e1211205510026 = 5609252021130 := by decide
theorem cert_e1211205510026 : check e1211205510026 [[],[]] .chain = true := by decide
def e1211205510050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211205510050 : Closed e1211205510050 ∧ code e1211205510050 = 5609252021154 := by decide
theorem cert_e1211205510050 : check e1211205510050 [[],[]] .chain = true := by decide
def e1211205510062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e1211205510062 : Closed e1211205510062 ∧ code e1211205510062 = 5609252021166 := by decide
theorem cert_e1211205510062 : check e1211205510062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 1))))))
theorem wire_e1211205510070 : Closed e1211205510070 ∧ code e1211205510070 = 5609252021174 := by decide
theorem cert_e1211205510070 : check e1211205510070 [[],[]] .chain = true := by decide
def e1211205510074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e1211205510074 : Closed e1211205510074 ∧ code e1211205510074 = 5609252021178 := by decide
theorem cert_e1211205510074 : check e1211205510074 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e1211205510102 : Closed e1211205510102 ∧ code e1211205510102 = 5609252021206 := by decide
theorem cert_e1211205510102 : check e1211205510102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e1211205510106 : Closed e1211205510106 ∧ code e1211205510106 = 5609252021210 := by decide
theorem cert_e1211205510106 : check e1211205510106 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205510838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e1211205510838 : Closed e1211205510838 ∧ code e1211205510838 = 5609252021942 := by decide
theorem cert_e1211205510838 : check e1211205510838 [[],[]] .chain = true := by decide
def e1211205510870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e1211205510870 : Closed e1211205510870 ∧ code e1211205510870 = 5609252021974 := by decide
theorem cert_e1211205510870 : check e1211205510870 [[],[]] .chain = true := by decide
def e1211205510874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e1211205510874 : Closed e1211205510874 ∧ code e1211205510874 = 5609252021978 := by decide
theorem cert_e1211205510874 : check e1211205510874 [[],[]] .chain = true := by decide
def e1211205510998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211205510998 : Closed e1211205510998 ∧ code e1211205510998 = 5609252022102 := by decide
theorem cert_e1211205510998 : check e1211205510998 [[],[]] .chain = true := by decide
def e1211205511002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211205511002 : Closed e1211205511002 ∧ code e1211205511002 = 5609252022106 := by decide
theorem cert_e1211205511002 : check e1211205511002 [[],[]] .chain = true := by decide
def e1211205511018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211205511018 : Closed e1211205511018 ∧ code e1211205511018 = 5609252022122 := by decide
theorem cert_e1211205511018 : check e1211205511018 [[],[]] .chain = true := by decide
def e1211205511222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205511222 : Closed e1211205511222 ∧ code e1211205511222 = 5609252022326 := by decide
theorem cert_e1211205511222 : check e1211205511222 [[],[]] .chain = true := by decide
def e1211205511310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205511310 : Closed e1211205511310 ∧ code e1211205511310 = 5609252022414 := by decide
theorem cert_e1211205511310 : check e1211205511310 [[],[]] .chain = true := by decide
def e1211205511394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211205511394 : Closed e1211205511394 ∧ code e1211205511394 = 5609252022498 := by decide
theorem cert_e1211205511394 : check e1211205511394 [[],[]] .chain = true := by decide
def e1211205511406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211205511406 : Closed e1211205511406 ∧ code e1211205511406 = 5609252022510 := by decide
theorem cert_e1211205511406 : check e1211205511406 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205511414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211205511414 : Closed e1211205511414 ∧ code e1211205511414 = 5609252022518 := by decide
theorem cert_e1211205511414 : check e1211205511414 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205511606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211205511606 : Closed e1211205511606 ∧ code e1211205511606 = 5609252022710 := by decide
theorem cert_e1211205511606 : check e1211205511606 [[],[]] .chain = true := by decide
def e1211205511638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211205511638 : Closed e1211205511638 ∧ code e1211205511638 = 5609252022742 := by decide
theorem cert_e1211205511638 : check e1211205511638 [[],[]] .chain = true := by decide
def e1211205511642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211205511642 : Closed e1211205511642 ∧ code e1211205511642 = 5609252022746 := by decide
theorem cert_e1211205511642 : check e1211205511642 [[],[]] .chain = true := by decide
def e1211205511798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205511798 : Closed e1211205511798 ∧ code e1211205511798 = 5609252022902 := by decide
theorem cert_e1211205511798 : check e1211205511798 [[],[]] .chain = true := by decide
def e1211205511942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205511942 : Closed e1211205511942 ∧ code e1211205511942 = 5609252023046 := by decide
theorem cert_e1211205511942 : check e1211205511942 [[],[]] .chain = true := by decide
def e1211205511966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211205511966 : Closed e1211205511966 ∧ code e1211205511966 = 5609252023070 := by decide
theorem cert_e1211205511966 : check e1211205511966 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205511990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205511990 : Closed e1211205511990 ∧ code e1211205511990 = 5609252023094 := by decide
theorem cert_e1211205511990 : check e1211205511990 [[],[]] .chain = true := by decide
def e1211205511994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205511994 : Closed e1211205511994 ∧ code e1211205511994 = 5609252023098 := by decide
theorem cert_e1211205511994 : check e1211205511994 [[],[]] .chain = true := by decide
def e1211205512078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211205512078 : Closed e1211205512078 ∧ code e1211205512078 = 5609252023182 := by decide
theorem cert_e1211205512078 : check e1211205512078 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211205512214 : Closed e1211205512214 ∧ code e1211205512214 = 5609252023318 := by decide
theorem cert_e1211205512214 : check e1211205512214 [[],[]] .chain = true := by decide
def e1211205512218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205512218 : Closed e1211205512218 ∧ code e1211205512218 = 5609252023322 := by decide
theorem cert_e1211205512218 : check e1211205512218 [[],[]] .chain = true := by decide
def e1211205512262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205512262 : Closed e1211205512262 ∧ code e1211205512262 = 5609252023366 := by decide
theorem cert_e1211205512262 : check e1211205512262 [[],[]] .chain = true := by decide
def e1211205512290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211205512290 : Closed e1211205512290 ∧ code e1211205512290 = 5609252023394 := by decide
theorem cert_e1211205512290 : check e1211205512290 [[],[]] .chain = true := by decide
def e1211205512302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205512302 : Closed e1211205512302 ∧ code e1211205512302 = 5609252023406 := by decide
theorem cert_e1211205512302 : check e1211205512302 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211205512310 : Closed e1211205512310 ∧ code e1211205512310 = 5609252023414 := by decide
theorem cert_e1211205512310 : check e1211205512310 [[],[]] .chain = true := by decide
def e1211205512314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205512314 : Closed e1211205512314 ∧ code e1211205512314 = 5609252023418 := by decide
theorem cert_e1211205512314 : check e1211205512314 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211205512406 : Closed e1211205512406 ∧ code e1211205512406 = 5609252023510 := by decide
theorem cert_e1211205512406 : check e1211205512406 [[],[]] .chain = true := by decide
def e1211205512410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211205512410 : Closed e1211205512410 ∧ code e1211205512410 = 5609252023514 := by decide
theorem cert_e1211205512410 : check e1211205512410 [[],[]] .chain = true := by decide
def e1211205512426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211205512426 : Closed e1211205512426 ∧ code e1211205512426 = 5609252023530 := by decide
theorem cert_e1211205512426 : check e1211205512426 [[],[]] .chain = true := by decide
def e1211205512454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205512454 : Closed e1211205512454 ∧ code e1211205512454 = 5609252023558 := by decide
theorem cert_e1211205512454 : check e1211205512454 [[],[]] .chain = true := by decide
def e1211205512478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205512478 : Closed e1211205512478 ∧ code e1211205512478 = 5609252023582 := by decide
theorem cert_e1211205512478 : check e1211205512478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205512502 : Closed e1211205512502 ∧ code e1211205512502 = 5609252023606 := by decide
theorem cert_e1211205512502 : check e1211205512502 [[],[]] .chain = true := by decide
def e1211205512506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205512506 : Closed e1211205512506 ∧ code e1211205512506 = 5609252023610 := by decide
theorem cert_e1211205512506 : check e1211205512506 [[],[]] .chain = true := by decide
def e1211205512578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205512578 : Closed e1211205512578 ∧ code e1211205512578 = 5609252023682 := by decide
theorem cert_e1211205512578 : check e1211205512578 [[],[]] .chain = true := by decide
def e1211205512590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211205512590 : Closed e1211205512590 ∧ code e1211205512590 = 5609252023694 := by decide
theorem cert_e1211205512590 : check e1211205512590 [[],[]] .chain = true := by decide
def e1211205512602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205512602 : Closed e1211205512602 ∧ code e1211205512602 = 5609252023706 := by decide
theorem cert_e1211205512602 : check e1211205512602 [[],[]] .chain = true := by decide
def e1211205512646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205512646 : Closed e1211205512646 ∧ code e1211205512646 = 5609252023750 := by decide
theorem cert_e1211205512646 : check e1211205512646 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205512758 : Closed e1211205512758 ∧ code e1211205512758 = 5609252023862 := by decide
theorem cert_e1211205512758 : check e1211205512758 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205512762 : Closed e1211205512762 ∧ code e1211205512762 = 5609252023866 := by decide
theorem cert_e1211205512762 : check e1211205512762 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205512846 : Closed e1211205512846 ∧ code e1211205512846 = 5609252023950 := by decide
theorem cert_e1211205512846 : check e1211205512846 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205512902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205512902 : Closed e1211205512902 ∧ code e1211205512902 = 5609252024006 := by decide
theorem cert_e1211205512902 : check e1211205512902 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205513302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e1211205513302 : Closed e1211205513302 ∧ code e1211205513302 = 5609252024406 := by decide
theorem cert_e1211205513302 : check e1211205513302 [[],[]] .chain = true := by decide
def e1211205513306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e1211205513306 : Closed e1211205513306 ∧ code e1211205513306 = 5609252024410 := by decide
theorem cert_e1211205513306 : check e1211205513306 [[],[]] .chain = true := by decide
def e1211205513322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))) (.var 0))))))
theorem wire_e1211205513322 : Closed e1211205513322 ∧ code e1211205513322 = 5609252024426 := by decide
theorem cert_e1211205513322 : check e1211205513322 [[],[]] .chain = true := by decide
def e1211205513498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211205513498 : Closed e1211205513498 ∧ code e1211205513498 = 5609252024602 := by decide
theorem cert_e1211205513498 : check e1211205513498 [[],[]] .chain = true := by decide
def e1211205513542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211205513542 : Closed e1211205513542 ∧ code e1211205513542 = 5609252024646 := by decide
theorem cert_e1211205513542 : check e1211205513542 [[],[]] .chain = true := by decide
def e1211205513610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211205513610 : Closed e1211205513610 ∧ code e1211205513610 = 5609252024714 := by decide
theorem cert_e1211205513610 : check e1211205513610 [[],[]] .chain = true := by decide
def e1211205513634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211205513634 : Closed e1211205513634 ∧ code e1211205513634 = 5609252024738 := by decide
theorem cert_e1211205513634 : check e1211205513634 [[],[]] .chain = true := by decide
def e1211205513646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e1211205513646 : Closed e1211205513646 ∧ code e1211205513646 = 5609252024750 := by decide
theorem cert_e1211205513646 : check e1211205513646 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205513654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e1211205513654 : Closed e1211205513654 ∧ code e1211205513654 = 5609252024758 := by decide
theorem cert_e1211205513654 : check e1211205513654 [[],[]] .chain = true := by decide
def e1211205513658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e1211205513658 : Closed e1211205513658 ∧ code e1211205513658 = 5609252024762 := by decide
theorem cert_e1211205513658 : check e1211205513658 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205513686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e1211205513686 : Closed e1211205513686 ∧ code e1211205513686 = 5609252024790 := by decide
theorem cert_e1211205513686 : check e1211205513686 [[],[]] .chain = true := by decide
def e1211205513690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e1211205513690 : Closed e1211205513690 ∧ code e1211205513690 = 5609252024794 := by decide
theorem cert_e1211205513690 : check e1211205513690 [[],[]] .chain = true := by decide
def e1211205513706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e1211205513706 : Closed e1211205513706 ∧ code e1211205513706 = 5609252024810 := by decide
theorem cert_e1211205513706 : check e1211205513706 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205514070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211205514070 : Closed e1211205514070 ∧ code e1211205514070 = 5609252025174 := by decide
theorem cert_e1211205514070 : check e1211205514070 [[],[]] .chain = true := by decide
def e1211205514074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211205514074 : Closed e1211205514074 ∧ code e1211205514074 = 5609252025178 := by decide
theorem cert_e1211205514074 : check e1211205514074 [[],[]] .chain = true := by decide
def e1211205514090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211205514090 : Closed e1211205514090 ∧ code e1211205514090 = 5609252025194 := by decide
theorem cert_e1211205514090 : check e1211205514090 [[],[]] .chain = true := by decide
def e1211205514154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e1211205514154 : Closed e1211205514154 ∧ code e1211205514154 = 5609252025258 := by decide
theorem cert_e1211205514154 : check e1211205514154 [[],[]] .chain = true := by decide
def e1211205514262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211205514262 : Closed e1211205514262 ∧ code e1211205514262 = 5609252025366 := by decide
theorem cert_e1211205514262 : check e1211205514262 [[],[]] .chain = true := by decide
def e1211205514266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205514266 : Closed e1211205514266 ∧ code e1211205514266 = 5609252025370 := by decide
theorem cert_e1211205514266 : check e1211205514266 [[],[]] .chain = true := by decide
def e1211205514310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205514310 : Closed e1211205514310 ∧ code e1211205514310 = 5609252025414 := by decide
theorem cert_e1211205514310 : check e1211205514310 [[],[]] .chain = true := by decide
def e1211205514338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211205514338 : Closed e1211205514338 ∧ code e1211205514338 = 5609252025442 := by decide
theorem cert_e1211205514338 : check e1211205514338 [[],[]] .chain = true := by decide
def e1211205514350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205514350 : Closed e1211205514350 ∧ code e1211205514350 = 5609252025454 := by decide
theorem cert_e1211205514350 : check e1211205514350 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205514358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211205514358 : Closed e1211205514358 ∧ code e1211205514358 = 5609252025462 := by decide
theorem cert_e1211205514358 : check e1211205514358 [[],[]] .chain = true := by decide
def e1211205514362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205514362 : Closed e1211205514362 ∧ code e1211205514362 = 5609252025466 := by decide
theorem cert_e1211205514362 : check e1211205514362 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205514454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211205514454 : Closed e1211205514454 ∧ code e1211205514454 = 5609252025558 := by decide
theorem cert_e1211205514454 : check e1211205514454 [[],[]] .chain = true := by decide
def e1211205514458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211205514458 : Closed e1211205514458 ∧ code e1211205514458 = 5609252025562 := by decide
theorem cert_e1211205514458 : check e1211205514458 [[],[]] .chain = true := by decide
def e1211205514474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211205514474 : Closed e1211205514474 ∧ code e1211205514474 = 5609252025578 := by decide
theorem cert_e1211205514474 : check e1211205514474 [[],[]] .chain = true := by decide
def e1211205514502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205514502 : Closed e1211205514502 ∧ code e1211205514502 = 5609252025606 := by decide
theorem cert_e1211205514502 : check e1211205514502 [[],[]] .chain = true := by decide
def e1211205514526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205514526 : Closed e1211205514526 ∧ code e1211205514526 = 5609252025630 := by decide
theorem cert_e1211205514526 : check e1211205514526 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205514550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205514550 : Closed e1211205514550 ∧ code e1211205514550 = 5609252025654 := by decide
theorem cert_e1211205514550 : check e1211205514550 [[],[]] .chain = true := by decide
def e1211205514554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205514554 : Closed e1211205514554 ∧ code e1211205514554 = 5609252025658 := by decide
theorem cert_e1211205514554 : check e1211205514554 [[],[]] .chain = true := by decide
def e1211205514626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205514626 : Closed e1211205514626 ∧ code e1211205514626 = 5609252025730 := by decide
theorem cert_e1211205514626 : check e1211205514626 [[],[]] .chain = true := by decide
def e1211205514638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211205514638 : Closed e1211205514638 ∧ code e1211205514638 = 5609252025742 := by decide
theorem cert_e1211205514638 : check e1211205514638 [[],[]] .chain = true := by decide
def e1211205514650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205514650 : Closed e1211205514650 ∧ code e1211205514650 = 5609252025754 := by decide
theorem cert_e1211205514650 : check e1211205514650 [[],[]] .chain = true := by decide
def e1211205514694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205514694 : Closed e1211205514694 ∧ code e1211205514694 = 5609252025798 := by decide
theorem cert_e1211205514694 : check e1211205514694 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205514762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211205514762 : Closed e1211205514762 ∧ code e1211205514762 = 5609252025866 := by decide
theorem cert_e1211205514762 : check e1211205514762 [[],[]] .chain = true := by decide
def e1211205514806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205514806 : Closed e1211205514806 ∧ code e1211205514806 = 5609252025910 := by decide
theorem cert_e1211205514806 : check e1211205514806 [[],[]] .chain = true := by decide
def e1211205514810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205514810 : Closed e1211205514810 ∧ code e1211205514810 = 5609252025914 := by decide
theorem cert_e1211205514810 : check e1211205514810 [[],[]] .chain = true := by decide
def e1211205514858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211205514858 : Closed e1211205514858 ∧ code e1211205514858 = 5609252025962 := by decide
theorem cert_e1211205514858 : check e1211205514858 [[],[]] .chain = true := by decide
def e1211205514882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205514882 : Closed e1211205514882 ∧ code e1211205514882 = 5609252025986 := by decide
theorem cert_e1211205514882 : check e1211205514882 [[],[]] .chain = true := by decide
def e1211205514894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205514894 : Closed e1211205514894 ∧ code e1211205514894 = 5609252025998 := by decide
theorem cert_e1211205514894 : check e1211205514894 [[],[]] .chain = true := by decide
def e1211205514906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205514906 : Closed e1211205514906 ∧ code e1211205514906 = 5609252026010 := by decide
theorem cert_e1211205514906 : check e1211205514906 [[],[]] .chain = true := by decide
def e1211205514950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205514950 : Closed e1211205514950 ∧ code e1211205514950 = 5609252026054 := by decide
theorem cert_e1211205514950 : check e1211205514950 [[],[]] .chain = true := by decide
def e1211205515034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211205515034 : Closed e1211205515034 ∧ code e1211205515034 = 5609252026138 := by decide
theorem cert_e1211205515034 : check e1211205515034 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211205515078 : Closed e1211205515078 ∧ code e1211205515078 = 5609252026182 := by decide
theorem cert_e1211205515078 : check e1211205515078 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e1211205515478 : Closed e1211205515478 ∧ code e1211205515478 = 5609252026582 := by decide
theorem cert_e1211205515478 : check e1211205515478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e1211205515482 : Closed e1211205515482 ∧ code e1211205515482 = 5609252026586 := by decide
theorem cert_e1211205515482 : check e1211205515482 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e1211205515498 : Closed e1211205515498 ∧ code e1211205515498 = 5609252026602 := by decide
theorem cert_e1211205515498 : check e1211205515498 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205515830 : Closed e1211205515830 ∧ code e1211205515830 = 5609252026934 := by decide
theorem cert_e1211205515830 : check e1211205515830 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205515834 : Closed e1211205515834 ∧ code e1211205515834 = 5609252026938 := by decide
theorem cert_e1211205515834 : check e1211205515834 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205515918 : Closed e1211205515918 ∧ code e1211205515918 = 5609252027022 := by decide
theorem cert_e1211205515918 : check e1211205515918 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205515974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205515974 : Closed e1211205515974 ∧ code e1211205515974 = 5609252027078 := by decide
theorem cert_e1211205515974 : check e1211205515974 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205516058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211205516058 : Closed e1211205516058 ∧ code e1211205516058 = 5609252027162 := by decide
theorem cert_e1211205516058 : check e1211205516058 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205516102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211205516102 : Closed e1211205516102 ∧ code e1211205516102 = 5609252027206 := by decide
theorem cert_e1211205516102 : check e1211205516102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205517558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1))))))
theorem wire_e1211205517558 : Closed e1211205517558 ∧ code e1211205517558 = 5609252028662 := by decide
theorem cert_e1211205517558 : check e1211205517558 [[],[]] .chain = true := by decide
def e1211205517562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))) (.var 0))))))
theorem wire_e1211205517562 : Closed e1211205517562 ∧ code e1211205517562 = 5609252028666 := by decide
theorem cert_e1211205517562 : check e1211205517562 [[],[]] .chain = true := by decide
def e1211205517942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205517942 : Closed e1211205517942 ∧ code e1211205517942 = 5609252029046 := by decide
theorem cert_e1211205517942 : check e1211205517942 [[],[]] .chain = true := by decide
def e1211205518134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205518134 : Closed e1211205518134 ∧ code e1211205518134 = 5609252029238 := by decide
theorem cert_e1211205518134 : check e1211205518134 [[],[]] .chain = true := by decide
def e1211205518138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205518138 : Closed e1211205518138 ∧ code e1211205518138 = 5609252029242 := by decide
theorem cert_e1211205518138 : check e1211205518138 [[],[]] .chain = true := by decide
def e1211205518222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.var 2)))))))
theorem wire_e1211205518222 : Closed e1211205518222 ∧ code e1211205518222 = 5609252029326 := by decide
theorem cert_e1211205518222 : check e1211205518222 [[],[]] .chain = true := by decide
def e1211205518278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.lam (.var 1)))))))
theorem wire_e1211205518278 : Closed e1211205518278 ∧ code e1211205518278 = 5609252029382 := by decide
theorem cert_e1211205518278 : check e1211205518278 [[],[]] .chain = true := by decide
def e1211205518902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e1211205518902 : Closed e1211205518902 ∧ code e1211205518902 = 5609252030006 := by decide
theorem cert_e1211205518902 : check e1211205518902 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205518990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e1211205518990 : Closed e1211205518990 ∧ code e1211205518990 = 5609252030094 := by decide
theorem cert_e1211205518990 : check e1211205518990 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205519086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e1211205519086 : Closed e1211205519086 ∧ code e1211205519086 = 5609252030190 := by decide
theorem cert_e1211205519086 : check e1211205519086 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205519094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e1211205519094 : Closed e1211205519094 ∧ code e1211205519094 = 5609252030198 := by decide
theorem cert_e1211205519094 : check e1211205519094 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205519126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211205519126 : Closed e1211205519126 ∧ code e1211205519126 = 5609252030230 := by decide
theorem cert_e1211205519126 : check e1211205519126 [[],[]] .chain = true := by decide
def e1211205519222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211205519222 : Closed e1211205519222 ∧ code e1211205519222 = 5609252030326 := by decide
theorem cert_e1211205519222 : check e1211205519222 [[],[]] .chain = true := by decide
def e1211205519242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205519242 : Closed e1211205519242 ∧ code e1211205519242 = 5609252030346 := by decide
theorem cert_e1211205519242 : check e1211205519242 [[],[]] .chain = true := by decide
def e1211205519278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e1211205519278 : Closed e1211205519278 ∧ code e1211205519278 = 5609252030382 := by decide
theorem cert_e1211205519278 : check e1211205519278 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205519286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211205519286 : Closed e1211205519286 ∧ code e1211205519286 = 5609252030390 := by decide
theorem cert_e1211205519286 : check e1211205519286 [[],[]] .chain = true := by decide
def e1211205519290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e1211205519290 : Closed e1211205519290 ∧ code e1211205519290 = 5609252030394 := by decide
theorem cert_e1211205519290 : check e1211205519290 [[],[]] .chain = true := by decide
def e1211205519318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e1211205519318 : Closed e1211205519318 ∧ code e1211205519318 = 5609252030422 := by decide
theorem cert_e1211205519318 : check e1211205519318 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205519758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205519758 : Closed e1211205519758 ∧ code e1211205519758 = 5609252030862 := by decide
theorem cert_e1211205519758 : check e1211205519758 [[],[]] .chain = true := by decide
def e1211205519814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205519814 : Closed e1211205519814 ∧ code e1211205519814 = 5609252030918 := by decide
theorem cert_e1211205519814 : check e1211205519814 [[],[]] .chain = true := by decide
def e1211205520414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3))))))))
theorem wire_e1211205520414 : Closed e1211205520414 ∧ code e1211205520414 = 5609252031518 := by decide
theorem cert_e1211205520414 : check e1211205520414 [[],[]] .chain = true := by decide
def e1211205520610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211205520610 : Closed e1211205520610 ∧ code e1211205520610 = 5609252031714 := by decide
theorem cert_e1211205520610 : check e1211205520610 [[],[]] .chain = true := by decide
def e1211205520622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205520622 : Closed e1211205520622 ∧ code e1211205520622 = 5609252031726 := by decide
theorem cert_e1211205520622 : check e1211205520622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205520630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205520630 : Closed e1211205520630 ∧ code e1211205520630 = 5609252031734 := by decide
theorem cert_e1211205520630 : check e1211205520630 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205520910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211205520910 : Closed e1211205520910 ∧ code e1211205520910 = 5609252032014 := by decide
theorem cert_e1211205520910 : check e1211205520910 [[],[]] .chain = true := by decide
def e1211205520922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211205520922 : Closed e1211205520922 ∧ code e1211205520922 = 5609252032026 := by decide
theorem cert_e1211205520922 : check e1211205520922 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205520994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211205520994 : Closed e1211205520994 ∧ code e1211205520994 = 5609252032098 := by decide
theorem cert_e1211205520994 : check e1211205520994 [[],[]] .chain = true := by decide
end Blc.Floor42
