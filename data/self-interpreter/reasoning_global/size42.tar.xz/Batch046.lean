import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1124661464022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124661464022 : Closed e1124661464022 ∧ code e1124661464022 = 5522707975126 := by decide
def e1124661464026 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124661464026 : Closed e1124661464026 ∧ code e1124661464026 = 5522707975130 := by decide
private def t_e1124661464026 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e1124661464026 : ¬ IsSelfInterpreter e1124661464026 :=
  wSource (t := t_e1124661464026) (replay_sound (ps := []) (t := e1124661464026) (by decide)) (by decide)
def e1124661464302 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124661464302 : Closed e1124661464302 ∧ code e1124661464302 = 5522707975406 := by decide
def e1124661464310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124661464310 : Closed e1124661464310 ∧ code e1124661464310 = 5522707975414 := by decide
def e1124661464686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124661464686 : Closed e1124661464686 ∧ code e1124661464686 = 5522707975790 := by decide
theorem cert_e1124661464686 : check e1124661464686 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1124661464698 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124661464698 : Closed e1124661464698 ∧ code e1124661464698 = 5522707975802 := by decide
theorem cert_e1124661464698 : check e1124661464698 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1124661464886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124661464886 : Closed e1124661464886 ∧ code e1124661464886 = 5522707975990 := by decide
def e1124661464890 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124661464890 : Closed e1124661464890 ∧ code e1124661464890 = 5522707975994 := by decide
def e1127172464666 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172464666 : Closed e1127172464666 ∧ code e1127172464666 = 5525218975770 := by decide
theorem cert_e1127172464666 : check e1127172464666 [[]] .width = true := by decide
def e1127172464758 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172464758 : Closed e1127172464758 ∧ code e1127172464758 = 5525218975862 := by decide
theorem cert_e1127172464758 : check e1127172464758 [[]] .width = true := by decide
def e1127172465002 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172465002 : Closed e1127172465002 ∧ code e1127172465002 = 5525218976106 := by decide
theorem cert_e1127172465002 : check e1127172465002 [[]] .width = true := by decide
def e1127172465050 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172465050 : Closed e1127172465050 ∧ code e1127172465050 = 5525218976154 := by decide
theorem cert_e1127172465050 : check e1127172465050 [[]] .width = true := by decide
def e1127172497434 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172497434 : Closed e1127172497434 ∧ code e1127172497434 = 5525219008538 := by decide
theorem cert_e1127172497434 : check e1127172497434 [[]] .width = true := by decide
def e1127172497526 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172497526 : Closed e1127172497526 ∧ code e1127172497526 = 5525219008630 := by decide
theorem cert_e1127172497526 : check e1127172497526 [[]] .width = true := by decide
def e1127172497770 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172497770 : Closed e1127172497770 ∧ code e1127172497770 = 5525219008874 := by decide
theorem cert_e1127172497770 : check e1127172497770 [[]] .width = true := by decide
def e1127172497818 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172497818 : Closed e1127172497818 ∧ code e1127172497818 = 5525219008922 := by decide
theorem cert_e1127172497818 : check e1127172497818 [[]] .width = true := by decide
def e1127172726810 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172726810 : Closed e1127172726810 ∧ code e1127172726810 = 5525219237914 := by decide
theorem cert_e1127172726810 : check e1127172726810 [[]] .width = true := by decide
def e1127172726902 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172726902 : Closed e1127172726902 ∧ code e1127172726902 = 5525219238006 := by decide
theorem cert_e1127172726902 : check e1127172726902 [[]] .width = true := by decide
def e1127172727146 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172727146 : Closed e1127172727146 ∧ code e1127172727146 = 5525219238250 := by decide
theorem cert_e1127172727146 : check e1127172727146 [[]] .width = true := by decide
def e1127172727194 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172727194 : Closed e1127172727194 ∧ code e1127172727194 = 5525219238298 := by decide
theorem cert_e1127172727194 : check e1127172727194 [[]] .width = true := by decide
def e1127172775962 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172775962 : Closed e1127172775962 ∧ code e1127172775962 = 5525219287066 := by decide
theorem cert_e1127172775962 : check e1127172775962 [[]] .width = true := by decide
def e1127172776054 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172776054 : Closed e1127172776054 ∧ code e1127172776054 = 5525219287158 := by decide
theorem cert_e1127172776054 : check e1127172776054 [[]] .width = true := by decide
def e1127172776298 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172776298 : Closed e1127172776298 ∧ code e1127172776298 = 5525219287402 := by decide
theorem cert_e1127172776298 : check e1127172776298 [[]] .width = true := by decide
def e1127172776346 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172776346 : Closed e1127172776346 ∧ code e1127172776346 = 5525219287450 := by decide
theorem cert_e1127172776346 : check e1127172776346 [[]] .width = true := by decide
def e1127172890650 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172890650 : Closed e1127172890650 ∧ code e1127172890650 = 5525219401754 := by decide
theorem cert_e1127172890650 : check e1127172890650 [[]] .width = true := by decide
def e1127172890742 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172890742 : Closed e1127172890742 ∧ code e1127172890742 = 5525219401846 := by decide
theorem cert_e1127172890742 : check e1127172890742 [[]] .width = true := by decide
def e1127172890986 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172890986 : Closed e1127172890986 ∧ code e1127172890986 = 5525219402090 := by decide
theorem cert_e1127172890986 : check e1127172890986 [[]] .width = true := by decide
def e1127172891034 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172891034 : Closed e1127172891034 ∧ code e1127172891034 = 5525219402138 := by decide
theorem cert_e1127172891034 : check e1127172891034 [[]] .width = true := by decide
def e1127172907034 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127172907034 : Closed e1127172907034 ∧ code e1127172907034 = 5525219418138 := by decide
theorem cert_e1127172907034 : check e1127172907034 [[]] .width = true := by decide
def e1127172907126 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127172907126 : Closed e1127172907126 ∧ code e1127172907126 = 5525219418230 := by decide
theorem cert_e1127172907126 : check e1127172907126 [[]] .width = true := by decide
def e1127172907370 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127172907370 : Closed e1127172907370 ∧ code e1127172907370 = 5525219418474 := by decide
theorem cert_e1127172907370 : check e1127172907370 [[]] .width = true := by decide
def e1127172907418 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127172907418 : Closed e1127172907418 ∧ code e1127172907418 = 5525219418522 := by decide
theorem cert_e1127172907418 : check e1127172907418 [[]] .width = true := by decide
def e1127174037530 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127174037530 : Closed e1127174037530 ∧ code e1127174037530 = 5525220548634 := by decide
theorem cert_e1127174037530 : check e1127174037530 [[]] .width = true := by decide
def e1127174037622 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127174037622 : Closed e1127174037622 ∧ code e1127174037622 = 5525220548726 := by decide
theorem cert_e1127174037622 : check e1127174037622 [[]] .width = true := by decide
def e1127174037866 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127174037866 : Closed e1127174037866 ∧ code e1127174037866 = 5525220548970 := by decide
theorem cert_e1127174037866 : check e1127174037866 [[]] .width = true := by decide
def e1127174037914 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127174037914 : Closed e1127174037914 ∧ code e1127174037914 = 5525220549018 := by decide
theorem cert_e1127174037914 : check e1127174037914 [[]] .width = true := by decide
def e1127174070298 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127174070298 : Closed e1127174070298 ∧ code e1127174070298 = 5525220581402 := by decide
theorem cert_e1127174070298 : check e1127174070298 [[]] .width = true := by decide
def e1127174070390 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127174070390 : Closed e1127174070390 ∧ code e1127174070390 = 5525220581494 := by decide
theorem cert_e1127174070390 : check e1127174070390 [[]] .width = true := by decide
def e1127174070634 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127174070634 : Closed e1127174070634 ∧ code e1127174070634 = 5525220581738 := by decide
theorem cert_e1127174070634 : check e1127174070634 [[]] .width = true := by decide
def e1127174070682 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127174070682 : Closed e1127174070682 ∧ code e1127174070682 = 5525220581786 := by decide
theorem cert_e1127174070682 : check e1127174070682 [[]] .width = true := by decide
def e1127175610394 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127175610394 : Closed e1127175610394 ∧ code e1127175610394 = 5525222121498 := by decide
theorem cert_e1127175610394 : check e1127175610394 [[]] .width = true := by decide
def e1127175610486 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127175610486 : Closed e1127175610486 ∧ code e1127175610486 = 5525222121590 := by decide
theorem cert_e1127175610486 : check e1127175610486 [[]] .width = true := by decide
def e1127175610730 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127175610730 : Closed e1127175610730 ∧ code e1127175610730 = 5525222121834 := by decide
theorem cert_e1127175610730 : check e1127175610730 [[]] .width = true := by decide
def e1127175610778 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127175610778 : Closed e1127175610778 ∧ code e1127175610778 = 5525222121882 := by decide
theorem cert_e1127175610778 : check e1127175610778 [[]] .width = true := by decide
def e1127175659546 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127175659546 : Closed e1127175659546 ∧ code e1127175659546 = 5525222170650 := by decide
theorem cert_e1127175659546 : check e1127175659546 [[]] .width = true := by decide
def e1127175659638 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127175659638 : Closed e1127175659638 ∧ code e1127175659638 = 5525222170742 := by decide
theorem cert_e1127175659638 : check e1127175659638 [[]] .width = true := by decide
def e1127175659882 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127175659882 : Closed e1127175659882 ∧ code e1127175659882 = 5525222170986 := by decide
theorem cert_e1127175659882 : check e1127175659882 [[]] .width = true := by decide
def e1127175659930 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127175659930 : Closed e1127175659930 ∧ code e1127175659930 = 5525222171034 := by decide
theorem cert_e1127175659930 : check e1127175659930 [[]] .width = true := by decide
def e1127176429594 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127176429594 : Closed e1127176429594 ∧ code e1127176429594 = 5525222940698 := by decide
theorem cert_e1127176429594 : check e1127176429594 [[]] .width = true := by decide
def e1127176429686 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127176429686 : Closed e1127176429686 ∧ code e1127176429686 = 5525222940790 := by decide
theorem cert_e1127176429686 : check e1127176429686 [[]] .width = true := by decide
def e1127176429930 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127176429930 : Closed e1127176429930 ∧ code e1127176429930 = 5525222941034 := by decide
theorem cert_e1127176429930 : check e1127176429930 [[]] .width = true := by decide
def e1127176429978 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127176429978 : Closed e1127176429978 ∧ code e1127176429978 = 5525222941082 := by decide
theorem cert_e1127176429978 : check e1127176429978 [[]] .width = true := by decide
def e1127176445978 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1127176445978 : Closed e1127176445978 ∧ code e1127176445978 = 5525222957082 := by decide
theorem cert_e1127176445978 : check e1127176445978 [[]] .width = true := by decide
def e1127176446070 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1127176446070 : Closed e1127176446070 ∧ code e1127176446070 = 5525222957174 := by decide
theorem cert_e1127176446070 : check e1127176446070 [[]] .width = true := by decide
def e1127176446314 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1127176446314 : Closed e1127176446314 ∧ code e1127176446314 = 5525222957418 := by decide
theorem cert_e1127176446314 : check e1127176446314 [[]] .width = true := by decide
def e1127176446362 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1127176446362 : Closed e1127176446362 ∧ code e1127176446362 = 5525222957466 := by decide
theorem cert_e1127176446362 : check e1127176446362 [[]] .width = true := by decide
def e1127261231982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1127261231982 : Closed e1127261231982 ∧ code e1127261231982 = 5525307743086 := by decide
theorem cert_e1127261231982 : check e1127261231982 [[]] .sourceHead = true := by decide
def e1127261231990 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1127261231990 : Closed e1127261231990 ∧ code e1127261231990 = 5525307743094 := by decide
theorem cert_e1127261231990 : check e1127261231990 [[]] .sourceHead = true := by decide
def e1127261232054 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1127261232054 : Closed e1127261232054 ∧ code e1127261232054 = 5525307743158 := by decide
theorem cert_e1127261232054 : check e1127261232054 [[]] .sourceHead = true := by decide
def e1127261232494 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1127261232494 : Closed e1127261232494 ∧ code e1127261232494 = 5525307743598 := by decide
theorem cert_e1127261232494 : check e1127261232494 [[]] .sourceHead = true := by decide
def e1127261232502 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1127261232502 : Closed e1127261232502 ∧ code e1127261232502 = 5525307743606 := by decide
theorem cert_e1127261232502 : check e1127261232502 [[]] .sourceHead = true := by decide
def e1127261232558 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1127261232558 : Closed e1127261232558 ∧ code e1127261232558 = 5525307743662 := by decide
theorem cert_e1127261232558 : check e1127261232558 [[]] .sourceHead = true := by decide
def e1127261232570 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1127261232570 : Closed e1127261232570 ∧ code e1127261232570 = 5525307743674 := by decide
theorem cert_e1127261232570 : check e1127261232570 [[]] .sourceHead = true := by decide
def e1127261232598 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1127261232598 : Closed e1127261232598 ∧ code e1127261232598 = 5525307743702 := by decide
theorem cert_e1127261232598 : check e1127261232598 [[]] .sourceHead = true := by decide
def e1127261232602 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1127261232602 : Closed e1127261232602 ∧ code e1127261232602 = 5525307743706 := by decide
theorem cert_e1127261232602 : check e1127261232602 [[]] .sourceHead = true := by decide
def e1127261232822 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1127261232822 : Closed e1127261232822 ∧ code e1127261232822 = 5525307743926 := by decide
theorem cert_e1127261232822 : check e1127261232822 [[]] .sourceHead = true := by decide
def e1127261232854 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1127261232854 : Closed e1127261232854 ∧ code e1127261232854 = 5525307743958 := by decide
theorem cert_e1127261232854 : check e1127261232854 [[]] .sourceHead = true := by decide
def e1127261232858 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1127261232858 : Closed e1127261232858 ∧ code e1127261232858 = 5525307743962 := by decide
theorem cert_e1127261232858 : check e1127261232858 [[]] .sourceHead = true := by decide
def e1127261235054 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1127261235054 : Closed e1127261235054 ∧ code e1127261235054 = 5525307746158 := by decide
theorem cert_e1127261235054 : check e1127261235054 [[]] .sourceHead = true := by decide
def e1127261235062 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1127261235062 : Closed e1127261235062 ∧ code e1127261235062 = 5525307746166 := by decide
theorem cert_e1127261235062 : check e1127261235062 [[]] .sourceHead = true := by decide
def e1127261235126 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1127261235126 : Closed e1127261235126 ∧ code e1127261235126 = 5525307746230 := by decide
theorem cert_e1127261235126 : check e1127261235126 [[]] .sourceHead = true := by decide
def e1127261236462 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1127261236462 : Closed e1127261236462 ∧ code e1127261236462 = 5525307747566 := by decide
theorem cert_e1127261236462 : check e1127261236462 [[]] .sourceHead = true := by decide
def e1127261236470 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1127261236470 : Closed e1127261236470 ∧ code e1127261236470 = 5525307747574 := by decide
theorem cert_e1127261236470 : check e1127261236470 [[]] .sourceHead = true := by decide
def e1127261236854 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1127261236854 : Closed e1127261236854 ∧ code e1127261236854 = 5525307747958 := by decide
theorem cert_e1127261236854 : check e1127261236854 [[]] .sourceHead = true := by decide
def e1127261238126 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1127261238126 : Closed e1127261238126 ∧ code e1127261238126 = 5525307749230 := by decide
theorem cert_e1127261238126 : check e1127261238126 [[]] .sourceHead = true := by decide
def e1127261238134 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1127261238134 : Closed e1127261238134 ∧ code e1127261238134 = 5525307749238 := by decide
theorem cert_e1127261238134 : check e1127261238134 [[]] .sourceHead = true := by decide
def e1127261238190 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1127261238190 : Closed e1127261238190 ∧ code e1127261238190 = 5525307749294 := by decide
theorem cert_e1127261238190 : check e1127261238190 [[]] .sourceHead = true := by decide
def e1127261238202 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1127261238202 : Closed e1127261238202 ∧ code e1127261238202 = 5525307749306 := by decide
theorem cert_e1127261238202 : check e1127261238202 [[]] .sourceHead = true := by decide
def e1127261238230 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1127261238230 : Closed e1127261238230 ∧ code e1127261238230 = 5525307749334 := by decide
theorem cert_e1127261238230 : check e1127261238230 [[]] .sourceHead = true := by decide
def e1127261238234 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1127261238234 : Closed e1127261238234 ∧ code e1127261238234 = 5525307749338 := by decide
theorem cert_e1127261238234 : check e1127261238234 [[]] .sourceHead = true := by decide
def e1127261238510 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1127261238510 : Closed e1127261238510 ∧ code e1127261238510 = 5525307749614 := by decide
theorem cert_e1127261238510 : check e1127261238510 [[]] .sourceHead = true := by decide
def e1127261238518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1127261238518 : Closed e1127261238518 ∧ code e1127261238518 = 5525307749622 := by decide
theorem cert_e1127261238518 : check e1127261238518 [[]] .sourceHead = true := by decide
def e1127261238894 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1127261238894 : Closed e1127261238894 ∧ code e1127261238894 = 5525307749998 := by decide
theorem cert_e1127261238894 : check e1127261238894 [[]] .sourceHead = true := by decide
def e1127261238906 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1127261238906 : Closed e1127261238906 ∧ code e1127261238906 = 5525307750010 := by decide
theorem cert_e1127261238906 : check e1127261238906 [[]] .sourceHead = true := by decide
def e1127261239094 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1127261239094 : Closed e1127261239094 ∧ code e1127261239094 = 5525307750198 := by decide
theorem cert_e1127261239094 : check e1127261239094 [[]] .sourceHead = true := by decide
def e1127261239098 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1127261239098 : Closed e1127261239098 ∧ code e1127261239098 = 5525307750202 := by decide
theorem cert_e1127261239098 : check e1127261239098 [[]] .sourceHead = true := by decide
def e1127261239734 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1127261239734 : Closed e1127261239734 ∧ code e1127261239734 = 5525307750838 := by decide
theorem cert_e1127261239734 : check e1127261239734 [[]] .sourceHead = true := by decide
def e1127261239766 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1127261239766 : Closed e1127261239766 ∧ code e1127261239766 = 5525307750870 := by decide
theorem cert_e1127261239766 : check e1127261239766 [[]] .sourceHead = true := by decide
def e1127261239770 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1127261239770 : Closed e1127261239770 ∧ code e1127261239770 = 5525307750874 := by decide
theorem cert_e1127261239770 : check e1127261239770 [[]] .sourceHead = true := by decide
def e1127261239926 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1127261239926 : Closed e1127261239926 ∧ code e1127261239926 = 5525307751030 := by decide
theorem cert_e1127261239926 : check e1127261239926 [[]] .sourceHead = true := by decide
def e1127261240118 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1127261240118 : Closed e1127261240118 ∧ code e1127261240118 = 5525307751222 := by decide
theorem cert_e1127261240118 : check e1127261240118 [[]] .sourceHead = true := by decide
def e1127261240122 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1127261240122 : Closed e1127261240122 ∧ code e1127261240122 = 5525307751226 := by decide
theorem cert_e1127261240122 : check e1127261240122 [[]] .sourceHead = true := by decide
def e1127261247342 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1127261247342 : Closed e1127261247342 ∧ code e1127261247342 = 5525307758446 := by decide
theorem cert_e1127261247342 : check e1127261247342 [[]] .sourceHead = true := by decide
def e1127261247350 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1127261247350 : Closed e1127261247350 ∧ code e1127261247350 = 5525307758454 := by decide
theorem cert_e1127261247350 : check e1127261247350 [[]] .sourceHead = true := by decide
def e1127261247414 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1127261247414 : Closed e1127261247414 ∧ code e1127261247414 = 5525307758518 := by decide
theorem cert_e1127261247414 : check e1127261247414 [[]] .sourceHead = true := by decide
def e1127261248750 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1127261248750 : Closed e1127261248750 ∧ code e1127261248750 = 5525307759854 := by decide
theorem cert_e1127261248750 : check e1127261248750 [[]] .sourceHead = true := by decide
def e1127261248758 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1127261248758 : Closed e1127261248758 ∧ code e1127261248758 = 5525307759862 := by decide
theorem cert_e1127261248758 : check e1127261248758 [[]] .sourceHead = true := by decide
def e1127261249142 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1127261249142 : Closed e1127261249142 ∧ code e1127261249142 = 5525307760246 := by decide
theorem cert_e1127261249142 : check e1127261249142 [[]] .sourceHead = true := by decide
def e1127261260654 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1127261260654 : Closed e1127261260654 ∧ code e1127261260654 = 5525307771758 := by decide
theorem cert_e1127261260654 : check e1127261260654 [[]] .sourceHead = true := by decide
def e1127261260662 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1127261260662 : Closed e1127261260662 ∧ code e1127261260662 = 5525307771766 := by decide
theorem cert_e1127261260662 : check e1127261260662 [[]] .sourceHead = true := by decide
def e1127261260718 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1127261260718 : Closed e1127261260718 ∧ code e1127261260718 = 5525307771822 := by decide
theorem cert_e1127261260718 : check e1127261260718 [[]] .sourceHead = true := by decide
def e1127261260730 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1127261260730 : Closed e1127261260730 ∧ code e1127261260730 = 5525307771834 := by decide
theorem cert_e1127261260730 : check e1127261260730 [[]] .sourceHead = true := by decide
def e1127261260758 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1127261260758 : Closed e1127261260758 ∧ code e1127261260758 = 5525307771862 := by decide
theorem cert_e1127261260758 : check e1127261260758 [[]] .sourceHead = true := by decide
def e1127261260762 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1127261260762 : Closed e1127261260762 ∧ code e1127261260762 = 5525307771866 := by decide
theorem cert_e1127261260762 : check e1127261260762 [[]] .sourceHead = true := by decide
def e1127261261038 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1127261261038 : Closed e1127261261038 ∧ code e1127261261038 = 5525307772142 := by decide
theorem cert_e1127261261038 : check e1127261261038 [[]] .sourceHead = true := by decide
def e1127261261046 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1127261261046 : Closed e1127261261046 ∧ code e1127261261046 = 5525307772150 := by decide
theorem cert_e1127261261046 : check e1127261261046 [[]] .sourceHead = true := by decide
def e1127261261422 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1127261261422 : Closed e1127261261422 ∧ code e1127261261422 = 5525307772526 := by decide
theorem cert_e1127261261422 : check e1127261261422 [[]] .sourceHead = true := by decide
def e1127261261434 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1127261261434 : Closed e1127261261434 ∧ code e1127261261434 = 5525307772538 := by decide
theorem cert_e1127261261434 : check e1127261261434 [[]] .sourceHead = true := by decide
def e1127261261622 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1127261261622 : Closed e1127261261622 ∧ code e1127261261622 = 5525307772726 := by decide
theorem cert_e1127261261622 : check e1127261261622 [[]] .sourceHead = true := by decide
def e1127261261626 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1127261261626 : Closed e1127261261626 ∧ code e1127261261626 = 5525307772730 := by decide
theorem cert_e1127261261626 : check e1127261261626 [[]] .sourceHead = true := by decide
def e1127261267382 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1127261267382 : Closed e1127261267382 ∧ code e1127261267382 = 5525307778486 := by decide
theorem cert_e1127261267382 : check e1127261267382 [[]] .sourceHead = true := by decide
def e1127261267414 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1127261267414 : Closed e1127261267414 ∧ code e1127261267414 = 5525307778518 := by decide
theorem cert_e1127261267414 : check e1127261267414 [[]] .sourceHead = true := by decide
def e1127261267418 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1127261267418 : Closed e1127261267418 ∧ code e1127261267418 = 5525307778522 := by decide
theorem cert_e1127261267418 : check e1127261267418 [[]] .sourceHead = true := by decide
def e1127261267574 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1127261267574 : Closed e1127261267574 ∧ code e1127261267574 = 5525307778678 := by decide
theorem cert_e1127261267574 : check e1127261267574 [[]] .sourceHead = true := by decide
def e1127261267766 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1127261267766 : Closed e1127261267766 ∧ code e1127261267766 = 5525307778870 := by decide
theorem cert_e1127261267766 : check e1127261267766 [[]] .sourceHead = true := by decide
def e1127261267770 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1127261267770 : Closed e1127261267770 ∧ code e1127261267770 = 5525307778874 := by decide
theorem cert_e1127261267770 : check e1127261267770 [[]] .sourceHead = true := by decide
def e1127261604718 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1127261604718 : Closed e1127261604718 ∧ code e1127261604718 = 5525308115822 := by decide
theorem cert_e1127261604718 : check e1127261604718 [[]] .sourceHead = true := by decide
def e1127261604726 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1127261604726 : Closed e1127261604726 ∧ code e1127261604726 = 5525308115830 := by decide
theorem cert_e1127261604726 : check e1127261604726 [[]] .sourceHead = true := by decide
def e1127261604782 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1127261604782 : Closed e1127261604782 ∧ code e1127261604782 = 5525308115886 := by decide
theorem cert_e1127261604782 : check e1127261604782 [[]] .sourceHead = true := by decide
def e1127261604794 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1127261604794 : Closed e1127261604794 ∧ code e1127261604794 = 5525308115898 := by decide
theorem cert_e1127261604794 : check e1127261604794 [[]] .sourceHead = true := by decide
def e1127261604822 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1127261604822 : Closed e1127261604822 ∧ code e1127261604822 = 5525308115926 := by decide
theorem cert_e1127261604822 : check e1127261604822 [[]] .sourceHead = true := by decide
def e1127261604826 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1127261604826 : Closed e1127261604826 ∧ code e1127261604826 = 5525308115930 := by decide
theorem cert_e1127261604826 : check e1127261604826 [[]] .sourceHead = true := by decide
def e1127261605102 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1127261605102 : Closed e1127261605102 ∧ code e1127261605102 = 5525308116206 := by decide
theorem cert_e1127261605102 : check e1127261605102 [[]] .sourceHead = true := by decide
def e1127261605110 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1127261605110 : Closed e1127261605110 ∧ code e1127261605110 = 5525308116214 := by decide
theorem cert_e1127261605110 : check e1127261605110 [[]] .sourceHead = true := by decide
def e1127261605486 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1127261605486 : Closed e1127261605486 ∧ code e1127261605486 = 5525308116590 := by decide
theorem cert_e1127261605486 : check e1127261605486 [[]] .sourceHead = true := by decide
def e1127261605498 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1127261605498 : Closed e1127261605498 ∧ code e1127261605498 = 5525308116602 := by decide
theorem cert_e1127261605498 : check e1127261605498 [[]] .sourceHead = true := by decide
def e1127261605686 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1127261605686 : Closed e1127261605686 ∧ code e1127261605686 = 5525308116790 := by decide
theorem cert_e1127261605686 : check e1127261605686 [[]] .sourceHead = true := by decide
def e1127261605690 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1127261605690 : Closed e1127261605690 ∧ code e1127261605690 = 5525308116794 := by decide
theorem cert_e1127261605690 : check e1127261605690 [[]] .sourceHead = true := by decide
def e1129624355014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129624355014 : Closed e1129624355014 ∧ code e1129624355014 = 5527670866118 := by decide
theorem cert_e1129624355014 : check e1129624355014 [[]] .width = true := by decide
def e1129624494106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129624494106 : Closed e1129624494106 ∧ code e1129624494106 = 5527671005210 := by decide
theorem cert_e1129624494106 : check e1129624494106 [[]] .width = true := by decide
def e1129624494198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129624494198 : Closed e1129624494198 ∧ code e1129624494198 = 5527671005302 := by decide
theorem cert_e1129624494198 : check e1129624494198 [[]] .width = true := by decide
def e1129624494442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129624494442 : Closed e1129624494442 ∧ code e1129624494442 = 5527671005546 := by decide
theorem cert_e1129624494442 : check e1129624494442 [[]] .width = true := by decide
def e1129624494490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129624494490 : Closed e1129624494490 ∧ code e1129624494490 = 5527671005594 := by decide
theorem cert_e1129624494490 : check e1129624494490 [[]] .width = true := by decide
def e1129624551622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129624551622 : Closed e1129624551622 ∧ code e1129624551622 = 5527671062726 := by decide
theorem cert_e1129624551622 : check e1129624551622 [[]] .width = true := by decide
def e1129624559642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129624559642 : Closed e1129624559642 ∧ code e1129624559642 = 5527671070746 := by decide
theorem cert_e1129624559642 : check e1129624559642 [[]] .width = true := by decide
def e1129624559734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129624559734 : Closed e1129624559734 ∧ code e1129624559734 = 5527671070838 := by decide
theorem cert_e1129624559734 : check e1129624559734 [[]] .width = true := by decide
def e1129624559978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129624559978 : Closed e1129624559978 ∧ code e1129624559978 = 5527671071082 := by decide
theorem cert_e1129624559978 : check e1129624559978 [[]] .width = true := by decide
def e1129624560026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129624560026 : Closed e1129624560026 ∧ code e1129624560026 = 5527671071130 := by decide
theorem cert_e1129624560026 : check e1129624560026 [[]] .width = true := by decide
def e1129625403590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129625403590 : Closed e1129625403590 ∧ code e1129625403590 = 5527671914694 := by decide
theorem cert_e1129625403590 : check e1129625403590 [[]] .width = true := by decide
def e1129625632966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129625632966 : Closed e1129625632966 ∧ code e1129625632966 = 5527672144070 := by decide
theorem cert_e1129625632966 : check e1129625632966 [[]] .width = true := by decide
def e1129626066970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129626066970 : Closed e1129626066970 ∧ code e1129626066970 = 5527672578074 := by decide
theorem cert_e1129626066970 : check e1129626066970 [[]] .width = true := by decide
def e1129626067062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129626067062 : Closed e1129626067062 ∧ code e1129626067062 = 5527672578166 := by decide
theorem cert_e1129626067062 : check e1129626067062 [[]] .width = true := by decide
def e1129626067306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129626067306 : Closed e1129626067306 ∧ code e1129626067306 = 5527672578410 := by decide
theorem cert_e1129626067306 : check e1129626067306 [[]] .width = true := by decide
def e1129626067354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129626067354 : Closed e1129626067354 ∧ code e1129626067354 = 5527672578458 := by decide
theorem cert_e1129626067354 : check e1129626067354 [[]] .width = true := by decide
def e1129626181658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129626181658 : Closed e1129626181658 ∧ code e1129626181658 = 5527672692762 := by decide
theorem cert_e1129626181658 : check e1129626181658 [[]] .width = true := by decide
def e1129626181750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129626181750 : Closed e1129626181750 ∧ code e1129626181750 = 5527672692854 := by decide
theorem cert_e1129626181750 : check e1129626181750 [[]] .width = true := by decide
def e1129626181994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129626181994 : Closed e1129626181994 ∧ code e1129626181994 = 5527672693098 := by decide
theorem cert_e1129626181994 : check e1129626181994 [[]] .width = true := by decide
def e1129626182042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129626182042 : Closed e1129626182042 ∧ code e1129626182042 = 5527672693146 := by decide
theorem cert_e1129626182042 : check e1129626182042 [[]] .width = true := by decide
def e1129626386630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129626386630 : Closed e1129626386630 ∧ code e1129626386630 = 5527672897734 := by decide
theorem cert_e1129626386630 : check e1129626386630 [[]] .width = true := by decide
def e1129626394650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129626394650 : Closed e1129626394650 ∧ code e1129626394650 = 5527672905754 := by decide
theorem cert_e1129626394650 : check e1129626394650 [[]] .width = true := by decide
def e1129626394742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129626394742 : Closed e1129626394742 ∧ code e1129626394742 = 5527672905846 := by decide
theorem cert_e1129626394742 : check e1129626394742 [[]] .width = true := by decide
def e1129626394986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129626394986 : Closed e1129626394986 ∧ code e1129626394986 = 5527672906090 := by decide
theorem cert_e1129626394986 : check e1129626394986 [[]] .width = true := by decide
def e1129626395034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129626395034 : Closed e1129626395034 ∧ code e1129626395034 = 5527672906138 := by decide
theorem cert_e1129626395034 : check e1129626395034 [[]] .width = true := by decide
def e1129626419398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129626419398 : Closed e1129626419398 ∧ code e1129626419398 = 5527672930502 := by decide
theorem cert_e1129626419398 : check e1129626419398 [[]] .width = true := by decide
def e1129626443802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129626443802 : Closed e1129626443802 ∧ code e1129626443802 = 5527672954906 := by decide
theorem cert_e1129626443802 : check e1129626443802 [[]] .width = true := by decide
def e1129626443894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129626443894 : Closed e1129626443894 ∧ code e1129626443894 = 5527672954998 := by decide
theorem cert_e1129626443894 : check e1129626443894 [[]] .width = true := by decide
def e1129626444138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129626444138 : Closed e1129626444138 ∧ code e1129626444138 = 5527672955242 := by decide
theorem cert_e1129626444138 : check e1129626444138 [[]] .width = true := by decide
def e1129626444186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129626444186 : Closed e1129626444186 ∧ code e1129626444186 = 5527672955290 := by decide
theorem cert_e1129626444186 : check e1129626444186 [[]] .width = true := by decide
def e1129630646470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129630646470 : Closed e1129630646470 ∧ code e1129630646470 = 5527677157574 := by decide
theorem cert_e1129630646470 : check e1129630646470 [[]] .width = true := by decide
def e1129630785562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129630785562 : Closed e1129630785562 ∧ code e1129630785562 = 5527677296666 := by decide
theorem cert_e1129630785562 : check e1129630785562 [[]] .width = true := by decide
end Blc.Floor42
