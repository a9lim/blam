import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196691643834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196691643834 : Closed e1196691643834 ∧ code e1196691643834 = 5594738154938 := by decide
theorem cert_e1196691643834 : check e1196691643834 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196691643862 : Closed e1196691643862 ∧ code e1196691643862 = 5594738154966 := by decide
theorem cert_e1196691643862 : check e1196691643862 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196691643866 : Closed e1196691643866 ∧ code e1196691643866 = 5594738154970 := by decide
theorem cert_e1196691643866 : check e1196691643866 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691644086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1196691644086 : Closed e1196691644086 ∧ code e1196691644086 = 5594738155190 := by decide
theorem cert_e1196691644086 : check e1196691644086 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691644118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1196691644118 : Closed e1196691644118 ∧ code e1196691644118 = 5594738155222 := by decide
theorem cert_e1196691644118 : check e1196691644118 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691644122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1196691644122 : Closed e1196691644122 ∧ code e1196691644122 = 5594738155226 := by decide
theorem cert_e1196691644122 : check e1196691644122 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691646318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1196691646318 : Closed e1196691646318 ∧ code e1196691646318 = 5594738157422 := by decide
theorem cert_e1196691646318 : check e1196691646318 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691646326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1196691646326 : Closed e1196691646326 ∧ code e1196691646326 = 5594738157430 := by decide
theorem cert_e1196691646326 : check e1196691646326 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691646390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1196691646390 : Closed e1196691646390 ∧ code e1196691646390 = 5594738157494 := by decide
theorem cert_e1196691646390 : check e1196691646390 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691647726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196691647726 : Closed e1196691647726 ∧ code e1196691647726 = 5594738158830 := by decide
theorem cert_e1196691647726 : check e1196691647726 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691647734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196691647734 : Closed e1196691647734 ∧ code e1196691647734 = 5594738158838 := by decide
theorem cert_e1196691647734 : check e1196691647734 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691648118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196691648118 : Closed e1196691648118 ∧ code e1196691648118 = 5594738159222 := by decide
theorem cert_e1196691648118 : check e1196691648118 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196691649390 : Closed e1196691649390 ∧ code e1196691649390 = 5594738160494 := by decide
theorem cert_e1196691649390 : check e1196691649390 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196691649398 : Closed e1196691649398 ∧ code e1196691649398 = 5594738160502 := by decide
theorem cert_e1196691649398 : check e1196691649398 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196691649454 : Closed e1196691649454 ∧ code e1196691649454 = 5594738160558 := by decide
theorem cert_e1196691649454 : check e1196691649454 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196691649466 : Closed e1196691649466 ∧ code e1196691649466 = 5594738160570 := by decide
theorem cert_e1196691649466 : check e1196691649466 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196691649494 : Closed e1196691649494 ∧ code e1196691649494 = 5594738160598 := by decide
theorem cert_e1196691649494 : check e1196691649494 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196691649498 : Closed e1196691649498 ∧ code e1196691649498 = 5594738160602 := by decide
theorem cert_e1196691649498 : check e1196691649498 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196691649774 : Closed e1196691649774 ∧ code e1196691649774 = 5594738160878 := by decide
theorem cert_e1196691649774 : check e1196691649774 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691649782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196691649782 : Closed e1196691649782 ∧ code e1196691649782 = 5594738160886 := by decide
theorem cert_e1196691649782 : check e1196691649782 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691650158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196691650158 : Closed e1196691650158 ∧ code e1196691650158 = 5594738161262 := by decide
theorem cert_e1196691650158 : check e1196691650158 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691650170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196691650170 : Closed e1196691650170 ∧ code e1196691650170 = 5594738161274 := by decide
theorem cert_e1196691650170 : check e1196691650170 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691650358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196691650358 : Closed e1196691650358 ∧ code e1196691650358 = 5594738161462 := by decide
theorem cert_e1196691650358 : check e1196691650358 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691650362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196691650362 : Closed e1196691650362 ∧ code e1196691650362 = 5594738161466 := by decide
theorem cert_e1196691650362 : check e1196691650362 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691650998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1196691650998 : Closed e1196691650998 ∧ code e1196691650998 = 5594738162102 := by decide
theorem cert_e1196691650998 : check e1196691650998 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691651030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1196691651030 : Closed e1196691651030 ∧ code e1196691651030 = 5594738162134 := by decide
theorem cert_e1196691651030 : check e1196691651030 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691651034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1196691651034 : Closed e1196691651034 ∧ code e1196691651034 = 5594738162138 := by decide
theorem cert_e1196691651034 : check e1196691651034 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691651190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196691651190 : Closed e1196691651190 ∧ code e1196691651190 = 5594738162294 := by decide
theorem cert_e1196691651190 : check e1196691651190 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691651382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196691651382 : Closed e1196691651382 ∧ code e1196691651382 = 5594738162486 := by decide
theorem cert_e1196691651382 : check e1196691651382 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691651386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196691651386 : Closed e1196691651386 ∧ code e1196691651386 = 5594738162490 := by decide
theorem cert_e1196691651386 : check e1196691651386 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691658606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1196691658606 : Closed e1196691658606 ∧ code e1196691658606 = 5594738169710 := by decide
theorem cert_e1196691658606 : check e1196691658606 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691658614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1196691658614 : Closed e1196691658614 ∧ code e1196691658614 = 5594738169718 := by decide
theorem cert_e1196691658614 : check e1196691658614 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691658678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1196691658678 : Closed e1196691658678 ∧ code e1196691658678 = 5594738169782 := by decide
theorem cert_e1196691658678 : check e1196691658678 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691660014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196691660014 : Closed e1196691660014 ∧ code e1196691660014 = 5594738171118 := by decide
theorem cert_e1196691660014 : check e1196691660014 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691660022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196691660022 : Closed e1196691660022 ∧ code e1196691660022 = 5594738171126 := by decide
theorem cert_e1196691660022 : check e1196691660022 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691660406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196691660406 : Closed e1196691660406 ∧ code e1196691660406 = 5594738171510 := by decide
theorem cert_e1196691660406 : check e1196691660406 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691671918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196691671918 : Closed e1196691671918 ∧ code e1196691671918 = 5594738183022 := by decide
theorem cert_e1196691671918 : check e1196691671918 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691671926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196691671926 : Closed e1196691671926 ∧ code e1196691671926 = 5594738183030 := by decide
theorem cert_e1196691671926 : check e1196691671926 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691671982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196691671982 : Closed e1196691671982 ∧ code e1196691671982 = 5594738183086 := by decide
theorem cert_e1196691671982 : check e1196691671982 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691671994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196691671994 : Closed e1196691671994 ∧ code e1196691671994 = 5594738183098 := by decide
theorem cert_e1196691671994 : check e1196691671994 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196691672022 : Closed e1196691672022 ∧ code e1196691672022 = 5594738183126 := by decide
theorem cert_e1196691672022 : check e1196691672022 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196691672026 : Closed e1196691672026 ∧ code e1196691672026 = 5594738183130 := by decide
theorem cert_e1196691672026 : check e1196691672026 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196691672302 : Closed e1196691672302 ∧ code e1196691672302 = 5594738183406 := by decide
theorem cert_e1196691672302 : check e1196691672302 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196691672310 : Closed e1196691672310 ∧ code e1196691672310 = 5594738183414 := by decide
theorem cert_e1196691672310 : check e1196691672310 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196691672686 : Closed e1196691672686 ∧ code e1196691672686 = 5594738183790 := by decide
theorem cert_e1196691672686 : check e1196691672686 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196691672698 : Closed e1196691672698 ∧ code e1196691672698 = 5594738183802 := by decide
theorem cert_e1196691672698 : check e1196691672698 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196691672886 : Closed e1196691672886 ∧ code e1196691672886 = 5594738183990 := by decide
theorem cert_e1196691672886 : check e1196691672886 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691672890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196691672890 : Closed e1196691672890 ∧ code e1196691672890 = 5594738183994 := by decide
theorem cert_e1196691672890 : check e1196691672890 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691678646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1196691678646 : Closed e1196691678646 ∧ code e1196691678646 = 5594738189750 := by decide
theorem cert_e1196691678646 : check e1196691678646 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691678678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1196691678678 : Closed e1196691678678 ∧ code e1196691678678 = 5594738189782 := by decide
theorem cert_e1196691678678 : check e1196691678678 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691678682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1196691678682 : Closed e1196691678682 ∧ code e1196691678682 = 5594738189786 := by decide
theorem cert_e1196691678682 : check e1196691678682 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691678838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196691678838 : Closed e1196691678838 ∧ code e1196691678838 = 5594738189942 := by decide
theorem cert_e1196691678838 : check e1196691678838 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691679030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196691679030 : Closed e1196691679030 ∧ code e1196691679030 = 5594738190134 := by decide
theorem cert_e1196691679030 : check e1196691679030 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691679034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196691679034 : Closed e1196691679034 ∧ code e1196691679034 = 5594738190138 := by decide
theorem cert_e1196691679034 : check e1196691679034 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692015982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196692015982 : Closed e1196692015982 ∧ code e1196692015982 = 5594738527086 := by decide
theorem cert_e1196692015982 : check e1196692015982 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692015990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196692015990 : Closed e1196692015990 ∧ code e1196692015990 = 5594738527094 := by decide
theorem cert_e1196692015990 : check e1196692015990 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196692016046 : Closed e1196692016046 ∧ code e1196692016046 = 5594738527150 := by decide
theorem cert_e1196692016046 : check e1196692016046 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196692016058 : Closed e1196692016058 ∧ code e1196692016058 = 5594738527162 := by decide
theorem cert_e1196692016058 : check e1196692016058 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196692016086 : Closed e1196692016086 ∧ code e1196692016086 = 5594738527190 := by decide
theorem cert_e1196692016086 : check e1196692016086 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196692016090 : Closed e1196692016090 ∧ code e1196692016090 = 5594738527194 := by decide
theorem cert_e1196692016090 : check e1196692016090 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196692016366 : Closed e1196692016366 ∧ code e1196692016366 = 5594738527470 := by decide
theorem cert_e1196692016366 : check e1196692016366 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196692016374 : Closed e1196692016374 ∧ code e1196692016374 = 5594738527478 := by decide
theorem cert_e1196692016374 : check e1196692016374 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196692016750 : Closed e1196692016750 ∧ code e1196692016750 = 5594738527854 := by decide
theorem cert_e1196692016750 : check e1196692016750 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196692016762 : Closed e1196692016762 ∧ code e1196692016762 = 5594738527866 := by decide
theorem cert_e1196692016762 : check e1196692016762 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196692016950 : Closed e1196692016950 ∧ code e1196692016950 = 5594738528054 := by decide
theorem cert_e1196692016950 : check e1196692016950 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692016954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196692016954 : Closed e1196692016954 ∧ code e1196692016954 = 5594738528058 := by decide
theorem cert_e1196692016954 : check e1196692016954 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196692614622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1196692614622 : Closed e1196692614622 ∧ code e1196692614622 = 5594739125726 := by decide
theorem cert_e1196692614622 : check e1196692614622 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1196692614638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1196692614638 : Closed e1196692614638 ∧ code e1196692614638 = 5594739125742 := by decide
theorem cert_e1196692614638 : check e1196692614638 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1196692615006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1196692615006 : Closed e1196692615006 ∧ code e1196692615006 = 5594739126110 := by decide
theorem cert_e1196692615006 : check e1196692615006 [[],[.left],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1196692615034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1196692615034 : Closed e1196692615034 ∧ code e1196692615034 = 5594739126138 := by decide
theorem cert_e1196692615034 : check e1196692615034 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1196692615086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1196692615086 : Closed e1196692615086 ∧ code e1196692615086 = 5594739126190 := by decide
theorem cert_e1196692615086 : check e1196692615086 [[],[.left],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1196692615098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1196692615098 : Closed e1196692615098 ∧ code e1196692615098 = 5594739126202 := by decide
theorem cert_e1196692615098 : check e1196692615098 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1196692616158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1196692616158 : Closed e1196692616158 ∧ code e1196692616158 = 5594739127262 := by decide
theorem cert_e1196692616158 : check e1196692616158 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1196692616174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1196692616174 : Closed e1196692616174 ∧ code e1196692616174 = 5594739127278 := by decide
theorem cert_e1196692616174 : check e1196692616174 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1196692618462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196692618462 : Closed e1196692618462 ∧ code e1196692618462 = 5594739129566 := by decide
theorem cert_e1196692618462 : check e1196692618462 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e1196692618490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196692618490 : Closed e1196692618490 ∧ code e1196692618490 = 5594739129594 := by decide
theorem cert_e1196692618490 : check e1196692618490 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e1196692618862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196692618862 : Closed e1196692618862 ∧ code e1196692618862 = 5594739129966 := by decide
theorem cert_e1196692618862 : check e1196692618862 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e1196692618874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196692618874 : Closed e1196692618874 ∧ code e1196692618874 = 5594739129978 := by decide
theorem cert_e1196692618874 : check e1196692618874 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e1196692647278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196692647278 : Closed e1196692647278 ∧ code e1196692647278 = 5594739158382 := by decide
private def t_e1196692647278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e1196692647278 : ¬ IsSelfInterpreter e1196692647278 :=
  wSource (t := t_e1196692647278) (replay_sound (ps := []) (t := e1196692647278) (by decide)) (by decide)
def e1196692647286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196692647286 : Closed e1196692647286 ∧ code e1196692647286 = 5594739158390 := by decide
private def t_e1196692647286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e1196692647286 : ¬ IsSelfInterpreter e1196692647286 :=
  wSource (t := t_e1196692647286) (replay_sound (ps := []) (t := e1196692647286) (by decide)) (by decide)
def e1196692647342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196692647342 : Closed e1196692647342 ∧ code e1196692647342 = 5594739158446 := by decide
theorem cert_e1196692647342 : check e1196692647342 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1196692647354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196692647354 : Closed e1196692647354 ∧ code e1196692647354 = 5594739158458 := by decide
theorem cert_e1196692647354 : check e1196692647354 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1196692647382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196692647382 : Closed e1196692647382 ∧ code e1196692647382 = 5594739158486 := by decide
private def t_e1196692647382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1196692647382 : ¬ IsSelfInterpreter e1196692647382 :=
  wSource (t := t_e1196692647382) (replay_sound (ps := []) (t := e1196692647382) (by decide)) (by decide)
def e1196692647386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196692647386 : Closed e1196692647386 ∧ code e1196692647386 = 5594739158490 := by decide
private def t_e1196692647386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1196692647386 : ¬ IsSelfInterpreter e1196692647386 :=
  wSource (t := t_e1196692647386) (replay_sound (ps := []) (t := e1196692647386) (by decide)) (by decide)
def e1196692647598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1196692647598 : Closed e1196692647598 ∧ code e1196692647598 = 5594739158702 := by decide
theorem cert_e1196692647598 : check e1196692647598 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692647610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1196692647610 : Closed e1196692647610 ∧ code e1196692647610 = 5594739158714 := by decide
theorem cert_e1196692647610 : check e1196692647610 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692647658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1196692647658 : Closed e1196692647658 ∧ code e1196692647658 = 5594739158762 := by decide
theorem cert_e1196692647658 : check e1196692647658 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1196692647766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1196692647766 : Closed e1196692647766 ∧ code e1196692647766 = 5594739158870 := by decide
private def t_e1196692647766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1196692647766 : ¬ IsSelfInterpreter e1196692647766 :=
  wSource (t := t_e1196692647766) (replay_sound (ps := []) (t := e1196692647766) (by decide)) (by decide)
def e1196692647770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1196692647770 : Closed e1196692647770 ∧ code e1196692647770 = 5594739158874 := by decide
private def t_e1196692647770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1196692647770 : ¬ IsSelfInterpreter e1196692647770 :=
  wSource (t := t_e1196692647770) (replay_sound (ps := []) (t := e1196692647770) (by decide)) (by decide)
def e1196692647786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1196692647786 : Closed e1196692647786 ∧ code e1196692647786 = 5594739158890 := by decide
def e1196692648814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196692648814 : Closed e1196692648814 ∧ code e1196692648814 = 5594739159918 := by decide
theorem cert_e1196692648814 : check e1196692648814 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1196692648822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196692648822 : Closed e1196692648822 ∧ code e1196692648822 = 5594739159926 := by decide
private def t_e1196692648822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e1196692648822 : ¬ IsSelfInterpreter e1196692648822 :=
  wSource (t := t_e1196692648822) (replay_sound (ps := []) (t := e1196692648822) (by decide)) (by decide)
def e1196692648878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196692648878 : Closed e1196692648878 ∧ code e1196692648878 = 5594739159982 := by decide
def e1196692648890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196692648890 : Closed e1196692648890 ∧ code e1196692648890 = 5594739159994 := by decide
theorem cert_e1196692648890 : check e1196692648890 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196692648918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196692648918 : Closed e1196692648918 ∧ code e1196692648918 = 5594739160022 := by decide
private def t_e1196692648918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e1196692648918 : ¬ IsSelfInterpreter e1196692648918 :=
  wSource (t := t_e1196692648918) (replay_sound (ps := []) (t := e1196692648918) (by decide)) (by decide)
def e1196692648922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196692648922 : Closed e1196692648922 ∧ code e1196692648922 = 5594739160026 := by decide
theorem cert_e1196692648922 : check e1196692648922 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1196692649198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196692649198 : Closed e1196692649198 ∧ code e1196692649198 = 5594739160302 := by decide
private def t_e1196692649198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e1196692649198 : ¬ IsSelfInterpreter e1196692649198 :=
  wSource (t := t_e1196692649198) (replay_sound (ps := []) (t := e1196692649198) (by decide)) (by decide)
def e1196692649206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196692649206 : Closed e1196692649206 ∧ code e1196692649206 = 5594739160310 := by decide
private def t_e1196692649206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e1196692649206 : ¬ IsSelfInterpreter e1196692649206 :=
  wSource (t := t_e1196692649206) (replay_sound (ps := []) (t := e1196692649206) (by decide)) (by decide)
def e1196692649582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196692649582 : Closed e1196692649582 ∧ code e1196692649582 = 5594739160686 := by decide
theorem cert_e1196692649582 : check e1196692649582 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692649594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196692649594 : Closed e1196692649594 ∧ code e1196692649594 = 5594739160698 := by decide
theorem cert_e1196692649594 : check e1196692649594 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692649782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196692649782 : Closed e1196692649782 ∧ code e1196692649782 = 5594739160886 := by decide
private def t_e1196692649782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1196692649782 : ¬ IsSelfInterpreter e1196692649782 :=
  wSource (t := t_e1196692649782) (replay_sound (ps := []) (t := e1196692649782) (by decide)) (by decide)
def e1196692649786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196692649786 : Closed e1196692649786 ∧ code e1196692649786 = 5594739160890 := by decide
private def t_e1196692649786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1196692649786 : ¬ IsSelfInterpreter e1196692649786 :=
  wSource (t := t_e1196692649786) (replay_sound (ps := []) (t := e1196692649786) (by decide)) (by decide)
def e1196692650414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1196692650414 : Closed e1196692650414 ∧ code e1196692650414 = 5594739161518 := by decide
theorem cert_e1196692650414 : check e1196692650414 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1196692650426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1196692650426 : Closed e1196692650426 ∧ code e1196692650426 = 5594739161530 := by decide
theorem cert_e1196692650426 : check e1196692650426 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1196692650474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1196692650474 : Closed e1196692650474 ∧ code e1196692650474 = 5594739161578 := by decide
theorem cert_e1196692650474 : check e1196692650474 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692650606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196692650606 : Closed e1196692650606 ∧ code e1196692650606 = 5594739161710 := by decide
theorem cert_e1196692650606 : check e1196692650606 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692650618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196692650618 : Closed e1196692650618 ∧ code e1196692650618 = 5594739161722 := by decide
theorem cert_e1196692650618 : check e1196692650618 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692650906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196692650906 : Closed e1196692650906 ∧ code e1196692650906 = 5594739162010 := by decide
theorem cert_e1196692650906 : check e1196692650906 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1196692651222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1196692651222 : Closed e1196692651222 ∧ code e1196692651222 = 5594739162326 := by decide
private def t_e1196692651222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1196692651222 : ¬ IsSelfInterpreter e1196692651222 :=
  wSource (t := t_e1196692651222) (replay_sound (ps := []) (t := e1196692651222) (by decide)) (by decide)
def e1196692651226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1196692651226 : Closed e1196692651226 ∧ code e1196692651226 = 5594739162330 := by decide
theorem cert_e1196692651226 : check e1196692651226 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1196692651242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1196692651242 : Closed e1196692651242 ∧ code e1196692651242 = 5594739162346 := by decide
def e1196692651318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196692651318 : Closed e1196692651318 ∧ code e1196692651318 = 5594739162422 := by decide
private def t_e1196692651318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1196692651318 : ¬ IsSelfInterpreter e1196692651318 :=
  wSource (t := t_e1196692651318) (replay_sound (ps := []) (t := e1196692651318) (by decide)) (by decide)
def e1196692651322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196692651322 : Closed e1196692651322 ∧ code e1196692651322 = 5594739162426 := by decide
private def t_e1196692651322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1196692651322 : ¬ IsSelfInterpreter e1196692651322 :=
  wSource (t := t_e1196692651322) (replay_sound (ps := []) (t := e1196692651322) (by decide)) (by decide)
def e1196692651418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196692651418 : Closed e1196692651418 ∧ code e1196692651418 = 5594739162522 := by decide
def e1196692653022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1196692653022 : Closed e1196692653022 ∧ code e1196692653022 = 5594739164126 := by decide
theorem cert_e1196692653022 : check e1196692653022 [[],[.left],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1196692653038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1196692653038 : Closed e1196692653038 ∧ code e1196692653038 = 5594739164142 := by decide
theorem cert_e1196692653038 : check e1196692653038 [[],[.left],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1196692654958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196692654958 : Closed e1196692654958 ∧ code e1196692654958 = 5594739166062 := by decide
theorem cert_e1196692654958 : check e1196692654958 [[],[.left],[],[],[.under],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196692654966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196692654966 : Closed e1196692654966 ∧ code e1196692654966 = 5594739166070 := by decide
private def t_e1196692654966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1196692654966 : ¬ IsSelfInterpreter e1196692654966 :=
  wSource (t := t_e1196692654966) (replay_sound (ps := []) (t := e1196692654966) (by decide)) (by decide)
def e1196692655022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196692655022 : Closed e1196692655022 ∧ code e1196692655022 = 5594739166126 := by decide
theorem cert_e1196692655022 : check e1196692655022 [[],[.left],[],[],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692655034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196692655034 : Closed e1196692655034 ∧ code e1196692655034 = 5594739166138 := by decide
def e1196692655062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196692655062 : Closed e1196692655062 ∧ code e1196692655062 = 5594739166166 := by decide
private def t_e1196692655062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1196692655062 : ¬ IsSelfInterpreter e1196692655062 :=
  wSource (t := t_e1196692655062) (replay_sound (ps := []) (t := e1196692655062) (by decide)) (by decide)
def e1196692655066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196692655066 : Closed e1196692655066 ∧ code e1196692655066 = 5594739166170 := by decide
def e1196692655342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196692655342 : Closed e1196692655342 ∧ code e1196692655342 = 5594739166446 := by decide
def e1196692655350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196692655350 : Closed e1196692655350 ∧ code e1196692655350 = 5594739166454 := by decide
def e1196692655726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196692655726 : Closed e1196692655726 ∧ code e1196692655726 = 5594739166830 := by decide
theorem cert_e1196692655726 : check e1196692655726 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196692655738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196692655738 : Closed e1196692655738 ∧ code e1196692655738 = 5594739166842 := by decide
def e1196692655926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196692655926 : Closed e1196692655926 ∧ code e1196692655926 = 5594739167030 := by decide
theorem cert_e1196692655926 : check e1196692655926 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196692655930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196692655930 : Closed e1196692655930 ∧ code e1196692655930 = 5594739167034 := by decide
def e1196692660702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1196692660702 : Closed e1196692660702 ∧ code e1196692660702 = 5594739171806 := by decide
theorem cert_e1196692660702 : check e1196692660702 [[],[.left],[],[],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1196692660726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1196692660726 : Closed e1196692660726 ∧ code e1196692660726 = 5594739171830 := by decide
theorem cert_e1196692660726 : check e1196692660726 [[],[.left],[],[],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1196692661678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1196692661678 : Closed e1196692661678 ∧ code e1196692661678 = 5594739172782 := by decide
theorem cert_e1196692661678 : check e1196692661678 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1196692661690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1196692661690 : Closed e1196692661690 ∧ code e1196692661690 = 5594739172794 := by decide
theorem cert_e1196692661690 : check e1196692661690 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1196692661738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1196692661738 : Closed e1196692661738 ∧ code e1196692661738 = 5594739172842 := by decide
def e1196692661870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196692661870 : Closed e1196692661870 ∧ code e1196692661870 = 5594739172974 := by decide
def e1196692661882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196692661882 : Closed e1196692661882 ∧ code e1196692661882 = 5594739172986 := by decide
def e1196692662170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196692662170 : Closed e1196692662170 ∧ code e1196692662170 = 5594739173274 := by decide
def e1196692664558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1196692664558 : Closed e1196692664558 ∧ code e1196692664558 = 5594739175662 := by decide
theorem cert_e1196692664558 : check e1196692664558 [[],[.left],[],[],[.under],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1196692664566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1196692664566 : Closed e1196692664566 ∧ code e1196692664566 = 5594739175670 := by decide
theorem cert_e1196692664566 : check e1196692664566 [[],[.left],[],[],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1196692665046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1196692665046 : Closed e1196692665046 ∧ code e1196692665046 = 5594739176150 := by decide
private def t_e1196692665046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1196692665046 : ¬ IsSelfInterpreter e1196692665046 :=
  wSource (t := t_e1196692665046) (replay_sound (ps := []) (t := e1196692665046) (by decide)) (by decide)
def e1196692665050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1196692665050 : Closed e1196692665050 ∧ code e1196692665050 = 5594739176154 := by decide
theorem cert_e1196692665050 : check e1196692665050 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1196692665066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1196692665066 : Closed e1196692665066 ∧ code e1196692665066 = 5594739176170 := by decide
def e1196692665142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196692665142 : Closed e1196692665142 ∧ code e1196692665142 = 5594739176246 := by decide
def e1196692665146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196692665146 : Closed e1196692665146 ∧ code e1196692665146 = 5594739176250 := by decide
def e1196692665242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196692665242 : Closed e1196692665242 ∧ code e1196692665242 = 5594739176346 := by decide
def e1196692802414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196692802414 : Closed e1196692802414 ∧ code e1196692802414 = 5594739313518 := by decide
theorem cert_e1196692802414 : check e1196692802414 [[],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692802422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196692802422 : Closed e1196692802422 ∧ code e1196692802422 = 5594739313526 := by decide
theorem cert_e1196692802422 : check e1196692802422 [[],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692802478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196692802478 : Closed e1196692802478 ∧ code e1196692802478 = 5594739313582 := by decide
theorem cert_e1196692802478 : check e1196692802478 [[],[.left],[],[],[.under,.left],[.under],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196692802490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196692802490 : Closed e1196692802490 ∧ code e1196692802490 = 5594739313594 := by decide
def e1196692802518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196692802518 : Closed e1196692802518 ∧ code e1196692802518 = 5594739313622 := by decide
theorem cert_e1196692802518 : check e1196692802518 [[],[.left],[],[],[.under,.left],[.under],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196692802522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196692802522 : Closed e1196692802522 ∧ code e1196692802522 = 5594739313626 := by decide
def e1196692802798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196692802798 : Closed e1196692802798 ∧ code e1196692802798 = 5594739313902 := by decide
theorem cert_e1196692802798 : check e1196692802798 [[],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692802806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196692802806 : Closed e1196692802806 ∧ code e1196692802806 = 5594739313910 := by decide
theorem cert_e1196692802806 : check e1196692802806 [[],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1196692803182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196692803182 : Closed e1196692803182 ∧ code e1196692803182 = 5594739314286 := by decide
theorem cert_e1196692803182 : check e1196692803182 [[],[.left],[],[],[.under,.left],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1196692803194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196692803194 : Closed e1196692803194 ∧ code e1196692803194 = 5594739314298 := by decide
def e1196692803382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196692803382 : Closed e1196692803382 ∧ code e1196692803382 = 5594739314486 := by decide
theorem cert_e1196692803382 : check e1196692803382 [[],[.left],[],[],[.under,.left],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1196692803386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196692803386 : Closed e1196692803386 ∧ code e1196692803386 = 5594739314490 := by decide
def e1196710452702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1196710452702 : Closed e1196710452702 ∧ code e1196710452702 = 5594756963806 := by decide
theorem cert_e1196710452702 : check e1196710452702 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196710452718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1196710452718 : Closed e1196710452718 ∧ code e1196710452718 = 5594756963822 := by decide
theorem cert_e1196710452718 : check e1196710452718 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196710452958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1196710452958 : Closed e1196710452958 ∧ code e1196710452958 = 5594756964062 := by decide
theorem cert_e1196710452958 : check e1196710452958 [[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196710452982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1196710452982 : Closed e1196710452982 ∧ code e1196710452982 = 5594756964086 := by decide
private def t_e1196710452982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem cert_e1196710452982 : ¬ IsSelfInterpreter e1196710452982 :=
  wSource (t := t_e1196710452982) (replay_sound (ps := []) (t := e1196710452982) (by decide)) (by decide)
end Blc.Floor42
