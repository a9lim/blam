import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210849590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210849590 : Closed e1211210849590 ∧ code e1211210849590 = 5609257360694 := by decide
theorem cert_e1211210849590 : check e1211210849590 [[],[]] .chain = true := by decide
def e1211210849594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210849594 : Closed e1211210849594 ∧ code e1211210849594 = 5609257360698 := by decide
theorem cert_e1211210849594 : check e1211210849594 [[],[]] .chain = true := by decide
def e1211210849666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210849666 : Closed e1211210849666 ∧ code e1211210849666 = 5609257360770 := by decide
theorem cert_e1211210849666 : check e1211210849666 [[],[]] .chain = true := by decide
def e1211210849678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211210849678 : Closed e1211210849678 ∧ code e1211210849678 = 5609257360782 := by decide
theorem cert_e1211210849678 : check e1211210849678 [[],[]] .chain = true := by decide
def e1211210849690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210849690 : Closed e1211210849690 ∧ code e1211210849690 = 5609257360794 := by decide
theorem cert_e1211210849690 : check e1211210849690 [[],[]] .chain = true := by decide
def e1211210849734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211210849734 : Closed e1211210849734 ∧ code e1211210849734 = 5609257360838 := by decide
theorem cert_e1211210849734 : check e1211210849734 [[],[]] .sourceHead = true := by decide
def e1211210850478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e1211210850478 : Closed e1211210850478 ∧ code e1211210850478 = 5609257361582 := by decide
theorem cert_e1211210850478 : check e1211210850478 [[],[]] .chain = true := by decide
def e1211210850490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e1211210850490 : Closed e1211210850490 ∧ code e1211210850490 = 5609257361594 := by decide
theorem cert_e1211210850490 : check e1211210850490 [[],[]] .chain = true := by decide
def e1211210851182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211210851182 : Closed e1211210851182 ∧ code e1211210851182 = 5609257362286 := by decide
theorem cert_e1211210851182 : check e1211210851182 [[],[]] .chain = true := by decide
def e1211210851190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211210851190 : Closed e1211210851190 ∧ code e1211210851190 = 5609257362294 := by decide
theorem cert_e1211210851190 : check e1211210851190 [[],[]] .chain = true := by decide
def e1211210851246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211210851246 : Closed e1211210851246 ∧ code e1211210851246 = 5609257362350 := by decide
theorem cert_e1211210851246 : check e1211210851246 [[],[]] .chain = true := by decide
def e1211210851258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211210851258 : Closed e1211210851258 ∧ code e1211210851258 = 5609257362362 := by decide
theorem cert_e1211210851258 : check e1211210851258 [[],[]] .chain = true := by decide
def e1211210851286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211210851286 : Closed e1211210851286 ∧ code e1211210851286 = 5609257362390 := by decide
theorem cert_e1211210851286 : check e1211210851286 [[],[]] .chain = true := by decide
def e1211210851290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211210851290 : Closed e1211210851290 ∧ code e1211210851290 = 5609257362394 := by decide
theorem cert_e1211210851290 : check e1211210851290 [[],[]] .chain = true := by decide
def e1211210852014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211210852014 : Closed e1211210852014 ∧ code e1211210852014 = 5609257363118 := by decide
theorem cert_e1211210852014 : check e1211210852014 [[],[]] .chain = true := by decide
def e1211210852026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211210852026 : Closed e1211210852026 ∧ code e1211210852026 = 5609257363130 := by decide
theorem cert_e1211210852026 : check e1211210852026 [[],[]] .chain = true := by decide
def e1211210852074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211210852074 : Closed e1211210852074 ∧ code e1211210852074 = 5609257363178 := by decide
theorem cert_e1211210852074 : check e1211210852074 [[],[]] .chain = true := by decide
def e1211210852266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211210852266 : Closed e1211210852266 ∧ code e1211210852266 = 5609257363370 := by decide
theorem cert_e1211210852266 : check e1211210852266 [[],[]] .chain = true := by decide
def e1211210852398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211210852398 : Closed e1211210852398 ∧ code e1211210852398 = 5609257363502 := by decide
theorem cert_e1211210852398 : check e1211210852398 [[],[]] .chain = true := by decide
def e1211210852590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211210852590 : Closed e1211210852590 ∧ code e1211210852590 = 5609257363694 := by decide
theorem cert_e1211210852590 : check e1211210852590 [[],[]] .chain = true := by decide
def e1211210852598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211210852598 : Closed e1211210852598 ∧ code e1211210852598 = 5609257363702 := by decide
theorem cert_e1211210852598 : check e1211210852598 [[],[]] .chain = true := by decide
def e1211210852782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211210852782 : Closed e1211210852782 ∧ code e1211210852782 = 5609257363886 := by decide
theorem cert_e1211210852782 : check e1211210852782 [[],[]] .chain = true := by decide
def e1211210852794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211210852794 : Closed e1211210852794 ∧ code e1211210852794 = 5609257363898 := by decide
theorem cert_e1211210852794 : check e1211210852794 [[],[]] .chain = true := by decide
def e1211210852842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211210852842 : Closed e1211210852842 ∧ code e1211210852842 = 5609257363946 := by decide
theorem cert_e1211210852842 : check e1211210852842 [[],[]] .chain = true := by decide
def e1211210852974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210852974 : Closed e1211210852974 ∧ code e1211210852974 = 5609257364078 := by decide
theorem cert_e1211210852974 : check e1211210852974 [[],[]] .chain = true := by decide
def e1211210852986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210852986 : Closed e1211210852986 ∧ code e1211210852986 = 5609257364090 := by decide
theorem cert_e1211210852986 : check e1211210852986 [[],[]] .chain = true := by decide
def e1211210853150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211210853150 : Closed e1211210853150 ∧ code e1211210853150 = 5609257364254 := by decide
theorem cert_e1211210853150 : check e1211210853150 [[],[]] .chain = true := by decide
def e1211210853250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210853250 : Closed e1211210853250 ∧ code e1211210853250 = 5609257364354 := by decide
theorem cert_e1211210853250 : check e1211210853250 [[],[]] .chain = true := by decide
def e1211210853262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211210853262 : Closed e1211210853262 ∧ code e1211210853262 = 5609257364366 := by decide
theorem cert_e1211210853262 : check e1211210853262 [[],[]] .chain = true := by decide
def e1211210853274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210853274 : Closed e1211210853274 ∧ code e1211210853274 = 5609257364378 := by decide
theorem cert_e1211210853274 : check e1211210853274 [[],[]] .chain = true := by decide
def e1211210853486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211210853486 : Closed e1211210853486 ∧ code e1211210853486 = 5609257364590 := by decide
theorem cert_e1211210853486 : check e1211210853486 [[],[]] .chain = true := by decide
def e1211210853498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211210853498 : Closed e1211210853498 ∧ code e1211210853498 = 5609257364602 := by decide
theorem cert_e1211210853498 : check e1211210853498 [[],[]] .chain = true := by decide
def e1211210853662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211210853662 : Closed e1211210853662 ∧ code e1211210853662 = 5609257364766 := by decide
theorem cert_e1211210853662 : check e1211210853662 [[],[]] .chain = true := by decide
def e1211210853830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211210853830 : Closed e1211210853830 ∧ code e1211210853830 = 5609257364934 := by decide
theorem cert_e1211210853830 : check e1211210853830 [[],[]] .chain = true := by decide
def e1211210853898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211210853898 : Closed e1211210853898 ∧ code e1211210853898 = 5609257365002 := by decide
theorem cert_e1211210853898 : check e1211210853898 [[],[]] .chain = true := by decide
def e1211210853942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211210853942 : Closed e1211210853942 ∧ code e1211210853942 = 5609257365046 := by decide
theorem cert_e1211210853942 : check e1211210853942 [[],[]] .chain = true := by decide
def e1211210853946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211210853946 : Closed e1211210853946 ∧ code e1211210853946 = 5609257365050 := by decide
theorem cert_e1211210853946 : check e1211210853946 [[],[]] .chain = true := by decide
def e1211210853994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211210853994 : Closed e1211210853994 ∧ code e1211210853994 = 5609257365098 := by decide
theorem cert_e1211210853994 : check e1211210853994 [[],[]] .chain = true := by decide
def e1211210854018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210854018 : Closed e1211210854018 ∧ code e1211210854018 = 5609257365122 := by decide
theorem cert_e1211210854018 : check e1211210854018 [[],[]] .chain = true := by decide
def e1211210854030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211210854030 : Closed e1211210854030 ∧ code e1211210854030 = 5609257365134 := by decide
theorem cert_e1211210854030 : check e1211210854030 [[],[]] .chain = true := by decide
def e1211210854042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210854042 : Closed e1211210854042 ∧ code e1211210854042 = 5609257365146 := by decide
theorem cert_e1211210854042 : check e1211210854042 [[],[]] .chain = true := by decide
def e1211210854086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211210854086 : Closed e1211210854086 ∧ code e1211210854086 = 5609257365190 := by decide
theorem cert_e1211210854086 : check e1211210854086 [[],[]] .chain = true := by decide
def e1211210854486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211210854486 : Closed e1211210854486 ∧ code e1211210854486 = 5609257365590 := by decide
theorem cert_e1211210854486 : check e1211210854486 [[],[]] .chain = true := by decide
def e1211210854490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211210854490 : Closed e1211210854490 ∧ code e1211210854490 = 5609257365594 := by decide
theorem cert_e1211210854490 : check e1211210854490 [[],[]] .chain = true := by decide
def e1211210854506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e1211210854506 : Closed e1211210854506 ∧ code e1211210854506 = 5609257365610 := by decide
theorem cert_e1211210854506 : check e1211210854506 [[],[]] .chain = true := by decide
def e1211210854682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211210854682 : Closed e1211210854682 ∧ code e1211210854682 = 5609257365786 := by decide
theorem cert_e1211210854682 : check e1211210854682 [[],[]] .chain = true := by decide
def e1211210854726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211210854726 : Closed e1211210854726 ∧ code e1211210854726 = 5609257365830 := by decide
theorem cert_e1211210854726 : check e1211210854726 [[],[]] .chain = true := by decide
def e1211210854794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211210854794 : Closed e1211210854794 ∧ code e1211210854794 = 5609257365898 := by decide
theorem cert_e1211210854794 : check e1211210854794 [[],[]] .chain = true := by decide
def e1211210854818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211210854818 : Closed e1211210854818 ∧ code e1211210854818 = 5609257365922 := by decide
theorem cert_e1211210854818 : check e1211210854818 [[],[]] .chain = true := by decide
def e1211210854830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211210854830 : Closed e1211210854830 ∧ code e1211210854830 = 5609257365934 := by decide
theorem cert_e1211210854830 : check e1211210854830 [[],[]] .sourceHead = true := by decide
def e1211210854838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1211210854838 : Closed e1211210854838 ∧ code e1211210854838 = 5609257365942 := by decide
theorem cert_e1211210854838 : check e1211210854838 [[],[]] .chain = true := by decide
def e1211210854842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211210854842 : Closed e1211210854842 ∧ code e1211210854842 = 5609257365946 := by decide
theorem cert_e1211210854842 : check e1211210854842 [[],[]] .sourceHead = true := by decide
def e1211210854870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211210854870 : Closed e1211210854870 ∧ code e1211210854870 = 5609257365974 := by decide
theorem cert_e1211210854870 : check e1211210854870 [[],[]] .chain = true := by decide
def e1211210854874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211210854874 : Closed e1211210854874 ∧ code e1211210854874 = 5609257365978 := by decide
theorem cert_e1211210854874 : check e1211210854874 [[],[]] .chain = true := by decide
def e1211210854890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211210854890 : Closed e1211210854890 ∧ code e1211210854890 = 5609257365994 := by decide
theorem cert_e1211210854890 : check e1211210854890 [[],[]] .sourceHead = true := by decide
def e1211210855254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211210855254 : Closed e1211210855254 ∧ code e1211210855254 = 5609257366358 := by decide
theorem cert_e1211210855254 : check e1211210855254 [[],[]] .chain = true := by decide
def e1211210855258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211210855258 : Closed e1211210855258 ∧ code e1211210855258 = 5609257366362 := by decide
theorem cert_e1211210855258 : check e1211210855258 [[],[]] .chain = true := by decide
def e1211210855274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211210855274 : Closed e1211210855274 ∧ code e1211210855274 = 5609257366378 := by decide
theorem cert_e1211210855274 : check e1211210855274 [[],[]] .chain = true := by decide
def e1211210855338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211210855338 : Closed e1211210855338 ∧ code e1211210855338 = 5609257366442 := by decide
theorem cert_e1211210855338 : check e1211210855338 [[],[]] .chain = true := by decide
def e1211210855446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211210855446 : Closed e1211210855446 ∧ code e1211210855446 = 5609257366550 := by decide
theorem cert_e1211210855446 : check e1211210855446 [[],[]] .chain = true := by decide
def e1211210855450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211210855450 : Closed e1211210855450 ∧ code e1211210855450 = 5609257366554 := by decide
theorem cert_e1211210855450 : check e1211210855450 [[],[]] .chain = true := by decide
def e1211210855494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211210855494 : Closed e1211210855494 ∧ code e1211210855494 = 5609257366598 := by decide
theorem cert_e1211210855494 : check e1211210855494 [[],[]] .chain = true := by decide
def e1211210855522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211210855522 : Closed e1211210855522 ∧ code e1211210855522 = 5609257366626 := by decide
theorem cert_e1211210855522 : check e1211210855522 [[],[]] .chain = true := by decide
def e1211210855534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211210855534 : Closed e1211210855534 ∧ code e1211210855534 = 5609257366638 := by decide
theorem cert_e1211210855534 : check e1211210855534 [[],[]] .sourceHead = true := by decide
def e1211210855542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211210855542 : Closed e1211210855542 ∧ code e1211210855542 = 5609257366646 := by decide
theorem cert_e1211210855542 : check e1211210855542 [[],[]] .chain = true := by decide
def e1211210855546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211210855546 : Closed e1211210855546 ∧ code e1211210855546 = 5609257366650 := by decide
theorem cert_e1211210855546 : check e1211210855546 [[],[]] .sourceHead = true := by decide
def e1211210855638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211210855638 : Closed e1211210855638 ∧ code e1211210855638 = 5609257366742 := by decide
theorem cert_e1211210855638 : check e1211210855638 [[],[]] .chain = true := by decide
def e1211210855642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211210855642 : Closed e1211210855642 ∧ code e1211210855642 = 5609257366746 := by decide
theorem cert_e1211210855642 : check e1211210855642 [[],[]] .chain = true := by decide
def e1211210855658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211210855658 : Closed e1211210855658 ∧ code e1211210855658 = 5609257366762 := by decide
theorem cert_e1211210855658 : check e1211210855658 [[],[]] .chain = true := by decide
def e1211210855686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210855686 : Closed e1211210855686 ∧ code e1211210855686 = 5609257366790 := by decide
theorem cert_e1211210855686 : check e1211210855686 [[],[]] .chain = true := by decide
def e1211210855710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211210855710 : Closed e1211210855710 ∧ code e1211210855710 = 5609257366814 := by decide
theorem cert_e1211210855710 : check e1211210855710 [[],[]] .sourceHead = true := by decide
def e1211210855734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210855734 : Closed e1211210855734 ∧ code e1211210855734 = 5609257366838 := by decide
theorem cert_e1211210855734 : check e1211210855734 [[],[]] .chain = true := by decide
def e1211210855738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210855738 : Closed e1211210855738 ∧ code e1211210855738 = 5609257366842 := by decide
theorem cert_e1211210855738 : check e1211210855738 [[],[]] .chain = true := by decide
def e1211210855810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210855810 : Closed e1211210855810 ∧ code e1211210855810 = 5609257366914 := by decide
theorem cert_e1211210855810 : check e1211210855810 [[],[]] .chain = true := by decide
def e1211210855822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211210855822 : Closed e1211210855822 ∧ code e1211210855822 = 5609257366926 := by decide
theorem cert_e1211210855822 : check e1211210855822 [[],[]] .chain = true := by decide
def e1211210855834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210855834 : Closed e1211210855834 ∧ code e1211210855834 = 5609257366938 := by decide
theorem cert_e1211210855834 : check e1211210855834 [[],[]] .chain = true := by decide
def e1211210855878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211210855878 : Closed e1211210855878 ∧ code e1211210855878 = 5609257366982 := by decide
theorem cert_e1211210855878 : check e1211210855878 [[],[]] .sourceHead = true := by decide
def e1211210855946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211210855946 : Closed e1211210855946 ∧ code e1211210855946 = 5609257367050 := by decide
theorem cert_e1211210855946 : check e1211210855946 [[],[]] .chain = true := by decide
def e1211210855990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211210855990 : Closed e1211210855990 ∧ code e1211210855990 = 5609257367094 := by decide
theorem cert_e1211210855990 : check e1211210855990 [[],[]] .chain = true := by decide
def e1211210855994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211210855994 : Closed e1211210855994 ∧ code e1211210855994 = 5609257367098 := by decide
theorem cert_e1211210855994 : check e1211210855994 [[],[]] .chain = true := by decide
def e1211210856042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211210856042 : Closed e1211210856042 ∧ code e1211210856042 = 5609257367146 := by decide
theorem cert_e1211210856042 : check e1211210856042 [[],[]] .chain = true := by decide
def e1211210856066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210856066 : Closed e1211210856066 ∧ code e1211210856066 = 5609257367170 := by decide
theorem cert_e1211210856066 : check e1211210856066 [[],[]] .chain = true := by decide
def e1211210856078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211210856078 : Closed e1211210856078 ∧ code e1211210856078 = 5609257367182 := by decide
theorem cert_e1211210856078 : check e1211210856078 [[],[]] .chain = true := by decide
def e1211210856090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210856090 : Closed e1211210856090 ∧ code e1211210856090 = 5609257367194 := by decide
theorem cert_e1211210856090 : check e1211210856090 [[],[]] .chain = true := by decide
def e1211210856134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211210856134 : Closed e1211210856134 ∧ code e1211210856134 = 5609257367238 := by decide
theorem cert_e1211210856134 : check e1211210856134 [[],[]] .chain = true := by decide
def e1211210856218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211210856218 : Closed e1211210856218 ∧ code e1211210856218 = 5609257367322 := by decide
theorem cert_e1211210856218 : check e1211210856218 [[],[]] .sourceHead = true := by decide
def e1211210856262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211210856262 : Closed e1211210856262 ∧ code e1211210856262 = 5609257367366 := by decide
theorem cert_e1211210856262 : check e1211210856262 [[],[]] .sourceHead = true := by decide
def e1211210858990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211210858990 : Closed e1211210858990 ∧ code e1211210858990 = 5609257370094 := by decide
theorem cert_e1211210858990 : check e1211210858990 [[],[]] .chain = true := by decide
def e1211210859002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211210859002 : Closed e1211210859002 ∧ code e1211210859002 = 5609257370106 := by decide
theorem cert_e1211210859002 : check e1211210859002 [[],[]] .chain = true := by decide
def e1211210859758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211210859758 : Closed e1211210859758 ∧ code e1211210859758 = 5609257370862 := by decide
theorem cert_e1211210859758 : check e1211210859758 [[],[]] .chain = true := by decide
def e1211210859766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211210859766 : Closed e1211210859766 ∧ code e1211210859766 = 5609257370870 := by decide
theorem cert_e1211210859766 : check e1211210859766 [[],[]] .chain = true := by decide
def e1211210860142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210860142 : Closed e1211210860142 ∧ code e1211210860142 = 5609257371246 := by decide
theorem cert_e1211210860142 : check e1211210860142 [[],[]] .chain = true := by decide
def e1211210860154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210860154 : Closed e1211210860154 ∧ code e1211210860154 = 5609257371258 := by decide
theorem cert_e1211210860154 : check e1211210860154 [[],[]] .chain = true := by decide
def e1211210860318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211210860318 : Closed e1211210860318 ∧ code e1211210860318 = 5609257371422 := by decide
theorem cert_e1211210860318 : check e1211210860318 [[],[]] .chain = true := by decide
def e1211210860486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211210860486 : Closed e1211210860486 ∧ code e1211210860486 = 5609257371590 := by decide
theorem cert_e1211210860486 : check e1211210860486 [[],[]] .chain = true := by decide
def e1211210861678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211210861678 : Closed e1211210861678 ∧ code e1211210861678 = 5609257372782 := by decide
theorem cert_e1211210861678 : check e1211210861678 [[],[]] .sourceHead = true := by decide
def e1211210861854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211210861854 : Closed e1211210861854 ∧ code e1211210861854 = 5609257372958 := by decide
theorem cert_e1211210861854 : check e1211210861854 [[],[]] .sourceHead = true := by decide
def e1211210862062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e1211210862062 : Closed e1211210862062 ∧ code e1211210862062 = 5609257373166 := by decide
theorem cert_e1211210862062 : check e1211210862062 [[],[]] .sourceHead = true := by decide
def e1211210862126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211210862126 : Closed e1211210862126 ∧ code e1211210862126 = 5609257373230 := by decide
theorem cert_e1211210862126 : check e1211210862126 [[],[]] .chain = true := by decide
def e1211210862318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211210862318 : Closed e1211210862318 ∧ code e1211210862318 = 5609257373422 := by decide
theorem cert_e1211210862318 : check e1211210862318 [[],[]] .chain = true := by decide
def e1211210862326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211210862326 : Closed e1211210862326 ∧ code e1211210862326 = 5609257373430 := by decide
theorem cert_e1211210862326 : check e1211210862326 [[],[]] .chain = true := by decide
def e1211210862446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211210862446 : Closed e1211210862446 ∧ code e1211210862446 = 5609257373550 := by decide
theorem cert_e1211210862446 : check e1211210862446 [[],[]] .chain = true := by decide
def e1211210862458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211210862458 : Closed e1211210862458 ∧ code e1211210862458 = 5609257373562 := by decide
theorem cert_e1211210862458 : check e1211210862458 [[],[]] .chain = true := by decide
def e1211210862474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211210862474 : Closed e1211210862474 ∧ code e1211210862474 = 5609257373578 := by decide
theorem cert_e1211210862474 : check e1211210862474 [[],[]] .chain = true := by decide
def e1211210862510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e1211210862510 : Closed e1211210862510 ∧ code e1211210862510 = 5609257373614 := by decide
theorem cert_e1211210862510 : check e1211210862510 [[],[]] .sourceHead = true := by decide
def e1211210862518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211210862518 : Closed e1211210862518 ∧ code e1211210862518 = 5609257373622 := by decide
theorem cert_e1211210862518 : check e1211210862518 [[],[]] .chain = true := by decide
def e1211210862522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211210862522 : Closed e1211210862522 ∧ code e1211210862522 = 5609257373626 := by decide
theorem cert_e1211210862522 : check e1211210862522 [[],[]] .chain = true := by decide
def e1211210863390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211210863390 : Closed e1211210863390 ∧ code e1211210863390 = 5609257374494 := by decide
theorem cert_e1211210863390 : check e1211210863390 [[],[]] .chain = true := by decide
def e1211210863558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211210863558 : Closed e1211210863558 ∧ code e1211210863558 = 5609257374662 := by decide
theorem cert_e1211210863558 : check e1211210863558 [[],[]] .chain = true := by decide
def e1211210864702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211210864702 : Closed e1211210864702 ∧ code e1211210864702 = 5609257375806 := by decide
theorem cert_e1211210864702 : check e1211210864702 [[],[]] .chain = true := by decide
def e1211210865122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211210865122 : Closed e1211210865122 ∧ code e1211210865122 = 5609257376226 := by decide
theorem cert_e1211210865122 : check e1211210865122 [[],[]] .chain = true := by decide
def e1211210865134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211210865134 : Closed e1211210865134 ∧ code e1211210865134 = 5609257376238 := by decide
theorem cert_e1211210865134 : check e1211210865134 [[],[]] .sourceHead = true := by decide
def e1211210865902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211210865902 : Closed e1211210865902 ∧ code e1211210865902 = 5609257377006 := by decide
theorem cert_e1211210865902 : check e1211210865902 [[],[]] .chain = true := by decide
def e1211210865910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211210865910 : Closed e1211210865910 ∧ code e1211210865910 = 5609257377014 := by decide
theorem cert_e1211210865910 : check e1211210865910 [[],[]] .chain = true := by decide
def e1211210866190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211210866190 : Closed e1211210866190 ∧ code e1211210866190 = 5609257377294 := by decide
theorem cert_e1211210866190 : check e1211210866190 [[],[]] .chain = true := by decide
def e1211210866202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210866202 : Closed e1211210866202 ∧ code e1211210866202 = 5609257377306 := by decide
theorem cert_e1211210866202 : check e1211210866202 [[],[]] .sourceHead = true := by decide
def e1211210866274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211210866274 : Closed e1211210866274 ∧ code e1211210866274 = 5609257377378 := by decide
theorem cert_e1211210866274 : check e1211210866274 [[],[]] .chain = true := by decide
def e1211210866286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210866286 : Closed e1211210866286 ∧ code e1211210866286 = 5609257377390 := by decide
theorem cert_e1211210866286 : check e1211210866286 [[],[]] .sourceHead = true := by decide
def e1211210866294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211210866294 : Closed e1211210866294 ∧ code e1211210866294 = 5609257377398 := by decide
theorem cert_e1211210866294 : check e1211210866294 [[],[]] .chain = true := by decide
def e1211210866298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210866298 : Closed e1211210866298 ∧ code e1211210866298 = 5609257377402 := by decide
theorem cert_e1211210866298 : check e1211210866298 [[],[]] .sourceHead = true := by decide
def e1211210870126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211210870126 : Closed e1211210870126 ∧ code e1211210870126 = 5609257381230 := by decide
theorem cert_e1211210870126 : check e1211210870126 [[],[]] .chain = true := by decide
def e1211210870134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211210870134 : Closed e1211210870134 ∧ code e1211210870134 = 5609257381238 := by decide
theorem cert_e1211210870134 : check e1211210870134 [[],[]] .chain = true := by decide
def e1211210870190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211210870190 : Closed e1211210870190 ∧ code e1211210870190 = 5609257381294 := by decide
theorem cert_e1211210870190 : check e1211210870190 [[],[]] .chain = true := by decide
def e1211210870202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211210870202 : Closed e1211210870202 ∧ code e1211210870202 = 5609257381306 := by decide
theorem cert_e1211210870202 : check e1211210870202 [[],[]] .chain = true := by decide
def e1211210870230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211210870230 : Closed e1211210870230 ∧ code e1211210870230 = 5609257381334 := by decide
theorem cert_e1211210870230 : check e1211210870230 [[],[]] .chain = true := by decide
def e1211210870234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211210870234 : Closed e1211210870234 ∧ code e1211210870234 = 5609257381338 := by decide
theorem cert_e1211210870234 : check e1211210870234 [[],[]] .chain = true := by decide
def e1211210870446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211210870446 : Closed e1211210870446 ∧ code e1211210870446 = 5609257381550 := by decide
theorem cert_e1211210870446 : check e1211210870446 [[],[]] .chain = true := by decide
def e1211210870458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211210870458 : Closed e1211210870458 ∧ code e1211210870458 = 5609257381562 := by decide
theorem cert_e1211210870458 : check e1211210870458 [[],[]] .chain = true := by decide
def e1211210870506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211210870506 : Closed e1211210870506 ∧ code e1211210870506 = 5609257381610 := by decide
theorem cert_e1211210870506 : check e1211210870506 [[],[]] .chain = true := by decide
def e1211210870614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211210870614 : Closed e1211210870614 ∧ code e1211210870614 = 5609257381718 := by decide
theorem cert_e1211210870614 : check e1211210870614 [[],[]] .chain = true := by decide
def e1211210870618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211210870618 : Closed e1211210870618 ∧ code e1211210870618 = 5609257381722 := by decide
theorem cert_e1211210870618 : check e1211210870618 [[],[]] .chain = true := by decide
def e1211210870634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211210870634 : Closed e1211210870634 ∧ code e1211210870634 = 5609257381738 := by decide
theorem cert_e1211210870634 : check e1211210870634 [[],[]] .chain = true := by decide
def e1211210870894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211210870894 : Closed e1211210870894 ∧ code e1211210870894 = 5609257381998 := by decide
theorem cert_e1211210870894 : check e1211210870894 [[],[]] .chain = true := by decide
def e1211210871070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211210871070 : Closed e1211210871070 ∧ code e1211210871070 = 5609257382174 := by decide
theorem cert_e1211210871070 : check e1211210871070 [[],[]] .chain = true := by decide
def e1211210871266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211210871266 : Closed e1211210871266 ∧ code e1211210871266 = 5609257382370 := by decide
theorem cert_e1211210871266 : check e1211210871266 [[],[]] .chain = true := by decide
def e1211210871278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211210871278 : Closed e1211210871278 ∧ code e1211210871278 = 5609257382382 := by decide
theorem cert_e1211210871278 : check e1211210871278 [[],[]] .sourceHead = true := by decide
def e1211210871662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211210871662 : Closed e1211210871662 ∧ code e1211210871662 = 5609257382766 := by decide
theorem cert_e1211210871662 : check e1211210871662 [[],[]] .chain = true := by decide
def e1211210871670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211210871670 : Closed e1211210871670 ∧ code e1211210871670 = 5609257382774 := by decide
theorem cert_e1211210871670 : check e1211210871670 [[],[]] .chain = true := by decide
def e1211210871726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211210871726 : Closed e1211210871726 ∧ code e1211210871726 = 5609257382830 := by decide
theorem cert_e1211210871726 : check e1211210871726 [[],[]] .chain = true := by decide
def e1211210871738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211210871738 : Closed e1211210871738 ∧ code e1211210871738 = 5609257382842 := by decide
theorem cert_e1211210871738 : check e1211210871738 [[],[]] .chain = true := by decide
def e1211210871766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211210871766 : Closed e1211210871766 ∧ code e1211210871766 = 5609257382870 := by decide
theorem cert_e1211210871766 : check e1211210871766 [[],[]] .chain = true := by decide
def e1211210871770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211210871770 : Closed e1211210871770 ∧ code e1211210871770 = 5609257382874 := by decide
theorem cert_e1211210871770 : check e1211210871770 [[],[]] .chain = true := by decide
def e1211210872046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211210872046 : Closed e1211210872046 ∧ code e1211210872046 = 5609257383150 := by decide
theorem cert_e1211210872046 : check e1211210872046 [[],[]] .chain = true := by decide
def e1211210872054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211210872054 : Closed e1211210872054 ∧ code e1211210872054 = 5609257383158 := by decide
theorem cert_e1211210872054 : check e1211210872054 [[],[]] .chain = true := by decide
def e1211210872430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210872430 : Closed e1211210872430 ∧ code e1211210872430 = 5609257383534 := by decide
theorem cert_e1211210872430 : check e1211210872430 [[],[]] .chain = true := by decide
def e1211210872442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210872442 : Closed e1211210872442 ∧ code e1211210872442 = 5609257383546 := by decide
theorem cert_e1211210872442 : check e1211210872442 [[],[]] .chain = true := by decide
def e1211210872582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210872582 : Closed e1211210872582 ∧ code e1211210872582 = 5609257383686 := by decide
theorem cert_e1211210872582 : check e1211210872582 [[],[]] .chain = true := by decide
def e1211210872606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211210872606 : Closed e1211210872606 ∧ code e1211210872606 = 5609257383710 := by decide
theorem cert_e1211210872606 : check e1211210872606 [[],[]] .sourceHead = true := by decide
def e1211210872630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210872630 : Closed e1211210872630 ∧ code e1211210872630 = 5609257383734 := by decide
theorem cert_e1211210872630 : check e1211210872630 [[],[]] .chain = true := by decide
def e1211210872634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210872634 : Closed e1211210872634 ∧ code e1211210872634 = 5609257383738 := by decide
theorem cert_e1211210872634 : check e1211210872634 [[],[]] .chain = true := by decide
def e1211210872878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211210872878 : Closed e1211210872878 ∧ code e1211210872878 = 5609257383982 := by decide
theorem cert_e1211210872878 : check e1211210872878 [[],[]] .chain = true := by decide
def e1211210873070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211210873070 : Closed e1211210873070 ∧ code e1211210873070 = 5609257384174 := by decide
theorem cert_e1211210873070 : check e1211210873070 [[],[]] .chain = true := by decide
def e1211210873078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211210873078 : Closed e1211210873078 ∧ code e1211210873078 = 5609257384182 := by decide
theorem cert_e1211210873078 : check e1211210873078 [[],[]] .chain = true := by decide
def e1211210873262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211210873262 : Closed e1211210873262 ∧ code e1211210873262 = 5609257384366 := by decide
theorem cert_e1211210873262 : check e1211210873262 [[],[]] .chain = true := by decide
def e1211210873274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211210873274 : Closed e1211210873274 ∧ code e1211210873274 = 5609257384378 := by decide
theorem cert_e1211210873274 : check e1211210873274 [[],[]] .chain = true := by decide
def e1211210873322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211210873322 : Closed e1211210873322 ∧ code e1211210873322 = 5609257384426 := by decide
theorem cert_e1211210873322 : check e1211210873322 [[],[]] .chain = true := by decide
def e1211210873454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210873454 : Closed e1211210873454 ∧ code e1211210873454 = 5609257384558 := by decide
theorem cert_e1211210873454 : check e1211210873454 [[],[]] .chain = true := by decide
def e1211210873466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210873466 : Closed e1211210873466 ∧ code e1211210873466 = 5609257384570 := by decide
theorem cert_e1211210873466 : check e1211210873466 [[],[]] .chain = true := by decide
def e1211210873630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211210873630 : Closed e1211210873630 ∧ code e1211210873630 = 5609257384734 := by decide
theorem cert_e1211210873630 : check e1211210873630 [[],[]] .chain = true := by decide
def e1211210873730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210873730 : Closed e1211210873730 ∧ code e1211210873730 = 5609257384834 := by decide
theorem cert_e1211210873730 : check e1211210873730 [[],[]] .chain = true := by decide
end Blc.Floor42
