import CodeBridge
import R1209577550702Blk0
import R1209577550702Blk6
import R1209577550702Blk12
namespace Certgen.R1209577550702
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor42 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit106 : Term := .var 0
def lit69 : Term := .var 1
def lit24 : Term := .var 2
def lit61 : Term := .lam lit106
def lit68 : Term := .lam lit69
def lit104 : Term := .app lit106 lit106
def lit60 : Term := .lam lit61
def lit21 : Term := .app lit106 lit69
def lit67 : Term := .lam lit68
def lit70 : Term := .var 6
def lit103 : Term := .lam lit104
def lit8 : Term := .app lit106 lit104
def lit58 : Term := .app lit106 lit60
def lit19 : Term := .app lit106 lit21
def lit65 : Term := .app lit106 lit67
def lit7 : Term := .lam lit8
def lit18 : Term := .app lit19 lit24
def lit98 : Term := .app lit103 lit103
def lit17 : Term := .lam lit18
def lit64 : Term := .app lit65 lit70
def lit63 : Term := .lam lit64
def lit15 : Term := .app lit69 lit17
def lit14 : Term := .lam lit15
def lit13 : Term := .lam lit14
def lit57 : Term := .app lit58 lit63
def lit56 : Term := .lam lit57
def lit6 : Term := .app lit7 lit13
def lit5 : Term := .app lit6 lit60
def lit50 : Term := .app lit65 lit56
def lit49 : Term := .lam lit50
def lit43 : Term := .app lit65 lit49
def lit42 : Term := .lam lit43
def lit36 : Term := .app lit65 lit42
def lit35 : Term := .lam lit36
def lit29 : Term := .app lit65 lit35
def lit28 : Term := .lam lit29
def lit4 : Term := .app lit5 lit28
def lit3 : Term := .app lit4 lit98
def lit2 : Term := .app lit3 lit98
def lit1 : Term := .app lit2 lit98
def lit0 : Term := .app lit1 lit98
def filling : Nat → Term := fun p => if p = 70 then Term.var 6 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub106 : model.term 106 = lit106 := model.var_eq 106 0 (by rfl)
theorem sub105 : model.term 105 = lit106 := model.var_eq 105 0 (by rfl)
theorem sub104 : model.term 104 = lit104 := by rw [model.app_eq 104 105 106 (by rfl), sub105, sub106]; rfl
theorem sub103 : model.term 103 = lit103 := by rw [model.lam_eq 103 104 (by rfl), sub104]; rfl
theorem sub102 : model.term 102 = lit106 := model.var_eq 102 0 (by rfl)
theorem sub101 : model.term 101 = lit106 := model.var_eq 101 0 (by rfl)
theorem sub100 : model.term 100 = lit104 := by rw [model.app_eq 100 101 102 (by rfl), sub101, sub102]; rfl
theorem sub99 : model.term 99 = lit103 := by rw [model.lam_eq 99 100 (by rfl), sub100]; rfl
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 103 (by rfl), sub99, sub103]; rfl
theorem sub97 : model.term 97 = lit106 := model.var_eq 97 0 (by rfl)
theorem sub96 : model.term 96 = lit106 := model.var_eq 96 0 (by rfl)
theorem sub95 : model.term 95 = lit104 := by rw [model.app_eq 95 96 97 (by rfl), sub96, sub97]; rfl
theorem sub94 : model.term 94 = lit103 := by rw [model.lam_eq 94 95 (by rfl), sub95]; rfl
theorem sub93 : model.term 93 = lit106 := model.var_eq 93 0 (by rfl)
theorem sub92 : model.term 92 = lit106 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit104 := by rw [model.app_eq 91 92 93 (by rfl), sub92, sub93]; rfl
theorem sub90 : model.term 90 = lit103 := by rw [model.lam_eq 90 91 (by rfl), sub91]; rfl
theorem sub89 : model.term 89 = lit98 := by rw [model.app_eq 89 90 94 (by rfl), sub90, sub94]; rfl
theorem sub88 : model.term 88 = lit106 := model.var_eq 88 0 (by rfl)
theorem sub87 : model.term 87 = lit106 := model.var_eq 87 0 (by rfl)
theorem sub86 : model.term 86 = lit104 := by rw [model.app_eq 86 87 88 (by rfl), sub87, sub88]; rfl
theorem sub85 : model.term 85 = lit103 := by rw [model.lam_eq 85 86 (by rfl), sub86]; rfl
theorem sub84 : model.term 84 = lit106 := model.var_eq 84 0 (by rfl)
theorem sub83 : model.term 83 = lit106 := model.var_eq 83 0 (by rfl)
theorem sub82 : model.term 82 = lit104 := by rw [model.app_eq 82 83 84 (by rfl), sub83, sub84]; rfl
theorem sub81 : model.term 81 = lit103 := by rw [model.lam_eq 81 82 (by rfl), sub82]; rfl
theorem sub80 : model.term 80 = lit98 := by rw [model.app_eq 80 81 85 (by rfl), sub81, sub85]; rfl
theorem sub79 : model.term 79 = lit106 := model.var_eq 79 0 (by rfl)
theorem sub78 : model.term 78 = lit106 := model.var_eq 78 0 (by rfl)
theorem sub77 : model.term 77 = lit104 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit103 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit106 := model.var_eq 75 0 (by rfl)
theorem sub74 : model.term 74 = lit106 := model.var_eq 74 0 (by rfl)
theorem sub73 : model.term 73 = lit104 := by rw [model.app_eq 73 74 75 (by rfl), sub74, sub75]; rfl
theorem sub72 : model.term 72 = lit103 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit98 := by rw [model.app_eq 71 72 76 (by rfl), sub72, sub76]; rfl
theorem sub70 : model.term 70 = lit70 := (opaqueTerm (rankedCode code ordered_code) filling (p := 70) (by rfl)).trans (by rfl)
theorem sub69 : model.term 69 = lit69 := model.var_eq 69 1 (by rfl)
theorem sub68 : model.term 68 = lit68 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit67 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit106 := model.var_eq 66 0 (by rfl)
theorem sub65 : model.term 65 = lit65 := by rw [model.app_eq 65 66 67 (by rfl), sub66, sub67]; rfl
theorem sub64 : model.term 64 = lit64 := by rw [model.app_eq 64 65 70 (by rfl), sub65, sub70]; rfl
theorem sub63 : model.term 63 = lit63 := by rw [model.lam_eq 63 64 (by rfl), sub64]; rfl
theorem sub62 : model.term 62 = lit106 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit61 := by rw [model.lam_eq 61 62 (by rfl), sub62]; rfl
theorem sub60 : model.term 60 = lit60 := by rw [model.lam_eq 60 61 (by rfl), sub61]; rfl
theorem sub59 : model.term 59 = lit106 := model.var_eq 59 0 (by rfl)
theorem sub58 : model.term 58 = lit58 := by rw [model.app_eq 58 59 60 (by rfl), sub59, sub60]; rfl
theorem sub57 : model.term 57 = lit57 := by rw [model.app_eq 57 58 63 (by rfl), sub58, sub63]; rfl
theorem sub56 : model.term 56 = lit56 := by rw [model.lam_eq 56 57 (by rfl), sub57]; rfl
theorem sub55 : model.term 55 = lit69 := model.var_eq 55 1 (by rfl)
theorem sub54 : model.term 54 = lit68 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit67 := by rw [model.lam_eq 53 54 (by rfl), sub54]; rfl
theorem sub52 : model.term 52 = lit106 := model.var_eq 52 0 (by rfl)
theorem sub51 : model.term 51 = lit65 := by rw [model.app_eq 51 52 53 (by rfl), sub52, sub53]; rfl
theorem sub50 : model.term 50 = lit50 := by rw [model.app_eq 50 51 56 (by rfl), sub51, sub56]; rfl
theorem sub49 : model.term 49 = lit49 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit69 := model.var_eq 48 1 (by rfl)
theorem sub47 : model.term 47 = lit68 := by rw [model.lam_eq 47 48 (by rfl), sub48]; rfl
theorem sub46 : model.term 46 = lit67 := by rw [model.lam_eq 46 47 (by rfl), sub47]; rfl
theorem sub45 : model.term 45 = lit106 := model.var_eq 45 0 (by rfl)
theorem sub44 : model.term 44 = lit65 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.app_eq 43 44 49 (by rfl), sub44, sub49]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit69 := model.var_eq 41 1 (by rfl)
theorem sub40 : model.term 40 = lit68 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit67 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit106 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit65 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 42 (by rfl), sub37, sub42]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit69 := model.var_eq 34 1 (by rfl)
theorem sub33 : model.term 33 = lit68 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit67 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit106 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit65 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit29 := by rw [model.app_eq 29 30 35 (by rfl), sub30, sub35]; rfl
theorem sub28 : model.term 28 = lit28 := by rw [model.lam_eq 28 29 (by rfl), sub29]; rfl
theorem sub27 : model.term 27 = lit106 := model.var_eq 27 0 (by rfl)
theorem sub26 : model.term 26 = lit61 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit60 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit24 := model.var_eq 24 2 (by rfl)
theorem sub23 : model.term 23 = lit69 := model.var_eq 23 1 (by rfl)
theorem sub22 : model.term 22 = lit106 := model.var_eq 22 0 (by rfl)
theorem sub21 : model.term 21 = lit21 := by rw [model.app_eq 21 22 23 (by rfl), sub22, sub23]; rfl
theorem sub20 : model.term 20 = lit106 := model.var_eq 20 0 (by rfl)
theorem sub19 : model.term 19 = lit19 := by rw [model.app_eq 19 20 21 (by rfl), sub20, sub21]; rfl
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 24 (by rfl), sub19, sub24]; rfl
theorem sub17 : model.term 17 = lit17 := by rw [model.lam_eq 17 18 (by rfl), sub18]; rfl
theorem sub16 : model.term 16 = lit69 := model.var_eq 16 1 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.lam_eq 14 15 (by rfl), sub15]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit106 := model.var_eq 12 0 (by rfl)
theorem sub11 : model.term 11 = lit106 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit104 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit106 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 13 (by rfl), sub7, sub13]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 25 (by rfl), sub6, sub25]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 28 (by rfl), sub5, sub28]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 71 (by rfl), sub4, sub71]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 80 (by rfl), sub3, sub80]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 89 (by rfl), sub2, sub89]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 98 (by rfl), sub1, sub98]; rfl
theorem allValid (i : Nat) (h : i < 192) : validState i = true := by
 by_cases h96 : i < 96
 · by_cases h48 : i < 48
   · by_cases h24 : i < 24
     · by_cases h12 : i < 12
       · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
     · by_cases h36 : i < 36
       · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
   · by_cases h72 : i < 72
     · by_cases h60 : i < 60
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
     · by_cases h84 : i < 84
       · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
 · by_cases h144 : i < 144
   · by_cases h120 : i < 120
     · by_cases h108 : i < 108
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
     · by_cases h132 : i < 132
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
   · by_cases h168 : i < 168
     · by_cases h156 : i < 156
       · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
     · by_cases h180 : i < 180
       · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 192
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e1209577550702 := by
 intro he
 have hp : replay [] (call e1209577550702 (.lam (.lam (.var 0))) (.lam (.lam (.var 0))) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R1209577550702
