import Batch119
import ExtraBase
namespace Blc.Floor42.Extra119
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1208664284890 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem ex_e1208664284890 : ¬ IsSelfInterpreter e1208664284890 := by
  intro he
  have hp := replay_sound (t := e1208664284890) (u := t_e1208664284890) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1208664284890
private def t_e1208664656858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1208664656858 : ¬ IsSelfInterpreter e1208664656858 := by
  intro he
  have hp := replay_sound (t := e1208664656858) (u := t_e1208664656858) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1208664656858
private def t_e1208664657142 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1208664657142 : ¬ IsSelfInterpreter e1208664657142 := by
  intro he
  have hp := replay_sound (t := e1208664657142) (u := t_e1208664657142) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1208664657142
private def t_e1208664657722 : Term := (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0))))
theorem ex_e1208664657722 : ¬ IsSelfInterpreter e1208664657722 := by
  intro he
  have hp := replay_sound (t := (call e1208664657722 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1208664657722) (ps := [[.left,.left],[.left,.left],[.left],[.left,.right,.under,.right],[.left,.left,.left],[.left,.left],[.left,.left,.right,.under,.right],[.left,.left],[.left],[.left,.right,.under,.right],[.left],[.left,.right,.under],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := SelfintKnot.occ_betas_zero hr 0 (by decide)
  exact (by decide : ¬ occ 0 (.var 0) = 0) hz
#print axioms ex_e1208664657722
end Blc.Floor42.Extra119
