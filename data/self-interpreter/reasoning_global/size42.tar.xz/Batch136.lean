import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182196598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211182196598 : Closed e1211182196598 ∧ code e1211182196598 = 5609228707702 := by decide
theorem cert_e1211182196598 : check e1211182196598 [[],[]] .smaller = true := by decide
def e1211182196602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211182196602 : Closed e1211182196602 ∧ code e1211182196602 = 5609228707706 := by decide
theorem cert_e1211182196602 : check e1211182196602 [[],[]] .smaller = true := by decide
def e1211182196662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211182196662 : Closed e1211182196662 ∧ code e1211182196662 = 5609228707766 := by decide
theorem cert_e1211182196662 : check e1211182196662 [[],[]] .smaller = true := by decide
def e1211182196694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211182196694 : Closed e1211182196694 ∧ code e1211182196694 = 5609228707798 := by decide
theorem cert_e1211182196694 : check e1211182196694 [[],[]] .smaller = true := by decide
def e1211182196698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211182196698 : Closed e1211182196698 ∧ code e1211182196698 = 5609228707802 := by decide
theorem cert_e1211182196698 : check e1211182196698 [[],[]] .smaller = true := by decide
def e1211182197214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211182197214 : Closed e1211182197214 ∧ code e1211182197214 = 5609228708318 := by decide
theorem cert_e1211182197214 : check e1211182197214 [[],[]] .smaller = true := by decide
def e1211182197238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211182197238 : Closed e1211182197238 ∧ code e1211182197238 = 5609228708342 := by decide
theorem cert_e1211182197238 : check e1211182197238 [[],[]] .smaller = true := by decide
def e1211182197886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 5)))))))))
theorem wire_e1211182197886 : Closed e1211182197886 ∧ code e1211182197886 = 5609228708990 := by decide
theorem cert_e1211182197886 : check e1211182197886 [[],[]] .three = true := by decide
def e1211182197982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182197982 : Closed e1211182197982 ∧ code e1211182197982 = 5609228709086 := by decide
theorem cert_e1211182197982 : check e1211182197982 [[],[]] .smaller = true := by decide
def e1211182197998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182197998 : Closed e1211182197998 ∧ code e1211182197998 = 5609228709102 := by decide
theorem cert_e1211182197998 : check e1211182197998 [[],[]] .smaller = true := by decide
def e1211182198006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182198006 : Closed e1211182198006 ∧ code e1211182198006 = 5609228709110 := by decide
theorem cert_e1211182198006 : check e1211182198006 [[],[]] .smaller = true := by decide
def e1211182198010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182198010 : Closed e1211182198010 ∧ code e1211182198010 = 5609228709114 := by decide
theorem cert_e1211182198010 : check e1211182198010 [[],[]] .smaller = true := by decide
def e1211182198334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211182198334 : Closed e1211182198334 ∧ code e1211182198334 = 5609228709438 := by decide
theorem cert_e1211182198334 : check e1211182198334 [[],[]] .smaller = true := by decide
def e1211182198390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182198390 : Closed e1211182198390 ∧ code e1211182198390 = 5609228709494 := by decide
theorem cert_e1211182198390 : check e1211182198390 [[],[]] .smaller = true := by decide
def e1211182198558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211182198558 : Closed e1211182198558 ∧ code e1211182198558 = 5609228709662 := by decide
theorem cert_e1211182198558 : check e1211182198558 [[],[]] .smaller = true := by decide
def e1211182198582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182198582 : Closed e1211182198582 ∧ code e1211182198582 = 5609228709686 := by decide
theorem cert_e1211182198582 : check e1211182198582 [[],[]] .smaller = true := by decide
def e1211182198586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182198586 : Closed e1211182198586 ∧ code e1211182198586 = 5609228709690 := by decide
theorem cert_e1211182198586 : check e1211182198586 [[],[]] .smaller = true := by decide
def e1211182198670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.lam (.var 2)))))))))
theorem wire_e1211182198670 : Closed e1211182198670 ∧ code e1211182198670 = 5609228709774 := by decide
theorem cert_e1211182198670 : check e1211182198670 [[],[]] .three = true := by decide
def e1211182199230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 4))))))))
theorem wire_e1211182199230 : Closed e1211182199230 ∧ code e1211182199230 = 5609228710334 := by decide
theorem cert_e1211182199230 : check e1211182199230 [[],[]] .three = true := by decide
def e1211182199262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211182199262 : Closed e1211182199262 ∧ code e1211182199262 = 5609228710366 := by decide
theorem cert_e1211182199262 : check e1211182199262 [[],[]] .smaller = true := by decide
def e1211182199278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211182199278 : Closed e1211182199278 ∧ code e1211182199278 = 5609228710382 := by decide
theorem cert_e1211182199278 : check e1211182199278 [[],[]] .smaller = true := by decide
def e1211182199286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211182199286 : Closed e1211182199286 ∧ code e1211182199286 = 5609228710390 := by decide
theorem cert_e1211182199286 : check e1211182199286 [[],[]] .smaller = true := by decide
def e1211182199290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 5))) (.var 0))))))))
theorem wire_e1211182199290 : Closed e1211182199290 ∧ code e1211182199290 = 5609228710394 := by decide
theorem cert_e1211182199290 : check e1211182199290 [[],[]] .three = true := by decide
def e1211182199646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211182199646 : Closed e1211182199646 ∧ code e1211182199646 = 5609228710750 := by decide
theorem cert_e1211182199646 : check e1211182199646 [[],[]] .smaller = true := by decide
def e1211182199662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211182199662 : Closed e1211182199662 ∧ code e1211182199662 = 5609228710766 := by decide
theorem cert_e1211182199662 : check e1211182199662 [[],[]] .smaller = true := by decide
def e1211182199670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211182199670 : Closed e1211182199670 ∧ code e1211182199670 = 5609228710774 := by decide
theorem cert_e1211182199670 : check e1211182199670 [[],[]] .smaller = true := by decide
def e1211182199674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211182199674 : Closed e1211182199674 ∧ code e1211182199674 = 5609228710778 := by decide
theorem cert_e1211182199674 : check e1211182199674 [[],[]] .smaller = true := by decide
def e1211182199726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211182199726 : Closed e1211182199726 ∧ code e1211182199726 = 5609228710830 := by decide
theorem cert_e1211182199726 : check e1211182199726 [[],[]] .smaller = true := by decide
def e1211182199738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211182199738 : Closed e1211182199738 ∧ code e1211182199738 = 5609228710842 := by decide
theorem cert_e1211182199738 : check e1211182199738 [[],[]] .smaller = true := by decide
def e1211182199766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211182199766 : Closed e1211182199766 ∧ code e1211182199766 = 5609228710870 := by decide
theorem cert_e1211182199766 : check e1211182199766 [[],[]] .smaller = true := by decide
def e1211182199770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211182199770 : Closed e1211182199770 ∧ code e1211182199770 = 5609228710874 := by decide
theorem cert_e1211182199770 : check e1211182199770 [[],[]] .smaller = true := by decide
def e1211182199786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211182199786 : Closed e1211182199786 ∧ code e1211182199786 = 5609228710890 := by decide
theorem cert_e1211182199786 : check e1211182199786 [[],[]] .smaller = true := by decide
def e1211182199934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 5)))))))))
theorem wire_e1211182199934 : Closed e1211182199934 ∧ code e1211182199934 = 5609228711038 := by decide
theorem cert_e1211182199934 : check e1211182199934 [[],[]] .three = true := by decide
def e1211182200030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182200030 : Closed e1211182200030 ∧ code e1211182200030 = 5609228711134 := by decide
theorem cert_e1211182200030 : check e1211182200030 [[],[]] .smaller = true := by decide
def e1211182200046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182200046 : Closed e1211182200046 ∧ code e1211182200046 = 5609228711150 := by decide
theorem cert_e1211182200046 : check e1211182200046 [[],[]] .smaller = true := by decide
def e1211182200054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182200054 : Closed e1211182200054 ∧ code e1211182200054 = 5609228711158 := by decide
theorem cert_e1211182200054 : check e1211182200054 [[],[]] .smaller = true := by decide
def e1211182200058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182200058 : Closed e1211182200058 ∧ code e1211182200058 = 5609228711162 := by decide
theorem cert_e1211182200058 : check e1211182200058 [[],[]] .smaller = true := by decide
def e1211182200382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211182200382 : Closed e1211182200382 ∧ code e1211182200382 = 5609228711486 := by decide
theorem cert_e1211182200382 : check e1211182200382 [[],[]] .smaller = true := by decide
def e1211182200430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182200430 : Closed e1211182200430 ∧ code e1211182200430 = 5609228711534 := by decide
theorem cert_e1211182200430 : check e1211182200430 [[],[]] .smaller = true := by decide
def e1211182200442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182200442 : Closed e1211182200442 ∧ code e1211182200442 = 5609228711546 := by decide
theorem cert_e1211182200442 : check e1211182200442 [[],[]] .smaller = true := by decide
def e1211182200606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211182200606 : Closed e1211182200606 ∧ code e1211182200606 = 5609228711710 := by decide
theorem cert_e1211182200606 : check e1211182200606 [[],[]] .smaller = true := by decide
def e1211182200630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182200630 : Closed e1211182200630 ∧ code e1211182200630 = 5609228711734 := by decide
theorem cert_e1211182200630 : check e1211182200630 [[],[]] .smaller = true := by decide
def e1211182200634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182200634 : Closed e1211182200634 ∧ code e1211182200634 = 5609228711738 := by decide
theorem cert_e1211182200634 : check e1211182200634 [[],[]] .smaller = true := by decide
def e1211182200718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211182200718 : Closed e1211182200718 ∧ code e1211182200718 = 5609228711822 := by decide
theorem cert_e1211182200718 : check e1211182200718 [[],[]] .smaller = true := by decide
def e1211182200730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182200730 : Closed e1211182200730 ∧ code e1211182200730 = 5609228711834 := by decide
theorem cert_e1211182200730 : check e1211182200730 [[],[]] .smaller = true := by decide
def e1211182200774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.lam (.var 1)))))))))
theorem wire_e1211182200774 : Closed e1211182200774 ∧ code e1211182200774 = 5609228711878 := by decide
theorem cert_e1211182200774 : check e1211182200774 [[],[]] .three = true := by decide
def e1211182201054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211182201054 : Closed e1211182201054 ∧ code e1211182201054 = 5609228712158 := by decide
theorem cert_e1211182201054 : check e1211182201054 [[],[]] .smaller = true := by decide
def e1211182201070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211182201070 : Closed e1211182201070 ∧ code e1211182201070 = 5609228712174 := by decide
theorem cert_e1211182201070 : check e1211182201070 [[],[]] .smaller = true := by decide
def e1211182201078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211182201078 : Closed e1211182201078 ∧ code e1211182201078 = 5609228712182 := by decide
theorem cert_e1211182201078 : check e1211182201078 [[],[]] .smaller = true := by decide
def e1211182201082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211182201082 : Closed e1211182201082 ∧ code e1211182201082 = 5609228712186 := by decide
theorem cert_e1211182201082 : check e1211182201082 [[],[]] .smaller = true := by decide
def e1211182201270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211182201270 : Closed e1211182201270 ∧ code e1211182201270 = 5609228712374 := by decide
theorem cert_e1211182201270 : check e1211182201270 [[],[]] .smaller = true := by decide
def e1211182201302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211182201302 : Closed e1211182201302 ∧ code e1211182201302 = 5609228712406 := by decide
theorem cert_e1211182201302 : check e1211182201302 [[],[]] .smaller = true := by decide
def e1211182201306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211182201306 : Closed e1211182201306 ∧ code e1211182201306 = 5609228712410 := by decide
theorem cert_e1211182201306 : check e1211182201306 [[],[]] .smaller = true := by decide
def e1211182201406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211182201406 : Closed e1211182201406 ∧ code e1211182201406 = 5609228712510 := by decide
theorem cert_e1211182201406 : check e1211182201406 [[],[]] .smaller = true := by decide
def e1211182201462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182201462 : Closed e1211182201462 ∧ code e1211182201462 = 5609228712566 := by decide
theorem cert_e1211182201462 : check e1211182201462 [[],[]] .smaller = true := by decide
def e1211182201630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211182201630 : Closed e1211182201630 ∧ code e1211182201630 = 5609228712734 := by decide
theorem cert_e1211182201630 : check e1211182201630 [[],[]] .smaller = true := by decide
def e1211182201654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182201654 : Closed e1211182201654 ∧ code e1211182201654 = 5609228712758 := by decide
theorem cert_e1211182201654 : check e1211182201654 [[],[]] .smaller = true := by decide
def e1211182201658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182201658 : Closed e1211182201658 ∧ code e1211182201658 = 5609228712762 := by decide
theorem cert_e1211182201658 : check e1211182201658 [[],[]] .smaller = true := by decide
def e1211182201742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211182201742 : Closed e1211182201742 ∧ code e1211182201742 = 5609228712846 := by decide
theorem cert_e1211182201742 : check e1211182201742 [[],[]] .smaller = true := by decide
def e1211182201790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 4))))))))
theorem wire_e1211182201790 : Closed e1211182201790 ∧ code e1211182201790 = 5609228712894 := by decide
theorem cert_e1211182201790 : check e1211182201790 [[],[]] .three = true := by decide
def e1211182201798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211182201798 : Closed e1211182201798 ∧ code e1211182201798 = 5609228712902 := by decide
theorem cert_e1211182201798 : check e1211182201798 [[],[]] .smaller = true := by decide
def e1211182201822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 3))))))))
theorem wire_e1211182201822 : Closed e1211182201822 ∧ code e1211182201822 = 5609228712926 := by decide
theorem cert_e1211182201822 : check e1211182201822 [[],[]] .smaller = true := by decide
def e1211182201838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 4)) (.var 2))))))))
theorem wire_e1211182201838 : Closed e1211182201838 ∧ code e1211182201838 = 5609228712942 := by decide
theorem cert_e1211182201838 : check e1211182201838 [[],[]] .three = true := by decide
def e1211182201966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211182201966 : Closed e1211182201966 ∧ code e1211182201966 = 5609228713070 := by decide
theorem cert_e1211182201966 : check e1211182201966 [[],[]] .smaller = true := by decide
def e1211182201974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211182201974 : Closed e1211182201974 ∧ code e1211182201974 = 5609228713078 := by decide
theorem cert_e1211182201974 : check e1211182201974 [[],[]] .smaller = true := by decide
def e1211182201978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211182201978 : Closed e1211182201978 ∧ code e1211182201978 = 5609228713082 := by decide
theorem cert_e1211182201978 : check e1211182201978 [[],[]] .smaller = true := by decide
def e1211182202070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211182202070 : Closed e1211182202070 ∧ code e1211182202070 = 5609228713174 := by decide
theorem cert_e1211182202070 : check e1211182202070 [[],[]] .smaller = true := by decide
def e1211182202074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211182202074 : Closed e1211182202074 ∧ code e1211182202074 = 5609228713178 := by decide
theorem cert_e1211182202074 : check e1211182202074 [[],[]] .smaller = true := by decide
def e1211182202090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211182202090 : Closed e1211182202090 ∧ code e1211182202090 = 5609228713194 := by decide
theorem cert_e1211182202090 : check e1211182202090 [[],[]] .smaller = true := by decide
def e1211182202142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211182202142 : Closed e1211182202142 ∧ code e1211182202142 = 5609228713246 := by decide
theorem cert_e1211182202142 : check e1211182202142 [[],[]] .smaller = true := by decide
def e1211182202166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182202166 : Closed e1211182202166 ∧ code e1211182202166 = 5609228713270 := by decide
theorem cert_e1211182202166 : check e1211182202166 [[],[]] .smaller = true := by decide
def e1211182202170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182202170 : Closed e1211182202170 ∧ code e1211182202170 = 5609228713274 := by decide
theorem cert_e1211182202170 : check e1211182202170 [[],[]] .smaller = true := by decide
def e1211182202254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211182202254 : Closed e1211182202254 ∧ code e1211182202254 = 5609228713358 := by decide
theorem cert_e1211182202254 : check e1211182202254 [[],[]] .smaller = true := by decide
def e1211182202266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182202266 : Closed e1211182202266 ∧ code e1211182202266 = 5609228713370 := by decide
theorem cert_e1211182202266 : check e1211182202266 [[],[]] .smaller = true := by decide
def e1211182202310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211182202310 : Closed e1211182202310 ∧ code e1211182202310 = 5609228713414 := by decide
theorem cert_e1211182202310 : check e1211182202310 [[],[]] .smaller = true := by decide
def e1211182202334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 3))))))))
theorem wire_e1211182202334 : Closed e1211182202334 ∧ code e1211182202334 = 5609228713438 := by decide
theorem cert_e1211182202334 : check e1211182202334 [[],[]] .smaller = true := by decide
def e1211182202350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 2))))))))
theorem wire_e1211182202350 : Closed e1211182202350 ∧ code e1211182202350 = 5609228713454 := by decide
theorem cert_e1211182202350 : check e1211182202350 [[],[]] .smaller = true := by decide
def e1211182202422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211182202422 : Closed e1211182202422 ∧ code e1211182202422 = 5609228713526 := by decide
theorem cert_e1211182202422 : check e1211182202422 [[],[]] .three = true := by decide
def e1211182202426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211182202426 : Closed e1211182202426 ∧ code e1211182202426 = 5609228713530 := by decide
theorem cert_e1211182202426 : check e1211182202426 [[],[]] .three = true := by decide
def e1211182202510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211182202510 : Closed e1211182202510 ∧ code e1211182202510 = 5609228713614 := by decide
theorem cert_e1211182202510 : check e1211182202510 [[],[]] .three = true := by decide
def e1211182202566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211182202566 : Closed e1211182202566 ∧ code e1211182202566 = 5609228713670 := by decide
theorem cert_e1211182202566 : check e1211182202566 [[],[]] .three = true := by decide
def e1211182202606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 2)) (.var 2))))))))
theorem wire_e1211182202606 : Closed e1211182202606 ∧ code e1211182202606 = 5609228713710 := by decide
theorem cert_e1211182202606 : check e1211182202606 [[],[]] .three = true := by decide
def e1211182204606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 4))))))))
theorem wire_e1211182204606 : Closed e1211182204606 ∧ code e1211182204606 = 5609228715710 := by decide
theorem cert_e1211182204606 : check e1211182204606 [[],[]] .three = true := by decide
def e1211182204638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 3))))))))
theorem wire_e1211182204638 : Closed e1211182204638 ∧ code e1211182204638 = 5609228715742 := by decide
theorem cert_e1211182204638 : check e1211182204638 [[],[]] .smaller = true := by decide
def e1211182204654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))))))
theorem wire_e1211182204654 : Closed e1211182204654 ∧ code e1211182204654 = 5609228715758 := by decide
theorem cert_e1211182204654 : check e1211182204654 [[],[]] .smaller = true := by decide
def e1211182204662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 1))))))))
theorem wire_e1211182204662 : Closed e1211182204662 ∧ code e1211182204662 = 5609228715766 := by decide
theorem cert_e1211182204662 : check e1211182204662 [[],[]] .smaller = true := by decide
def e1211182204666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 4)) (.var 0))))))))
theorem wire_e1211182204666 : Closed e1211182204666 ∧ code e1211182204666 = 5609228715770 := by decide
theorem cert_e1211182204666 : check e1211182204666 [[],[]] .three = true := by decide
def e1211182204766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 3))))))))
theorem wire_e1211182204766 : Closed e1211182204766 ∧ code e1211182204766 = 5609228715870 := by decide
theorem cert_e1211182204766 : check e1211182204766 [[],[]] .smaller = true := by decide
def e1211182204794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 3)) (.var 0))))))))
theorem wire_e1211182204794 : Closed e1211182204794 ∧ code e1211182204794 = 5609228715898 := by decide
theorem cert_e1211182204794 : check e1211182204794 [[],[]] .smaller = true := by decide
def e1211182204846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2))))))))
theorem wire_e1211182204846 : Closed e1211182204846 ∧ code e1211182204846 = 5609228715950 := by decide
theorem cert_e1211182204846 : check e1211182204846 [[],[]] .smaller = true := by decide
def e1211182204858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0))))))))
theorem wire_e1211182204858 : Closed e1211182204858 ∧ code e1211182204858 = 5609228715962 := by decide
theorem cert_e1211182204858 : check e1211182204858 [[],[]] .smaller = true := by decide
def e1211182204886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 1))))))))
theorem wire_e1211182204886 : Closed e1211182204886 ∧ code e1211182204886 = 5609228715990 := by decide
theorem cert_e1211182204886 : check e1211182204886 [[],[]] .smaller = true := by decide
def e1211182204890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 1)) (.var 0))))))))
theorem wire_e1211182204890 : Closed e1211182204890 ∧ code e1211182204890 = 5609228715994 := by decide
theorem cert_e1211182204890 : check e1211182204890 [[],[]] .smaller = true := by decide
def e1211182204906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 5))) (.var 0)) (.var 0))))))))
theorem wire_e1211182204906 : Closed e1211182204906 ∧ code e1211182204906 = 5609228716010 := by decide
theorem cert_e1211182204906 : check e1211182204906 [[],[]] .three = true := by decide
def e1211182206302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211182206302 : Closed e1211182206302 ∧ code e1211182206302 = 5609228717406 := by decide
theorem cert_e1211182206302 : check e1211182206302 [[],[]] .smaller = true := by decide
def e1211182206318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e1211182206318 : Closed e1211182206318 ∧ code e1211182206318 = 5609228717422 := by decide
theorem cert_e1211182206318 : check e1211182206318 [[],[]] .smaller = true := by decide
def e1211182206326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e1211182206326 : Closed e1211182206326 ∧ code e1211182206326 = 5609228717430 := by decide
theorem cert_e1211182206326 : check e1211182206326 [[],[]] .smaller = true := by decide
def e1211182206330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211182206330 : Closed e1211182206330 ∧ code e1211182206330 = 5609228717434 := by decide
theorem cert_e1211182206330 : check e1211182206330 [[],[]] .smaller = true := by decide
def e1211182206382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211182206382 : Closed e1211182206382 ∧ code e1211182206382 = 5609228717486 := by decide
theorem cert_e1211182206382 : check e1211182206382 [[],[]] .smaller = true := by decide
def e1211182206394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211182206394 : Closed e1211182206394 ∧ code e1211182206394 = 5609228717498 := by decide
theorem cert_e1211182206394 : check e1211182206394 [[],[]] .smaller = true := by decide
def e1211182206422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e1211182206422 : Closed e1211182206422 ∧ code e1211182206422 = 5609228717526 := by decide
theorem cert_e1211182206422 : check e1211182206422 [[],[]] .smaller = true := by decide
def e1211182206426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e1211182206426 : Closed e1211182206426 ∧ code e1211182206426 = 5609228717530 := by decide
theorem cert_e1211182206426 : check e1211182206426 [[],[]] .smaller = true := by decide
def e1211182206442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211182206442 : Closed e1211182206442 ∧ code e1211182206442 = 5609228717546 := by decide
theorem cert_e1211182206442 : check e1211182206442 [[],[]] .smaller = true := by decide
def e1211182206638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e1211182206638 : Closed e1211182206638 ∧ code e1211182206638 = 5609228717742 := by decide
theorem cert_e1211182206638 : check e1211182206638 [[],[]] .smaller = true := by decide
def e1211182206650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e1211182206650 : Closed e1211182206650 ∧ code e1211182206650 = 5609228717754 := by decide
theorem cert_e1211182206650 : check e1211182206650 [[],[]] .smaller = true := by decide
def e1211182206698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211182206698 : Closed e1211182206698 ∧ code e1211182206698 = 5609228717802 := by decide
theorem cert_e1211182206698 : check e1211182206698 [[],[]] .smaller = true := by decide
def e1211182206806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211182206806 : Closed e1211182206806 ∧ code e1211182206806 = 5609228717910 := by decide
theorem cert_e1211182206806 : check e1211182206806 [[],[]] .smaller = true := by decide
def e1211182206810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211182206810 : Closed e1211182206810 ∧ code e1211182206810 = 5609228717914 := by decide
theorem cert_e1211182206810 : check e1211182206810 [[],[]] .smaller = true := by decide
def e1211182206826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211182206826 : Closed e1211182206826 ∧ code e1211182206826 = 5609228717930 := by decide
theorem cert_e1211182206826 : check e1211182206826 [[],[]] .smaller = true := by decide
def e1211182206890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e1211182206890 : Closed e1211182206890 ∧ code e1211182206890 = 5609228717994 := by decide
theorem cert_e1211182206890 : check e1211182206890 [[],[]] .smaller = true := by decide
def e1211182207422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 4))))))))
theorem wire_e1211182207422 : Closed e1211182207422 ∧ code e1211182207422 = 5609228718526 := by decide
theorem cert_e1211182207422 : check e1211182207422 [[],[]] .three = true := by decide
def e1211182207454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211182207454 : Closed e1211182207454 ∧ code e1211182207454 = 5609228718558 := by decide
theorem cert_e1211182207454 : check e1211182207454 [[],[]] .smaller = true := by decide
def e1211182207470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211182207470 : Closed e1211182207470 ∧ code e1211182207470 = 5609228718574 := by decide
theorem cert_e1211182207470 : check e1211182207470 [[],[]] .smaller = true := by decide
def e1211182207478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211182207478 : Closed e1211182207478 ∧ code e1211182207478 = 5609228718582 := by decide
theorem cert_e1211182207478 : check e1211182207478 [[],[]] .smaller = true := by decide
def e1211182207482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 5))) (.var 0))))))))
theorem wire_e1211182207482 : Closed e1211182207482 ∧ code e1211182207482 = 5609228718586 := by decide
theorem cert_e1211182207482 : check e1211182207482 [[],[]] .three = true := by decide
def e1211182207838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211182207838 : Closed e1211182207838 ∧ code e1211182207838 = 5609228718942 := by decide
theorem cert_e1211182207838 : check e1211182207838 [[],[]] .smaller = true := by decide
def e1211182207854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211182207854 : Closed e1211182207854 ∧ code e1211182207854 = 5609228718958 := by decide
theorem cert_e1211182207854 : check e1211182207854 [[],[]] .smaller = true := by decide
def e1211182207862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211182207862 : Closed e1211182207862 ∧ code e1211182207862 = 5609228718966 := by decide
theorem cert_e1211182207862 : check e1211182207862 [[],[]] .smaller = true := by decide
def e1211182207866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211182207866 : Closed e1211182207866 ∧ code e1211182207866 = 5609228718970 := by decide
theorem cert_e1211182207866 : check e1211182207866 [[],[]] .smaller = true := by decide
def e1211182207918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211182207918 : Closed e1211182207918 ∧ code e1211182207918 = 5609228719022 := by decide
theorem cert_e1211182207918 : check e1211182207918 [[],[]] .smaller = true := by decide
def e1211182207930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211182207930 : Closed e1211182207930 ∧ code e1211182207930 = 5609228719034 := by decide
theorem cert_e1211182207930 : check e1211182207930 [[],[]] .smaller = true := by decide
def e1211182207958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211182207958 : Closed e1211182207958 ∧ code e1211182207958 = 5609228719062 := by decide
theorem cert_e1211182207958 : check e1211182207958 [[],[]] .smaller = true := by decide
def e1211182207962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211182207962 : Closed e1211182207962 ∧ code e1211182207962 = 5609228719066 := by decide
theorem cert_e1211182207962 : check e1211182207962 [[],[]] .smaller = true := by decide
def e1211182207978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211182207978 : Closed e1211182207978 ∧ code e1211182207978 = 5609228719082 := by decide
theorem cert_e1211182207978 : check e1211182207978 [[],[]] .smaller = true := by decide
def e1211182208126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 5)))))))))
theorem wire_e1211182208126 : Closed e1211182208126 ∧ code e1211182208126 = 5609228719230 := by decide
theorem cert_e1211182208126 : check e1211182208126 [[],[]] .three = true := by decide
def e1211182208222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182208222 : Closed e1211182208222 ∧ code e1211182208222 = 5609228719326 := by decide
theorem cert_e1211182208222 : check e1211182208222 [[],[]] .smaller = true := by decide
def e1211182208238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182208238 : Closed e1211182208238 ∧ code e1211182208238 = 5609228719342 := by decide
theorem cert_e1211182208238 : check e1211182208238 [[],[]] .smaller = true := by decide
def e1211182208246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182208246 : Closed e1211182208246 ∧ code e1211182208246 = 5609228719350 := by decide
theorem cert_e1211182208246 : check e1211182208246 [[],[]] .smaller = true := by decide
def e1211182208250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182208250 : Closed e1211182208250 ∧ code e1211182208250 = 5609228719354 := by decide
theorem cert_e1211182208250 : check e1211182208250 [[],[]] .smaller = true := by decide
def e1211182208574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211182208574 : Closed e1211182208574 ∧ code e1211182208574 = 5609228719678 := by decide
theorem cert_e1211182208574 : check e1211182208574 [[],[]] .smaller = true := by decide
def e1211182208622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182208622 : Closed e1211182208622 ∧ code e1211182208622 = 5609228719726 := by decide
theorem cert_e1211182208622 : check e1211182208622 [[],[]] .smaller = true := by decide
def e1211182208634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182208634 : Closed e1211182208634 ∧ code e1211182208634 = 5609228719738 := by decide
theorem cert_e1211182208634 : check e1211182208634 [[],[]] .smaller = true := by decide
def e1211182208798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211182208798 : Closed e1211182208798 ∧ code e1211182208798 = 5609228719902 := by decide
theorem cert_e1211182208798 : check e1211182208798 [[],[]] .smaller = true := by decide
def e1211182208822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182208822 : Closed e1211182208822 ∧ code e1211182208822 = 5609228719926 := by decide
theorem cert_e1211182208822 : check e1211182208822 [[],[]] .smaller = true := by decide
def e1211182208826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182208826 : Closed e1211182208826 ∧ code e1211182208826 = 5609228719930 := by decide
theorem cert_e1211182208826 : check e1211182208826 [[],[]] .smaller = true := by decide
def e1211182208910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211182208910 : Closed e1211182208910 ∧ code e1211182208910 = 5609228720014 := by decide
theorem cert_e1211182208910 : check e1211182208910 [[],[]] .smaller = true := by decide
def e1211182208922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182208922 : Closed e1211182208922 ∧ code e1211182208922 = 5609228720026 := by decide
theorem cert_e1211182208922 : check e1211182208922 [[],[]] .smaller = true := by decide
def e1211182208966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.lam (.var 1)))))))))
theorem wire_e1211182208966 : Closed e1211182208966 ∧ code e1211182208966 = 5609228720070 := by decide
theorem cert_e1211182208966 : check e1211182208966 [[],[]] .three = true := by decide
def e1211182209246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211182209246 : Closed e1211182209246 ∧ code e1211182209246 = 5609228720350 := by decide
theorem cert_e1211182209246 : check e1211182209246 [[],[]] .smaller = true := by decide
def e1211182209274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211182209274 : Closed e1211182209274 ∧ code e1211182209274 = 5609228720378 := by decide
theorem cert_e1211182209274 : check e1211182209274 [[],[]] .smaller = true := by decide
def e1211182209454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211182209454 : Closed e1211182209454 ∧ code e1211182209454 = 5609228720558 := by decide
theorem cert_e1211182209454 : check e1211182209454 [[],[]] .smaller = true := by decide
def e1211182209466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211182209466 : Closed e1211182209466 ∧ code e1211182209466 = 5609228720570 := by decide
theorem cert_e1211182209466 : check e1211182209466 [[],[]] .smaller = true := by decide
def e1211182209514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211182209514 : Closed e1211182209514 ∧ code e1211182209514 = 5609228720618 := by decide
theorem cert_e1211182209514 : check e1211182209514 [[],[]] .smaller = true := by decide
def e1211182209598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211182209598 : Closed e1211182209598 ∧ code e1211182209598 = 5609228720702 := by decide
theorem cert_e1211182209598 : check e1211182209598 [[],[]] .smaller = true := by decide
def e1211182209646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182209646 : Closed e1211182209646 ∧ code e1211182209646 = 5609228720750 := by decide
theorem cert_e1211182209646 : check e1211182209646 [[],[]] .smaller = true := by decide
def e1211182209658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182209658 : Closed e1211182209658 ∧ code e1211182209658 = 5609228720762 := by decide
theorem cert_e1211182209658 : check e1211182209658 [[],[]] .smaller = true := by decide
def e1211182209946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182209946 : Closed e1211182209946 ∧ code e1211182209946 = 5609228721050 := by decide
theorem cert_e1211182209946 : check e1211182209946 [[],[]] .smaller = true := by decide
def e1211182209982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 4))))))))
theorem wire_e1211182209982 : Closed e1211182209982 ∧ code e1211182209982 = 5609228721086 := by decide
theorem cert_e1211182209982 : check e1211182209982 [[],[]] .three = true := by decide
def e1211182209990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211182209990 : Closed e1211182209990 ∧ code e1211182209990 = 5609228721094 := by decide
theorem cert_e1211182209990 : check e1211182209990 [[],[]] .smaller = true := by decide
def e1211182210030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.var 2))))))))
theorem wire_e1211182210030 : Closed e1211182210030 ∧ code e1211182210030 = 5609228721134 := by decide
theorem cert_e1211182210030 : check e1211182210030 [[],[]] .three = true := by decide
def e1211182210158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211182210158 : Closed e1211182210158 ∧ code e1211182210158 = 5609228721262 := by decide
theorem cert_e1211182210158 : check e1211182210158 [[],[]] .smaller = true := by decide
def e1211182210170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211182210170 : Closed e1211182210170 ∧ code e1211182210170 = 5609228721274 := by decide
theorem cert_e1211182210170 : check e1211182210170 [[],[]] .smaller = true := by decide
def e1211182210262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211182210262 : Closed e1211182210262 ∧ code e1211182210262 = 5609228721366 := by decide
theorem cert_e1211182210262 : check e1211182210262 [[],[]] .smaller = true := by decide
def e1211182210266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211182210266 : Closed e1211182210266 ∧ code e1211182210266 = 5609228721370 := by decide
theorem cert_e1211182210266 : check e1211182210266 [[],[]] .smaller = true := by decide
def e1211182210282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211182210282 : Closed e1211182210282 ∧ code e1211182210282 = 5609228721386 := by decide
theorem cert_e1211182210282 : check e1211182210282 [[],[]] .smaller = true := by decide
def e1211182210334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211182210334 : Closed e1211182210334 ∧ code e1211182210334 = 5609228721438 := by decide
theorem cert_e1211182210334 : check e1211182210334 [[],[]] .smaller = true := by decide
def e1211182210358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182210358 : Closed e1211182210358 ∧ code e1211182210358 = 5609228721462 := by decide
theorem cert_e1211182210358 : check e1211182210358 [[],[]] .smaller = true := by decide
def e1211182210362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182210362 : Closed e1211182210362 ∧ code e1211182210362 = 5609228721466 := by decide
theorem cert_e1211182210362 : check e1211182210362 [[],[]] .smaller = true := by decide
def e1211182210458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182210458 : Closed e1211182210458 ∧ code e1211182210458 = 5609228721562 := by decide
theorem cert_e1211182210458 : check e1211182210458 [[],[]] .smaller = true := by decide
def e1211182210494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 4))))))))
theorem wire_e1211182210494 : Closed e1211182210494 ∧ code e1211182210494 = 5609228721598 := by decide
theorem cert_e1211182210494 : check e1211182210494 [[],[]] .three = true := by decide
end Blc.Floor42
