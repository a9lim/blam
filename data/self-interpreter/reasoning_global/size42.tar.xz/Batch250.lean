import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211298978282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211298978282 : Closed e1211298978282 ∧ code e1211298978282 = 5609345489386 := by decide
theorem cert_e1211298978282 : checkPay e1211298978282 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left,.left,.right],[.under,.left,.left,.left,.right,.left,.right,.right]] = true := by decide
def e1211298978414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298978414 : Closed e1211298978414 ∧ code e1211298978414 = 5609345489518 := by decide
def e1211298978426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298978426 : Closed e1211298978426 ∧ code e1211298978426 = 5609345489530 := by decide
def e1211298978590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211298978590 : Closed e1211298978590 ∧ code e1211298978590 = 5609345489694 := by decide
theorem cert_e1211298978590 : checkPay e1211298978590 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left]] = true := by decide
def e1211298978690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298978690 : Closed e1211298978690 ∧ code e1211298978690 = 5609345489794 := by decide
theorem cert_e1211298978690 : checkPay e1211298978690 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298978702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211298978702 : Closed e1211298978702 ∧ code e1211298978702 = 5609345489806 := by decide
theorem cert_e1211298978702 : checkPay e1211298978702 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298978714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298978714 : Closed e1211298978714 ∧ code e1211298978714 = 5609345489818 := by decide
def e1211298978926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211298978926 : Closed e1211298978926 ∧ code e1211298978926 = 5609345490030 := by decide
theorem cert_e1211298978926 : checkPay e1211298978926 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.right,.under,.under,.left],[.right,.under,.under,.left,.left,.left],[.right,.under,.under,.left,.left,.left,.left]] = true := by decide
def e1211298978938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211298978938 : Closed e1211298978938 ∧ code e1211298978938 = 5609345490042 := by decide
theorem cert_e1211298978938 : checkPay e1211298978938 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298979102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211298979102 : Closed e1211298979102 ∧ code e1211298979102 = 5609345490206 := by decide
theorem cert_e1211298979102 : checkPay e1211298979102 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.right,.under,.left],[.right,.under,.left,.left,.left]] = true := by decide
def e1211298979270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211298979270 : Closed e1211298979270 ∧ code e1211298979270 = 5609345490374 := by decide
theorem cert_e1211298979270 : checkPay e1211298979270 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298979338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211298979338 : Closed e1211298979338 ∧ code e1211298979338 = 5609345490442 := by decide
theorem cert_e1211298979338 : checkPay e1211298979338 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.right],[.under,.left,.left,.left,.left,.right,.under]] = true := by decide
def e1211298979382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211298979382 : Closed e1211298979382 ∧ code e1211298979382 = 5609345490486 := by decide
theorem cert_e1211298979382 : checkPay e1211298979382 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.right],[.under,.under,.left,.left,.left,.left,.right,.under]] = true := by decide
def e1211298979386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211298979386 : Closed e1211298979386 ∧ code e1211298979386 = 5609345490490 := by decide
theorem cert_e1211298979386 : checkPay e1211298979386 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.under]] = true := by decide
def e1211298979434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211298979434 : Closed e1211298979434 ∧ code e1211298979434 = 5609345490538 := by decide
theorem cert_e1211298979434 : checkPay e1211298979434 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.right]] = true := by decide
def e1211298979458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298979458 : Closed e1211298979458 ∧ code e1211298979458 = 5609345490562 := by decide
theorem cert_e1211298979458 : checkPay e1211298979458 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298979470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211298979470 : Closed e1211298979470 ∧ code e1211298979470 = 5609345490574 := by decide
theorem cert_e1211298979470 : checkPay e1211298979470 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298979482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298979482 : Closed e1211298979482 ∧ code e1211298979482 = 5609345490586 := by decide
def e1211298979526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211298979526 : Closed e1211298979526 ∧ code e1211298979526 = 5609345490630 := by decide
theorem cert_e1211298979526 : checkPay e1211298979526 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[]] = true := by decide
def e1211298980318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211298980318 : Closed e1211298980318 ∧ code e1211298980318 = 5609345491422 := by decide
theorem cert_e1211298980318 : checkPay e1211298980318 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e1211298980342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211298980342 : Closed e1211298980342 ∧ code e1211298980342 = 5609345491446 := by decide
theorem cert_e1211298980342 : checkPay e1211298980342 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right,.under],[.under,.right,.under,.right,.under]] = true := by decide
def e1211298981294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211298981294 : Closed e1211298981294 ∧ code e1211298981294 = 5609345492398 := by decide
theorem cert_e1211298981294 : checkPay e1211298981294 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e1211298981306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211298981306 : Closed e1211298981306 ∧ code e1211298981306 = 5609345492410 := by decide
theorem cert_e1211298981306 : checkPay e1211298981306 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e1211298981354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211298981354 : Closed e1211298981354 ∧ code e1211298981354 = 5609345492458 := by decide
theorem cert_e1211298981354 : checkPay e1211298981354 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right,.left],[.under,.right,.left,.right,.left],[.under,.right,.left,.right]] = true := by decide
def e1211298981486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298981486 : Closed e1211298981486 ∧ code e1211298981486 = 5609345492590 := by decide
theorem cert_e1211298981486 : checkPay e1211298981486 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e1211298981498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298981498 : Closed e1211298981498 ∧ code e1211298981498 = 5609345492602 := by decide
theorem cert_e1211298981498 : checkPay e1211298981498 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right,.right],[.under,.right,.right,.right,.right]] = true := by decide
def e1211298981662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211298981662 : Closed e1211298981662 ∧ code e1211298981662 = 5609345492766 := by decide
theorem cert_e1211298981662 : checkPay e1211298981662 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.left],[.under,.right]] = true := by decide
def e1211298981762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298981762 : Closed e1211298981762 ∧ code e1211298981762 = 5609345492866 := by decide
theorem cert_e1211298981762 : checkPay e1211298981762 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.right],[.under,.right,.right,.under]] = true := by decide
def e1211298981774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211298981774 : Closed e1211298981774 ∧ code e1211298981774 = 5609345492878 := by decide
theorem cert_e1211298981774 : checkPay e1211298981774 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.right],[.under,.right,.right,.under]] = true := by decide
def e1211298981786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298981786 : Closed e1211298981786 ∧ code e1211298981786 = 5609345492890 := by decide
theorem cert_e1211298981786 : checkPay e1211298981786 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.right]] = true := by decide
def e1211298984734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211298984734 : Closed e1211298984734 ∧ code e1211298984734 = 5609345495838 := by decide
theorem cert_e1211298984734 : checkPay e1211298984734 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298984902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211298984902 : Closed e1211298984902 ∧ code e1211298984902 = 5609345496006 := by decide
theorem cert_e1211298984902 : checkPay e1211298984902 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211298986102 : Closed e1211298986102 ∧ code e1211298986102 = 5609345497206 := by decide
theorem cert_e1211298986102 : checkPay e1211298986102 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211298986346 : Closed e1211298986346 ∧ code e1211298986346 = 5609345497450 := by decide
theorem cert_e1211298986346 : checkPay e1211298986346 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298986370 : Closed e1211298986370 ∧ code e1211298986370 = 5609345497474 := by decide
theorem cert_e1211298986370 : checkPay e1211298986370 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211298986382 : Closed e1211298986382 ∧ code e1211298986382 = 5609345497486 := by decide
theorem cert_e1211298986382 : checkPay e1211298986382 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298986394 : Closed e1211298986394 ∧ code e1211298986394 = 5609345497498 := by decide
theorem cert_e1211298986394 : checkPay e1211298986394 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298986438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211298986438 : Closed e1211298986438 ∧ code e1211298986438 = 5609345497542 := by decide
theorem cert_e1211298986438 : checkPay e1211298986438 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298988342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298988342 : Closed e1211298988342 ∧ code e1211298988342 = 5609345499446 := by decide
theorem cert_e1211298988342 : check e1211298988342 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211298988346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298988346 : Closed e1211298988346 ∧ code e1211298988346 = 5609345499450 := by decide
theorem cert_e1211298988346 : check e1211298988346 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211298988982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1211298988982 : Closed e1211298988982 ∧ code e1211298988982 = 5609345500086 := by decide
private def t_e1211298988982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem cert_e1211298988982 : ¬ IsSelfInterpreter e1211298988982 :=
  wSource (t := t_e1211298988982) (replay_sound (ps := []) (t := e1211298988982) (by decide)) (by decide)
def e1211298988986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211298988986 : Closed e1211298988986 ∧ code e1211298988986 = 5609345500090 := by decide
theorem cert_e1211298988986 : check e1211298988986 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211298989018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211298989018 : Closed e1211298989018 ∧ code e1211298989018 = 5609345500122 := by decide
theorem cert_e1211298989018 : check e1211298989018 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211298989686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211298989686 : Closed e1211298989686 ∧ code e1211298989686 = 5609345500790 := by decide
theorem cert_e1211298989686 : check e1211298989686 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211298989878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298989878 : Closed e1211298989878 ∧ code e1211298989878 = 5609345500982 := by decide
theorem cert_e1211298989878 : check e1211298989878 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e1211298989882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298989882 : Closed e1211298989882 ∧ code e1211298989882 = 5609345500986 := by decide
theorem cert_e1211298989882 : check e1211298989882 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e1211298990934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211298990934 : Closed e1211298990934 ∧ code e1211298990934 = 5609345502038 := by decide
private def t_e1211298990934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem cert_e1211298990934 : ¬ IsSelfInterpreter e1211298990934 :=
  wSource (t := t_e1211298990934) (replay_sound (ps := []) (t := e1211298990934) (by decide)) (by decide)
def e1211298990938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211298990938 : Closed e1211298990938 ∧ code e1211298990938 = 5609345502042 := by decide
private def t_e1211298990938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem cert_e1211298990938 : ¬ IsSelfInterpreter e1211298990938 :=
  wSource (t := t_e1211298990938) (replay_sound (ps := []) (t := e1211298990938) (by decide)) (by decide)
def e1211298990954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211298990954 : Closed e1211298990954 ∧ code e1211298990954 = 5609345502058 := by decide
theorem cert_e1211298990954 : check e1211298990954 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298991018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1211298991018 : Closed e1211298991018 ∧ code e1211298991018 = 5609345502122 := by decide
theorem cert_e1211298991018 : check e1211298991018 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211298991126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211298991126 : Closed e1211298991126 ∧ code e1211298991126 = 5609345502230 := by decide
theorem cert_e1211298991126 : check e1211298991126 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1211298991222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211298991222 : Closed e1211298991222 ∧ code e1211298991222 = 5609345502326 := by decide
theorem cert_e1211298991222 : check e1211298991222 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298991318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211298991318 : Closed e1211298991318 ∧ code e1211298991318 = 5609345502422 := by decide
private def t_e1211298991318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem cert_e1211298991318 : ¬ IsSelfInterpreter e1211298991318 :=
  wSource (t := t_e1211298991318) (replay_sound (ps := []) (t := e1211298991318) (by decide)) (by decide)
def e1211298991322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211298991322 : Closed e1211298991322 ∧ code e1211298991322 = 5609345502426 := by decide
def e1211298991338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211298991338 : Closed e1211298991338 ∧ code e1211298991338 = 5609345502442 := by decide
def e1211298991414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298991414 : Closed e1211298991414 ∧ code e1211298991414 = 5609345502518 := by decide
private def t_e1211298991414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298991414 : ¬ IsSelfInterpreter e1211298991414 :=
  wSource (t := t_e1211298991414) (replay_sound (ps := []) (t := e1211298991414) (by decide)) (by decide)
def e1211298991418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298991418 : Closed e1211298991418 ∧ code e1211298991418 = 5609345502522 := by decide
private def t_e1211298991418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298991418 : ¬ IsSelfInterpreter e1211298991418 :=
  wSource (t := t_e1211298991418) (replay_sound (ps := []) (t := e1211298991418) (by decide)) (by decide)
def e1211298991490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298991490 : Closed e1211298991490 ∧ code e1211298991490 = 5609345502594 := by decide
theorem cert_e1211298991490 : check e1211298991490 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1211298991502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211298991502 : Closed e1211298991502 ∧ code e1211298991502 = 5609345502606 := by decide
theorem cert_e1211298991502 : check e1211298991502 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298991514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298991514 : Closed e1211298991514 ∧ code e1211298991514 = 5609345502618 := by decide
theorem cert_e1211298991514 : check e1211298991514 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298991626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211298991626 : Closed e1211298991626 ∧ code e1211298991626 = 5609345502730 := by decide
theorem cert_e1211298991626 : check e1211298991626 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211298991670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211298991670 : Closed e1211298991670 ∧ code e1211298991670 = 5609345502774 := by decide
theorem cert_e1211298991670 : checkPay e1211298991670 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.right,.under],[.under,.under,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.under],[.under,.under,.left,.right,.under,.left,.left,.right,.under,.left]] = true := by decide
def e1211298991674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211298991674 : Closed e1211298991674 ∧ code e1211298991674 = 5609345502778 := by decide
theorem cert_e1211298991674 : checkPay e1211298991674 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [] = true := by decide
def e1211298991722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211298991722 : Closed e1211298991722 ∧ code e1211298991722 = 5609345502826 := by decide
def e1211298991746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298991746 : Closed e1211298991746 ∧ code e1211298991746 = 5609345502850 := by decide
theorem cert_e1211298991746 : checkPay e1211298991746 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right],[.under,.left,.right,.under,.left,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1211298991758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211298991758 : Closed e1211298991758 ∧ code e1211298991758 = 5609345502862 := by decide
theorem cert_e1211298991758 : checkPay e1211298991758 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right],[.under,.left,.right,.under,.left,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1211298991770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298991770 : Closed e1211298991770 ∧ code e1211298991770 = 5609345502874 := by decide
theorem cert_e1211298991770 : checkPay e1211298991770 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right],[.under,.left,.right,.under,.left,.left,.right],[.under,.left,.right,.under,.left,.right,.left,.left],[.under,.left,.right,.under,.left,.right,.left,.right]] = true := by decide
def e1211298991814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211298991814 : Closed e1211298991814 ∧ code e1211298991814 = 5609345502918 := by decide
theorem cert_e1211298991814 : checkPay e1211298991814 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [] = true := by decide
def e1211298992366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211298992366 : Closed e1211298992366 ∧ code e1211298992366 = 5609345503470 := by decide
private def t_e1211298992366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e1211298992366 : ¬ IsSelfInterpreter e1211298992366 :=
  wSource (t := t_e1211298992366) (replay_sound (ps := []) (t := e1211298992366) (by decide)) (by decide)
def e1211298992374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211298992374 : Closed e1211298992374 ∧ code e1211298992374 = 5609345503478 := by decide
private def t_e1211298992374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e1211298992374 : ¬ IsSelfInterpreter e1211298992374 :=
  wSource (t := t_e1211298992374) (replay_sound (ps := []) (t := e1211298992374) (by decide)) (by decide)
def e1211298992854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211298992854 : Closed e1211298992854 ∧ code e1211298992854 = 5609345503958 := by decide
private def t_e1211298992854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1211298992854 : ¬ IsSelfInterpreter e1211298992854 :=
  wSource (t := t_e1211298992854) (replay_sound (ps := []) (t := e1211298992854) (by decide)) (by decide)
def e1211298992858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211298992858 : Closed e1211298992858 ∧ code e1211298992858 = 5609345503962 := by decide
private def t_e1211298992858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e1211298992858 : ¬ IsSelfInterpreter e1211298992858 :=
  wSource (t := t_e1211298992858) (replay_sound (ps := []) (t := e1211298992858) (by decide)) (by decide)
def e1211298992874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211298992874 : Closed e1211298992874 ∧ code e1211298992874 = 5609345503978 := by decide
private def t_e1211298992874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e1211298992874 : ¬ IsSelfInterpreter e1211298992874 :=
  wSource (t := t_e1211298992874) (replay_sound (ps := []) (t := e1211298992874) (by decide)) (by decide)
def e1211298992950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298992950 : Closed e1211298992950 ∧ code e1211298992950 = 5609345504054 := by decide
private def t_e1211298992950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211298992950 : ¬ IsSelfInterpreter e1211298992950 :=
  wSource (t := t_e1211298992950) (replay_sound (ps := []) (t := e1211298992950) (by decide)) (by decide)
def e1211298992954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298992954 : Closed e1211298992954 ∧ code e1211298992954 = 5609345504058 := by decide
private def t_e1211298992954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211298992954 : ¬ IsSelfInterpreter e1211298992954 :=
  wSource (t := t_e1211298992954) (replay_sound (ps := []) (t := e1211298992954) (by decide)) (by decide)
def e1211298993026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298993026 : Closed e1211298993026 ∧ code e1211298993026 = 5609345504130 := by decide
private def t_e1211298993026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem cert_e1211298993026 : ¬ IsSelfInterpreter e1211298993026 :=
  wSource (t := t_e1211298993026) (replay_sound (ps := []) (t := e1211298993026) (by decide)) (by decide)
def e1211298993038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211298993038 : Closed e1211298993038 ∧ code e1211298993038 = 5609345504142 := by decide
private def t_e1211298993038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem cert_e1211298993038 : ¬ IsSelfInterpreter e1211298993038 :=
  wSource (t := t_e1211298993038) (replay_sound (ps := []) (t := e1211298993038) (by decide)) (by decide)
def e1211298993050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298993050 : Closed e1211298993050 ∧ code e1211298993050 = 5609345504154 := by decide
private def t_e1211298993050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211298993050 : ¬ IsSelfInterpreter e1211298993050 :=
  wSource (t := t_e1211298993050) (replay_sound (ps := []) (t := e1211298993050) (by decide)) (by decide)
def e1211298994294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211298994294 : Closed e1211298994294 ∧ code e1211298994294 = 5609345505398 := by decide
theorem cert_e1211298994294 : check e1211298994294 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211298994538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211298994538 : Closed e1211298994538 ∧ code e1211298994538 = 5609345505642 := by decide
theorem cert_e1211298994538 : check e1211298994538 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211298994562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298994562 : Closed e1211298994562 ∧ code e1211298994562 = 5609345505666 := by decide
theorem cert_e1211298994562 : check e1211298994562 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211298994574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211298994574 : Closed e1211298994574 ∧ code e1211298994574 = 5609345505678 := by decide
theorem cert_e1211298994574 : check e1211298994574 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211298994586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298994586 : Closed e1211298994586 ∧ code e1211298994586 = 5609345505690 := by decide
theorem cert_e1211298994586 : check e1211298994586 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211298994630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211298994630 : Closed e1211298994630 ∧ code e1211298994630 = 5609345505734 := by decide
theorem cert_e1211298994630 : check e1211298994630 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211299007342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211299007342 : Closed e1211299007342 ∧ code e1211299007342 = 5609345518446 := by decide
theorem cert_e1211299007342 : check e1211299007342 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299007350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211299007350 : Closed e1211299007350 ∧ code e1211299007350 = 5609345518454 := by decide
theorem cert_e1211299007350 : check e1211299007350 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299007406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211299007406 : Closed e1211299007406 ∧ code e1211299007406 = 5609345518510 := by decide
theorem cert_e1211299007406 : check e1211299007406 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299007418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211299007418 : Closed e1211299007418 ∧ code e1211299007418 = 5609345518522 := by decide
private def t_e1211299007418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem cert_e1211299007418 : ¬ IsSelfInterpreter e1211299007418 :=
  wSource (t := t_e1211299007418) (replay_sound (ps := []) (t := e1211299007418) (by decide)) (by decide)
def e1211299007446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211299007446 : Closed e1211299007446 ∧ code e1211299007446 = 5609345518550 := by decide
theorem cert_e1211299007446 : check e1211299007446 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299007450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211299007450 : Closed e1211299007450 ∧ code e1211299007450 = 5609345518554 := by decide
private def t_e1211299007450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem cert_e1211299007450 : ¬ IsSelfInterpreter e1211299007450 :=
  wSource (t := t_e1211299007450) (replay_sound (ps := []) (t := e1211299007450) (by decide)) (by decide)
def e1211299007726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211299007726 : Closed e1211299007726 ∧ code e1211299007726 = 5609345518830 := by decide
theorem cert_e1211299007726 : check e1211299007726 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299007734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211299007734 : Closed e1211299007734 ∧ code e1211299007734 = 5609345518838 := by decide
theorem cert_e1211299007734 : check e1211299007734 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211299008110 : Closed e1211299008110 ∧ code e1211299008110 = 5609345519214 := by decide
theorem cert_e1211299008110 : check e1211299008110 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211299008122 : Closed e1211299008122 ∧ code e1211299008122 = 5609345519226 := by decide
theorem cert_e1211299008122 : check e1211299008122 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211299008310 : Closed e1211299008310 ∧ code e1211299008310 = 5609345519414 := by decide
theorem cert_e1211299008310 : check e1211299008310 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211299008314 : Closed e1211299008314 ∧ code e1211299008314 = 5609345519418 := by decide
theorem cert_e1211299008314 : check e1211299008314 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211299008446 : Closed e1211299008446 ∧ code e1211299008446 = 5609345519550 := by decide
theorem cert_e1211299008446 : check e1211299008446 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299008478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211299008478 : Closed e1211299008478 ∧ code e1211299008478 = 5609345519582 := by decide
theorem cert_e1211299008478 : check e1211299008478 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299016158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211299016158 : Closed e1211299016158 ∧ code e1211299016158 = 5609345527262 := by decide
theorem cert_e1211299016158 : check e1211299016158 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211299016174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211299016174 : Closed e1211299016174 ∧ code e1211299016174 = 5609345527278 := by decide
private def t_e1211299016174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem cert_e1211299016174 : ¬ IsSelfInterpreter e1211299016174 :=
  wSource (t := t_e1211299016174) (replay_sound (ps := []) (t := e1211299016174) (by decide)) (by decide)
def e1211299016542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211299016542 : Closed e1211299016542 ∧ code e1211299016542 = 5609345527646 := by decide
theorem cert_e1211299016542 : checkPay e1211299016542 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[]] 0 [[.under,.left]] = true := by decide
def e1211299016570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211299016570 : Closed e1211299016570 ∧ code e1211299016570 = 5609345527674 := by decide
theorem cert_e1211299016570 : checkPay e1211299016570 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[]] 0 [] = true := by decide
def e1211299016622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211299016622 : Closed e1211299016622 ∧ code e1211299016622 = 5609345527726 := by decide
private def t_e1211299016622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem cert_e1211299016622 : ¬ IsSelfInterpreter e1211299016622 :=
  wSource (t := t_e1211299016622) (replay_sound (ps := []) (t := e1211299016622) (by decide)) (by decide)
def e1211299016634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211299016634 : Closed e1211299016634 ∧ code e1211299016634 = 5609345527738 := by decide
theorem cert_e1211299016634 : check e1211299016634 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211299017694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211299017694 : Closed e1211299017694 ∧ code e1211299017694 = 5609345528798 := by decide
theorem cert_e1211299017694 : checkPay e1211299017694 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[],[]] 0 [] = true := by decide
def e1211299017710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211299017710 : Closed e1211299017710 ∧ code e1211299017710 = 5609345528814 := by decide
theorem cert_e1211299017710 : check e1211299017710 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211299019998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211299019998 : Closed e1211299019998 ∧ code e1211299019998 = 5609345531102 := by decide
theorem cert_e1211299019998 : check e1211299019998 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299020026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211299020026 : Closed e1211299020026 ∧ code e1211299020026 = 5609345531130 := by decide
theorem cert_e1211299020026 : check e1211299020026 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299020398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211299020398 : Closed e1211299020398 ∧ code e1211299020398 = 5609345531502 := by decide
theorem cert_e1211299020398 : check e1211299020398 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299020410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211299020410 : Closed e1211299020410 ∧ code e1211299020410 = 5609345531514 := by decide
theorem cert_e1211299020410 : check e1211299020410 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299048814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211299048814 : Closed e1211299048814 ∧ code e1211299048814 = 5609345559918 := by decide
private def t_e1211299048814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem cert_e1211299048814 : ¬ IsSelfInterpreter e1211299048814 :=
  wSource (t := t_e1211299048814) (replay_sound (ps := []) (t := e1211299048814) (by decide)) (by decide)
def e1211299048822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211299048822 : Closed e1211299048822 ∧ code e1211299048822 = 5609345559926 := by decide
private def t_e1211299048822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem cert_e1211299048822 : ¬ IsSelfInterpreter e1211299048822 :=
  wSource (t := t_e1211299048822) (replay_sound (ps := []) (t := e1211299048822) (by decide)) (by decide)
def e1211299048878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211299048878 : Closed e1211299048878 ∧ code e1211299048878 = 5609345559982 := by decide
theorem cert_e1211299048878 : check e1211299048878 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211299048890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211299048890 : Closed e1211299048890 ∧ code e1211299048890 = 5609345559994 := by decide
theorem cert_e1211299048890 : check e1211299048890 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211299048918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211299048918 : Closed e1211299048918 ∧ code e1211299048918 = 5609345560022 := by decide
private def t_e1211299048918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e1211299048918 : ¬ IsSelfInterpreter e1211299048918 :=
  wSource (t := t_e1211299048918) (replay_sound (ps := []) (t := e1211299048918) (by decide)) (by decide)
def e1211299048922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211299048922 : Closed e1211299048922 ∧ code e1211299048922 = 5609345560026 := by decide
private def t_e1211299048922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e1211299048922 : ¬ IsSelfInterpreter e1211299048922 :=
  wSource (t := t_e1211299048922) (replay_sound (ps := []) (t := e1211299048922) (by decide)) (by decide)
def e1211299049134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211299049134 : Closed e1211299049134 ∧ code e1211299049134 = 5609345560238 := by decide
theorem cert_e1211299049134 : check e1211299049134 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299049146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211299049146 : Closed e1211299049146 ∧ code e1211299049146 = 5609345560250 := by decide
theorem cert_e1211299049146 : check e1211299049146 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299049194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211299049194 : Closed e1211299049194 ∧ code e1211299049194 = 5609345560298 := by decide
theorem cert_e1211299049194 : check e1211299049194 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299049302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211299049302 : Closed e1211299049302 ∧ code e1211299049302 = 5609345560406 := by decide
private def t_e1211299049302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem cert_e1211299049302 : ¬ IsSelfInterpreter e1211299049302 :=
  wSource (t := t_e1211299049302) (replay_sound (ps := []) (t := e1211299049302) (by decide)) (by decide)
def e1211299049306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211299049306 : Closed e1211299049306 ∧ code e1211299049306 = 5609345560410 := by decide
private def t_e1211299049306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem cert_e1211299049306 : ¬ IsSelfInterpreter e1211299049306 :=
  wSource (t := t_e1211299049306) (replay_sound (ps := []) (t := e1211299049306) (by decide)) (by decide)
def e1211299049322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211299049322 : Closed e1211299049322 ∧ code e1211299049322 = 5609345560426 := by decide
theorem cert_e1211299049322 : check e1211299049322 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299050350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211299050350 : Closed e1211299050350 ∧ code e1211299050350 = 5609345561454 := by decide
theorem cert_e1211299050350 : check e1211299050350 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211299050358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211299050358 : Closed e1211299050358 ∧ code e1211299050358 = 5609345561462 := by decide
private def t_e1211299050358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem cert_e1211299050358 : ¬ IsSelfInterpreter e1211299050358 :=
  wSource (t := t_e1211299050358) (replay_sound (ps := []) (t := e1211299050358) (by decide)) (by decide)
def e1211299050414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211299050414 : Closed e1211299050414 ∧ code e1211299050414 = 5609345561518 := by decide
theorem cert_e1211299050414 : check e1211299050414 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299050426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211299050426 : Closed e1211299050426 ∧ code e1211299050426 = 5609345561530 := by decide
theorem cert_e1211299050426 : check e1211299050426 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299050454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211299050454 : Closed e1211299050454 ∧ code e1211299050454 = 5609345561558 := by decide
private def t_e1211299050454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem cert_e1211299050454 : ¬ IsSelfInterpreter e1211299050454 :=
  wSource (t := t_e1211299050454) (replay_sound (ps := []) (t := e1211299050454) (by decide)) (by decide)
def e1211299050458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211299050458 : Closed e1211299050458 ∧ code e1211299050458 = 5609345561562 := by decide
theorem cert_e1211299050458 : check e1211299050458 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299050734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211299050734 : Closed e1211299050734 ∧ code e1211299050734 = 5609345561838 := by decide
private def t_e1211299050734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211299050734 : ¬ IsSelfInterpreter e1211299050734 :=
  wSource (t := t_e1211299050734) (replay_sound (ps := []) (t := e1211299050734) (by decide)) (by decide)
def e1211299050742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211299050742 : Closed e1211299050742 ∧ code e1211299050742 = 5609345561846 := by decide
private def t_e1211299050742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211299050742 : ¬ IsSelfInterpreter e1211299050742 :=
  wSource (t := t_e1211299050742) (replay_sound (ps := []) (t := e1211299050742) (by decide)) (by decide)
def e1211299051118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211299051118 : Closed e1211299051118 ∧ code e1211299051118 = 5609345562222 := by decide
theorem cert_e1211299051118 : check e1211299051118 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299051130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211299051130 : Closed e1211299051130 ∧ code e1211299051130 = 5609345562234 := by decide
theorem cert_e1211299051130 : check e1211299051130 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299051318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211299051318 : Closed e1211299051318 ∧ code e1211299051318 = 5609345562422 := by decide
private def t_e1211299051318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211299051318 : ¬ IsSelfInterpreter e1211299051318 :=
  wSource (t := t_e1211299051318) (replay_sound (ps := []) (t := e1211299051318) (by decide)) (by decide)
def e1211299051322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211299051322 : Closed e1211299051322 ∧ code e1211299051322 = 5609345562426 := by decide
private def t_e1211299051322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211299051322 : ¬ IsSelfInterpreter e1211299051322 :=
  wSource (t := t_e1211299051322) (replay_sound (ps := []) (t := e1211299051322) (by decide)) (by decide)
def e1211299051566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211299051566 : Closed e1211299051566 ∧ code e1211299051566 = 5609345562670 := by decide
theorem cert_e1211299051566 : check e1211299051566 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299051758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211299051758 : Closed e1211299051758 ∧ code e1211299051758 = 5609345562862 := by decide
theorem cert_e1211299051758 : check e1211299051758 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299051766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211299051766 : Closed e1211299051766 ∧ code e1211299051766 = 5609345562870 := by decide
theorem cert_e1211299051766 : check e1211299051766 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299051950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211299051950 : Closed e1211299051950 ∧ code e1211299051950 = 5609345563054 := by decide
theorem cert_e1211299051950 : check e1211299051950 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299051962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211299051962 : Closed e1211299051962 ∧ code e1211299051962 = 5609345563066 := by decide
theorem cert_e1211299051962 : check e1211299051962 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211299052010 : Closed e1211299052010 ∧ code e1211299052010 = 5609345563114 := by decide
theorem cert_e1211299052010 : check e1211299052010 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211299052142 : Closed e1211299052142 ∧ code e1211299052142 = 5609345563246 := by decide
theorem cert_e1211299052142 : check e1211299052142 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211299052154 : Closed e1211299052154 ∧ code e1211299052154 = 5609345563258 := by decide
theorem cert_e1211299052154 : check e1211299052154 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211299052318 : Closed e1211299052318 ∧ code e1211299052318 = 5609345563422 := by decide
theorem cert_e1211299052318 : check e1211299052318 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299052418 : Closed e1211299052418 ∧ code e1211299052418 = 5609345563522 := by decide
theorem cert_e1211299052418 : check e1211299052418 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211299052430 : Closed e1211299052430 ∧ code e1211299052430 = 5609345563534 := by decide
theorem cert_e1211299052430 : check e1211299052430 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299052442 : Closed e1211299052442 ∧ code e1211299052442 = 5609345563546 := by decide
theorem cert_e1211299052442 : check e1211299052442 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1211299052566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211299052566 : Closed e1211299052566 ∧ code e1211299052566 = 5609345563670 := by decide
theorem cert_e1211299052566 : check e1211299052566 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211299052662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211299052662 : Closed e1211299052662 ∧ code e1211299052662 = 5609345563766 := by decide
theorem cert_e1211299052662 : check e1211299052662 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211299052758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211299052758 : Closed e1211299052758 ∧ code e1211299052758 = 5609345563862 := by decide
private def t_e1211299052758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem cert_e1211299052758 : ¬ IsSelfInterpreter e1211299052758 :=
  wSource (t := t_e1211299052758) (replay_sound (ps := []) (t := e1211299052758) (by decide)) (by decide)
def e1211299052762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211299052762 : Closed e1211299052762 ∧ code e1211299052762 = 5609345563866 := by decide
theorem cert_e1211299052762 : check e1211299052762 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299052778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211299052778 : Closed e1211299052778 ∧ code e1211299052778 = 5609345563882 := by decide
theorem cert_e1211299052778 : check e1211299052778 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211299052854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211299052854 : Closed e1211299052854 ∧ code e1211299052854 = 5609345563958 := by decide
private def t_e1211299052854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211299052854 : ¬ IsSelfInterpreter e1211299052854 :=
  wSource (t := t_e1211299052854) (replay_sound (ps := []) (t := e1211299052854) (by decide)) (by decide)
def e1211299052858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211299052858 : Closed e1211299052858 ∧ code e1211299052858 = 5609345563962 := by decide
private def t_e1211299052858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211299052858 : ¬ IsSelfInterpreter e1211299052858 :=
  wSource (t := t_e1211299052858) (replay_sound (ps := []) (t := e1211299052858) (by decide)) (by decide)
def e1211299052930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299052930 : Closed e1211299052930 ∧ code e1211299052930 = 5609345564034 := by decide
theorem cert_e1211299052930 : check e1211299052930 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211299052942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211299052942 : Closed e1211299052942 ∧ code e1211299052942 = 5609345564046 := by decide
theorem cert_e1211299052942 : check e1211299052942 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211299052954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299052954 : Closed e1211299052954 ∧ code e1211299052954 = 5609345564058 := by decide
def e1211299054558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211299054558 : Closed e1211299054558 ∧ code e1211299054558 = 5609345565662 := by decide
theorem cert_e1211299054558 : checkPay e1211299054558 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[.left]] 0 [] = true := by decide
def e1211299054574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211299054574 : Closed e1211299054574 ∧ code e1211299054574 = 5609345565678 := by decide
theorem cert_e1211299054574 : check e1211299054574 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211299056494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211299056494 : Closed e1211299056494 ∧ code e1211299056494 = 5609345567598 := by decide
def e1211299056502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211299056502 : Closed e1211299056502 ∧ code e1211299056502 = 5609345567606 := by decide
private def t_e1211299056502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211299056502 : ¬ IsSelfInterpreter e1211299056502 :=
  wSource (t := t_e1211299056502) (replay_sound (ps := []) (t := e1211299056502) (by decide)) (by decide)
end Blc.Floor42
