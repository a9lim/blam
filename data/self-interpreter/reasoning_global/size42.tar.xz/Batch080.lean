import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196687234938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1196687234938 : Closed e1196687234938 ∧ code e1196687234938 = 5594733746042 := by decide
theorem cert_e1196687234938 : check e1196687234938 [[],[.left],[],[.under]] .three = true := by decide
def e1196687234998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1196687234998 : Closed e1196687234998 ∧ code e1196687234998 = 5594733746102 := by decide
theorem cert_e1196687234998 : check e1196687234998 [[],[.left],[],[.under]] .three = true := by decide
def e1196687235030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1196687235030 : Closed e1196687235030 ∧ code e1196687235030 = 5594733746134 := by decide
private def t_e1196687235030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e1196687235030 : ¬ IsSelfInterpreter e1196687235030 :=
  wSource (t := t_e1196687235030) (replay_sound (ps := []) (t := e1196687235030) (by decide)) (by decide)
def e1196687235034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1196687235034 : Closed e1196687235034 ∧ code e1196687235034 = 5594733746138 := by decide
theorem cert_e1196687235034 : check e1196687235034 [[],[.left],[],[.under]] .three = true := by decide
def e1196687235550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196687235550 : Closed e1196687235550 ∧ code e1196687235550 = 5594733746654 := by decide
theorem cert_e1196687235550 : check e1196687235550 [[],[.left],[],[.under]] .three = true := by decide
def e1196687235574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196687235574 : Closed e1196687235574 ∧ code e1196687235574 = 5594733746678 := by decide
theorem cert_e1196687235574 : check e1196687235574 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196687236318 : Closed e1196687236318 ∧ code e1196687236318 = 5594733747422 := by decide
theorem cert_e1196687236318 : check e1196687236318 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196687236334 : Closed e1196687236334 ∧ code e1196687236334 = 5594733747438 := by decide
theorem cert_e1196687236334 : check e1196687236334 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196687236342 : Closed e1196687236342 ∧ code e1196687236342 = 5594733747446 := by decide
theorem cert_e1196687236342 : check e1196687236342 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196687236346 : Closed e1196687236346 ∧ code e1196687236346 = 5594733747450 := by decide
theorem cert_e1196687236346 : check e1196687236346 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196687236726 : Closed e1196687236726 ∧ code e1196687236726 = 5594733747830 := by decide
theorem cert_e1196687236726 : check e1196687236726 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196687236918 : Closed e1196687236918 ∧ code e1196687236918 = 5594733748022 := by decide
theorem cert_e1196687236918 : check e1196687236918 [[],[.left],[],[.under]] .three = true := by decide
def e1196687236922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196687236922 : Closed e1196687236922 ∧ code e1196687236922 = 5594733748026 := by decide
theorem cert_e1196687236922 : check e1196687236922 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1196687251126 : Closed e1196687251126 ∧ code e1196687251126 = 5594733762230 := by decide
theorem cert_e1196687251126 : check e1196687251126 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1196687251158 : Closed e1196687251158 ∧ code e1196687251158 = 5594733762262 := by decide
theorem cert_e1196687251158 : check e1196687251158 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1196687251162 : Closed e1196687251162 ∧ code e1196687251162 = 5594733762266 := by decide
theorem cert_e1196687251162 : check e1196687251162 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1196687251286 : Closed e1196687251286 ∧ code e1196687251286 = 5594733762390 := by decide
theorem cert_e1196687251286 : check e1196687251286 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1196687251290 : Closed e1196687251290 ∧ code e1196687251290 = 5594733762394 := by decide
theorem cert_e1196687251290 : check e1196687251290 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1196687251306 : Closed e1196687251306 ∧ code e1196687251306 = 5594733762410 := by decide
theorem cert_e1196687251306 : check e1196687251306 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196687251694 : Closed e1196687251694 ∧ code e1196687251694 = 5594733762798 := by decide
theorem cert_e1196687251694 : check e1196687251694 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196687251702 : Closed e1196687251702 ∧ code e1196687251702 = 5594733762806 := by decide
theorem cert_e1196687251702 : check e1196687251702 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1196687251894 : Closed e1196687251894 ∧ code e1196687251894 = 5594733762998 := by decide
theorem cert_e1196687251894 : check e1196687251894 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1196687251926 : Closed e1196687251926 ∧ code e1196687251926 = 5594733763030 := by decide
theorem cert_e1196687251926 : check e1196687251926 [[],[.left],[],[.under]] .three = true := by decide
def e1196687251930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1196687251930 : Closed e1196687251930 ∧ code e1196687251930 = 5594733763034 := by decide
theorem cert_e1196687251930 : check e1196687251930 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196687252086 : Closed e1196687252086 ∧ code e1196687252086 = 5594733763190 := by decide
theorem cert_e1196687252086 : check e1196687252086 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196687252254 : Closed e1196687252254 ∧ code e1196687252254 = 5594733763358 := by decide
theorem cert_e1196687252254 : check e1196687252254 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196687252278 : Closed e1196687252278 ∧ code e1196687252278 = 5594733763382 := by decide
theorem cert_e1196687252278 : check e1196687252278 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196687252282 : Closed e1196687252282 ∧ code e1196687252282 = 5594733763386 := by decide
theorem cert_e1196687252282 : check e1196687252282 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196687252366 : Closed e1196687252366 ∧ code e1196687252366 = 5594733763470 := by decide
theorem cert_e1196687252366 : check e1196687252366 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196687252590 : Closed e1196687252590 ∧ code e1196687252590 = 5594733763694 := by decide
theorem cert_e1196687252590 : check e1196687252590 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196687252602 : Closed e1196687252602 ∧ code e1196687252602 = 5594733763706 := by decide
theorem cert_e1196687252602 : check e1196687252602 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1196687252694 : Closed e1196687252694 ∧ code e1196687252694 = 5594733763798 := by decide
theorem cert_e1196687252694 : check e1196687252694 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1196687252698 : Closed e1196687252698 ∧ code e1196687252698 = 5594733763802 := by decide
theorem cert_e1196687252698 : check e1196687252698 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1196687252714 : Closed e1196687252714 ∧ code e1196687252714 = 5594733763818 := by decide
theorem cert_e1196687252714 : check e1196687252714 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196687252766 : Closed e1196687252766 ∧ code e1196687252766 = 5594733763870 := by decide
theorem cert_e1196687252766 : check e1196687252766 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196687252790 : Closed e1196687252790 ∧ code e1196687252790 = 5594733763894 := by decide
theorem cert_e1196687252790 : check e1196687252790 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196687252794 : Closed e1196687252794 ∧ code e1196687252794 = 5594733763898 := by decide
theorem cert_e1196687252794 : check e1196687252794 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196687252890 : Closed e1196687252890 ∧ code e1196687252890 = 5594733763994 := by decide
theorem cert_e1196687252890 : check e1196687252890 [[],[.left],[],[.under]] .three = true := by decide
def e1196687252934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196687252934 : Closed e1196687252934 ∧ code e1196687252934 = 5594733764038 := by decide
theorem cert_e1196687252934 : check e1196687252934 [[],[.left],[],[.under]] .three = true := by decide
def e1196687253046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196687253046 : Closed e1196687253046 ∧ code e1196687253046 = 5594733764150 := by decide
theorem cert_e1196687253046 : check e1196687253046 [[],[.left],[],[.under]] .three = true := by decide
def e1196687253050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196687253050 : Closed e1196687253050 ∧ code e1196687253050 = 5594733764154 := by decide
theorem cert_e1196687253050 : check e1196687253050 [[],[.left],[],[.under]] .three = true := by decide
def e1196687253134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196687253134 : Closed e1196687253134 ∧ code e1196687253134 = 5594733764238 := by decide
theorem cert_e1196687253134 : check e1196687253134 [[],[.left],[],[.under]] .three = true := by decide
def e1196687253190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196687253190 : Closed e1196687253190 ∧ code e1196687253190 = 5594733764294 := by decide
theorem cert_e1196687253190 : check e1196687253190 [[],[.left],[],[.under]] .three = true := by decide
def e1196687253998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1196687253998 : Closed e1196687253998 ∧ code e1196687253998 = 5594733765102 := by decide
theorem cert_e1196687253998 : check e1196687253998 [[],[.left],[],[.under]] .three = true := by decide
def e1196687254966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1196687254966 : Closed e1196687254966 ∧ code e1196687254966 = 5594733766070 := by decide
theorem cert_e1196687254966 : check e1196687254966 [[],[.left],[],[.under]] .three = true := by decide
def e1196687254998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1196687254998 : Closed e1196687254998 ∧ code e1196687254998 = 5594733766102 := by decide
theorem cert_e1196687254998 : check e1196687254998 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1196687255002 : Closed e1196687255002 ∧ code e1196687255002 = 5594733766106 := by decide
theorem cert_e1196687255002 : check e1196687255002 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196687255158 : Closed e1196687255158 ∧ code e1196687255158 = 5594733766262 := by decide
theorem cert_e1196687255158 : check e1196687255158 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196687255326 : Closed e1196687255326 ∧ code e1196687255326 = 5594733766430 := by decide
theorem cert_e1196687255326 : check e1196687255326 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196687255350 : Closed e1196687255350 ∧ code e1196687255350 = 5594733766454 := by decide
theorem cert_e1196687255350 : check e1196687255350 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196687255354 : Closed e1196687255354 ∧ code e1196687255354 = 5594733766458 := by decide
theorem cert_e1196687255354 : check e1196687255354 [[],[.left],[],[.under]] .three = true := by decide
def e1196687255438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196687255438 : Closed e1196687255438 ∧ code e1196687255438 = 5594733766542 := by decide
theorem cert_e1196687255438 : check e1196687255438 [[],[.left],[],[.under]] .three = true := by decide
def e1196687257838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1196687257838 : Closed e1196687257838 ∧ code e1196687257838 = 5594733768942 := by decide
theorem cert_e1196687257838 : check e1196687257838 [[],[.left],[],[.under]] .three = true := by decide
def e1196687257846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1196687257846 : Closed e1196687257846 ∧ code e1196687257846 = 5594733768950 := by decide
theorem cert_e1196687257846 : check e1196687257846 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1196687258326 : Closed e1196687258326 ∧ code e1196687258326 = 5594733769430 := by decide
theorem cert_e1196687258326 : check e1196687258326 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1196687258330 : Closed e1196687258330 ∧ code e1196687258330 = 5594733769434 := by decide
theorem cert_e1196687258330 : check e1196687258330 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1196687258346 : Closed e1196687258346 ∧ code e1196687258346 = 5594733769450 := by decide
theorem cert_e1196687258346 : check e1196687258346 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196687258398 : Closed e1196687258398 ∧ code e1196687258398 = 5594733769502 := by decide
theorem cert_e1196687258398 : check e1196687258398 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196687258422 : Closed e1196687258422 ∧ code e1196687258422 = 5594733769526 := by decide
theorem cert_e1196687258422 : check e1196687258422 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196687258426 : Closed e1196687258426 ∧ code e1196687258426 = 5594733769530 := by decide
theorem cert_e1196687258426 : check e1196687258426 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196687258522 : Closed e1196687258522 ∧ code e1196687258522 = 5594733769626 := by decide
theorem cert_e1196687258522 : check e1196687258522 [[],[.left],[],[.under]] .three = true := by decide
def e1196687258566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196687258566 : Closed e1196687258566 ∧ code e1196687258566 = 5594733769670 := by decide
theorem cert_e1196687258566 : check e1196687258566 [[],[.left],[],[.under]] .three = true := by decide
def e1196687260046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196687260046 : Closed e1196687260046 ∧ code e1196687260046 = 5594733771150 := by decide
theorem cert_e1196687260046 : check e1196687260046 [[],[.left],[],[.under]] .three = true := by decide
def e1196687260102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196687260102 : Closed e1196687260102 ∧ code e1196687260102 = 5594733771206 := by decide
theorem cert_e1196687260102 : check e1196687260102 [[],[.left],[],[.under]] .three = true := by decide
def e1196691053430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1196691053430 : Closed e1196691053430 ∧ code e1196691053430 = 5594737564534 := by decide
def e1196691053494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1196691053494 : Closed e1196691053494 ∧ code e1196691053494 = 5594737564598 := by decide
def e1196691053942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1196691053942 : Closed e1196691053942 ∧ code e1196691053942 = 5594737565046 := by decide
def e1196691054038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1196691054038 : Closed e1196691054038 ∧ code e1196691054038 = 5594737565142 := by decide
def e1196691054262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1196691054262 : Closed e1196691054262 ∧ code e1196691054262 = 5594737565366 := by decide
def e1196691054294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1196691054294 : Closed e1196691054294 ∧ code e1196691054294 = 5594737565398 := by decide
def e1196691056502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1196691056502 : Closed e1196691056502 ∧ code e1196691056502 = 5594737567606 := by decide
def e1196691056566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1196691056566 : Closed e1196691056566 ∧ code e1196691056566 = 5594737567670 := by decide
def e1196691059574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1196691059574 : Closed e1196691059574 ∧ code e1196691059574 = 5594737570678 := by decide
def e1196691059670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1196691059670 : Closed e1196691059670 ∧ code e1196691059670 = 5594737570774 := by decide
def e1196691061174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1196691061174 : Closed e1196691061174 ∧ code e1196691061174 = 5594737572278 := by decide
def e1196691061206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1196691061206 : Closed e1196691061206 ∧ code e1196691061206 = 5594737572310 := by decide
def e1196691229550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196691229550 : Closed e1196691229550 ∧ code e1196691229550 = 5594737740654 := by decide
def e1196691229558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196691229558 : Closed e1196691229558 ∧ code e1196691229558 = 5594737740662 := by decide
def e1196691229614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196691229614 : Closed e1196691229614 ∧ code e1196691229614 = 5594737740718 := by decide
def e1196691229626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196691229626 : Closed e1196691229626 ∧ code e1196691229626 = 5594737740730 := by decide
def e1196691229654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196691229654 : Closed e1196691229654 ∧ code e1196691229654 = 5594737740758 := by decide
def e1196691229658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196691229658 : Closed e1196691229658 ∧ code e1196691229658 = 5594737740762 := by decide
def e1196691229934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196691229934 : Closed e1196691229934 ∧ code e1196691229934 = 5594737741038 := by decide
def e1196691229942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196691229942 : Closed e1196691229942 ∧ code e1196691229942 = 5594737741046 := by decide
def e1196691230318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196691230318 : Closed e1196691230318 ∧ code e1196691230318 = 5594737741422 := by decide
def e1196691230330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196691230330 : Closed e1196691230330 ∧ code e1196691230330 = 5594737741434 := by decide
def e1196691230518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196691230518 : Closed e1196691230518 ∧ code e1196691230518 = 5594737741622 := by decide
def e1196691230522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196691230522 : Closed e1196691230522 ∧ code e1196691230522 = 5594737741626 := by decide
def e1196691303866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1196691303866 : Closed e1196691303866 ∧ code e1196691303866 = 5594737814970 := by decide
def e1196691303898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1196691303898 : Closed e1196691303898 ∧ code e1196691303898 = 5594737815002 := by decide
private def t_e1196691303898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem cert_e1196691303898 : ¬ IsSelfInterpreter e1196691303898 :=
  wSource (t := t_e1196691303898) (replay_sound (ps := []) (t := e1196691303898) (by decide)) (by decide)
def e1196691304122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1196691304122 : Closed e1196691304122 ∧ code e1196691304122 = 5594737815226 := by decide
def e1196691304170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1196691304170 : Closed e1196691304170 ∧ code e1196691304170 = 5594737815274 := by decide
def e1196691304282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1196691304282 : Closed e1196691304282 ∧ code e1196691304282 = 5594737815386 := by decide
private def t_e1196691304282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem cert_e1196691304282 : ¬ IsSelfInterpreter e1196691304282 :=
  wSource (t := t_e1196691304282) (replay_sound (ps := []) (t := e1196691304282) (by decide)) (by decide)
def e1196691304298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1196691304298 : Closed e1196691304298 ∧ code e1196691304298 = 5594737815402 := by decide
def e1196691305402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1196691305402 : Closed e1196691305402 ∧ code e1196691305402 = 5594737816506 := by decide
def e1196691305434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1196691305434 : Closed e1196691305434 ∧ code e1196691305434 = 5594737816538 := by decide
def e1196691306938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1196691306938 : Closed e1196691306938 ∧ code e1196691306938 = 5594737818042 := by decide
def e1196691306986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1196691306986 : Closed e1196691306986 ∧ code e1196691306986 = 5594737818090 := by decide
def e1196691307738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1196691307738 : Closed e1196691307738 ∧ code e1196691307738 = 5594737818842 := by decide
def e1196691307754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1196691307754 : Closed e1196691307754 ∧ code e1196691307754 = 5594737818858 := by decide
def e1196691360622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196691360622 : Closed e1196691360622 ∧ code e1196691360622 = 5594737871726 := by decide
def e1196691360630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196691360630 : Closed e1196691360630 ∧ code e1196691360630 = 5594737871734 := by decide
def e1196691360686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196691360686 : Closed e1196691360686 ∧ code e1196691360686 = 5594737871790 := by decide
def e1196691360698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196691360698 : Closed e1196691360698 ∧ code e1196691360698 = 5594737871802 := by decide
def e1196691360726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196691360726 : Closed e1196691360726 ∧ code e1196691360726 = 5594737871830 := by decide
def e1196691360730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196691360730 : Closed e1196691360730 ∧ code e1196691360730 = 5594737871834 := by decide
def e1196691361006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196691361006 : Closed e1196691361006 ∧ code e1196691361006 = 5594737872110 := by decide
def e1196691361014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196691361014 : Closed e1196691361014 ∧ code e1196691361014 = 5594737872118 := by decide
def e1196691361390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196691361390 : Closed e1196691361390 ∧ code e1196691361390 = 5594737872494 := by decide
def e1196691361402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196691361402 : Closed e1196691361402 ∧ code e1196691361402 = 5594737872506 := by decide
def e1196691361590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196691361590 : Closed e1196691361590 ∧ code e1196691361590 = 5594737872694 := by decide
def e1196691361594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196691361594 : Closed e1196691361594 ∧ code e1196691361594 = 5594737872698 := by decide
def e1196691560158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1196691560158 : Closed e1196691560158 ∧ code e1196691560158 = 5594738071262 := by decide
theorem cert_e1196691560158 : check e1196691560158 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1196691560182 : Closed e1196691560182 ∧ code e1196691560182 = 5594738071286 := by decide
theorem cert_e1196691560182 : check e1196691560182 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1196691560286 : Closed e1196691560286 ∧ code e1196691560286 = 5594738071390 := by decide
theorem cert_e1196691560286 : check e1196691560286 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1196691560314 : Closed e1196691560314 ∧ code e1196691560314 = 5594738071418 := by decide
theorem cert_e1196691560314 : check e1196691560314 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1196691560406 : Closed e1196691560406 ∧ code e1196691560406 = 5594738071510 := by decide
theorem cert_e1196691560406 : check e1196691560406 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1196691560410 : Closed e1196691560410 ∧ code e1196691560410 = 5594738071514 := by decide
theorem cert_e1196691560410 : check e1196691560410 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1196691560926 : Closed e1196691560926 ∧ code e1196691560926 = 5594738072030 := by decide
theorem cert_e1196691560926 : check e1196691560926 [[],[.left],[],[]] .smaller = true := by decide
def e1196691560950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1196691560950 : Closed e1196691560950 ∧ code e1196691560950 = 5594738072054 := by decide
theorem cert_e1196691560950 : check e1196691560950 [[],[.left],[],[]] .smaller = true := by decide
def e1196691561694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1196691561694 : Closed e1196691561694 ∧ code e1196691561694 = 5594738072798 := by decide
theorem cert_e1196691561694 : check e1196691561694 [[],[.left],[],[]] .smaller = true := by decide
def e1196691561722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1196691561722 : Closed e1196691561722 ∧ code e1196691561722 = 5594738072826 := by decide
theorem cert_e1196691561722 : check e1196691561722 [[],[.left],[],[]] .smaller = true := by decide
def e1196691562294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196691562294 : Closed e1196691562294 ∧ code e1196691562294 = 5594738073398 := by decide
theorem cert_e1196691562294 : check e1196691562294 [[],[.left],[],[]] .smaller = true := by decide
def e1196691562298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196691562298 : Closed e1196691562298 ∧ code e1196691562298 = 5594738073402 := by decide
theorem cert_e1196691562298 : check e1196691562298 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1196691577070 : Closed e1196691577070 ∧ code e1196691577070 = 5594738088174 := by decide
theorem cert_e1196691577070 : check e1196691577070 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1196691577078 : Closed e1196691577078 ∧ code e1196691577078 = 5594738088182 := by decide
theorem cert_e1196691577078 : check e1196691577078 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1196691577630 : Closed e1196691577630 ∧ code e1196691577630 = 5594738088734 := by decide
theorem cert_e1196691577630 : check e1196691577630 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1196691577742 : Closed e1196691577742 ∧ code e1196691577742 = 5594738088846 := by decide
theorem cert_e1196691577742 : check e1196691577742 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1196691577966 : Closed e1196691577966 ∧ code e1196691577966 = 5594738089070 := by decide
theorem cert_e1196691577966 : check e1196691577966 [[],[.left],[],[]] .smaller = true := by decide
def e1196691577978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1196691577978 : Closed e1196691577978 ∧ code e1196691577978 = 5594738089082 := by decide
theorem cert_e1196691577978 : check e1196691577978 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1196691578142 : Closed e1196691578142 ∧ code e1196691578142 = 5594738089246 := by decide
theorem cert_e1196691578142 : check e1196691578142 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1196691578310 : Closed e1196691578310 ∧ code e1196691578310 = 5594738089414 := by decide
theorem cert_e1196691578310 : check e1196691578310 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1196691578334 : Closed e1196691578334 ∧ code e1196691578334 = 5594738089438 := by decide
theorem cert_e1196691578334 : check e1196691578334 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691578350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1196691578350 : Closed e1196691578350 ∧ code e1196691578350 = 5594738089454 := by decide
theorem cert_e1196691578350 : check e1196691578350 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691578422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1196691578422 : Closed e1196691578422 ∧ code e1196691578422 = 5594738089526 := by decide
theorem cert_e1196691578422 : check e1196691578422 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1196691578426 : Closed e1196691578426 ∧ code e1196691578426 = 5594738089530 := by decide
theorem cert_e1196691578426 : check e1196691578426 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1196691578510 : Closed e1196691578510 ∧ code e1196691578510 = 5594738089614 := by decide
theorem cert_e1196691578510 : check e1196691578510 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1196691578566 : Closed e1196691578566 ∧ code e1196691578566 = 5594738089670 := by decide
theorem cert_e1196691578566 : check e1196691578566 [[],[.left],[],[]] .smaller = true := by decide
def e1196691578590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1196691578590 : Closed e1196691578590 ∧ code e1196691578590 = 5594738089694 := by decide
theorem cert_e1196691578590 : check e1196691578590 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691578614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1196691578614 : Closed e1196691578614 ∧ code e1196691578614 = 5594738089718 := by decide
theorem cert_e1196691578614 : check e1196691578614 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691578734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1196691578734 : Closed e1196691578734 ∧ code e1196691578734 = 5594738089838 := by decide
theorem cert_e1196691578734 : check e1196691578734 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691578742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1196691578742 : Closed e1196691578742 ∧ code e1196691578742 = 5594738089846 := by decide
theorem cert_e1196691578742 : check e1196691578742 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691580702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1196691580702 : Closed e1196691580702 ∧ code e1196691580702 = 5594738091806 := by decide
theorem cert_e1196691580702 : check e1196691580702 [[],[.left],[],[]] .smaller = true := by decide
def e1196691580814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1196691580814 : Closed e1196691580814 ∧ code e1196691580814 = 5594738091918 := by decide
theorem cert_e1196691580814 : check e1196691580814 [[],[.left],[],[]] .smaller = true := by decide
def e1196691583774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1196691583774 : Closed e1196691583774 ∧ code e1196691583774 = 5594738094878 := by decide
theorem cert_e1196691583774 : check e1196691583774 [[],[.left],[],[]] .smaller = true := by decide
def e1196691583942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1196691583942 : Closed e1196691583942 ∧ code e1196691583942 = 5594738095046 := by decide
theorem cert_e1196691583942 : check e1196691583942 [[],[.left],[],[]] .smaller = true := by decide
def e1196691583966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1196691583966 : Closed e1196691583966 ∧ code e1196691583966 = 5594738095070 := by decide
theorem cert_e1196691583966 : check e1196691583966 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691583982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1196691583982 : Closed e1196691583982 ∧ code e1196691583982 = 5594738095086 := by decide
theorem cert_e1196691583982 : check e1196691583982 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691585422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1196691585422 : Closed e1196691585422 ∧ code e1196691585422 = 5594738096526 := by decide
theorem cert_e1196691585422 : check e1196691585422 [[],[.left],[],[]] .smaller = true := by decide
def e1196691585478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1196691585478 : Closed e1196691585478 ∧ code e1196691585478 = 5594738096582 := by decide
theorem cert_e1196691585478 : check e1196691585478 [[],[.left],[],[]] .smaller = true := by decide
def e1196691585502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196691585502 : Closed e1196691585502 ∧ code e1196691585502 = 5594738096606 := by decide
theorem cert_e1196691585502 : check e1196691585502 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691585526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196691585526 : Closed e1196691585526 ∧ code e1196691585526 = 5594738096630 := by decide
theorem cert_e1196691585526 : check e1196691585526 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691586286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196691586286 : Closed e1196691586286 ∧ code e1196691586286 = 5594738097390 := by decide
theorem cert_e1196691586286 : check e1196691586286 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691586294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196691586294 : Closed e1196691586294 ∧ code e1196691586294 = 5594738097398 := by decide
theorem cert_e1196691586294 : check e1196691586294 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1196691643246 : Closed e1196691643246 ∧ code e1196691643246 = 5594738154350 := by decide
theorem cert_e1196691643246 : check e1196691643246 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1196691643254 : Closed e1196691643254 ∧ code e1196691643254 = 5594738154358 := by decide
theorem cert_e1196691643254 : check e1196691643254 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1196691643318 : Closed e1196691643318 ∧ code e1196691643318 = 5594738154422 := by decide
theorem cert_e1196691643318 : check e1196691643318 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196691643758 : Closed e1196691643758 ∧ code e1196691643758 = 5594738154862 := by decide
theorem cert_e1196691643758 : check e1196691643758 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196691643766 : Closed e1196691643766 ∧ code e1196691643766 = 5594738154870 := by decide
theorem cert_e1196691643766 : check e1196691643766 [[],[.left],[],[]] .sourceHead = true := by decide
def e1196691643822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196691643822 : Closed e1196691643822 ∧ code e1196691643822 = 5594738154926 := by decide
theorem cert_e1196691643822 : check e1196691643822 [[],[.left],[],[]] .sourceHead = true := by decide
end Blc.Floor42
