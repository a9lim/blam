import Batch062
import ExtraBase
namespace Blc.Floor42.Extra062
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1131212281710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem ex_e1131212281710 : ¬ IsSelfInterpreter e1131212281710 := by
  intro he
  have hp := replay_sound (t := e1131212281710) (u := t_e1131212281710) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2))) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212281710
private def t_e1131212281718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem ex_e1131212281718 : ¬ IsSelfInterpreter e1131212281718 := by
  intro he
  have hp := replay_sound (t := e1131212281718) (u := t_e1131212281718) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1))) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212281718
private def t_e1131212281782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem ex_e1131212281782 : ¬ IsSelfInterpreter e1131212281782 := by
  intro he
  have hp := replay_sound (t := e1131212281782) (u := t_e1131212281782) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212281782
private def t_e1131212283118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem ex_e1131212283118 : ¬ IsSelfInterpreter e1131212283118 := by
  intro he
  have hp := replay_sound (t := e1131212283118) (u := t_e1131212283118) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 0) (.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 1) (SO.var 2)))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 1))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212283118
private def t_e1131212283126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem ex_e1131212283126 : ¬ IsSelfInterpreter e1131212283126 := by
  intro he
  have hp := replay_sound (t := e1131212283126) (u := t_e1131212283126) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 1) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 2) (SO.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212283126
private def t_e1131212283510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem ex_e1131212283510 : ¬ IsSelfInterpreter e1131212283510 := by
  intro he
  have hp := replay_sound (t := e1131212283510) (u := t_e1131212283510) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1)))) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1131212283510
private def t_e1192558157242 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem ex_e1192558157242 : ¬ IsSelfInterpreter e1192558157242 := by
  intro he
  have hp := replay_sound (t := e1192558157242) (u := t_e1192558157242) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558157242
private def t_e1192558157274 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem ex_e1192558157274 : ¬ IsSelfInterpreter e1192558157274 := by
  intro he
  have hp := replay_sound (t := e1192558157274) (u := t_e1192558157274) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558157274
private def t_e1192558157530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem ex_e1192558157530 : ¬ IsSelfInterpreter e1192558157530 := by
  intro he
  have hp := replay_sound (t := e1192558157530) (u := t_e1192558157530) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558157530
private def t_e1192558164442 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem ex_e1192558164442 : ¬ IsSelfInterpreter e1192558164442 := by
  intro he
  have hp := replay_sound (t := e1192558164442) (u := t_e1192558164442) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558164442
private def t_e1192558529454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem ex_e1192558529454 : ¬ IsSelfInterpreter e1192558529454 := by
  intro he
  have hp := replay_sound (t := e1192558529454) (u := t_e1192558529454) (ps := [[],[.left,.left],[.left],[.left,.right,.under,.left],[.left,.right,.under],[.left,.right,.under,.right,.under,.left],[.left,.right,.under,.right,.under],[.left],[],[.right,.under,.left]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1192558529454) (by decide) (by decide) hj
#print axioms ex_e1192558529454
private def t_e1192558529466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem ex_e1192558529466 : ¬ IsSelfInterpreter e1192558529466 := by
  intro he
  have hp := replay_sound (t := e1192558529466) (u := t_e1192558529466) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558529466
private def t_e1192558529498 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1192558529498 : ¬ IsSelfInterpreter e1192558529498 := by
  intro he
  have hp := replay_sound (t := e1192558529498) (u := t_e1192558529498) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558529498
private def t_e1192558529774 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem ex_e1192558529774 : ¬ IsSelfInterpreter e1192558529774 := by
  intro he
  have hp := replay_sound (t := e1192558529774) (u := t_e1192558529774) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558529774
private def t_e1192558529782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1192558529782 : ¬ IsSelfInterpreter e1192558529782 := by
  intro he
  have hp := replay_sound (t := e1192558529782) (u := t_e1192558529782) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1192558529782
private def t_e1192558530362 : Term := (.app (.lam (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.lam (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem ex_e1192558530362 : ¬ IsSelfInterpreter e1192558530362 := by
  intro he
  have hp := replay_sound (t := (call e1192558530362 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1192558530362) (ps := [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.right,.under,.right],[.left,.left,.left],[.left,.left],[.left,.left,.right,.under,.right],[.left,.left],[.left,.left],[.left],[.left],[.left,.right,.under,.right],[.left,.right,.under,.right],[.left,.right,.under,.right,.right,.under,.right,.left],[.left,.right,.under,.right,.right,.under,.right],[.left,.right,.under,.right,.right,.under],[.left],[.left,.right,.under],[.left],[.left,.right,.under],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := SelfintKnot.occ_betas_zero hr 0 (by decide)
  exact (by decide : ¬ occ 0 (.var 0) = 0) hz
#print axioms ex_e1192558530362
end Blc.Floor42.Extra062
