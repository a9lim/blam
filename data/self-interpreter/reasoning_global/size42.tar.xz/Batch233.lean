import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211273551158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273551158 : Closed e1211273551158 ∧ code e1211273551158 = 5609320062262 := by decide
theorem cert_e1211273551158 : check e1211273551158 [[],[]] .sourceHead = true := by decide
def e1211273551162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273551162 : Closed e1211273551162 ∧ code e1211273551162 = 5609320062266 := by decide
theorem cert_e1211273551162 : check e1211273551162 [[],[]] .sourceHead = true := by decide
def e1211273599214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211273599214 : Closed e1211273599214 ∧ code e1211273599214 = 5609320110318 := by decide
theorem cert_e1211273599214 : check e1211273599214 [[],[]] .chain = true := by decide
def e1211273599222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211273599222 : Closed e1211273599222 ∧ code e1211273599222 = 5609320110326 := by decide
theorem cert_e1211273599222 : check e1211273599222 [[],[]] .chain = true := by decide
def e1211273599774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211273599774 : Closed e1211273599774 ∧ code e1211273599774 = 5609320110878 := by decide
theorem cert_e1211273599774 : check e1211273599774 [[],[]] .chain = true := by decide
def e1211273599886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211273599886 : Closed e1211273599886 ∧ code e1211273599886 = 5609320110990 := by decide
theorem cert_e1211273599886 : check e1211273599886 [[],[]] .chain = true := by decide
def e1211273600110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211273600110 : Closed e1211273600110 ∧ code e1211273600110 = 5609320111214 := by decide
theorem cert_e1211273600110 : check e1211273600110 [[],[]] .chain = true := by decide
def e1211273600122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211273600122 : Closed e1211273600122 ∧ code e1211273600122 = 5609320111226 := by decide
theorem cert_e1211273600122 : check e1211273600122 [[],[]] .chain = true := by decide
def e1211273600286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211273600286 : Closed e1211273600286 ∧ code e1211273600286 = 5609320111390 := by decide
theorem cert_e1211273600286 : check e1211273600286 [[],[]] .chain = true := by decide
def e1211273600454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211273600454 : Closed e1211273600454 ∧ code e1211273600454 = 5609320111558 := by decide
theorem cert_e1211273600454 : check e1211273600454 [[],[]] .chain = true := by decide
def e1211273600566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211273600566 : Closed e1211273600566 ∧ code e1211273600566 = 5609320111670 := by decide
theorem cert_e1211273600566 : check e1211273600566 [[],[]] .chain = true := by decide
def e1211273600570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211273600570 : Closed e1211273600570 ∧ code e1211273600570 = 5609320111674 := by decide
theorem cert_e1211273600570 : check e1211273600570 [[],[]] .chain = true := by decide
def e1211273600654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211273600654 : Closed e1211273600654 ∧ code e1211273600654 = 5609320111758 := by decide
theorem cert_e1211273600654 : check e1211273600654 [[],[]] .chain = true := by decide
def e1211273600710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211273600710 : Closed e1211273600710 ∧ code e1211273600710 = 5609320111814 := by decide
theorem cert_e1211273600710 : check e1211273600710 [[],[]] .chain = true := by decide
def e1211273602846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211273602846 : Closed e1211273602846 ∧ code e1211273602846 = 5609320113950 := by decide
theorem cert_e1211273602846 : check e1211273602846 [[],[]] .chain = true := by decide
def e1211273602958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211273602958 : Closed e1211273602958 ∧ code e1211273602958 = 5609320114062 := by decide
theorem cert_e1211273602958 : check e1211273602958 [[],[]] .chain = true := by decide
def e1211273605918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211273605918 : Closed e1211273605918 ∧ code e1211273605918 = 5609320117022 := by decide
theorem cert_e1211273605918 : check e1211273605918 [[],[]] .chain = true := by decide
def e1211273606086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211273606086 : Closed e1211273606086 ∧ code e1211273606086 = 5609320117190 := by decide
theorem cert_e1211273606086 : check e1211273606086 [[],[]] .chain = true := by decide
def e1211273607566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211273607566 : Closed e1211273607566 ∧ code e1211273607566 = 5609320118670 := by decide
theorem cert_e1211273607566 : check e1211273607566 [[],[]] .chain = true := by decide
def e1211273607622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211273607622 : Closed e1211273607622 ∧ code e1211273607622 = 5609320118726 := by decide
theorem cert_e1211273607622 : check e1211273607622 [[],[]] .chain = true := by decide
def e1211273841518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211273841518 : Closed e1211273841518 ∧ code e1211273841518 = 5609320352622 := by decide
theorem cert_e1211273841518 : check e1211273841518 [[],[]] .smaller = true := by decide
def e1211273841526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211273841526 : Closed e1211273841526 ∧ code e1211273841526 = 5609320352630 := by decide
theorem cert_e1211273841526 : check e1211273841526 [[],[]] .smaller = true := by decide
def e1211273841582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211273841582 : Closed e1211273841582 ∧ code e1211273841582 = 5609320352686 := by decide
theorem cert_e1211273841582 : check e1211273841582 [[],[]] .smaller = true := by decide
def e1211273841594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211273841594 : Closed e1211273841594 ∧ code e1211273841594 = 5609320352698 := by decide
theorem cert_e1211273841594 : check e1211273841594 [[],[]] .smaller = true := by decide
def e1211273841622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211273841622 : Closed e1211273841622 ∧ code e1211273841622 = 5609320352726 := by decide
theorem cert_e1211273841622 : check e1211273841622 [[],[]] .smaller = true := by decide
def e1211273841626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211273841626 : Closed e1211273841626 ∧ code e1211273841626 = 5609320352730 := by decide
theorem cert_e1211273841626 : check e1211273841626 [[],[]] .smaller = true := by decide
def e1211273841902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211273841902 : Closed e1211273841902 ∧ code e1211273841902 = 5609320353006 := by decide
theorem cert_e1211273841902 : check e1211273841902 [[],[]] .smaller = true := by decide
def e1211273841910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211273841910 : Closed e1211273841910 ∧ code e1211273841910 = 5609320353014 := by decide
theorem cert_e1211273841910 : check e1211273841910 [[],[]] .smaller = true := by decide
def e1211273842286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211273842286 : Closed e1211273842286 ∧ code e1211273842286 = 5609320353390 := by decide
theorem cert_e1211273842286 : check e1211273842286 [[],[]] .smaller = true := by decide
def e1211273842298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211273842298 : Closed e1211273842298 ∧ code e1211273842298 = 5609320353402 := by decide
theorem cert_e1211273842298 : check e1211273842298 [[],[]] .smaller = true := by decide
def e1211273842486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211273842486 : Closed e1211273842486 ∧ code e1211273842486 = 5609320353590 := by decide
theorem cert_e1211273842486 : check e1211273842486 [[],[]] .smaller = true := by decide
def e1211273842490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211273842490 : Closed e1211273842490 ∧ code e1211273842490 = 5609320353594 := by decide
theorem cert_e1211273842490 : check e1211273842490 [[],[]] .smaller = true := by decide
def e1211274648438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e1211274648438 : Closed e1211274648438 ∧ code e1211274648438 = 5609321159542 := by decide
theorem cert_e1211274648438 : check e1211274648438 [[],[]] .sourceHead = true := by decide
def e1211274648502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e1211274648502 : Closed e1211274648502 ∧ code e1211274648502 = 5609321159606 := by decide
theorem cert_e1211274648502 : check e1211274648502 [[],[]] .sourceHead = true := by decide
def e1211274648950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e1211274648950 : Closed e1211274648950 ∧ code e1211274648950 = 5609321160054 := by decide
theorem cert_e1211274648950 : check e1211274648950 [[],[]] .sourceHead = true := by decide
def e1211274649046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e1211274649046 : Closed e1211274649046 ∧ code e1211274649046 = 5609321160150 := by decide
theorem cert_e1211274649046 : check e1211274649046 [[],[]] .sourceHead = true := by decide
def e1211274649270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e1211274649270 : Closed e1211274649270 ∧ code e1211274649270 = 5609321160374 := by decide
theorem cert_e1211274649270 : check e1211274649270 [[],[]] .sourceHead = true := by decide
def e1211274649302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e1211274649302 : Closed e1211274649302 ∧ code e1211274649302 = 5609321160406 := by decide
theorem cert_e1211274649302 : check e1211274649302 [[],[]] .sourceHead = true := by decide
def e1211274651510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e1211274651510 : Closed e1211274651510 ∧ code e1211274651510 = 5609321162614 := by decide
theorem cert_e1211274651510 : check e1211274651510 [[],[]] .sourceHead = true := by decide
def e1211274651574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e1211274651574 : Closed e1211274651574 ∧ code e1211274651574 = 5609321162678 := by decide
theorem cert_e1211274651574 : check e1211274651574 [[],[]] .sourceHead = true := by decide
def e1211274654582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e1211274654582 : Closed e1211274654582 ∧ code e1211274654582 = 5609321165686 := by decide
theorem cert_e1211274654582 : check e1211274654582 [[],[]] .sourceHead = true := by decide
def e1211274654678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e1211274654678 : Closed e1211274654678 ∧ code e1211274654678 = 5609321165782 := by decide
theorem cert_e1211274654678 : check e1211274654678 [[],[]] .sourceHead = true := by decide
def e1211274656182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e1211274656182 : Closed e1211274656182 ∧ code e1211274656182 = 5609321167286 := by decide
theorem cert_e1211274656182 : check e1211274656182 [[],[]] .sourceHead = true := by decide
def e1211274656214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e1211274656214 : Closed e1211274656214 ∧ code e1211274656214 = 5609321167318 := by decide
theorem cert_e1211274656214 : check e1211274656214 [[],[]] .sourceHead = true := by decide
def e1211274824558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211274824558 : Closed e1211274824558 ∧ code e1211274824558 = 5609321335662 := by decide
theorem cert_e1211274824558 : check e1211274824558 [[],[]] .sourceHead = true := by decide
def e1211274824566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211274824566 : Closed e1211274824566 ∧ code e1211274824566 = 5609321335670 := by decide
theorem cert_e1211274824566 : check e1211274824566 [[],[]] .sourceHead = true := by decide
def e1211274824622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211274824622 : Closed e1211274824622 ∧ code e1211274824622 = 5609321335726 := by decide
theorem cert_e1211274824622 : check e1211274824622 [[],[]] .sourceHead = true := by decide
def e1211274824634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211274824634 : Closed e1211274824634 ∧ code e1211274824634 = 5609321335738 := by decide
theorem cert_e1211274824634 : check e1211274824634 [[],[]] .sourceHead = true := by decide
def e1211274824662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211274824662 : Closed e1211274824662 ∧ code e1211274824662 = 5609321335766 := by decide
theorem cert_e1211274824662 : check e1211274824662 [[],[]] .sourceHead = true := by decide
def e1211274824666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211274824666 : Closed e1211274824666 ∧ code e1211274824666 = 5609321335770 := by decide
theorem cert_e1211274824666 : check e1211274824666 [[],[]] .sourceHead = true := by decide
def e1211274824942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211274824942 : Closed e1211274824942 ∧ code e1211274824942 = 5609321336046 := by decide
theorem cert_e1211274824942 : check e1211274824942 [[],[]] .sourceHead = true := by decide
def e1211274824950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211274824950 : Closed e1211274824950 ∧ code e1211274824950 = 5609321336054 := by decide
theorem cert_e1211274824950 : check e1211274824950 [[],[]] .sourceHead = true := by decide
def e1211274825326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211274825326 : Closed e1211274825326 ∧ code e1211274825326 = 5609321336430 := by decide
theorem cert_e1211274825326 : check e1211274825326 [[],[]] .sourceHead = true := by decide
def e1211274825338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211274825338 : Closed e1211274825338 ∧ code e1211274825338 = 5609321336442 := by decide
theorem cert_e1211274825338 : check e1211274825338 [[],[]] .sourceHead = true := by decide
def e1211274825526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211274825526 : Closed e1211274825526 ∧ code e1211274825526 = 5609321336630 := by decide
theorem cert_e1211274825526 : check e1211274825526 [[],[]] .sourceHead = true := by decide
def e1211274825530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211274825530 : Closed e1211274825530 ∧ code e1211274825530 = 5609321336634 := by decide
theorem cert_e1211274825530 : check e1211274825530 [[],[]] .sourceHead = true := by decide
def e1211274898874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211274898874 : Closed e1211274898874 ∧ code e1211274898874 = 5609321409978 := by decide
theorem cert_e1211274898874 : check e1211274898874 [[],[]] .sourceHead = true := by decide
def e1211274898906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211274898906 : Closed e1211274898906 ∧ code e1211274898906 = 5609321410010 := by decide
theorem cert_e1211274898906 : check e1211274898906 [[],[]] .sourceHead = true := by decide
def e1211274899130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211274899130 : Closed e1211274899130 ∧ code e1211274899130 = 5609321410234 := by decide
theorem cert_e1211274899130 : check e1211274899130 [[],[]] .sourceHead = true := by decide
def e1211274899178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211274899178 : Closed e1211274899178 ∧ code e1211274899178 = 5609321410282 := by decide
theorem cert_e1211274899178 : check e1211274899178 [[],[]] .sourceHead = true := by decide
def e1211274899290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211274899290 : Closed e1211274899290 ∧ code e1211274899290 = 5609321410394 := by decide
theorem cert_e1211274899290 : check e1211274899290 [[],[]] .sourceHead = true := by decide
def e1211274899306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211274899306 : Closed e1211274899306 ∧ code e1211274899306 = 5609321410410 := by decide
theorem cert_e1211274899306 : check e1211274899306 [[],[]] .sourceHead = true := by decide
def e1211274900410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211274900410 : Closed e1211274900410 ∧ code e1211274900410 = 5609321411514 := by decide
theorem cert_e1211274900410 : check e1211274900410 [[],[]] .sourceHead = true := by decide
def e1211274900442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211274900442 : Closed e1211274900442 ∧ code e1211274900442 = 5609321411546 := by decide
theorem cert_e1211274900442 : check e1211274900442 [[],[]] .sourceHead = true := by decide
def e1211274901946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211274901946 : Closed e1211274901946 ∧ code e1211274901946 = 5609321413050 := by decide
theorem cert_e1211274901946 : check e1211274901946 [[],[]] .sourceHead = true := by decide
def e1211274901994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211274901994 : Closed e1211274901994 ∧ code e1211274901994 = 5609321413098 := by decide
theorem cert_e1211274901994 : check e1211274901994 [[],[]] .sourceHead = true := by decide
def e1211274902746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211274902746 : Closed e1211274902746 ∧ code e1211274902746 = 5609321413850 := by decide
theorem cert_e1211274902746 : check e1211274902746 [[],[]] .sourceHead = true := by decide
def e1211274902762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211274902762 : Closed e1211274902762 ∧ code e1211274902762 = 5609321413866 := by decide
theorem cert_e1211274902762 : check e1211274902762 [[],[]] .sourceHead = true := by decide
def e1211274955630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211274955630 : Closed e1211274955630 ∧ code e1211274955630 = 5609321466734 := by decide
theorem cert_e1211274955630 : check e1211274955630 [[],[]] .sourceHead = true := by decide
def e1211274955638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211274955638 : Closed e1211274955638 ∧ code e1211274955638 = 5609321466742 := by decide
theorem cert_e1211274955638 : check e1211274955638 [[],[]] .sourceHead = true := by decide
def e1211274955694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211274955694 : Closed e1211274955694 ∧ code e1211274955694 = 5609321466798 := by decide
theorem cert_e1211274955694 : check e1211274955694 [[],[]] .sourceHead = true := by decide
def e1211274955706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211274955706 : Closed e1211274955706 ∧ code e1211274955706 = 5609321466810 := by decide
theorem cert_e1211274955706 : check e1211274955706 [[],[]] .sourceHead = true := by decide
def e1211274955734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211274955734 : Closed e1211274955734 ∧ code e1211274955734 = 5609321466838 := by decide
theorem cert_e1211274955734 : check e1211274955734 [[],[]] .sourceHead = true := by decide
def e1211274955738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211274955738 : Closed e1211274955738 ∧ code e1211274955738 = 5609321466842 := by decide
theorem cert_e1211274955738 : check e1211274955738 [[],[]] .sourceHead = true := by decide
def e1211274956014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211274956014 : Closed e1211274956014 ∧ code e1211274956014 = 5609321467118 := by decide
theorem cert_e1211274956014 : check e1211274956014 [[],[]] .sourceHead = true := by decide
def e1211274956022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211274956022 : Closed e1211274956022 ∧ code e1211274956022 = 5609321467126 := by decide
theorem cert_e1211274956022 : check e1211274956022 [[],[]] .sourceHead = true := by decide
def e1211274956398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211274956398 : Closed e1211274956398 ∧ code e1211274956398 = 5609321467502 := by decide
theorem cert_e1211274956398 : check e1211274956398 [[],[]] .sourceHead = true := by decide
def e1211274956410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211274956410 : Closed e1211274956410 ∧ code e1211274956410 = 5609321467514 := by decide
theorem cert_e1211274956410 : check e1211274956410 [[],[]] .sourceHead = true := by decide
def e1211274956598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211274956598 : Closed e1211274956598 ∧ code e1211274956598 = 5609321467702 := by decide
theorem cert_e1211274956598 : check e1211274956598 [[],[]] .sourceHead = true := by decide
def e1211274956602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211274956602 : Closed e1211274956602 ∧ code e1211274956602 = 5609321467706 := by decide
theorem cert_e1211274956602 : check e1211274956602 [[],[]] .sourceHead = true := by decide
def e1211275155166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211275155166 : Closed e1211275155166 ∧ code e1211275155166 = 5609321666270 := by decide
theorem cert_e1211275155166 : check e1211275155166 [[],[]] .smaller = true := by decide
def e1211275155190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211275155190 : Closed e1211275155190 ∧ code e1211275155190 = 5609321666294 := by decide
theorem cert_e1211275155190 : check e1211275155190 [[],[]] .smaller = true := by decide
def e1211275155294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211275155294 : Closed e1211275155294 ∧ code e1211275155294 = 5609321666398 := by decide
theorem cert_e1211275155294 : check e1211275155294 [[],[]] .smaller = true := by decide
def e1211275155322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211275155322 : Closed e1211275155322 ∧ code e1211275155322 = 5609321666426 := by decide
theorem cert_e1211275155322 : check e1211275155322 [[],[]] .smaller = true := by decide
def e1211275155414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211275155414 : Closed e1211275155414 ∧ code e1211275155414 = 5609321666518 := by decide
theorem cert_e1211275155414 : check e1211275155414 [[],[]] .smaller = true := by decide
def e1211275155418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211275155418 : Closed e1211275155418 ∧ code e1211275155418 = 5609321666522 := by decide
theorem cert_e1211275155418 : check e1211275155418 [[],[]] .smaller = true := by decide
def e1211275155934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211275155934 : Closed e1211275155934 ∧ code e1211275155934 = 5609321667038 := by decide
theorem cert_e1211275155934 : check e1211275155934 [[],[]] .smaller = true := by decide
def e1211275155958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211275155958 : Closed e1211275155958 ∧ code e1211275155958 = 5609321667062 := by decide
theorem cert_e1211275155958 : check e1211275155958 [[],[]] .smaller = true := by decide
def e1211275156702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211275156702 : Closed e1211275156702 ∧ code e1211275156702 = 5609321667806 := by decide
theorem cert_e1211275156702 : check e1211275156702 [[],[]] .smaller = true := by decide
def e1211275156730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211275156730 : Closed e1211275156730 ∧ code e1211275156730 = 5609321667834 := by decide
theorem cert_e1211275156730 : check e1211275156730 [[],[]] .smaller = true := by decide
def e1211275157302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211275157302 : Closed e1211275157302 ∧ code e1211275157302 = 5609321668406 := by decide
theorem cert_e1211275157302 : check e1211275157302 [[],[]] .smaller = true := by decide
def e1211275157306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211275157306 : Closed e1211275157306 ∧ code e1211275157306 = 5609321668410 := by decide
theorem cert_e1211275157306 : check e1211275157306 [[],[]] .smaller = true := by decide
def e1211275172078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211275172078 : Closed e1211275172078 ∧ code e1211275172078 = 5609321683182 := by decide
theorem cert_e1211275172078 : check e1211275172078 [[],[]] .smaller = true := by decide
def e1211275172086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211275172086 : Closed e1211275172086 ∧ code e1211275172086 = 5609321683190 := by decide
theorem cert_e1211275172086 : check e1211275172086 [[],[]] .smaller = true := by decide
def e1211275172638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211275172638 : Closed e1211275172638 ∧ code e1211275172638 = 5609321683742 := by decide
theorem cert_e1211275172638 : check e1211275172638 [[],[]] .smaller = true := by decide
def e1211275172750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211275172750 : Closed e1211275172750 ∧ code e1211275172750 = 5609321683854 := by decide
theorem cert_e1211275172750 : check e1211275172750 [[],[]] .smaller = true := by decide
def e1211275172974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211275172974 : Closed e1211275172974 ∧ code e1211275172974 = 5609321684078 := by decide
theorem cert_e1211275172974 : check e1211275172974 [[],[]] .smaller = true := by decide
def e1211275172986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211275172986 : Closed e1211275172986 ∧ code e1211275172986 = 5609321684090 := by decide
theorem cert_e1211275172986 : check e1211275172986 [[],[]] .smaller = true := by decide
def e1211275173150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211275173150 : Closed e1211275173150 ∧ code e1211275173150 = 5609321684254 := by decide
theorem cert_e1211275173150 : check e1211275173150 [[],[]] .smaller = true := by decide
def e1211275173318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211275173318 : Closed e1211275173318 ∧ code e1211275173318 = 5609321684422 := by decide
theorem cert_e1211275173318 : check e1211275173318 [[],[]] .smaller = true := by decide
def e1211275173342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1211275173342 : Closed e1211275173342 ∧ code e1211275173342 = 5609321684446 := by decide
theorem cert_e1211275173342 : check e1211275173342 [[],[]] .chain = true := by decide
def e1211275173358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1211275173358 : Closed e1211275173358 ∧ code e1211275173358 = 5609321684462 := by decide
theorem cert_e1211275173358 : check e1211275173358 [[],[]] .chain = true := by decide
def e1211275173430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211275173430 : Closed e1211275173430 ∧ code e1211275173430 = 5609321684534 := by decide
theorem cert_e1211275173430 : check e1211275173430 [[],[]] .smaller = true := by decide
def e1211275173434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211275173434 : Closed e1211275173434 ∧ code e1211275173434 = 5609321684538 := by decide
theorem cert_e1211275173434 : check e1211275173434 [[],[]] .smaller = true := by decide
def e1211275173518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211275173518 : Closed e1211275173518 ∧ code e1211275173518 = 5609321684622 := by decide
theorem cert_e1211275173518 : check e1211275173518 [[],[]] .smaller = true := by decide
def e1211275173574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211275173574 : Closed e1211275173574 ∧ code e1211275173574 = 5609321684678 := by decide
theorem cert_e1211275173574 : check e1211275173574 [[],[]] .smaller = true := by decide
def e1211275173598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1211275173598 : Closed e1211275173598 ∧ code e1211275173598 = 5609321684702 := by decide
theorem cert_e1211275173598 : check e1211275173598 [[],[]] .chain = true := by decide
def e1211275173622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1211275173622 : Closed e1211275173622 ∧ code e1211275173622 = 5609321684726 := by decide
theorem cert_e1211275173622 : check e1211275173622 [[],[]] .chain = true := by decide
def e1211275173742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1211275173742 : Closed e1211275173742 ∧ code e1211275173742 = 5609321684846 := by decide
theorem cert_e1211275173742 : check e1211275173742 [[],[]] .chain = true := by decide
def e1211275173750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1211275173750 : Closed e1211275173750 ∧ code e1211275173750 = 5609321684854 := by decide
theorem cert_e1211275173750 : check e1211275173750 [[],[]] .chain = true := by decide
def e1211275175710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211275175710 : Closed e1211275175710 ∧ code e1211275175710 = 5609321686814 := by decide
theorem cert_e1211275175710 : check e1211275175710 [[],[]] .smaller = true := by decide
def e1211275175822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211275175822 : Closed e1211275175822 ∧ code e1211275175822 = 5609321686926 := by decide
theorem cert_e1211275175822 : check e1211275175822 [[],[]] .smaller = true := by decide
def e1211275178782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211275178782 : Closed e1211275178782 ∧ code e1211275178782 = 5609321689886 := by decide
theorem cert_e1211275178782 : check e1211275178782 [[],[]] .smaller = true := by decide
def e1211275178950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211275178950 : Closed e1211275178950 ∧ code e1211275178950 = 5609321690054 := by decide
theorem cert_e1211275178950 : check e1211275178950 [[],[]] .smaller = true := by decide
def e1211275178974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211275178974 : Closed e1211275178974 ∧ code e1211275178974 = 5609321690078 := by decide
theorem cert_e1211275178974 : check e1211275178974 [[],[]] .chain = true := by decide
def e1211275178990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211275178990 : Closed e1211275178990 ∧ code e1211275178990 = 5609321690094 := by decide
theorem cert_e1211275178990 : check e1211275178990 [[],[]] .chain = true := by decide
def e1211275180430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211275180430 : Closed e1211275180430 ∧ code e1211275180430 = 5609321691534 := by decide
theorem cert_e1211275180430 : check e1211275180430 [[],[]] .smaller = true := by decide
def e1211275180486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211275180486 : Closed e1211275180486 ∧ code e1211275180486 = 5609321691590 := by decide
theorem cert_e1211275180486 : check e1211275180486 [[],[]] .smaller = true := by decide
def e1211275180510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211275180510 : Closed e1211275180510 ∧ code e1211275180510 = 5609321691614 := by decide
theorem cert_e1211275180510 : check e1211275180510 [[],[]] .chain = true := by decide
def e1211275180534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211275180534 : Closed e1211275180534 ∧ code e1211275180534 = 5609321691638 := by decide
theorem cert_e1211275180534 : check e1211275180534 [[],[]] .chain = true := by decide
def e1211275181294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211275181294 : Closed e1211275181294 ∧ code e1211275181294 = 5609321692398 := by decide
theorem cert_e1211275181294 : check e1211275181294 [[],[]] .chain = true := by decide
def e1211275181302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211275181302 : Closed e1211275181302 ∧ code e1211275181302 = 5609321692406 := by decide
theorem cert_e1211275181302 : check e1211275181302 [[],[]] .chain = true := by decide
def e1211275238254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211275238254 : Closed e1211275238254 ∧ code e1211275238254 = 5609321749358 := by decide
theorem cert_e1211275238254 : check e1211275238254 [[],[]] .chain = true := by decide
def e1211275238262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211275238262 : Closed e1211275238262 ∧ code e1211275238262 = 5609321749366 := by decide
theorem cert_e1211275238262 : check e1211275238262 [[],[]] .chain = true := by decide
def e1211275238326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211275238326 : Closed e1211275238326 ∧ code e1211275238326 = 5609321749430 := by decide
theorem cert_e1211275238326 : check e1211275238326 [[],[]] .chain = true := by decide
def e1211275238766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211275238766 : Closed e1211275238766 ∧ code e1211275238766 = 5609321749870 := by decide
theorem cert_e1211275238766 : check e1211275238766 [[],[]] .chain = true := by decide
def e1211275238774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211275238774 : Closed e1211275238774 ∧ code e1211275238774 = 5609321749878 := by decide
theorem cert_e1211275238774 : check e1211275238774 [[],[]] .chain = true := by decide
def e1211275238830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211275238830 : Closed e1211275238830 ∧ code e1211275238830 = 5609321749934 := by decide
theorem cert_e1211275238830 : check e1211275238830 [[],[]] .chain = true := by decide
def e1211275238842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211275238842 : Closed e1211275238842 ∧ code e1211275238842 = 5609321749946 := by decide
theorem cert_e1211275238842 : check e1211275238842 [[],[]] .chain = true := by decide
def e1211275238870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211275238870 : Closed e1211275238870 ∧ code e1211275238870 = 5609321749974 := by decide
theorem cert_e1211275238870 : check e1211275238870 [[],[]] .chain = true := by decide
def e1211275238874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211275238874 : Closed e1211275238874 ∧ code e1211275238874 = 5609321749978 := by decide
theorem cert_e1211275238874 : check e1211275238874 [[],[]] .chain = true := by decide
def e1211275239094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211275239094 : Closed e1211275239094 ∧ code e1211275239094 = 5609321750198 := by decide
theorem cert_e1211275239094 : check e1211275239094 [[],[]] .chain = true := by decide
def e1211275239126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211275239126 : Closed e1211275239126 ∧ code e1211275239126 = 5609321750230 := by decide
theorem cert_e1211275239126 : check e1211275239126 [[],[]] .chain = true := by decide
def e1211275239130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211275239130 : Closed e1211275239130 ∧ code e1211275239130 = 5609321750234 := by decide
theorem cert_e1211275239130 : check e1211275239130 [[],[]] .chain = true := by decide
def e1211275241326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211275241326 : Closed e1211275241326 ∧ code e1211275241326 = 5609321752430 := by decide
theorem cert_e1211275241326 : check e1211275241326 [[],[]] .chain = true := by decide
def e1211275241334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211275241334 : Closed e1211275241334 ∧ code e1211275241334 = 5609321752438 := by decide
theorem cert_e1211275241334 : check e1211275241334 [[],[]] .chain = true := by decide
def e1211275241398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211275241398 : Closed e1211275241398 ∧ code e1211275241398 = 5609321752502 := by decide
theorem cert_e1211275241398 : check e1211275241398 [[],[]] .chain = true := by decide
def e1211275242734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211275242734 : Closed e1211275242734 ∧ code e1211275242734 = 5609321753838 := by decide
theorem cert_e1211275242734 : check e1211275242734 [[],[]] .chain = true := by decide
def e1211275242742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211275242742 : Closed e1211275242742 ∧ code e1211275242742 = 5609321753846 := by decide
theorem cert_e1211275242742 : check e1211275242742 [[],[]] .chain = true := by decide
def e1211275243126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211275243126 : Closed e1211275243126 ∧ code e1211275243126 = 5609321754230 := by decide
theorem cert_e1211275243126 : check e1211275243126 [[],[]] .chain = true := by decide
def e1211275244398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211275244398 : Closed e1211275244398 ∧ code e1211275244398 = 5609321755502 := by decide
theorem cert_e1211275244398 : check e1211275244398 [[],[]] .chain = true := by decide
def e1211275244406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211275244406 : Closed e1211275244406 ∧ code e1211275244406 = 5609321755510 := by decide
theorem cert_e1211275244406 : check e1211275244406 [[],[]] .chain = true := by decide
def e1211275244462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211275244462 : Closed e1211275244462 ∧ code e1211275244462 = 5609321755566 := by decide
theorem cert_e1211275244462 : check e1211275244462 [[],[]] .chain = true := by decide
def e1211275244474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211275244474 : Closed e1211275244474 ∧ code e1211275244474 = 5609321755578 := by decide
theorem cert_e1211275244474 : check e1211275244474 [[],[]] .chain = true := by decide
def e1211275244502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211275244502 : Closed e1211275244502 ∧ code e1211275244502 = 5609321755606 := by decide
theorem cert_e1211275244502 : check e1211275244502 [[],[]] .chain = true := by decide
def e1211275244506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211275244506 : Closed e1211275244506 ∧ code e1211275244506 = 5609321755610 := by decide
theorem cert_e1211275244506 : check e1211275244506 [[],[]] .chain = true := by decide
def e1211275244782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211275244782 : Closed e1211275244782 ∧ code e1211275244782 = 5609321755886 := by decide
theorem cert_e1211275244782 : check e1211275244782 [[],[]] .chain = true := by decide
def e1211275244790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211275244790 : Closed e1211275244790 ∧ code e1211275244790 = 5609321755894 := by decide
theorem cert_e1211275244790 : check e1211275244790 [[],[]] .chain = true := by decide
def e1211275245166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211275245166 : Closed e1211275245166 ∧ code e1211275245166 = 5609321756270 := by decide
theorem cert_e1211275245166 : check e1211275245166 [[],[]] .chain = true := by decide
def e1211275245178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211275245178 : Closed e1211275245178 ∧ code e1211275245178 = 5609321756282 := by decide
theorem cert_e1211275245178 : check e1211275245178 [[],[]] .chain = true := by decide
def e1211275245366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211275245366 : Closed e1211275245366 ∧ code e1211275245366 = 5609321756470 := by decide
theorem cert_e1211275245366 : check e1211275245366 [[],[]] .chain = true := by decide
def e1211275245370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211275245370 : Closed e1211275245370 ∧ code e1211275245370 = 5609321756474 := by decide
theorem cert_e1211275245370 : check e1211275245370 [[],[]] .chain = true := by decide
def e1211275246006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211275246006 : Closed e1211275246006 ∧ code e1211275246006 = 5609321757110 := by decide
theorem cert_e1211275246006 : check e1211275246006 [[],[]] .chain = true := by decide
def e1211275246038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211275246038 : Closed e1211275246038 ∧ code e1211275246038 = 5609321757142 := by decide
theorem cert_e1211275246038 : check e1211275246038 [[],[]] .chain = true := by decide
def e1211275246042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211275246042 : Closed e1211275246042 ∧ code e1211275246042 = 5609321757146 := by decide
theorem cert_e1211275246042 : check e1211275246042 [[],[]] .chain = true := by decide
def e1211275246198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211275246198 : Closed e1211275246198 ∧ code e1211275246198 = 5609321757302 := by decide
theorem cert_e1211275246198 : check e1211275246198 [[],[]] .chain = true := by decide
def e1211275246390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211275246390 : Closed e1211275246390 ∧ code e1211275246390 = 5609321757494 := by decide
theorem cert_e1211275246390 : check e1211275246390 [[],[]] .chain = true := by decide
def e1211275246394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211275246394 : Closed e1211275246394 ∧ code e1211275246394 = 5609321757498 := by decide
theorem cert_e1211275246394 : check e1211275246394 [[],[]] .chain = true := by decide
def e1211275253614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211275253614 : Closed e1211275253614 ∧ code e1211275253614 = 5609321764718 := by decide
theorem cert_e1211275253614 : check e1211275253614 [[],[]] .chain = true := by decide
def e1211275253622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211275253622 : Closed e1211275253622 ∧ code e1211275253622 = 5609321764726 := by decide
theorem cert_e1211275253622 : check e1211275253622 [[],[]] .chain = true := by decide
end Blc.Floor42
