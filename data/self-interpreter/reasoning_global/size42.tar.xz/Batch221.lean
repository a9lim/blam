import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210373078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211210373078 : Closed e1211210373078 ∧ code e1211210373078 = 5609256884182 := by decide
theorem cert_e1211210373078 : check e1211210373078 [[],[]] .chain = true := by decide
def e1211210373082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211210373082 : Closed e1211210373082 ∧ code e1211210373082 = 5609256884186 := by decide
theorem cert_e1211210373082 : check e1211210373082 [[],[]] .chain = true := by decide
def e1211210373182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e1211210373182 : Closed e1211210373182 ∧ code e1211210373182 = 5609256884286 := by decide
theorem cert_e1211210373182 : check e1211210373182 [[],[]] .smaller = true := by decide
def e1211210373598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211210373598 : Closed e1211210373598 ∧ code e1211210373598 = 5609256884702 := by decide
theorem cert_e1211210373598 : check e1211210373598 [[],[]] .chain = true := by decide
def e1211210373602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211210373602 : Closed e1211210373602 ∧ code e1211210373602 = 5609256884706 := by decide
theorem cert_e1211210373602 : check e1211210373602 [[],[]] .smaller = true := by decide
def e1211210373614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211210373614 : Closed e1211210373614 ∧ code e1211210373614 = 5609256884718 := by decide
theorem cert_e1211210373614 : check e1211210373614 [[],[]] .smaller = true := by decide
def e1211210373622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211210373622 : Closed e1211210373622 ∧ code e1211210373622 = 5609256884726 := by decide
theorem cert_e1211210373622 : check e1211210373622 [[],[]] .chain = true := by decide
def e1211210374366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210374366 : Closed e1211210374366 ∧ code e1211210374366 = 5609256885470 := by decide
theorem cert_e1211210374366 : check e1211210374366 [[],[]] .chain = true := by decide
def e1211210374394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210374394 : Closed e1211210374394 ∧ code e1211210374394 = 5609256885498 := by decide
theorem cert_e1211210374394 : check e1211210374394 [[],[]] .chain = true := by decide
def e1211210374670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211210374670 : Closed e1211210374670 ∧ code e1211210374670 = 5609256885774 := by decide
theorem cert_e1211210374670 : check e1211210374670 [[],[]] .smaller = true := by decide
def e1211210374718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211210374718 : Closed e1211210374718 ∧ code e1211210374718 = 5609256885822 := by decide
theorem cert_e1211210374718 : check e1211210374718 [[],[]] .chain = true := by decide
def e1211210374754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211210374754 : Closed e1211210374754 ∧ code e1211210374754 = 5609256885858 := by decide
theorem cert_e1211210374754 : check e1211210374754 [[],[]] .smaller = true := by decide
def e1211210374766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210374766 : Closed e1211210374766 ∧ code e1211210374766 = 5609256885870 := by decide
theorem cert_e1211210374766 : check e1211210374766 [[],[]] .smaller = true := by decide
def e1211210374778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210374778 : Closed e1211210374778 ∧ code e1211210374778 = 5609256885882 := by decide
theorem cert_e1211210374778 : check e1211210374778 [[],[]] .smaller = true := by decide
def e1211210374942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211210374942 : Closed e1211210374942 ∧ code e1211210374942 = 5609256886046 := by decide
theorem cert_e1211210374942 : check e1211210374942 [[],[]] .chain = true := by decide
def e1211210374966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210374966 : Closed e1211210374966 ∧ code e1211210374966 = 5609256886070 := by decide
theorem cert_e1211210374966 : check e1211210374966 [[],[]] .chain = true := by decide
def e1211210374970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210374970 : Closed e1211210374970 ∧ code e1211210374970 = 5609256886074 := by decide
theorem cert_e1211210374970 : check e1211210374970 [[],[]] .chain = true := by decide
def e1211210384318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e1211210384318 : Closed e1211210384318 ∧ code e1211210384318 = 5609256895422 := by decide
theorem cert_e1211210384318 : check e1211210384318 [[],[]] .chain = true := by decide
def e1211210384374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e1211210384374 : Closed e1211210384374 ∧ code e1211210384374 = 5609256895478 := by decide
theorem cert_e1211210384374 : check e1211210384374 [[],[]] .chain = true := by decide
def e1211210386198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211210386198 : Closed e1211210386198 ∧ code e1211210386198 = 5609256897302 := by decide
theorem cert_e1211210386198 : check e1211210386198 [[],[]] .smaller = true := by decide
def e1211210386270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211210386270 : Closed e1211210386270 ∧ code e1211210386270 = 5609256897374 := by decide
theorem cert_e1211210386270 : check e1211210386270 [[],[]] .chain = true := by decide
def e1211210386274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211210386274 : Closed e1211210386274 ∧ code e1211210386274 = 5609256897378 := by decide
theorem cert_e1211210386274 : check e1211210386274 [[],[]] .smaller = true := by decide
def e1211210386286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211210386286 : Closed e1211210386286 ∧ code e1211210386286 = 5609256897390 := by decide
theorem cert_e1211210386286 : check e1211210386286 [[],[]] .smaller = true := by decide
def e1211210386294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211210386294 : Closed e1211210386294 ∧ code e1211210386294 = 5609256897398 := by decide
theorem cert_e1211210386294 : check e1211210386294 [[],[]] .smaller = true := by decide
def e1211210386298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211210386298 : Closed e1211210386298 ∧ code e1211210386298 = 5609256897402 := by decide
theorem cert_e1211210386298 : check e1211210386298 [[],[]] .chain = true := by decide
def e1211210386314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211210386314 : Closed e1211210386314 ∧ code e1211210386314 = 5609256897418 := by decide
theorem cert_e1211210386314 : check e1211210386314 [[],[]] .smaller = true := by decide
def e1211210386338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211210386338 : Closed e1211210386338 ∧ code e1211210386338 = 5609256897442 := by decide
theorem cert_e1211210386338 : check e1211210386338 [[],[]] .smaller = true := by decide
def e1211210386350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211210386350 : Closed e1211210386350 ∧ code e1211210386350 = 5609256897454 := by decide
theorem cert_e1211210386350 : check e1211210386350 [[],[]] .smaller = true := by decide
def e1211210386362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211210386362 : Closed e1211210386362 ∧ code e1211210386362 = 5609256897466 := by decide
theorem cert_e1211210386362 : check e1211210386362 [[],[]] .smaller = true := by decide
def e1211210386390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211210386390 : Closed e1211210386390 ∧ code e1211210386390 = 5609256897494 := by decide
theorem cert_e1211210386390 : check e1211210386390 [[],[]] .smaller = true := by decide
def e1211210386394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211210386394 : Closed e1211210386394 ∧ code e1211210386394 = 5609256897498 := by decide
theorem cert_e1211210386394 : check e1211210386394 [[],[]] .smaller = true := by decide
def e1211210386410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211210386410 : Closed e1211210386410 ∧ code e1211210386410 = 5609256897514 := by decide
theorem cert_e1211210386410 : check e1211210386410 [[],[]] .chain = true := by decide
def e1211210386462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211210386462 : Closed e1211210386462 ∧ code e1211210386462 = 5609256897566 := by decide
theorem cert_e1211210386462 : check e1211210386462 [[],[]] .smaller = true := by decide
def e1211210386654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210386654 : Closed e1211210386654 ∧ code e1211210386654 = 5609256897758 := by decide
theorem cert_e1211210386654 : check e1211210386654 [[],[]] .chain = true := by decide
def e1211210386658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211210386658 : Closed e1211210386658 ∧ code e1211210386658 = 5609256897762 := by decide
theorem cert_e1211210386658 : check e1211210386658 [[],[]] .smaller = true := by decide
def e1211210386670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211210386670 : Closed e1211210386670 ∧ code e1211210386670 = 5609256897774 := by decide
theorem cert_e1211210386670 : check e1211210386670 [[],[]] .smaller = true := by decide
def e1211210386678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211210386678 : Closed e1211210386678 ∧ code e1211210386678 = 5609256897782 := by decide
theorem cert_e1211210386678 : check e1211210386678 [[],[]] .smaller = true := by decide
def e1211210386682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210386682 : Closed e1211210386682 ∧ code e1211210386682 = 5609256897786 := by decide
theorem cert_e1211210386682 : check e1211210386682 [[],[]] .chain = true := by decide
def e1211210386958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211210386958 : Closed e1211210386958 ∧ code e1211210386958 = 5609256898062 := by decide
theorem cert_e1211210386958 : check e1211210386958 [[],[]] .smaller = true := by decide
def e1211210387006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211210387006 : Closed e1211210387006 ∧ code e1211210387006 = 5609256898110 := by decide
theorem cert_e1211210387006 : check e1211210387006 [[],[]] .chain = true := by decide
def e1211210387042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211210387042 : Closed e1211210387042 ∧ code e1211210387042 = 5609256898146 := by decide
theorem cert_e1211210387042 : check e1211210387042 [[],[]] .smaller = true := by decide
def e1211210387054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210387054 : Closed e1211210387054 ∧ code e1211210387054 = 5609256898158 := by decide
theorem cert_e1211210387054 : check e1211210387054 [[],[]] .smaller = true := by decide
def e1211210387066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210387066 : Closed e1211210387066 ∧ code e1211210387066 = 5609256898170 := by decide
theorem cert_e1211210387066 : check e1211210387066 [[],[]] .smaller = true := by decide
def e1211210387254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210387254 : Closed e1211210387254 ∧ code e1211210387254 = 5609256898358 := by decide
theorem cert_e1211210387254 : check e1211210387254 [[],[]] .smaller = true := by decide
def e1211210387258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210387258 : Closed e1211210387258 ∧ code e1211210387258 = 5609256898362 := by decide
theorem cert_e1211210387258 : check e1211210387258 [[],[]] .smaller = true := by decide
def e1211210387342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211210387342 : Closed e1211210387342 ∧ code e1211210387342 = 5609256898446 := by decide
theorem cert_e1211210387342 : check e1211210387342 [[],[]] .chain = true := by decide
def e1211210387354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210387354 : Closed e1211210387354 ∧ code e1211210387354 = 5609256898458 := by decide
theorem cert_e1211210387354 : check e1211210387354 [[],[]] .chain = true := by decide
def e1211210392030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211210392030 : Closed e1211210392030 ∧ code e1211210392030 = 5609256903134 := by decide
theorem cert_e1211210392030 : check e1211210392030 [[],[]] .chain = true := by decide
def e1211210392046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211210392046 : Closed e1211210392046 ∧ code e1211210392046 = 5609256903150 := by decide
theorem cert_e1211210392046 : check e1211210392046 [[],[]] .chain = true := by decide
def e1211210392054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211210392054 : Closed e1211210392054 ∧ code e1211210392054 = 5609256903158 := by decide
theorem cert_e1211210392054 : check e1211210392054 [[],[]] .chain = true := by decide
def e1211210393006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211210393006 : Closed e1211210393006 ∧ code e1211210393006 = 5609256904110 := by decide
theorem cert_e1211210393006 : check e1211210393006 [[],[]] .chain = true := by decide
def e1211210393014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211210393014 : Closed e1211210393014 ∧ code e1211210393014 = 5609256904118 := by decide
theorem cert_e1211210393014 : check e1211210393014 [[],[]] .chain = true := by decide
def e1211210393018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211210393018 : Closed e1211210393018 ∧ code e1211210393018 = 5609256904122 := by decide
theorem cert_e1211210393018 : check e1211210393018 [[],[]] .chain = true := by decide
def e1211210393046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211210393046 : Closed e1211210393046 ∧ code e1211210393046 = 5609256904150 := by decide
theorem cert_e1211210393046 : check e1211210393046 [[],[]] .chain = true := by decide
def e1211210393050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211210393050 : Closed e1211210393050 ∧ code e1211210393050 = 5609256904154 := by decide
theorem cert_e1211210393050 : check e1211210393050 [[],[]] .chain = true := by decide
def e1211210393066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211210393066 : Closed e1211210393066 ∧ code e1211210393066 = 5609256904170 := by decide
theorem cert_e1211210393066 : check e1211210393066 [[],[]] .chain = true := by decide
def e1211210393198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210393198 : Closed e1211210393198 ∧ code e1211210393198 = 5609256904302 := by decide
theorem cert_e1211210393198 : check e1211210393198 [[],[]] .chain = true := by decide
def e1211210393206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211210393206 : Closed e1211210393206 ∧ code e1211210393206 = 5609256904310 := by decide
theorem cert_e1211210393206 : check e1211210393206 [[],[]] .chain = true := by decide
def e1211210393210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210393210 : Closed e1211210393210 ∧ code e1211210393210 = 5609256904314 := by decide
theorem cert_e1211210393210 : check e1211210393210 [[],[]] .chain = true := by decide
def e1211210393374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211210393374 : Closed e1211210393374 ∧ code e1211210393374 = 5609256904478 := by decide
theorem cert_e1211210393374 : check e1211210393374 [[],[]] .chain = true := by decide
def e1211210393398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210393398 : Closed e1211210393398 ∧ code e1211210393398 = 5609256904502 := by decide
theorem cert_e1211210393398 : check e1211210393398 [[],[]] .chain = true := by decide
def e1211210393402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210393402 : Closed e1211210393402 ∧ code e1211210393402 = 5609256904506 := by decide
theorem cert_e1211210393402 : check e1211210393402 [[],[]] .chain = true := by decide
def e1211210393486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211210393486 : Closed e1211210393486 ∧ code e1211210393486 = 5609256904590 := by decide
theorem cert_e1211210393486 : check e1211210393486 [[],[]] .chain = true := by decide
def e1211210393498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210393498 : Closed e1211210393498 ∧ code e1211210393498 = 5609256904602 := by decide
theorem cert_e1211210393498 : check e1211210393498 [[],[]] .chain = true := by decide
def e1211210712686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210712686 : Closed e1211210712686 ∧ code e1211210712686 = 5609257223790 := by decide
theorem cert_e1211210712686 : check e1211210712686 [[],[]] .sourceHead = true := by decide
def e1211210712698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210712698 : Closed e1211210712698 ∧ code e1211210712698 = 5609257223802 := by decide
theorem cert_e1211210712698 : check e1211210712698 [[],[]] .sourceHead = true := by decide
def e1211210715934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211210715934 : Closed e1211210715934 ∧ code e1211210715934 = 5609257227038 := by decide
theorem cert_e1211210715934 : check e1211210715934 [[],[]] .sourceHead = true := by decide
def e1211210716102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211210716102 : Closed e1211210716102 ∧ code e1211210716102 = 5609257227206 := by decide
theorem cert_e1211210716102 : check e1211210716102 [[],[]] .sourceHead = true := by decide
def e1211210839406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211210839406 : Closed e1211210839406 ∧ code e1211210839406 = 5609257350510 := by decide
theorem cert_e1211210839406 : check e1211210839406 [[],[]] .chain = true := by decide
def e1211210839414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211210839414 : Closed e1211210839414 ∧ code e1211210839414 = 5609257350518 := by decide
theorem cert_e1211210839414 : check e1211210839414 [[],[]] .chain = true := by decide
def e1211210839470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211210839470 : Closed e1211210839470 ∧ code e1211210839470 = 5609257350574 := by decide
theorem cert_e1211210839470 : check e1211210839470 [[],[]] .chain = true := by decide
def e1211210839482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211210839482 : Closed e1211210839482 ∧ code e1211210839482 = 5609257350586 := by decide
theorem cert_e1211210839482 : check e1211210839482 [[],[]] .chain = true := by decide
def e1211210839510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211210839510 : Closed e1211210839510 ∧ code e1211210839510 = 5609257350614 := by decide
theorem cert_e1211210839510 : check e1211210839510 [[],[]] .chain = true := by decide
def e1211210839514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211210839514 : Closed e1211210839514 ∧ code e1211210839514 = 5609257350618 := by decide
theorem cert_e1211210839514 : check e1211210839514 [[],[]] .chain = true := by decide
def e1211210839726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211210839726 : Closed e1211210839726 ∧ code e1211210839726 = 5609257350830 := by decide
theorem cert_e1211210839726 : check e1211210839726 [[],[]] .chain = true := by decide
def e1211210839738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211210839738 : Closed e1211210839738 ∧ code e1211210839738 = 5609257350842 := by decide
theorem cert_e1211210839738 : check e1211210839738 [[],[]] .chain = true := by decide
def e1211210839786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211210839786 : Closed e1211210839786 ∧ code e1211210839786 = 5609257350890 := by decide
theorem cert_e1211210839786 : check e1211210839786 [[],[]] .chain = true := by decide
def e1211210839894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211210839894 : Closed e1211210839894 ∧ code e1211210839894 = 5609257350998 := by decide
theorem cert_e1211210839894 : check e1211210839894 [[],[]] .chain = true := by decide
def e1211210839898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211210839898 : Closed e1211210839898 ∧ code e1211210839898 = 5609257351002 := by decide
theorem cert_e1211210839898 : check e1211210839898 [[],[]] .chain = true := by decide
def e1211210839914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211210839914 : Closed e1211210839914 ∧ code e1211210839914 = 5609257351018 := by decide
theorem cert_e1211210839914 : check e1211210839914 [[],[]] .chain = true := by decide
def e1211210840750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211210840750 : Closed e1211210840750 ∧ code e1211210840750 = 5609257351854 := by decide
theorem cert_e1211210840750 : check e1211210840750 [[],[]] .chain = true := by decide
def e1211210840762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211210840762 : Closed e1211210840762 ∧ code e1211210840762 = 5609257351866 := by decide
theorem cert_e1211210840762 : check e1211210840762 [[],[]] .chain = true := by decide
def e1211210840810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211210840810 : Closed e1211210840810 ∧ code e1211210840810 = 5609257351914 := by decide
theorem cert_e1211210840810 : check e1211210840810 [[],[]] .chain = true := by decide
def e1211210841002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211210841002 : Closed e1211210841002 ∧ code e1211210841002 = 5609257352106 := by decide
theorem cert_e1211210841002 : check e1211210841002 [[],[]] .chain = true := by decide
def e1211210841430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211210841430 : Closed e1211210841430 ∧ code e1211210841430 = 5609257352534 := by decide
theorem cert_e1211210841430 : check e1211210841430 [[],[]] .chain = true := by decide
def e1211210841434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211210841434 : Closed e1211210841434 ∧ code e1211210841434 = 5609257352538 := by decide
theorem cert_e1211210841434 : check e1211210841434 [[],[]] .chain = true := by decide
def e1211210841450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211210841450 : Closed e1211210841450 ∧ code e1211210841450 = 5609257352554 := by decide
theorem cert_e1211210841450 : check e1211210841450 [[],[]] .chain = true := by decide
def e1211210841514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211210841514 : Closed e1211210841514 ∧ code e1211210841514 = 5609257352618 := by decide
theorem cert_e1211210841514 : check e1211210841514 [[],[]] .chain = true := by decide
def e1211210842478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211210842478 : Closed e1211210842478 ∧ code e1211210842478 = 5609257353582 := by decide
theorem cert_e1211210842478 : check e1211210842478 [[],[]] .chain = true := by decide
def e1211210842486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211210842486 : Closed e1211210842486 ∧ code e1211210842486 = 5609257353590 := by decide
theorem cert_e1211210842486 : check e1211210842486 [[],[]] .chain = true := by decide
def e1211210842542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211210842542 : Closed e1211210842542 ∧ code e1211210842542 = 5609257353646 := by decide
theorem cert_e1211210842542 : check e1211210842542 [[],[]] .chain = true := by decide
def e1211210842554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211210842554 : Closed e1211210842554 ∧ code e1211210842554 = 5609257353658 := by decide
theorem cert_e1211210842554 : check e1211210842554 [[],[]] .chain = true := by decide
def e1211210843246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211210843246 : Closed e1211210843246 ∧ code e1211210843246 = 5609257354350 := by decide
theorem cert_e1211210843246 : check e1211210843246 [[],[]] .chain = true := by decide
def e1211210843258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211210843258 : Closed e1211210843258 ∧ code e1211210843258 = 5609257354362 := by decide
theorem cert_e1211210843258 : check e1211210843258 [[],[]] .chain = true := by decide
def e1211210843422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211210843422 : Closed e1211210843422 ∧ code e1211210843422 = 5609257354526 := by decide
theorem cert_e1211210843422 : check e1211210843422 [[],[]] .chain = true := by decide
def e1211210843590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211210843590 : Closed e1211210843590 ∧ code e1211210843590 = 5609257354694 := by decide
theorem cert_e1211210843590 : check e1211210843590 [[],[]] .chain = true := by decide
def e1211210843694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211210843694 : Closed e1211210843694 ∧ code e1211210843694 = 5609257354798 := by decide
theorem cert_e1211210843694 : check e1211210843694 [[],[]] .chain = true := by decide
def e1211210843874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211210843874 : Closed e1211210843874 ∧ code e1211210843874 = 5609257354978 := by decide
theorem cert_e1211210843874 : check e1211210843874 [[],[]] .chain = true := by decide
def e1211210843886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211210843886 : Closed e1211210843886 ∧ code e1211210843886 = 5609257354990 := by decide
theorem cert_e1211210843886 : check e1211210843886 [[],[]] .sourceHead = true := by decide
def e1211210844014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211210844014 : Closed e1211210844014 ∧ code e1211210844014 = 5609257355118 := by decide
theorem cert_e1211210844014 : check e1211210844014 [[],[]] .chain = true := by decide
def e1211210844022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211210844022 : Closed e1211210844022 ∧ code e1211210844022 = 5609257355126 := by decide
theorem cert_e1211210844022 : check e1211210844022 [[],[]] .chain = true := by decide
def e1211210844042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211210844042 : Closed e1211210844042 ∧ code e1211210844042 = 5609257355146 := by decide
theorem cert_e1211210844042 : check e1211210844042 [[],[]] .chain = true := by decide
def e1211210844066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211210844066 : Closed e1211210844066 ∧ code e1211210844066 = 5609257355170 := by decide
theorem cert_e1211210844066 : check e1211210844066 [[],[]] .chain = true := by decide
def e1211210844078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211210844078 : Closed e1211210844078 ∧ code e1211210844078 = 5609257355182 := by decide
theorem cert_e1211210844078 : check e1211210844078 [[],[]] .sourceHead = true := by decide
def e1211210844086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211210844086 : Closed e1211210844086 ∧ code e1211210844086 = 5609257355190 := by decide
theorem cert_e1211210844086 : check e1211210844086 [[],[]] .chain = true := by decide
def e1211210844090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211210844090 : Closed e1211210844090 ∧ code e1211210844090 = 5609257355194 := by decide
theorem cert_e1211210844090 : check e1211210844090 [[],[]] .sourceHead = true := by decide
def e1211210845550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211210845550 : Closed e1211210845550 ∧ code e1211210845550 = 5609257356654 := by decide
theorem cert_e1211210845550 : check e1211210845550 [[],[]] .chain = true := by decide
def e1211210845558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211210845558 : Closed e1211210845558 ∧ code e1211210845558 = 5609257356662 := by decide
theorem cert_e1211210845558 : check e1211210845558 [[],[]] .chain = true := by decide
def e1211210845614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211210845614 : Closed e1211210845614 ∧ code e1211210845614 = 5609257356718 := by decide
theorem cert_e1211210845614 : check e1211210845614 [[],[]] .chain = true := by decide
def e1211210845626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211210845626 : Closed e1211210845626 ∧ code e1211210845626 = 5609257356730 := by decide
theorem cert_e1211210845626 : check e1211210845626 [[],[]] .chain = true := by decide
def e1211210845654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211210845654 : Closed e1211210845654 ∧ code e1211210845654 = 5609257356758 := by decide
theorem cert_e1211210845654 : check e1211210845654 [[],[]] .chain = true := by decide
def e1211210845658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211210845658 : Closed e1211210845658 ∧ code e1211210845658 = 5609257356762 := by decide
theorem cert_e1211210845658 : check e1211210845658 [[],[]] .chain = true := by decide
def e1211210845870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211210845870 : Closed e1211210845870 ∧ code e1211210845870 = 5609257356974 := by decide
theorem cert_e1211210845870 : check e1211210845870 [[],[]] .chain = true := by decide
def e1211210845882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211210845882 : Closed e1211210845882 ∧ code e1211210845882 = 5609257356986 := by decide
theorem cert_e1211210845882 : check e1211210845882 [[],[]] .chain = true := by decide
def e1211210845930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211210845930 : Closed e1211210845930 ∧ code e1211210845930 = 5609257357034 := by decide
theorem cert_e1211210845930 : check e1211210845930 [[],[]] .chain = true := by decide
def e1211210846038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211210846038 : Closed e1211210846038 ∧ code e1211210846038 = 5609257357142 := by decide
theorem cert_e1211210846038 : check e1211210846038 [[],[]] .chain = true := by decide
def e1211210846042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211210846042 : Closed e1211210846042 ∧ code e1211210846042 = 5609257357146 := by decide
theorem cert_e1211210846042 : check e1211210846042 [[],[]] .chain = true := by decide
def e1211210846058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211210846058 : Closed e1211210846058 ∧ code e1211210846058 = 5609257357162 := by decide
theorem cert_e1211210846058 : check e1211210846058 [[],[]] .chain = true := by decide
def e1211210846318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211210846318 : Closed e1211210846318 ∧ code e1211210846318 = 5609257357422 := by decide
theorem cert_e1211210846318 : check e1211210846318 [[],[]] .chain = true := by decide
def e1211210846494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211210846494 : Closed e1211210846494 ∧ code e1211210846494 = 5609257357598 := by decide
theorem cert_e1211210846494 : check e1211210846494 [[],[]] .chain = true := by decide
def e1211210846690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211210846690 : Closed e1211210846690 ∧ code e1211210846690 = 5609257357794 := by decide
theorem cert_e1211210846690 : check e1211210846690 [[],[]] .chain = true := by decide
def e1211210846702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211210846702 : Closed e1211210846702 ∧ code e1211210846702 = 5609257357806 := by decide
theorem cert_e1211210846702 : check e1211210846702 [[],[]] .sourceHead = true := by decide
def e1211210847086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211210847086 : Closed e1211210847086 ∧ code e1211210847086 = 5609257358190 := by decide
theorem cert_e1211210847086 : check e1211210847086 [[],[]] .chain = true := by decide
def e1211210847094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211210847094 : Closed e1211210847094 ∧ code e1211210847094 = 5609257358198 := by decide
theorem cert_e1211210847094 : check e1211210847094 [[],[]] .chain = true := by decide
def e1211210847150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211210847150 : Closed e1211210847150 ∧ code e1211210847150 = 5609257358254 := by decide
theorem cert_e1211210847150 : check e1211210847150 [[],[]] .chain = true := by decide
def e1211210847162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211210847162 : Closed e1211210847162 ∧ code e1211210847162 = 5609257358266 := by decide
theorem cert_e1211210847162 : check e1211210847162 [[],[]] .chain = true := by decide
def e1211210847190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211210847190 : Closed e1211210847190 ∧ code e1211210847190 = 5609257358294 := by decide
theorem cert_e1211210847190 : check e1211210847190 [[],[]] .chain = true := by decide
def e1211210847194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211210847194 : Closed e1211210847194 ∧ code e1211210847194 = 5609257358298 := by decide
theorem cert_e1211210847194 : check e1211210847194 [[],[]] .chain = true := by decide
def e1211210847470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211210847470 : Closed e1211210847470 ∧ code e1211210847470 = 5609257358574 := by decide
theorem cert_e1211210847470 : check e1211210847470 [[],[]] .chain = true := by decide
def e1211210847478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211210847478 : Closed e1211210847478 ∧ code e1211210847478 = 5609257358582 := by decide
theorem cert_e1211210847478 : check e1211210847478 [[],[]] .chain = true := by decide
def e1211210847854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210847854 : Closed e1211210847854 ∧ code e1211210847854 = 5609257358958 := by decide
theorem cert_e1211210847854 : check e1211210847854 [[],[]] .chain = true := by decide
def e1211210847866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210847866 : Closed e1211210847866 ∧ code e1211210847866 = 5609257358970 := by decide
theorem cert_e1211210847866 : check e1211210847866 [[],[]] .chain = true := by decide
def e1211210848006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210848006 : Closed e1211210848006 ∧ code e1211210848006 = 5609257359110 := by decide
theorem cert_e1211210848006 : check e1211210848006 [[],[]] .chain = true := by decide
def e1211210848030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211210848030 : Closed e1211210848030 ∧ code e1211210848030 = 5609257359134 := by decide
theorem cert_e1211210848030 : check e1211210848030 [[],[]] .sourceHead = true := by decide
def e1211210848054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210848054 : Closed e1211210848054 ∧ code e1211210848054 = 5609257359158 := by decide
theorem cert_e1211210848054 : check e1211210848054 [[],[]] .chain = true := by decide
def e1211210848058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210848058 : Closed e1211210848058 ∧ code e1211210848058 = 5609257359162 := by decide
theorem cert_e1211210848058 : check e1211210848058 [[],[]] .chain = true := by decide
def e1211210848302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211210848302 : Closed e1211210848302 ∧ code e1211210848302 = 5609257359406 := by decide
theorem cert_e1211210848302 : check e1211210848302 [[],[]] .chain = true := by decide
def e1211210848494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211210848494 : Closed e1211210848494 ∧ code e1211210848494 = 5609257359598 := by decide
theorem cert_e1211210848494 : check e1211210848494 [[],[]] .chain = true := by decide
def e1211210848502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211210848502 : Closed e1211210848502 ∧ code e1211210848502 = 5609257359606 := by decide
theorem cert_e1211210848502 : check e1211210848502 [[],[]] .chain = true := by decide
def e1211210848686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211210848686 : Closed e1211210848686 ∧ code e1211210848686 = 5609257359790 := by decide
theorem cert_e1211210848686 : check e1211210848686 [[],[]] .chain = true := by decide
def e1211210848698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211210848698 : Closed e1211210848698 ∧ code e1211210848698 = 5609257359802 := by decide
theorem cert_e1211210848698 : check e1211210848698 [[],[]] .chain = true := by decide
def e1211210848746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211210848746 : Closed e1211210848746 ∧ code e1211210848746 = 5609257359850 := by decide
theorem cert_e1211210848746 : check e1211210848746 [[],[]] .chain = true := by decide
def e1211210848878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210848878 : Closed e1211210848878 ∧ code e1211210848878 = 5609257359982 := by decide
theorem cert_e1211210848878 : check e1211210848878 [[],[]] .chain = true := by decide
def e1211210848890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210848890 : Closed e1211210848890 ∧ code e1211210848890 = 5609257359994 := by decide
theorem cert_e1211210848890 : check e1211210848890 [[],[]] .chain = true := by decide
def e1211210849054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211210849054 : Closed e1211210849054 ∧ code e1211210849054 = 5609257360158 := by decide
theorem cert_e1211210849054 : check e1211210849054 [[],[]] .chain = true := by decide
def e1211210849154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210849154 : Closed e1211210849154 ∧ code e1211210849154 = 5609257360258 := by decide
theorem cert_e1211210849154 : check e1211210849154 [[],[]] .chain = true := by decide
def e1211210849166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211210849166 : Closed e1211210849166 ∧ code e1211210849166 = 5609257360270 := by decide
theorem cert_e1211210849166 : check e1211210849166 [[],[]] .chain = true := by decide
def e1211210849178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210849178 : Closed e1211210849178 ∧ code e1211210849178 = 5609257360282 := by decide
theorem cert_e1211210849178 : check e1211210849178 [[],[]] .chain = true := by decide
def e1211210849302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211210849302 : Closed e1211210849302 ∧ code e1211210849302 = 5609257360406 := by decide
theorem cert_e1211210849302 : check e1211210849302 [[],[]] .chain = true := by decide
def e1211210849306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211210849306 : Closed e1211210849306 ∧ code e1211210849306 = 5609257360410 := by decide
theorem cert_e1211210849306 : check e1211210849306 [[],[]] .chain = true := by decide
def e1211210849350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211210849350 : Closed e1211210849350 ∧ code e1211210849350 = 5609257360454 := by decide
theorem cert_e1211210849350 : check e1211210849350 [[],[]] .chain = true := by decide
def e1211210849378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211210849378 : Closed e1211210849378 ∧ code e1211210849378 = 5609257360482 := by decide
theorem cert_e1211210849378 : check e1211210849378 [[],[]] .chain = true := by decide
def e1211210849390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211210849390 : Closed e1211210849390 ∧ code e1211210849390 = 5609257360494 := by decide
theorem cert_e1211210849390 : check e1211210849390 [[],[]] .sourceHead = true := by decide
def e1211210849398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211210849398 : Closed e1211210849398 ∧ code e1211210849398 = 5609257360502 := by decide
theorem cert_e1211210849398 : check e1211210849398 [[],[]] .chain = true := by decide
def e1211210849402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211210849402 : Closed e1211210849402 ∧ code e1211210849402 = 5609257360506 := by decide
theorem cert_e1211210849402 : check e1211210849402 [[],[]] .sourceHead = true := by decide
def e1211210849494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211210849494 : Closed e1211210849494 ∧ code e1211210849494 = 5609257360598 := by decide
theorem cert_e1211210849494 : check e1211210849494 [[],[]] .chain = true := by decide
def e1211210849498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211210849498 : Closed e1211210849498 ∧ code e1211210849498 = 5609257360602 := by decide
theorem cert_e1211210849498 : check e1211210849498 [[],[]] .chain = true := by decide
def e1211210849514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211210849514 : Closed e1211210849514 ∧ code e1211210849514 = 5609257360618 := by decide
theorem cert_e1211210849514 : check e1211210849514 [[],[]] .chain = true := by decide
def e1211210849542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210849542 : Closed e1211210849542 ∧ code e1211210849542 = 5609257360646 := by decide
theorem cert_e1211210849542 : check e1211210849542 [[],[]] .chain = true := by decide
def e1211210849566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211210849566 : Closed e1211210849566 ∧ code e1211210849566 = 5609257360670 := by decide
theorem cert_e1211210849566 : check e1211210849566 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
