import Tables
import Batch117
namespace Blc.Floor42.Grades117
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1205858217402 : ¬ IsSelfInterpreter e1205858217402 := cutM5_2 (by decide)
#print axioms ex_e1205858217402
theorem ex_e1205858217434 : ¬ IsSelfInterpreter e1205858217434 := cutM5_2 (by decide)
#print axioms ex_e1205858217434
theorem ex_e1205858470766 : ¬ IsSelfInterpreter e1205858470766 := cutM5_2 (by decide)
#print axioms ex_e1205858470766
theorem ex_e1205858217658 : ¬ IsSelfInterpreter e1205858217658 := cutM6_2 (by decide)
#print axioms ex_e1205858217658
theorem ex_e1205858217818 : ¬ IsSelfInterpreter e1205858217818 := cutM6_2 (by decide)
#print axioms ex_e1205858217818
theorem ex_e1205858220474 : ¬ IsSelfInterpreter e1205858220474 := cutM14_0 (by decide)
#print axioms ex_e1205858220474
theorem ex_e1205858221274 : ¬ IsSelfInterpreter e1205858221274 := cutM14_0 (by decide)
#print axioms ex_e1205858221274
end Blc.Floor42.Grades117
