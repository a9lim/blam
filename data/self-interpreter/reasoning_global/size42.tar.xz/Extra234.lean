import Batch234
import ExtraBase
namespace Blc.Floor42.Extra234
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211277310390 : Term := (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1))))))
theorem ex_e1211277310390 : ¬ IsSelfInterpreter e1211277310390 := by
  intro he
  have hp := replay_sound (t := e1211277310390) (u := t_e1211277310390) (ps := [[],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))))) h
#print axioms ex_e1211277310390
private def t_e1211277310422 : Term := (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1))))))
theorem ex_e1211277310422 : ¬ IsSelfInterpreter e1211277310422 := by
  intro he
  have hp := replay_sound (t := e1211277310422) (u := t_e1211277310422) (ps := [[],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))))) h
#print axioms ex_e1211277310422
end Blc.Floor42.Extra234
