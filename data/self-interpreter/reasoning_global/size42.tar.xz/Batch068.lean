import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194823781294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194823781294 : Closed e1194823781294 ∧ code e1194823781294 = 5592870292398 := by decide
theorem cert_e1194823781294 : check e1194823781294 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194823781306 : Closed e1194823781306 ∧ code e1194823781306 = 5592870292410 := by decide
theorem cert_e1194823781306 : check e1194823781306 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194823781334 : Closed e1194823781334 ∧ code e1194823781334 = 5592870292438 := by decide
theorem cert_e1194823781334 : check e1194823781334 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194823781338 : Closed e1194823781338 ∧ code e1194823781338 = 5592870292442 := by decide
theorem cert_e1194823781338 : check e1194823781338 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194823781614 : Closed e1194823781614 ∧ code e1194823781614 = 5592870292718 := by decide
theorem cert_e1194823781614 : check e1194823781614 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194823781622 : Closed e1194823781622 ∧ code e1194823781622 = 5592870292726 := by decide
theorem cert_e1194823781622 : check e1194823781622 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194823781998 : Closed e1194823781998 ∧ code e1194823781998 = 5592870293102 := by decide
theorem cert_e1194823781998 : check e1194823781998 [[],[.left],[.left]] .smaller = true := by decide
def e1194823782010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194823782010 : Closed e1194823782010 ∧ code e1194823782010 = 5592870293114 := by decide
theorem cert_e1194823782010 : check e1194823782010 [[],[.left],[.left]] .smaller = true := by decide
def e1194823782198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194823782198 : Closed e1194823782198 ∧ code e1194823782198 = 5592870293302 := by decide
theorem cert_e1194823782198 : check e1194823782198 [[],[.left],[.left]] .smaller = true := by decide
def e1194823782202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194823782202 : Closed e1194823782202 ∧ code e1194823782202 = 5592870293306 := by decide
theorem cert_e1194823782202 : check e1194823782202 [[],[.left],[.left]] .smaller = true := by decide
def e1194873367918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1194873367918 : Closed e1194873367918 ∧ code e1194873367918 = 5592919879022 := by decide
theorem cert_e1194873367918 : check e1194873367918 [[],[.left],[]] .chain = true := by decide
def e1194873367926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1194873367926 : Closed e1194873367926 ∧ code e1194873367926 = 5592919879030 := by decide
theorem cert_e1194873367926 : check e1194873367926 [[],[.left],[]] .chain = true := by decide
def e1194873367982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1194873367982 : Closed e1194873367982 ∧ code e1194873367982 = 5592919879086 := by decide
theorem cert_e1194873367982 : check e1194873367982 [[],[.left],[]] .chain = true := by decide
def e1194873367994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1194873367994 : Closed e1194873367994 ∧ code e1194873367994 = 5592919879098 := by decide
theorem cert_e1194873367994 : check e1194873367994 [[],[.left],[]] .chain = true := by decide
def e1194873368022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1194873368022 : Closed e1194873368022 ∧ code e1194873368022 = 5592919879126 := by decide
theorem cert_e1194873368022 : check e1194873368022 [[],[.left],[]] .chain = true := by decide
def e1194873368026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1194873368026 : Closed e1194873368026 ∧ code e1194873368026 = 5592919879130 := by decide
theorem cert_e1194873368026 : check e1194873368026 [[],[.left],[]] .chain = true := by decide
def e1194873368238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1194873368238 : Closed e1194873368238 ∧ code e1194873368238 = 5592919879342 := by decide
theorem cert_e1194873368238 : check e1194873368238 [[],[.left],[]] .chain = true := by decide
def e1194873368250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1194873368250 : Closed e1194873368250 ∧ code e1194873368250 = 5592919879354 := by decide
theorem cert_e1194873368250 : check e1194873368250 [[],[.left],[]] .chain = true := by decide
def e1194873368298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1194873368298 : Closed e1194873368298 ∧ code e1194873368298 = 5592919879402 := by decide
theorem cert_e1194873368298 : check e1194873368298 [[],[.left],[]] .chain = true := by decide
def e1194873368406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1194873368406 : Closed e1194873368406 ∧ code e1194873368406 = 5592919879510 := by decide
theorem cert_e1194873368406 : check e1194873368406 [[],[.left],[]] .chain = true := by decide
def e1194873368410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1194873368410 : Closed e1194873368410 ∧ code e1194873368410 = 5592919879514 := by decide
theorem cert_e1194873368410 : check e1194873368410 [[],[.left],[]] .chain = true := by decide
def e1194873368426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1194873368426 : Closed e1194873368426 ∧ code e1194873368426 = 5592919879530 := by decide
theorem cert_e1194873368426 : check e1194873368426 [[],[.left],[]] .chain = true := by decide
def e1194873369454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1194873369454 : Closed e1194873369454 ∧ code e1194873369454 = 5592919880558 := by decide
theorem cert_e1194873369454 : check e1194873369454 [[],[.left],[]] .chain = true := by decide
def e1194873369462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1194873369462 : Closed e1194873369462 ∧ code e1194873369462 = 5592919880566 := by decide
theorem cert_e1194873369462 : check e1194873369462 [[],[.left],[]] .chain = true := by decide
def e1194873369518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1194873369518 : Closed e1194873369518 ∧ code e1194873369518 = 5592919880622 := by decide
theorem cert_e1194873369518 : check e1194873369518 [[],[.left],[]] .chain = true := by decide
def e1194873369530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1194873369530 : Closed e1194873369530 ∧ code e1194873369530 = 5592919880634 := by decide
theorem cert_e1194873369530 : check e1194873369530 [[],[.left],[]] .chain = true := by decide
def e1194873369558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1194873369558 : Closed e1194873369558 ∧ code e1194873369558 = 5592919880662 := by decide
theorem cert_e1194873369558 : check e1194873369558 [[],[.left],[]] .chain = true := by decide
def e1194873369562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1194873369562 : Closed e1194873369562 ∧ code e1194873369562 = 5592919880666 := by decide
theorem cert_e1194873369562 : check e1194873369562 [[],[.left],[]] .chain = true := by decide
def e1194873369838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1194873369838 : Closed e1194873369838 ∧ code e1194873369838 = 5592919880942 := by decide
theorem cert_e1194873369838 : check e1194873369838 [[],[.left],[]] .chain = true := by decide
def e1194873369846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1194873369846 : Closed e1194873369846 ∧ code e1194873369846 = 5592919880950 := by decide
theorem cert_e1194873369846 : check e1194873369846 [[],[.left],[]] .chain = true := by decide
def e1194873370222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1194873370222 : Closed e1194873370222 ∧ code e1194873370222 = 5592919881326 := by decide
theorem cert_e1194873370222 : check e1194873370222 [[],[.left],[]] .chain = true := by decide
def e1194873370234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1194873370234 : Closed e1194873370234 ∧ code e1194873370234 = 5592919881338 := by decide
theorem cert_e1194873370234 : check e1194873370234 [[],[.left],[]] .chain = true := by decide
def e1194873370422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194873370422 : Closed e1194873370422 ∧ code e1194873370422 = 5592919881526 := by decide
theorem cert_e1194873370422 : check e1194873370422 [[],[.left],[]] .chain = true := by decide
def e1194873370426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194873370426 : Closed e1194873370426 ∧ code e1194873370426 = 5592919881530 := by decide
theorem cert_e1194873370426 : check e1194873370426 [[],[.left],[]] .chain = true := by decide
def e1194873371054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1194873371054 : Closed e1194873371054 ∧ code e1194873371054 = 5592919882158 := by decide
theorem cert_e1194873371054 : check e1194873371054 [[],[.left],[]] .chain = true := by decide
def e1194873371066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1194873371066 : Closed e1194873371066 ∧ code e1194873371066 = 5592919882170 := by decide
theorem cert_e1194873371066 : check e1194873371066 [[],[.left],[]] .chain = true := by decide
def e1194873371114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1194873371114 : Closed e1194873371114 ∧ code e1194873371114 = 5592919882218 := by decide
theorem cert_e1194873371114 : check e1194873371114 [[],[.left],[]] .chain = true := by decide
def e1194873371246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1194873371246 : Closed e1194873371246 ∧ code e1194873371246 = 5592919882350 := by decide
theorem cert_e1194873371246 : check e1194873371246 [[],[.left],[]] .chain = true := by decide
def e1194873371258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1194873371258 : Closed e1194873371258 ∧ code e1194873371258 = 5592919882362 := by decide
theorem cert_e1194873371258 : check e1194873371258 [[],[.left],[]] .chain = true := by decide
def e1194873371546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1194873371546 : Closed e1194873371546 ∧ code e1194873371546 = 5592919882650 := by decide
theorem cert_e1194873371546 : check e1194873371546 [[],[.left],[]] .chain = true := by decide
def e1194873371862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1194873371862 : Closed e1194873371862 ∧ code e1194873371862 = 5592919882966 := by decide
theorem cert_e1194873371862 : check e1194873371862 [[],[.left],[]] .chain = true := by decide
def e1194873371866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1194873371866 : Closed e1194873371866 ∧ code e1194873371866 = 5592919882970 := by decide
theorem cert_e1194873371866 : check e1194873371866 [[],[.left],[]] .chain = true := by decide
def e1194873371882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1194873371882 : Closed e1194873371882 ∧ code e1194873371882 = 5592919882986 := by decide
theorem cert_e1194873371882 : check e1194873371882 [[],[.left],[]] .chain = true := by decide
def e1194873371958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194873371958 : Closed e1194873371958 ∧ code e1194873371958 = 5592919883062 := by decide
theorem cert_e1194873371958 : check e1194873371958 [[],[.left],[]] .chain = true := by decide
def e1194873371962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194873371962 : Closed e1194873371962 ∧ code e1194873371962 = 5592919883066 := by decide
theorem cert_e1194873371962 : check e1194873371962 [[],[.left],[]] .chain = true := by decide
def e1194873372058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1194873372058 : Closed e1194873372058 ∧ code e1194873372058 = 5592919883162 := by decide
theorem cert_e1194873372058 : check e1194873372058 [[],[.left],[]] .chain = true := by decide
def e1194873375598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1194873375598 : Closed e1194873375598 ∧ code e1194873375598 = 5592919886702 := by decide
theorem cert_e1194873375598 : check e1194873375598 [[],[.left],[]] .chain = true := by decide
def e1194873375606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1194873375606 : Closed e1194873375606 ∧ code e1194873375606 = 5592919886710 := by decide
theorem cert_e1194873375606 : check e1194873375606 [[],[.left],[]] .chain = true := by decide
def e1194873375662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1194873375662 : Closed e1194873375662 ∧ code e1194873375662 = 5592919886766 := by decide
theorem cert_e1194873375662 : check e1194873375662 [[],[.left],[]] .chain = true := by decide
def e1194873375674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1194873375674 : Closed e1194873375674 ∧ code e1194873375674 = 5592919886778 := by decide
theorem cert_e1194873375674 : check e1194873375674 [[],[.left],[]] .chain = true := by decide
def e1194873375702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1194873375702 : Closed e1194873375702 ∧ code e1194873375702 = 5592919886806 := by decide
theorem cert_e1194873375702 : check e1194873375702 [[],[.left],[]] .chain = true := by decide
def e1194873375706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1194873375706 : Closed e1194873375706 ∧ code e1194873375706 = 5592919886810 := by decide
theorem cert_e1194873375706 : check e1194873375706 [[],[.left],[]] .chain = true := by decide
def e1194873375982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194873375982 : Closed e1194873375982 ∧ code e1194873375982 = 5592919887086 := by decide
theorem cert_e1194873375982 : check e1194873375982 [[],[.left],[]] .chain = true := by decide
def e1194873375990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194873375990 : Closed e1194873375990 ∧ code e1194873375990 = 5592919887094 := by decide
theorem cert_e1194873375990 : check e1194873375990 [[],[.left],[]] .chain = true := by decide
def e1194873376366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194873376366 : Closed e1194873376366 ∧ code e1194873376366 = 5592919887470 := by decide
theorem cert_e1194873376366 : check e1194873376366 [[],[.left],[]] .chain = true := by decide
def e1194873376378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194873376378 : Closed e1194873376378 ∧ code e1194873376378 = 5592919887482 := by decide
theorem cert_e1194873376378 : check e1194873376378 [[],[.left],[]] .chain = true := by decide
def e1194873376566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194873376566 : Closed e1194873376566 ∧ code e1194873376566 = 5592919887670 := by decide
theorem cert_e1194873376566 : check e1194873376566 [[],[.left],[]] .chain = true := by decide
def e1194873376570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194873376570 : Closed e1194873376570 ∧ code e1194873376570 = 5592919887674 := by decide
theorem cert_e1194873376570 : check e1194873376570 [[],[.left],[]] .chain = true := by decide
def e1194873382318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1194873382318 : Closed e1194873382318 ∧ code e1194873382318 = 5592919893422 := by decide
theorem cert_e1194873382318 : check e1194873382318 [[],[.left],[]] .chain = true := by decide
def e1194873382330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1194873382330 : Closed e1194873382330 ∧ code e1194873382330 = 5592919893434 := by decide
theorem cert_e1194873382330 : check e1194873382330 [[],[.left],[]] .chain = true := by decide
def e1194873382378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1194873382378 : Closed e1194873382378 ∧ code e1194873382378 = 5592919893482 := by decide
theorem cert_e1194873382378 : check e1194873382378 [[],[.left],[]] .chain = true := by decide
def e1194873382510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194873382510 : Closed e1194873382510 ∧ code e1194873382510 = 5592919893614 := by decide
theorem cert_e1194873382510 : check e1194873382510 [[],[.left],[]] .chain = true := by decide
def e1194873382522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194873382522 : Closed e1194873382522 ∧ code e1194873382522 = 5592919893626 := by decide
theorem cert_e1194873382522 : check e1194873382522 [[],[.left],[]] .chain = true := by decide
def e1194873382810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1194873382810 : Closed e1194873382810 ∧ code e1194873382810 = 5592919893914 := by decide
theorem cert_e1194873382810 : check e1194873382810 [[],[.left],[]] .chain = true := by decide
def e1194873385686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1194873385686 : Closed e1194873385686 ∧ code e1194873385686 = 5592919896790 := by decide
theorem cert_e1194873385686 : check e1194873385686 [[],[.left],[]] .chain = true := by decide
def e1194873385690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1194873385690 : Closed e1194873385690 ∧ code e1194873385690 = 5592919896794 := by decide
theorem cert_e1194873385690 : check e1194873385690 [[],[.left],[]] .chain = true := by decide
def e1194873385706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1194873385706 : Closed e1194873385706 ∧ code e1194873385706 = 5592919896810 := by decide
theorem cert_e1194873385706 : check e1194873385706 [[],[.left],[]] .chain = true := by decide
def e1194873385782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194873385782 : Closed e1194873385782 ∧ code e1194873385782 = 5592919896886 := by decide
theorem cert_e1194873385782 : check e1194873385782 [[],[.left],[]] .chain = true := by decide
def e1194873385786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194873385786 : Closed e1194873385786 ∧ code e1194873385786 = 5592919896890 := by decide
theorem cert_e1194873385786 : check e1194873385786 [[],[.left],[]] .chain = true := by decide
def e1194873385882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1194873385882 : Closed e1194873385882 ∧ code e1194873385882 = 5592919896986 := by decide
theorem cert_e1194873385882 : check e1194873385882 [[],[.left],[]] .chain = true := by decide
def e1194873501422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1194873501422 : Closed e1194873501422 ∧ code e1194873501422 = 5592920012526 := by decide
theorem cert_e1194873501422 : check e1194873501422 [[],[.left],[]] .sourceHead = true := by decide
def e1194873501550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1194873501550 : Closed e1194873501550 ∧ code e1194873501550 = 5592920012654 := by decide
theorem cert_e1194873501550 : check e1194873501550 [[],[.left],[]] .sourceHead = true := by decide
def e1194873501558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1194873501558 : Closed e1194873501558 ∧ code e1194873501558 = 5592920012662 := by decide
theorem cert_e1194873501558 : check e1194873501558 [[],[.left],[]] .sourceHead = true := by decide
def e1194873502446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1194873502446 : Closed e1194873502446 ∧ code e1194873502446 = 5592920013550 := by decide
theorem cert_e1194873502446 : check e1194873502446 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e1194873502638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1194873502638 : Closed e1194873502638 ∧ code e1194873502638 = 5592920013742 := by decide
theorem cert_e1194873502638 : check e1194873502638 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1194873502650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1194873502650 : Closed e1194873502650 ∧ code e1194873502650 = 5592920013754 := by decide
theorem cert_e1194873502650 : check e1194873502650 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1194873503086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1194873503086 : Closed e1194873503086 ∧ code e1194873503086 = 5592920014190 := by decide
theorem cert_e1194873503086 : check e1194873503086 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under,.left,.left]] .identityHead = true := by decide
def e1194873503094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1194873503094 : Closed e1194873503094 ∧ code e1194873503094 = 5592920014198 := by decide
theorem cert_e1194873503094 : check e1194873503094 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194873503150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1194873503150 : Closed e1194873503150 ∧ code e1194873503150 = 5592920014254 := by decide
theorem cert_e1194873503150 : check e1194873503150 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1194873503162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1194873503162 : Closed e1194873503162 ∧ code e1194873503162 = 5592920014266 := by decide
theorem cert_e1194873503162 : check e1194873503162 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194873503190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1194873503190 : Closed e1194873503190 ∧ code e1194873503190 = 5592920014294 := by decide
theorem cert_e1194873503190 : check e1194873503190 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1194873503194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1194873503194 : Closed e1194873503194 ∧ code e1194873503194 = 5592920014298 := by decide
private def t_e1194873503194 : Term := (.lam (.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem cert_e1194873503194 : ¬ IsSelfInterpreter e1194873503194 :=
  wSource (t := t_e1194873503194) (replay_sound (ps := [[],[.left],[],[.under,.left,.left]]) (t := e1194873503194) (by decide)) (by decide)
def e1194873507566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1194873507566 : Closed e1194873507566 ∧ code e1194873507566 = 5592920018670 := by decide
theorem cert_e1194873507566 : check e1194873507566 [[],[.left],[]] .sourceHead = true := by decide
def e1194873507694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1194873507694 : Closed e1194873507694 ∧ code e1194873507694 = 5592920018798 := by decide
theorem cert_e1194873507694 : check e1194873507694 [[],[.left],[]] .sourceHead = true := by decide
def e1194873507702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1194873507702 : Closed e1194873507702 ∧ code e1194873507702 = 5592920018806 := by decide
theorem cert_e1194873507702 : check e1194873507702 [[],[.left],[]] .sourceHead = true := by decide
def e1194873510382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1194873510382 : Closed e1194873510382 ∧ code e1194873510382 = 5592920021486 := by decide
theorem cert_e1194873510382 : check e1194873510382 [[],[.left],[]] .sourceHead = true := by decide
def e1194873511150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194873511150 : Closed e1194873511150 ∧ code e1194873511150 = 5592920022254 := by decide
theorem cert_e1194873511150 : check e1194873511150 [[],[.left],[]] .sourceHead = true := by decide
def e1194873511158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194873511158 : Closed e1194873511158 ∧ code e1194873511158 = 5592920022262 := by decide
theorem cert_e1194873511158 : check e1194873511158 [[],[.left],[]] .sourceHead = true := by decide
def e1194873513710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1194873513710 : Closed e1194873513710 ∧ code e1194873513710 = 5592920024814 := by decide
theorem cert_e1194873513710 : check e1194873513710 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194873513902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1194873513902 : Closed e1194873513902 ∧ code e1194873513902 = 5592920025006 := by decide
theorem cert_e1194873513902 : check e1194873513902 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194873513914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1194873513914 : Closed e1194873513914 ∧ code e1194873513914 = 5592920025018 := by decide
theorem cert_e1194873513914 : checkPay e1194873513914 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1194873514478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1194873514478 : Closed e1194873514478 ∧ code e1194873514478 = 5592920025582 := by decide
theorem cert_e1194873514478 : check e1194873514478 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1194873515630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194873515630 : Closed e1194873515630 ∧ code e1194873515630 = 5592920026734 := by decide
theorem cert_e1194873515630 : check e1194873515630 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1194873515642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194873515642 : Closed e1194873515642 ∧ code e1194873515642 = 5592920026746 := by decide
theorem cert_e1194873515642 : check e1194873515642 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194873516910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1194873516910 : Closed e1194873516910 ∧ code e1194873516910 = 5592920028014 := by decide
theorem cert_e1194873516910 : check e1194873516910 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873516918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1194873516918 : Closed e1194873516918 ∧ code e1194873516918 = 5592920028022 := by decide
theorem cert_e1194873516918 : check e1194873516918 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873516974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1194873516974 : Closed e1194873516974 ∧ code e1194873516974 = 5592920028078 := by decide
theorem cert_e1194873516974 : check e1194873516974 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873516986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1194873516986 : Closed e1194873516986 ∧ code e1194873516986 = 5592920028090 := by decide
theorem cert_e1194873516986 : check e1194873516986 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194873517014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1194873517014 : Closed e1194873517014 ∧ code e1194873517014 = 5592920028118 := by decide
theorem cert_e1194873517014 : check e1194873517014 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1194873517018 : Closed e1194873517018 ∧ code e1194873517018 = 5592920028122 := by decide
theorem cert_e1194873517018 : check e1194873517018 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194873517294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194873517294 : Closed e1194873517294 ∧ code e1194873517294 = 5592920028398 := by decide
theorem cert_e1194873517294 : check e1194873517294 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194873517302 : Closed e1194873517302 ∧ code e1194873517302 = 5592920028406 := by decide
theorem cert_e1194873517302 : check e1194873517302 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194873517678 : Closed e1194873517678 ∧ code e1194873517678 = 5592920028782 := by decide
theorem cert_e1194873517678 : check e1194873517678 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194873517690 : Closed e1194873517690 ∧ code e1194873517690 = 5592920028794 := by decide
theorem cert_e1194873517690 : check e1194873517690 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194873517878 : Closed e1194873517878 ∧ code e1194873517878 = 5592920028982 := by decide
theorem cert_e1194873517878 : check e1194873517878 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873517882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194873517882 : Closed e1194873517882 ∧ code e1194873517882 = 5592920028986 := by decide
theorem cert_e1194873517882 : check e1194873517882 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1194873523054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1194873523054 : Closed e1194873523054 ∧ code e1194873523054 = 5592920034158 := by decide
theorem cert_e1194873523054 : check e1194873523054 [[],[.left],[]] .chain = true := by decide
def e1194873523062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1194873523062 : Closed e1194873523062 ∧ code e1194873523062 = 5592920034166 := by decide
theorem cert_e1194873523062 : check e1194873523062 [[],[.left],[]] .chain = true := by decide
def e1194873523118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1194873523118 : Closed e1194873523118 ∧ code e1194873523118 = 5592920034222 := by decide
theorem cert_e1194873523118 : check e1194873523118 [[],[.left],[]] .chain = true := by decide
def e1194873523130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1194873523130 : Closed e1194873523130 ∧ code e1194873523130 = 5592920034234 := by decide
theorem cert_e1194873523130 : check e1194873523130 [[],[.left],[]] .chain = true := by decide
def e1194873523158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1194873523158 : Closed e1194873523158 ∧ code e1194873523158 = 5592920034262 := by decide
theorem cert_e1194873523158 : check e1194873523158 [[],[.left],[]] .chain = true := by decide
def e1194873523162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1194873523162 : Closed e1194873523162 ∧ code e1194873523162 = 5592920034266 := by decide
theorem cert_e1194873523162 : check e1194873523162 [[],[.left],[]] .chain = true := by decide
def e1194873523438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194873523438 : Closed e1194873523438 ∧ code e1194873523438 = 5592920034542 := by decide
theorem cert_e1194873523438 : check e1194873523438 [[],[.left],[]] .chain = true := by decide
def e1194873523446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194873523446 : Closed e1194873523446 ∧ code e1194873523446 = 5592920034550 := by decide
theorem cert_e1194873523446 : check e1194873523446 [[],[.left],[]] .chain = true := by decide
def e1194873523822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194873523822 : Closed e1194873523822 ∧ code e1194873523822 = 5592920034926 := by decide
theorem cert_e1194873523822 : check e1194873523822 [[],[.left],[]] .chain = true := by decide
def e1194873523834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194873523834 : Closed e1194873523834 ∧ code e1194873523834 = 5592920034938 := by decide
theorem cert_e1194873523834 : check e1194873523834 [[],[.left],[]] .chain = true := by decide
def e1194873524022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194873524022 : Closed e1194873524022 ∧ code e1194873524022 = 5592920035126 := by decide
theorem cert_e1194873524022 : check e1194873524022 [[],[.left],[]] .chain = true := by decide
def e1194873524026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194873524026 : Closed e1194873524026 ∧ code e1194873524026 = 5592920035130 := by decide
theorem cert_e1194873524026 : check e1194873524026 [[],[.left],[]] .chain = true := by decide
def e1194873532142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1194873532142 : Closed e1194873532142 ∧ code e1194873532142 = 5592920043246 := by decide
theorem cert_e1194873532142 : check e1194873532142 [[],[.left],[]] .sourceHead = true := by decide
def e1194873532270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1194873532270 : Closed e1194873532270 ∧ code e1194873532270 = 5592920043374 := by decide
theorem cert_e1194873532270 : check e1194873532270 [[],[.left],[]] .sourceHead = true := by decide
def e1194873532278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1194873532278 : Closed e1194873532278 ∧ code e1194873532278 = 5592920043382 := by decide
theorem cert_e1194873532278 : check e1194873532278 [[],[.left],[]] .sourceHead = true := by decide
def e1194873534958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1194873534958 : Closed e1194873534958 ∧ code e1194873534958 = 5592920046062 := by decide
theorem cert_e1194873534958 : check e1194873534958 [[],[.left],[]] .sourceHead = true := by decide
def e1194873535726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1194873535726 : Closed e1194873535726 ∧ code e1194873535726 = 5592920046830 := by decide
theorem cert_e1194873535726 : check e1194873535726 [[],[.left],[]] .sourceHead = true := by decide
def e1194873535734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1194873535734 : Closed e1194873535734 ∧ code e1194873535734 = 5592920046838 := by decide
theorem cert_e1194873535734 : check e1194873535734 [[],[.left],[]] .sourceHead = true := by decide
def e1194873558766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1194873558766 : Closed e1194873558766 ∧ code e1194873558766 = 5592920069870 := by decide
theorem cert_e1194873558766 : check e1194873558766 [[],[.left],[],[.under]] .three = true := by decide
def e1194873558958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1194873558958 : Closed e1194873558958 ∧ code e1194873558958 = 5592920070062 := by decide
theorem cert_e1194873558958 : check e1194873558958 [[],[.left],[],[.under]] .three = true := by decide
def e1194873558970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1194873558970 : Closed e1194873558970 ∧ code e1194873558970 = 5592920070074 := by decide
theorem cert_e1194873558970 : check e1194873558970 [[],[.left],[],[.under]] .three = true := by decide
def e1194873559534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1194873559534 : Closed e1194873559534 ∧ code e1194873559534 = 5592920070638 := by decide
theorem cert_e1194873559534 : check e1194873559534 [[],[.left],[],[.under]] .three = true := by decide
def e1194873560686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1194873560686 : Closed e1194873560686 ∧ code e1194873560686 = 5592920071790 := by decide
theorem cert_e1194873560686 : check e1194873560686 [[],[.left],[],[.under]] .three = true := by decide
def e1194873560698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1194873560698 : Closed e1194873560698 ∧ code e1194873560698 = 5592920071802 := by decide
theorem cert_e1194873560698 : check e1194873560698 [[],[.left],[],[.under]] .three = true := by decide
def e1194873572206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194873572206 : Closed e1194873572206 ∧ code e1194873572206 = 5592920083310 := by decide
theorem cert_e1194873572206 : check e1194873572206 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194873572214 : Closed e1194873572214 ∧ code e1194873572214 = 5592920083318 := by decide
theorem cert_e1194873572214 : check e1194873572214 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194873572270 : Closed e1194873572270 ∧ code e1194873572270 = 5592920083374 := by decide
theorem cert_e1194873572270 : check e1194873572270 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194873572282 : Closed e1194873572282 ∧ code e1194873572282 = 5592920083386 := by decide
theorem cert_e1194873572282 : check e1194873572282 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194873572310 : Closed e1194873572310 ∧ code e1194873572310 = 5592920083414 := by decide
theorem cert_e1194873572310 : check e1194873572310 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194873572314 : Closed e1194873572314 ∧ code e1194873572314 = 5592920083418 := by decide
theorem cert_e1194873572314 : check e1194873572314 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194873572590 : Closed e1194873572590 ∧ code e1194873572590 = 5592920083694 := by decide
theorem cert_e1194873572590 : check e1194873572590 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194873572598 : Closed e1194873572598 ∧ code e1194873572598 = 5592920083702 := by decide
theorem cert_e1194873572598 : check e1194873572598 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194873572974 : Closed e1194873572974 ∧ code e1194873572974 = 5592920084078 := by decide
theorem cert_e1194873572974 : check e1194873572974 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873572986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194873572986 : Closed e1194873572986 ∧ code e1194873572986 = 5592920084090 := by decide
theorem cert_e1194873572986 : check e1194873572986 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873573174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194873573174 : Closed e1194873573174 ∧ code e1194873573174 = 5592920084278 := by decide
theorem cert_e1194873573174 : check e1194873573174 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194873573178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194873573178 : Closed e1194873573178 ∧ code e1194873573178 = 5592920084282 := by decide
theorem cert_e1194873573178 : check e1194873573178 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194874112878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1194874112878 : Closed e1194874112878 ∧ code e1194874112878 = 5592920623982 := by decide
theorem cert_e1194874112878 : check e1194874112878 [[],[.left],[],[]] .smaller = true := by decide
def e1194874112886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1194874112886 : Closed e1194874112886 ∧ code e1194874112886 = 5592920623990 := by decide
theorem cert_e1194874112886 : check e1194874112886 [[],[.left],[],[]] .smaller = true := by decide
def e1194874112942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1194874112942 : Closed e1194874112942 ∧ code e1194874112942 = 5592920624046 := by decide
theorem cert_e1194874112942 : check e1194874112942 [[],[.left],[],[]] .smaller = true := by decide
def e1194874112954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1194874112954 : Closed e1194874112954 ∧ code e1194874112954 = 5592920624058 := by decide
theorem cert_e1194874112954 : check e1194874112954 [[],[.left],[],[]] .smaller = true := by decide
def e1194874112982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1194874112982 : Closed e1194874112982 ∧ code e1194874112982 = 5592920624086 := by decide
theorem cert_e1194874112982 : check e1194874112982 [[],[.left],[],[]] .smaller = true := by decide
def e1194874112986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1194874112986 : Closed e1194874112986 ∧ code e1194874112986 = 5592920624090 := by decide
theorem cert_e1194874112986 : check e1194874112986 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194874113262 : Closed e1194874113262 ∧ code e1194874113262 = 5592920624366 := by decide
theorem cert_e1194874113262 : check e1194874113262 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194874113270 : Closed e1194874113270 ∧ code e1194874113270 = 5592920624374 := by decide
theorem cert_e1194874113270 : check e1194874113270 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194874113646 : Closed e1194874113646 ∧ code e1194874113646 = 5592920624750 := by decide
theorem cert_e1194874113646 : check e1194874113646 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194874113658 : Closed e1194874113658 ∧ code e1194874113658 = 5592920624762 := by decide
theorem cert_e1194874113658 : check e1194874113658 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194874113846 : Closed e1194874113846 ∧ code e1194874113846 = 5592920624950 := by decide
theorem cert_e1194874113846 : check e1194874113846 [[],[.left],[],[]] .smaller = true := by decide
def e1194874113850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194874113850 : Closed e1194874113850 ∧ code e1194874113850 = 5592920624954 := by decide
theorem cert_e1194874113850 : check e1194874113850 [[],[.left],[],[]] .smaller = true := by decide
def e1195779382126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1195779382126 : Closed e1195779382126 ∧ code e1195779382126 = 5593825893230 := by decide
theorem cert_e1195779382126 : check e1195779382126 [[],[.left],[]] .sourceHead = true := by decide
def e1195779382134 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1195779382134 : Closed e1195779382134 ∧ code e1195779382134 = 5593825893238 := by decide
theorem cert_e1195779382134 : check e1195779382134 [[],[.left],[]] .sourceHead = true := by decide
def e1195779382198 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1195779382198 : Closed e1195779382198 ∧ code e1195779382198 = 5593825893302 := by decide
theorem cert_e1195779382198 : check e1195779382198 [[],[.left],[]] .sourceHead = true := by decide
def e1195779382638 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1195779382638 : Closed e1195779382638 ∧ code e1195779382638 = 5593825893742 := by decide
def e1195779382646 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1195779382646 : Closed e1195779382646 ∧ code e1195779382646 = 5593825893750 := by decide
theorem cert_e1195779382646 : check e1195779382646 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1195779382702 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1195779382702 : Closed e1195779382702 ∧ code e1195779382702 = 5593825893806 := by decide
theorem cert_e1195779382702 : check e1195779382702 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor42
