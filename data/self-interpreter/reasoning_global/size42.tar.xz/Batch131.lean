import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209576485662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1209576485662 : Closed e1209576485662 ∧ code e1209576485662 = 5607622996766 := by decide
theorem cert_e1209576485662 : check e1209576485662 [[],[]] .smaller = true := by decide
def e1209576485830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1209576485830 : Closed e1209576485830 ∧ code e1209576485830 = 5607622996934 := by decide
theorem cert_e1209576485830 : check e1209576485830 [[],[]] .smaller = true := by decide
def e1209576485854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1209576485854 : Closed e1209576485854 ∧ code e1209576485854 = 5607622996958 := by decide
theorem cert_e1209576485854 : check e1209576485854 [[],[]] .sourceHead = true := by decide
def e1209576485870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1209576485870 : Closed e1209576485870 ∧ code e1209576485870 = 5607622996974 := by decide
theorem cert_e1209576485870 : check e1209576485870 [[],[]] .sourceHead = true := by decide
def e1209576487310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1209576487310 : Closed e1209576487310 ∧ code e1209576487310 = 5607622998414 := by decide
theorem cert_e1209576487310 : check e1209576487310 [[],[]] .smaller = true := by decide
def e1209576487366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1209576487366 : Closed e1209576487366 ∧ code e1209576487366 = 5607622998470 := by decide
theorem cert_e1209576487366 : check e1209576487366 [[],[]] .smaller = true := by decide
def e1209576487390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209576487390 : Closed e1209576487390 ∧ code e1209576487390 = 5607622998494 := by decide
theorem cert_e1209576487390 : check e1209576487390 [[],[]] .sourceHead = true := by decide
def e1209576487414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209576487414 : Closed e1209576487414 ∧ code e1209576487414 = 5607622998518 := by decide
theorem cert_e1209576487414 : check e1209576487414 [[],[]] .sourceHead = true := by decide
def e1209576488174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209576488174 : Closed e1209576488174 ∧ code e1209576488174 = 5607622999278 := by decide
theorem cert_e1209576488174 : check e1209576488174 [[],[]] .sourceHead = true := by decide
def e1209576488182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209576488182 : Closed e1209576488182 ∧ code e1209576488182 = 5607622999286 := by decide
theorem cert_e1209576488182 : check e1209576488182 [[],[]] .sourceHead = true := by decide
def e1209576545134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1209576545134 : Closed e1209576545134 ∧ code e1209576545134 = 5607623056238 := by decide
theorem cert_e1209576545134 : check e1209576545134 [[],[]] .sourceHead = true := by decide
def e1209576545142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1209576545142 : Closed e1209576545142 ∧ code e1209576545142 = 5607623056246 := by decide
theorem cert_e1209576545142 : check e1209576545142 [[],[]] .sourceHead = true := by decide
def e1209576545206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1209576545206 : Closed e1209576545206 ∧ code e1209576545206 = 5607623056310 := by decide
theorem cert_e1209576545206 : check e1209576545206 [[],[]] .sourceHead = true := by decide
def e1209576545646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209576545646 : Closed e1209576545646 ∧ code e1209576545646 = 5607623056750 := by decide
theorem cert_e1209576545646 : check e1209576545646 [[],[]] .sourceHead = true := by decide
def e1209576545654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209576545654 : Closed e1209576545654 ∧ code e1209576545654 = 5607623056758 := by decide
theorem cert_e1209576545654 : check e1209576545654 [[],[]] .sourceHead = true := by decide
def e1209576545710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209576545710 : Closed e1209576545710 ∧ code e1209576545710 = 5607623056814 := by decide
theorem cert_e1209576545710 : check e1209576545710 [[],[]] .sourceHead = true := by decide
def e1209576545722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209576545722 : Closed e1209576545722 ∧ code e1209576545722 = 5607623056826 := by decide
theorem cert_e1209576545722 : check e1209576545722 [[],[]] .sourceHead = true := by decide
def e1209576545750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209576545750 : Closed e1209576545750 ∧ code e1209576545750 = 5607623056854 := by decide
theorem cert_e1209576545750 : check e1209576545750 [[],[]] .sourceHead = true := by decide
def e1209576545754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209576545754 : Closed e1209576545754 ∧ code e1209576545754 = 5607623056858 := by decide
theorem cert_e1209576545754 : check e1209576545754 [[],[]] .sourceHead = true := by decide
def e1209576545974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1209576545974 : Closed e1209576545974 ∧ code e1209576545974 = 5607623057078 := by decide
theorem cert_e1209576545974 : check e1209576545974 [[],[]] .sourceHead = true := by decide
def e1209576546006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1209576546006 : Closed e1209576546006 ∧ code e1209576546006 = 5607623057110 := by decide
theorem cert_e1209576546006 : check e1209576546006 [[],[]] .sourceHead = true := by decide
def e1209576546010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1209576546010 : Closed e1209576546010 ∧ code e1209576546010 = 5607623057114 := by decide
theorem cert_e1209576546010 : check e1209576546010 [[],[]] .sourceHead = true := by decide
def e1209576548206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1209576548206 : Closed e1209576548206 ∧ code e1209576548206 = 5607623059310 := by decide
theorem cert_e1209576548206 : check e1209576548206 [[],[]] .sourceHead = true := by decide
def e1209576548214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1209576548214 : Closed e1209576548214 ∧ code e1209576548214 = 5607623059318 := by decide
theorem cert_e1209576548214 : check e1209576548214 [[],[]] .sourceHead = true := by decide
def e1209576548278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1209576548278 : Closed e1209576548278 ∧ code e1209576548278 = 5607623059382 := by decide
theorem cert_e1209576548278 : check e1209576548278 [[],[]] .sourceHead = true := by decide
def e1209576549614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209576549614 : Closed e1209576549614 ∧ code e1209576549614 = 5607623060718 := by decide
theorem cert_e1209576549614 : check e1209576549614 [[],[]] .sourceHead = true := by decide
def e1209576549622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209576549622 : Closed e1209576549622 ∧ code e1209576549622 = 5607623060726 := by decide
theorem cert_e1209576549622 : check e1209576549622 [[],[]] .sourceHead = true := by decide
def e1209576550006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209576550006 : Closed e1209576550006 ∧ code e1209576550006 = 5607623061110 := by decide
theorem cert_e1209576550006 : check e1209576550006 [[],[]] .sourceHead = true := by decide
def e1209576551278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209576551278 : Closed e1209576551278 ∧ code e1209576551278 = 5607623062382 := by decide
theorem cert_e1209576551278 : check e1209576551278 [[],[]] .sourceHead = true := by decide
def e1209576551286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209576551286 : Closed e1209576551286 ∧ code e1209576551286 = 5607623062390 := by decide
theorem cert_e1209576551286 : check e1209576551286 [[],[]] .sourceHead = true := by decide
def e1209576551342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209576551342 : Closed e1209576551342 ∧ code e1209576551342 = 5607623062446 := by decide
theorem cert_e1209576551342 : check e1209576551342 [[],[]] .sourceHead = true := by decide
def e1209576551354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209576551354 : Closed e1209576551354 ∧ code e1209576551354 = 5607623062458 := by decide
theorem cert_e1209576551354 : check e1209576551354 [[],[]] .sourceHead = true := by decide
def e1209576551382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209576551382 : Closed e1209576551382 ∧ code e1209576551382 = 5607623062486 := by decide
theorem cert_e1209576551382 : check e1209576551382 [[],[]] .sourceHead = true := by decide
def e1209576551386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209576551386 : Closed e1209576551386 ∧ code e1209576551386 = 5607623062490 := by decide
theorem cert_e1209576551386 : check e1209576551386 [[],[]] .sourceHead = true := by decide
def e1209576551662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209576551662 : Closed e1209576551662 ∧ code e1209576551662 = 5607623062766 := by decide
theorem cert_e1209576551662 : check e1209576551662 [[],[]] .sourceHead = true := by decide
def e1209576551670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209576551670 : Closed e1209576551670 ∧ code e1209576551670 = 5607623062774 := by decide
theorem cert_e1209576551670 : check e1209576551670 [[],[]] .sourceHead = true := by decide
def e1209576552046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209576552046 : Closed e1209576552046 ∧ code e1209576552046 = 5607623063150 := by decide
theorem cert_e1209576552046 : check e1209576552046 [[],[]] .sourceHead = true := by decide
def e1209576552058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209576552058 : Closed e1209576552058 ∧ code e1209576552058 = 5607623063162 := by decide
theorem cert_e1209576552058 : check e1209576552058 [[],[]] .sourceHead = true := by decide
def e1209576552246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209576552246 : Closed e1209576552246 ∧ code e1209576552246 = 5607623063350 := by decide
theorem cert_e1209576552246 : check e1209576552246 [[],[]] .sourceHead = true := by decide
def e1209576552250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209576552250 : Closed e1209576552250 ∧ code e1209576552250 = 5607623063354 := by decide
theorem cert_e1209576552250 : check e1209576552250 [[],[]] .sourceHead = true := by decide
def e1209576552886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1209576552886 : Closed e1209576552886 ∧ code e1209576552886 = 5607623063990 := by decide
theorem cert_e1209576552886 : check e1209576552886 [[],[]] .sourceHead = true := by decide
def e1209576552918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1209576552918 : Closed e1209576552918 ∧ code e1209576552918 = 5607623064022 := by decide
theorem cert_e1209576552918 : check e1209576552918 [[],[]] .sourceHead = true := by decide
def e1209576552922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1209576552922 : Closed e1209576552922 ∧ code e1209576552922 = 5607623064026 := by decide
theorem cert_e1209576552922 : check e1209576552922 [[],[]] .sourceHead = true := by decide
def e1209576553078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209576553078 : Closed e1209576553078 ∧ code e1209576553078 = 5607623064182 := by decide
theorem cert_e1209576553078 : check e1209576553078 [[],[]] .sourceHead = true := by decide
def e1209576553270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209576553270 : Closed e1209576553270 ∧ code e1209576553270 = 5607623064374 := by decide
theorem cert_e1209576553270 : check e1209576553270 [[],[]] .sourceHead = true := by decide
def e1209576553274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209576553274 : Closed e1209576553274 ∧ code e1209576553274 = 5607623064378 := by decide
theorem cert_e1209576553274 : check e1209576553274 [[],[]] .sourceHead = true := by decide
def e1209576560494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1209576560494 : Closed e1209576560494 ∧ code e1209576560494 = 5607623071598 := by decide
theorem cert_e1209576560494 : check e1209576560494 [[],[]] .sourceHead = true := by decide
def e1209576560502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1209576560502 : Closed e1209576560502 ∧ code e1209576560502 = 5607623071606 := by decide
theorem cert_e1209576560502 : check e1209576560502 [[],[]] .sourceHead = true := by decide
def e1209576560566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1209576560566 : Closed e1209576560566 ∧ code e1209576560566 = 5607623071670 := by decide
theorem cert_e1209576560566 : check e1209576560566 [[],[]] .sourceHead = true := by decide
def e1209576561902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209576561902 : Closed e1209576561902 ∧ code e1209576561902 = 5607623073006 := by decide
theorem cert_e1209576561902 : check e1209576561902 [[],[]] .sourceHead = true := by decide
def e1209576561910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209576561910 : Closed e1209576561910 ∧ code e1209576561910 = 5607623073014 := by decide
theorem cert_e1209576561910 : check e1209576561910 [[],[]] .sourceHead = true := by decide
def e1209576562294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209576562294 : Closed e1209576562294 ∧ code e1209576562294 = 5607623073398 := by decide
theorem cert_e1209576562294 : check e1209576562294 [[],[]] .sourceHead = true := by decide
def e1209576573806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209576573806 : Closed e1209576573806 ∧ code e1209576573806 = 5607623084910 := by decide
theorem cert_e1209576573806 : check e1209576573806 [[],[]] .sourceHead = true := by decide
def e1209576573814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209576573814 : Closed e1209576573814 ∧ code e1209576573814 = 5607623084918 := by decide
theorem cert_e1209576573814 : check e1209576573814 [[],[]] .sourceHead = true := by decide
def e1209576573870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209576573870 : Closed e1209576573870 ∧ code e1209576573870 = 5607623084974 := by decide
theorem cert_e1209576573870 : check e1209576573870 [[],[]] .sourceHead = true := by decide
def e1209576573882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209576573882 : Closed e1209576573882 ∧ code e1209576573882 = 5607623084986 := by decide
theorem cert_e1209576573882 : check e1209576573882 [[],[]] .sourceHead = true := by decide
def e1209576573910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209576573910 : Closed e1209576573910 ∧ code e1209576573910 = 5607623085014 := by decide
theorem cert_e1209576573910 : check e1209576573910 [[],[]] .sourceHead = true := by decide
def e1209576573914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209576573914 : Closed e1209576573914 ∧ code e1209576573914 = 5607623085018 := by decide
theorem cert_e1209576573914 : check e1209576573914 [[],[]] .sourceHead = true := by decide
def e1209576574190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209576574190 : Closed e1209576574190 ∧ code e1209576574190 = 5607623085294 := by decide
theorem cert_e1209576574190 : check e1209576574190 [[],[]] .sourceHead = true := by decide
def e1209576574198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209576574198 : Closed e1209576574198 ∧ code e1209576574198 = 5607623085302 := by decide
theorem cert_e1209576574198 : check e1209576574198 [[],[]] .sourceHead = true := by decide
def e1209576574574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209576574574 : Closed e1209576574574 ∧ code e1209576574574 = 5607623085678 := by decide
theorem cert_e1209576574574 : check e1209576574574 [[],[]] .sourceHead = true := by decide
def e1209576574586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209576574586 : Closed e1209576574586 ∧ code e1209576574586 = 5607623085690 := by decide
theorem cert_e1209576574586 : check e1209576574586 [[],[]] .sourceHead = true := by decide
def e1209576574774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209576574774 : Closed e1209576574774 ∧ code e1209576574774 = 5607623085878 := by decide
theorem cert_e1209576574774 : check e1209576574774 [[],[]] .sourceHead = true := by decide
def e1209576574778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209576574778 : Closed e1209576574778 ∧ code e1209576574778 = 5607623085882 := by decide
theorem cert_e1209576574778 : check e1209576574778 [[],[]] .sourceHead = true := by decide
def e1209576580534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1209576580534 : Closed e1209576580534 ∧ code e1209576580534 = 5607623091638 := by decide
theorem cert_e1209576580534 : check e1209576580534 [[],[]] .sourceHead = true := by decide
def e1209576580566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1209576580566 : Closed e1209576580566 ∧ code e1209576580566 = 5607623091670 := by decide
theorem cert_e1209576580566 : check e1209576580566 [[],[]] .sourceHead = true := by decide
def e1209576580570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1209576580570 : Closed e1209576580570 ∧ code e1209576580570 = 5607623091674 := by decide
theorem cert_e1209576580570 : check e1209576580570 [[],[]] .sourceHead = true := by decide
def e1209576580726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209576580726 : Closed e1209576580726 ∧ code e1209576580726 = 5607623091830 := by decide
theorem cert_e1209576580726 : check e1209576580726 [[],[]] .sourceHead = true := by decide
def e1209576580918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209576580918 : Closed e1209576580918 ∧ code e1209576580918 = 5607623092022 := by decide
theorem cert_e1209576580918 : check e1209576580918 [[],[]] .sourceHead = true := by decide
def e1209576580922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209576580922 : Closed e1209576580922 ∧ code e1209576580922 = 5607623092026 := by decide
theorem cert_e1209576580922 : check e1209576580922 [[],[]] .sourceHead = true := by decide
def e1209576917870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209576917870 : Closed e1209576917870 ∧ code e1209576917870 = 5607623428974 := by decide
theorem cert_e1209576917870 : check e1209576917870 [[],[]] .sourceHead = true := by decide
def e1209576917878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209576917878 : Closed e1209576917878 ∧ code e1209576917878 = 5607623428982 := by decide
theorem cert_e1209576917878 : check e1209576917878 [[],[]] .sourceHead = true := by decide
def e1209576917934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209576917934 : Closed e1209576917934 ∧ code e1209576917934 = 5607623429038 := by decide
theorem cert_e1209576917934 : check e1209576917934 [[],[]] .sourceHead = true := by decide
def e1209576917946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209576917946 : Closed e1209576917946 ∧ code e1209576917946 = 5607623429050 := by decide
theorem cert_e1209576917946 : check e1209576917946 [[],[]] .sourceHead = true := by decide
def e1209576917974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209576917974 : Closed e1209576917974 ∧ code e1209576917974 = 5607623429078 := by decide
theorem cert_e1209576917974 : check e1209576917974 [[],[]] .sourceHead = true := by decide
def e1209576917978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209576917978 : Closed e1209576917978 ∧ code e1209576917978 = 5607623429082 := by decide
theorem cert_e1209576917978 : check e1209576917978 [[],[]] .sourceHead = true := by decide
def e1209576918254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209576918254 : Closed e1209576918254 ∧ code e1209576918254 = 5607623429358 := by decide
theorem cert_e1209576918254 : check e1209576918254 [[],[]] .sourceHead = true := by decide
def e1209576918262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209576918262 : Closed e1209576918262 ∧ code e1209576918262 = 5607623429366 := by decide
theorem cert_e1209576918262 : check e1209576918262 [[],[]] .sourceHead = true := by decide
def e1209576918638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209576918638 : Closed e1209576918638 ∧ code e1209576918638 = 5607623429742 := by decide
theorem cert_e1209576918638 : check e1209576918638 [[],[]] .sourceHead = true := by decide
def e1209576918650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209576918650 : Closed e1209576918650 ∧ code e1209576918650 = 5607623429754 := by decide
theorem cert_e1209576918650 : check e1209576918650 [[],[]] .sourceHead = true := by decide
def e1209576918838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209576918838 : Closed e1209576918838 ∧ code e1209576918838 = 5607623429942 := by decide
theorem cert_e1209576918838 : check e1209576918838 [[],[]] .sourceHead = true := by decide
def e1209576918842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209576918842 : Closed e1209576918842 ∧ code e1209576918842 = 5607623429946 := by decide
theorem cert_e1209576918842 : check e1209576918842 [[],[]] .sourceHead = true := by decide
def e1209577516510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1209577516510 : Closed e1209577516510 ∧ code e1209577516510 = 5607624027614 := by decide
theorem cert_e1209577516510 : check e1209577516510 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577516526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1209577516526 : Closed e1209577516526 ∧ code e1209577516526 = 5607624027630 := by decide
theorem cert_e1209577516526 : check e1209577516526 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577516894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1209577516894 : Closed e1209577516894 ∧ code e1209577516894 = 5607624027998 := by decide
theorem cert_e1209577516894 : check e1209577516894 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577516922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1209577516922 : Closed e1209577516922 ∧ code e1209577516922 = 5607624028026 := by decide
theorem cert_e1209577516922 : check e1209577516922 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577516974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1209577516974 : Closed e1209577516974 ∧ code e1209577516974 = 5607624028078 := by decide
theorem cert_e1209577516974 : check e1209577516974 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577516986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1209577516986 : Closed e1209577516986 ∧ code e1209577516986 = 5607624028090 := by decide
theorem cert_e1209577516986 : check e1209577516986 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577518046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1209577518046 : Closed e1209577518046 ∧ code e1209577518046 = 5607624029150 := by decide
theorem cert_e1209577518046 : check e1209577518046 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577518062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1209577518062 : Closed e1209577518062 ∧ code e1209577518062 = 5607624029166 := by decide
theorem cert_e1209577518062 : check e1209577518062 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577520350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209577520350 : Closed e1209577520350 ∧ code e1209577520350 = 5607624031454 := by decide
theorem cert_e1209577520350 : check e1209577520350 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577520378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209577520378 : Closed e1209577520378 ∧ code e1209577520378 = 5607624031482 := by decide
theorem cert_e1209577520378 : check e1209577520378 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577520750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209577520750 : Closed e1209577520750 ∧ code e1209577520750 = 5607624031854 := by decide
theorem cert_e1209577520750 : check e1209577520750 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577520762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209577520762 : Closed e1209577520762 ∧ code e1209577520762 = 5607624031866 := by decide
theorem cert_e1209577520762 : check e1209577520762 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e1209577549166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209577549166 : Closed e1209577549166 ∧ code e1209577549166 = 5607624060270 := by decide
private def t_e1209577549166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e1209577549166 : ¬ IsSelfInterpreter e1209577549166 :=
  wSource (t := t_e1209577549166) (replay_sound (ps := []) (t := e1209577549166) (by decide)) (by decide)
def e1209577549174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209577549174 : Closed e1209577549174 ∧ code e1209577549174 = 5607624060278 := by decide
private def t_e1209577549174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e1209577549174 : ¬ IsSelfInterpreter e1209577549174 :=
  wSource (t := t_e1209577549174) (replay_sound (ps := []) (t := e1209577549174) (by decide)) (by decide)
def e1209577549230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209577549230 : Closed e1209577549230 ∧ code e1209577549230 = 5607624060334 := by decide
theorem cert_e1209577549230 : check e1209577549230 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1209577549242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209577549242 : Closed e1209577549242 ∧ code e1209577549242 = 5607624060346 := by decide
theorem cert_e1209577549242 : check e1209577549242 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1209577549270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209577549270 : Closed e1209577549270 ∧ code e1209577549270 = 5607624060374 := by decide
private def t_e1209577549270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1209577549270 : ¬ IsSelfInterpreter e1209577549270 :=
  wSource (t := t_e1209577549270) (replay_sound (ps := []) (t := e1209577549270) (by decide)) (by decide)
def e1209577549274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209577549274 : Closed e1209577549274 ∧ code e1209577549274 = 5607624060378 := by decide
private def t_e1209577549274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1209577549274 : ¬ IsSelfInterpreter e1209577549274 :=
  wSource (t := t_e1209577549274) (replay_sound (ps := []) (t := e1209577549274) (by decide)) (by decide)
def e1209577549486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1209577549486 : Closed e1209577549486 ∧ code e1209577549486 = 5607624060590 := by decide
theorem cert_e1209577549486 : check e1209577549486 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1209577549498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1209577549498 : Closed e1209577549498 ∧ code e1209577549498 = 5607624060602 := by decide
theorem cert_e1209577549498 : check e1209577549498 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1209577549546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1209577549546 : Closed e1209577549546 ∧ code e1209577549546 = 5607624060650 := by decide
theorem cert_e1209577549546 : check e1209577549546 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1209577549654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1209577549654 : Closed e1209577549654 ∧ code e1209577549654 = 5607624060758 := by decide
private def t_e1209577549654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1209577549654 : ¬ IsSelfInterpreter e1209577549654 :=
  wSource (t := t_e1209577549654) (replay_sound (ps := []) (t := e1209577549654) (by decide)) (by decide)
def e1209577549658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1209577549658 : Closed e1209577549658 ∧ code e1209577549658 = 5607624060762 := by decide
private def t_e1209577549658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1209577549658 : ¬ IsSelfInterpreter e1209577549658 :=
  wSource (t := t_e1209577549658) (replay_sound (ps := []) (t := e1209577549658) (by decide)) (by decide)
def e1209577549674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1209577549674 : Closed e1209577549674 ∧ code e1209577549674 = 5607624060778 := by decide
def e1209577550702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209577550702 : Closed e1209577550702 ∧ code e1209577550702 = 5607624061806 := by decide
def e1209577550710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209577550710 : Closed e1209577550710 ∧ code e1209577550710 = 5607624061814 := by decide
private def t_e1209577550710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e1209577550710 : ¬ IsSelfInterpreter e1209577550710 :=
  wSource (t := t_e1209577550710) (replay_sound (ps := []) (t := e1209577550710) (by decide)) (by decide)
def e1209577550766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209577550766 : Closed e1209577550766 ∧ code e1209577550766 = 5607624061870 := by decide
def e1209577550778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209577550778 : Closed e1209577550778 ∧ code e1209577550778 = 5607624061882 := by decide
theorem cert_e1209577550778 : check e1209577550778 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1209577550806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209577550806 : Closed e1209577550806 ∧ code e1209577550806 = 5607624061910 := by decide
private def t_e1209577550806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e1209577550806 : ¬ IsSelfInterpreter e1209577550806 :=
  wSource (t := t_e1209577550806) (replay_sound (ps := []) (t := e1209577550806) (by decide)) (by decide)
def e1209577550810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209577550810 : Closed e1209577550810 ∧ code e1209577550810 = 5607624061914 := by decide
def e1209577551086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209577551086 : Closed e1209577551086 ∧ code e1209577551086 = 5607624062190 := by decide
private def t_e1209577551086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e1209577551086 : ¬ IsSelfInterpreter e1209577551086 :=
  wSource (t := t_e1209577551086) (replay_sound (ps := []) (t := e1209577551086) (by decide)) (by decide)
def e1209577551094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209577551094 : Closed e1209577551094 ∧ code e1209577551094 = 5607624062198 := by decide
private def t_e1209577551094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e1209577551094 : ¬ IsSelfInterpreter e1209577551094 :=
  wSource (t := t_e1209577551094) (replay_sound (ps := []) (t := e1209577551094) (by decide)) (by decide)
def e1209577551470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209577551470 : Closed e1209577551470 ∧ code e1209577551470 = 5607624062574 := by decide
theorem cert_e1209577551470 : check e1209577551470 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209577551482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209577551482 : Closed e1209577551482 ∧ code e1209577551482 = 5607624062586 := by decide
theorem cert_e1209577551482 : check e1209577551482 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209577551670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209577551670 : Closed e1209577551670 ∧ code e1209577551670 = 5607624062774 := by decide
private def t_e1209577551670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1209577551670 : ¬ IsSelfInterpreter e1209577551670 :=
  wSource (t := t_e1209577551670) (replay_sound (ps := []) (t := e1209577551670) (by decide)) (by decide)
def e1209577551674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209577551674 : Closed e1209577551674 ∧ code e1209577551674 = 5607624062778 := by decide
private def t_e1209577551674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1209577551674 : ¬ IsSelfInterpreter e1209577551674 :=
  wSource (t := t_e1209577551674) (replay_sound (ps := []) (t := e1209577551674) (by decide)) (by decide)
def e1209577552302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1209577552302 : Closed e1209577552302 ∧ code e1209577552302 = 5607624063406 := by decide
theorem cert_e1209577552302 : check e1209577552302 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577552314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1209577552314 : Closed e1209577552314 ∧ code e1209577552314 = 5607624063418 := by decide
theorem cert_e1209577552314 : check e1209577552314 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577552362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1209577552362 : Closed e1209577552362 ∧ code e1209577552362 = 5607624063466 := by decide
theorem cert_e1209577552362 : check e1209577552362 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577552494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209577552494 : Closed e1209577552494 ∧ code e1209577552494 = 5607624063598 := by decide
theorem cert_e1209577552494 : check e1209577552494 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577552506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209577552506 : Closed e1209577552506 ∧ code e1209577552506 = 5607624063610 := by decide
theorem cert_e1209577552506 : check e1209577552506 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577552794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209577552794 : Closed e1209577552794 ∧ code e1209577552794 = 5607624063898 := by decide
theorem cert_e1209577552794 : check e1209577552794 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577553110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1209577553110 : Closed e1209577553110 ∧ code e1209577553110 = 5607624064214 := by decide
private def t_e1209577553110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1209577553110 : ¬ IsSelfInterpreter e1209577553110 :=
  wSource (t := t_e1209577553110) (replay_sound (ps := []) (t := e1209577553110) (by decide)) (by decide)
def e1209577553114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1209577553114 : Closed e1209577553114 ∧ code e1209577553114 = 5607624064218 := by decide
def e1209577553130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1209577553130 : Closed e1209577553130 ∧ code e1209577553130 = 5607624064234 := by decide
def e1209577553206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209577553206 : Closed e1209577553206 ∧ code e1209577553206 = 5607624064310 := by decide
private def t_e1209577553206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1209577553206 : ¬ IsSelfInterpreter e1209577553206 :=
  wSource (t := t_e1209577553206) (replay_sound (ps := []) (t := e1209577553206) (by decide)) (by decide)
def e1209577553210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209577553210 : Closed e1209577553210 ∧ code e1209577553210 = 5607624064314 := by decide
private def t_e1209577553210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1209577553210 : ¬ IsSelfInterpreter e1209577553210 :=
  wSource (t := t_e1209577553210) (replay_sound (ps := []) (t := e1209577553210) (by decide)) (by decide)
def e1209577553306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209577553306 : Closed e1209577553306 ∧ code e1209577553306 = 5607624064410 := by decide
def e1209577554910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1209577554910 : Closed e1209577554910 ∧ code e1209577554910 = 5607624066014 := by decide
theorem cert_e1209577554910 : check e1209577554910 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577554926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1209577554926 : Closed e1209577554926 ∧ code e1209577554926 = 5607624066030 := by decide
theorem cert_e1209577554926 : check e1209577554926 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577556846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209577556846 : Closed e1209577556846 ∧ code e1209577556846 = 5607624067950 := by decide
def e1209577556854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209577556854 : Closed e1209577556854 ∧ code e1209577556854 = 5607624067958 := by decide
private def t_e1209577556854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1209577556854 : ¬ IsSelfInterpreter e1209577556854 :=
  wSource (t := t_e1209577556854) (replay_sound (ps := []) (t := e1209577556854) (by decide)) (by decide)
def e1209577556910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209577556910 : Closed e1209577556910 ∧ code e1209577556910 = 5607624068014 := by decide
def e1209577556922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209577556922 : Closed e1209577556922 ∧ code e1209577556922 = 5607624068026 := by decide
theorem cert_e1209577556922 : check e1209577556922 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209577556950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209577556950 : Closed e1209577556950 ∧ code e1209577556950 = 5607624068054 := by decide
private def t_e1209577556950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1209577556950 : ¬ IsSelfInterpreter e1209577556950 :=
  wSource (t := t_e1209577556950) (replay_sound (ps := []) (t := e1209577556950) (by decide)) (by decide)
def e1209577556954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209577556954 : Closed e1209577556954 ∧ code e1209577556954 = 5607624068058 := by decide
def e1209577557230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209577557230 : Closed e1209577557230 ∧ code e1209577557230 = 5607624068334 := by decide
def e1209577557238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209577557238 : Closed e1209577557238 ∧ code e1209577557238 = 5607624068342 := by decide
def e1209577557614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209577557614 : Closed e1209577557614 ∧ code e1209577557614 = 5607624068718 := by decide
def e1209577557626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209577557626 : Closed e1209577557626 ∧ code e1209577557626 = 5607624068730 := by decide
def e1209577557814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209577557814 : Closed e1209577557814 ∧ code e1209577557814 = 5607624068918 := by decide
def e1209577557818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209577557818 : Closed e1209577557818 ∧ code e1209577557818 = 5607624068922 := by decide
def e1209577562590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1209577562590 : Closed e1209577562590 ∧ code e1209577562590 = 5607624073694 := by decide
theorem cert_e1209577562590 : check e1209577562590 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577562614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1209577562614 : Closed e1209577562614 ∧ code e1209577562614 = 5607624073718 := by decide
theorem cert_e1209577562614 : check e1209577562614 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577563566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1209577563566 : Closed e1209577563566 ∧ code e1209577563566 = 5607624074670 := by decide
theorem cert_e1209577563566 : check e1209577563566 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577563578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1209577563578 : Closed e1209577563578 ∧ code e1209577563578 = 5607624074682 := by decide
theorem cert_e1209577563578 : check e1209577563578 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577563626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1209577563626 : Closed e1209577563626 ∧ code e1209577563626 = 5607624074730 := by decide
theorem cert_e1209577563626 : check e1209577563626 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577563758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209577563758 : Closed e1209577563758 ∧ code e1209577563758 = 5607624074862 := by decide
theorem cert_e1209577563758 : check e1209577563758 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577563770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209577563770 : Closed e1209577563770 ∧ code e1209577563770 = 5607624074874 := by decide
theorem cert_e1209577563770 : check e1209577563770 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577564058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209577564058 : Closed e1209577564058 ∧ code e1209577564058 = 5607624075162 := by decide
theorem cert_e1209577564058 : check e1209577564058 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209577566446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1209577566446 : Closed e1209577566446 ∧ code e1209577566446 = 5607624077550 := by decide
theorem cert_e1209577566446 : check e1209577566446 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577566454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1209577566454 : Closed e1209577566454 ∧ code e1209577566454 = 5607624077558 := by decide
theorem cert_e1209577566454 : check e1209577566454 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577566934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1209577566934 : Closed e1209577566934 ∧ code e1209577566934 = 5607624078038 := by decide
private def t_e1209577566934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1209577566934 : ¬ IsSelfInterpreter e1209577566934 :=
  wSource (t := t_e1209577566934) (replay_sound (ps := []) (t := e1209577566934) (by decide)) (by decide)
def e1209577566938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1209577566938 : Closed e1209577566938 ∧ code e1209577566938 = 5607624078042 := by decide
theorem cert_e1209577566938 : check e1209577566938 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577566954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1209577566954 : Closed e1209577566954 ∧ code e1209577566954 = 5607624078058 := by decide
theorem cert_e1209577566954 : check e1209577566954 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577567030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209577567030 : Closed e1209577567030 ∧ code e1209577567030 = 5607624078134 := by decide
theorem cert_e1209577567030 : check e1209577567030 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577567034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209577567034 : Closed e1209577567034 ∧ code e1209577567034 = 5607624078138 := by decide
theorem cert_e1209577567034 : check e1209577567034 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209577567130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209577567130 : Closed e1209577567130 ∧ code e1209577567130 = 5607624078234 := by decide
theorem cert_e1209577567130 : check e1209577567130 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
end Blc.Floor42
