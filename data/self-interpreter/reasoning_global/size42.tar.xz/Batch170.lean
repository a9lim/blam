import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188297398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211188297398 : Closed e1211188297398 ∧ code e1211188297398 = 5609234808502 := by decide
theorem cert_e1211188297398 : check e1211188297398 [[],[]] .three = true := by decide
def e1211188297402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211188297402 : Closed e1211188297402 ∧ code e1211188297402 = 5609234808506 := by decide
theorem cert_e1211188297402 : check e1211188297402 [[],[]] .three = true := by decide
def e1211188297430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211188297430 : Closed e1211188297430 ∧ code e1211188297430 = 5609234808534 := by decide
theorem cert_e1211188297430 : check e1211188297430 [[],[]] .three = true := by decide
def e1211188297434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211188297434 : Closed e1211188297434 ∧ code e1211188297434 = 5609234808538 := by decide
theorem cert_e1211188297434 : check e1211188297434 [[],[]] .three = true := by decide
def e1211188297450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211188297450 : Closed e1211188297450 ∧ code e1211188297450 = 5609234808554 := by decide
theorem cert_e1211188297450 : check e1211188297450 [[],[]] .three = true := by decide
def e1211188298206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211188298206 : Closed e1211188298206 ∧ code e1211188298206 = 5609234809310 := by decide
theorem cert_e1211188298206 : check e1211188298206 [[],[]] .three = true := by decide
def e1211188298222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e1211188298222 : Closed e1211188298222 ∧ code e1211188298222 = 5609234809326 := by decide
theorem cert_e1211188298222 : check e1211188298222 [[],[]] .smaller = true := by decide
def e1211188298230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e1211188298230 : Closed e1211188298230 ∧ code e1211188298230 = 5609234809334 := by decide
theorem cert_e1211188298230 : check e1211188298230 [[],[]] .smaller = true := by decide
def e1211188298234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211188298234 : Closed e1211188298234 ∧ code e1211188298234 = 5609234809338 := by decide
theorem cert_e1211188298234 : check e1211188298234 [[],[]] .three = true := by decide
def e1211188298590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e1211188298590 : Closed e1211188298590 ∧ code e1211188298590 = 5609234809694 := by decide
theorem cert_e1211188298590 : check e1211188298590 [[],[]] .three = true := by decide
def e1211188298606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211188298606 : Closed e1211188298606 ∧ code e1211188298606 = 5609234809710 := by decide
theorem cert_e1211188298606 : check e1211188298606 [[],[]] .smaller = true := by decide
def e1211188298618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211188298618 : Closed e1211188298618 ∧ code e1211188298618 = 5609234809722 := by decide
theorem cert_e1211188298618 : check e1211188298618 [[],[]] .smaller = true := by decide
def e1211188298670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211188298670 : Closed e1211188298670 ∧ code e1211188298670 = 5609234809774 := by decide
theorem cert_e1211188298670 : check e1211188298670 [[],[]] .smaller = true := by decide
def e1211188298730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211188298730 : Closed e1211188298730 ∧ code e1211188298730 = 5609234809834 := by decide
theorem cert_e1211188298730 : check e1211188298730 [[],[]] .smaller = true := by decide
def e1211188298974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188298974 : Closed e1211188298974 ∧ code e1211188298974 = 5609234810078 := by decide
theorem cert_e1211188298974 : check e1211188298974 [[],[]] .three = true := by decide
def e1211188298990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188298990 : Closed e1211188298990 ∧ code e1211188298990 = 5609234810094 := by decide
theorem cert_e1211188298990 : check e1211188298990 [[],[]] .smaller = true := by decide
def e1211188298998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188298998 : Closed e1211188298998 ∧ code e1211188298998 = 5609234810102 := by decide
theorem cert_e1211188298998 : check e1211188298998 [[],[]] .smaller = true := by decide
def e1211188299002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188299002 : Closed e1211188299002 ∧ code e1211188299002 = 5609234810106 := by decide
theorem cert_e1211188299002 : check e1211188299002 [[],[]] .three = true := by decide
def e1211188299326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211188299326 : Closed e1211188299326 ∧ code e1211188299326 = 5609234810430 := by decide
theorem cert_e1211188299326 : check e1211188299326 [[],[]] .three = true := by decide
def e1211188299374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188299374 : Closed e1211188299374 ∧ code e1211188299374 = 5609234810478 := by decide
theorem cert_e1211188299374 : check e1211188299374 [[],[]] .smaller = true := by decide
def e1211188299386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188299386 : Closed e1211188299386 ∧ code e1211188299386 = 5609234810490 := by decide
theorem cert_e1211188299386 : check e1211188299386 [[],[]] .smaller = true := by decide
def e1211188299550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e1211188299550 : Closed e1211188299550 ∧ code e1211188299550 = 5609234810654 := by decide
theorem cert_e1211188299550 : check e1211188299550 [[],[]] .smaller = true := by decide
def e1211188299662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e1211188299662 : Closed e1211188299662 ∧ code e1211188299662 = 5609234810766 := by decide
theorem cert_e1211188299662 : check e1211188299662 [[],[]] .smaller = true := by decide
def e1211188299674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188299674 : Closed e1211188299674 ∧ code e1211188299674 = 5609234810778 := by decide
theorem cert_e1211188299674 : check e1211188299674 [[],[]] .smaller = true := by decide
def e1211188299718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211188299718 : Closed e1211188299718 ∧ code e1211188299718 = 5609234810822 := by decide
theorem cert_e1211188299718 : check e1211188299718 [[],[]] .three = true := by decide
def e1211188299742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 3))))))))
theorem wire_e1211188299742 : Closed e1211188299742 ∧ code e1211188299742 = 5609234810846 := by decide
theorem cert_e1211188299742 : check e1211188299742 [[],[]] .three = true := by decide
def e1211188300894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211188300894 : Closed e1211188300894 ∧ code e1211188300894 = 5609234811998 := by decide
theorem cert_e1211188300894 : check e1211188300894 [[],[]] .three = true := by decide
def e1211188300910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211188300910 : Closed e1211188300910 ∧ code e1211188300910 = 5609234812014 := by decide
theorem cert_e1211188300910 : check e1211188300910 [[],[]] .smaller = true := by decide
def e1211188300922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211188300922 : Closed e1211188300922 ∧ code e1211188300922 = 5609234812026 := by decide
theorem cert_e1211188300922 : check e1211188300922 [[],[]] .smaller = true := by decide
def e1211188301086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211188301086 : Closed e1211188301086 ∧ code e1211188301086 = 5609234812190 := by decide
theorem cert_e1211188301086 : check e1211188301086 [[],[]] .smaller = true := by decide
def e1211188301254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211188301254 : Closed e1211188301254 ∧ code e1211188301254 = 5609234812358 := by decide
theorem cert_e1211188301254 : check e1211188301254 [[],[]] .smaller = true := by decide
def e1211188301278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211188301278 : Closed e1211188301278 ∧ code e1211188301278 = 5609234812382 := by decide
theorem cert_e1211188301278 : check e1211188301278 [[],[]] .three = true := by decide
def e1211188301282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211188301282 : Closed e1211188301282 ∧ code e1211188301282 = 5609234812386 := by decide
theorem cert_e1211188301282 : check e1211188301282 [[],[]] .three = true := by decide
def e1211188301294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211188301294 : Closed e1211188301294 ∧ code e1211188301294 = 5609234812398 := by decide
theorem cert_e1211188301294 : check e1211188301294 [[],[]] .three = true := by decide
def e1211188301358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211188301358 : Closed e1211188301358 ∧ code e1211188301358 = 5609234812462 := by decide
theorem cert_e1211188301358 : check e1211188301358 [[],[]] .smaller = true := by decide
def e1211188301534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e1211188301534 : Closed e1211188301534 ∧ code e1211188301534 = 5609234812638 := by decide
theorem cert_e1211188301534 : check e1211188301534 [[],[]] .three = true := by decide
def e1211188301538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211188301538 : Closed e1211188301538 ∧ code e1211188301538 = 5609234812642 := by decide
theorem cert_e1211188301538 : check e1211188301538 [[],[]] .smaller = true := by decide
def e1211188301550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1211188301550 : Closed e1211188301550 ∧ code e1211188301550 = 5609234812654 := by decide
theorem cert_e1211188301550 : check e1211188301550 [[],[]] .smaller = true := by decide
def e1211188301558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e1211188301558 : Closed e1211188301558 ∧ code e1211188301558 = 5609234812662 := by decide
theorem cert_e1211188301558 : check e1211188301558 [[],[]] .three = true := by decide
def e1211188301590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211188301590 : Closed e1211188301590 ∧ code e1211188301590 = 5609234812694 := by decide
theorem cert_e1211188301590 : check e1211188301590 [[],[]] .smaller = true := by decide
def e1211188301594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211188301594 : Closed e1211188301594 ∧ code e1211188301594 = 5609234812698 := by decide
theorem cert_e1211188301594 : check e1211188301594 [[],[]] .smaller = true := by decide
def e1211188301638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211188301638 : Closed e1211188301638 ∧ code e1211188301638 = 5609234812742 := by decide
theorem cert_e1211188301638 : check e1211188301638 [[],[]] .smaller = true := by decide
def e1211188301662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211188301662 : Closed e1211188301662 ∧ code e1211188301662 = 5609234812766 := by decide
theorem cert_e1211188301662 : check e1211188301662 [[],[]] .three = true := by decide
def e1211188301666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211188301666 : Closed e1211188301666 ∧ code e1211188301666 = 5609234812770 := by decide
theorem cert_e1211188301666 : check e1211188301666 [[],[]] .smaller = true := by decide
def e1211188301678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1211188301678 : Closed e1211188301678 ∧ code e1211188301678 = 5609234812782 := by decide
theorem cert_e1211188301678 : check e1211188301678 [[],[]] .smaller = true := by decide
def e1211188301686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1211188301686 : Closed e1211188301686 ∧ code e1211188301686 = 5609234812790 := by decide
theorem cert_e1211188301686 : check e1211188301686 [[],[]] .smaller = true := by decide
def e1211188301690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211188301690 : Closed e1211188301690 ∧ code e1211188301690 = 5609234812794 := by decide
theorem cert_e1211188301690 : check e1211188301690 [[],[]] .three = true := by decide
def e1211188301706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188301706 : Closed e1211188301706 ∧ code e1211188301706 = 5609234812810 := by decide
theorem cert_e1211188301706 : check e1211188301706 [[],[]] .three = true := by decide
def e1211188301730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188301730 : Closed e1211188301730 ∧ code e1211188301730 = 5609234812834 := by decide
theorem cert_e1211188301730 : check e1211188301730 [[],[]] .three = true := by decide
def e1211188301742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211188301742 : Closed e1211188301742 ∧ code e1211188301742 = 5609234812846 := by decide
theorem cert_e1211188301742 : check e1211188301742 [[],[]] .three = true := by decide
def e1211188301750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e1211188301750 : Closed e1211188301750 ∧ code e1211188301750 = 5609234812854 := by decide
theorem cert_e1211188301750 : check e1211188301750 [[],[]] .three = true := by decide
def e1211188301754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211188301754 : Closed e1211188301754 ∧ code e1211188301754 = 5609234812858 := by decide
theorem cert_e1211188301754 : check e1211188301754 [[],[]] .three = true := by decide
def e1211188301950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211188301950 : Closed e1211188301950 ∧ code e1211188301950 = 5609234813054 := by decide
theorem cert_e1211188301950 : check e1211188301950 [[],[]] .three = true := by decide
def e1211188302046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188302046 : Closed e1211188302046 ∧ code e1211188302046 = 5609234813150 := by decide
theorem cert_e1211188302046 : check e1211188302046 [[],[]] .smaller = true := by decide
def e1211188302074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188302074 : Closed e1211188302074 ∧ code e1211188302074 = 5609234813178 := by decide
theorem cert_e1211188302074 : check e1211188302074 [[],[]] .smaller = true := by decide
def e1211188302622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211188302622 : Closed e1211188302622 ∧ code e1211188302622 = 5609234813726 := by decide
theorem cert_e1211188302622 : check e1211188302622 [[],[]] .smaller = true := by decide
def e1211188302790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211188302790 : Closed e1211188302790 ∧ code e1211188302790 = 5609234813894 := by decide
theorem cert_e1211188302790 : check e1211188302790 [[],[]] .smaller = true := by decide
def e1211188302814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211188302814 : Closed e1211188302814 ∧ code e1211188302814 = 5609234813918 := by decide
theorem cert_e1211188302814 : check e1211188302814 [[],[]] .three = true := by decide
def e1211188302818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211188302818 : Closed e1211188302818 ∧ code e1211188302818 = 5609234813922 := by decide
theorem cert_e1211188302818 : check e1211188302818 [[],[]] .three = true := by decide
def e1211188302830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211188302830 : Closed e1211188302830 ∧ code e1211188302830 = 5609234813934 := by decide
theorem cert_e1211188302830 : check e1211188302830 [[],[]] .three = true := by decide
def e1211188303934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e1211188303934 : Closed e1211188303934 ∧ code e1211188303934 = 5609234815038 := by decide
theorem cert_e1211188303934 : check e1211188303934 [[],[]] .smaller = true := by decide
def e1211188304350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211188304350 : Closed e1211188304350 ∧ code e1211188304350 = 5609234815454 := by decide
theorem cert_e1211188304350 : check e1211188304350 [[],[]] .three = true := by decide
def e1211188304354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211188304354 : Closed e1211188304354 ∧ code e1211188304354 = 5609234815458 := by decide
theorem cert_e1211188304354 : check e1211188304354 [[],[]] .smaller = true := by decide
def e1211188304366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211188304366 : Closed e1211188304366 ∧ code e1211188304366 = 5609234815470 := by decide
theorem cert_e1211188304366 : check e1211188304366 [[],[]] .smaller = true := by decide
def e1211188304374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211188304374 : Closed e1211188304374 ∧ code e1211188304374 = 5609234815478 := by decide
theorem cert_e1211188304374 : check e1211188304374 [[],[]] .three = true := by decide
def e1211188304926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211188304926 : Closed e1211188304926 ∧ code e1211188304926 = 5609234816030 := by decide
theorem cert_e1211188304926 : check e1211188304926 [[],[]] .smaller = true := by decide
def e1211188304950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188304950 : Closed e1211188304950 ∧ code e1211188304950 = 5609234816054 := by decide
theorem cert_e1211188304950 : check e1211188304950 [[],[]] .smaller = true := by decide
def e1211188304954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188304954 : Closed e1211188304954 ∧ code e1211188304954 = 5609234816058 := by decide
theorem cert_e1211188304954 : check e1211188304954 [[],[]] .smaller = true := by decide
def e1211188305094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211188305094 : Closed e1211188305094 ∧ code e1211188305094 = 5609234816198 := by decide
theorem cert_e1211188305094 : check e1211188305094 [[],[]] .smaller = true := by decide
def e1211188305118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188305118 : Closed e1211188305118 ∧ code e1211188305118 = 5609234816222 := by decide
theorem cert_e1211188305118 : check e1211188305118 [[],[]] .three = true := by decide
def e1211188305122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211188305122 : Closed e1211188305122 ∧ code e1211188305122 = 5609234816226 := by decide
theorem cert_e1211188305122 : check e1211188305122 [[],[]] .smaller = true := by decide
def e1211188305134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188305134 : Closed e1211188305134 ∧ code e1211188305134 = 5609234816238 := by decide
theorem cert_e1211188305134 : check e1211188305134 [[],[]] .smaller = true := by decide
def e1211188305142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188305142 : Closed e1211188305142 ∧ code e1211188305142 = 5609234816246 := by decide
theorem cert_e1211188305142 : check e1211188305142 [[],[]] .smaller = true := by decide
def e1211188305146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188305146 : Closed e1211188305146 ∧ code e1211188305146 = 5609234816250 := by decide
theorem cert_e1211188305146 : check e1211188305146 [[],[]] .three = true := by decide
def e1211188305422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188305422 : Closed e1211188305422 ∧ code e1211188305422 = 5609234816526 := by decide
theorem cert_e1211188305422 : check e1211188305422 [[],[]] .three = true := by decide
def e1211188305434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188305434 : Closed e1211188305434 ∧ code e1211188305434 = 5609234816538 := by decide
theorem cert_e1211188305434 : check e1211188305434 [[],[]] .three = true := by decide
def e1211188305470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 4)))))))))
theorem wire_e1211188305470 : Closed e1211188305470 ∧ code e1211188305470 = 5609234816574 := by decide
theorem cert_e1211188305470 : check e1211188305470 [[],[]] .three = true := by decide
def e1211188305506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188305506 : Closed e1211188305506 ∧ code e1211188305506 = 5609234816610 := by decide
theorem cert_e1211188305506 : check e1211188305506 [[],[]] .three = true := by decide
def e1211188305518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188305518 : Closed e1211188305518 ∧ code e1211188305518 = 5609234816622 := by decide
theorem cert_e1211188305518 : check e1211188305518 [[],[]] .three = true := by decide
def e1211188305526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188305526 : Closed e1211188305526 ∧ code e1211188305526 = 5609234816630 := by decide
theorem cert_e1211188305526 : check e1211188305526 [[],[]] .three = true := by decide
def e1211188305530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188305530 : Closed e1211188305530 ∧ code e1211188305530 = 5609234816634 := by decide
theorem cert_e1211188305530 : check e1211188305530 [[],[]] .three = true := by decide
def e1211188306158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211188306158 : Closed e1211188306158 ∧ code e1211188306158 = 5609234817262 := by decide
theorem cert_e1211188306158 : check e1211188306158 [[],[]] .smaller = true := by decide
def e1211188306170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e1211188306170 : Closed e1211188306170 ∧ code e1211188306170 = 5609234817274 := by decide
theorem cert_e1211188306170 : check e1211188306170 [[],[]] .smaller = true := by decide
def e1211188306542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188306542 : Closed e1211188306542 ∧ code e1211188306542 = 5609234817646 := by decide
theorem cert_e1211188306542 : check e1211188306542 [[],[]] .smaller = true := by decide
def e1211188306554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188306554 : Closed e1211188306554 ∧ code e1211188306554 = 5609234817658 := by decide
theorem cert_e1211188306554 : check e1211188306554 [[],[]] .smaller = true := by decide
def e1211188306718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211188306718 : Closed e1211188306718 ∧ code e1211188306718 = 5609234817822 := by decide
theorem cert_e1211188306718 : check e1211188306718 [[],[]] .smaller = true := by decide
def e1211188306886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e1211188306886 : Closed e1211188306886 ∧ code e1211188306886 = 5609234817990 := by decide
theorem cert_e1211188306886 : check e1211188306886 [[],[]] .smaller = true := by decide
def e1211188306910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211188306910 : Closed e1211188306910 ∧ code e1211188306910 = 5609234818014 := by decide
theorem cert_e1211188306910 : check e1211188306910 [[],[]] .three = true := by decide
def e1211188306926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211188306926 : Closed e1211188306926 ∧ code e1211188306926 = 5609234818030 := by decide
theorem cert_e1211188306926 : check e1211188306926 [[],[]] .three = true := by decide
def e1211188307502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211188307502 : Closed e1211188307502 ∧ code e1211188307502 = 5609234818606 := by decide
theorem cert_e1211188307502 : check e1211188307502 [[],[]] .smaller = true := by decide
def e1211188307678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211188307678 : Closed e1211188307678 ∧ code e1211188307678 = 5609234818782 := by decide
theorem cert_e1211188307678 : check e1211188307678 [[],[]] .three = true := by decide
def e1211188307682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211188307682 : Closed e1211188307682 ∧ code e1211188307682 = 5609234818786 := by decide
theorem cert_e1211188307682 : check e1211188307682 [[],[]] .smaller = true := by decide
def e1211188307694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e1211188307694 : Closed e1211188307694 ∧ code e1211188307694 = 5609234818798 := by decide
theorem cert_e1211188307694 : check e1211188307694 [[],[]] .smaller = true := by decide
def e1211188307702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211188307702 : Closed e1211188307702 ∧ code e1211188307702 = 5609234818806 := by decide
theorem cert_e1211188307702 : check e1211188307702 [[],[]] .three = true := by decide
def e1211188307806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211188307806 : Closed e1211188307806 ∧ code e1211188307806 = 5609234818910 := by decide
theorem cert_e1211188307806 : check e1211188307806 [[],[]] .three = true := by decide
def e1211188307834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211188307834 : Closed e1211188307834 ∧ code e1211188307834 = 5609234818938 := by decide
theorem cert_e1211188307834 : check e1211188307834 [[],[]] .three = true := by decide
def e1211188307850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188307850 : Closed e1211188307850 ∧ code e1211188307850 = 5609234818954 := by decide
theorem cert_e1211188307850 : check e1211188307850 [[],[]] .smaller = true := by decide
def e1211188307874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188307874 : Closed e1211188307874 ∧ code e1211188307874 = 5609234818978 := by decide
theorem cert_e1211188307874 : check e1211188307874 [[],[]] .smaller = true := by decide
def e1211188307886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e1211188307886 : Closed e1211188307886 ∧ code e1211188307886 = 5609234818990 := by decide
theorem cert_e1211188307886 : check e1211188307886 [[],[]] .smaller = true := by decide
def e1211188307898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e1211188307898 : Closed e1211188307898 ∧ code e1211188307898 = 5609234819002 := by decide
theorem cert_e1211188307898 : check e1211188307898 [[],[]] .smaller = true := by decide
def e1211188307926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211188307926 : Closed e1211188307926 ∧ code e1211188307926 = 5609234819030 := by decide
theorem cert_e1211188307926 : check e1211188307926 [[],[]] .three = true := by decide
def e1211188307930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211188307930 : Closed e1211188307930 ∧ code e1211188307930 = 5609234819034 := by decide
theorem cert_e1211188307930 : check e1211188307930 [[],[]] .three = true := by decide
def e1211188308030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e1211188308030 : Closed e1211188308030 ∧ code e1211188308030 = 5609234819134 := by decide
theorem cert_e1211188308030 : check e1211188308030 [[],[]] .smaller = true := by decide
def e1211188308446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211188308446 : Closed e1211188308446 ∧ code e1211188308446 = 5609234819550 := by decide
theorem cert_e1211188308446 : check e1211188308446 [[],[]] .three = true := by decide
def e1211188308450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211188308450 : Closed e1211188308450 ∧ code e1211188308450 = 5609234819554 := by decide
theorem cert_e1211188308450 : check e1211188308450 [[],[]] .smaller = true := by decide
def e1211188308462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211188308462 : Closed e1211188308462 ∧ code e1211188308462 = 5609234819566 := by decide
theorem cert_e1211188308462 : check e1211188308462 [[],[]] .smaller = true := by decide
def e1211188308470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211188308470 : Closed e1211188308470 ∧ code e1211188308470 = 5609234819574 := by decide
theorem cert_e1211188308470 : check e1211188308470 [[],[]] .three = true := by decide
def e1211188309214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188309214 : Closed e1211188309214 ∧ code e1211188309214 = 5609234820318 := by decide
theorem cert_e1211188309214 : check e1211188309214 [[],[]] .three = true := by decide
def e1211188309242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188309242 : Closed e1211188309242 ∧ code e1211188309242 = 5609234820346 := by decide
theorem cert_e1211188309242 : check e1211188309242 [[],[]] .three = true := by decide
def e1211188309518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188309518 : Closed e1211188309518 ∧ code e1211188309518 = 5609234820622 := by decide
theorem cert_e1211188309518 : check e1211188309518 [[],[]] .smaller = true := by decide
def e1211188309566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211188309566 : Closed e1211188309566 ∧ code e1211188309566 = 5609234820670 := by decide
theorem cert_e1211188309566 : check e1211188309566 [[],[]] .three = true := by decide
def e1211188309602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188309602 : Closed e1211188309602 ∧ code e1211188309602 = 5609234820706 := by decide
theorem cert_e1211188309602 : check e1211188309602 [[],[]] .smaller = true := by decide
def e1211188309614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188309614 : Closed e1211188309614 ∧ code e1211188309614 = 5609234820718 := by decide
theorem cert_e1211188309614 : check e1211188309614 [[],[]] .smaller = true := by decide
def e1211188309626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188309626 : Closed e1211188309626 ∧ code e1211188309626 = 5609234820730 := by decide
theorem cert_e1211188309626 : check e1211188309626 [[],[]] .smaller = true := by decide
def e1211188309790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211188309790 : Closed e1211188309790 ∧ code e1211188309790 = 5609234820894 := by decide
theorem cert_e1211188309790 : check e1211188309790 [[],[]] .three = true := by decide
def e1211188309814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188309814 : Closed e1211188309814 ∧ code e1211188309814 = 5609234820918 := by decide
theorem cert_e1211188309814 : check e1211188309814 [[],[]] .three = true := by decide
def e1211188309818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188309818 : Closed e1211188309818 ∧ code e1211188309818 = 5609234820922 := by decide
theorem cert_e1211188309818 : check e1211188309818 [[],[]] .three = true := by decide
def e1211188310134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211188310134 : Closed e1211188310134 ∧ code e1211188310134 = 5609234821238 := by decide
theorem cert_e1211188310134 : check e1211188310134 [[],[]] .smaller = true := by decide
def e1211188310138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211188310138 : Closed e1211188310138 ∧ code e1211188310138 = 5609234821242 := by decide
theorem cert_e1211188310138 : check e1211188310138 [[],[]] .smaller = true := by decide
def e1211188310234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211188310234 : Closed e1211188310234 ∧ code e1211188310234 = 5609234821338 := by decide
theorem cert_e1211188310234 : check e1211188310234 [[],[]] .smaller = true := by decide
def e1211188310250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211188310250 : Closed e1211188310250 ∧ code e1211188310250 = 5609234821354 := by decide
theorem cert_e1211188310250 : check e1211188310250 [[],[]] .smaller = true := by decide
def e1211188310326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188310326 : Closed e1211188310326 ∧ code e1211188310326 = 5609234821430 := by decide
theorem cert_e1211188310326 : check e1211188310326 [[],[]] .smaller = true := by decide
def e1211188310330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188310330 : Closed e1211188310330 ∧ code e1211188310330 = 5609234821434 := by decide
theorem cert_e1211188310330 : check e1211188310330 [[],[]] .smaller = true := by decide
def e1211188310414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211188310414 : Closed e1211188310414 ∧ code e1211188310414 = 5609234821518 := by decide
theorem cert_e1211188310414 : check e1211188310414 [[],[]] .smaller = true := by decide
def e1211188310426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188310426 : Closed e1211188310426 ∧ code e1211188310426 = 5609234821530 := by decide
theorem cert_e1211188310426 : check e1211188310426 [[],[]] .smaller = true := by decide
def e1211188310470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211188310470 : Closed e1211188310470 ∧ code e1211188310470 = 5609234821574 := by decide
theorem cert_e1211188310470 : check e1211188310470 [[],[]] .smaller = true := by decide
def e1211188310494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211188310494 : Closed e1211188310494 ∧ code e1211188310494 = 5609234821598 := by decide
theorem cert_e1211188310494 : check e1211188310494 [[],[]] .three = true := by decide
def e1211188310518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211188310518 : Closed e1211188310518 ∧ code e1211188310518 = 5609234821622 := by decide
theorem cert_e1211188310518 : check e1211188310518 [[],[]] .three = true := by decide
def e1211188310806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211188310806 : Closed e1211188310806 ∧ code e1211188310806 = 5609234821910 := by decide
theorem cert_e1211188310806 : check e1211188310806 [[],[]] .smaller = true := by decide
def e1211188310810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211188310810 : Closed e1211188310810 ∧ code e1211188310810 = 5609234821914 := by decide
theorem cert_e1211188310810 : check e1211188310810 [[],[]] .smaller = true := by decide
def e1211188310854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211188310854 : Closed e1211188310854 ∧ code e1211188310854 = 5609234821958 := by decide
theorem cert_e1211188310854 : check e1211188310854 [[],[]] .smaller = true := by decide
def e1211188310878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211188310878 : Closed e1211188310878 ∧ code e1211188310878 = 5609234821982 := by decide
theorem cert_e1211188310878 : check e1211188310878 [[],[]] .three = true := by decide
def e1211188310882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211188310882 : Closed e1211188310882 ∧ code e1211188310882 = 5609234821986 := by decide
theorem cert_e1211188310882 : check e1211188310882 [[],[]] .smaller = true := by decide
def e1211188310894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211188310894 : Closed e1211188310894 ∧ code e1211188310894 = 5609234821998 := by decide
theorem cert_e1211188310894 : check e1211188310894 [[],[]] .smaller = true := by decide
def e1211188310902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211188310902 : Closed e1211188310902 ∧ code e1211188310902 = 5609234822006 := by decide
theorem cert_e1211188310902 : check e1211188310902 [[],[]] .smaller = true := by decide
def e1211188310906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211188310906 : Closed e1211188310906 ∧ code e1211188310906 = 5609234822010 := by decide
theorem cert_e1211188310906 : check e1211188310906 [[],[]] .three = true := by decide
def e1211188310922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188310922 : Closed e1211188310922 ∧ code e1211188310922 = 5609234822026 := by decide
theorem cert_e1211188310922 : check e1211188310922 [[],[]] .smaller = true := by decide
def e1211188310946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188310946 : Closed e1211188310946 ∧ code e1211188310946 = 5609234822050 := by decide
theorem cert_e1211188310946 : check e1211188310946 [[],[]] .smaller = true := by decide
def e1211188310958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211188310958 : Closed e1211188310958 ∧ code e1211188310958 = 5609234822062 := by decide
theorem cert_e1211188310958 : check e1211188310958 [[],[]] .smaller = true := by decide
def e1211188310970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211188310970 : Closed e1211188310970 ∧ code e1211188310970 = 5609234822074 := by decide
theorem cert_e1211188310970 : check e1211188310970 [[],[]] .smaller = true := by decide
def e1211188310998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211188310998 : Closed e1211188310998 ∧ code e1211188310998 = 5609234822102 := by decide
theorem cert_e1211188310998 : check e1211188310998 [[],[]] .smaller = true := by decide
def e1211188311002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211188311002 : Closed e1211188311002 ∧ code e1211188311002 = 5609234822106 := by decide
theorem cert_e1211188311002 : check e1211188311002 [[],[]] .smaller = true := by decide
def e1211188311018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211188311018 : Closed e1211188311018 ∧ code e1211188311018 = 5609234822122 := by decide
theorem cert_e1211188311018 : check e1211188311018 [[],[]] .three = true := by decide
def e1211188311070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211188311070 : Closed e1211188311070 ∧ code e1211188311070 = 5609234822174 := by decide
theorem cert_e1211188311070 : check e1211188311070 [[],[]] .smaller = true := by decide
def e1211188311094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188311094 : Closed e1211188311094 ∧ code e1211188311094 = 5609234822198 := by decide
theorem cert_e1211188311094 : check e1211188311094 [[],[]] .smaller = true := by decide
def e1211188311098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188311098 : Closed e1211188311098 ∧ code e1211188311098 = 5609234822202 := by decide
theorem cert_e1211188311098 : check e1211188311098 [[],[]] .smaller = true := by decide
def e1211188311238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211188311238 : Closed e1211188311238 ∧ code e1211188311238 = 5609234822342 := by decide
theorem cert_e1211188311238 : check e1211188311238 [[],[]] .smaller = true := by decide
def e1211188311262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188311262 : Closed e1211188311262 ∧ code e1211188311262 = 5609234822366 := by decide
theorem cert_e1211188311262 : check e1211188311262 [[],[]] .three = true := by decide
def e1211188311266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211188311266 : Closed e1211188311266 ∧ code e1211188311266 = 5609234822370 := by decide
theorem cert_e1211188311266 : check e1211188311266 [[],[]] .smaller = true := by decide
def e1211188311278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188311278 : Closed e1211188311278 ∧ code e1211188311278 = 5609234822382 := by decide
theorem cert_e1211188311278 : check e1211188311278 [[],[]] .smaller = true := by decide
def e1211188311286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188311286 : Closed e1211188311286 ∧ code e1211188311286 = 5609234822390 := by decide
theorem cert_e1211188311286 : check e1211188311286 [[],[]] .smaller = true := by decide
def e1211188311290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188311290 : Closed e1211188311290 ∧ code e1211188311290 = 5609234822394 := by decide
theorem cert_e1211188311290 : check e1211188311290 [[],[]] .three = true := by decide
def e1211188311566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188311566 : Closed e1211188311566 ∧ code e1211188311566 = 5609234822670 := by decide
theorem cert_e1211188311566 : check e1211188311566 [[],[]] .smaller = true := by decide
def e1211188311614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211188311614 : Closed e1211188311614 ∧ code e1211188311614 = 5609234822718 := by decide
theorem cert_e1211188311614 : check e1211188311614 [[],[]] .three = true := by decide
def e1211188311650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188311650 : Closed e1211188311650 ∧ code e1211188311650 = 5609234822754 := by decide
theorem cert_e1211188311650 : check e1211188311650 [[],[]] .smaller = true := by decide
def e1211188311662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188311662 : Closed e1211188311662 ∧ code e1211188311662 = 5609234822766 := by decide
theorem cert_e1211188311662 : check e1211188311662 [[],[]] .smaller = true := by decide
def e1211188311674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188311674 : Closed e1211188311674 ∧ code e1211188311674 = 5609234822778 := by decide
theorem cert_e1211188311674 : check e1211188311674 [[],[]] .smaller = true := by decide
def e1211188311862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188311862 : Closed e1211188311862 ∧ code e1211188311862 = 5609234822966 := by decide
theorem cert_e1211188311862 : check e1211188311862 [[],[]] .smaller = true := by decide
def e1211188311866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188311866 : Closed e1211188311866 ∧ code e1211188311866 = 5609234822970 := by decide
theorem cert_e1211188311866 : check e1211188311866 [[],[]] .smaller = true := by decide
def e1211188311950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211188311950 : Closed e1211188311950 ∧ code e1211188311950 = 5609234823054 := by decide
theorem cert_e1211188311950 : check e1211188311950 [[],[]] .three = true := by decide
end Blc.Floor42
