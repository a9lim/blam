import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e379702319342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e379702319342 : Closed e379702319342 ∧ code e379702319342 = 4777748830446 := by decide
theorem cert_e379702319342 : check e379702319342 [] .sourceHead = true := by decide
def e379702319350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e379702319350 : Closed e379702319350 ∧ code e379702319350 = 4777748830454 := by decide
theorem cert_e379702319350 : check e379702319350 [] .sourceHead = true := by decide
def e379702319902 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e379702319902 : Closed e379702319902 ∧ code e379702319902 = 4777748831006 := by decide
theorem cert_e379702319902 : check e379702319902 [] .sourceHead = true := by decide
def e379702320014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e379702320014 : Closed e379702320014 ∧ code e379702320014 = 4777748831118 := by decide
theorem cert_e379702320014 : check e379702320014 [] .sourceHead = true := by decide
def e379702320238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e379702320238 : Closed e379702320238 ∧ code e379702320238 = 4777748831342 := by decide
theorem cert_e379702320238 : check e379702320238 [] .sourceHead = true := by decide
def e379702320250 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e379702320250 : Closed e379702320250 ∧ code e379702320250 = 4777748831354 := by decide
theorem cert_e379702320250 : check e379702320250 [] .sourceHead = true := by decide
def e379702320414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e379702320414 : Closed e379702320414 ∧ code e379702320414 = 4777748831518 := by decide
theorem cert_e379702320414 : check e379702320414 [] .sourceHead = true := by decide
def e379702320582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e379702320582 : Closed e379702320582 ∧ code e379702320582 = 4777748831686 := by decide
theorem cert_e379702320582 : check e379702320582 [] .sourceHead = true := by decide
def e379702320694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e379702320694 : Closed e379702320694 ∧ code e379702320694 = 4777748831798 := by decide
theorem cert_e379702320694 : check e379702320694 [] .sourceHead = true := by decide
def e379702320698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e379702320698 : Closed e379702320698 ∧ code e379702320698 = 4777748831802 := by decide
theorem cert_e379702320698 : check e379702320698 [] .sourceHead = true := by decide
def e379702320782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e379702320782 : Closed e379702320782 ∧ code e379702320782 = 4777748831886 := by decide
theorem cert_e379702320782 : check e379702320782 [] .sourceHead = true := by decide
def e379702320838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e379702320838 : Closed e379702320838 ∧ code e379702320838 = 4777748831942 := by decide
theorem cert_e379702320838 : check e379702320838 [] .sourceHead = true := by decide
def e379702322974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e379702322974 : Closed e379702322974 ∧ code e379702322974 = 4777748834078 := by decide
theorem cert_e379702322974 : check e379702322974 [] .sourceHead = true := by decide
def e379702323086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e379702323086 : Closed e379702323086 ∧ code e379702323086 = 4777748834190 := by decide
theorem cert_e379702323086 : check e379702323086 [] .sourceHead = true := by decide
def e379702326046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e379702326046 : Closed e379702326046 ∧ code e379702326046 = 4777748837150 := by decide
theorem cert_e379702326046 : check e379702326046 [] .sourceHead = true := by decide
def e379702326214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e379702326214 : Closed e379702326214 ∧ code e379702326214 = 4777748837318 := by decide
theorem cert_e379702326214 : check e379702326214 [] .sourceHead = true := by decide
def e379702327694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e379702327694 : Closed e379702327694 ∧ code e379702327694 = 4777748838798 := by decide
theorem cert_e379702327694 : check e379702327694 [] .sourceHead = true := by decide
def e379702327750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e379702327750 : Closed e379702327750 ∧ code e379702327750 = 4777748838854 := by decide
theorem cert_e379702327750 : check e379702327750 [] .sourceHead = true := by decide
def e379702330990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e379702330990 : Closed e379702330990 ∧ code e379702330990 = 4777748842094 := by decide
theorem cert_e379702330990 : check e379702330990 [] .sourceHead = true := by decide
def e379702331002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e379702331002 : Closed e379702331002 ∧ code e379702331002 = 4777748842106 := by decide
theorem cert_e379702331002 : check e379702331002 [] .sourceHead = true := by decide
def e379702331290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e379702331290 : Closed e379702331290 ∧ code e379702331290 = 4777748842394 := by decide
theorem cert_e379702331290 : check e379702331290 [] .sourceHead = true := by decide
def e379702332526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e379702332526 : Closed e379702332526 ∧ code e379702332526 = 4777748843630 := by decide
theorem cert_e379702332526 : check e379702332526 [] .sourceHead = true := by decide
def e379702332538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e379702332538 : Closed e379702332538 ∧ code e379702332538 = 4777748843642 := by decide
theorem cert_e379702332538 : check e379702332538 [] .sourceHead = true := by decide
def e379702332702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e379702332702 : Closed e379702332702 ∧ code e379702332702 = 4777748843806 := by decide
theorem cert_e379702332702 : check e379702332702 [] .sourceHead = true := by decide
def e379702332870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e379702332870 : Closed e379702332870 ∧ code e379702332870 = 4777748843974 := by decide
theorem cert_e379702332870 : check e379702332870 [] .sourceHead = true := by decide
def e379702333210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e379702333210 : Closed e379702333210 ∧ code e379702333210 = 4777748844314 := by decide
theorem cert_e379702333210 : check e379702333210 [] .sourceHead = true := by decide
def e379702333254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e379702333254 : Closed e379702333254 ∧ code e379702333254 = 4777748844358 := by decide
theorem cert_e379702333254 : check e379702333254 [] .sourceHead = true := by decide
def e379702334238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e379702334238 : Closed e379702334238 ∧ code e379702334238 = 4777748845342 := by decide
theorem cert_e379702334238 : check e379702334238 [] .sourceHead = true := by decide
def e379702334406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e379702334406 : Closed e379702334406 ∧ code e379702334406 = 4777748845510 := by decide
theorem cert_e379702334406 : check e379702334406 [] .sourceHead = true := by decide
def e379702336710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e379702336710 : Closed e379702336710 ∧ code e379702336710 = 4777748847814 := by decide
theorem cert_e379702336710 : check e379702336710 [] .sourceHead = true := by decide
def e379702338358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e379702338358 : Closed e379702338358 ∧ code e379702338358 = 4777748849462 := by decide
theorem cert_e379702338358 : check e379702338358 [] .sourceHead = true := by decide
def e379702338362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e379702338362 : Closed e379702338362 ∧ code e379702338362 = 4777748849466 := by decide
theorem cert_e379702338362 : check e379702338362 [] .sourceHead = true := by decide
def e379702338458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e379702338458 : Closed e379702338458 ∧ code e379702338458 = 4777748849562 := by decide
theorem cert_e379702338458 : check e379702338458 [] .sourceHead = true := by decide
def e379702339126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e379702339126 : Closed e379702339126 ∧ code e379702339126 = 4777748850230 := by decide
theorem cert_e379702339126 : check e379702339126 [] .sourceHead = true := by decide
def e379702339130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e379702339130 : Closed e379702339130 ∧ code e379702339130 = 4777748850234 := by decide
theorem cert_e379702339130 : check e379702339130 [] .sourceHead = true := by decide
def e379702339214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e379702339214 : Closed e379702339214 ∧ code e379702339214 = 4777748850318 := by decide
theorem cert_e379702339214 : check e379702339214 [] .sourceHead = true := by decide
def e379702339270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e379702339270 : Closed e379702339270 ∧ code e379702339270 = 4777748850374 := by decide
theorem cert_e379702339270 : check e379702339270 [] .sourceHead = true := by decide
def e379702339354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e379702339354 : Closed e379702339354 ∧ code e379702339354 = 4777748850458 := by decide
theorem cert_e379702339354 : check e379702339354 [] .sourceHead = true := by decide
def e379702339398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e379702339398 : Closed e379702339398 ∧ code e379702339398 = 4777748850502 := by decide
theorem cert_e379702339398 : check e379702339398 [] .sourceHead = true := by decide
def e379702339982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e379702339982 : Closed e379702339982 ∧ code e379702339982 = 4777748851086 := by decide
theorem cert_e379702339982 : check e379702339982 [] .sourceHead = true := by decide
def e379702340038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e379702340038 : Closed e379702340038 ∧ code e379702340038 = 4777748851142 := by decide
theorem cert_e379702340038 : check e379702340038 [] .sourceHead = true := by decide
def e379702340806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e379702340806 : Closed e379702340806 ∧ code e379702340806 = 4777748851910 := by decide
theorem cert_e379702340806 : check e379702340806 [] .sourceHead = true := by decide
def e379702351582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e379702351582 : Closed e379702351582 ∧ code e379702351582 = 4777748862686 := by decide
theorem cert_e379702351582 : check e379702351582 [] .sourceHead = true := by decide
def e379702351606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e379702351606 : Closed e379702351606 ∧ code e379702351606 = 4777748862710 := by decide
theorem cert_e379702351606 : check e379702351606 [] .sourceHead = true := by decide
def e379702351710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e379702351710 : Closed e379702351710 ∧ code e379702351710 = 4777748862814 := by decide
theorem cert_e379702351710 : check e379702351710 [] .sourceHead = true := by decide
def e379702351738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e379702351738 : Closed e379702351738 ∧ code e379702351738 = 4777748862842 := by decide
theorem cert_e379702351738 : check e379702351738 [] .sourceHead = true := by decide
def e379702351830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e379702351830 : Closed e379702351830 ∧ code e379702351830 = 4777748862934 := by decide
theorem cert_e379702351830 : check e379702351830 [] .sourceHead = true := by decide
def e379702351834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e379702351834 : Closed e379702351834 ∧ code e379702351834 = 4777748862938 := by decide
theorem cert_e379702351834 : check e379702351834 [] .sourceHead = true := by decide
def e379702352350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e379702352350 : Closed e379702352350 ∧ code e379702352350 = 4777748863454 := by decide
theorem cert_e379702352350 : check e379702352350 [] .sourceHead = true := by decide
def e379702352374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e379702352374 : Closed e379702352374 ∧ code e379702352374 = 4777748863478 := by decide
theorem cert_e379702352374 : check e379702352374 [] .sourceHead = true := by decide
def e379702353118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e379702353118 : Closed e379702353118 ∧ code e379702353118 = 4777748864222 := by decide
theorem cert_e379702353118 : check e379702353118 [] .sourceHead = true := by decide
def e379702353146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e379702353146 : Closed e379702353146 ∧ code e379702353146 = 4777748864250 := by decide
theorem cert_e379702353146 : check e379702353146 [] .sourceHead = true := by decide
def e379702353718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702353718 : Closed e379702353718 ∧ code e379702353718 = 4777748864822 := by decide
theorem cert_e379702353718 : check e379702353718 [] .sourceHead = true := by decide
def e379702353722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702353722 : Closed e379702353722 ∧ code e379702353722 = 4777748864826 := by decide
theorem cert_e379702353722 : check e379702353722 [] .sourceHead = true := by decide
def e379702368494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e379702368494 : Closed e379702368494 ∧ code e379702368494 = 4777748879598 := by decide
theorem cert_e379702368494 : check e379702368494 [] .sourceHead = true := by decide
def e379702368502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e379702368502 : Closed e379702368502 ∧ code e379702368502 = 4777748879606 := by decide
theorem cert_e379702368502 : check e379702368502 [] .sourceHead = true := by decide
def e379702369054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e379702369054 : Closed e379702369054 ∧ code e379702369054 = 4777748880158 := by decide
theorem cert_e379702369054 : check e379702369054 [] .sourceHead = true := by decide
def e379702369166 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e379702369166 : Closed e379702369166 ∧ code e379702369166 = 4777748880270 := by decide
theorem cert_e379702369166 : check e379702369166 [] .sourceHead = true := by decide
def e379702369390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e379702369390 : Closed e379702369390 ∧ code e379702369390 = 4777748880494 := by decide
theorem cert_e379702369390 : check e379702369390 [] .sourceHead = true := by decide
def e379702369402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e379702369402 : Closed e379702369402 ∧ code e379702369402 = 4777748880506 := by decide
theorem cert_e379702369402 : check e379702369402 [] .sourceHead = true := by decide
def e379702369566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e379702369566 : Closed e379702369566 ∧ code e379702369566 = 4777748880670 := by decide
theorem cert_e379702369566 : check e379702369566 [] .sourceHead = true := by decide
def e379702369734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e379702369734 : Closed e379702369734 ∧ code e379702369734 = 4777748880838 := by decide
theorem cert_e379702369734 : check e379702369734 [] .sourceHead = true := by decide
def e379702369846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e379702369846 : Closed e379702369846 ∧ code e379702369846 = 4777748880950 := by decide
theorem cert_e379702369846 : check e379702369846 [] .sourceHead = true := by decide
def e379702369850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e379702369850 : Closed e379702369850 ∧ code e379702369850 = 4777748880954 := by decide
theorem cert_e379702369850 : check e379702369850 [] .sourceHead = true := by decide
def e379702369934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e379702369934 : Closed e379702369934 ∧ code e379702369934 = 4777748881038 := by decide
theorem cert_e379702369934 : check e379702369934 [] .sourceHead = true := by decide
def e379702369990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e379702369990 : Closed e379702369990 ∧ code e379702369990 = 4777748881094 := by decide
theorem cert_e379702369990 : check e379702369990 [] .sourceHead = true := by decide
def e379702372126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e379702372126 : Closed e379702372126 ∧ code e379702372126 = 4777748883230 := by decide
theorem cert_e379702372126 : check e379702372126 [] .sourceHead = true := by decide
def e379702372238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e379702372238 : Closed e379702372238 ∧ code e379702372238 = 4777748883342 := by decide
theorem cert_e379702372238 : check e379702372238 [] .sourceHead = true := by decide
def e379702375198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e379702375198 : Closed e379702375198 ∧ code e379702375198 = 4777748886302 := by decide
theorem cert_e379702375198 : check e379702375198 [] .sourceHead = true := by decide
def e379702375366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e379702375366 : Closed e379702375366 ∧ code e379702375366 = 4777748886470 := by decide
theorem cert_e379702375366 : check e379702375366 [] .sourceHead = true := by decide
def e379702376846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e379702376846 : Closed e379702376846 ∧ code e379702376846 = 4777748887950 := by decide
theorem cert_e379702376846 : check e379702376846 [] .sourceHead = true := by decide
def e379702376902 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e379702376902 : Closed e379702376902 ∧ code e379702376902 = 4777748888006 := by decide
theorem cert_e379702376902 : check e379702376902 [] .sourceHead = true := by decide
def e379702414190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e379702414190 : Closed e379702414190 ∧ code e379702414190 = 4777748925294 := by decide
theorem cert_e379702414190 : check e379702414190 [] .sourceHead = true := by decide
def e379702414198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e379702414198 : Closed e379702414198 ∧ code e379702414198 = 4777748925302 := by decide
theorem cert_e379702414198 : check e379702414198 [] .sourceHead = true := by decide
def e379702414254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e379702414254 : Closed e379702414254 ∧ code e379702414254 = 4777748925358 := by decide
theorem cert_e379702414254 : check e379702414254 [] .sourceHead = true := by decide
def e379702414266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e379702414266 : Closed e379702414266 ∧ code e379702414266 = 4777748925370 := by decide
theorem cert_e379702414266 : check e379702414266 [] .sourceHead = true := by decide
def e379702414294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e379702414294 : Closed e379702414294 ∧ code e379702414294 = 4777748925398 := by decide
theorem cert_e379702414294 : check e379702414294 [] .sourceHead = true := by decide
def e379702414298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e379702414298 : Closed e379702414298 ∧ code e379702414298 = 4777748925402 := by decide
theorem cert_e379702414298 : check e379702414298 [] .sourceHead = true := by decide
def e379702414574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e379702414574 : Closed e379702414574 ∧ code e379702414574 = 4777748925678 := by decide
theorem cert_e379702414574 : check e379702414574 [] .sourceHead = true := by decide
def e379702414582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e379702414582 : Closed e379702414582 ∧ code e379702414582 = 4777748925686 := by decide
theorem cert_e379702414582 : check e379702414582 [] .sourceHead = true := by decide
def e379702414958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e379702414958 : Closed e379702414958 ∧ code e379702414958 = 4777748926062 := by decide
theorem cert_e379702414958 : check e379702414958 [] .sourceHead = true := by decide
def e379702414970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e379702414970 : Closed e379702414970 ∧ code e379702414970 = 4777748926074 := by decide
theorem cert_e379702414970 : check e379702414970 [] .sourceHead = true := by decide
def e379702415158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e379702415158 : Closed e379702415158 ∧ code e379702415158 = 4777748926262 := by decide
theorem cert_e379702415158 : check e379702415158 [] .sourceHead = true := by decide
def e379702415162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e379702415162 : Closed e379702415162 ∧ code e379702415162 = 4777748926266 := by decide
theorem cert_e379702415162 : check e379702415162 [] .sourceHead = true := by decide
def e379702422638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e379702422638 : Closed e379702422638 ∧ code e379702422638 = 4777748933742 := by decide
theorem cert_e379702422638 : check e379702422638 [] .sourceHead = true := by decide
def e379702422650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e379702422650 : Closed e379702422650 ∧ code e379702422650 = 4777748933754 := by decide
theorem cert_e379702422650 : check e379702422650 [] .sourceHead = true := by decide
def e379702422814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e379702422814 : Closed e379702422814 ∧ code e379702422814 = 4777748933918 := by decide
theorem cert_e379702422814 : check e379702422814 [] .sourceHead = true := by decide
def e379702422982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e379702422982 : Closed e379702422982 ∧ code e379702422982 = 4777748934086 := by decide
theorem cert_e379702422982 : check e379702422982 [] .sourceHead = true := by decide
def e379702423322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e379702423322 : Closed e379702423322 ∧ code e379702423322 = 4777748934426 := by decide
theorem cert_e379702423322 : check e379702423322 [] .sourceHead = true := by decide
def e379702423366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e379702423366 : Closed e379702423366 ∧ code e379702423366 = 4777748934470 := by decide
theorem cert_e379702423366 : check e379702423366 [] .sourceHead = true := by decide
def e379702424350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e379702424350 : Closed e379702424350 ∧ code e379702424350 = 4777748935454 := by decide
theorem cert_e379702424350 : check e379702424350 [] .sourceHead = true := by decide
def e379702424518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e379702424518 : Closed e379702424518 ∧ code e379702424518 = 4777748935622 := by decide
theorem cert_e379702424518 : check e379702424518 [] .sourceHead = true := by decide
def e379702426822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e379702426822 : Closed e379702426822 ∧ code e379702426822 = 4777748937926 := by decide
theorem cert_e379702426822 : check e379702426822 [] .sourceHead = true := by decide
def e379702449718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e379702449718 : Closed e379702449718 ∧ code e379702449718 = 4777748960822 := by decide
theorem cert_e379702449718 : check e379702449718 [] .sourceHead = true := by decide
def e379702449722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e379702449722 : Closed e379702449722 ∧ code e379702449722 = 4777748960826 := by decide
theorem cert_e379702449722 : check e379702449722 [] .sourceHead = true := by decide
def e379702449806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e379702449806 : Closed e379702449806 ∧ code e379702449806 = 4777748960910 := by decide
theorem cert_e379702449806 : check e379702449806 [] .sourceHead = true := by decide
def e379702449862 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e379702449862 : Closed e379702449862 ∧ code e379702449862 = 4777748960966 := by decide
theorem cert_e379702449862 : check e379702449862 [] .sourceHead = true := by decide
def e379702449946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e379702449946 : Closed e379702449946 ∧ code e379702449946 = 4777748961050 := by decide
theorem cert_e379702449946 : check e379702449946 [] .sourceHead = true := by decide
def e379702449990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e379702449990 : Closed e379702449990 ∧ code e379702449990 = 4777748961094 := by decide
theorem cert_e379702449990 : check e379702449990 [] .sourceHead = true := by decide
def e379702450574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e379702450574 : Closed e379702450574 ∧ code e379702450574 = 4777748961678 := by decide
theorem cert_e379702450574 : check e379702450574 [] .sourceHead = true := by decide
def e379702450630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e379702450630 : Closed e379702450630 ∧ code e379702450630 = 4777748961734 := by decide
theorem cert_e379702450630 : check e379702450630 [] .sourceHead = true := by decide
def e379702451398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e379702451398 : Closed e379702451398 ∧ code e379702451398 = 4777748962502 := by decide
theorem cert_e379702451398 : check e379702451398 [] .sourceHead = true := by decide
def e379703548142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e379703548142 : Closed e379703548142 ∧ code e379703548142 = 4777750059246 := by decide
theorem cert_e379703548142 : check e379703548142 [] .sourceHead = true := by decide
def e379703548150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e379703548150 : Closed e379703548150 ∧ code e379703548150 = 4777750059254 := by decide
theorem cert_e379703548150 : check e379703548150 [] .sourceHead = true := by decide
def e379703548702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e379703548702 : Closed e379703548702 ∧ code e379703548702 = 4777750059806 := by decide
theorem cert_e379703548702 : check e379703548702 [] .sourceHead = true := by decide
def e379703548814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e379703548814 : Closed e379703548814 ∧ code e379703548814 = 4777750059918 := by decide
theorem cert_e379703548814 : check e379703548814 [] .sourceHead = true := by decide
def e379703549038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e379703549038 : Closed e379703549038 ∧ code e379703549038 = 4777750060142 := by decide
theorem cert_e379703549038 : check e379703549038 [] .sourceHead = true := by decide
def e379703549050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e379703549050 : Closed e379703549050 ∧ code e379703549050 = 4777750060154 := by decide
theorem cert_e379703549050 : check e379703549050 [] .sourceHead = true := by decide
def e379703549214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e379703549214 : Closed e379703549214 ∧ code e379703549214 = 4777750060318 := by decide
theorem cert_e379703549214 : check e379703549214 [] .sourceHead = true := by decide
def e379703549382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e379703549382 : Closed e379703549382 ∧ code e379703549382 = 4777750060486 := by decide
theorem cert_e379703549382 : check e379703549382 [] .sourceHead = true := by decide
def e379703549494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e379703549494 : Closed e379703549494 ∧ code e379703549494 = 4777750060598 := by decide
theorem cert_e379703549494 : check e379703549494 [] .sourceHead = true := by decide
def e379703549498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e379703549498 : Closed e379703549498 ∧ code e379703549498 = 4777750060602 := by decide
theorem cert_e379703549498 : check e379703549498 [] .sourceHead = true := by decide
def e379703549582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e379703549582 : Closed e379703549582 ∧ code e379703549582 = 4777750060686 := by decide
theorem cert_e379703549582 : check e379703549582 [] .sourceHead = true := by decide
def e379703549638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e379703549638 : Closed e379703549638 ∧ code e379703549638 = 4777750060742 := by decide
theorem cert_e379703549638 : check e379703549638 [] .sourceHead = true := by decide
def e379703551774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e379703551774 : Closed e379703551774 ∧ code e379703551774 = 4777750062878 := by decide
theorem cert_e379703551774 : check e379703551774 [] .sourceHead = true := by decide
def e379703551886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e379703551886 : Closed e379703551886 ∧ code e379703551886 = 4777750062990 := by decide
theorem cert_e379703551886 : check e379703551886 [] .sourceHead = true := by decide
def e379703554846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e379703554846 : Closed e379703554846 ∧ code e379703554846 = 4777750065950 := by decide
theorem cert_e379703554846 : check e379703554846 [] .sourceHead = true := by decide
def e379703555014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e379703555014 : Closed e379703555014 ∧ code e379703555014 = 4777750066118 := by decide
theorem cert_e379703555014 : check e379703555014 [] .sourceHead = true := by decide
def e379703556494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e379703556494 : Closed e379703556494 ∧ code e379703556494 = 4777750067598 := by decide
theorem cert_e379703556494 : check e379703556494 [] .sourceHead = true := by decide
def e379703556550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e379703556550 : Closed e379703556550 ∧ code e379703556550 = 4777750067654 := by decide
theorem cert_e379703556550 : check e379703556550 [] .sourceHead = true := by decide
def e379708249822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e379708249822 : Closed e379708249822 ∧ code e379708249822 = 4777754760926 := by decide
theorem cert_e379708249822 : check e379708249822 [] .sourceHead = true := by decide
def e379708249846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e379708249846 : Closed e379708249846 ∧ code e379708249846 = 4777754760950 := by decide
theorem cert_e379708249846 : check e379708249846 [] .sourceHead = true := by decide
def e379708249950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e379708249950 : Closed e379708249950 ∧ code e379708249950 = 4777754761054 := by decide
theorem cert_e379708249950 : check e379708249950 [] .sourceHead = true := by decide
def e379708249978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e379708249978 : Closed e379708249978 ∧ code e379708249978 = 4777754761082 := by decide
theorem cert_e379708249978 : check e379708249978 [] .sourceHead = true := by decide
def e379708250070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e379708250070 : Closed e379708250070 ∧ code e379708250070 = 4777754761174 := by decide
theorem cert_e379708250070 : check e379708250070 [] .sourceHead = true := by decide
def e379708250074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e379708250074 : Closed e379708250074 ∧ code e379708250074 = 4777754761178 := by decide
theorem cert_e379708250074 : check e379708250074 [] .sourceHead = true := by decide
def e379708250590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e379708250590 : Closed e379708250590 ∧ code e379708250590 = 4777754761694 := by decide
theorem cert_e379708250590 : check e379708250590 [] .sourceHead = true := by decide
def e379708250614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e379708250614 : Closed e379708250614 ∧ code e379708250614 = 4777754761718 := by decide
theorem cert_e379708250614 : check e379708250614 [] .sourceHead = true := by decide
def e379708251358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e379708251358 : Closed e379708251358 ∧ code e379708251358 = 4777754762462 := by decide
theorem cert_e379708251358 : check e379708251358 [] .sourceHead = true := by decide
def e379708251386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e379708251386 : Closed e379708251386 ∧ code e379708251386 = 4777754762490 := by decide
theorem cert_e379708251386 : check e379708251386 [] .sourceHead = true := by decide
def e379708251958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e379708251958 : Closed e379708251958 ∧ code e379708251958 = 4777754763062 := by decide
theorem cert_e379708251958 : check e379708251958 [] .sourceHead = true := by decide
def e379708251962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e379708251962 : Closed e379708251962 ∧ code e379708251962 = 4777754763066 := by decide
theorem cert_e379708251962 : check e379708251962 [] .sourceHead = true := by decide
def e379708266734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e379708266734 : Closed e379708266734 ∧ code e379708266734 = 4777754777838 := by decide
theorem cert_e379708266734 : check e379708266734 [] .sourceHead = true := by decide
def e379708266742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e379708266742 : Closed e379708266742 ∧ code e379708266742 = 4777754777846 := by decide
theorem cert_e379708266742 : check e379708266742 [] .sourceHead = true := by decide
def e379708267294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e379708267294 : Closed e379708267294 ∧ code e379708267294 = 4777754778398 := by decide
theorem cert_e379708267294 : check e379708267294 [] .sourceHead = true := by decide
def e379708267406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e379708267406 : Closed e379708267406 ∧ code e379708267406 = 4777754778510 := by decide
theorem cert_e379708267406 : check e379708267406 [] .sourceHead = true := by decide
def e379708267630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e379708267630 : Closed e379708267630 ∧ code e379708267630 = 4777754778734 := by decide
theorem cert_e379708267630 : check e379708267630 [] .sourceHead = true := by decide
def e379708267642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e379708267642 : Closed e379708267642 ∧ code e379708267642 = 4777754778746 := by decide
theorem cert_e379708267642 : check e379708267642 [] .sourceHead = true := by decide
def e379708267806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e379708267806 : Closed e379708267806 ∧ code e379708267806 = 4777754778910 := by decide
theorem cert_e379708267806 : check e379708267806 [] .sourceHead = true := by decide
def e379708267974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e379708267974 : Closed e379708267974 ∧ code e379708267974 = 4777754779078 := by decide
theorem cert_e379708267974 : check e379708267974 [] .sourceHead = true := by decide
def e379708268086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e379708268086 : Closed e379708268086 ∧ code e379708268086 = 4777754779190 := by decide
theorem cert_e379708268086 : check e379708268086 [] .sourceHead = true := by decide
def e379708268090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e379708268090 : Closed e379708268090 ∧ code e379708268090 = 4777754779194 := by decide
theorem cert_e379708268090 : check e379708268090 [] .sourceHead = true := by decide
def e379708268174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e379708268174 : Closed e379708268174 ∧ code e379708268174 = 4777754779278 := by decide
theorem cert_e379708268174 : check e379708268174 [] .sourceHead = true := by decide
def e379708268230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e379708268230 : Closed e379708268230 ∧ code e379708268230 = 4777754779334 := by decide
theorem cert_e379708268230 : check e379708268230 [] .sourceHead = true := by decide
def e379708270366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e379708270366 : Closed e379708270366 ∧ code e379708270366 = 4777754781470 := by decide
theorem cert_e379708270366 : check e379708270366 [] .sourceHead = true := by decide
def e379708270478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e379708270478 : Closed e379708270478 ∧ code e379708270478 = 4777754781582 := by decide
theorem cert_e379708270478 : check e379708270478 [] .sourceHead = true := by decide
def e379708273438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e379708273438 : Closed e379708273438 ∧ code e379708273438 = 4777754784542 := by decide
theorem cert_e379708273438 : check e379708273438 [] .sourceHead = true := by decide
def e379708273606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e379708273606 : Closed e379708273606 ∧ code e379708273606 = 4777754784710 := by decide
theorem cert_e379708273606 : check e379708273606 [] .sourceHead = true := by decide
def e379708275086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e379708275086 : Closed e379708275086 ∧ code e379708275086 = 4777754786190 := by decide
theorem cert_e379708275086 : check e379708275086 [] .sourceHead = true := by decide
def e379708275142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e379708275142 : Closed e379708275142 ∧ code e379708275142 = 4777754786246 := by decide
theorem cert_e379708275142 : check e379708275142 [] .sourceHead = true := by decide
def e412612647646 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e412612647646 : Closed e412612647646 ∧ code e412612647646 = 4810659158750 := by decide
theorem cert_e412612647646 : check e412612647646 [] .sourceHead = true := by decide
def e412612647670 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e412612647670 : Closed e412612647670 ∧ code e412612647670 = 4810659158774 := by decide
theorem cert_e412612647670 : check e412612647670 [] .sourceHead = true := by decide
def e412612647774 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e412612647774 : Closed e412612647774 ∧ code e412612647774 = 4810659158878 := by decide
theorem cert_e412612647774 : check e412612647774 [] .sourceHead = true := by decide
def e412612647802 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e412612647802 : Closed e412612647802 ∧ code e412612647802 = 4810659158906 := by decide
theorem cert_e412612647802 : check e412612647802 [] .sourceHead = true := by decide
def e412612647894 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e412612647894 : Closed e412612647894 ∧ code e412612647894 = 4810659158998 := by decide
theorem cert_e412612647894 : check e412612647894 [] .sourceHead = true := by decide
def e412612647898 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e412612647898 : Closed e412612647898 ∧ code e412612647898 = 4810659159002 := by decide
theorem cert_e412612647898 : check e412612647898 [] .sourceHead = true := by decide
def e412612648286 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e412612648286 : Closed e412612648286 ∧ code e412612648286 = 4810659159390 := by decide
theorem cert_e412612648286 : check e412612648286 [] .sourceHead = true := by decide
def e412612648314 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e412612648314 : Closed e412612648314 ∧ code e412612648314 = 4810659159418 := by decide
theorem cert_e412612648314 : check e412612648314 [] .sourceHead = true := by decide
def e412612648426 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e412612648426 : Closed e412612648426 ∧ code e412612648426 = 4810659159530 := by decide
theorem cert_e412612648426 : check e412612648426 [] .sourceHead = true := by decide
def e412612648790 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e412612648790 : Closed e412612648790 ∧ code e412612648790 = 4810659159894 := by decide
theorem cert_e412612648790 : check e412612648790 [] .sourceHead = true := by decide
end Blc.Floor42
