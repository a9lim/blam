import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207486702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207486702 : Closed e1211207486702 ∧ code e1211207486702 = 5609253997806 := by decide
theorem cert_e1211207486702 : check e1211207486702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207486710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207486710 : Closed e1211207486710 ∧ code e1211207486710 = 5609253997814 := by decide
theorem cert_e1211207486710 : check e1211207486710 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207486990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211207486990 : Closed e1211207486990 ∧ code e1211207486990 = 5609253998094 := by decide
theorem cert_e1211207486990 : check e1211207486990 [[],[]] .chain = true := by decide
def e1211207487002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207487002 : Closed e1211207487002 ∧ code e1211207487002 = 5609253998106 := by decide
theorem cert_e1211207487002 : check e1211207487002 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211207487074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211207487074 : Closed e1211207487074 ∧ code e1211207487074 = 5609253998178 := by decide
theorem cert_e1211207487074 : check e1211207487074 [[],[]] .chain = true := by decide
def e1211207487086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207487086 : Closed e1211207487086 ∧ code e1211207487086 = 5609253998190 := by decide
theorem cert_e1211207487086 : check e1211207487086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211207487094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207487094 : Closed e1211207487094 ∧ code e1211207487094 = 5609253998198 := by decide
theorem cert_e1211207487094 : check e1211207487094 [[],[]] .chain = true := by decide
def e1211207487098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207487098 : Closed e1211207487098 ∧ code e1211207487098 = 5609253998202 := by decide
theorem cert_e1211207487098 : check e1211207487098 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211207487286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207487286 : Closed e1211207487286 ∧ code e1211207487286 = 5609253998390 := by decide
theorem cert_e1211207487286 : check e1211207487286 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207487290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207487290 : Closed e1211207487290 ∧ code e1211207487290 = 5609253998394 := by decide
theorem cert_e1211207487290 : check e1211207487290 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207489206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211207489206 : Closed e1211207489206 ∧ code e1211207489206 = 5609254000310 := by decide
theorem cert_e1211207489206 : check e1211207489206 [[],[]] .chain = true := by decide
def e1211207489238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211207489238 : Closed e1211207489238 ∧ code e1211207489238 = 5609254000342 := by decide
theorem cert_e1211207489238 : check e1211207489238 [[],[]] .chain = true := by decide
def e1211207489242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211207489242 : Closed e1211207489242 ∧ code e1211207489242 = 5609254000346 := by decide
theorem cert_e1211207489242 : check e1211207489242 [[],[]] .chain = true := by decide
def e1211207489366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211207489366 : Closed e1211207489366 ∧ code e1211207489366 = 5609254000470 := by decide
theorem cert_e1211207489366 : check e1211207489366 [[],[]] .chain = true := by decide
def e1211207489370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211207489370 : Closed e1211207489370 ∧ code e1211207489370 = 5609254000474 := by decide
theorem cert_e1211207489370 : check e1211207489370 [[],[]] .chain = true := by decide
def e1211207489386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211207489386 : Closed e1211207489386 ∧ code e1211207489386 = 5609254000490 := by decide
theorem cert_e1211207489386 : check e1211207489386 [[],[]] .chain = true := by decide
def e1211207489590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211207489590 : Closed e1211207489590 ∧ code e1211207489590 = 5609254000694 := by decide
theorem cert_e1211207489590 : check e1211207489590 [[],[]] .chain = true := by decide
def e1211207489678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211207489678 : Closed e1211207489678 ∧ code e1211207489678 = 5609254000782 := by decide
theorem cert_e1211207489678 : check e1211207489678 [[],[]] .chain = true := by decide
def e1211207489762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211207489762 : Closed e1211207489762 ∧ code e1211207489762 = 5609254000866 := by decide
theorem cert_e1211207489762 : check e1211207489762 [[],[]] .chain = true := by decide
def e1211207489774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211207489774 : Closed e1211207489774 ∧ code e1211207489774 = 5609254000878 := by decide
theorem cert_e1211207489774 : check e1211207489774 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207489782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211207489782 : Closed e1211207489782 ∧ code e1211207489782 = 5609254000886 := by decide
theorem cert_e1211207489782 : check e1211207489782 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207489974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211207489974 : Closed e1211207489974 ∧ code e1211207489974 = 5609254001078 := by decide
theorem cert_e1211207489974 : check e1211207489974 [[],[]] .chain = true := by decide
def e1211207490006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211207490006 : Closed e1211207490006 ∧ code e1211207490006 = 5609254001110 := by decide
theorem cert_e1211207490006 : check e1211207490006 [[],[]] .chain = true := by decide
def e1211207490010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211207490010 : Closed e1211207490010 ∧ code e1211207490010 = 5609254001114 := by decide
theorem cert_e1211207490010 : check e1211207490010 [[],[]] .chain = true := by decide
def e1211207490166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207490166 : Closed e1211207490166 ∧ code e1211207490166 = 5609254001270 := by decide
theorem cert_e1211207490166 : check e1211207490166 [[],[]] .chain = true := by decide
def e1211207490310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207490310 : Closed e1211207490310 ∧ code e1211207490310 = 5609254001414 := by decide
theorem cert_e1211207490310 : check e1211207490310 [[],[]] .chain = true := by decide
def e1211207490334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211207490334 : Closed e1211207490334 ∧ code e1211207490334 = 5609254001438 := by decide
theorem cert_e1211207490334 : check e1211207490334 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211207490358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207490358 : Closed e1211207490358 ∧ code e1211207490358 = 5609254001462 := by decide
theorem cert_e1211207490358 : check e1211207490358 [[],[]] .chain = true := by decide
def e1211207490362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207490362 : Closed e1211207490362 ∧ code e1211207490362 = 5609254001466 := by decide
theorem cert_e1211207490362 : check e1211207490362 [[],[]] .chain = true := by decide
def e1211207490446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211207490446 : Closed e1211207490446 ∧ code e1211207490446 = 5609254001550 := by decide
theorem cert_e1211207490446 : check e1211207490446 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207490582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211207490582 : Closed e1211207490582 ∧ code e1211207490582 = 5609254001686 := by decide
theorem cert_e1211207490582 : check e1211207490582 [[],[]] .chain = true := by decide
def e1211207490586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211207490586 : Closed e1211207490586 ∧ code e1211207490586 = 5609254001690 := by decide
theorem cert_e1211207490586 : check e1211207490586 [[],[]] .chain = true := by decide
def e1211207490630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211207490630 : Closed e1211207490630 ∧ code e1211207490630 = 5609254001734 := by decide
theorem cert_e1211207490630 : check e1211207490630 [[],[]] .chain = true := by decide
def e1211207490658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211207490658 : Closed e1211207490658 ∧ code e1211207490658 = 5609254001762 := by decide
theorem cert_e1211207490658 : check e1211207490658 [[],[]] .chain = true := by decide
def e1211207490670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211207490670 : Closed e1211207490670 ∧ code e1211207490670 = 5609254001774 := by decide
theorem cert_e1211207490670 : check e1211207490670 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207490678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211207490678 : Closed e1211207490678 ∧ code e1211207490678 = 5609254001782 := by decide
theorem cert_e1211207490678 : check e1211207490678 [[],[]] .chain = true := by decide
def e1211207490682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211207490682 : Closed e1211207490682 ∧ code e1211207490682 = 5609254001786 := by decide
theorem cert_e1211207490682 : check e1211207490682 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207490774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211207490774 : Closed e1211207490774 ∧ code e1211207490774 = 5609254001878 := by decide
theorem cert_e1211207490774 : check e1211207490774 [[],[]] .chain = true := by decide
def e1211207490778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211207490778 : Closed e1211207490778 ∧ code e1211207490778 = 5609254001882 := by decide
theorem cert_e1211207490778 : check e1211207490778 [[],[]] .chain = true := by decide
def e1211207490794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211207490794 : Closed e1211207490794 ∧ code e1211207490794 = 5609254001898 := by decide
theorem cert_e1211207490794 : check e1211207490794 [[],[]] .chain = true := by decide
def e1211207490822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207490822 : Closed e1211207490822 ∧ code e1211207490822 = 5609254001926 := by decide
theorem cert_e1211207490822 : check e1211207490822 [[],[]] .chain = true := by decide
def e1211207490846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211207490846 : Closed e1211207490846 ∧ code e1211207490846 = 5609254001950 := by decide
theorem cert_e1211207490846 : check e1211207490846 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207490870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207490870 : Closed e1211207490870 ∧ code e1211207490870 = 5609254001974 := by decide
theorem cert_e1211207490870 : check e1211207490870 [[],[]] .chain = true := by decide
def e1211207490874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207490874 : Closed e1211207490874 ∧ code e1211207490874 = 5609254001978 := by decide
theorem cert_e1211207490874 : check e1211207490874 [[],[]] .chain = true := by decide
def e1211207490946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207490946 : Closed e1211207490946 ∧ code e1211207490946 = 5609254002050 := by decide
theorem cert_e1211207490946 : check e1211207490946 [[],[]] .chain = true := by decide
def e1211207490958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211207490958 : Closed e1211207490958 ∧ code e1211207490958 = 5609254002062 := by decide
theorem cert_e1211207490958 : check e1211207490958 [[],[]] .chain = true := by decide
def e1211207490970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207490970 : Closed e1211207490970 ∧ code e1211207490970 = 5609254002074 := by decide
theorem cert_e1211207490970 : check e1211207490970 [[],[]] .chain = true := by decide
def e1211207491014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211207491014 : Closed e1211207491014 ∧ code e1211207491014 = 5609254002118 := by decide
theorem cert_e1211207491014 : check e1211207491014 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207491126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211207491126 : Closed e1211207491126 ∧ code e1211207491126 = 5609254002230 := by decide
theorem cert_e1211207491126 : check e1211207491126 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207491130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211207491130 : Closed e1211207491130 ∧ code e1211207491130 = 5609254002234 := by decide
theorem cert_e1211207491130 : check e1211207491130 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[],[.under,.left]] .identityHead = true := by decide
def e1211207491214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211207491214 : Closed e1211207491214 ∧ code e1211207491214 = 5609254002318 := by decide
theorem cert_e1211207491214 : check e1211207491214 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207491270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211207491270 : Closed e1211207491270 ∧ code e1211207491270 = 5609254002374 := by decide
theorem cert_e1211207491270 : check e1211207491270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207491646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211207491646 : Closed e1211207491646 ∧ code e1211207491646 = 5609254002750 := by decide
theorem cert_e1211207491646 : check e1211207491646 [[],[]] .chain = true := by decide
def e1211207492066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211207492066 : Closed e1211207492066 ∧ code e1211207492066 = 5609254003170 := by decide
theorem cert_e1211207492066 : check e1211207492066 [[],[]] .chain = true := by decide
def e1211207492078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211207492078 : Closed e1211207492078 ∧ code e1211207492078 = 5609254003182 := by decide
theorem cert_e1211207492078 : check e1211207492078 [[],[]] .chain = true := by decide
def e1211207493046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211207493046 : Closed e1211207493046 ∧ code e1211207493046 = 5609254004150 := by decide
theorem cert_e1211207493046 : check e1211207493046 [[],[]] .chain = true := by decide
def e1211207493078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211207493078 : Closed e1211207493078 ∧ code e1211207493078 = 5609254004182 := by decide
theorem cert_e1211207493078 : check e1211207493078 [[],[]] .chain = true := by decide
def e1211207493082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211207493082 : Closed e1211207493082 ∧ code e1211207493082 = 5609254004186 := by decide
theorem cert_e1211207493082 : check e1211207493082 [[],[]] .chain = true := by decide
def e1211207493238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207493238 : Closed e1211207493238 ∧ code e1211207493238 = 5609254004342 := by decide
theorem cert_e1211207493238 : check e1211207493238 [[],[]] .chain = true := by decide
def e1211207493382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207493382 : Closed e1211207493382 ∧ code e1211207493382 = 5609254004486 := by decide
theorem cert_e1211207493382 : check e1211207493382 [[],[]] .chain = true := by decide
def e1211207493406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211207493406 : Closed e1211207493406 ∧ code e1211207493406 = 5609254004510 := by decide
theorem cert_e1211207493406 : check e1211207493406 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207493430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207493430 : Closed e1211207493430 ∧ code e1211207493430 = 5609254004534 := by decide
theorem cert_e1211207493430 : check e1211207493430 [[],[]] .chain = true := by decide
def e1211207493434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207493434 : Closed e1211207493434 ∧ code e1211207493434 = 5609254004538 := by decide
theorem cert_e1211207493434 : check e1211207493434 [[],[]] .chain = true := by decide
def e1211207493518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211207493518 : Closed e1211207493518 ∧ code e1211207493518 = 5609254004622 := by decide
theorem cert_e1211207493518 : check e1211207493518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[.under],[.under,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1211207495710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211207495710 : Closed e1211207495710 ∧ code e1211207495710 = 5609254006814 := by decide
theorem cert_e1211207495710 : check e1211207495710 [[],[]] .chain = true := by decide
def e1211207495878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211207495878 : Closed e1211207495878 ∧ code e1211207495878 = 5609254006982 := by decide
theorem cert_e1211207495878 : checkPay e1211207495878 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211207495902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211207495902 : Closed e1211207495902 ∧ code e1211207495902 = 5609254007006 := by decide
theorem cert_e1211207495902 : checkPay e1211207495902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211207495906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211207495906 : Closed e1211207495906 ∧ code e1211207495906 = 5609254007010 := by decide
theorem cert_e1211207495906 : check e1211207495906 [[],[]] .chain = true := by decide
def e1211207495918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207495918 : Closed e1211207495918 ∧ code e1211207495918 = 5609254007022 := by decide
theorem cert_e1211207495918 : check e1211207495918 [[],[]] .chain = true := by decide
def e1211207495926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207495926 : Closed e1211207495926 ∧ code e1211207495926 = 5609254007030 := by decide
theorem cert_e1211207495926 : check e1211207495926 [[],[]] .chain = true := by decide
def e1211207495930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211207495930 : Closed e1211207495930 ∧ code e1211207495930 = 5609254007034 := by decide
theorem cert_e1211207495930 : checkPay e1211207495930 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211207496406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211207496406 : Closed e1211207496406 ∧ code e1211207496406 = 5609254007510 := by decide
theorem cert_e1211207496406 : check e1211207496406 [[],[]] .chain = true := by decide
def e1211207496410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211207496410 : Closed e1211207496410 ∧ code e1211207496410 = 5609254007514 := by decide
theorem cert_e1211207496410 : check e1211207496410 [[],[]] .chain = true := by decide
def e1211207496426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211207496426 : Closed e1211207496426 ∧ code e1211207496426 = 5609254007530 := by decide
theorem cert_e1211207496426 : check e1211207496426 [[],[]] .chain = true := by decide
def e1211207496454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207496454 : Closed e1211207496454 ∧ code e1211207496454 = 5609254007558 := by decide
theorem cert_e1211207496454 : check e1211207496454 [[],[]] .chain = true := by decide
def e1211207496478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211207496478 : Closed e1211207496478 ∧ code e1211207496478 = 5609254007582 := by decide
theorem cert_e1211207496478 : checkPay e1211207496478 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.left],[],[.under,.under,.right,.left]] = true := by decide
def e1211207496502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207496502 : Closed e1211207496502 ∧ code e1211207496502 = 5609254007606 := by decide
theorem cert_e1211207496502 : check e1211207496502 [[],[]] .chain = true := by decide
def e1211207496506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207496506 : Closed e1211207496506 ∧ code e1211207496506 = 5609254007610 := by decide
theorem cert_e1211207496506 : check e1211207496506 [[],[]] .chain = true := by decide
def e1211207496578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207496578 : Closed e1211207496578 ∧ code e1211207496578 = 5609254007682 := by decide
theorem cert_e1211207496578 : check e1211207496578 [[],[]] .chain = true := by decide
def e1211207496590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211207496590 : Closed e1211207496590 ∧ code e1211207496590 = 5609254007694 := by decide
theorem cert_e1211207496590 : check e1211207496590 [[],[]] .chain = true := by decide
def e1211207496602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207496602 : Closed e1211207496602 ∧ code e1211207496602 = 5609254007706 := by decide
theorem cert_e1211207496602 : check e1211207496602 [[],[]] .chain = true := by decide
def e1211207496646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211207496646 : Closed e1211207496646 ∧ code e1211207496646 = 5609254007750 := by decide
theorem cert_e1211207496646 : checkPay e1211207496646 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right,.left,.left],[.under,.under,.right,.left],[.under,.under,.right,.left,.left],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
def e1211207497838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207497838 : Closed e1211207497838 ∧ code e1211207497838 = 5609254008942 := by decide
theorem cert_e1211207497838 : check e1211207497838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207497850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207497850 : Closed e1211207497850 ∧ code e1211207497850 = 5609254008954 := by decide
theorem cert_e1211207497850 : check e1211207497850 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207498126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211207498126 : Closed e1211207498126 ∧ code e1211207498126 = 5609254009230 := by decide
theorem cert_e1211207498126 : check e1211207498126 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207498182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211207498182 : Closed e1211207498182 ∧ code e1211207498182 = 5609254009286 := by decide
theorem cert_e1211207498182 : check e1211207498182 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207522014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211207522014 : Closed e1211207522014 ∧ code e1211207522014 = 5609254033118 := by decide
theorem cert_e1211207522014 : check e1211207522014 [[],[]] .smaller = true := by decide
def e1211207522038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211207522038 : Closed e1211207522038 ∧ code e1211207522038 = 5609254033142 := by decide
theorem cert_e1211207522038 : check e1211207522038 [[],[]] .smaller = true := by decide
def e1211207522142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211207522142 : Closed e1211207522142 ∧ code e1211207522142 = 5609254033246 := by decide
theorem cert_e1211207522142 : check e1211207522142 [[],[]] .smaller = true := by decide
def e1211207522170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211207522170 : Closed e1211207522170 ∧ code e1211207522170 = 5609254033274 := by decide
theorem cert_e1211207522170 : check e1211207522170 [[],[]] .smaller = true := by decide
def e1211207522262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211207522262 : Closed e1211207522262 ∧ code e1211207522262 = 5609254033366 := by decide
theorem cert_e1211207522262 : check e1211207522262 [[],[]] .smaller = true := by decide
def e1211207522266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211207522266 : Closed e1211207522266 ∧ code e1211207522266 = 5609254033370 := by decide
theorem cert_e1211207522266 : check e1211207522266 [[],[]] .smaller = true := by decide
def e1211207522782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211207522782 : Closed e1211207522782 ∧ code e1211207522782 = 5609254033886 := by decide
theorem cert_e1211207522782 : check e1211207522782 [[],[]] .smaller = true := by decide
def e1211207522806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211207522806 : Closed e1211207522806 ∧ code e1211207522806 = 5609254033910 := by decide
theorem cert_e1211207522806 : check e1211207522806 [[],[]] .smaller = true := by decide
def e1211207523550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211207523550 : Closed e1211207523550 ∧ code e1211207523550 = 5609254034654 := by decide
theorem cert_e1211207523550 : check e1211207523550 [[],[]] .smaller = true := by decide
def e1211207523578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211207523578 : Closed e1211207523578 ∧ code e1211207523578 = 5609254034682 := by decide
theorem cert_e1211207523578 : check e1211207523578 [[],[]] .smaller = true := by decide
def e1211207524150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211207524150 : Closed e1211207524150 ∧ code e1211207524150 = 5609254035254 := by decide
theorem cert_e1211207524150 : check e1211207524150 [[],[]] .smaller = true := by decide
def e1211207524154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211207524154 : Closed e1211207524154 ∧ code e1211207524154 = 5609254035258 := by decide
theorem cert_e1211207524154 : check e1211207524154 [[],[]] .smaller = true := by decide
def e1211207538926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211207538926 : Closed e1211207538926 ∧ code e1211207538926 = 5609254050030 := by decide
theorem cert_e1211207538926 : check e1211207538926 [[],[]] .smaller = true := by decide
def e1211207538934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211207538934 : Closed e1211207538934 ∧ code e1211207538934 = 5609254050038 := by decide
theorem cert_e1211207538934 : check e1211207538934 [[],[]] .smaller = true := by decide
def e1211207539486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211207539486 : Closed e1211207539486 ∧ code e1211207539486 = 5609254050590 := by decide
theorem cert_e1211207539486 : check e1211207539486 [[],[]] .smaller = true := by decide
def e1211207539598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211207539598 : Closed e1211207539598 ∧ code e1211207539598 = 5609254050702 := by decide
theorem cert_e1211207539598 : check e1211207539598 [[],[]] .smaller = true := by decide
def e1211207539822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211207539822 : Closed e1211207539822 ∧ code e1211207539822 = 5609254050926 := by decide
theorem cert_e1211207539822 : check e1211207539822 [[],[]] .smaller = true := by decide
def e1211207539834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211207539834 : Closed e1211207539834 ∧ code e1211207539834 = 5609254050938 := by decide
theorem cert_e1211207539834 : check e1211207539834 [[],[]] .smaller = true := by decide
def e1211207539998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211207539998 : Closed e1211207539998 ∧ code e1211207539998 = 5609254051102 := by decide
theorem cert_e1211207539998 : check e1211207539998 [[],[]] .smaller = true := by decide
def e1211207540166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211207540166 : Closed e1211207540166 ∧ code e1211207540166 = 5609254051270 := by decide
theorem cert_e1211207540166 : check e1211207540166 [[],[]] .smaller = true := by decide
def e1211207540190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211207540190 : Closed e1211207540190 ∧ code e1211207540190 = 5609254051294 := by decide
theorem cert_e1211207540190 : check e1211207540190 [[],[]] .chain = true := by decide
def e1211207540206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211207540206 : Closed e1211207540206 ∧ code e1211207540206 = 5609254051310 := by decide
theorem cert_e1211207540206 : check e1211207540206 [[],[]] .chain = true := by decide
def e1211207540278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211207540278 : Closed e1211207540278 ∧ code e1211207540278 = 5609254051382 := by decide
theorem cert_e1211207540278 : check e1211207540278 [[],[]] .smaller = true := by decide
def e1211207540282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211207540282 : Closed e1211207540282 ∧ code e1211207540282 = 5609254051386 := by decide
theorem cert_e1211207540282 : check e1211207540282 [[],[]] .smaller = true := by decide
def e1211207540366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211207540366 : Closed e1211207540366 ∧ code e1211207540366 = 5609254051470 := by decide
theorem cert_e1211207540366 : check e1211207540366 [[],[]] .smaller = true := by decide
def e1211207540422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211207540422 : Closed e1211207540422 ∧ code e1211207540422 = 5609254051526 := by decide
theorem cert_e1211207540422 : check e1211207540422 [[],[]] .smaller = true := by decide
def e1211207540446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211207540446 : Closed e1211207540446 ∧ code e1211207540446 = 5609254051550 := by decide
theorem cert_e1211207540446 : check e1211207540446 [[],[]] .chain = true := by decide
def e1211207540470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211207540470 : Closed e1211207540470 ∧ code e1211207540470 = 5609254051574 := by decide
theorem cert_e1211207540470 : check e1211207540470 [[],[]] .chain = true := by decide
def e1211207540590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211207540590 : Closed e1211207540590 ∧ code e1211207540590 = 5609254051694 := by decide
theorem cert_e1211207540590 : check e1211207540590 [[],[]] .chain = true := by decide
def e1211207540598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211207540598 : Closed e1211207540598 ∧ code e1211207540598 = 5609254051702 := by decide
theorem cert_e1211207540598 : check e1211207540598 [[],[]] .chain = true := by decide
def e1211207542558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211207542558 : Closed e1211207542558 ∧ code e1211207542558 = 5609254053662 := by decide
theorem cert_e1211207542558 : check e1211207542558 [[],[]] .smaller = true := by decide
def e1211207542670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211207542670 : Closed e1211207542670 ∧ code e1211207542670 = 5609254053774 := by decide
theorem cert_e1211207542670 : check e1211207542670 [[],[]] .smaller = true := by decide
def e1211207545630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211207545630 : Closed e1211207545630 ∧ code e1211207545630 = 5609254056734 := by decide
theorem cert_e1211207545630 : check e1211207545630 [[],[]] .smaller = true := by decide
def e1211207545798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211207545798 : Closed e1211207545798 ∧ code e1211207545798 = 5609254056902 := by decide
theorem cert_e1211207545798 : check e1211207545798 [[],[]] .smaller = true := by decide
def e1211207545822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211207545822 : Closed e1211207545822 ∧ code e1211207545822 = 5609254056926 := by decide
theorem cert_e1211207545822 : check e1211207545822 [[],[]] .chain = true := by decide
def e1211207545838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211207545838 : Closed e1211207545838 ∧ code e1211207545838 = 5609254056942 := by decide
theorem cert_e1211207545838 : check e1211207545838 [[],[]] .chain = true := by decide
def e1211207547278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211207547278 : Closed e1211207547278 ∧ code e1211207547278 = 5609254058382 := by decide
theorem cert_e1211207547278 : check e1211207547278 [[],[]] .smaller = true := by decide
def e1211207547334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211207547334 : Closed e1211207547334 ∧ code e1211207547334 = 5609254058438 := by decide
theorem cert_e1211207547334 : check e1211207547334 [[],[]] .smaller = true := by decide
def e1211207547358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211207547358 : Closed e1211207547358 ∧ code e1211207547358 = 5609254058462 := by decide
theorem cert_e1211207547358 : check e1211207547358 [[],[]] .chain = true := by decide
def e1211207547382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211207547382 : Closed e1211207547382 ∧ code e1211207547382 = 5609254058486 := by decide
theorem cert_e1211207547382 : check e1211207547382 [[],[]] .chain = true := by decide
def e1211207548142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207548142 : Closed e1211207548142 ∧ code e1211207548142 = 5609254059246 := by decide
theorem cert_e1211207548142 : check e1211207548142 [[],[]] .chain = true := by decide
def e1211207548150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207548150 : Closed e1211207548150 ∧ code e1211207548150 = 5609254059254 := by decide
theorem cert_e1211207548150 : check e1211207548150 [[],[]] .chain = true := by decide
def e1211207605102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211207605102 : Closed e1211207605102 ∧ code e1211207605102 = 5609254116206 := by decide
theorem cert_e1211207605102 : check e1211207605102 [[],[]] .chain = true := by decide
def e1211207605110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211207605110 : Closed e1211207605110 ∧ code e1211207605110 = 5609254116214 := by decide
theorem cert_e1211207605110 : check e1211207605110 [[],[]] .chain = true := by decide
def e1211207605174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211207605174 : Closed e1211207605174 ∧ code e1211207605174 = 5609254116278 := by decide
theorem cert_e1211207605174 : check e1211207605174 [[],[]] .chain = true := by decide
def e1211207605614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211207605614 : Closed e1211207605614 ∧ code e1211207605614 = 5609254116718 := by decide
theorem cert_e1211207605614 : check e1211207605614 [[],[]] .chain = true := by decide
def e1211207605622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211207605622 : Closed e1211207605622 ∧ code e1211207605622 = 5609254116726 := by decide
theorem cert_e1211207605622 : check e1211207605622 [[],[]] .chain = true := by decide
def e1211207605678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211207605678 : Closed e1211207605678 ∧ code e1211207605678 = 5609254116782 := by decide
theorem cert_e1211207605678 : check e1211207605678 [[],[]] .chain = true := by decide
def e1211207605690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211207605690 : Closed e1211207605690 ∧ code e1211207605690 = 5609254116794 := by decide
theorem cert_e1211207605690 : check e1211207605690 [[],[]] .chain = true := by decide
def e1211207605718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211207605718 : Closed e1211207605718 ∧ code e1211207605718 = 5609254116822 := by decide
theorem cert_e1211207605718 : check e1211207605718 [[],[]] .chain = true := by decide
def e1211207605722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211207605722 : Closed e1211207605722 ∧ code e1211207605722 = 5609254116826 := by decide
theorem cert_e1211207605722 : check e1211207605722 [[],[]] .chain = true := by decide
def e1211207605942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211207605942 : Closed e1211207605942 ∧ code e1211207605942 = 5609254117046 := by decide
theorem cert_e1211207605942 : check e1211207605942 [[],[]] .chain = true := by decide
def e1211207605974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211207605974 : Closed e1211207605974 ∧ code e1211207605974 = 5609254117078 := by decide
theorem cert_e1211207605974 : check e1211207605974 [[],[]] .chain = true := by decide
def e1211207605978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211207605978 : Closed e1211207605978 ∧ code e1211207605978 = 5609254117082 := by decide
theorem cert_e1211207605978 : check e1211207605978 [[],[]] .chain = true := by decide
def e1211207608174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211207608174 : Closed e1211207608174 ∧ code e1211207608174 = 5609254119278 := by decide
theorem cert_e1211207608174 : check e1211207608174 [[],[]] .chain = true := by decide
def e1211207608182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211207608182 : Closed e1211207608182 ∧ code e1211207608182 = 5609254119286 := by decide
theorem cert_e1211207608182 : check e1211207608182 [[],[]] .chain = true := by decide
def e1211207608246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211207608246 : Closed e1211207608246 ∧ code e1211207608246 = 5609254119350 := by decide
theorem cert_e1211207608246 : check e1211207608246 [[],[]] .chain = true := by decide
def e1211207609582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207609582 : Closed e1211207609582 ∧ code e1211207609582 = 5609254120686 := by decide
theorem cert_e1211207609582 : check e1211207609582 [[],[]] .chain = true := by decide
def e1211207609590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207609590 : Closed e1211207609590 ∧ code e1211207609590 = 5609254120694 := by decide
theorem cert_e1211207609590 : check e1211207609590 [[],[]] .chain = true := by decide
def e1211207609974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207609974 : Closed e1211207609974 ∧ code e1211207609974 = 5609254121078 := by decide
theorem cert_e1211207609974 : check e1211207609974 [[],[]] .chain = true := by decide
def e1211207610478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211207610478 : Closed e1211207610478 ∧ code e1211207610478 = 5609254121582 := by decide
theorem cert_e1211207610478 : check e1211207610478 [[],[]] .chain = true := by decide
def e1211207610654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211207610654 : Closed e1211207610654 ∧ code e1211207610654 = 5609254121758 := by decide
theorem cert_e1211207610654 : check e1211207610654 [[],[]] .chain = true := by decide
def e1211207610850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211207610850 : Closed e1211207610850 ∧ code e1211207610850 = 5609254121954 := by decide
theorem cert_e1211207610850 : check e1211207610850 [[],[]] .chain = true := by decide
def e1211207610862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211207610862 : Closed e1211207610862 ∧ code e1211207610862 = 5609254121966 := by decide
theorem cert_e1211207610862 : check e1211207610862 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207611246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211207611246 : Closed e1211207611246 ∧ code e1211207611246 = 5609254122350 := by decide
theorem cert_e1211207611246 : check e1211207611246 [[],[]] .chain = true := by decide
def e1211207611254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211207611254 : Closed e1211207611254 ∧ code e1211207611254 = 5609254122358 := by decide
theorem cert_e1211207611254 : check e1211207611254 [[],[]] .chain = true := by decide
def e1211207611310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211207611310 : Closed e1211207611310 ∧ code e1211207611310 = 5609254122414 := by decide
theorem cert_e1211207611310 : check e1211207611310 [[],[]] .chain = true := by decide
def e1211207611322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211207611322 : Closed e1211207611322 ∧ code e1211207611322 = 5609254122426 := by decide
theorem cert_e1211207611322 : check e1211207611322 [[],[]] .chain = true := by decide
def e1211207611350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211207611350 : Closed e1211207611350 ∧ code e1211207611350 = 5609254122454 := by decide
theorem cert_e1211207611350 : check e1211207611350 [[],[]] .chain = true := by decide
def e1211207611354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211207611354 : Closed e1211207611354 ∧ code e1211207611354 = 5609254122458 := by decide
theorem cert_e1211207611354 : check e1211207611354 [[],[]] .chain = true := by decide
def e1211207611630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207611630 : Closed e1211207611630 ∧ code e1211207611630 = 5609254122734 := by decide
theorem cert_e1211207611630 : check e1211207611630 [[],[]] .chain = true := by decide
def e1211207611638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207611638 : Closed e1211207611638 ∧ code e1211207611638 = 5609254122742 := by decide
theorem cert_e1211207611638 : check e1211207611638 [[],[]] .chain = true := by decide
def e1211207612014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207612014 : Closed e1211207612014 ∧ code e1211207612014 = 5609254123118 := by decide
theorem cert_e1211207612014 : check e1211207612014 [[],[]] .chain = true := by decide
def e1211207612026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207612026 : Closed e1211207612026 ∧ code e1211207612026 = 5609254123130 := by decide
theorem cert_e1211207612026 : check e1211207612026 [[],[]] .chain = true := by decide
end Blc.Floor42
