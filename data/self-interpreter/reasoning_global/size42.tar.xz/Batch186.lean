import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203638510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203638510 : Closed e1211203638510 ∧ code e1211203638510 = 5609250149614 := by decide
theorem cert_e1211203638510 : check e1211203638510 [[],[]] .chain = true := by decide
def e1211203638518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203638518 : Closed e1211203638518 ∧ code e1211203638518 = 5609250149622 := by decide
theorem cert_e1211203638518 : check e1211203638518 [[],[]] .chain = true := by decide
def e1211203638894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203638894 : Closed e1211203638894 ∧ code e1211203638894 = 5609250149998 := by decide
theorem cert_e1211203638894 : check e1211203638894 [[],[]] .chain = true := by decide
def e1211203638906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203638906 : Closed e1211203638906 ∧ code e1211203638906 = 5609250150010 := by decide
theorem cert_e1211203638906 : check e1211203638906 [[],[]] .chain = true := by decide
def e1211203639046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203639046 : Closed e1211203639046 ∧ code e1211203639046 = 5609250150150 := by decide
theorem cert_e1211203639046 : check e1211203639046 [[],[]] .chain = true := by decide
def e1211203639070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203639070 : Closed e1211203639070 ∧ code e1211203639070 = 5609250150174 := by decide
theorem cert_e1211203639070 : check e1211203639070 [[],[]] .sourceHead = true := by decide
def e1211203639094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203639094 : Closed e1211203639094 ∧ code e1211203639094 = 5609250150198 := by decide
theorem cert_e1211203639094 : check e1211203639094 [[],[]] .chain = true := by decide
def e1211203639098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203639098 : Closed e1211203639098 ∧ code e1211203639098 = 5609250150202 := by decide
theorem cert_e1211203639098 : check e1211203639098 [[],[]] .chain = true := by decide
def e1211203639342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203639342 : Closed e1211203639342 ∧ code e1211203639342 = 5609250150446 := by decide
theorem cert_e1211203639342 : check e1211203639342 [[],[]] .chain = true := by decide
def e1211203639534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203639534 : Closed e1211203639534 ∧ code e1211203639534 = 5609250150638 := by decide
theorem cert_e1211203639534 : check e1211203639534 [[],[]] .chain = true := by decide
def e1211203639542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203639542 : Closed e1211203639542 ∧ code e1211203639542 = 5609250150646 := by decide
theorem cert_e1211203639542 : check e1211203639542 [[],[]] .chain = true := by decide
def e1211203639726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203639726 : Closed e1211203639726 ∧ code e1211203639726 = 5609250150830 := by decide
theorem cert_e1211203639726 : check e1211203639726 [[],[]] .chain = true := by decide
def e1211203639738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203639738 : Closed e1211203639738 ∧ code e1211203639738 = 5609250150842 := by decide
theorem cert_e1211203639738 : check e1211203639738 [[],[]] .chain = true := by decide
def e1211203639786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203639786 : Closed e1211203639786 ∧ code e1211203639786 = 5609250150890 := by decide
theorem cert_e1211203639786 : check e1211203639786 [[],[]] .chain = true := by decide
def e1211203639918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203639918 : Closed e1211203639918 ∧ code e1211203639918 = 5609250151022 := by decide
theorem cert_e1211203639918 : check e1211203639918 [[],[]] .chain = true := by decide
def e1211203639930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203639930 : Closed e1211203639930 ∧ code e1211203639930 = 5609250151034 := by decide
theorem cert_e1211203639930 : check e1211203639930 [[],[]] .chain = true := by decide
def e1211203640094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203640094 : Closed e1211203640094 ∧ code e1211203640094 = 5609250151198 := by decide
theorem cert_e1211203640094 : check e1211203640094 [[],[]] .chain = true := by decide
def e1211203640194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203640194 : Closed e1211203640194 ∧ code e1211203640194 = 5609250151298 := by decide
theorem cert_e1211203640194 : check e1211203640194 [[],[]] .chain = true := by decide
def e1211203640206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203640206 : Closed e1211203640206 ∧ code e1211203640206 = 5609250151310 := by decide
theorem cert_e1211203640206 : check e1211203640206 [[],[]] .chain = true := by decide
def e1211203640218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203640218 : Closed e1211203640218 ∧ code e1211203640218 = 5609250151322 := by decide
theorem cert_e1211203640218 : check e1211203640218 [[],[]] .chain = true := by decide
def e1211203640342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203640342 : Closed e1211203640342 ∧ code e1211203640342 = 5609250151446 := by decide
theorem cert_e1211203640342 : check e1211203640342 [[],[]] .chain = true := by decide
def e1211203640346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203640346 : Closed e1211203640346 ∧ code e1211203640346 = 5609250151450 := by decide
theorem cert_e1211203640346 : check e1211203640346 [[],[]] .chain = true := by decide
def e1211203640390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203640390 : Closed e1211203640390 ∧ code e1211203640390 = 5609250151494 := by decide
theorem cert_e1211203640390 : check e1211203640390 [[],[]] .chain = true := by decide
def e1211203640418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203640418 : Closed e1211203640418 ∧ code e1211203640418 = 5609250151522 := by decide
theorem cert_e1211203640418 : check e1211203640418 [[],[]] .chain = true := by decide
def e1211203640430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203640430 : Closed e1211203640430 ∧ code e1211203640430 = 5609250151534 := by decide
theorem cert_e1211203640430 : check e1211203640430 [[],[]] .sourceHead = true := by decide
def e1211203640438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203640438 : Closed e1211203640438 ∧ code e1211203640438 = 5609250151542 := by decide
theorem cert_e1211203640438 : check e1211203640438 [[],[]] .chain = true := by decide
def e1211203640442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203640442 : Closed e1211203640442 ∧ code e1211203640442 = 5609250151546 := by decide
theorem cert_e1211203640442 : check e1211203640442 [[],[]] .sourceHead = true := by decide
def e1211203640534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203640534 : Closed e1211203640534 ∧ code e1211203640534 = 5609250151638 := by decide
theorem cert_e1211203640534 : check e1211203640534 [[],[]] .chain = true := by decide
def e1211203640538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203640538 : Closed e1211203640538 ∧ code e1211203640538 = 5609250151642 := by decide
theorem cert_e1211203640538 : check e1211203640538 [[],[]] .chain = true := by decide
def e1211203640554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203640554 : Closed e1211203640554 ∧ code e1211203640554 = 5609250151658 := by decide
theorem cert_e1211203640554 : check e1211203640554 [[],[]] .chain = true := by decide
def e1211203640582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203640582 : Closed e1211203640582 ∧ code e1211203640582 = 5609250151686 := by decide
theorem cert_e1211203640582 : check e1211203640582 [[],[]] .chain = true := by decide
def e1211203640606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203640606 : Closed e1211203640606 ∧ code e1211203640606 = 5609250151710 := by decide
theorem cert_e1211203640606 : check e1211203640606 [[],[]] .sourceHead = true := by decide
def e1211203640630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203640630 : Closed e1211203640630 ∧ code e1211203640630 = 5609250151734 := by decide
theorem cert_e1211203640630 : check e1211203640630 [[],[]] .chain = true := by decide
def e1211203640634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203640634 : Closed e1211203640634 ∧ code e1211203640634 = 5609250151738 := by decide
theorem cert_e1211203640634 : check e1211203640634 [[],[]] .chain = true := by decide
def e1211203640706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203640706 : Closed e1211203640706 ∧ code e1211203640706 = 5609250151810 := by decide
theorem cert_e1211203640706 : check e1211203640706 [[],[]] .chain = true := by decide
def e1211203640718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203640718 : Closed e1211203640718 ∧ code e1211203640718 = 5609250151822 := by decide
theorem cert_e1211203640718 : check e1211203640718 [[],[]] .chain = true := by decide
def e1211203640730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203640730 : Closed e1211203640730 ∧ code e1211203640730 = 5609250151834 := by decide
theorem cert_e1211203640730 : check e1211203640730 [[],[]] .chain = true := by decide
def e1211203640774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203640774 : Closed e1211203640774 ∧ code e1211203640774 = 5609250151878 := by decide
theorem cert_e1211203640774 : check e1211203640774 [[],[]] .sourceHead = true := by decide
def e1211203641518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e1211203641518 : Closed e1211203641518 ∧ code e1211203641518 = 5609250152622 := by decide
theorem cert_e1211203641518 : check e1211203641518 [[],[]] .chain = true := by decide
def e1211203641530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e1211203641530 : Closed e1211203641530 ∧ code e1211203641530 = 5609250152634 := by decide
theorem cert_e1211203641530 : check e1211203641530 [[],[]] .chain = true := by decide
def e1211203642222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203642222 : Closed e1211203642222 ∧ code e1211203642222 = 5609250153326 := by decide
theorem cert_e1211203642222 : check e1211203642222 [[],[]] .chain = true := by decide
def e1211203642230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203642230 : Closed e1211203642230 ∧ code e1211203642230 = 5609250153334 := by decide
theorem cert_e1211203642230 : check e1211203642230 [[],[]] .chain = true := by decide
def e1211203642286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203642286 : Closed e1211203642286 ∧ code e1211203642286 = 5609250153390 := by decide
theorem cert_e1211203642286 : check e1211203642286 [[],[]] .chain = true := by decide
def e1211203642298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203642298 : Closed e1211203642298 ∧ code e1211203642298 = 5609250153402 := by decide
theorem cert_e1211203642298 : check e1211203642298 [[],[]] .chain = true := by decide
def e1211203642326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203642326 : Closed e1211203642326 ∧ code e1211203642326 = 5609250153430 := by decide
theorem cert_e1211203642326 : check e1211203642326 [[],[]] .chain = true := by decide
def e1211203642330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203642330 : Closed e1211203642330 ∧ code e1211203642330 = 5609250153434 := by decide
theorem cert_e1211203642330 : check e1211203642330 [[],[]] .chain = true := by decide
def e1211203643054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203643054 : Closed e1211203643054 ∧ code e1211203643054 = 5609250154158 := by decide
theorem cert_e1211203643054 : check e1211203643054 [[],[]] .chain = true := by decide
def e1211203643066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203643066 : Closed e1211203643066 ∧ code e1211203643066 = 5609250154170 := by decide
theorem cert_e1211203643066 : check e1211203643066 [[],[]] .chain = true := by decide
def e1211203643114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203643114 : Closed e1211203643114 ∧ code e1211203643114 = 5609250154218 := by decide
theorem cert_e1211203643114 : check e1211203643114 [[],[]] .chain = true := by decide
def e1211203643306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e1211203643306 : Closed e1211203643306 ∧ code e1211203643306 = 5609250154410 := by decide
theorem cert_e1211203643306 : check e1211203643306 [[],[]] .chain = true := by decide
def e1211203643438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203643438 : Closed e1211203643438 ∧ code e1211203643438 = 5609250154542 := by decide
theorem cert_e1211203643438 : check e1211203643438 [[],[]] .chain = true := by decide
def e1211203643630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203643630 : Closed e1211203643630 ∧ code e1211203643630 = 5609250154734 := by decide
theorem cert_e1211203643630 : check e1211203643630 [[],[]] .chain = true := by decide
def e1211203643638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203643638 : Closed e1211203643638 ∧ code e1211203643638 = 5609250154742 := by decide
theorem cert_e1211203643638 : check e1211203643638 [[],[]] .chain = true := by decide
def e1211203643822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203643822 : Closed e1211203643822 ∧ code e1211203643822 = 5609250154926 := by decide
theorem cert_e1211203643822 : check e1211203643822 [[],[]] .chain = true := by decide
def e1211203643834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203643834 : Closed e1211203643834 ∧ code e1211203643834 = 5609250154938 := by decide
theorem cert_e1211203643834 : check e1211203643834 [[],[]] .chain = true := by decide
def e1211203643882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203643882 : Closed e1211203643882 ∧ code e1211203643882 = 5609250154986 := by decide
theorem cert_e1211203643882 : check e1211203643882 [[],[]] .chain = true := by decide
def e1211203644014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203644014 : Closed e1211203644014 ∧ code e1211203644014 = 5609250155118 := by decide
theorem cert_e1211203644014 : check e1211203644014 [[],[]] .chain = true := by decide
def e1211203644026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203644026 : Closed e1211203644026 ∧ code e1211203644026 = 5609250155130 := by decide
theorem cert_e1211203644026 : check e1211203644026 [[],[]] .chain = true := by decide
def e1211203644190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203644190 : Closed e1211203644190 ∧ code e1211203644190 = 5609250155294 := by decide
theorem cert_e1211203644190 : check e1211203644190 [[],[]] .chain = true := by decide
def e1211203644290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203644290 : Closed e1211203644290 ∧ code e1211203644290 = 5609250155394 := by decide
theorem cert_e1211203644290 : check e1211203644290 [[],[]] .chain = true := by decide
def e1211203644302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203644302 : Closed e1211203644302 ∧ code e1211203644302 = 5609250155406 := by decide
theorem cert_e1211203644302 : check e1211203644302 [[],[]] .chain = true := by decide
def e1211203644314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203644314 : Closed e1211203644314 ∧ code e1211203644314 = 5609250155418 := by decide
theorem cert_e1211203644314 : check e1211203644314 [[],[]] .chain = true := by decide
def e1211203644526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203644526 : Closed e1211203644526 ∧ code e1211203644526 = 5609250155630 := by decide
theorem cert_e1211203644526 : check e1211203644526 [[],[]] .chain = true := by decide
def e1211203644538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203644538 : Closed e1211203644538 ∧ code e1211203644538 = 5609250155642 := by decide
theorem cert_e1211203644538 : check e1211203644538 [[],[]] .chain = true := by decide
def e1211203644702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203644702 : Closed e1211203644702 ∧ code e1211203644702 = 5609250155806 := by decide
theorem cert_e1211203644702 : check e1211203644702 [[],[]] .chain = true := by decide
def e1211203644870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203644870 : Closed e1211203644870 ∧ code e1211203644870 = 5609250155974 := by decide
theorem cert_e1211203644870 : check e1211203644870 [[],[]] .chain = true := by decide
def e1211203644938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203644938 : Closed e1211203644938 ∧ code e1211203644938 = 5609250156042 := by decide
theorem cert_e1211203644938 : check e1211203644938 [[],[]] .chain = true := by decide
def e1211203644982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203644982 : Closed e1211203644982 ∧ code e1211203644982 = 5609250156086 := by decide
theorem cert_e1211203644982 : check e1211203644982 [[],[]] .chain = true := by decide
def e1211203644986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203644986 : Closed e1211203644986 ∧ code e1211203644986 = 5609250156090 := by decide
theorem cert_e1211203644986 : check e1211203644986 [[],[]] .chain = true := by decide
def e1211203645034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203645034 : Closed e1211203645034 ∧ code e1211203645034 = 5609250156138 := by decide
theorem cert_e1211203645034 : check e1211203645034 [[],[]] .chain = true := by decide
def e1211203645058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203645058 : Closed e1211203645058 ∧ code e1211203645058 = 5609250156162 := by decide
theorem cert_e1211203645058 : check e1211203645058 [[],[]] .chain = true := by decide
def e1211203645070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203645070 : Closed e1211203645070 ∧ code e1211203645070 = 5609250156174 := by decide
theorem cert_e1211203645070 : check e1211203645070 [[],[]] .chain = true := by decide
def e1211203645082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203645082 : Closed e1211203645082 ∧ code e1211203645082 = 5609250156186 := by decide
theorem cert_e1211203645082 : check e1211203645082 [[],[]] .chain = true := by decide
def e1211203645126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203645126 : Closed e1211203645126 ∧ code e1211203645126 = 5609250156230 := by decide
theorem cert_e1211203645126 : check e1211203645126 [[],[]] .chain = true := by decide
def e1211203645526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e1211203645526 : Closed e1211203645526 ∧ code e1211203645526 = 5609250156630 := by decide
theorem cert_e1211203645526 : check e1211203645526 [[],[]] .chain = true := by decide
def e1211203645530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e1211203645530 : Closed e1211203645530 ∧ code e1211203645530 = 5609250156634 := by decide
theorem cert_e1211203645530 : check e1211203645530 [[],[]] .chain = true := by decide
def e1211203645546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e1211203645546 : Closed e1211203645546 ∧ code e1211203645546 = 5609250156650 := by decide
theorem cert_e1211203645546 : check e1211203645546 [[],[]] .chain = true := by decide
def e1211203645722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203645722 : Closed e1211203645722 ∧ code e1211203645722 = 5609250156826 := by decide
theorem cert_e1211203645722 : check e1211203645722 [[],[]] .chain = true := by decide
def e1211203645766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203645766 : Closed e1211203645766 ∧ code e1211203645766 = 5609250156870 := by decide
theorem cert_e1211203645766 : check e1211203645766 [[],[]] .chain = true := by decide
def e1211203645834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203645834 : Closed e1211203645834 ∧ code e1211203645834 = 5609250156938 := by decide
theorem cert_e1211203645834 : check e1211203645834 [[],[]] .chain = true := by decide
def e1211203645858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203645858 : Closed e1211203645858 ∧ code e1211203645858 = 5609250156962 := by decide
theorem cert_e1211203645858 : check e1211203645858 [[],[]] .chain = true := by decide
def e1211203645870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203645870 : Closed e1211203645870 ∧ code e1211203645870 = 5609250156974 := by decide
theorem cert_e1211203645870 : check e1211203645870 [[],[]] .sourceHead = true := by decide
def e1211203645878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e1211203645878 : Closed e1211203645878 ∧ code e1211203645878 = 5609250156982 := by decide
theorem cert_e1211203645878 : check e1211203645878 [[],[]] .chain = true := by decide
def e1211203645882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203645882 : Closed e1211203645882 ∧ code e1211203645882 = 5609250156986 := by decide
theorem cert_e1211203645882 : check e1211203645882 [[],[]] .sourceHead = true := by decide
def e1211203645910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203645910 : Closed e1211203645910 ∧ code e1211203645910 = 5609250157014 := by decide
theorem cert_e1211203645910 : check e1211203645910 [[],[]] .chain = true := by decide
def e1211203645914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203645914 : Closed e1211203645914 ∧ code e1211203645914 = 5609250157018 := by decide
theorem cert_e1211203645914 : check e1211203645914 [[],[]] .chain = true := by decide
def e1211203645930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e1211203645930 : Closed e1211203645930 ∧ code e1211203645930 = 5609250157034 := by decide
theorem cert_e1211203645930 : check e1211203645930 [[],[]] .sourceHead = true := by decide
def e1211203646294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203646294 : Closed e1211203646294 ∧ code e1211203646294 = 5609250157398 := by decide
theorem cert_e1211203646294 : check e1211203646294 [[],[]] .chain = true := by decide
def e1211203646298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203646298 : Closed e1211203646298 ∧ code e1211203646298 = 5609250157402 := by decide
theorem cert_e1211203646298 : check e1211203646298 [[],[]] .chain = true := by decide
def e1211203646314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203646314 : Closed e1211203646314 ∧ code e1211203646314 = 5609250157418 := by decide
theorem cert_e1211203646314 : check e1211203646314 [[],[]] .chain = true := by decide
def e1211203646378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e1211203646378 : Closed e1211203646378 ∧ code e1211203646378 = 5609250157482 := by decide
theorem cert_e1211203646378 : check e1211203646378 [[],[]] .chain = true := by decide
def e1211203646486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203646486 : Closed e1211203646486 ∧ code e1211203646486 = 5609250157590 := by decide
theorem cert_e1211203646486 : check e1211203646486 [[],[]] .chain = true := by decide
def e1211203646490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203646490 : Closed e1211203646490 ∧ code e1211203646490 = 5609250157594 := by decide
theorem cert_e1211203646490 : check e1211203646490 [[],[]] .chain = true := by decide
def e1211203646534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203646534 : Closed e1211203646534 ∧ code e1211203646534 = 5609250157638 := by decide
theorem cert_e1211203646534 : check e1211203646534 [[],[]] .chain = true := by decide
def e1211203646562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203646562 : Closed e1211203646562 ∧ code e1211203646562 = 5609250157666 := by decide
theorem cert_e1211203646562 : check e1211203646562 [[],[]] .chain = true := by decide
def e1211203646574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203646574 : Closed e1211203646574 ∧ code e1211203646574 = 5609250157678 := by decide
theorem cert_e1211203646574 : check e1211203646574 [[],[]] .sourceHead = true := by decide
def e1211203646582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203646582 : Closed e1211203646582 ∧ code e1211203646582 = 5609250157686 := by decide
theorem cert_e1211203646582 : check e1211203646582 [[],[]] .chain = true := by decide
def e1211203646586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203646586 : Closed e1211203646586 ∧ code e1211203646586 = 5609250157690 := by decide
theorem cert_e1211203646586 : check e1211203646586 [[],[]] .sourceHead = true := by decide
def e1211203646678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203646678 : Closed e1211203646678 ∧ code e1211203646678 = 5609250157782 := by decide
theorem cert_e1211203646678 : check e1211203646678 [[],[]] .chain = true := by decide
def e1211203646682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203646682 : Closed e1211203646682 ∧ code e1211203646682 = 5609250157786 := by decide
theorem cert_e1211203646682 : check e1211203646682 [[],[]] .chain = true := by decide
def e1211203646698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203646698 : Closed e1211203646698 ∧ code e1211203646698 = 5609250157802 := by decide
theorem cert_e1211203646698 : check e1211203646698 [[],[]] .chain = true := by decide
def e1211203646726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203646726 : Closed e1211203646726 ∧ code e1211203646726 = 5609250157830 := by decide
theorem cert_e1211203646726 : check e1211203646726 [[],[]] .chain = true := by decide
def e1211203646750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203646750 : Closed e1211203646750 ∧ code e1211203646750 = 5609250157854 := by decide
theorem cert_e1211203646750 : check e1211203646750 [[],[]] .sourceHead = true := by decide
def e1211203646774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203646774 : Closed e1211203646774 ∧ code e1211203646774 = 5609250157878 := by decide
theorem cert_e1211203646774 : check e1211203646774 [[],[]] .chain = true := by decide
def e1211203646778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203646778 : Closed e1211203646778 ∧ code e1211203646778 = 5609250157882 := by decide
theorem cert_e1211203646778 : check e1211203646778 [[],[]] .chain = true := by decide
def e1211203646850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203646850 : Closed e1211203646850 ∧ code e1211203646850 = 5609250157954 := by decide
theorem cert_e1211203646850 : check e1211203646850 [[],[]] .chain = true := by decide
def e1211203646862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203646862 : Closed e1211203646862 ∧ code e1211203646862 = 5609250157966 := by decide
theorem cert_e1211203646862 : check e1211203646862 [[],[]] .chain = true := by decide
def e1211203646874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203646874 : Closed e1211203646874 ∧ code e1211203646874 = 5609250157978 := by decide
theorem cert_e1211203646874 : check e1211203646874 [[],[]] .chain = true := by decide
def e1211203646918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203646918 : Closed e1211203646918 ∧ code e1211203646918 = 5609250158022 := by decide
theorem cert_e1211203646918 : check e1211203646918 [[],[]] .sourceHead = true := by decide
def e1211203646986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203646986 : Closed e1211203646986 ∧ code e1211203646986 = 5609250158090 := by decide
theorem cert_e1211203646986 : check e1211203646986 [[],[]] .chain = true := by decide
def e1211203647030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203647030 : Closed e1211203647030 ∧ code e1211203647030 = 5609250158134 := by decide
theorem cert_e1211203647030 : check e1211203647030 [[],[]] .chain = true := by decide
def e1211203647034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203647034 : Closed e1211203647034 ∧ code e1211203647034 = 5609250158138 := by decide
theorem cert_e1211203647034 : check e1211203647034 [[],[]] .chain = true := by decide
def e1211203647082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203647082 : Closed e1211203647082 ∧ code e1211203647082 = 5609250158186 := by decide
theorem cert_e1211203647082 : check e1211203647082 [[],[]] .chain = true := by decide
def e1211203647106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203647106 : Closed e1211203647106 ∧ code e1211203647106 = 5609250158210 := by decide
theorem cert_e1211203647106 : check e1211203647106 [[],[]] .chain = true := by decide
def e1211203647118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203647118 : Closed e1211203647118 ∧ code e1211203647118 = 5609250158222 := by decide
theorem cert_e1211203647118 : check e1211203647118 [[],[]] .chain = true := by decide
def e1211203647130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203647130 : Closed e1211203647130 ∧ code e1211203647130 = 5609250158234 := by decide
theorem cert_e1211203647130 : check e1211203647130 [[],[]] .chain = true := by decide
def e1211203647174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203647174 : Closed e1211203647174 ∧ code e1211203647174 = 5609250158278 := by decide
theorem cert_e1211203647174 : check e1211203647174 [[],[]] .chain = true := by decide
def e1211203647258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203647258 : Closed e1211203647258 ∧ code e1211203647258 = 5609250158362 := by decide
theorem cert_e1211203647258 : check e1211203647258 [[],[]] .sourceHead = true := by decide
def e1211203647302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203647302 : Closed e1211203647302 ∧ code e1211203647302 = 5609250158406 := by decide
theorem cert_e1211203647302 : check e1211203647302 [[],[]] .sourceHead = true := by decide
def e1211203650030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211203650030 : Closed e1211203650030 ∧ code e1211203650030 = 5609250161134 := by decide
theorem cert_e1211203650030 : check e1211203650030 [[],[]] .chain = true := by decide
def e1211203650042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 5))))) (.var 0))))))
theorem wire_e1211203650042 : Closed e1211203650042 ∧ code e1211203650042 = 5609250161146 := by decide
theorem cert_e1211203650042 : check e1211203650042 [[],[]] .chain = true := by decide
def e1211203650798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203650798 : Closed e1211203650798 ∧ code e1211203650798 = 5609250161902 := by decide
theorem cert_e1211203650798 : check e1211203650798 [[],[]] .chain = true := by decide
def e1211203650806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203650806 : Closed e1211203650806 ∧ code e1211203650806 = 5609250161910 := by decide
theorem cert_e1211203650806 : check e1211203650806 [[],[]] .chain = true := by decide
def e1211203651182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203651182 : Closed e1211203651182 ∧ code e1211203651182 = 5609250162286 := by decide
theorem cert_e1211203651182 : check e1211203651182 [[],[]] .chain = true := by decide
def e1211203651194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203651194 : Closed e1211203651194 ∧ code e1211203651194 = 5609250162298 := by decide
theorem cert_e1211203651194 : check e1211203651194 [[],[]] .chain = true := by decide
def e1211203651358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211203651358 : Closed e1211203651358 ∧ code e1211203651358 = 5609250162462 := by decide
theorem cert_e1211203651358 : check e1211203651358 [[],[]] .chain = true := by decide
def e1211203651526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.lam (.var 1)))))))
theorem wire_e1211203651526 : Closed e1211203651526 ∧ code e1211203651526 = 5609250162630 := by decide
theorem cert_e1211203651526 : check e1211203651526 [[],[]] .chain = true := by decide
def e1211203652718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211203652718 : Closed e1211203652718 ∧ code e1211203652718 = 5609250163822 := by decide
theorem cert_e1211203652718 : check e1211203652718 [[],[]] .sourceHead = true := by decide
def e1211203652894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211203652894 : Closed e1211203652894 ∧ code e1211203652894 = 5609250163998 := by decide
theorem cert_e1211203652894 : check e1211203652894 [[],[]] .sourceHead = true := by decide
def e1211203653102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 2))))))
theorem wire_e1211203653102 : Closed e1211203653102 ∧ code e1211203653102 = 5609250164206 := by decide
theorem cert_e1211203653102 : check e1211203653102 [[],[]] .sourceHead = true := by decide
def e1211203653166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203653166 : Closed e1211203653166 ∧ code e1211203653166 = 5609250164270 := by decide
theorem cert_e1211203653166 : check e1211203653166 [[],[]] .chain = true := by decide
def e1211203653358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1211203653358 : Closed e1211203653358 ∧ code e1211203653358 = 5609250164462 := by decide
theorem cert_e1211203653358 : check e1211203653358 [[],[]] .chain = true := by decide
def e1211203653366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1211203653366 : Closed e1211203653366 ∧ code e1211203653366 = 5609250164470 := by decide
theorem cert_e1211203653366 : check e1211203653366 [[],[]] .chain = true := by decide
def e1211203653486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1211203653486 : Closed e1211203653486 ∧ code e1211203653486 = 5609250164590 := by decide
theorem cert_e1211203653486 : check e1211203653486 [[],[]] .chain = true := by decide
def e1211203653498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1211203653498 : Closed e1211203653498 ∧ code e1211203653498 = 5609250164602 := by decide
theorem cert_e1211203653498 : check e1211203653498 [[],[]] .chain = true := by decide
def e1211203653514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203653514 : Closed e1211203653514 ∧ code e1211203653514 = 5609250164618 := by decide
theorem cert_e1211203653514 : check e1211203653514 [[],[]] .chain = true := by decide
def e1211203653550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 2))))))
theorem wire_e1211203653550 : Closed e1211203653550 ∧ code e1211203653550 = 5609250164654 := by decide
theorem cert_e1211203653550 : check e1211203653550 [[],[]] .sourceHead = true := by decide
def e1211203653558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1211203653558 : Closed e1211203653558 ∧ code e1211203653558 = 5609250164662 := by decide
theorem cert_e1211203653558 : check e1211203653558 [[],[]] .chain = true := by decide
def e1211203653562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1211203653562 : Closed e1211203653562 ∧ code e1211203653562 = 5609250164666 := by decide
theorem cert_e1211203653562 : check e1211203653562 [[],[]] .chain = true := by decide
def e1211203654430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203654430 : Closed e1211203654430 ∧ code e1211203654430 = 5609250165534 := by decide
theorem cert_e1211203654430 : check e1211203654430 [[],[]] .chain = true := by decide
def e1211203654598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203654598 : Closed e1211203654598 ∧ code e1211203654598 = 5609250165702 := by decide
theorem cert_e1211203654598 : check e1211203654598 [[],[]] .chain = true := by decide
def e1211203655742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e1211203655742 : Closed e1211203655742 ∧ code e1211203655742 = 5609250166846 := by decide
theorem cert_e1211203655742 : check e1211203655742 [[],[]] .chain = true := by decide
def e1211203656162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203656162 : Closed e1211203656162 ∧ code e1211203656162 = 5609250167266 := by decide
theorem cert_e1211203656162 : check e1211203656162 [[],[]] .chain = true := by decide
def e1211203656174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203656174 : Closed e1211203656174 ∧ code e1211203656174 = 5609250167278 := by decide
theorem cert_e1211203656174 : check e1211203656174 [[],[]] .sourceHead = true := by decide
def e1211203656942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203656942 : Closed e1211203656942 ∧ code e1211203656942 = 5609250168046 := by decide
theorem cert_e1211203656942 : check e1211203656942 [[],[]] .chain = true := by decide
def e1211203656950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203656950 : Closed e1211203656950 ∧ code e1211203656950 = 5609250168054 := by decide
theorem cert_e1211203656950 : check e1211203656950 [[],[]] .chain = true := by decide
def e1211203657230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203657230 : Closed e1211203657230 ∧ code e1211203657230 = 5609250168334 := by decide
theorem cert_e1211203657230 : check e1211203657230 [[],[]] .chain = true := by decide
def e1211203657242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203657242 : Closed e1211203657242 ∧ code e1211203657242 = 5609250168346 := by decide
theorem cert_e1211203657242 : check e1211203657242 [[],[]] .sourceHead = true := by decide
def e1211203657314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203657314 : Closed e1211203657314 ∧ code e1211203657314 = 5609250168418 := by decide
theorem cert_e1211203657314 : check e1211203657314 [[],[]] .chain = true := by decide
def e1211203657326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203657326 : Closed e1211203657326 ∧ code e1211203657326 = 5609250168430 := by decide
theorem cert_e1211203657326 : check e1211203657326 [[],[]] .sourceHead = true := by decide
def e1211203657334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203657334 : Closed e1211203657334 ∧ code e1211203657334 = 5609250168438 := by decide
theorem cert_e1211203657334 : check e1211203657334 [[],[]] .chain = true := by decide
def e1211203657338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203657338 : Closed e1211203657338 ∧ code e1211203657338 = 5609250168442 := by decide
theorem cert_e1211203657338 : check e1211203657338 [[],[]] .sourceHead = true := by decide
def e1211203661166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211203661166 : Closed e1211203661166 ∧ code e1211203661166 = 5609250172270 := by decide
theorem cert_e1211203661166 : check e1211203661166 [[],[]] .chain = true := by decide
def e1211203661174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211203661174 : Closed e1211203661174 ∧ code e1211203661174 = 5609250172278 := by decide
theorem cert_e1211203661174 : check e1211203661174 [[],[]] .chain = true := by decide
def e1211203661230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211203661230 : Closed e1211203661230 ∧ code e1211203661230 = 5609250172334 := by decide
theorem cert_e1211203661230 : check e1211203661230 [[],[]] .chain = true := by decide
def e1211203661242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211203661242 : Closed e1211203661242 ∧ code e1211203661242 = 5609250172346 := by decide
theorem cert_e1211203661242 : check e1211203661242 [[],[]] .chain = true := by decide
def e1211203661270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211203661270 : Closed e1211203661270 ∧ code e1211203661270 = 5609250172374 := by decide
theorem cert_e1211203661270 : check e1211203661270 [[],[]] .chain = true := by decide
def e1211203661274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211203661274 : Closed e1211203661274 ∧ code e1211203661274 = 5609250172378 := by decide
theorem cert_e1211203661274 : check e1211203661274 [[],[]] .chain = true := by decide
def e1211203661486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211203661486 : Closed e1211203661486 ∧ code e1211203661486 = 5609250172590 := by decide
theorem cert_e1211203661486 : check e1211203661486 [[],[]] .chain = true := by decide
def e1211203661498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211203661498 : Closed e1211203661498 ∧ code e1211203661498 = 5609250172602 := by decide
theorem cert_e1211203661498 : check e1211203661498 [[],[]] .chain = true := by decide
end Blc.Floor42
