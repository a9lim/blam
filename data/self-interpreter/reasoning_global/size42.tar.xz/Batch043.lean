import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1124040010998 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124040010998 : Closed e1124040010998 ∧ code e1124040010998 = 5522086522102 := by decide
theorem cert_e1124040010998 : check e1124040010998 [[]] .sourceHead = true := by decide
def e1124040011382 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124040011382 : Closed e1124040011382 ∧ code e1124040011382 = 5522086522486 := by decide
theorem cert_e1124040011382 : check e1124040011382 [[]] .sourceHead = true := by decide
def e1124040012654 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1124040012654 : Closed e1124040012654 ∧ code e1124040012654 = 5522086523758 := by decide
theorem cert_e1124040012654 : check e1124040012654 [[]] .sourceHead = true := by decide
def e1124040012662 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1124040012662 : Closed e1124040012662 ∧ code e1124040012662 = 5522086523766 := by decide
theorem cert_e1124040012662 : check e1124040012662 [[]] .sourceHead = true := by decide
def e1124040012718 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1124040012718 : Closed e1124040012718 ∧ code e1124040012718 = 5522086523822 := by decide
theorem cert_e1124040012718 : check e1124040012718 [[]] .sourceHead = true := by decide
def e1124040012730 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1124040012730 : Closed e1124040012730 ∧ code e1124040012730 = 5522086523834 := by decide
theorem cert_e1124040012730 : check e1124040012730 [[]] .sourceHead = true := by decide
def e1124040012758 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1124040012758 : Closed e1124040012758 ∧ code e1124040012758 = 5522086523862 := by decide
theorem cert_e1124040012758 : check e1124040012758 [[]] .sourceHead = true := by decide
def e1124040012762 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1124040012762 : Closed e1124040012762 ∧ code e1124040012762 = 5522086523866 := by decide
theorem cert_e1124040012762 : check e1124040012762 [[]] .sourceHead = true := by decide
def e1124040013038 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124040013038 : Closed e1124040013038 ∧ code e1124040013038 = 5522086524142 := by decide
theorem cert_e1124040013038 : check e1124040013038 [[]] .sourceHead = true := by decide
def e1124040013046 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124040013046 : Closed e1124040013046 ∧ code e1124040013046 = 5522086524150 := by decide
theorem cert_e1124040013046 : check e1124040013046 [[]] .sourceHead = true := by decide
def e1124040013422 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1124040013422 : Closed e1124040013422 ∧ code e1124040013422 = 5522086524526 := by decide
theorem cert_e1124040013422 : check e1124040013422 [[]] .sourceHead = true := by decide
def e1124040013434 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1124040013434 : Closed e1124040013434 ∧ code e1124040013434 = 5522086524538 := by decide
theorem cert_e1124040013434 : check e1124040013434 [[]] .sourceHead = true := by decide
def e1124040013622 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124040013622 : Closed e1124040013622 ∧ code e1124040013622 = 5522086524726 := by decide
theorem cert_e1124040013622 : check e1124040013622 [[]] .sourceHead = true := by decide
def e1124040013626 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124040013626 : Closed e1124040013626 ∧ code e1124040013626 = 5522086524730 := by decide
theorem cert_e1124040013626 : check e1124040013626 [[]] .sourceHead = true := by decide
def e1124040014262 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1124040014262 : Closed e1124040014262 ∧ code e1124040014262 = 5522086525366 := by decide
theorem cert_e1124040014262 : check e1124040014262 [[]] .sourceHead = true := by decide
def e1124040014294 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1124040014294 : Closed e1124040014294 ∧ code e1124040014294 = 5522086525398 := by decide
theorem cert_e1124040014294 : check e1124040014294 [[]] .sourceHead = true := by decide
def e1124040014298 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1124040014298 : Closed e1124040014298 ∧ code e1124040014298 = 5522086525402 := by decide
theorem cert_e1124040014298 : check e1124040014298 [[]] .sourceHead = true := by decide
def e1124040014454 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124040014454 : Closed e1124040014454 ∧ code e1124040014454 = 5522086525558 := by decide
theorem cert_e1124040014454 : check e1124040014454 [[]] .sourceHead = true := by decide
def e1124040014646 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124040014646 : Closed e1124040014646 ∧ code e1124040014646 = 5522086525750 := by decide
theorem cert_e1124040014646 : check e1124040014646 [[]] .sourceHead = true := by decide
def e1124040014650 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124040014650 : Closed e1124040014650 ∧ code e1124040014650 = 5522086525754 := by decide
theorem cert_e1124040014650 : check e1124040014650 [[]] .sourceHead = true := by decide
def e1124040021870 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1124040021870 : Closed e1124040021870 ∧ code e1124040021870 = 5522086532974 := by decide
theorem cert_e1124040021870 : check e1124040021870 [[]] .sourceHead = true := by decide
def e1124040021878 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1124040021878 : Closed e1124040021878 ∧ code e1124040021878 = 5522086532982 := by decide
theorem cert_e1124040021878 : check e1124040021878 [[]] .sourceHead = true := by decide
def e1124040021942 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1124040021942 : Closed e1124040021942 ∧ code e1124040021942 = 5522086533046 := by decide
theorem cert_e1124040021942 : check e1124040021942 [[]] .sourceHead = true := by decide
def e1124040023278 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1124040023278 : Closed e1124040023278 ∧ code e1124040023278 = 5522086534382 := by decide
theorem cert_e1124040023278 : check e1124040023278 [[]] .sourceHead = true := by decide
def e1124040023286 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1124040023286 : Closed e1124040023286 ∧ code e1124040023286 = 5522086534390 := by decide
theorem cert_e1124040023286 : check e1124040023286 [[]] .sourceHead = true := by decide
def e1124040023670 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1124040023670 : Closed e1124040023670 ∧ code e1124040023670 = 5522086534774 := by decide
theorem cert_e1124040023670 : check e1124040023670 [[]] .sourceHead = true := by decide
def e1124040035182 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124040035182 : Closed e1124040035182 ∧ code e1124040035182 = 5522086546286 := by decide
theorem cert_e1124040035182 : check e1124040035182 [[]] .sourceHead = true := by decide
def e1124040035190 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124040035190 : Closed e1124040035190 ∧ code e1124040035190 = 5522086546294 := by decide
theorem cert_e1124040035190 : check e1124040035190 [[]] .sourceHead = true := by decide
def e1124040035246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124040035246 : Closed e1124040035246 ∧ code e1124040035246 = 5522086546350 := by decide
theorem cert_e1124040035246 : check e1124040035246 [[]] .sourceHead = true := by decide
def e1124040035258 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124040035258 : Closed e1124040035258 ∧ code e1124040035258 = 5522086546362 := by decide
theorem cert_e1124040035258 : check e1124040035258 [[]] .sourceHead = true := by decide
def e1124040035286 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124040035286 : Closed e1124040035286 ∧ code e1124040035286 = 5522086546390 := by decide
theorem cert_e1124040035286 : check e1124040035286 [[]] .sourceHead = true := by decide
def e1124040035290 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124040035290 : Closed e1124040035290 ∧ code e1124040035290 = 5522086546394 := by decide
theorem cert_e1124040035290 : check e1124040035290 [[]] .sourceHead = true := by decide
def e1124040035566 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124040035566 : Closed e1124040035566 ∧ code e1124040035566 = 5522086546670 := by decide
theorem cert_e1124040035566 : check e1124040035566 [[]] .sourceHead = true := by decide
def e1124040035574 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124040035574 : Closed e1124040035574 ∧ code e1124040035574 = 5522086546678 := by decide
theorem cert_e1124040035574 : check e1124040035574 [[]] .sourceHead = true := by decide
def e1124040035950 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124040035950 : Closed e1124040035950 ∧ code e1124040035950 = 5522086547054 := by decide
theorem cert_e1124040035950 : check e1124040035950 [[]] .sourceHead = true := by decide
def e1124040035962 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124040035962 : Closed e1124040035962 ∧ code e1124040035962 = 5522086547066 := by decide
theorem cert_e1124040035962 : check e1124040035962 [[]] .sourceHead = true := by decide
def e1124040036150 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124040036150 : Closed e1124040036150 ∧ code e1124040036150 = 5522086547254 := by decide
theorem cert_e1124040036150 : check e1124040036150 [[]] .sourceHead = true := by decide
def e1124040036154 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124040036154 : Closed e1124040036154 ∧ code e1124040036154 = 5522086547258 := by decide
theorem cert_e1124040036154 : check e1124040036154 [[]] .sourceHead = true := by decide
def e1124040041910 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1124040041910 : Closed e1124040041910 ∧ code e1124040041910 = 5522086553014 := by decide
theorem cert_e1124040041910 : check e1124040041910 [[]] .sourceHead = true := by decide
def e1124040041942 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1124040041942 : Closed e1124040041942 ∧ code e1124040041942 = 5522086553046 := by decide
theorem cert_e1124040041942 : check e1124040041942 [[]] .sourceHead = true := by decide
def e1124040041946 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1124040041946 : Closed e1124040041946 ∧ code e1124040041946 = 5522086553050 := by decide
theorem cert_e1124040041946 : check e1124040041946 [[]] .sourceHead = true := by decide
def e1124040042102 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1124040042102 : Closed e1124040042102 ∧ code e1124040042102 = 5522086553206 := by decide
theorem cert_e1124040042102 : check e1124040042102 [[]] .sourceHead = true := by decide
def e1124040042294 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1124040042294 : Closed e1124040042294 ∧ code e1124040042294 = 5522086553398 := by decide
theorem cert_e1124040042294 : check e1124040042294 [[]] .sourceHead = true := by decide
def e1124040042298 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1124040042298 : Closed e1124040042298 ∧ code e1124040042298 = 5522086553402 := by decide
theorem cert_e1124040042298 : check e1124040042298 [[]] .sourceHead = true := by decide
def e1124040379246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124040379246 : Closed e1124040379246 ∧ code e1124040379246 = 5522086890350 := by decide
theorem cert_e1124040379246 : check e1124040379246 [[]] .sourceHead = true := by decide
def e1124040379254 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124040379254 : Closed e1124040379254 ∧ code e1124040379254 = 5522086890358 := by decide
theorem cert_e1124040379254 : check e1124040379254 [[]] .sourceHead = true := by decide
def e1124040379310 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124040379310 : Closed e1124040379310 ∧ code e1124040379310 = 5522086890414 := by decide
theorem cert_e1124040379310 : check e1124040379310 [[]] .sourceHead = true := by decide
def e1124040379322 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124040379322 : Closed e1124040379322 ∧ code e1124040379322 = 5522086890426 := by decide
theorem cert_e1124040379322 : check e1124040379322 [[]] .sourceHead = true := by decide
def e1124040379350 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124040379350 : Closed e1124040379350 ∧ code e1124040379350 = 5522086890454 := by decide
theorem cert_e1124040379350 : check e1124040379350 [[]] .sourceHead = true := by decide
def e1124040379354 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124040379354 : Closed e1124040379354 ∧ code e1124040379354 = 5522086890458 := by decide
theorem cert_e1124040379354 : check e1124040379354 [[]] .sourceHead = true := by decide
def e1124040379630 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124040379630 : Closed e1124040379630 ∧ code e1124040379630 = 5522086890734 := by decide
theorem cert_e1124040379630 : check e1124040379630 [[]] .sourceHead = true := by decide
def e1124040379638 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124040379638 : Closed e1124040379638 ∧ code e1124040379638 = 5522086890742 := by decide
theorem cert_e1124040379638 : check e1124040379638 [[]] .sourceHead = true := by decide
def e1124040380014 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124040380014 : Closed e1124040380014 ∧ code e1124040380014 = 5522086891118 := by decide
theorem cert_e1124040380014 : check e1124040380014 [[]] .sourceHead = true := by decide
def e1124040380026 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124040380026 : Closed e1124040380026 ∧ code e1124040380026 = 5522086891130 := by decide
theorem cert_e1124040380026 : check e1124040380026 [[]] .sourceHead = true := by decide
def e1124040380214 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124040380214 : Closed e1124040380214 ∧ code e1124040380214 = 5522086891318 := by decide
theorem cert_e1124040380214 : check e1124040380214 [[]] .sourceHead = true := by decide
def e1124040380218 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124040380218 : Closed e1124040380218 ∧ code e1124040380218 = 5522086891322 := by decide
theorem cert_e1124040380218 : check e1124040380218 [[]] .sourceHead = true := by decide
def e1124219680282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124219680282 : Closed e1124219680282 ∧ code e1124219680282 = 5522266191386 := by decide
theorem cert_e1124219680282 : check e1124219680282 [[]] .width = true := by decide
def e1124219729434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124219729434 : Closed e1124219729434 ∧ code e1124219729434 = 5522266240538 := by decide
theorem cert_e1124219729434 : check e1124219729434 [[]] .width = true := by decide
def e1124219942426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124219942426 : Closed e1124219942426 ∧ code e1124219942426 = 5522266453530 := by decide
theorem cert_e1124219942426 : check e1124219942426 [[]] .width = true := by decide
def e1124219999770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124219999770 : Closed e1124219999770 ∧ code e1124219999770 = 5522266510874 := by decide
private def t_e1124219999770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124219999770 : ¬ IsSelfInterpreter e1124219999770 :=
  wSource (t := t_e1124219999770) (replay_sound (ps := []) (t := e1124219999770) (by decide)) (by decide)
def e1124220188186 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124220188186 : Closed e1124220188186 ∧ code e1124220188186 = 5522266699290 := by decide
theorem cert_e1124220188186 : check e1124220188186 [[]] .width = true := by decide
def e1124220196378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124220196378 : Closed e1124220196378 ∧ code e1124220196378 = 5522266707482 := by decide
private def t_e1124220196378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124220196378 : ¬ IsSelfInterpreter e1124220196378 :=
  wSource (t := t_e1124220196378) (replay_sound (ps := []) (t := e1124220196378) (by decide)) (by decide)
def e1124221253146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124221253146 : Closed e1124221253146 ∧ code e1124221253146 = 5522267764250 := by decide
theorem cert_e1124221253146 : check e1124221253146 [[]] .width = true := by decide
def e1124221302298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124221302298 : Closed e1124221302298 ∧ code e1124221302298 = 5522267813402 := by decide
theorem cert_e1124221302298 : check e1124221302298 [[]] .width = true := by decide
def e1124222826010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124222826010 : Closed e1124222826010 ∧ code e1124222826010 = 5522269337114 := by decide
theorem cert_e1124222826010 : check e1124222826010 [[]] .width = true := by decide
def e1124222883354 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124222883354 : Closed e1124222883354 ∧ code e1124222883354 = 5522269394458 := by decide
theorem cert_e1124222883354 : check e1124222883354 [[]] .width = true := by decide
def e1124224054810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124224054810 : Closed e1124224054810 ∧ code e1124224054810 = 5522270565914 := by decide
theorem cert_e1124224054810 : check e1124224054810 [[]] .width = true := by decide
def e1124224063002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124224063002 : Closed e1124224063002 ∧ code e1124224063002 = 5522270574106 := by decide
theorem cert_e1124224063002 : check e1124224063002 [[]] .width = true := by decide
def e1124254316058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124254316058 : Closed e1124254316058 ∧ code e1124254316058 = 5522300827162 := by decide
theorem cert_e1124254316058 : check e1124254316058 [[]] .width = true := by decide
def e1124254332442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124254332442 : Closed e1124254332442 ∧ code e1124254332442 = 5522300843546 := by decide
theorem cert_e1124254332442 : check e1124254332442 [[]] .width = true := by decide
def e1124255462938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124255462938 : Closed e1124255462938 ∧ code e1124255462938 = 5522301974042 := by decide
theorem cert_e1124255462938 : check e1124255462938 [[]] .width = true := by decide
def e1124255632922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124255632922 : Closed e1124255632922 ∧ code e1124255632922 = 5522302144026 := by decide
theorem cert_e1124255632922 : check e1124255632922 [[]] .width = true := by decide
def e1124255637530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124255637530 : Closed e1124255637530 ∧ code e1124255637530 = 5522302148634 := by decide
theorem cert_e1124255637530 : check e1124255637530 [[]] .width = true := by decide
def e1124255637622 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124255637622 : Closed e1124255637622 ∧ code e1124255637622 = 5522302148726 := by decide
theorem cert_e1124255637622 : check e1124255637622 [[]] .width = true := by decide
def e1124255637866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124255637866 : Closed e1124255637866 ∧ code e1124255637866 = 5522302148970 := by decide
theorem cert_e1124255637866 : check e1124255637866 [[]] .width = true := by decide
def e1124255637914 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124255637914 : Closed e1124255637914 ∧ code e1124255637914 = 5522302149018 := by decide
theorem cert_e1124255637914 : check e1124255637914 [[]] .width = true := by decide
def e1124255641798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124255641798 : Closed e1124255641798 ∧ code e1124255641798 = 5522302152902 := by decide
theorem cert_e1124255641798 : check e1124255641798 [[]] .width = true := by decide
def e1124255692314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124255692314 : Closed e1124255692314 ∧ code e1124255692314 = 5522302203418 := by decide
private def t_e1124255692314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124255692314 : ¬ IsSelfInterpreter e1124255692314 :=
  wSource (t := t_e1124255692314) (replay_sound (ps := []) (t := e1124255692314) (by decide)) (by decide)
def e1124255763994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124255763994 : Closed e1124255763994 ∧ code e1124255763994 = 5522302275098 := by decide
private def t_e1124255763994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124255763994 : ¬ IsSelfInterpreter e1124255763994 :=
  wSource (t := t_e1124255763994) (replay_sound (ps := []) (t := e1124255763994) (by decide)) (by decide)
def e1124255768602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124255768602 : Closed e1124255768602 ∧ code e1124255768602 = 5522302279706 := by decide
theorem cert_e1124255768602 : check e1124255768602 [[]] .width = true := by decide
def e1124255768694 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124255768694 : Closed e1124255768694 ∧ code e1124255768694 = 5522302279798 := by decide
private def t_e1124255768694 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1124255768694 : ¬ IsSelfInterpreter e1124255768694 :=
  wSource (t := t_e1124255768694) (replay_sound (ps := []) (t := e1124255768694) (by decide)) (by decide)
def e1124255768938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124255768938 : Closed e1124255768938 ∧ code e1124255768938 = 5522302280042 := by decide
private def t_e1124255768938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1124255768938 : ¬ IsSelfInterpreter e1124255768938 :=
  wSource (t := t_e1124255768938) (replay_sound (ps := []) (t := e1124255768938) (by decide)) (by decide)
def e1124255768986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124255768986 : Closed e1124255768986 ∧ code e1124255768986 = 5522302280090 := by decide
private def t_e1124255768986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1124255768986 : ¬ IsSelfInterpreter e1124255768986 :=
  wSource (t := t_e1124255768986) (replay_sound (ps := []) (t := e1124255768986) (by decide)) (by decide)
def e1124255772870 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124255772870 : Closed e1124255772870 ∧ code e1124255772870 = 5522302283974 := by decide
theorem cert_e1124255772870 : check e1124255772870 [[]] .width = true := by decide
def e1124256151066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256151066 : Closed e1124256151066 ∧ code e1124256151066 = 5522302662170 := by decide
theorem cert_e1124256151066 : check e1124256151066 [[]] .width = true := by decide
def e1124256175642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256175642 : Closed e1124256175642 ∧ code e1124256175642 = 5522302686746 := by decide
theorem cert_e1124256175642 : check e1124256175642 [[]] .width = true := by decide
def e1124256511514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256511514 : Closed e1124256511514 ∧ code e1124256511514 = 5522303022618 := by decide
theorem cert_e1124256511514 : check e1124256511514 [[]] .width = true := by decide
def e1124256681498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256681498 : Closed e1124256681498 ∧ code e1124256681498 = 5522303192602 := by decide
theorem cert_e1124256681498 : check e1124256681498 [[]] .width = true := by decide
def e1124256686106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124256686106 : Closed e1124256686106 ∧ code e1124256686106 = 5522303197210 := by decide
theorem cert_e1124256686106 : check e1124256686106 [[]] .width = true := by decide
def e1124256686198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124256686198 : Closed e1124256686198 ∧ code e1124256686198 = 5522303197302 := by decide
theorem cert_e1124256686198 : check e1124256686198 [[]] .width = true := by decide
def e1124256686442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124256686442 : Closed e1124256686442 ∧ code e1124256686442 = 5522303197546 := by decide
theorem cert_e1124256686442 : check e1124256686442 [[]] .width = true := by decide
def e1124256686490 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124256686490 : Closed e1124256686490 ∧ code e1124256686490 = 5522303197594 := by decide
theorem cert_e1124256686490 : check e1124256686490 [[]] .width = true := by decide
def e1124256690374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124256690374 : Closed e1124256690374 ∧ code e1124256690374 = 5522303201478 := by decide
theorem cert_e1124256690374 : check e1124256690374 [[]] .width = true := by decide
def e1124256855578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256855578 : Closed e1124256855578 ∧ code e1124256855578 = 5522303366682 := by decide
theorem cert_e1124256855578 : check e1124256855578 [[]] .width = true := by decide
def e1124256878106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124256878106 : Closed e1124256878106 ∧ code e1124256878106 = 5522303389210 := by decide
theorem cert_e1124256878106 : check e1124256878106 [[]] .width = true := by decide
def e1124256882714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124256882714 : Closed e1124256882714 ∧ code e1124256882714 = 5522303393818 := by decide
theorem cert_e1124256882714 : check e1124256882714 [[]] .width = true := by decide
def e1124256882806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124256882806 : Closed e1124256882806 ∧ code e1124256882806 = 5522303393910 := by decide
theorem cert_e1124256882806 : check e1124256882806 [[]] .width = true := by decide
def e1124256883050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124256883050 : Closed e1124256883050 ∧ code e1124256883050 = 5522303394154 := by decide
theorem cert_e1124256883050 : check e1124256883050 [[]] .width = true := by decide
def e1124256883098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124256883098 : Closed e1124256883098 ∧ code e1124256883098 = 5522303394202 := by decide
theorem cert_e1124256883098 : check e1124256883098 [[]] .width = true := by decide
def e1124256886982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124256886982 : Closed e1124256886982 ∧ code e1124256886982 = 5522303398086 := by decide
theorem cert_e1124256886982 : check e1124256886982 [[]] .width = true := by decide
def e1124257084954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257084954 : Closed e1124257084954 ∧ code e1124257084954 = 5522303596058 := by decide
theorem cert_e1124257084954 : check e1124257084954 [[]] .width = true := by decide
def e1124257093146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257093146 : Closed e1124257093146 ∧ code e1124257093146 = 5522303604250 := by decide
theorem cert_e1124257093146 : check e1124257093146 [[]] .width = true := by decide
def e1124257265178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257265178 : Closed e1124257265178 ∧ code e1124257265178 = 5522303776282 := by decide
private def t_e1124257265178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124257265178 : ¬ IsSelfInterpreter e1124257265178 :=
  wSource (t := t_e1124257265178) (replay_sound (ps := []) (t := e1124257265178) (by decide)) (by decide)
def e1124257336858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257336858 : Closed e1124257336858 ∧ code e1124257336858 = 5522303847962 := by decide
private def t_e1124257336858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124257336858 : ¬ IsSelfInterpreter e1124257336858 :=
  wSource (t := t_e1124257336858) (replay_sound (ps := []) (t := e1124257336858) (by decide)) (by decide)
def e1124257341466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124257341466 : Closed e1124257341466 ∧ code e1124257341466 = 5522303852570 := by decide
theorem cert_e1124257341466 : check e1124257341466 [[]] .width = true := by decide
def e1124257341558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124257341558 : Closed e1124257341558 ∧ code e1124257341558 = 5522303852662 := by decide
private def t_e1124257341558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1124257341558 : ¬ IsSelfInterpreter e1124257341558 :=
  wSource (t := t_e1124257341558) (replay_sound (ps := []) (t := e1124257341558) (by decide)) (by decide)
def e1124257341802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124257341802 : Closed e1124257341802 ∧ code e1124257341802 = 5522303852906 := by decide
private def t_e1124257341802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1124257341802 : ¬ IsSelfInterpreter e1124257341802 :=
  wSource (t := t_e1124257341802) (replay_sound (ps := []) (t := e1124257341802) (by decide)) (by decide)
def e1124257341850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124257341850 : Closed e1124257341850 ∧ code e1124257341850 = 5522303852954 := by decide
private def t_e1124257341850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1124257341850 : ¬ IsSelfInterpreter e1124257341850 :=
  wSource (t := t_e1124257341850) (replay_sound (ps := []) (t := e1124257341850) (by decide)) (by decide)
def e1124257345734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124257345734 : Closed e1124257345734 ∧ code e1124257345734 = 5522303856838 := by decide
theorem cert_e1124257345734 : check e1124257345734 [[]] .width = true := by decide
def e1124257379866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257379866 : Closed e1124257379866 ∧ code e1124257379866 = 5522303890970 := by decide
theorem cert_e1124257379866 : check e1124257379866 [[]] .width = true := by decide
def e1124257402394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124257402394 : Closed e1124257402394 ∧ code e1124257402394 = 5522303913498 := by decide
theorem cert_e1124257402394 : check e1124257402394 [[]] .width = true := by decide
def e1124257407002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124257407002 : Closed e1124257407002 ∧ code e1124257407002 = 5522303918106 := by decide
theorem cert_e1124257407002 : check e1124257407002 [[]] .width = true := by decide
def e1124257407094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124257407094 : Closed e1124257407094 ∧ code e1124257407094 = 5522303918198 := by decide
theorem cert_e1124257407094 : check e1124257407094 [[]] .width = true := by decide
def e1124257407338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124257407338 : Closed e1124257407338 ∧ code e1124257407338 = 5522303918442 := by decide
theorem cert_e1124257407338 : check e1124257407338 [[]] .width = true := by decide
def e1124257407386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124257407386 : Closed e1124257407386 ∧ code e1124257407386 = 5522303918490 := by decide
theorem cert_e1124257407386 : check e1124257407386 [[]] .width = true := by decide
def e1124257411270 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124257411270 : Closed e1124257411270 ∧ code e1124257411270 = 5522303922374 := by decide
theorem cert_e1124257411270 : check e1124257411270 [[]] .width = true := by decide
def e1124261754394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124261754394 : Closed e1124261754394 ∧ code e1124261754394 = 5522308265498 := by decide
theorem cert_e1124261754394 : check e1124261754394 [[]] .width = true := by decide
def e1124261924378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124261924378 : Closed e1124261924378 ∧ code e1124261924378 = 5522308435482 := by decide
theorem cert_e1124261924378 : check e1124261924378 [[]] .width = true := by decide
def e1124261928986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124261928986 : Closed e1124261928986 ∧ code e1124261928986 = 5522308440090 := by decide
theorem cert_e1124261928986 : check e1124261928986 [[]] .width = true := by decide
def e1124261929078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124261929078 : Closed e1124261929078 ∧ code e1124261929078 = 5522308440182 := by decide
theorem cert_e1124261929078 : check e1124261929078 [[]] .width = true := by decide
def e1124261929322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124261929322 : Closed e1124261929322 ∧ code e1124261929322 = 5522308440426 := by decide
theorem cert_e1124261929322 : check e1124261929322 [[]] .width = true := by decide
def e1124261929370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124261929370 : Closed e1124261929370 ∧ code e1124261929370 = 5522308440474 := by decide
theorem cert_e1124261929370 : check e1124261929370 [[]] .width = true := by decide
def e1124261933254 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124261933254 : Closed e1124261933254 ∧ code e1124261933254 = 5522308444358 := by decide
theorem cert_e1124261933254 : check e1124261933254 [[]] .width = true := by decide
def e1124261983770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124261983770 : Closed e1124261983770 ∧ code e1124261983770 = 5522308494874 := by decide
theorem cert_e1124261983770 : check e1124261983770 [[]] .width = true := by decide
def e1124262055450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124262055450 : Closed e1124262055450 ∧ code e1124262055450 = 5522308566554 := by decide
theorem cert_e1124262055450 : check e1124262055450 [[]] .width = true := by decide
def e1124262060058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124262060058 : Closed e1124262060058 ∧ code e1124262060058 = 5522308571162 := by decide
theorem cert_e1124262060058 : check e1124262060058 [[]] .width = true := by decide
def e1124262060150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124262060150 : Closed e1124262060150 ∧ code e1124262060150 = 5522308571254 := by decide
theorem cert_e1124262060150 : check e1124262060150 [[]] .width = true := by decide
def e1124262060394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124262060394 : Closed e1124262060394 ∧ code e1124262060394 = 5522308571498 := by decide
theorem cert_e1124262060394 : check e1124262060394 [[]] .width = true := by decide
def e1124262060442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124262060442 : Closed e1124262060442 ∧ code e1124262060442 = 5522308571546 := by decide
theorem cert_e1124262060442 : check e1124262060442 [[]] .width = true := by decide
def e1124262064326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124262064326 : Closed e1124262064326 ∧ code e1124262064326 = 5522308575430 := by decide
theorem cert_e1124262064326 : check e1124262064326 [[]] .width = true := by decide
def e1124268045850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124268045850 : Closed e1124268045850 ∧ code e1124268045850 = 5522314556954 := by decide
theorem cert_e1124268045850 : check e1124268045850 [[]] .width = true := by decide
def e1124268215834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124268215834 : Closed e1124268215834 ∧ code e1124268215834 = 5522314726938 := by decide
theorem cert_e1124268215834 : check e1124268215834 [[]] .width = true := by decide
def e1124268220442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124268220442 : Closed e1124268220442 ∧ code e1124268220442 = 5522314731546 := by decide
theorem cert_e1124268220442 : check e1124268220442 [[]] .width = true := by decide
def e1124268220534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124268220534 : Closed e1124268220534 ∧ code e1124268220534 = 5522314731638 := by decide
theorem cert_e1124268220534 : check e1124268220534 [[]] .width = true := by decide
def e1124268220778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124268220778 : Closed e1124268220778 ∧ code e1124268220778 = 5522314731882 := by decide
theorem cert_e1124268220778 : check e1124268220778 [[]] .width = true := by decide
def e1124268220826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124268220826 : Closed e1124268220826 ∧ code e1124268220826 = 5522314731930 := by decide
theorem cert_e1124268220826 : check e1124268220826 [[]] .width = true := by decide
def e1124268224710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124268224710 : Closed e1124268224710 ∧ code e1124268224710 = 5522314735814 := by decide
theorem cert_e1124268224710 : check e1124268224710 [[]] .width = true := by decide
def e1124268389914 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124268389914 : Closed e1124268389914 ∧ code e1124268389914 = 5522314901018 := by decide
theorem cert_e1124268389914 : check e1124268389914 [[]] .width = true := by decide
def e1124268412442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124268412442 : Closed e1124268412442 ∧ code e1124268412442 = 5522314923546 := by decide
theorem cert_e1124268412442 : check e1124268412442 [[]] .width = true := by decide
def e1124268417050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124268417050 : Closed e1124268417050 ∧ code e1124268417050 = 5522314928154 := by decide
theorem cert_e1124268417050 : check e1124268417050 [[]] .width = true := by decide
def e1124268417142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124268417142 : Closed e1124268417142 ∧ code e1124268417142 = 5522314928246 := by decide
theorem cert_e1124268417142 : check e1124268417142 [[]] .width = true := by decide
def e1124268417386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124268417386 : Closed e1124268417386 ∧ code e1124268417386 = 5522314928490 := by decide
theorem cert_e1124268417386 : check e1124268417386 [[]] .width = true := by decide
def e1124268417434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124268417434 : Closed e1124268417434 ∧ code e1124268417434 = 5522314928538 := by decide
theorem cert_e1124268417434 : check e1124268417434 [[]] .width = true := by decide
def e1124268421318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124268421318 : Closed e1124268421318 ∧ code e1124268421318 = 5522314932422 := by decide
theorem cert_e1124268421318 : check e1124268421318 [[]] .width = true := by decide
def e1124271420954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124271420954 : Closed e1124271420954 ∧ code e1124271420954 = 5522317932058 := by decide
theorem cert_e1124271420954 : check e1124271420954 [[]] .width = true := by decide
def e1124271492634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124271492634 : Closed e1124271492634 ∧ code e1124271492634 = 5522318003738 := by decide
theorem cert_e1124271492634 : check e1124271492634 [[]] .width = true := by decide
def e1124271497242 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124271497242 : Closed e1124271497242 ∧ code e1124271497242 = 5522318008346 := by decide
theorem cert_e1124271497242 : check e1124271497242 [[]] .width = true := by decide
def e1124271497334 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124271497334 : Closed e1124271497334 ∧ code e1124271497334 = 5522318008438 := by decide
theorem cert_e1124271497334 : check e1124271497334 [[]] .width = true := by decide
def e1124271497578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124271497578 : Closed e1124271497578 ∧ code e1124271497578 = 5522318008682 := by decide
theorem cert_e1124271497578 : check e1124271497578 [[]] .width = true := by decide
def e1124271497626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124271497626 : Closed e1124271497626 ∧ code e1124271497626 = 5522318008730 := by decide
theorem cert_e1124271497626 : check e1124271497626 [[]] .width = true := by decide
def e1124271501510 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124271501510 : Closed e1124271501510 ∧ code e1124271501510 = 5522318012614 := by decide
theorem cert_e1124271501510 : check e1124271501510 [[]] .width = true := by decide
def e1124271535642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124271535642 : Closed e1124271535642 ∧ code e1124271535642 = 5522318046746 := by decide
theorem cert_e1124271535642 : check e1124271535642 [[]] .width = true := by decide
def e1124271558170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124271558170 : Closed e1124271558170 ∧ code e1124271558170 = 5522318069274 := by decide
theorem cert_e1124271558170 : check e1124271558170 [[]] .width = true := by decide
def e1124271562778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124271562778 : Closed e1124271562778 ∧ code e1124271562778 = 5522318073882 := by decide
theorem cert_e1124271562778 : check e1124271562778 [[]] .width = true := by decide
def e1124271562870 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124271562870 : Closed e1124271562870 ∧ code e1124271562870 = 5522318073974 := by decide
theorem cert_e1124271562870 : check e1124271562870 [[]] .width = true := by decide
def e1124271563114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124271563114 : Closed e1124271563114 ∧ code e1124271563114 = 5522318074218 := by decide
theorem cert_e1124271563114 : check e1124271563114 [[]] .width = true := by decide
def e1124271563162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124271563162 : Closed e1124271563162 ∧ code e1124271563162 = 5522318074266 := by decide
theorem cert_e1124271563162 : check e1124271563162 [[]] .width = true := by decide
def e1124271567046 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124271567046 : Closed e1124271567046 ∧ code e1124271567046 = 5522318078150 := by decide
theorem cert_e1124271567046 : check e1124271567046 [[]] .width = true := by decide
def e1124325879322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325879322 : Closed e1124325879322 ∧ code e1124325879322 = 5522372390426 := by decide
theorem cert_e1124325879322 : check e1124325879322 [[]] .width = true := by decide
def e1124325881370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325881370 : Closed e1124325881370 ∧ code e1124325881370 = 5522372392474 := by decide
theorem cert_e1124325881370 : check e1124325881370 [[]] .width = true := by decide
end Blc.Floor42
