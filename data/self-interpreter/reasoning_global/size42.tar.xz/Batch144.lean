import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182749558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211182749558 : Closed e1211182749558 ∧ code e1211182749558 = 5609229260662 := by decide
theorem cert_e1211182749558 : check e1211182749558 [[],[]] .smaller = true := by decide
def e1211182749562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211182749562 : Closed e1211182749562 ∧ code e1211182749562 = 5609229260666 := by decide
theorem cert_e1211182749562 : check e1211182749562 [[],[]] .smaller = true := by decide
def e1211182749622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211182749622 : Closed e1211182749622 ∧ code e1211182749622 = 5609229260726 := by decide
theorem cert_e1211182749622 : check e1211182749622 [[],[]] .smaller = true := by decide
def e1211182749654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211182749654 : Closed e1211182749654 ∧ code e1211182749654 = 5609229260758 := by decide
theorem cert_e1211182749654 : check e1211182749654 [[],[]] .smaller = true := by decide
def e1211182749658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211182749658 : Closed e1211182749658 ∧ code e1211182749658 = 5609229260762 := by decide
theorem cert_e1211182749658 : check e1211182749658 [[],[]] .smaller = true := by decide
def e1211182750174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211182750174 : Closed e1211182750174 ∧ code e1211182750174 = 5609229261278 := by decide
theorem cert_e1211182750174 : check e1211182750174 [[],[]] .smaller = true := by decide
def e1211182750198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211182750198 : Closed e1211182750198 ∧ code e1211182750198 = 5609229261302 := by decide
theorem cert_e1211182750198 : check e1211182750198 [[],[]] .smaller = true := by decide
def e1211182750942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211182750942 : Closed e1211182750942 ∧ code e1211182750942 = 5609229262046 := by decide
theorem cert_e1211182750942 : check e1211182750942 [[],[]] .smaller = true := by decide
def e1211182750958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182750958 : Closed e1211182750958 ∧ code e1211182750958 = 5609229262062 := by decide
theorem cert_e1211182750958 : check e1211182750958 [[],[]] .smaller = true := by decide
def e1211182750966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182750966 : Closed e1211182750966 ∧ code e1211182750966 = 5609229262070 := by decide
theorem cert_e1211182750966 : check e1211182750966 [[],[]] .smaller = true := by decide
def e1211182750970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211182750970 : Closed e1211182750970 ∧ code e1211182750970 = 5609229262074 := by decide
theorem cert_e1211182750970 : check e1211182750970 [[],[]] .smaller = true := by decide
def e1211182751350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182751350 : Closed e1211182751350 ∧ code e1211182751350 = 5609229262454 := by decide
theorem cert_e1211182751350 : check e1211182751350 [[],[]] .smaller = true := by decide
def e1211182751542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182751542 : Closed e1211182751542 ∧ code e1211182751542 = 5609229262646 := by decide
theorem cert_e1211182751542 : check e1211182751542 [[],[]] .smaller = true := by decide
def e1211182751546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182751546 : Closed e1211182751546 ∧ code e1211182751546 = 5609229262650 := by decide
theorem cert_e1211182751546 : check e1211182751546 [[],[]] .smaller = true := by decide
def e1211182765750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211182765750 : Closed e1211182765750 ∧ code e1211182765750 = 5609229276854 := by decide
theorem cert_e1211182765750 : check e1211182765750 [[],[]] .smaller = true := by decide
def e1211182765782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182765782 : Closed e1211182765782 ∧ code e1211182765782 = 5609229276886 := by decide
theorem cert_e1211182765782 : check e1211182765782 [[],[]] .smaller = true := by decide
def e1211182765786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182765786 : Closed e1211182765786 ∧ code e1211182765786 = 5609229276890 := by decide
theorem cert_e1211182765786 : check e1211182765786 [[],[]] .smaller = true := by decide
def e1211182765910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182765910 : Closed e1211182765910 ∧ code e1211182765910 = 5609229277014 := by decide
theorem cert_e1211182765910 : check e1211182765910 [[],[]] .smaller = true := by decide
def e1211182765914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182765914 : Closed e1211182765914 ∧ code e1211182765914 = 5609229277018 := by decide
theorem cert_e1211182765914 : check e1211182765914 [[],[]] .smaller = true := by decide
def e1211182765930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182765930 : Closed e1211182765930 ∧ code e1211182765930 = 5609229277034 := by decide
theorem cert_e1211182765930 : check e1211182765930 [[],[]] .smaller = true := by decide
def e1211182766302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211182766302 : Closed e1211182766302 ∧ code e1211182766302 = 5609229277406 := by decide
theorem cert_e1211182766302 : check e1211182766302 [[],[]] .smaller = true := by decide
def e1211182766318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211182766318 : Closed e1211182766318 ∧ code e1211182766318 = 5609229277422 := by decide
theorem cert_e1211182766318 : check e1211182766318 [[],[]] .smaller = true := by decide
def e1211182766326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211182766326 : Closed e1211182766326 ∧ code e1211182766326 = 5609229277430 := by decide
theorem cert_e1211182766326 : check e1211182766326 [[],[]] .smaller = true := by decide
def e1211182766330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211182766330 : Closed e1211182766330 ∧ code e1211182766330 = 5609229277434 := by decide
theorem cert_e1211182766330 : check e1211182766330 [[],[]] .smaller = true := by decide
def e1211182766518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211182766518 : Closed e1211182766518 ∧ code e1211182766518 = 5609229277622 := by decide
theorem cert_e1211182766518 : check e1211182766518 [[],[]] .smaller = true := by decide
def e1211182766550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211182766550 : Closed e1211182766550 ∧ code e1211182766550 = 5609229277654 := by decide
theorem cert_e1211182766550 : check e1211182766550 [[],[]] .smaller = true := by decide
def e1211182766554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211182766554 : Closed e1211182766554 ∧ code e1211182766554 = 5609229277658 := by decide
theorem cert_e1211182766554 : check e1211182766554 [[],[]] .smaller = true := by decide
def e1211182766654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211182766654 : Closed e1211182766654 ∧ code e1211182766654 = 5609229277758 := by decide
theorem cert_e1211182766654 : check e1211182766654 [[],[]] .smaller = true := by decide
def e1211182766710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182766710 : Closed e1211182766710 ∧ code e1211182766710 = 5609229277814 := by decide
theorem cert_e1211182766710 : check e1211182766710 [[],[]] .smaller = true := by decide
def e1211182766878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211182766878 : Closed e1211182766878 ∧ code e1211182766878 = 5609229277982 := by decide
theorem cert_e1211182766878 : check e1211182766878 [[],[]] .smaller = true := by decide
def e1211182766902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182766902 : Closed e1211182766902 ∧ code e1211182766902 = 5609229278006 := by decide
theorem cert_e1211182766902 : check e1211182766902 [[],[]] .smaller = true := by decide
def e1211182766906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182766906 : Closed e1211182766906 ∧ code e1211182766906 = 5609229278010 := by decide
theorem cert_e1211182766906 : check e1211182766906 [[],[]] .smaller = true := by decide
def e1211182766990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211182766990 : Closed e1211182766990 ∧ code e1211182766990 = 5609229278094 := by decide
theorem cert_e1211182766990 : check e1211182766990 [[],[]] .smaller = true := by decide
def e1211182767038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e1211182767038 : Closed e1211182767038 ∧ code e1211182767038 = 5609229278142 := by decide
theorem cert_e1211182767038 : check e1211182767038 [[],[]] .three = true := by decide
def e1211182767046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211182767046 : Closed e1211182767046 ∧ code e1211182767046 = 5609229278150 := by decide
theorem cert_e1211182767046 : check e1211182767046 [[],[]] .smaller = true := by decide
def e1211182767070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 3)))))))))
theorem wire_e1211182767070 : Closed e1211182767070 ∧ code e1211182767070 = 5609229278174 := by decide
theorem cert_e1211182767070 : check e1211182767070 [[],[]] .smaller = true := by decide
def e1211182767086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e1211182767086 : Closed e1211182767086 ∧ code e1211182767086 = 5609229278190 := by decide
theorem cert_e1211182767086 : check e1211182767086 [[],[]] .three = true := by decide
def e1211182767214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211182767214 : Closed e1211182767214 ∧ code e1211182767214 = 5609229278318 := by decide
theorem cert_e1211182767214 : check e1211182767214 [[],[]] .smaller = true := by decide
def e1211182767226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211182767226 : Closed e1211182767226 ∧ code e1211182767226 = 5609229278330 := by decide
theorem cert_e1211182767226 : check e1211182767226 [[],[]] .smaller = true := by decide
def e1211182767318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211182767318 : Closed e1211182767318 ∧ code e1211182767318 = 5609229278422 := by decide
theorem cert_e1211182767318 : check e1211182767318 [[],[]] .smaller = true := by decide
def e1211182767322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211182767322 : Closed e1211182767322 ∧ code e1211182767322 = 5609229278426 := by decide
theorem cert_e1211182767322 : check e1211182767322 [[],[]] .smaller = true := by decide
def e1211182767338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211182767338 : Closed e1211182767338 ∧ code e1211182767338 = 5609229278442 := by decide
theorem cert_e1211182767338 : check e1211182767338 [[],[]] .smaller = true := by decide
def e1211182767390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211182767390 : Closed e1211182767390 ∧ code e1211182767390 = 5609229278494 := by decide
theorem cert_e1211182767390 : check e1211182767390 [[],[]] .smaller = true := by decide
def e1211182767414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182767414 : Closed e1211182767414 ∧ code e1211182767414 = 5609229278518 := by decide
theorem cert_e1211182767414 : check e1211182767414 [[],[]] .smaller = true := by decide
def e1211182767418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182767418 : Closed e1211182767418 ∧ code e1211182767418 = 5609229278522 := by decide
theorem cert_e1211182767418 : check e1211182767418 [[],[]] .smaller = true := by decide
def e1211182767514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182767514 : Closed e1211182767514 ∧ code e1211182767514 = 5609229278618 := by decide
theorem cert_e1211182767514 : check e1211182767514 [[],[]] .smaller = true := by decide
def e1211182767550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e1211182767550 : Closed e1211182767550 ∧ code e1211182767550 = 5609229278654 := by decide
theorem cert_e1211182767550 : check e1211182767550 [[],[]] .three = true := by decide
def e1211182767558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211182767558 : Closed e1211182767558 ∧ code e1211182767558 = 5609229278662 := by decide
theorem cert_e1211182767558 : check e1211182767558 [[],[]] .smaller = true := by decide
def e1211182767582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211182767582 : Closed e1211182767582 ∧ code e1211182767582 = 5609229278686 := by decide
theorem cert_e1211182767582 : check e1211182767582 [[],[]] .smaller = true := by decide
def e1211182767598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211182767598 : Closed e1211182767598 ∧ code e1211182767598 = 5609229278702 := by decide
theorem cert_e1211182767598 : check e1211182767598 [[],[]] .smaller = true := by decide
def e1211182767606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e1211182767606 : Closed e1211182767606 ∧ code e1211182767606 = 5609229278710 := by decide
theorem cert_e1211182767606 : check e1211182767606 [[],[]] .three = true := by decide
def e1211182767670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211182767670 : Closed e1211182767670 ∧ code e1211182767670 = 5609229278774 := by decide
theorem cert_e1211182767670 : check e1211182767670 [[],[]] .smaller = true := by decide
def e1211182767674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211182767674 : Closed e1211182767674 ∧ code e1211182767674 = 5609229278778 := by decide
theorem cert_e1211182767674 : check e1211182767674 [[],[]] .smaller = true := by decide
def e1211182767758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211182767758 : Closed e1211182767758 ∧ code e1211182767758 = 5609229278862 := by decide
theorem cert_e1211182767758 : check e1211182767758 [[],[]] .smaller = true := by decide
def e1211182767806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e1211182767806 : Closed e1211182767806 ∧ code e1211182767806 = 5609229278910 := by decide
theorem cert_e1211182767806 : check e1211182767806 [[],[]] .three = true := by decide
def e1211182767814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211182767814 : Closed e1211182767814 ∧ code e1211182767814 = 5609229278918 := by decide
theorem cert_e1211182767814 : check e1211182767814 [[],[]] .smaller = true := by decide
def e1211182767838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211182767838 : Closed e1211182767838 ∧ code e1211182767838 = 5609229278942 := by decide
theorem cert_e1211182767838 : check e1211182767838 [[],[]] .smaller = true := by decide
def e1211182767862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211182767862 : Closed e1211182767862 ∧ code e1211182767862 = 5609229278966 := by decide
theorem cert_e1211182767862 : check e1211182767862 [[],[]] .smaller = true := by decide
def e1211182767866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e1211182767866 : Closed e1211182767866 ∧ code e1211182767866 = 5609229278970 := by decide
theorem cert_e1211182767866 : check e1211182767866 [[],[]] .three = true := by decide
def e1211182767898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211182767898 : Closed e1211182767898 ∧ code e1211182767898 = 5609229279002 := by decide
theorem cert_e1211182767898 : check e1211182767898 [[],[]] .smaller = true := by decide
def e1211182767942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211182767942 : Closed e1211182767942 ∧ code e1211182767942 = 5609229279046 := by decide
theorem cert_e1211182767942 : check e1211182767942 [[],[]] .smaller = true := by decide
def e1211182767966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 3)))))))))
theorem wire_e1211182767966 : Closed e1211182767966 ∧ code e1211182767966 = 5609229279070 := by decide
theorem cert_e1211182767966 : check e1211182767966 [[],[]] .smaller = true := by decide
def e1211182767982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211182767982 : Closed e1211182767982 ∧ code e1211182767982 = 5609229279086 := by decide
theorem cert_e1211182767982 : check e1211182767982 [[],[]] .smaller = true := by decide
def e1211182767990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211182767990 : Closed e1211182767990 ∧ code e1211182767990 = 5609229279094 := by decide
theorem cert_e1211182767990 : check e1211182767990 [[],[]] .smaller = true := by decide
def e1211182767994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.var 0)))))))))
theorem wire_e1211182767994 : Closed e1211182767994 ∧ code e1211182767994 = 5609229279098 := by decide
theorem cert_e1211182767994 : check e1211182767994 [[],[]] .smaller = true := by decide
def e1211182768046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e1211182768046 : Closed e1211182768046 ∧ code e1211182768046 = 5609229279150 := by decide
theorem cert_e1211182768046 : check e1211182768046 [[],[]] .three = true := by decide
def e1211182768054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e1211182768054 : Closed e1211182768054 ∧ code e1211182768054 = 5609229279158 := by decide
theorem cert_e1211182768054 : check e1211182768054 [[],[]] .three = true := by decide
def e1211182768058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e1211182768058 : Closed e1211182768058 ∧ code e1211182768058 = 5609229279162 := by decide
theorem cert_e1211182768058 : check e1211182768058 [[],[]] .three = true := by decide
def e1211182768622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e1211182768622 : Closed e1211182768622 ∧ code e1211182768622 = 5609229279726 := by decide
theorem cert_e1211182768622 : check e1211182768622 [[],[]] .smaller = true := by decide
def e1211182769590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211182769590 : Closed e1211182769590 ∧ code e1211182769590 = 5609229280694 := by decide
theorem cert_e1211182769590 : check e1211182769590 [[],[]] .smaller = true := by decide
def e1211182769622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211182769622 : Closed e1211182769622 ∧ code e1211182769622 = 5609229280726 := by decide
theorem cert_e1211182769622 : check e1211182769622 [[],[]] .smaller = true := by decide
def e1211182769626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211182769626 : Closed e1211182769626 ∧ code e1211182769626 = 5609229280730 := by decide
theorem cert_e1211182769626 : check e1211182769626 [[],[]] .smaller = true := by decide
def e1211182769726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211182769726 : Closed e1211182769726 ∧ code e1211182769726 = 5609229280830 := by decide
theorem cert_e1211182769726 : check e1211182769726 [[],[]] .smaller = true := by decide
def e1211182769782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182769782 : Closed e1211182769782 ∧ code e1211182769782 = 5609229280886 := by decide
theorem cert_e1211182769782 : check e1211182769782 [[],[]] .smaller = true := by decide
def e1211182769950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211182769950 : Closed e1211182769950 ∧ code e1211182769950 = 5609229281054 := by decide
theorem cert_e1211182769950 : check e1211182769950 [[],[]] .smaller = true := by decide
def e1211182769974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182769974 : Closed e1211182769974 ∧ code e1211182769974 = 5609229281078 := by decide
theorem cert_e1211182769974 : check e1211182769974 [[],[]] .smaller = true := by decide
def e1211182769978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182769978 : Closed e1211182769978 ∧ code e1211182769978 = 5609229281082 := by decide
theorem cert_e1211182769978 : check e1211182769978 [[],[]] .smaller = true := by decide
def e1211182770062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211182770062 : Closed e1211182770062 ∧ code e1211182770062 = 5609229281166 := by decide
theorem cert_e1211182770062 : check e1211182770062 [[],[]] .smaller = true := by decide
def e1211182770110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211182770110 : Closed e1211182770110 ∧ code e1211182770110 = 5609229281214 := by decide
theorem cert_e1211182770110 : check e1211182770110 [[],[]] .three = true := by decide
def e1211182770118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211182770118 : Closed e1211182770118 ∧ code e1211182770118 = 5609229281222 := by decide
theorem cert_e1211182770118 : check e1211182770118 [[],[]] .smaller = true := by decide
def e1211182770142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 3))))))))))
theorem wire_e1211182770142 : Closed e1211182770142 ∧ code e1211182770142 = 5609229281246 := by decide
theorem cert_e1211182770142 : check e1211182770142 [[],[]] .smaller = true := by decide
def e1211182770158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211182770158 : Closed e1211182770158 ∧ code e1211182770158 = 5609229281262 := by decide
theorem cert_e1211182770158 : check e1211182770158 [[],[]] .three = true := by decide
def e1211182772462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182772462 : Closed e1211182772462 ∧ code e1211182772462 = 5609229283566 := by decide
theorem cert_e1211182772462 : check e1211182772462 [[],[]] .smaller = true := by decide
def e1211182772470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182772470 : Closed e1211182772470 ∧ code e1211182772470 = 5609229283574 := by decide
theorem cert_e1211182772470 : check e1211182772470 [[],[]] .smaller = true := by decide
def e1211182772950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211182772950 : Closed e1211182772950 ∧ code e1211182772950 = 5609229284054 := by decide
theorem cert_e1211182772950 : check e1211182772950 [[],[]] .smaller = true := by decide
def e1211182772954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211182772954 : Closed e1211182772954 ∧ code e1211182772954 = 5609229284058 := by decide
theorem cert_e1211182772954 : check e1211182772954 [[],[]] .smaller = true := by decide
def e1211182772970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211182772970 : Closed e1211182772970 ∧ code e1211182772970 = 5609229284074 := by decide
theorem cert_e1211182772970 : check e1211182772970 [[],[]] .smaller = true := by decide
def e1211182773022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211182773022 : Closed e1211182773022 ∧ code e1211182773022 = 5609229284126 := by decide
theorem cert_e1211182773022 : check e1211182773022 [[],[]] .smaller = true := by decide
def e1211182773046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182773046 : Closed e1211182773046 ∧ code e1211182773046 = 5609229284150 := by decide
theorem cert_e1211182773046 : check e1211182773046 [[],[]] .smaller = true := by decide
def e1211182773050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182773050 : Closed e1211182773050 ∧ code e1211182773050 = 5609229284154 := by decide
theorem cert_e1211182773050 : check e1211182773050 [[],[]] .smaller = true := by decide
def e1211182773146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182773146 : Closed e1211182773146 ∧ code e1211182773146 = 5609229284250 := by decide
theorem cert_e1211182773146 : check e1211182773146 [[],[]] .smaller = true := by decide
def e1211182773182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211182773182 : Closed e1211182773182 ∧ code e1211182773182 = 5609229284286 := by decide
theorem cert_e1211182773182 : check e1211182773182 [[],[]] .three = true := by decide
def e1211182773190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211182773190 : Closed e1211182773190 ∧ code e1211182773190 = 5609229284294 := by decide
theorem cert_e1211182773190 : check e1211182773190 [[],[]] .smaller = true := by decide
def e1211182773214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182773214 : Closed e1211182773214 ∧ code e1211182773214 = 5609229284318 := by decide
theorem cert_e1211182773214 : check e1211182773214 [[],[]] .smaller = true := by decide
def e1211182773230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182773230 : Closed e1211182773230 ∧ code e1211182773230 = 5609229284334 := by decide
theorem cert_e1211182773230 : check e1211182773230 [[],[]] .smaller = true := by decide
def e1211182773238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211182773238 : Closed e1211182773238 ∧ code e1211182773238 = 5609229284342 := by decide
theorem cert_e1211182773238 : check e1211182773238 [[],[]] .three = true := by decide
def e1211182774670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211182774670 : Closed e1211182774670 ∧ code e1211182774670 = 5609229285774 := by decide
theorem cert_e1211182774670 : check e1211182774670 [[],[]] .smaller = true := by decide
def e1211182774718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211182774718 : Closed e1211182774718 ∧ code e1211182774718 = 5609229285822 := by decide
theorem cert_e1211182774718 : check e1211182774718 [[],[]] .three = true := by decide
def e1211182774726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211182774726 : Closed e1211182774726 ∧ code e1211182774726 = 5609229285830 := by decide
theorem cert_e1211182774726 : check e1211182774726 [[],[]] .smaller = true := by decide
def e1211182774750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211182774750 : Closed e1211182774750 ∧ code e1211182774750 = 5609229285854 := by decide
theorem cert_e1211182774750 : check e1211182774750 [[],[]] .smaller = true := by decide
def e1211182774774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211182774774 : Closed e1211182774774 ∧ code e1211182774774 = 5609229285878 := by decide
theorem cert_e1211182774774 : check e1211182774774 [[],[]] .smaller = true := by decide
def e1211182774778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211182774778 : Closed e1211182774778 ∧ code e1211182774778 = 5609229285882 := by decide
theorem cert_e1211182774778 : check e1211182774778 [[],[]] .three = true := by decide
def e1211182775494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211182775494 : Closed e1211182775494 ∧ code e1211182775494 = 5609229286598 := by decide
theorem cert_e1211182775494 : check e1211182775494 [[],[]] .smaller = true := by decide
def e1211182775518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182775518 : Closed e1211182775518 ∧ code e1211182775518 = 5609229286622 := by decide
theorem cert_e1211182775518 : check e1211182775518 [[],[]] .smaller = true := by decide
def e1211182775534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182775534 : Closed e1211182775534 ∧ code e1211182775534 = 5609229286638 := by decide
theorem cert_e1211182775534 : check e1211182775534 [[],[]] .smaller = true := by decide
def e1211182775542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182775542 : Closed e1211182775542 ∧ code e1211182775542 = 5609229286646 := by decide
theorem cert_e1211182775542 : check e1211182775542 [[],[]] .smaller = true := by decide
def e1211182775546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182775546 : Closed e1211182775546 ∧ code e1211182775546 = 5609229286650 := by decide
theorem cert_e1211182775546 : check e1211182775546 [[],[]] .smaller = true := by decide
def e1211182775918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182775918 : Closed e1211182775918 ∧ code e1211182775918 = 5609229287022 := by decide
theorem cert_e1211182775918 : check e1211182775918 [[],[]] .three = true := by decide
def e1211182775926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182775926 : Closed e1211182775926 ∧ code e1211182775926 = 5609229287030 := by decide
theorem cert_e1211182775926 : check e1211182775926 [[],[]] .three = true := by decide
def e1211182775930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182775930 : Closed e1211182775930 ∧ code e1211182775930 = 5609229287034 := by decide
theorem cert_e1211182775930 : check e1211182775930 [[],[]] .three = true := by decide
def e1211182820182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182820182 : Closed e1211182820182 ∧ code e1211182820182 = 5609229331286 := by decide
theorem cert_e1211182820182 : check e1211182820182 [[],[]] .smaller = true := by decide
def e1211182820186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182820186 : Closed e1211182820186 ∧ code e1211182820186 = 5609229331290 := by decide
theorem cert_e1211182820186 : check e1211182820186 [[],[]] .smaller = true := by decide
def e1211182820202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182820202 : Closed e1211182820202 ∧ code e1211182820202 = 5609229331306 := by decide
theorem cert_e1211182820202 : check e1211182820202 [[],[]] .smaller = true := by decide
def e1211182820266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182820266 : Closed e1211182820266 ∧ code e1211182820266 = 5609229331370 := by decide
theorem cert_e1211182820266 : check e1211182820266 [[],[]] .smaller = true := by decide
def e1211182820462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211182820462 : Closed e1211182820462 ∧ code e1211182820462 = 5609229331566 := by decide
theorem cert_e1211182820462 : check e1211182820462 [[],[]] .smaller = true := by decide
def e1211182820470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e1211182820470 : Closed e1211182820470 ∧ code e1211182820470 = 5609229331574 := by decide
theorem cert_e1211182820470 : check e1211182820470 [[],[]] .smaller = true := by decide
def e1211182820474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211182820474 : Closed e1211182820474 ∧ code e1211182820474 = 5609229331578 := by decide
theorem cert_e1211182820474 : check e1211182820474 [[],[]] .smaller = true := by decide
def e1211182820566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211182820566 : Closed e1211182820566 ∧ code e1211182820566 = 5609229331670 := by decide
theorem cert_e1211182820566 : check e1211182820566 [[],[]] .smaller = true := by decide
def e1211182820570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211182820570 : Closed e1211182820570 ∧ code e1211182820570 = 5609229331674 := by decide
theorem cert_e1211182820570 : check e1211182820570 [[],[]] .smaller = true := by decide
def e1211182820586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211182820586 : Closed e1211182820586 ∧ code e1211182820586 = 5609229331690 := by decide
theorem cert_e1211182820586 : check e1211182820586 [[],[]] .smaller = true := by decide
def e1211182820638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211182820638 : Closed e1211182820638 ∧ code e1211182820638 = 5609229331742 := by decide
theorem cert_e1211182820638 : check e1211182820638 [[],[]] .smaller = true := by decide
def e1211182820662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182820662 : Closed e1211182820662 ∧ code e1211182820662 = 5609229331766 := by decide
theorem cert_e1211182820662 : check e1211182820662 [[],[]] .smaller = true := by decide
def e1211182820666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182820666 : Closed e1211182820666 ∧ code e1211182820666 = 5609229331770 := by decide
theorem cert_e1211182820666 : check e1211182820666 [[],[]] .smaller = true := by decide
def e1211182820750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e1211182820750 : Closed e1211182820750 ∧ code e1211182820750 = 5609229331854 := by decide
theorem cert_e1211182820750 : check e1211182820750 [[],[]] .smaller = true := by decide
def e1211182820762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182820762 : Closed e1211182820762 ∧ code e1211182820762 = 5609229331866 := by decide
theorem cert_e1211182820762 : check e1211182820762 [[],[]] .smaller = true := by decide
def e1211182820806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211182820806 : Closed e1211182820806 ∧ code e1211182820806 = 5609229331910 := by decide
theorem cert_e1211182820806 : check e1211182820806 [[],[]] .smaller = true := by decide
def e1211182820830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211182820830 : Closed e1211182820830 ∧ code e1211182820830 = 5609229331934 := by decide
theorem cert_e1211182820830 : check e1211182820830 [[],[]] .smaller = true := by decide
def e1211182820846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211182820846 : Closed e1211182820846 ∧ code e1211182820846 = 5609229331950 := by decide
theorem cert_e1211182820846 : check e1211182820846 [[],[]] .smaller = true := by decide
def e1211182820918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211182820918 : Closed e1211182820918 ∧ code e1211182820918 = 5609229332022 := by decide
theorem cert_e1211182820918 : check e1211182820918 [[],[]] .smaller = true := by decide
def e1211182820922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211182820922 : Closed e1211182820922 ∧ code e1211182820922 = 5609229332026 := by decide
theorem cert_e1211182820922 : check e1211182820922 [[],[]] .smaller = true := by decide
def e1211182820970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e1211182820970 : Closed e1211182820970 ∧ code e1211182820970 = 5609229332074 := by decide
theorem cert_e1211182820970 : check e1211182820970 [[],[]] .smaller = true := by decide
def e1211182821006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211182821006 : Closed e1211182821006 ∧ code e1211182821006 = 5609229332110 := by decide
theorem cert_e1211182821006 : check e1211182821006 [[],[]] .smaller = true := by decide
def e1211182821018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182821018 : Closed e1211182821018 ∧ code e1211182821018 = 5609229332122 := by decide
theorem cert_e1211182821018 : check e1211182821018 [[],[]] .smaller = true := by decide
def e1211182821062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211182821062 : Closed e1211182821062 ∧ code e1211182821062 = 5609229332166 := by decide
theorem cert_e1211182821062 : check e1211182821062 [[],[]] .smaller = true := by decide
def e1211182821102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211182821102 : Closed e1211182821102 ∧ code e1211182821102 = 5609229332206 := by decide
theorem cert_e1211182821102 : check e1211182821102 [[],[]] .smaller = true := by decide
def e1211182821146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211182821146 : Closed e1211182821146 ∧ code e1211182821146 = 5609229332250 := by decide
theorem cert_e1211182821146 : check e1211182821146 [[],[]] .smaller = true := by decide
def e1211182821190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211182821190 : Closed e1211182821190 ∧ code e1211182821190 = 5609229332294 := by decide
theorem cert_e1211182821190 : check e1211182821190 [[],[]] .smaller = true := by decide
def e1211182821214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211182821214 : Closed e1211182821214 ∧ code e1211182821214 = 5609229332318 := by decide
theorem cert_e1211182821214 : check e1211182821214 [[],[]] .smaller = true := by decide
def e1211182821230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211182821230 : Closed e1211182821230 ∧ code e1211182821230 = 5609229332334 := by decide
theorem cert_e1211182821230 : check e1211182821230 [[],[]] .smaller = true := by decide
def e1211182821238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211182821238 : Closed e1211182821238 ∧ code e1211182821238 = 5609229332342 := by decide
theorem cert_e1211182821238 : check e1211182821238 [[],[]] .smaller = true := by decide
def e1211182821242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211182821242 : Closed e1211182821242 ∧ code e1211182821242 = 5609229332346 := by decide
theorem cert_e1211182821242 : check e1211182821242 [[],[]] .smaller = true := by decide
def e1211182821294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211182821294 : Closed e1211182821294 ∧ code e1211182821294 = 5609229332398 := by decide
theorem cert_e1211182821294 : check e1211182821294 [[],[]] .smaller = true := by decide
def e1211182821306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211182821306 : Closed e1211182821306 ∧ code e1211182821306 = 5609229332410 := by decide
theorem cert_e1211182821306 : check e1211182821306 [[],[]] .smaller = true := by decide
def e1211182821614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182821614 : Closed e1211182821614 ∧ code e1211182821614 = 5609229332718 := by decide
theorem cert_e1211182821614 : check e1211182821614 [[],[]] .smaller = true := by decide
def e1211182821622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182821622 : Closed e1211182821622 ∧ code e1211182821622 = 5609229332726 := by decide
theorem cert_e1211182821622 : check e1211182821622 [[],[]] .smaller = true := by decide
def e1211182822102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211182822102 : Closed e1211182822102 ∧ code e1211182822102 = 5609229333206 := by decide
theorem cert_e1211182822102 : check e1211182822102 [[],[]] .smaller = true := by decide
def e1211182822106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211182822106 : Closed e1211182822106 ∧ code e1211182822106 = 5609229333210 := by decide
theorem cert_e1211182822106 : check e1211182822106 [[],[]] .smaller = true := by decide
def e1211182822122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211182822122 : Closed e1211182822122 ∧ code e1211182822122 = 5609229333226 := by decide
theorem cert_e1211182822122 : check e1211182822122 [[],[]] .smaller = true := by decide
def e1211182822174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211182822174 : Closed e1211182822174 ∧ code e1211182822174 = 5609229333278 := by decide
theorem cert_e1211182822174 : check e1211182822174 [[],[]] .smaller = true := by decide
def e1211182822198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182822198 : Closed e1211182822198 ∧ code e1211182822198 = 5609229333302 := by decide
theorem cert_e1211182822198 : check e1211182822198 [[],[]] .smaller = true := by decide
def e1211182822202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182822202 : Closed e1211182822202 ∧ code e1211182822202 = 5609229333306 := by decide
theorem cert_e1211182822202 : check e1211182822202 [[],[]] .smaller = true := by decide
def e1211182822286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e1211182822286 : Closed e1211182822286 ∧ code e1211182822286 = 5609229333390 := by decide
theorem cert_e1211182822286 : check e1211182822286 [[],[]] .smaller = true := by decide
def e1211182822298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182822298 : Closed e1211182822298 ∧ code e1211182822298 = 5609229333402 := by decide
theorem cert_e1211182822298 : check e1211182822298 [[],[]] .smaller = true := by decide
def e1211182822342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211182822342 : Closed e1211182822342 ∧ code e1211182822342 = 5609229333446 := by decide
theorem cert_e1211182822342 : check e1211182822342 [[],[]] .smaller = true := by decide
def e1211182822366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182822366 : Closed e1211182822366 ∧ code e1211182822366 = 5609229333470 := by decide
theorem cert_e1211182822366 : check e1211182822366 [[],[]] .smaller = true := by decide
def e1211182822382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182822382 : Closed e1211182822382 ∧ code e1211182822382 = 5609229333486 := by decide
theorem cert_e1211182822382 : check e1211182822382 [[],[]] .smaller = true := by decide
def e1211182823542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182823542 : Closed e1211182823542 ∧ code e1211182823542 = 5609229334646 := by decide
theorem cert_e1211182823542 : check e1211182823542 [[],[]] .smaller = true := by decide
def e1211182823786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e1211182823786 : Closed e1211182823786 ∧ code e1211182823786 = 5609229334890 := by decide
theorem cert_e1211182823786 : check e1211182823786 [[],[]] .smaller = true := by decide
def e1211182823822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211182823822 : Closed e1211182823822 ∧ code e1211182823822 = 5609229334926 := by decide
theorem cert_e1211182823822 : check e1211182823822 [[],[]] .smaller = true := by decide
def e1211182823834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182823834 : Closed e1211182823834 ∧ code e1211182823834 = 5609229334938 := by decide
theorem cert_e1211182823834 : check e1211182823834 [[],[]] .smaller = true := by decide
end Blc.Floor42
