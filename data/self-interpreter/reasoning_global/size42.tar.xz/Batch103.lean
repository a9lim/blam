import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812907246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205812907246 : Closed e1205812907246 ∧ code e1205812907246 = 5603859418350 := by decide
theorem cert_e1205812907246 : check e1205812907246 [[],[]] .smaller = true := by decide
def e1205812907254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205812907254 : Closed e1205812907254 ∧ code e1205812907254 = 5603859418358 := by decide
theorem cert_e1205812907254 : check e1205812907254 [[],[]] .smaller = true := by decide
def e1205812907582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1205812907582 : Closed e1205812907582 ∧ code e1205812907582 = 5603859418686 := by decide
theorem cert_e1205812907582 : check e1205812907582 [[],[]] .three = true := by decide
def e1205812907630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812907630 : Closed e1205812907630 ∧ code e1205812907630 = 5603859418734 := by decide
theorem cert_e1205812907630 : check e1205812907630 [[],[]] .smaller = true := by decide
def e1205812907642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812907642 : Closed e1205812907642 ∧ code e1205812907642 = 5603859418746 := by decide
theorem cert_e1205812907642 : check e1205812907642 [[],[]] .smaller = true := by decide
def e1205812907830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812907830 : Closed e1205812907830 ∧ code e1205812907830 = 5603859418934 := by decide
theorem cert_e1205812907830 : check e1205812907830 [[],[]] .smaller = true := by decide
def e1205812907834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812907834 : Closed e1205812907834 ∧ code e1205812907834 = 5603859418938 := by decide
theorem cert_e1205812907834 : check e1205812907834 [[],[]] .smaller = true := by decide
def e1205812907918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1205812907918 : Closed e1205812907918 ∧ code e1205812907918 = 5603859419022 := by decide
theorem cert_e1205812907918 : check e1205812907918 [[],[]] .three = true := by decide
def e1205812912606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1205812912606 : Closed e1205812912606 ∧ code e1205812912606 = 5603859423710 := by decide
theorem cert_e1205812912606 : check e1205812912606 [[],[]] .smaller = true := by decide
def e1205812912630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1205812912630 : Closed e1205812912630 ∧ code e1205812912630 = 5603859423734 := by decide
theorem cert_e1205812912630 : check e1205812912630 [[],[]] .smaller = true := by decide
def e1205812913582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205812913582 : Closed e1205812913582 ∧ code e1205812913582 = 5603859424686 := by decide
theorem cert_e1205812913582 : check e1205812913582 [[],[]] .smaller = true := by decide
def e1205812913594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205812913594 : Closed e1205812913594 ∧ code e1205812913594 = 5603859424698 := by decide
theorem cert_e1205812913594 : check e1205812913594 [[],[]] .smaller = true := by decide
def e1205812913642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205812913642 : Closed e1205812913642 ∧ code e1205812913642 = 5603859424746 := by decide
theorem cert_e1205812913642 : check e1205812913642 [[],[]] .smaller = true := by decide
def e1205812913726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1205812913726 : Closed e1205812913726 ∧ code e1205812913726 = 5603859424830 := by decide
theorem cert_e1205812913726 : check e1205812913726 [[],[]] .three = true := by decide
def e1205812913774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812913774 : Closed e1205812913774 ∧ code e1205812913774 = 5603859424878 := by decide
theorem cert_e1205812913774 : check e1205812913774 [[],[]] .smaller = true := by decide
def e1205812913786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812913786 : Closed e1205812913786 ∧ code e1205812913786 = 5603859424890 := by decide
theorem cert_e1205812913786 : check e1205812913786 [[],[]] .smaller = true := by decide
def e1205812913950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1205812913950 : Closed e1205812913950 ∧ code e1205812913950 = 5603859425054 := by decide
theorem cert_e1205812913950 : check e1205812913950 [[],[]] .smaller = true := by decide
def e1205812914062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1205812914062 : Closed e1205812914062 ∧ code e1205812914062 = 5603859425166 := by decide
theorem cert_e1205812914062 : check e1205812914062 [[],[]] .smaller = true := by decide
def e1205812914074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812914074 : Closed e1205812914074 ∧ code e1205812914074 = 5603859425178 := by decide
theorem cert_e1205812914074 : check e1205812914074 [[],[]] .smaller = true := by decide
def e1205812914118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1205812914118 : Closed e1205812914118 ∧ code e1205812914118 = 5603859425222 := by decide
theorem cert_e1205812914118 : check e1205812914118 [[],[]] .three = true := by decide
def e1205812914142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e1205812914142 : Closed e1205812914142 ∧ code e1205812914142 = 5603859425246 := by decide
theorem cert_e1205812914142 : check e1205812914142 [[],[]] .three = true := by decide
def e1205812916462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1205812916462 : Closed e1205812916462 ∧ code e1205812916462 = 5603859427566 := by decide
theorem cert_e1205812916462 : check e1205812916462 [[],[]] .smaller = true := by decide
def e1205812916470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1205812916470 : Closed e1205812916470 ∧ code e1205812916470 = 5603859427574 := by decide
theorem cert_e1205812916470 : check e1205812916470 [[],[]] .smaller = true := by decide
def e1205812916950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205812916950 : Closed e1205812916950 ∧ code e1205812916950 = 5603859428054 := by decide
theorem cert_e1205812916950 : check e1205812916950 [[],[]] .smaller = true := by decide
def e1205812916954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205812916954 : Closed e1205812916954 ∧ code e1205812916954 = 5603859428058 := by decide
theorem cert_e1205812916954 : check e1205812916954 [[],[]] .smaller = true := by decide
def e1205812916970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205812916970 : Closed e1205812916970 ∧ code e1205812916970 = 5603859428074 := by decide
theorem cert_e1205812916970 : check e1205812916970 [[],[]] .smaller = true := by decide
def e1205812917046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812917046 : Closed e1205812917046 ∧ code e1205812917046 = 5603859428150 := by decide
theorem cert_e1205812917046 : check e1205812917046 [[],[]] .smaller = true := by decide
def e1205812917050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812917050 : Closed e1205812917050 ∧ code e1205812917050 = 5603859428154 := by decide
theorem cert_e1205812917050 : check e1205812917050 [[],[]] .smaller = true := by decide
def e1205812917134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1205812917134 : Closed e1205812917134 ∧ code e1205812917134 = 5603859428238 := by decide
theorem cert_e1205812917134 : check e1205812917134 [[],[]] .smaller = true := by decide
def e1205812917146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812917146 : Closed e1205812917146 ∧ code e1205812917146 = 5603859428250 := by decide
theorem cert_e1205812917146 : check e1205812917146 [[],[]] .smaller = true := by decide
def e1205812917214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205812917214 : Closed e1205812917214 ∧ code e1205812917214 = 5603859428318 := by decide
theorem cert_e1205812917214 : check e1205812917214 [[],[]] .three = true := by decide
def e1205812917230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205812917230 : Closed e1205812917230 ∧ code e1205812917230 = 5603859428334 := by decide
theorem cert_e1205812917230 : check e1205812917230 [[],[]] .three = true := by decide
def e1205812918670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205812918670 : Closed e1205812918670 ∧ code e1205812918670 = 5603859429774 := by decide
theorem cert_e1205812918670 : check e1205812918670 [[],[]] .three = true := by decide
def e1205812918726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205812918726 : Closed e1205812918726 ∧ code e1205812918726 = 5603859429830 := by decide
theorem cert_e1205812918726 : check e1205812918726 [[],[]] .three = true := by decide
def e1205812918750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205812918750 : Closed e1205812918750 ∧ code e1205812918750 = 5603859429854 := by decide
theorem cert_e1205812918750 : check e1205812918750 [[],[]] .three = true := by decide
def e1205812918766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205812918766 : Closed e1205812918766 ∧ code e1205812918766 = 5603859429870 := by decide
theorem cert_e1205812918766 : check e1205812918766 [[],[]] .three = true := by decide
def e1205812918774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205812918774 : Closed e1205812918774 ∧ code e1205812918774 = 5603859429878 := by decide
theorem cert_e1205812918774 : check e1205812918774 [[],[]] .three = true := by decide
def e1205813008046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205813008046 : Closed e1205813008046 ∧ code e1205813008046 = 5603859519150 := by decide
theorem cert_e1205813008046 : check e1205813008046 [[],[]] .smaller = true := by decide
def e1205813008058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205813008058 : Closed e1205813008058 ∧ code e1205813008058 = 5603859519162 := by decide
theorem cert_e1205813008058 : check e1205813008058 [[],[]] .smaller = true := by decide
def e1205813008106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205813008106 : Closed e1205813008106 ∧ code e1205813008106 = 5603859519210 := by decide
theorem cert_e1205813008106 : check e1205813008106 [[],[]] .smaller = true := by decide
def e1205813008298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1205813008298 : Closed e1205813008298 ∧ code e1205813008298 = 5603859519402 := by decide
theorem cert_e1205813008298 : check e1205813008298 [[],[]] .smaller = true := by decide
def e1205813008606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1205813008606 : Closed e1205813008606 ∧ code e1205813008606 = 5603859519710 := by decide
theorem cert_e1205813008606 : check e1205813008606 [[],[]] .three = true := by decide
def e1205813008622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1205813008622 : Closed e1205813008622 ∧ code e1205813008622 = 5603859519726 := by decide
theorem cert_e1205813008622 : check e1205813008622 [[],[]] .smaller = true := by decide
def e1205813008630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1205813008630 : Closed e1205813008630 ∧ code e1205813008630 = 5603859519734 := by decide
theorem cert_e1205813008630 : check e1205813008630 [[],[]] .smaller = true := by decide
def e1205813008634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1205813008634 : Closed e1205813008634 ∧ code e1205813008634 = 5603859519738 := by decide
theorem cert_e1205813008634 : check e1205813008634 [[],[]] .three = true := by decide
def e1205813008814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205813008814 : Closed e1205813008814 ∧ code e1205813008814 = 5603859519918 := by decide
theorem cert_e1205813008814 : check e1205813008814 [[],[]] .smaller = true := by decide
def e1205813008826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205813008826 : Closed e1205813008826 ∧ code e1205813008826 = 5603859519930 := by decide
theorem cert_e1205813008826 : check e1205813008826 [[],[]] .smaller = true := by decide
def e1205813008874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205813008874 : Closed e1205813008874 ∧ code e1205813008874 = 5603859519978 := by decide
theorem cert_e1205813008874 : check e1205813008874 [[],[]] .smaller = true := by decide
def e1205813008958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1205813008958 : Closed e1205813008958 ∧ code e1205813008958 = 5603859520062 := by decide
theorem cert_e1205813008958 : check e1205813008958 [[],[]] .three = true := by decide
def e1205813009006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205813009006 : Closed e1205813009006 ∧ code e1205813009006 = 5603859520110 := by decide
theorem cert_e1205813009006 : check e1205813009006 [[],[]] .smaller = true := by decide
def e1205813009018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205813009018 : Closed e1205813009018 ∧ code e1205813009018 = 5603859520122 := by decide
theorem cert_e1205813009018 : check e1205813009018 [[],[]] .smaller = true := by decide
def e1205813009182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1205813009182 : Closed e1205813009182 ∧ code e1205813009182 = 5603859520286 := by decide
theorem cert_e1205813009182 : check e1205813009182 [[],[]] .smaller = true := by decide
def e1205813009294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1205813009294 : Closed e1205813009294 ∧ code e1205813009294 = 5603859520398 := by decide
theorem cert_e1205813009294 : check e1205813009294 [[],[]] .smaller = true := by decide
def e1205813009306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205813009306 : Closed e1205813009306 ∧ code e1205813009306 = 5603859520410 := by decide
theorem cert_e1205813009306 : check e1205813009306 [[],[]] .smaller = true := by decide
def e1205813009350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1205813009350 : Closed e1205813009350 ∧ code e1205813009350 = 5603859520454 := by decide
theorem cert_e1205813009350 : check e1205813009350 [[],[]] .three = true := by decide
def e1205813009374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e1205813009374 : Closed e1205813009374 ∧ code e1205813009374 = 5603859520478 := by decide
theorem cert_e1205813009374 : check e1205813009374 [[],[]] .three = true := by decide
def e1205813009518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1205813009518 : Closed e1205813009518 ∧ code e1205813009518 = 5603859520622 := by decide
theorem cert_e1205813009518 : check e1205813009518 [[],[]] .smaller = true := by decide
def e1205813009530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1205813009530 : Closed e1205813009530 ∧ code e1205813009530 = 5603859520634 := by decide
theorem cert_e1205813009530 : check e1205813009530 [[],[]] .smaller = true := by decide
def e1205813009694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1205813009694 : Closed e1205813009694 ∧ code e1205813009694 = 5603859520798 := by decide
theorem cert_e1205813009694 : check e1205813009694 [[],[]] .smaller = true := by decide
def e1205813009862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1205813009862 : Closed e1205813009862 ∧ code e1205813009862 = 5603859520966 := by decide
theorem cert_e1205813009862 : check e1205813009862 [[],[]] .smaller = true := by decide
def e1205813009886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1205813009886 : Closed e1205813009886 ∧ code e1205813009886 = 5603859520990 := by decide
theorem cert_e1205813009886 : check e1205813009886 [[],[]] .three = true := by decide
def e1205813009902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1205813009902 : Closed e1205813009902 ∧ code e1205813009902 = 5603859521006 := by decide
theorem cert_e1205813009902 : check e1205813009902 [[],[]] .three = true := by decide
def e1205813009974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205813009974 : Closed e1205813009974 ∧ code e1205813009974 = 5603859521078 := by decide
theorem cert_e1205813009974 : check e1205813009974 [[],[]] .smaller = true := by decide
def e1205813009978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205813009978 : Closed e1205813009978 ∧ code e1205813009978 = 5603859521082 := by decide
theorem cert_e1205813009978 : check e1205813009978 [[],[]] .smaller = true := by decide
def e1205813010026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1205813010026 : Closed e1205813010026 ∧ code e1205813010026 = 5603859521130 := by decide
theorem cert_e1205813010026 : check e1205813010026 [[],[]] .smaller = true := by decide
def e1205813010062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205813010062 : Closed e1205813010062 ∧ code e1205813010062 = 5603859521166 := by decide
theorem cert_e1205813010062 : check e1205813010062 [[],[]] .smaller = true := by decide
def e1205813010074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205813010074 : Closed e1205813010074 ∧ code e1205813010074 = 5603859521178 := by decide
theorem cert_e1205813010074 : check e1205813010074 [[],[]] .smaller = true := by decide
def e1205813010118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205813010118 : Closed e1205813010118 ∧ code e1205813010118 = 5603859521222 := by decide
theorem cert_e1205813010118 : check e1205813010118 [[],[]] .smaller = true := by decide
def e1205813010142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1205813010142 : Closed e1205813010142 ∧ code e1205813010142 = 5603859521246 := by decide
theorem cert_e1205813010142 : check e1205813010142 [[],[]] .three = true := by decide
def e1205813010166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1205813010166 : Closed e1205813010166 ∧ code e1205813010166 = 5603859521270 := by decide
theorem cert_e1205813010166 : check e1205813010166 [[],[]] .three = true := by decide
def e1205813010202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1205813010202 : Closed e1205813010202 ∧ code e1205813010202 = 5603859521306 := by decide
theorem cert_e1205813010202 : check e1205813010202 [[],[]] .three = true := by decide
def e1205813010246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1205813010246 : Closed e1205813010246 ∧ code e1205813010246 = 5603859521350 := by decide
theorem cert_e1205813010246 : check e1205813010246 [[],[]] .three = true := by decide
def e1205813010270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e1205813010270 : Closed e1205813010270 ∧ code e1205813010270 = 5603859521374 := by decide
theorem cert_e1205813010270 : check e1205813010270 [[],[]] .three = true := by decide
def e1205813010286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1205813010286 : Closed e1205813010286 ∧ code e1205813010286 = 5603859521390 := by decide
theorem cert_e1205813010286 : check e1205813010286 [[],[]] .three = true := by decide
def e1205813010294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1205813010294 : Closed e1205813010294 ∧ code e1205813010294 = 5603859521398 := by decide
theorem cert_e1205813010294 : check e1205813010294 [[],[]] .three = true := by decide
def e1205813010298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e1205813010298 : Closed e1205813010298 ∧ code e1205813010298 = 5603859521402 := by decide
theorem cert_e1205813010298 : check e1205813010298 [[],[]] .three = true := by decide
def e1205813010910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1205813010910 : Closed e1205813010910 ∧ code e1205813010910 = 5603859522014 := by decide
theorem cert_e1205813010910 : check e1205813010910 [[],[]] .smaller = true := by decide
def e1205813010934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1205813010934 : Closed e1205813010934 ∧ code e1205813010934 = 5603859522038 := by decide
theorem cert_e1205813010934 : check e1205813010934 [[],[]] .smaller = true := by decide
def e1205813011886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205813011886 : Closed e1205813011886 ∧ code e1205813011886 = 5603859522990 := by decide
theorem cert_e1205813011886 : check e1205813011886 [[],[]] .smaller = true := by decide
def e1205813011898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205813011898 : Closed e1205813011898 ∧ code e1205813011898 = 5603859523002 := by decide
theorem cert_e1205813011898 : check e1205813011898 [[],[]] .smaller = true := by decide
def e1205813011946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205813011946 : Closed e1205813011946 ∧ code e1205813011946 = 5603859523050 := by decide
theorem cert_e1205813011946 : check e1205813011946 [[],[]] .smaller = true := by decide
def e1205813012030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1205813012030 : Closed e1205813012030 ∧ code e1205813012030 = 5603859523134 := by decide
theorem cert_e1205813012030 : check e1205813012030 [[],[]] .three = true := by decide
def e1205813012078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205813012078 : Closed e1205813012078 ∧ code e1205813012078 = 5603859523182 := by decide
theorem cert_e1205813012078 : check e1205813012078 [[],[]] .smaller = true := by decide
def e1205813012090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205813012090 : Closed e1205813012090 ∧ code e1205813012090 = 5603859523194 := by decide
theorem cert_e1205813012090 : check e1205813012090 [[],[]] .smaller = true := by decide
def e1205813012254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1205813012254 : Closed e1205813012254 ∧ code e1205813012254 = 5603859523358 := by decide
theorem cert_e1205813012254 : check e1205813012254 [[],[]] .smaller = true := by decide
def e1205813012366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1205813012366 : Closed e1205813012366 ∧ code e1205813012366 = 5603859523470 := by decide
theorem cert_e1205813012366 : check e1205813012366 [[],[]] .smaller = true := by decide
def e1205813012378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205813012378 : Closed e1205813012378 ∧ code e1205813012378 = 5603859523482 := by decide
theorem cert_e1205813012378 : check e1205813012378 [[],[]] .smaller = true := by decide
def e1205813012422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1205813012422 : Closed e1205813012422 ∧ code e1205813012422 = 5603859523526 := by decide
theorem cert_e1205813012422 : check e1205813012422 [[],[]] .three = true := by decide
def e1205813012446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e1205813012446 : Closed e1205813012446 ∧ code e1205813012446 = 5603859523550 := by decide
theorem cert_e1205813012446 : check e1205813012446 [[],[]] .three = true := by decide
def e1205813015326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1205813015326 : Closed e1205813015326 ∧ code e1205813015326 = 5603859526430 := by decide
theorem cert_e1205813015326 : check e1205813015326 [[],[]] .smaller = true := by decide
def e1205813015494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1205813015494 : Closed e1205813015494 ∧ code e1205813015494 = 5603859526598 := by decide
theorem cert_e1205813015494 : check e1205813015494 [[],[]] .smaller = true := by decide
def e1205813015518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205813015518 : Closed e1205813015518 ∧ code e1205813015518 = 5603859526622 := by decide
theorem cert_e1205813015518 : check e1205813015518 [[],[]] .three = true := by decide
def e1205813015534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205813015534 : Closed e1205813015534 ∧ code e1205813015534 = 5603859526638 := by decide
theorem cert_e1205813015534 : check e1205813015534 [[],[]] .three = true := by decide
def e1205813016694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1205813016694 : Closed e1205813016694 ∧ code e1205813016694 = 5603859527798 := by decide
theorem cert_e1205813016694 : check e1205813016694 [[],[]] .smaller = true := by decide
def e1205813016938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1205813016938 : Closed e1205813016938 ∧ code e1205813016938 = 5603859528042 := by decide
theorem cert_e1205813016938 : check e1205813016938 [[],[]] .smaller = true := by decide
def e1205813016974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205813016974 : Closed e1205813016974 ∧ code e1205813016974 = 5603859528078 := by decide
theorem cert_e1205813016974 : check e1205813016974 [[],[]] .smaller = true := by decide
def e1205813016986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205813016986 : Closed e1205813016986 ∧ code e1205813016986 = 5603859528090 := by decide
theorem cert_e1205813016986 : check e1205813016986 [[],[]] .smaller = true := by decide
def e1205813017030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205813017030 : Closed e1205813017030 ∧ code e1205813017030 = 5603859528134 := by decide
theorem cert_e1205813017030 : check e1205813017030 [[],[]] .smaller = true := by decide
def e1205813017054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205813017054 : Closed e1205813017054 ∧ code e1205813017054 = 5603859528158 := by decide
theorem cert_e1205813017054 : check e1205813017054 [[],[]] .three = true := by decide
def e1205813017078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205813017078 : Closed e1205813017078 ∧ code e1205813017078 = 5603859528182 := by decide
theorem cert_e1205813017078 : check e1205813017078 [[],[]] .three = true := by decide
def e1205813017798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1205813017798 : Closed e1205813017798 ∧ code e1205813017798 = 5603859528902 := by decide
theorem cert_e1205813017798 : check e1205813017798 [[],[]] .three = true := by decide
def e1205813017822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205813017822 : Closed e1205813017822 ∧ code e1205813017822 = 5603859528926 := by decide
theorem cert_e1205813017822 : check e1205813017822 [[],[]] .three = true := by decide
def e1205813017838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205813017838 : Closed e1205813017838 ∧ code e1205813017838 = 5603859528942 := by decide
theorem cert_e1205813017838 : check e1205813017838 [[],[]] .three = true := by decide
def e1205813017846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205813017846 : Closed e1205813017846 ∧ code e1205813017846 = 5603859528950 := by decide
theorem cert_e1205813017846 : check e1205813017846 [[],[]] .three = true := by decide
def e1205813017850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205813017850 : Closed e1205813017850 ∧ code e1205813017850 = 5603859528954 := by decide
theorem cert_e1205813017850 : check e1205813017850 [[],[]] .three = true := by decide
def e1205813062486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205813062486 : Closed e1205813062486 ∧ code e1205813062486 = 5603859573590 := by decide
theorem cert_e1205813062486 : check e1205813062486 [[],[]] .smaller = true := by decide
def e1205813062490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205813062490 : Closed e1205813062490 ∧ code e1205813062490 = 5603859573594 := by decide
theorem cert_e1205813062490 : check e1205813062490 [[],[]] .smaller = true := by decide
def e1205813062506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205813062506 : Closed e1205813062506 ∧ code e1205813062506 = 5603859573610 := by decide
theorem cert_e1205813062506 : check e1205813062506 [[],[]] .smaller = true := by decide
def e1205813062570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1205813062570 : Closed e1205813062570 ∧ code e1205813062570 = 5603859573674 := by decide
theorem cert_e1205813062570 : check e1205813062570 [[],[]] .smaller = true := by decide
def e1205813062774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1205813062774 : Closed e1205813062774 ∧ code e1205813062774 = 5603859573878 := by decide
theorem cert_e1205813062774 : check e1205813062774 [[],[]] .smaller = true := by decide
def e1205813062870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205813062870 : Closed e1205813062870 ∧ code e1205813062870 = 5603859573974 := by decide
theorem cert_e1205813062870 : check e1205813062870 [[],[]] .smaller = true := by decide
def e1205813062874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205813062874 : Closed e1205813062874 ∧ code e1205813062874 = 5603859573978 := by decide
theorem cert_e1205813062874 : check e1205813062874 [[],[]] .smaller = true := by decide
def e1205813062890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205813062890 : Closed e1205813062890 ∧ code e1205813062890 = 5603859573994 := by decide
theorem cert_e1205813062890 : check e1205813062890 [[],[]] .smaller = true := by decide
def e1205813062966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205813062966 : Closed e1205813062966 ∧ code e1205813062966 = 5603859574070 := by decide
theorem cert_e1205813062966 : check e1205813062966 [[],[]] .smaller = true := by decide
def e1205813062970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205813062970 : Closed e1205813062970 ∧ code e1205813062970 = 5603859574074 := by decide
theorem cert_e1205813062970 : check e1205813062970 [[],[]] .smaller = true := by decide
def e1205813063054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1205813063054 : Closed e1205813063054 ∧ code e1205813063054 = 5603859574158 := by decide
theorem cert_e1205813063054 : check e1205813063054 [[],[]] .smaller = true := by decide
def e1205813063066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205813063066 : Closed e1205813063066 ∧ code e1205813063066 = 5603859574170 := by decide
theorem cert_e1205813063066 : check e1205813063066 [[],[]] .smaller = true := by decide
def e1205813063134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1205813063134 : Closed e1205813063134 ∧ code e1205813063134 = 5603859574238 := by decide
theorem cert_e1205813063134 : check e1205813063134 [[],[]] .three = true := by decide
def e1205813063150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1205813063150 : Closed e1205813063150 ∧ code e1205813063150 = 5603859574254 := by decide
theorem cert_e1205813063150 : check e1205813063150 [[],[]] .three = true := by decide
def e1205813063222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205813063222 : Closed e1205813063222 ∧ code e1205813063222 = 5603859574326 := by decide
theorem cert_e1205813063222 : check e1205813063222 [[],[]] .smaller = true := by decide
def e1205813063226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205813063226 : Closed e1205813063226 ∧ code e1205813063226 = 5603859574330 := by decide
theorem cert_e1205813063226 : check e1205813063226 [[],[]] .smaller = true := by decide
def e1205813063274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1205813063274 : Closed e1205813063274 ∧ code e1205813063274 = 5603859574378 := by decide
theorem cert_e1205813063274 : check e1205813063274 [[],[]] .smaller = true := by decide
def e1205813063310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205813063310 : Closed e1205813063310 ∧ code e1205813063310 = 5603859574414 := by decide
theorem cert_e1205813063310 : check e1205813063310 [[],[]] .smaller = true := by decide
def e1205813063322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205813063322 : Closed e1205813063322 ∧ code e1205813063322 = 5603859574426 := by decide
theorem cert_e1205813063322 : check e1205813063322 [[],[]] .smaller = true := by decide
def e1205813063366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205813063366 : Closed e1205813063366 ∧ code e1205813063366 = 5603859574470 := by decide
theorem cert_e1205813063366 : check e1205813063366 [[],[]] .smaller = true := by decide
def e1205813063390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1205813063390 : Closed e1205813063390 ∧ code e1205813063390 = 5603859574494 := by decide
theorem cert_e1205813063390 : check e1205813063390 [[],[]] .three = true := by decide
def e1205813063414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1205813063414 : Closed e1205813063414 ∧ code e1205813063414 = 5603859574518 := by decide
theorem cert_e1205813063414 : check e1205813063414 [[],[]] .three = true := by decide
def e1205813063518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1205813063518 : Closed e1205813063518 ∧ code e1205813063518 = 5603859574622 := by decide
theorem cert_e1205813063518 : check e1205813063518 [[],[]] .three = true := by decide
def e1205813063546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1205813063546 : Closed e1205813063546 ∧ code e1205813063546 = 5603859574650 := by decide
theorem cert_e1205813063546 : check e1205813063546 [[],[]] .three = true := by decide
def e1205813063598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1205813063598 : Closed e1205813063598 ∧ code e1205813063598 = 5603859574702 := by decide
theorem cert_e1205813063598 : check e1205813063598 [[],[]] .three = true := by decide
def e1205813063606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1205813063606 : Closed e1205813063606 ∧ code e1205813063606 = 5603859574710 := by decide
theorem cert_e1205813063606 : check e1205813063606 [[],[]] .three = true := by decide
def e1205813063610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1205813063610 : Closed e1205813063610 ∧ code e1205813063610 = 5603859574714 := by decide
theorem cert_e1205813063610 : check e1205813063610 [[],[]] .three = true := by decide
def e1205813063918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1205813063918 : Closed e1205813063918 ∧ code e1205813063918 = 5603859575022 := by decide
theorem cert_e1205813063918 : check e1205813063918 [[],[]] .smaller = true := by decide
def e1205813063926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1205813063926 : Closed e1205813063926 ∧ code e1205813063926 = 5603859575030 := by decide
theorem cert_e1205813063926 : check e1205813063926 [[],[]] .smaller = true := by decide
def e1205813064406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205813064406 : Closed e1205813064406 ∧ code e1205813064406 = 5603859575510 := by decide
theorem cert_e1205813064406 : check e1205813064406 [[],[]] .smaller = true := by decide
def e1205813064410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205813064410 : Closed e1205813064410 ∧ code e1205813064410 = 5603859575514 := by decide
theorem cert_e1205813064410 : check e1205813064410 [[],[]] .smaller = true := by decide
def e1205813064426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205813064426 : Closed e1205813064426 ∧ code e1205813064426 = 5603859575530 := by decide
theorem cert_e1205813064426 : check e1205813064426 [[],[]] .smaller = true := by decide
def e1205813064502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205813064502 : Closed e1205813064502 ∧ code e1205813064502 = 5603859575606 := by decide
theorem cert_e1205813064502 : check e1205813064502 [[],[]] .smaller = true := by decide
def e1205813064506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205813064506 : Closed e1205813064506 ∧ code e1205813064506 = 5603859575610 := by decide
theorem cert_e1205813064506 : check e1205813064506 [[],[]] .smaller = true := by decide
def e1205813064590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1205813064590 : Closed e1205813064590 ∧ code e1205813064590 = 5603859575694 := by decide
theorem cert_e1205813064590 : check e1205813064590 [[],[]] .smaller = true := by decide
def e1205813064602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205813064602 : Closed e1205813064602 ∧ code e1205813064602 = 5603859575706 := by decide
theorem cert_e1205813064602 : check e1205813064602 [[],[]] .smaller = true := by decide
def e1205813064670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205813064670 : Closed e1205813064670 ∧ code e1205813064670 = 5603859575774 := by decide
theorem cert_e1205813064670 : check e1205813064670 [[],[]] .three = true := by decide
def e1205813064686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205813064686 : Closed e1205813064686 ∧ code e1205813064686 = 5603859575790 := by decide
theorem cert_e1205813064686 : check e1205813064686 [[],[]] .three = true := by decide
def e1205813065846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1205813065846 : Closed e1205813065846 ∧ code e1205813065846 = 5603859576950 := by decide
theorem cert_e1205813065846 : check e1205813065846 [[],[]] .smaller = true := by decide
def e1205813066090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1205813066090 : Closed e1205813066090 ∧ code e1205813066090 = 5603859577194 := by decide
theorem cert_e1205813066090 : check e1205813066090 [[],[]] .smaller = true := by decide
def e1205813066126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205813066126 : Closed e1205813066126 ∧ code e1205813066126 = 5603859577230 := by decide
theorem cert_e1205813066126 : check e1205813066126 [[],[]] .smaller = true := by decide
def e1205813066138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205813066138 : Closed e1205813066138 ∧ code e1205813066138 = 5603859577242 := by decide
theorem cert_e1205813066138 : check e1205813066138 [[],[]] .smaller = true := by decide
def e1205813066182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205813066182 : Closed e1205813066182 ∧ code e1205813066182 = 5603859577286 := by decide
theorem cert_e1205813066182 : check e1205813066182 [[],[]] .smaller = true := by decide
def e1205813066206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205813066206 : Closed e1205813066206 ∧ code e1205813066206 = 5603859577310 := by decide
theorem cert_e1205813066206 : check e1205813066206 [[],[]] .three = true := by decide
def e1205813066230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205813066230 : Closed e1205813066230 ∧ code e1205813066230 = 5603859577334 := by decide
theorem cert_e1205813066230 : check e1205813066230 [[],[]] .three = true := by decide
def e1205813066974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205813066974 : Closed e1205813066974 ∧ code e1205813066974 = 5603859578078 := by decide
theorem cert_e1205813066974 : check e1205813066974 [[],[]] .three = true := by decide
def e1205813067002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205813067002 : Closed e1205813067002 ∧ code e1205813067002 = 5603859578106 := by decide
theorem cert_e1205813067002 : check e1205813067002 [[],[]] .three = true := by decide
def e1205813067374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205813067374 : Closed e1205813067374 ∧ code e1205813067374 = 5603859578478 := by decide
theorem cert_e1205813067374 : check e1205813067374 [[],[]] .three = true := by decide
def e1205813067382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205813067382 : Closed e1205813067382 ∧ code e1205813067382 = 5603859578486 := by decide
theorem cert_e1205813067382 : check e1205813067382 [[],[]] .three = true := by decide
def e1205813067386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205813067386 : Closed e1205813067386 ∧ code e1205813067386 = 5603859578490 := by decide
theorem cert_e1205813067386 : check e1205813067386 [[],[]] .three = true := by decide
def e1205813089846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205813089846 : Closed e1205813089846 ∧ code e1205813089846 = 5603859600950 := by decide
theorem cert_e1205813089846 : check e1205813089846 [[],[]] .three = true := by decide
def e1205813089850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205813089850 : Closed e1205813089850 ∧ code e1205813089850 = 5603859600954 := by decide
theorem cert_e1205813089850 : check e1205813089850 [[],[]] .three = true := by decide
def e1205813089934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205813089934 : Closed e1205813089934 ∧ code e1205813089934 = 5603859601038 := by decide
theorem cert_e1205813089934 : check e1205813089934 [[],[]] .three = true := by decide
def e1205813089990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205813089990 : Closed e1205813089990 ∧ code e1205813089990 = 5603859601094 := by decide
theorem cert_e1205813089990 : check e1205813089990 [[],[]] .three = true := by decide
def e1205813090014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1205813090014 : Closed e1205813090014 ∧ code e1205813090014 = 5603859601118 := by decide
theorem cert_e1205813090014 : check e1205813090014 [[],[]] .three = true := by decide
end Blc.Floor42
