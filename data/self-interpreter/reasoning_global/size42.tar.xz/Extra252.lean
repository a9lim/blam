import Batch252
import ExtraBase
namespace Blc.Floor42.Extra252
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211301919118 : Term := (.lam (.lam (.var 1)))
theorem ex_e1211301919118 : ¬ IsSelfInterpreter e1211301919118 := by
  intro he
  have hp := replay_sound (t := (projPair e1211301919118)) (u := t_e1211301919118) (ps := [[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.right,.left],[.left,.right,.left,.right],[.left,.right,.left,.right],[.left,.right,.left,.right,.right,.left],[.left,.right,.left,.right,.right],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left],[]]) (by decide)
  apply pair_not_so he hp
  exact (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1)))
#print axioms ex_e1211301919118
end Blc.Floor42.Extra252
