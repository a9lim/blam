import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1107799667950 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1107799667950 : Closed e1107799667950 ∧ code e1107799667950 = 5505846179054 := by decide
theorem cert_e1107799667950 : check e1107799667950 [[],[.under,.under]] .three = true := by decide
def e1107799667958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1107799667958 : Closed e1107799667958 ∧ code e1107799667958 = 5505846179062 := by decide
theorem cert_e1107799667958 : check e1107799667958 [[],[.under,.under]] .three = true := by decide
def e1107799668334 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1107799668334 : Closed e1107799668334 ∧ code e1107799668334 = 5505846179438 := by decide
theorem cert_e1107799668334 : check e1107799668334 [[],[.under,.under]] .three = true := by decide
def e1107799668346 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1107799668346 : Closed e1107799668346 ∧ code e1107799668346 = 5505846179450 := by decide
theorem cert_e1107799668346 : check e1107799668346 [[],[.under,.under]] .three = true := by decide
def e1107799668534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1107799668534 : Closed e1107799668534 ∧ code e1107799668534 = 5505846179638 := by decide
theorem cert_e1107799668534 : check e1107799668534 [[],[.under,.under]] .three = true := by decide
def e1107799668538 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1107799668538 : Closed e1107799668538 ∧ code e1107799668538 = 5505846179642 := by decide
theorem cert_e1107799668538 : check e1107799668538 [[],[.under,.under]] .three = true := by decide
def e1107799669174 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1107799669174 : Closed e1107799669174 ∧ code e1107799669174 = 5505846180278 := by decide
theorem cert_e1107799669174 : check e1107799669174 [[],[.under,.under]] .three = true := by decide
def e1107799669206 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1107799669206 : Closed e1107799669206 ∧ code e1107799669206 = 5505846180310 := by decide
theorem cert_e1107799669206 : check e1107799669206 [[],[.under,.under]] .three = true := by decide
def e1107799669210 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1107799669210 : Closed e1107799669210 ∧ code e1107799669210 = 5505846180314 := by decide
theorem cert_e1107799669210 : check e1107799669210 [[],[.under,.under]] .three = true := by decide
def e1107799669366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1107799669366 : Closed e1107799669366 ∧ code e1107799669366 = 5505846180470 := by decide
theorem cert_e1107799669366 : check e1107799669366 [[],[.under,.under]] .three = true := by decide
def e1107799669558 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1107799669558 : Closed e1107799669558 ∧ code e1107799669558 = 5505846180662 := by decide
theorem cert_e1107799669558 : check e1107799669558 [[],[.under,.under]] .three = true := by decide
def e1107799669562 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1107799669562 : Closed e1107799669562 ∧ code e1107799669562 = 5505846180666 := by decide
theorem cert_e1107799669562 : check e1107799669562 [[],[.under,.under]] .three = true := by decide
def e1107799676782 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1107799676782 : Closed e1107799676782 ∧ code e1107799676782 = 5505846187886 := by decide
theorem cert_e1107799676782 : check e1107799676782 [[],[.under,.under]] .three = true := by decide
def e1107799676790 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1107799676790 : Closed e1107799676790 ∧ code e1107799676790 = 5505846187894 := by decide
theorem cert_e1107799676790 : check e1107799676790 [[],[.under,.under]] .three = true := by decide
def e1107799676854 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1107799676854 : Closed e1107799676854 ∧ code e1107799676854 = 5505846187958 := by decide
theorem cert_e1107799676854 : check e1107799676854 [[],[.under,.under]] .three = true := by decide
def e1107799678190 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1107799678190 : Closed e1107799678190 ∧ code e1107799678190 = 5505846189294 := by decide
theorem cert_e1107799678190 : check e1107799678190 [[],[.under,.under]] .three = true := by decide
def e1107799678198 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1107799678198 : Closed e1107799678198 ∧ code e1107799678198 = 5505846189302 := by decide
theorem cert_e1107799678198 : check e1107799678198 [[],[.under,.under]] .three = true := by decide
def e1107799678582 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1107799678582 : Closed e1107799678582 ∧ code e1107799678582 = 5505846189686 := by decide
theorem cert_e1107799678582 : check e1107799678582 [[],[.under,.under]] .three = true := by decide
def e1107799690094 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1107799690094 : Closed e1107799690094 ∧ code e1107799690094 = 5505846201198 := by decide
theorem cert_e1107799690094 : check e1107799690094 [[],[.under,.under]] .three = true := by decide
def e1107799690102 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1107799690102 : Closed e1107799690102 ∧ code e1107799690102 = 5505846201206 := by decide
theorem cert_e1107799690102 : check e1107799690102 [[],[.under,.under]] .three = true := by decide
def e1107799690158 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1107799690158 : Closed e1107799690158 ∧ code e1107799690158 = 5505846201262 := by decide
theorem cert_e1107799690158 : check e1107799690158 [[],[.under,.under]] .three = true := by decide
def e1107799690170 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1107799690170 : Closed e1107799690170 ∧ code e1107799690170 = 5505846201274 := by decide
theorem cert_e1107799690170 : check e1107799690170 [[],[.under,.under]] .three = true := by decide
def e1107799690198 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1107799690198 : Closed e1107799690198 ∧ code e1107799690198 = 5505846201302 := by decide
theorem cert_e1107799690198 : check e1107799690198 [[],[.under,.under]] .three = true := by decide
def e1107799690202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1107799690202 : Closed e1107799690202 ∧ code e1107799690202 = 5505846201306 := by decide
theorem cert_e1107799690202 : check e1107799690202 [[],[.under,.under]] .three = true := by decide
def e1107799690478 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1107799690478 : Closed e1107799690478 ∧ code e1107799690478 = 5505846201582 := by decide
theorem cert_e1107799690478 : check e1107799690478 [[],[.under,.under]] .three = true := by decide
def e1107799690486 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1107799690486 : Closed e1107799690486 ∧ code e1107799690486 = 5505846201590 := by decide
theorem cert_e1107799690486 : check e1107799690486 [[],[.under,.under]] .three = true := by decide
def e1107799690862 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1107799690862 : Closed e1107799690862 ∧ code e1107799690862 = 5505846201966 := by decide
theorem cert_e1107799690862 : check e1107799690862 [[],[.under,.under]] .three = true := by decide
def e1107799690874 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1107799690874 : Closed e1107799690874 ∧ code e1107799690874 = 5505846201978 := by decide
theorem cert_e1107799690874 : check e1107799690874 [[],[.under,.under]] .three = true := by decide
def e1107799691062 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1107799691062 : Closed e1107799691062 ∧ code e1107799691062 = 5505846202166 := by decide
theorem cert_e1107799691062 : check e1107799691062 [[],[.under,.under]] .three = true := by decide
def e1107799691066 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1107799691066 : Closed e1107799691066 ∧ code e1107799691066 = 5505846202170 := by decide
theorem cert_e1107799691066 : check e1107799691066 [[],[.under,.under]] .three = true := by decide
def e1107799696822 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1107799696822 : Closed e1107799696822 ∧ code e1107799696822 = 5505846207926 := by decide
theorem cert_e1107799696822 : check e1107799696822 [[],[.under,.under]] .three = true := by decide
def e1107799696854 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1107799696854 : Closed e1107799696854 ∧ code e1107799696854 = 5505846207958 := by decide
theorem cert_e1107799696854 : check e1107799696854 [[],[.under,.under]] .three = true := by decide
def e1107799696858 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1107799696858 : Closed e1107799696858 ∧ code e1107799696858 = 5505846207962 := by decide
theorem cert_e1107799696858 : check e1107799696858 [[],[.under,.under]] .three = true := by decide
def e1107799697014 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1107799697014 : Closed e1107799697014 ∧ code e1107799697014 = 5505846208118 := by decide
theorem cert_e1107799697014 : check e1107799697014 [[],[.under,.under]] .three = true := by decide
def e1107799697206 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1107799697206 : Closed e1107799697206 ∧ code e1107799697206 = 5505846208310 := by decide
theorem cert_e1107799697206 : check e1107799697206 [[],[.under,.under]] .three = true := by decide
def e1107799697210 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1107799697210 : Closed e1107799697210 ∧ code e1107799697210 = 5505846208314 := by decide
theorem cert_e1107799697210 : check e1107799697210 [[],[.under,.under]] .three = true := by decide
def e1107800034158 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1107800034158 : Closed e1107800034158 ∧ code e1107800034158 = 5505846545262 := by decide
theorem cert_e1107800034158 : check e1107800034158 [[],[.under,.under]] .three = true := by decide
def e1107800034166 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1107800034166 : Closed e1107800034166 ∧ code e1107800034166 = 5505846545270 := by decide
private def t_e1107800034166 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1107800034166 : ¬ IsSelfInterpreter e1107800034166 :=
  wSource (t := t_e1107800034166) (replay_sound (ps := []) (t := e1107800034166) (by decide)) (by decide)
def e1107800034222 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1107800034222 : Closed e1107800034222 ∧ code e1107800034222 = 5505846545326 := by decide
theorem cert_e1107800034222 : check e1107800034222 [[],[.under,.under]] .three = true := by decide
def e1107800034234 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1107800034234 : Closed e1107800034234 ∧ code e1107800034234 = 5505846545338 := by decide
theorem cert_e1107800034234 : check e1107800034234 [[],[.under,.under]] .three = true := by decide
def e1107800034262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1107800034262 : Closed e1107800034262 ∧ code e1107800034262 = 5505846545366 := by decide
private def t_e1107800034262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1107800034262 : ¬ IsSelfInterpreter e1107800034262 :=
  wSource (t := t_e1107800034262) (replay_sound (ps := []) (t := e1107800034262) (by decide)) (by decide)
def e1107800034266 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1107800034266 : Closed e1107800034266 ∧ code e1107800034266 = 5505846545370 := by decide
theorem cert_e1107800034266 : check e1107800034266 [[],[.under,.under]] .three = true := by decide
def e1107800034542 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1107800034542 : Closed e1107800034542 ∧ code e1107800034542 = 5505846545646 := by decide
theorem cert_e1107800034542 : check e1107800034542 [[],[.under,.under]] .three = true := by decide
def e1107800034550 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1107800034550 : Closed e1107800034550 ∧ code e1107800034550 = 5505846545654 := by decide
theorem cert_e1107800034550 : check e1107800034550 [[],[.under,.under]] .three = true := by decide
def e1107800034926 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1107800034926 : Closed e1107800034926 ∧ code e1107800034926 = 5505846546030 := by decide
theorem cert_e1107800034926 : check e1107800034926 [[],[.under,.under]] .three = true := by decide
def e1107800034938 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1107800034938 : Closed e1107800034938 ∧ code e1107800034938 = 5505846546042 := by decide
theorem cert_e1107800034938 : check e1107800034938 [[],[.under,.under]] .three = true := by decide
def e1107800035126 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1107800035126 : Closed e1107800035126 ∧ code e1107800035126 = 5505846546230 := by decide
theorem cert_e1107800035126 : check e1107800035126 [[],[.under,.under]] .three = true := by decide
def e1107800035130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1107800035130 : Closed e1107800035130 ∧ code e1107800035130 = 5505846546234 := by decide
theorem cert_e1107800035130 : check e1107800035130 [[],[.under,.under]] .three = true := by decide
def e1123229851674 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123229851674 : Closed e1123229851674 ∧ code e1123229851674 = 5521276362778 := by decide
theorem cert_e1123229851674 : check e1123229851674 [[]] .width = true := by decide
def e1123229851766 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123229851766 : Closed e1123229851766 ∧ code e1123229851766 = 5521276362870 := by decide
theorem cert_e1123229851766 : check e1123229851766 [[]] .width = true := by decide
def e1123229852010 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123229852010 : Closed e1123229852010 ∧ code e1123229852010 = 5521276363114 := by decide
theorem cert_e1123229852010 : check e1123229852010 [[]] .width = true := by decide
def e1123229852058 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123229852058 : Closed e1123229852058 ∧ code e1123229852058 = 5521276363162 := by decide
theorem cert_e1123229852058 : check e1123229852058 [[]] .width = true := by decide
def e1123230113818 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123230113818 : Closed e1123230113818 ∧ code e1123230113818 = 5521276624922 := by decide
theorem cert_e1123230113818 : check e1123230113818 [[]] .width = true := by decide
def e1123230113910 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123230113910 : Closed e1123230113910 ∧ code e1123230113910 = 5521276625014 := by decide
theorem cert_e1123230113910 : check e1123230113910 [[]] .width = true := by decide
def e1123230114154 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123230114154 : Closed e1123230114154 ∧ code e1123230114154 = 5521276625258 := by decide
theorem cert_e1123230114154 : check e1123230114154 [[]] .width = true := by decide
def e1123230114202 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123230114202 : Closed e1123230114202 ∧ code e1123230114202 = 5521276625306 := by decide
theorem cert_e1123230114202 : check e1123230114202 [[]] .width = true := by decide
def e1123231948826 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123231948826 : Closed e1123231948826 ∧ code e1123231948826 = 5521278459930 := by decide
theorem cert_e1123231948826 : check e1123231948826 [[]] .width = true := by decide
def e1123231948918 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123231948918 : Closed e1123231948918 ∧ code e1123231948918 = 5521278460022 := by decide
theorem cert_e1123231948918 : check e1123231948918 [[]] .width = true := by decide
def e1123231949162 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123231949162 : Closed e1123231949162 ∧ code e1123231949162 = 5521278460266 := by decide
theorem cert_e1123231949162 : check e1123231949162 [[]] .width = true := by decide
def e1123231949210 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123231949210 : Closed e1123231949210 ∧ code e1123231949210 = 5521278460314 := by decide
theorem cert_e1123231949210 : check e1123231949210 [[]] .width = true := by decide
def e1123232342042 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123232342042 : Closed e1123232342042 ∧ code e1123232342042 = 5521278853146 := by decide
theorem cert_e1123232342042 : check e1123232342042 [[]] .width = true := by decide
def e1123232342134 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123232342134 : Closed e1123232342134 ∧ code e1123232342134 = 5521278853238 := by decide
theorem cert_e1123232342134 : check e1123232342134 [[]] .width = true := by decide
def e1123232342378 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123232342378 : Closed e1123232342378 ∧ code e1123232342378 = 5521278853482 := by decide
theorem cert_e1123232342378 : check e1123232342378 [[]] .width = true := by decide
def e1123232342426 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123232342426 : Closed e1123232342426 ∧ code e1123232342426 = 5521278853530 := by decide
theorem cert_e1123232342426 : check e1123232342426 [[]] .width = true := by decide
def e1123233259546 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123233259546 : Closed e1123233259546 ∧ code e1123233259546 = 5521279770650 := by decide
theorem cert_e1123233259546 : check e1123233259546 [[]] .width = true := by decide
def e1123233259638 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123233259638 : Closed e1123233259638 ∧ code e1123233259638 = 5521279770742 := by decide
theorem cert_e1123233259638 : check e1123233259638 [[]] .width = true := by decide
def e1123233259882 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123233259882 : Closed e1123233259882 ∧ code e1123233259882 = 5521279770986 := by decide
theorem cert_e1123233259882 : check e1123233259882 [[]] .width = true := by decide
def e1123233259930 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123233259930 : Closed e1123233259930 ∧ code e1123233259930 = 5521279771034 := by decide
theorem cert_e1123233259930 : check e1123233259930 [[]] .width = true := by decide
def e1123233390618 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123233390618 : Closed e1123233390618 ∧ code e1123233390618 = 5521279901722 := by decide
theorem cert_e1123233390618 : check e1123233390618 [[]] .width = true := by decide
def e1123233390710 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123233390710 : Closed e1123233390710 ∧ code e1123233390710 = 5521279901814 := by decide
theorem cert_e1123233390710 : check e1123233390710 [[]] .width = true := by decide
def e1123233390954 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123233390954 : Closed e1123233390954 ∧ code e1123233390954 = 5521279902058 := by decide
theorem cert_e1123233390954 : check e1123233390954 [[]] .width = true := by decide
def e1123233391002 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123233391002 : Closed e1123233391002 ∧ code e1123233391002 = 5521279902106 := by decide
theorem cert_e1123233391002 : check e1123233391002 [[]] .width = true := by decide
def e1123242434586 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123242434586 : Closed e1123242434586 ∧ code e1123242434586 = 5521288945690 := by decide
theorem cert_e1123242434586 : check e1123242434586 [[]] .width = true := by decide
def e1123242434678 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123242434678 : Closed e1123242434678 ∧ code e1123242434678 = 5521288945782 := by decide
theorem cert_e1123242434678 : check e1123242434678 [[]] .width = true := by decide
def e1123242434922 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123242434922 : Closed e1123242434922 ∧ code e1123242434922 = 5521288946026 := by decide
theorem cert_e1123242434922 : check e1123242434922 [[]] .width = true := by decide
def e1123242434970 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123242434970 : Closed e1123242434970 ∧ code e1123242434970 = 5521288946074 := by decide
theorem cert_e1123242434970 : check e1123242434970 [[]] .width = true := by decide
def e1123242696730 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123242696730 : Closed e1123242696730 ∧ code e1123242696730 = 5521289207834 := by decide
theorem cert_e1123242696730 : check e1123242696730 [[]] .width = true := by decide
def e1123242696822 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123242696822 : Closed e1123242696822 ∧ code e1123242696822 = 5521289207926 := by decide
theorem cert_e1123242696822 : check e1123242696822 [[]] .width = true := by decide
def e1123242697066 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123242697066 : Closed e1123242697066 ∧ code e1123242697066 = 5521289208170 := by decide
theorem cert_e1123242697066 : check e1123242697066 [[]] .width = true := by decide
def e1123242697114 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123242697114 : Closed e1123242697114 ∧ code e1123242697114 = 5521289208218 := by decide
theorem cert_e1123242697114 : check e1123242697114 [[]] .width = true := by decide
def e1123255017498 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123255017498 : Closed e1123255017498 ∧ code e1123255017498 = 5521301528602 := by decide
theorem cert_e1123255017498 : check e1123255017498 [[]] .width = true := by decide
def e1123255017590 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123255017590 : Closed e1123255017590 ∧ code e1123255017590 = 5521301528694 := by decide
theorem cert_e1123255017590 : check e1123255017590 [[]] .width = true := by decide
def e1123255017834 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123255017834 : Closed e1123255017834 ∧ code e1123255017834 = 5521301528938 := by decide
theorem cert_e1123255017834 : check e1123255017834 [[]] .width = true := by decide
def e1123255017882 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123255017882 : Closed e1123255017882 ∧ code e1123255017882 = 5521301528986 := by decide
theorem cert_e1123255017882 : check e1123255017882 [[]] .width = true := by decide
def e1123255410714 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123255410714 : Closed e1123255410714 ∧ code e1123255410714 = 5521301921818 := by decide
theorem cert_e1123255410714 : check e1123255410714 [[]] .width = true := by decide
def e1123255410806 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123255410806 : Closed e1123255410806 ∧ code e1123255410806 = 5521301921910 := by decide
theorem cert_e1123255410806 : check e1123255410806 [[]] .width = true := by decide
def e1123255411050 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123255411050 : Closed e1123255411050 ∧ code e1123255411050 = 5521301922154 := by decide
theorem cert_e1123255411050 : check e1123255411050 [[]] .width = true := by decide
def e1123255411098 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123255411098 : Closed e1123255411098 ∧ code e1123255411098 = 5521301922202 := by decide
theorem cert_e1123255411098 : check e1123255411098 [[]] .width = true := by decide
def e1123261571098 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123261571098 : Closed e1123261571098 ∧ code e1123261571098 = 5521308082202 := by decide
theorem cert_e1123261571098 : check e1123261571098 [[]] .width = true := by decide
def e1123261571190 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123261571190 : Closed e1123261571190 ∧ code e1123261571190 = 5521308082294 := by decide
theorem cert_e1123261571190 : check e1123261571190 [[]] .width = true := by decide
def e1123261571434 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123261571434 : Closed e1123261571434 ∧ code e1123261571434 = 5521308082538 := by decide
theorem cert_e1123261571434 : check e1123261571434 [[]] .width = true := by decide
def e1123261571482 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123261571482 : Closed e1123261571482 ∧ code e1123261571482 = 5521308082586 := by decide
theorem cert_e1123261571482 : check e1123261571482 [[]] .width = true := by decide
def e1123261702170 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123261702170 : Closed e1123261702170 ∧ code e1123261702170 = 5521308213274 := by decide
theorem cert_e1123261702170 : check e1123261702170 [[]] .width = true := by decide
def e1123261702262 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123261702262 : Closed e1123261702262 ∧ code e1123261702262 = 5521308213366 := by decide
theorem cert_e1123261702262 : check e1123261702262 [[]] .width = true := by decide
def e1123261702506 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123261702506 : Closed e1123261702506 ∧ code e1123261702506 = 5521308213610 := by decide
theorem cert_e1123261702506 : check e1123261702506 [[]] .width = true := by decide
def e1123261702554 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123261702554 : Closed e1123261702554 ∧ code e1123261702554 = 5521308213658 := by decide
theorem cert_e1123261702554 : check e1123261702554 [[]] .width = true := by decide
def e1123951239194 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951239194 : Closed e1123951239194 ∧ code e1123951239194 = 5521997750298 := by decide
theorem cert_e1123951239194 : check e1123951239194 [[]] .width = true := by decide
def e1123951239286 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951239286 : Closed e1123951239286 ∧ code e1123951239286 = 5521997750390 := by decide
theorem cert_e1123951239286 : check e1123951239286 [[]] .width = true := by decide
def e1123951239530 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951239530 : Closed e1123951239530 ∧ code e1123951239530 = 5521997750634 := by decide
theorem cert_e1123951239530 : check e1123951239530 [[]] .width = true := by decide
def e1123951239578 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951239578 : Closed e1123951239578 ∧ code e1123951239578 = 5521997750682 := by decide
theorem cert_e1123951239578 : check e1123951239578 [[]] .width = true := by decide
def e1123951271962 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951271962 : Closed e1123951271962 ∧ code e1123951271962 = 5521997783066 := by decide
theorem cert_e1123951271962 : check e1123951271962 [[]] .width = true := by decide
def e1123951272054 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951272054 : Closed e1123951272054 ∧ code e1123951272054 = 5521997783158 := by decide
theorem cert_e1123951272054 : check e1123951272054 [[]] .width = true := by decide
def e1123951272298 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951272298 : Closed e1123951272298 ∧ code e1123951272298 = 5521997783402 := by decide
theorem cert_e1123951272298 : check e1123951272298 [[]] .width = true := by decide
def e1123951272346 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951272346 : Closed e1123951272346 ∧ code e1123951272346 = 5521997783450 := by decide
theorem cert_e1123951272346 : check e1123951272346 [[]] .width = true := by decide
def e1123951501338 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951501338 : Closed e1123951501338 ∧ code e1123951501338 = 5521998012442 := by decide
theorem cert_e1123951501338 : check e1123951501338 [[]] .width = true := by decide
def e1123951501430 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951501430 : Closed e1123951501430 ∧ code e1123951501430 = 5521998012534 := by decide
theorem cert_e1123951501430 : check e1123951501430 [[]] .width = true := by decide
def e1123951501674 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951501674 : Closed e1123951501674 ∧ code e1123951501674 = 5521998012778 := by decide
theorem cert_e1123951501674 : check e1123951501674 [[]] .width = true := by decide
def e1123951501722 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951501722 : Closed e1123951501722 ∧ code e1123951501722 = 5521998012826 := by decide
theorem cert_e1123951501722 : check e1123951501722 [[]] .width = true := by decide
def e1123951550490 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951550490 : Closed e1123951550490 ∧ code e1123951550490 = 5521998061594 := by decide
theorem cert_e1123951550490 : check e1123951550490 [[]] .width = true := by decide
def e1123951550582 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951550582 : Closed e1123951550582 ∧ code e1123951550582 = 5521998061686 := by decide
theorem cert_e1123951550582 : check e1123951550582 [[]] .width = true := by decide
def e1123951550826 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951550826 : Closed e1123951550826 ∧ code e1123951550826 = 5521998061930 := by decide
theorem cert_e1123951550826 : check e1123951550826 [[]] .width = true := by decide
def e1123951550874 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951550874 : Closed e1123951550874 ∧ code e1123951550874 = 5521998061978 := by decide
theorem cert_e1123951550874 : check e1123951550874 [[]] .width = true := by decide
def e1123951665178 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951665178 : Closed e1123951665178 ∧ code e1123951665178 = 5521998176282 := by decide
theorem cert_e1123951665178 : check e1123951665178 [[]] .width = true := by decide
def e1123951665270 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951665270 : Closed e1123951665270 ∧ code e1123951665270 = 5521998176374 := by decide
theorem cert_e1123951665270 : check e1123951665270 [[]] .width = true := by decide
def e1123951665514 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951665514 : Closed e1123951665514 ∧ code e1123951665514 = 5521998176618 := by decide
theorem cert_e1123951665514 : check e1123951665514 [[]] .width = true := by decide
def e1123951665562 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951665562 : Closed e1123951665562 ∧ code e1123951665562 = 5521998176666 := by decide
theorem cert_e1123951665562 : check e1123951665562 [[]] .width = true := by decide
def e1123951681562 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123951681562 : Closed e1123951681562 ∧ code e1123951681562 = 5521998192666 := by decide
theorem cert_e1123951681562 : check e1123951681562 [[]] .width = true := by decide
def e1123951681654 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123951681654 : Closed e1123951681654 ∧ code e1123951681654 = 5521998192758 := by decide
theorem cert_e1123951681654 : check e1123951681654 [[]] .width = true := by decide
def e1123951681898 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123951681898 : Closed e1123951681898 ∧ code e1123951681898 = 5521998193002 := by decide
theorem cert_e1123951681898 : check e1123951681898 [[]] .width = true := by decide
def e1123951681946 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123951681946 : Closed e1123951681946 ∧ code e1123951681946 = 5521998193050 := by decide
theorem cert_e1123951681946 : check e1123951681946 [[]] .width = true := by decide
def e1123952812058 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123952812058 : Closed e1123952812058 ∧ code e1123952812058 = 5521999323162 := by decide
theorem cert_e1123952812058 : check e1123952812058 [[]] .width = true := by decide
def e1123952812150 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123952812150 : Closed e1123952812150 ∧ code e1123952812150 = 5521999323254 := by decide
theorem cert_e1123952812150 : check e1123952812150 [[]] .width = true := by decide
def e1123952812394 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123952812394 : Closed e1123952812394 ∧ code e1123952812394 = 5521999323498 := by decide
theorem cert_e1123952812394 : check e1123952812394 [[]] .width = true := by decide
def e1123952812442 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123952812442 : Closed e1123952812442 ∧ code e1123952812442 = 5521999323546 := by decide
theorem cert_e1123952812442 : check e1123952812442 [[]] .width = true := by decide
def e1123952844826 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123952844826 : Closed e1123952844826 ∧ code e1123952844826 = 5521999355930 := by decide
theorem cert_e1123952844826 : check e1123952844826 [[]] .width = true := by decide
def e1123952844918 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123952844918 : Closed e1123952844918 ∧ code e1123952844918 = 5521999356022 := by decide
theorem cert_e1123952844918 : check e1123952844918 [[]] .width = true := by decide
def e1123952845162 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123952845162 : Closed e1123952845162 ∧ code e1123952845162 = 5521999356266 := by decide
theorem cert_e1123952845162 : check e1123952845162 [[]] .width = true := by decide
def e1123952845210 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123952845210 : Closed e1123952845210 ∧ code e1123952845210 = 5521999356314 := by decide
theorem cert_e1123952845210 : check e1123952845210 [[]] .width = true := by decide
def e1123954384922 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123954384922 : Closed e1123954384922 ∧ code e1123954384922 = 5522000896026 := by decide
theorem cert_e1123954384922 : check e1123954384922 [[]] .width = true := by decide
def e1123954385014 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123954385014 : Closed e1123954385014 ∧ code e1123954385014 = 5522000896118 := by decide
theorem cert_e1123954385014 : check e1123954385014 [[]] .width = true := by decide
def e1123954385258 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123954385258 : Closed e1123954385258 ∧ code e1123954385258 = 5522000896362 := by decide
theorem cert_e1123954385258 : check e1123954385258 [[]] .width = true := by decide
def e1123954385306 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123954385306 : Closed e1123954385306 ∧ code e1123954385306 = 5522000896410 := by decide
theorem cert_e1123954385306 : check e1123954385306 [[]] .width = true := by decide
def e1123954434074 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123954434074 : Closed e1123954434074 ∧ code e1123954434074 = 5522000945178 := by decide
theorem cert_e1123954434074 : check e1123954434074 [[]] .width = true := by decide
def e1123954434166 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123954434166 : Closed e1123954434166 ∧ code e1123954434166 = 5522000945270 := by decide
theorem cert_e1123954434166 : check e1123954434166 [[]] .width = true := by decide
def e1123954434410 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123954434410 : Closed e1123954434410 ∧ code e1123954434410 = 5522000945514 := by decide
theorem cert_e1123954434410 : check e1123954434410 [[]] .width = true := by decide
def e1123954434458 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123954434458 : Closed e1123954434458 ∧ code e1123954434458 = 5522000945562 := by decide
theorem cert_e1123954434458 : check e1123954434458 [[]] .width = true := by decide
def e1123955204122 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123955204122 : Closed e1123955204122 ∧ code e1123955204122 = 5522001715226 := by decide
theorem cert_e1123955204122 : check e1123955204122 [[]] .width = true := by decide
def e1123955204214 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123955204214 : Closed e1123955204214 ∧ code e1123955204214 = 5522001715318 := by decide
theorem cert_e1123955204214 : check e1123955204214 [[]] .width = true := by decide
def e1123955204458 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123955204458 : Closed e1123955204458 ∧ code e1123955204458 = 5522001715562 := by decide
theorem cert_e1123955204458 : check e1123955204458 [[]] .width = true := by decide
def e1123955204506 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123955204506 : Closed e1123955204506 ∧ code e1123955204506 = 5522001715610 := by decide
theorem cert_e1123955204506 : check e1123955204506 [[]] .width = true := by decide
def e1123955220506 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1123955220506 : Closed e1123955220506 ∧ code e1123955220506 = 5522001731610 := by decide
theorem cert_e1123955220506 : check e1123955220506 [[]] .width = true := by decide
def e1123955220598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1123955220598 : Closed e1123955220598 ∧ code e1123955220598 = 5522001731702 := by decide
theorem cert_e1123955220598 : check e1123955220598 [[]] .width = true := by decide
def e1123955220842 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1123955220842 : Closed e1123955220842 ∧ code e1123955220842 = 5522001731946 := by decide
theorem cert_e1123955220842 : check e1123955220842 [[]] .width = true := by decide
def e1123955220890 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1123955220890 : Closed e1123955220890 ∧ code e1123955220890 = 5522001731994 := by decide
theorem cert_e1123955220890 : check e1123955220890 [[]] .width = true := by decide
def e1124040006510 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1124040006510 : Closed e1124040006510 ∧ code e1124040006510 = 5522086517614 := by decide
theorem cert_e1124040006510 : check e1124040006510 [[]] .sourceHead = true := by decide
def e1124040006518 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1124040006518 : Closed e1124040006518 ∧ code e1124040006518 = 5522086517622 := by decide
theorem cert_e1124040006518 : check e1124040006518 [[]] .sourceHead = true := by decide
def e1124040006582 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1124040006582 : Closed e1124040006582 ∧ code e1124040006582 = 5522086517686 := by decide
theorem cert_e1124040006582 : check e1124040006582 [[]] .sourceHead = true := by decide
def e1124040007022 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1124040007022 : Closed e1124040007022 ∧ code e1124040007022 = 5522086518126 := by decide
theorem cert_e1124040007022 : check e1124040007022 [[]] .sourceHead = true := by decide
def e1124040007030 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1124040007030 : Closed e1124040007030 ∧ code e1124040007030 = 5522086518134 := by decide
theorem cert_e1124040007030 : check e1124040007030 [[]] .sourceHead = true := by decide
def e1124040007086 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1124040007086 : Closed e1124040007086 ∧ code e1124040007086 = 5522086518190 := by decide
theorem cert_e1124040007086 : check e1124040007086 [[]] .sourceHead = true := by decide
def e1124040007098 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1124040007098 : Closed e1124040007098 ∧ code e1124040007098 = 5522086518202 := by decide
theorem cert_e1124040007098 : check e1124040007098 [[]] .sourceHead = true := by decide
def e1124040007126 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1124040007126 : Closed e1124040007126 ∧ code e1124040007126 = 5522086518230 := by decide
theorem cert_e1124040007126 : check e1124040007126 [[]] .sourceHead = true := by decide
def e1124040007130 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1124040007130 : Closed e1124040007130 ∧ code e1124040007130 = 5522086518234 := by decide
theorem cert_e1124040007130 : check e1124040007130 [[]] .sourceHead = true := by decide
def e1124040007350 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1124040007350 : Closed e1124040007350 ∧ code e1124040007350 = 5522086518454 := by decide
theorem cert_e1124040007350 : check e1124040007350 [[]] .sourceHead = true := by decide
def e1124040007382 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1124040007382 : Closed e1124040007382 ∧ code e1124040007382 = 5522086518486 := by decide
theorem cert_e1124040007382 : check e1124040007382 [[]] .sourceHead = true := by decide
def e1124040007386 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1124040007386 : Closed e1124040007386 ∧ code e1124040007386 = 5522086518490 := by decide
theorem cert_e1124040007386 : check e1124040007386 [[]] .sourceHead = true := by decide
def e1124040009582 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1124040009582 : Closed e1124040009582 ∧ code e1124040009582 = 5522086520686 := by decide
theorem cert_e1124040009582 : check e1124040009582 [[]] .sourceHead = true := by decide
def e1124040009590 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1124040009590 : Closed e1124040009590 ∧ code e1124040009590 = 5522086520694 := by decide
theorem cert_e1124040009590 : check e1124040009590 [[]] .sourceHead = true := by decide
def e1124040009654 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1124040009654 : Closed e1124040009654 ∧ code e1124040009654 = 5522086520758 := by decide
theorem cert_e1124040009654 : check e1124040009654 [[]] .sourceHead = true := by decide
def e1124040010990 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124040010990 : Closed e1124040010990 ∧ code e1124040010990 = 5522086522094 := by decide
theorem cert_e1124040010990 : check e1124040010990 [[]] .sourceHead = true := by decide
end Blc.Floor42
