import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211212359230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211212359230 : Closed e1211212359230 ∧ code e1211212359230 = 5609258870334 := by decide
theorem cert_e1211212359230 : check e1211212359230 [[],[],[.under,.under]] .three = true := by decide
def e1211212359286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212359286 : Closed e1211212359286 ∧ code e1211212359286 = 5609258870390 := by decide
theorem cert_e1211212359286 : check e1211212359286 [[],[]] .chain = true := by decide
def e1211212359454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211212359454 : Closed e1211212359454 ∧ code e1211212359454 = 5609258870558 := by decide
theorem cert_e1211212359454 : check e1211212359454 [[],[]] .chain = true := by decide
def e1211212359478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212359478 : Closed e1211212359478 ∧ code e1211212359478 = 5609258870582 := by decide
theorem cert_e1211212359478 : check e1211212359478 [[],[]] .chain = true := by decide
def e1211212359482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212359482 : Closed e1211212359482 ∧ code e1211212359482 = 5609258870586 := by decide
theorem cert_e1211212359482 : check e1211212359482 [[],[]] .chain = true := by decide
def e1211212359566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211212359566 : Closed e1211212359566 ∧ code e1211212359566 = 5609258870670 := by decide
theorem cert_e1211212359566 : check e1211212359566 [[],[]] .chain = true := by decide
def e1211212359622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211212359622 : Closed e1211212359622 ∧ code e1211212359622 = 5609258870726 := by decide
theorem cert_e1211212359622 : check e1211212359622 [[],[],[.under,.under]] .three = true := by decide
def e1211212361966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212361966 : Closed e1211212361966 ∧ code e1211212361966 = 5609258873070 := by decide
theorem cert_e1211212361966 : check e1211212361966 [[],[],[.under,.under]] .three = true := by decide
def e1211212361974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212361974 : Closed e1211212361974 ∧ code e1211212361974 = 5609258873078 := by decide
theorem cert_e1211212361974 : check e1211212361974 [[],[],[.under,.under]] .three = true := by decide
def e1211212362454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211212362454 : Closed e1211212362454 ∧ code e1211212362454 = 5609258873558 := by decide
private def t_e1211212362454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem cert_e1211212362454 : ¬ IsSelfInterpreter e1211212362454 :=
  wSource (t := t_e1211212362454) (replay_sound (ps := []) (t := e1211212362454) (by decide)) (by decide)
def e1211212362458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211212362458 : Closed e1211212362458 ∧ code e1211212362458 = 5609258873562 := by decide
theorem cert_e1211212362458 : check e1211212362458 [[],[],[.under,.under]] .three = true := by decide
def e1211212362474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211212362474 : Closed e1211212362474 ∧ code e1211212362474 = 5609258873578 := by decide
theorem cert_e1211212362474 : check e1211212362474 [[],[],[.under,.under]] .three = true := by decide
def e1211212362526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211212362526 : Closed e1211212362526 ∧ code e1211212362526 = 5609258873630 := by decide
theorem cert_e1211212362526 : check e1211212362526 [[],[],[.under,.under]] .three = true := by decide
def e1211212362550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212362550 : Closed e1211212362550 ∧ code e1211212362550 = 5609258873654 := by decide
theorem cert_e1211212362550 : check e1211212362550 [[],[],[.under,.under]] .three = true := by decide
def e1211212362554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212362554 : Closed e1211212362554 ∧ code e1211212362554 = 5609258873658 := by decide
theorem cert_e1211212362554 : check e1211212362554 [[],[],[.under,.under]] .three = true := by decide
def e1211212362650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211212362650 : Closed e1211212362650 ∧ code e1211212362650 = 5609258873754 := by decide
theorem cert_e1211212362650 : check e1211212362650 [[],[],[.under,.under]] .three = true := by decide
def e1211212362694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211212362694 : Closed e1211212362694 ∧ code e1211212362694 = 5609258873798 := by decide
theorem cert_e1211212362694 : check e1211212362694 [[],[],[.under,.under]] .three = true := by decide
def e1211212522294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212522294 : Closed e1211212522294 ∧ code e1211212522294 = 5609259033398 := by decide
theorem cert_e1211212522294 : check e1211212522294 [[],[],[.under,.under]] .three = true := by decide
def e1211212522298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212522298 : Closed e1211212522298 ∧ code e1211212522298 = 5609259033402 := by decide
theorem cert_e1211212522298 : check e1211212522298 [[],[],[.under,.under]] .three = true := by decide
def e1211212523918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211212523918 : Closed e1211212523918 ∧ code e1211212523918 = 5609259035022 := by decide
theorem cert_e1211212523918 : check e1211212523918 [[],[],[.under,.under]] .three = true := by decide
def e1211212523974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211212523974 : Closed e1211212523974 ∧ code e1211212523974 = 5609259035078 := by decide
theorem cert_e1211212523974 : check e1211212523974 [[],[],[.under,.under]] .three = true := by decide
def e1211212585654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211212585654 : Closed e1211212585654 ∧ code e1211212585654 = 5609259096758 := by decide
theorem cert_e1211212585654 : check e1211212585654 [[],[]] .chain = true := by decide
def e1211212585686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211212585686 : Closed e1211212585686 ∧ code e1211212585686 = 5609259096790 := by decide
theorem cert_e1211212585686 : check e1211212585686 [[],[]] .chain = true := by decide
def e1211212585690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211212585690 : Closed e1211212585690 ∧ code e1211212585690 = 5609259096794 := by decide
theorem cert_e1211212585690 : check e1211212585690 [[],[]] .chain = true := by decide
def e1211212585814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211212585814 : Closed e1211212585814 ∧ code e1211212585814 = 5609259096918 := by decide
theorem cert_e1211212585814 : check e1211212585814 [[],[]] .chain = true := by decide
def e1211212585818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211212585818 : Closed e1211212585818 ∧ code e1211212585818 = 5609259096922 := by decide
theorem cert_e1211212585818 : check e1211212585818 [[],[]] .chain = true := by decide
def e1211212585834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211212585834 : Closed e1211212585834 ∧ code e1211212585834 = 5609259096938 := by decide
theorem cert_e1211212585834 : check e1211212585834 [[],[]] .chain = true := by decide
def e1211212586326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211212586326 : Closed e1211212586326 ∧ code e1211212586326 = 5609259097430 := by decide
theorem cert_e1211212586326 : check e1211212586326 [[],[]] .chain = true := by decide
def e1211212586330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211212586330 : Closed e1211212586330 ∧ code e1211212586330 = 5609259097434 := by decide
theorem cert_e1211212586330 : check e1211212586330 [[],[]] .chain = true := by decide
def e1211212586346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211212586346 : Closed e1211212586346 ∧ code e1211212586346 = 5609259097450 := by decide
theorem cert_e1211212586346 : check e1211212586346 [[],[]] .chain = true := by decide
def e1211212586410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211212586410 : Closed e1211212586410 ∧ code e1211212586410 = 5609259097514 := by decide
theorem cert_e1211212586410 : check e1211212586410 [[],[]] .chain = true := by decide
def e1211212587190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e1211212587190 : Closed e1211212587190 ∧ code e1211212587190 = 5609259098294 := by decide
theorem cert_e1211212587190 : check e1211212587190 [[],[]] .chain = true := by decide
def e1211212587222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211212587222 : Closed e1211212587222 ∧ code e1211212587222 = 5609259098326 := by decide
theorem cert_e1211212587222 : check e1211212587222 [[],[]] .chain = true := by decide
def e1211212587226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211212587226 : Closed e1211212587226 ∧ code e1211212587226 = 5609259098330 := by decide
theorem cert_e1211212587226 : check e1211212587226 [[],[]] .chain = true := by decide
def e1211212587574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211212587574 : Closed e1211212587574 ∧ code e1211212587574 = 5609259098678 := by decide
theorem cert_e1211212587574 : check e1211212587574 [[],[]] .chain = true := by decide
def e1211212587578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211212587578 : Closed e1211212587578 ∧ code e1211212587578 = 5609259098682 := by decide
theorem cert_e1211212587578 : check e1211212587578 [[],[]] .chain = true := by decide
def e1211212587662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211212587662 : Closed e1211212587662 ∧ code e1211212587662 = 5609259098766 := by decide
theorem cert_e1211212587662 : check e1211212587662 [[],[]] .chain = true := by decide
def e1211212587718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211212587718 : Closed e1211212587718 ∧ code e1211212587718 = 5609259098822 := by decide
theorem cert_e1211212587718 : check e1211212587718 [[],[]] .chain = true := by decide
def e1211212587798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211212587798 : Closed e1211212587798 ∧ code e1211212587798 = 5609259098902 := by decide
theorem cert_e1211212587798 : check e1211212587798 [[],[]] .chain = true := by decide
def e1211212587874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211212587874 : Closed e1211212587874 ∧ code e1211212587874 = 5609259098978 := by decide
theorem cert_e1211212587874 : check e1211212587874 [[],[]] .chain = true := by decide
def e1211212587886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211212587886 : Closed e1211212587886 ∧ code e1211212587886 = 5609259098990 := by decide
theorem cert_e1211212587886 : check e1211212587886 [[],[],[.under,.under]] .three = true := by decide
def e1211212587894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211212587894 : Closed e1211212587894 ∧ code e1211212587894 = 5609259098998 := by decide
theorem cert_e1211212587894 : check e1211212587894 [[],[],[.under,.under]] .three = true := by decide
def e1211212587914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211212587914 : Closed e1211212587914 ∧ code e1211212587914 = 5609259099018 := by decide
theorem cert_e1211212587914 : check e1211212587914 [[],[]] .chain = true := by decide
def e1211212587938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211212587938 : Closed e1211212587938 ∧ code e1211212587938 = 5609259099042 := by decide
theorem cert_e1211212587938 : check e1211212587938 [[],[]] .chain = true := by decide
def e1211212587950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211212587950 : Closed e1211212587950 ∧ code e1211212587950 = 5609259099054 := by decide
theorem cert_e1211212587950 : check e1211212587950 [[],[],[.under,.under]] .three = true := by decide
def e1211212587958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211212587958 : Closed e1211212587958 ∧ code e1211212587958 = 5609259099062 := by decide
theorem cert_e1211212587958 : check e1211212587958 [[],[]] .chain = true := by decide
def e1211212587962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211212587962 : Closed e1211212587962 ∧ code e1211212587962 = 5609259099066 := by decide
theorem cert_e1211212587962 : check e1211212587962 [[],[],[.under,.under]] .three = true := by decide
def e1211212587990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211212587990 : Closed e1211212587990 ∧ code e1211212587990 = 5609259099094 := by decide
theorem cert_e1211212587990 : check e1211212587990 [[],[],[.under,.under]] .three = true := by decide
def e1211212587994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211212587994 : Closed e1211212587994 ∧ code e1211212587994 = 5609259099098 := by decide
theorem cert_e1211212587994 : check e1211212587994 [[],[],[.under,.under]] .three = true := by decide
def e1211212588726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211212588726 : Closed e1211212588726 ∧ code e1211212588726 = 5609259099830 := by decide
theorem cert_e1211212588726 : check e1211212588726 [[],[]] .chain = true := by decide
def e1211212588758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211212588758 : Closed e1211212588758 ∧ code e1211212588758 = 5609259099862 := by decide
theorem cert_e1211212588758 : check e1211212588758 [[],[]] .chain = true := by decide
def e1211212588762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211212588762 : Closed e1211212588762 ∧ code e1211212588762 = 5609259099866 := by decide
theorem cert_e1211212588762 : check e1211212588762 [[],[]] .chain = true := by decide
def e1211212588886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211212588886 : Closed e1211212588886 ∧ code e1211212588886 = 5609259099990 := by decide
theorem cert_e1211212588886 : check e1211212588886 [[],[]] .chain = true := by decide
def e1211212588890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211212588890 : Closed e1211212588890 ∧ code e1211212588890 = 5609259099994 := by decide
theorem cert_e1211212588890 : check e1211212588890 [[],[]] .chain = true := by decide
def e1211212588906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211212588906 : Closed e1211212588906 ∧ code e1211212588906 = 5609259100010 := by decide
theorem cert_e1211212588906 : check e1211212588906 [[],[]] .chain = true := by decide
def e1211212589110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211212589110 : Closed e1211212589110 ∧ code e1211212589110 = 5609259100214 := by decide
theorem cert_e1211212589110 : check e1211212589110 [[],[]] .chain = true := by decide
def e1211212589198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211212589198 : Closed e1211212589198 ∧ code e1211212589198 = 5609259100302 := by decide
theorem cert_e1211212589198 : check e1211212589198 [[],[]] .chain = true := by decide
def e1211212589282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211212589282 : Closed e1211212589282 ∧ code e1211212589282 = 5609259100386 := by decide
theorem cert_e1211212589282 : check e1211212589282 [[],[]] .chain = true := by decide
def e1211212589294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211212589294 : Closed e1211212589294 ∧ code e1211212589294 = 5609259100398 := by decide
theorem cert_e1211212589294 : check e1211212589294 [[],[],[.under,.under]] .three = true := by decide
def e1211212589302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211212589302 : Closed e1211212589302 ∧ code e1211212589302 = 5609259100406 := by decide
theorem cert_e1211212589302 : check e1211212589302 [[],[],[.under,.under]] .three = true := by decide
def e1211212589494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211212589494 : Closed e1211212589494 ∧ code e1211212589494 = 5609259100598 := by decide
theorem cert_e1211212589494 : check e1211212589494 [[],[]] .chain = true := by decide
def e1211212589526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211212589526 : Closed e1211212589526 ∧ code e1211212589526 = 5609259100630 := by decide
theorem cert_e1211212589526 : check e1211212589526 [[],[]] .chain = true := by decide
def e1211212589530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211212589530 : Closed e1211212589530 ∧ code e1211212589530 = 5609259100634 := by decide
theorem cert_e1211212589530 : check e1211212589530 [[],[]] .chain = true := by decide
def e1211212589686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211212589686 : Closed e1211212589686 ∧ code e1211212589686 = 5609259100790 := by decide
theorem cert_e1211212589686 : check e1211212589686 [[],[]] .chain = true := by decide
def e1211212589830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212589830 : Closed e1211212589830 ∧ code e1211212589830 = 5609259100934 := by decide
theorem cert_e1211212589830 : check e1211212589830 [[],[]] .chain = true := by decide
def e1211212589854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211212589854 : Closed e1211212589854 ∧ code e1211212589854 = 5609259100958 := by decide
theorem cert_e1211212589854 : check e1211212589854 [[],[],[.under,.under]] .three = true := by decide
def e1211212589878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212589878 : Closed e1211212589878 ∧ code e1211212589878 = 5609259100982 := by decide
theorem cert_e1211212589878 : check e1211212589878 [[],[]] .chain = true := by decide
def e1211212589882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212589882 : Closed e1211212589882 ∧ code e1211212589882 = 5609259100986 := by decide
theorem cert_e1211212589882 : check e1211212589882 [[],[]] .chain = true := by decide
def e1211212589966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211212589966 : Closed e1211212589966 ∧ code e1211212589966 = 5609259101070 := by decide
theorem cert_e1211212589966 : check e1211212589966 [[],[],[.under,.under]] .three = true := by decide
def e1211212590102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211212590102 : Closed e1211212590102 ∧ code e1211212590102 = 5609259101206 := by decide
theorem cert_e1211212590102 : check e1211212590102 [[],[]] .chain = true := by decide
def e1211212590106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211212590106 : Closed e1211212590106 ∧ code e1211212590106 = 5609259101210 := by decide
theorem cert_e1211212590106 : check e1211212590106 [[],[]] .chain = true := by decide
def e1211212590150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211212590150 : Closed e1211212590150 ∧ code e1211212590150 = 5609259101254 := by decide
theorem cert_e1211212590150 : check e1211212590150 [[],[]] .chain = true := by decide
def e1211212590178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211212590178 : Closed e1211212590178 ∧ code e1211212590178 = 5609259101282 := by decide
theorem cert_e1211212590178 : check e1211212590178 [[],[]] .chain = true := by decide
def e1211212590190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211212590190 : Closed e1211212590190 ∧ code e1211212590190 = 5609259101294 := by decide
theorem cert_e1211212590190 : check e1211212590190 [[],[],[.under,.under]] .three = true := by decide
def e1211212590198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211212590198 : Closed e1211212590198 ∧ code e1211212590198 = 5609259101302 := by decide
theorem cert_e1211212590198 : check e1211212590198 [[],[]] .chain = true := by decide
def e1211212590202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211212590202 : Closed e1211212590202 ∧ code e1211212590202 = 5609259101306 := by decide
theorem cert_e1211212590202 : check e1211212590202 [[],[],[.under,.under]] .three = true := by decide
def e1211212590294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211212590294 : Closed e1211212590294 ∧ code e1211212590294 = 5609259101398 := by decide
theorem cert_e1211212590294 : check e1211212590294 [[],[]] .chain = true := by decide
def e1211212590298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211212590298 : Closed e1211212590298 ∧ code e1211212590298 = 5609259101402 := by decide
theorem cert_e1211212590298 : check e1211212590298 [[],[]] .chain = true := by decide
def e1211212590314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211212590314 : Closed e1211212590314 ∧ code e1211212590314 = 5609259101418 := by decide
theorem cert_e1211212590314 : check e1211212590314 [[],[]] .chain = true := by decide
def e1211212590342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212590342 : Closed e1211212590342 ∧ code e1211212590342 = 5609259101446 := by decide
theorem cert_e1211212590342 : check e1211212590342 [[],[]] .chain = true := by decide
def e1211212590366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211212590366 : Closed e1211212590366 ∧ code e1211212590366 = 5609259101470 := by decide
theorem cert_e1211212590366 : check e1211212590366 [[],[],[.under,.under]] .three = true := by decide
def e1211212590390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212590390 : Closed e1211212590390 ∧ code e1211212590390 = 5609259101494 := by decide
theorem cert_e1211212590390 : check e1211212590390 [[],[]] .chain = true := by decide
def e1211212590394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212590394 : Closed e1211212590394 ∧ code e1211212590394 = 5609259101498 := by decide
theorem cert_e1211212590394 : check e1211212590394 [[],[]] .chain = true := by decide
def e1211212590466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212590466 : Closed e1211212590466 ∧ code e1211212590466 = 5609259101570 := by decide
theorem cert_e1211212590466 : check e1211212590466 [[],[]] .chain = true := by decide
def e1211212590478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211212590478 : Closed e1211212590478 ∧ code e1211212590478 = 5609259101582 := by decide
theorem cert_e1211212590478 : check e1211212590478 [[],[]] .chain = true := by decide
def e1211212590490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212590490 : Closed e1211212590490 ∧ code e1211212590490 = 5609259101594 := by decide
theorem cert_e1211212590490 : check e1211212590490 [[],[]] .chain = true := by decide
def e1211212590534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211212590534 : Closed e1211212590534 ∧ code e1211212590534 = 5609259101638 := by decide
theorem cert_e1211212590534 : check e1211212590534 [[],[],[.under,.under]] .three = true := by decide
def e1211212590646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211212590646 : Closed e1211212590646 ∧ code e1211212590646 = 5609259101750 := by decide
theorem cert_e1211212590646 : check e1211212590646 [[],[],[.under,.under]] .three = true := by decide
def e1211212590650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211212590650 : Closed e1211212590650 ∧ code e1211212590650 = 5609259101754 := by decide
theorem cert_e1211212590650 : check e1211212590650 [[],[],[.under,.under]] .three = true := by decide
def e1211212590734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211212590734 : Closed e1211212590734 ∧ code e1211212590734 = 5609259101838 := by decide
theorem cert_e1211212590734 : check e1211212590734 [[],[],[.under,.under]] .three = true := by decide
def e1211212590790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211212590790 : Closed e1211212590790 ∧ code e1211212590790 = 5609259101894 := by decide
theorem cert_e1211212590790 : check e1211212590790 [[],[],[.under,.under]] .three = true := by decide
def e1211212591190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211212591190 : Closed e1211212591190 ∧ code e1211212591190 = 5609259102294 := by decide
theorem cert_e1211212591190 : check e1211212591190 [[],[]] .chain = true := by decide
def e1211212591194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211212591194 : Closed e1211212591194 ∧ code e1211212591194 = 5609259102298 := by decide
theorem cert_e1211212591194 : check e1211212591194 [[],[]] .chain = true := by decide
def e1211212591210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e1211212591210 : Closed e1211212591210 ∧ code e1211212591210 = 5609259102314 := by decide
theorem cert_e1211212591210 : check e1211212591210 [[],[]] .chain = true := by decide
def e1211212591386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211212591386 : Closed e1211212591386 ∧ code e1211212591386 = 5609259102490 := by decide
theorem cert_e1211212591386 : check e1211212591386 [[],[]] .chain = true := by decide
def e1211212591430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211212591430 : Closed e1211212591430 ∧ code e1211212591430 = 5609259102534 := by decide
theorem cert_e1211212591430 : check e1211212591430 [[],[]] .chain = true := by decide
def e1211212591498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211212591498 : Closed e1211212591498 ∧ code e1211212591498 = 5609259102602 := by decide
theorem cert_e1211212591498 : check e1211212591498 [[],[]] .chain = true := by decide
def e1211212591522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211212591522 : Closed e1211212591522 ∧ code e1211212591522 = 5609259102626 := by decide
theorem cert_e1211212591522 : check e1211212591522 [[],[]] .chain = true := by decide
def e1211212591534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211212591534 : Closed e1211212591534 ∧ code e1211212591534 = 5609259102638 := by decide
theorem cert_e1211212591534 : check e1211212591534 [[],[],[.under,.under]] .three = true := by decide
def e1211212591542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1211212591542 : Closed e1211212591542 ∧ code e1211212591542 = 5609259102646 := by decide
theorem cert_e1211212591542 : check e1211212591542 [[],[]] .chain = true := by decide
def e1211212591546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211212591546 : Closed e1211212591546 ∧ code e1211212591546 = 5609259102650 := by decide
theorem cert_e1211212591546 : check e1211212591546 [[],[],[.under,.under]] .three = true := by decide
def e1211212591574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211212591574 : Closed e1211212591574 ∧ code e1211212591574 = 5609259102678 := by decide
theorem cert_e1211212591574 : check e1211212591574 [[],[]] .chain = true := by decide
def e1211212591578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211212591578 : Closed e1211212591578 ∧ code e1211212591578 = 5609259102682 := by decide
theorem cert_e1211212591578 : check e1211212591578 [[],[]] .chain = true := by decide
def e1211212591594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211212591594 : Closed e1211212591594 ∧ code e1211212591594 = 5609259102698 := by decide
theorem cert_e1211212591594 : check e1211212591594 [[],[],[.under,.under]] .three = true := by decide
def e1211212591958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211212591958 : Closed e1211212591958 ∧ code e1211212591958 = 5609259103062 := by decide
theorem cert_e1211212591958 : check e1211212591958 [[],[]] .chain = true := by decide
def e1211212591962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211212591962 : Closed e1211212591962 ∧ code e1211212591962 = 5609259103066 := by decide
theorem cert_e1211212591962 : check e1211212591962 [[],[]] .chain = true := by decide
def e1211212591978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211212591978 : Closed e1211212591978 ∧ code e1211212591978 = 5609259103082 := by decide
theorem cert_e1211212591978 : check e1211212591978 [[],[]] .chain = true := by decide
def e1211212592042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211212592042 : Closed e1211212592042 ∧ code e1211212592042 = 5609259103146 := by decide
theorem cert_e1211212592042 : check e1211212592042 [[],[]] .chain = true := by decide
def e1211212592150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211212592150 : Closed e1211212592150 ∧ code e1211212592150 = 5609259103254 := by decide
theorem cert_e1211212592150 : check e1211212592150 [[],[]] .chain = true := by decide
def e1211212592154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211212592154 : Closed e1211212592154 ∧ code e1211212592154 = 5609259103258 := by decide
theorem cert_e1211212592154 : check e1211212592154 [[],[]] .chain = true := by decide
def e1211212592198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211212592198 : Closed e1211212592198 ∧ code e1211212592198 = 5609259103302 := by decide
theorem cert_e1211212592198 : check e1211212592198 [[],[]] .chain = true := by decide
def e1211212592226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211212592226 : Closed e1211212592226 ∧ code e1211212592226 = 5609259103330 := by decide
theorem cert_e1211212592226 : check e1211212592226 [[],[]] .chain = true := by decide
def e1211212592238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211212592238 : Closed e1211212592238 ∧ code e1211212592238 = 5609259103342 := by decide
theorem cert_e1211212592238 : check e1211212592238 [[],[],[.under,.under]] .three = true := by decide
def e1211212592246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211212592246 : Closed e1211212592246 ∧ code e1211212592246 = 5609259103350 := by decide
theorem cert_e1211212592246 : check e1211212592246 [[],[]] .chain = true := by decide
def e1211212592250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211212592250 : Closed e1211212592250 ∧ code e1211212592250 = 5609259103354 := by decide
theorem cert_e1211212592250 : check e1211212592250 [[],[],[.under,.under]] .three = true := by decide
def e1211212592342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211212592342 : Closed e1211212592342 ∧ code e1211212592342 = 5609259103446 := by decide
theorem cert_e1211212592342 : check e1211212592342 [[],[]] .chain = true := by decide
def e1211212592346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211212592346 : Closed e1211212592346 ∧ code e1211212592346 = 5609259103450 := by decide
theorem cert_e1211212592346 : check e1211212592346 [[],[]] .chain = true := by decide
def e1211212592362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211212592362 : Closed e1211212592362 ∧ code e1211212592362 = 5609259103466 := by decide
theorem cert_e1211212592362 : check e1211212592362 [[],[]] .chain = true := by decide
def e1211212592390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212592390 : Closed e1211212592390 ∧ code e1211212592390 = 5609259103494 := by decide
theorem cert_e1211212592390 : check e1211212592390 [[],[]] .chain = true := by decide
def e1211212592414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211212592414 : Closed e1211212592414 ∧ code e1211212592414 = 5609259103518 := by decide
theorem cert_e1211212592414 : check e1211212592414 [[],[],[.under,.under]] .three = true := by decide
def e1211212592438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212592438 : Closed e1211212592438 ∧ code e1211212592438 = 5609259103542 := by decide
theorem cert_e1211212592438 : check e1211212592438 [[],[]] .chain = true := by decide
def e1211212592442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212592442 : Closed e1211212592442 ∧ code e1211212592442 = 5609259103546 := by decide
theorem cert_e1211212592442 : check e1211212592442 [[],[]] .chain = true := by decide
def e1211212592514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212592514 : Closed e1211212592514 ∧ code e1211212592514 = 5609259103618 := by decide
theorem cert_e1211212592514 : check e1211212592514 [[],[]] .chain = true := by decide
def e1211212592526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211212592526 : Closed e1211212592526 ∧ code e1211212592526 = 5609259103630 := by decide
theorem cert_e1211212592526 : check e1211212592526 [[],[]] .chain = true := by decide
def e1211212592538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212592538 : Closed e1211212592538 ∧ code e1211212592538 = 5609259103642 := by decide
theorem cert_e1211212592538 : check e1211212592538 [[],[]] .chain = true := by decide
def e1211212592582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211212592582 : Closed e1211212592582 ∧ code e1211212592582 = 5609259103686 := by decide
theorem cert_e1211212592582 : check e1211212592582 [[],[],[.under,.under]] .three = true := by decide
def e1211212592650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211212592650 : Closed e1211212592650 ∧ code e1211212592650 = 5609259103754 := by decide
theorem cert_e1211212592650 : check e1211212592650 [[],[]] .chain = true := by decide
def e1211212592694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211212592694 : Closed e1211212592694 ∧ code e1211212592694 = 5609259103798 := by decide
theorem cert_e1211212592694 : check e1211212592694 [[],[]] .chain = true := by decide
def e1211212592698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211212592698 : Closed e1211212592698 ∧ code e1211212592698 = 5609259103802 := by decide
theorem cert_e1211212592698 : check e1211212592698 [[],[]] .chain = true := by decide
def e1211212592746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211212592746 : Closed e1211212592746 ∧ code e1211212592746 = 5609259103850 := by decide
theorem cert_e1211212592746 : check e1211212592746 [[],[]] .chain = true := by decide
def e1211212592770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212592770 : Closed e1211212592770 ∧ code e1211212592770 = 5609259103874 := by decide
theorem cert_e1211212592770 : check e1211212592770 [[],[]] .chain = true := by decide
def e1211212592782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211212592782 : Closed e1211212592782 ∧ code e1211212592782 = 5609259103886 := by decide
theorem cert_e1211212592782 : check e1211212592782 [[],[]] .chain = true := by decide
def e1211212592794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212592794 : Closed e1211212592794 ∧ code e1211212592794 = 5609259103898 := by decide
theorem cert_e1211212592794 : check e1211212592794 [[],[]] .chain = true := by decide
def e1211212592838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211212592838 : Closed e1211212592838 ∧ code e1211212592838 = 5609259103942 := by decide
theorem cert_e1211212592838 : check e1211212592838 [[],[]] .chain = true := by decide
def e1211212592922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211212592922 : Closed e1211212592922 ∧ code e1211212592922 = 5609259104026 := by decide
theorem cert_e1211212592922 : check e1211212592922 [[],[],[.under,.under]] .three = true := by decide
def e1211212592966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211212592966 : Closed e1211212592966 ∧ code e1211212592966 = 5609259104070 := by decide
theorem cert_e1211212592966 : check e1211212592966 [[],[],[.under,.under]] .three = true := by decide
def e1211212593366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211212593366 : Closed e1211212593366 ∧ code e1211212593366 = 5609259104470 := by decide
theorem cert_e1211212593366 : check e1211212593366 [[],[],[.under,.under]] .three = true := by decide
def e1211212593370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211212593370 : Closed e1211212593370 ∧ code e1211212593370 = 5609259104474 := by decide
theorem cert_e1211212593370 : check e1211212593370 [[],[],[.under,.under]] .three = true := by decide
def e1211212593386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211212593386 : Closed e1211212593386 ∧ code e1211212593386 = 5609259104490 := by decide
theorem cert_e1211212593386 : check e1211212593386 [[],[],[.under,.under]] .three = true := by decide
def e1211212593718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211212593718 : Closed e1211212593718 ∧ code e1211212593718 = 5609259104822 := by decide
theorem cert_e1211212593718 : check e1211212593718 [[],[],[.under,.under]] .three = true := by decide
def e1211212593722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211212593722 : Closed e1211212593722 ∧ code e1211212593722 = 5609259104826 := by decide
theorem cert_e1211212593722 : check e1211212593722 [[],[],[.under,.under]] .three = true := by decide
def e1211212593806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211212593806 : Closed e1211212593806 ∧ code e1211212593806 = 5609259104910 := by decide
theorem cert_e1211212593806 : check e1211212593806 [[],[],[.under,.under]] .three = true := by decide
def e1211212593862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211212593862 : Closed e1211212593862 ∧ code e1211212593862 = 5609259104966 := by decide
theorem cert_e1211212593862 : check e1211212593862 [[],[],[.under,.under]] .three = true := by decide
def e1211212593946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211212593946 : Closed e1211212593946 ∧ code e1211212593946 = 5609259105050 := by decide
theorem cert_e1211212593946 : check e1211212593946 [[],[],[.under,.under]] .three = true := by decide
def e1211212593990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211212593990 : Closed e1211212593990 ∧ code e1211212593990 = 5609259105094 := by decide
theorem cert_e1211212593990 : check e1211212593990 [[],[],[.under,.under]] .three = true := by decide
def e1211212595446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211212595446 : Closed e1211212595446 ∧ code e1211212595446 = 5609259106550 := by decide
theorem cert_e1211212595446 : check e1211212595446 [[],[]] .chain = true := by decide
def e1211212595450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211212595450 : Closed e1211212595450 ∧ code e1211212595450 = 5609259106554 := by decide
theorem cert_e1211212595450 : check e1211212595450 [[],[]] .chain = true := by decide
def e1211212595830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211212595830 : Closed e1211212595830 ∧ code e1211212595830 = 5609259106934 := by decide
theorem cert_e1211212595830 : check e1211212595830 [[],[]] .chain = true := by decide
def e1211212596022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212596022 : Closed e1211212596022 ∧ code e1211212596022 = 5609259107126 := by decide
theorem cert_e1211212596022 : check e1211212596022 [[],[]] .chain = true := by decide
def e1211212596026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212596026 : Closed e1211212596026 ∧ code e1211212596026 = 5609259107130 := by decide
theorem cert_e1211212596026 : check e1211212596026 [[],[]] .chain = true := by decide
def e1211212596110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211212596110 : Closed e1211212596110 ∧ code e1211212596110 = 5609259107214 := by decide
theorem cert_e1211212596110 : check e1211212596110 [[],[]] .chain = true := by decide
def e1211212596166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211212596166 : Closed e1211212596166 ∧ code e1211212596166 = 5609259107270 := by decide
theorem cert_e1211212596166 : check e1211212596166 [[],[]] .chain = true := by decide
def e1211212596790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211212596790 : Closed e1211212596790 ∧ code e1211212596790 = 5609259107894 := by decide
theorem cert_e1211212596790 : check e1211212596790 [[],[],[.under,.under]] .three = true := by decide
def e1211212596878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211212596878 : Closed e1211212596878 ∧ code e1211212596878 = 5609259107982 := by decide
theorem cert_e1211212596878 : check e1211212596878 [[],[],[.under,.under]] .three = true := by decide
def e1211212596974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e1211212596974 : Closed e1211212596974 ∧ code e1211212596974 = 5609259108078 := by decide
theorem cert_e1211212596974 : check e1211212596974 [[],[],[.under,.under]] .three = true := by decide
def e1211212596982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211212596982 : Closed e1211212596982 ∧ code e1211212596982 = 5609259108086 := by decide
theorem cert_e1211212596982 : check e1211212596982 [[],[],[.under,.under]] .three = true := by decide
def e1211212597014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211212597014 : Closed e1211212597014 ∧ code e1211212597014 = 5609259108118 := by decide
theorem cert_e1211212597014 : check e1211212597014 [[],[]] .chain = true := by decide
def e1211212597110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211212597110 : Closed e1211212597110 ∧ code e1211212597110 = 5609259108214 := by decide
theorem cert_e1211212597110 : check e1211212597110 [[],[]] .chain = true := by decide
def e1211212597130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211212597130 : Closed e1211212597130 ∧ code e1211212597130 = 5609259108234 := by decide
theorem cert_e1211212597130 : check e1211212597130 [[],[]] .chain = true := by decide
def e1211212597166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e1211212597166 : Closed e1211212597166 ∧ code e1211212597166 = 5609259108270 := by decide
theorem cert_e1211212597166 : check e1211212597166 [[],[],[.under,.under]] .three = true := by decide
end Blc.Floor42
