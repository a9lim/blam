import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204228342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204228342 : Closed e1211204228342 ∧ code e1211204228342 = 5609250739446 := by decide
theorem cert_e1211204228342 : check e1211204228342 [[],[]] .chain = true := by decide
def e1211204228718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204228718 : Closed e1211204228718 ∧ code e1211204228718 = 5609250739822 := by decide
theorem cert_e1211204228718 : check e1211204228718 [[],[]] .chain = true := by decide
def e1211204228730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204228730 : Closed e1211204228730 ∧ code e1211204228730 = 5609250739834 := by decide
theorem cert_e1211204228730 : check e1211204228730 [[],[]] .chain = true := by decide
def e1211204228870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204228870 : Closed e1211204228870 ∧ code e1211204228870 = 5609250739974 := by decide
theorem cert_e1211204228870 : check e1211204228870 [[],[]] .chain = true := by decide
def e1211204228894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211204228894 : Closed e1211204228894 ∧ code e1211204228894 = 5609250739998 := by decide
theorem cert_e1211204228894 : check e1211204228894 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204228918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204228918 : Closed e1211204228918 ∧ code e1211204228918 = 5609250740022 := by decide
theorem cert_e1211204228918 : check e1211204228918 [[],[]] .chain = true := by decide
def e1211204228922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204228922 : Closed e1211204228922 ∧ code e1211204228922 = 5609250740026 := by decide
theorem cert_e1211204228922 : check e1211204228922 [[],[]] .chain = true := by decide
def e1211204229166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211204229166 : Closed e1211204229166 ∧ code e1211204229166 = 5609250740270 := by decide
theorem cert_e1211204229166 : check e1211204229166 [[],[]] .chain = true := by decide
def e1211204229358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211204229358 : Closed e1211204229358 ∧ code e1211204229358 = 5609250740462 := by decide
theorem cert_e1211204229358 : check e1211204229358 [[],[]] .chain = true := by decide
def e1211204229366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211204229366 : Closed e1211204229366 ∧ code e1211204229366 = 5609250740470 := by decide
theorem cert_e1211204229366 : check e1211204229366 [[],[]] .chain = true := by decide
def e1211204229550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211204229550 : Closed e1211204229550 ∧ code e1211204229550 = 5609250740654 := by decide
theorem cert_e1211204229550 : check e1211204229550 [[],[]] .chain = true := by decide
def e1211204229562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211204229562 : Closed e1211204229562 ∧ code e1211204229562 = 5609250740666 := by decide
theorem cert_e1211204229562 : check e1211204229562 [[],[]] .chain = true := by decide
def e1211204229610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211204229610 : Closed e1211204229610 ∧ code e1211204229610 = 5609250740714 := by decide
theorem cert_e1211204229610 : check e1211204229610 [[],[]] .chain = true := by decide
def e1211204229742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204229742 : Closed e1211204229742 ∧ code e1211204229742 = 5609250740846 := by decide
theorem cert_e1211204229742 : check e1211204229742 [[],[]] .chain = true := by decide
def e1211204229754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204229754 : Closed e1211204229754 ∧ code e1211204229754 = 5609250740858 := by decide
theorem cert_e1211204229754 : check e1211204229754 [[],[]] .chain = true := by decide
def e1211204229918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211204229918 : Closed e1211204229918 ∧ code e1211204229918 = 5609250741022 := by decide
theorem cert_e1211204229918 : check e1211204229918 [[],[]] .chain = true := by decide
def e1211204230018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204230018 : Closed e1211204230018 ∧ code e1211204230018 = 5609250741122 := by decide
theorem cert_e1211204230018 : check e1211204230018 [[],[]] .chain = true := by decide
def e1211204230030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211204230030 : Closed e1211204230030 ∧ code e1211204230030 = 5609250741134 := by decide
theorem cert_e1211204230030 : check e1211204230030 [[],[]] .chain = true := by decide
def e1211204230042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204230042 : Closed e1211204230042 ∧ code e1211204230042 = 5609250741146 := by decide
theorem cert_e1211204230042 : check e1211204230042 [[],[]] .chain = true := by decide
def e1211204230166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211204230166 : Closed e1211204230166 ∧ code e1211204230166 = 5609250741270 := by decide
theorem cert_e1211204230166 : check e1211204230166 [[],[]] .chain = true := by decide
def e1211204230170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211204230170 : Closed e1211204230170 ∧ code e1211204230170 = 5609250741274 := by decide
theorem cert_e1211204230170 : check e1211204230170 [[],[]] .chain = true := by decide
def e1211204230214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211204230214 : Closed e1211204230214 ∧ code e1211204230214 = 5609250741318 := by decide
theorem cert_e1211204230214 : check e1211204230214 [[],[]] .chain = true := by decide
def e1211204230242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211204230242 : Closed e1211204230242 ∧ code e1211204230242 = 5609250741346 := by decide
theorem cert_e1211204230242 : check e1211204230242 [[],[]] .chain = true := by decide
def e1211204230254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211204230254 : Closed e1211204230254 ∧ code e1211204230254 = 5609250741358 := by decide
theorem cert_e1211204230254 : check e1211204230254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204230262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211204230262 : Closed e1211204230262 ∧ code e1211204230262 = 5609250741366 := by decide
theorem cert_e1211204230262 : check e1211204230262 [[],[]] .chain = true := by decide
def e1211204230266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211204230266 : Closed e1211204230266 ∧ code e1211204230266 = 5609250741370 := by decide
theorem cert_e1211204230266 : check e1211204230266 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204230358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211204230358 : Closed e1211204230358 ∧ code e1211204230358 = 5609250741462 := by decide
theorem cert_e1211204230358 : check e1211204230358 [[],[]] .chain = true := by decide
def e1211204230362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211204230362 : Closed e1211204230362 ∧ code e1211204230362 = 5609250741466 := by decide
theorem cert_e1211204230362 : check e1211204230362 [[],[]] .chain = true := by decide
def e1211204230378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211204230378 : Closed e1211204230378 ∧ code e1211204230378 = 5609250741482 := by decide
theorem cert_e1211204230378 : check e1211204230378 [[],[]] .chain = true := by decide
def e1211204230406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204230406 : Closed e1211204230406 ∧ code e1211204230406 = 5609250741510 := by decide
theorem cert_e1211204230406 : check e1211204230406 [[],[]] .chain = true := by decide
def e1211204230430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211204230430 : Closed e1211204230430 ∧ code e1211204230430 = 5609250741534 := by decide
theorem cert_e1211204230430 : check e1211204230430 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204230454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204230454 : Closed e1211204230454 ∧ code e1211204230454 = 5609250741558 := by decide
theorem cert_e1211204230454 : check e1211204230454 [[],[]] .chain = true := by decide
def e1211204230458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204230458 : Closed e1211204230458 ∧ code e1211204230458 = 5609250741562 := by decide
theorem cert_e1211204230458 : check e1211204230458 [[],[]] .chain = true := by decide
def e1211204230530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204230530 : Closed e1211204230530 ∧ code e1211204230530 = 5609250741634 := by decide
theorem cert_e1211204230530 : check e1211204230530 [[],[]] .chain = true := by decide
def e1211204230542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211204230542 : Closed e1211204230542 ∧ code e1211204230542 = 5609250741646 := by decide
theorem cert_e1211204230542 : check e1211204230542 [[],[]] .chain = true := by decide
def e1211204230554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204230554 : Closed e1211204230554 ∧ code e1211204230554 = 5609250741658 := by decide
theorem cert_e1211204230554 : check e1211204230554 [[],[]] .chain = true := by decide
def e1211204230598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211204230598 : Closed e1211204230598 ∧ code e1211204230598 = 5609250741702 := by decide
theorem cert_e1211204230598 : check e1211204230598 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204231350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))) (.var 1))))))
theorem wire_e1211204231350 : Closed e1211204231350 ∧ code e1211204231350 = 5609250742454 := by decide
theorem cert_e1211204231350 : check e1211204231350 [[],[]] .chain = true := by decide
def e1211204231382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))) (.var 1))))))
theorem wire_e1211204231382 : Closed e1211204231382 ∧ code e1211204231382 = 5609250742486 := by decide
theorem cert_e1211204231382 : check e1211204231382 [[],[]] .chain = true := by decide
def e1211204231386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1))) (.var 0))))))
theorem wire_e1211204231386 : Closed e1211204231386 ∧ code e1211204231386 = 5609250742490 := by decide
theorem cert_e1211204231386 : check e1211204231386 [[],[]] .chain = true := by decide
def e1211204231734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211204231734 : Closed e1211204231734 ∧ code e1211204231734 = 5609250742838 := by decide
theorem cert_e1211204231734 : check e1211204231734 [[],[]] .chain = true := by decide
def e1211204231738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211204231738 : Closed e1211204231738 ∧ code e1211204231738 = 5609250742842 := by decide
theorem cert_e1211204231738 : check e1211204231738 [[],[]] .chain = true := by decide
def e1211204231822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211204231822 : Closed e1211204231822 ∧ code e1211204231822 = 5609250742926 := by decide
theorem cert_e1211204231822 : check e1211204231822 [[],[]] .chain = true := by decide
def e1211204231878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211204231878 : Closed e1211204231878 ∧ code e1211204231878 = 5609250742982 := by decide
theorem cert_e1211204231878 : check e1211204231878 [[],[]] .chain = true := by decide
def e1211204231958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211204231958 : Closed e1211204231958 ∧ code e1211204231958 = 5609250743062 := by decide
theorem cert_e1211204231958 : check e1211204231958 [[],[]] .chain = true := by decide
def e1211204232034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211204232034 : Closed e1211204232034 ∧ code e1211204232034 = 5609250743138 := by decide
theorem cert_e1211204232034 : check e1211204232034 [[],[]] .chain = true := by decide
def e1211204232046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e1211204232046 : Closed e1211204232046 ∧ code e1211204232046 = 5609250743150 := by decide
theorem cert_e1211204232046 : check e1211204232046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204232054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e1211204232054 : Closed e1211204232054 ∧ code e1211204232054 = 5609250743158 := by decide
theorem cert_e1211204232054 : checkPay e1211204232054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204232074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211204232074 : Closed e1211204232074 ∧ code e1211204232074 = 5609250743178 := by decide
theorem cert_e1211204232074 : check e1211204232074 [[],[]] .chain = true := by decide
def e1211204232098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211204232098 : Closed e1211204232098 ∧ code e1211204232098 = 5609250743202 := by decide
theorem cert_e1211204232098 : check e1211204232098 [[],[]] .chain = true := by decide
def e1211204232110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e1211204232110 : Closed e1211204232110 ∧ code e1211204232110 = 5609250743214 := by decide
theorem cert_e1211204232110 : check e1211204232110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204232118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.var 1))))))
theorem wire_e1211204232118 : Closed e1211204232118 ∧ code e1211204232118 = 5609250743222 := by decide
theorem cert_e1211204232118 : check e1211204232118 [[],[]] .chain = true := by decide
def e1211204232122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e1211204232122 : Closed e1211204232122 ∧ code e1211204232122 = 5609250743226 := by decide
theorem cert_e1211204232122 : check e1211204232122 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204232150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e1211204232150 : Closed e1211204232150 ∧ code e1211204232150 = 5609250743254 := by decide
theorem cert_e1211204232150 : checkPay e1211204232150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e1211204232154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e1211204232154 : Closed e1211204232154 ∧ code e1211204232154 = 5609250743258 := by decide
theorem cert_e1211204232154 : check e1211204232154 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204232886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e1211204232886 : Closed e1211204232886 ∧ code e1211204232886 = 5609250743990 := by decide
theorem cert_e1211204232886 : check e1211204232886 [[],[]] .chain = true := by decide
def e1211204232918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e1211204232918 : Closed e1211204232918 ∧ code e1211204232918 = 5609250744022 := by decide
theorem cert_e1211204232918 : check e1211204232918 [[],[]] .chain = true := by decide
def e1211204232922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e1211204232922 : Closed e1211204232922 ∧ code e1211204232922 = 5609250744026 := by decide
theorem cert_e1211204232922 : check e1211204232922 [[],[]] .chain = true := by decide
def e1211204233046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211204233046 : Closed e1211204233046 ∧ code e1211204233046 = 5609250744150 := by decide
theorem cert_e1211204233046 : check e1211204233046 [[],[]] .chain = true := by decide
def e1211204233050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211204233050 : Closed e1211204233050 ∧ code e1211204233050 = 5609250744154 := by decide
theorem cert_e1211204233050 : check e1211204233050 [[],[]] .chain = true := by decide
def e1211204233066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211204233066 : Closed e1211204233066 ∧ code e1211204233066 = 5609250744170 := by decide
theorem cert_e1211204233066 : check e1211204233066 [[],[]] .chain = true := by decide
def e1211204233270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211204233270 : Closed e1211204233270 ∧ code e1211204233270 = 5609250744374 := by decide
theorem cert_e1211204233270 : check e1211204233270 [[],[]] .chain = true := by decide
def e1211204233358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211204233358 : Closed e1211204233358 ∧ code e1211204233358 = 5609250744462 := by decide
theorem cert_e1211204233358 : check e1211204233358 [[],[]] .chain = true := by decide
def e1211204233442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211204233442 : Closed e1211204233442 ∧ code e1211204233442 = 5609250744546 := by decide
theorem cert_e1211204233442 : check e1211204233442 [[],[]] .chain = true := by decide
def e1211204233454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211204233454 : Closed e1211204233454 ∧ code e1211204233454 = 5609250744558 := by decide
theorem cert_e1211204233454 : check e1211204233454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204233462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211204233462 : Closed e1211204233462 ∧ code e1211204233462 = 5609250744566 := by decide
theorem cert_e1211204233462 : check e1211204233462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204233654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211204233654 : Closed e1211204233654 ∧ code e1211204233654 = 5609250744758 := by decide
theorem cert_e1211204233654 : check e1211204233654 [[],[]] .chain = true := by decide
def e1211204233686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211204233686 : Closed e1211204233686 ∧ code e1211204233686 = 5609250744790 := by decide
theorem cert_e1211204233686 : check e1211204233686 [[],[]] .chain = true := by decide
def e1211204233690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211204233690 : Closed e1211204233690 ∧ code e1211204233690 = 5609250744794 := by decide
theorem cert_e1211204233690 : check e1211204233690 [[],[]] .chain = true := by decide
def e1211204233846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204233846 : Closed e1211204233846 ∧ code e1211204233846 = 5609250744950 := by decide
theorem cert_e1211204233846 : check e1211204233846 [[],[]] .chain = true := by decide
def e1211204233990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204233990 : Closed e1211204233990 ∧ code e1211204233990 = 5609250745094 := by decide
theorem cert_e1211204233990 : check e1211204233990 [[],[]] .chain = true := by decide
def e1211204234014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211204234014 : Closed e1211204234014 ∧ code e1211204234014 = 5609250745118 := by decide
theorem cert_e1211204234014 : check e1211204234014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211204234038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204234038 : Closed e1211204234038 ∧ code e1211204234038 = 5609250745142 := by decide
theorem cert_e1211204234038 : check e1211204234038 [[],[]] .chain = true := by decide
def e1211204234042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204234042 : Closed e1211204234042 ∧ code e1211204234042 = 5609250745146 := by decide
theorem cert_e1211204234042 : check e1211204234042 [[],[]] .chain = true := by decide
def e1211204234126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211204234126 : Closed e1211204234126 ∧ code e1211204234126 = 5609250745230 := by decide
theorem cert_e1211204234126 : check e1211204234126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204234262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211204234262 : Closed e1211204234262 ∧ code e1211204234262 = 5609250745366 := by decide
theorem cert_e1211204234262 : check e1211204234262 [[],[]] .chain = true := by decide
def e1211204234266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211204234266 : Closed e1211204234266 ∧ code e1211204234266 = 5609250745370 := by decide
theorem cert_e1211204234266 : check e1211204234266 [[],[]] .chain = true := by decide
def e1211204234310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211204234310 : Closed e1211204234310 ∧ code e1211204234310 = 5609250745414 := by decide
theorem cert_e1211204234310 : check e1211204234310 [[],[]] .chain = true := by decide
def e1211204234338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211204234338 : Closed e1211204234338 ∧ code e1211204234338 = 5609250745442 := by decide
theorem cert_e1211204234338 : check e1211204234338 [[],[]] .chain = true := by decide
def e1211204234350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211204234350 : Closed e1211204234350 ∧ code e1211204234350 = 5609250745454 := by decide
theorem cert_e1211204234350 : check e1211204234350 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204234358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211204234358 : Closed e1211204234358 ∧ code e1211204234358 = 5609250745462 := by decide
theorem cert_e1211204234358 : check e1211204234358 [[],[]] .chain = true := by decide
def e1211204234362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211204234362 : Closed e1211204234362 ∧ code e1211204234362 = 5609250745466 := by decide
theorem cert_e1211204234362 : check e1211204234362 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204234454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211204234454 : Closed e1211204234454 ∧ code e1211204234454 = 5609250745558 := by decide
theorem cert_e1211204234454 : check e1211204234454 [[],[]] .chain = true := by decide
def e1211204234458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211204234458 : Closed e1211204234458 ∧ code e1211204234458 = 5609250745562 := by decide
theorem cert_e1211204234458 : check e1211204234458 [[],[]] .chain = true := by decide
def e1211204234474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211204234474 : Closed e1211204234474 ∧ code e1211204234474 = 5609250745578 := by decide
theorem cert_e1211204234474 : check e1211204234474 [[],[]] .chain = true := by decide
def e1211204234502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204234502 : Closed e1211204234502 ∧ code e1211204234502 = 5609250745606 := by decide
theorem cert_e1211204234502 : check e1211204234502 [[],[]] .chain = true := by decide
def e1211204234526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211204234526 : Closed e1211204234526 ∧ code e1211204234526 = 5609250745630 := by decide
theorem cert_e1211204234526 : check e1211204234526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204234550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204234550 : Closed e1211204234550 ∧ code e1211204234550 = 5609250745654 := by decide
theorem cert_e1211204234550 : check e1211204234550 [[],[]] .chain = true := by decide
def e1211204234554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204234554 : Closed e1211204234554 ∧ code e1211204234554 = 5609250745658 := by decide
theorem cert_e1211204234554 : check e1211204234554 [[],[]] .chain = true := by decide
def e1211204234626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204234626 : Closed e1211204234626 ∧ code e1211204234626 = 5609250745730 := by decide
theorem cert_e1211204234626 : check e1211204234626 [[],[]] .chain = true := by decide
def e1211204234638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211204234638 : Closed e1211204234638 ∧ code e1211204234638 = 5609250745742 := by decide
theorem cert_e1211204234638 : check e1211204234638 [[],[]] .chain = true := by decide
def e1211204234650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204234650 : Closed e1211204234650 ∧ code e1211204234650 = 5609250745754 := by decide
theorem cert_e1211204234650 : check e1211204234650 [[],[]] .chain = true := by decide
def e1211204234694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211204234694 : Closed e1211204234694 ∧ code e1211204234694 = 5609250745798 := by decide
theorem cert_e1211204234694 : check e1211204234694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204234806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211204234806 : Closed e1211204234806 ∧ code e1211204234806 = 5609250745910 := by decide
theorem cert_e1211204234806 : checkPay e1211204234806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204234810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211204234810 : Closed e1211204234810 ∧ code e1211204234810 = 5609250745914 := by decide
theorem cert_e1211204234810 : check e1211204234810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211204234894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211204234894 : Closed e1211204234894 ∧ code e1211204234894 = 5609250745998 := by decide
theorem cert_e1211204234894 : check e1211204234894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204234950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211204234950 : Closed e1211204234950 ∧ code e1211204234950 = 5609250746054 := by decide
theorem cert_e1211204234950 : check e1211204234950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204240366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))) (.var 2))))))
theorem wire_e1211204240366 : Closed e1211204240366 ∧ code e1211204240366 = 5609250751470 := by decide
theorem cert_e1211204240366 : check e1211204240366 [[],[]] .chain = true := by decide
def e1211204240374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))) (.var 1))))))
theorem wire_e1211204240374 : Closed e1211204240374 ∧ code e1211204240374 = 5609250751478 := by decide
theorem cert_e1211204240374 : check e1211204240374 [[],[]] .chain = true := by decide
def e1211204242670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204242670 : Closed e1211204242670 ∧ code e1211204242670 = 5609250753774 := by decide
theorem cert_e1211204242670 : check e1211204242670 [[],[]] .chain = true := by decide
def e1211204242678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204242678 : Closed e1211204242678 ∧ code e1211204242678 = 5609250753782 := by decide
theorem cert_e1211204242678 : check e1211204242678 [[],[]] .chain = true := by decide
def e1211204243230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.lam (.var 3)))))))
theorem wire_e1211204243230 : Closed e1211204243230 ∧ code e1211204243230 = 5609250754334 := by decide
theorem cert_e1211204243230 : check e1211204243230 [[],[]] .chain = true := by decide
def e1211204243342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.lam (.var 2)))))))
theorem wire_e1211204243342 : Closed e1211204243342 ∧ code e1211204243342 = 5609250754446 := by decide
theorem cert_e1211204243342 : check e1211204243342 [[],[]] .chain = true := by decide
def e1211204247086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211204247086 : Closed e1211204247086 ∧ code e1211204247086 = 5609250758190 := by decide
theorem cert_e1211204247086 : check e1211204247086 [[],[]] .chain = true := by decide
def e1211204247278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))) (.var 2))))))
theorem wire_e1211204247278 : Closed e1211204247278 ∧ code e1211204247278 = 5609250758382 := by decide
theorem cert_e1211204247278 : check e1211204247278 [[],[]] .chain = true := by decide
def e1211204247286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.var 1))))))
theorem wire_e1211204247286 : Closed e1211204247286 ∧ code e1211204247286 = 5609250758390 := by decide
theorem cert_e1211204247286 : check e1211204247286 [[],[]] .chain = true := by decide
def e1211204247318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211204247318 : Closed e1211204247318 ∧ code e1211204247318 = 5609250758422 := by decide
theorem cert_e1211204247318 : check e1211204247318 [[],[]] .chain = true := by decide
def e1211204247414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.var 1))))))
theorem wire_e1211204247414 : Closed e1211204247414 ∧ code e1211204247414 = 5609250758518 := by decide
theorem cert_e1211204247414 : check e1211204247414 [[],[]] .chain = true := by decide
def e1211204249374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211204249374 : Closed e1211204249374 ∧ code e1211204249374 = 5609250760478 := by decide
theorem cert_e1211204249374 : check e1211204249374 [[],[]] .chain = true := by decide
def e1211204249486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211204249486 : Closed e1211204249486 ∧ code e1211204249486 = 5609250760590 := by decide
theorem cert_e1211204249486 : check e1211204249486 [[],[]] .chain = true := by decide
def e1211204253758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.lam (.var 4))))))))
theorem wire_e1211204253758 : Closed e1211204253758 ∧ code e1211204253758 = 5609250764862 := by decide
theorem cert_e1211204253758 : check e1211204253758 [[],[]] .chain = true := by decide
def e1211204254178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211204254178 : Closed e1211204254178 ∧ code e1211204254178 = 5609250765282 := by decide
theorem cert_e1211204254178 : check e1211204254178 [[],[]] .chain = true := by decide
def e1211204254190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211204254190 : Closed e1211204254190 ∧ code e1211204254190 = 5609250765294 := by decide
theorem cert_e1211204254190 : check e1211204254190 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204254750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.lam (.var 3))))))))
theorem wire_e1211204254750 : Closed e1211204254750 ∧ code e1211204254750 = 5609250765854 := by decide
theorem cert_e1211204254750 : check e1211204254750 [[],[]] .chain = true := by decide
def e1211204254946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211204254946 : Closed e1211204254946 ∧ code e1211204254946 = 5609250766050 := by decide
theorem cert_e1211204254946 : check e1211204254946 [[],[]] .chain = true := by decide
def e1211204254958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204254958 : Closed e1211204254958 ∧ code e1211204254958 = 5609250766062 := by decide
theorem cert_e1211204254958 : check e1211204254958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204254966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204254966 : Closed e1211204254966 ∧ code e1211204254966 = 5609250766070 := by decide
theorem cert_e1211204254966 : check e1211204254966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204262766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e1211204262766 : Closed e1211204262766 ∧ code e1211204262766 = 5609250773870 := by decide
theorem cert_e1211204262766 : check e1211204262766 [[],[]] .chain = true := by decide
def e1211204262774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e1211204262774 : Closed e1211204262774 ∧ code e1211204262774 = 5609250773878 := by decide
theorem cert_e1211204262774 : check e1211204262774 [[],[]] .chain = true := by decide
def e1211204262838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e1211204262838 : Closed e1211204262838 ∧ code e1211204262838 = 5609250773942 := by decide
theorem cert_e1211204262838 : check e1211204262838 [[],[]] .chain = true := by decide
def e1211204263278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e1211204263278 : Closed e1211204263278 ∧ code e1211204263278 = 5609250774382 := by decide
theorem cert_e1211204263278 : check e1211204263278 [[],[]] .chain = true := by decide
def e1211204263286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211204263286 : Closed e1211204263286 ∧ code e1211204263286 = 5609250774390 := by decide
theorem cert_e1211204263286 : check e1211204263286 [[],[]] .chain = true := by decide
def e1211204263342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e1211204263342 : Closed e1211204263342 ∧ code e1211204263342 = 5609250774446 := by decide
theorem cert_e1211204263342 : check e1211204263342 [[],[]] .chain = true := by decide
def e1211204263354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211204263354 : Closed e1211204263354 ∧ code e1211204263354 = 5609250774458 := by decide
theorem cert_e1211204263354 : check e1211204263354 [[],[]] .chain = true := by decide
def e1211204263382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211204263382 : Closed e1211204263382 ∧ code e1211204263382 = 5609250774486 := by decide
theorem cert_e1211204263382 : check e1211204263382 [[],[]] .chain = true := by decide
def e1211204263386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211204263386 : Closed e1211204263386 ∧ code e1211204263386 = 5609250774490 := by decide
theorem cert_e1211204263386 : check e1211204263386 [[],[]] .chain = true := by decide
def e1211204263606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211204263606 : Closed e1211204263606 ∧ code e1211204263606 = 5609250774710 := by decide
theorem cert_e1211204263606 : check e1211204263606 [[],[]] .chain = true := by decide
def e1211204263638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211204263638 : Closed e1211204263638 ∧ code e1211204263638 = 5609250774742 := by decide
theorem cert_e1211204263638 : check e1211204263638 [[],[]] .chain = true := by decide
def e1211204263642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e1211204263642 : Closed e1211204263642 ∧ code e1211204263642 = 5609250774746 := by decide
theorem cert_e1211204263642 : check e1211204263642 [[],[]] .chain = true := by decide
def e1211204265838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e1211204265838 : Closed e1211204265838 ∧ code e1211204265838 = 5609250776942 := by decide
theorem cert_e1211204265838 : check e1211204265838 [[],[]] .chain = true := by decide
def e1211204265846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211204265846 : Closed e1211204265846 ∧ code e1211204265846 = 5609250776950 := by decide
theorem cert_e1211204265846 : check e1211204265846 [[],[]] .chain = true := by decide
def e1211204265910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211204265910 : Closed e1211204265910 ∧ code e1211204265910 = 5609250777014 := by decide
theorem cert_e1211204265910 : check e1211204265910 [[],[]] .chain = true := by decide
def e1211204267246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204267246 : Closed e1211204267246 ∧ code e1211204267246 = 5609250778350 := by decide
theorem cert_e1211204267246 : check e1211204267246 [[],[]] .chain = true := by decide
def e1211204267254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204267254 : Closed e1211204267254 ∧ code e1211204267254 = 5609250778358 := by decide
theorem cert_e1211204267254 : check e1211204267254 [[],[]] .chain = true := by decide
def e1211204267638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204267638 : Closed e1211204267638 ∧ code e1211204267638 = 5609250778742 := by decide
theorem cert_e1211204267638 : check e1211204267638 [[],[]] .chain = true := by decide
def e1211204268142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 2))))))
theorem wire_e1211204268142 : Closed e1211204268142 ∧ code e1211204268142 = 5609250779246 := by decide
theorem cert_e1211204268142 : check e1211204268142 [[],[]] .chain = true := by decide
def e1211204268318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.lam (.var 3)))))))
theorem wire_e1211204268318 : Closed e1211204268318 ∧ code e1211204268318 = 5609250779422 := by decide
theorem cert_e1211204268318 : check e1211204268318 [[],[]] .chain = true := by decide
def e1211204268514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.lam (.var 0)))))))
theorem wire_e1211204268514 : Closed e1211204268514 ∧ code e1211204268514 = 5609250779618 := by decide
theorem cert_e1211204268514 : check e1211204268514 [[],[]] .chain = true := by decide
def e1211204268526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211204268526 : Closed e1211204268526 ∧ code e1211204268526 = 5609250779630 := by decide
theorem cert_e1211204268526 : check e1211204268526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204268910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211204268910 : Closed e1211204268910 ∧ code e1211204268910 = 5609250780014 := by decide
theorem cert_e1211204268910 : check e1211204268910 [[],[]] .chain = true := by decide
def e1211204268918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211204268918 : Closed e1211204268918 ∧ code e1211204268918 = 5609250780022 := by decide
theorem cert_e1211204268918 : check e1211204268918 [[],[]] .chain = true := by decide
def e1211204268974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211204268974 : Closed e1211204268974 ∧ code e1211204268974 = 5609250780078 := by decide
theorem cert_e1211204268974 : check e1211204268974 [[],[]] .chain = true := by decide
def e1211204268986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211204268986 : Closed e1211204268986 ∧ code e1211204268986 = 5609250780090 := by decide
theorem cert_e1211204268986 : check e1211204268986 [[],[]] .chain = true := by decide
def e1211204269014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211204269014 : Closed e1211204269014 ∧ code e1211204269014 = 5609250780118 := by decide
theorem cert_e1211204269014 : check e1211204269014 [[],[]] .chain = true := by decide
def e1211204269018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211204269018 : Closed e1211204269018 ∧ code e1211204269018 = 5609250780122 := by decide
theorem cert_e1211204269018 : check e1211204269018 [[],[]] .chain = true := by decide
def e1211204269294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204269294 : Closed e1211204269294 ∧ code e1211204269294 = 5609250780398 := by decide
theorem cert_e1211204269294 : check e1211204269294 [[],[]] .chain = true := by decide
def e1211204269302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204269302 : Closed e1211204269302 ∧ code e1211204269302 = 5609250780406 := by decide
theorem cert_e1211204269302 : check e1211204269302 [[],[]] .chain = true := by decide
def e1211204269678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204269678 : Closed e1211204269678 ∧ code e1211204269678 = 5609250780782 := by decide
theorem cert_e1211204269678 : check e1211204269678 [[],[]] .chain = true := by decide
def e1211204269690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204269690 : Closed e1211204269690 ∧ code e1211204269690 = 5609250780794 := by decide
theorem cert_e1211204269690 : check e1211204269690 [[],[]] .chain = true := by decide
def e1211204269830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204269830 : Closed e1211204269830 ∧ code e1211204269830 = 5609250780934 := by decide
theorem cert_e1211204269830 : check e1211204269830 [[],[]] .chain = true := by decide
def e1211204269854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211204269854 : Closed e1211204269854 ∧ code e1211204269854 = 5609250780958 := by decide
theorem cert_e1211204269854 : check e1211204269854 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204269878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204269878 : Closed e1211204269878 ∧ code e1211204269878 = 5609250780982 := by decide
theorem cert_e1211204269878 : check e1211204269878 [[],[]] .chain = true := by decide
def e1211204269882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204269882 : Closed e1211204269882 ∧ code e1211204269882 = 5609250780986 := by decide
theorem cert_e1211204269882 : check e1211204269882 [[],[]] .chain = true := by decide
def e1211204270134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))) (.var 1))))))
theorem wire_e1211204270134 : Closed e1211204270134 ∧ code e1211204270134 = 5609250781238 := by decide
theorem cert_e1211204270134 : check e1211204270134 [[],[]] .chain = true := by decide
def e1211204270222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.lam (.var 2)))))))
theorem wire_e1211204270222 : Closed e1211204270222 ∧ code e1211204270222 = 5609250781326 := by decide
theorem cert_e1211204270222 : check e1211204270222 [[],[]] .chain = true := by decide
def e1211204270306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.lam (.var 0)))))))
theorem wire_e1211204270306 : Closed e1211204270306 ∧ code e1211204270306 = 5609250781410 := by decide
theorem cert_e1211204270306 : check e1211204270306 [[],[]] .chain = true := by decide
def e1211204270318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211204270318 : Closed e1211204270318 ∧ code e1211204270318 = 5609250781422 := by decide
theorem cert_e1211204270318 : check e1211204270318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204270326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211204270326 : Closed e1211204270326 ∧ code e1211204270326 = 5609250781430 := by decide
theorem cert_e1211204270326 : check e1211204270326 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204270518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211204270518 : Closed e1211204270518 ∧ code e1211204270518 = 5609250781622 := by decide
theorem cert_e1211204270518 : check e1211204270518 [[],[]] .chain = true := by decide
def e1211204270550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211204270550 : Closed e1211204270550 ∧ code e1211204270550 = 5609250781654 := by decide
theorem cert_e1211204270550 : check e1211204270550 [[],[]] .chain = true := by decide
end Blc.Floor42
