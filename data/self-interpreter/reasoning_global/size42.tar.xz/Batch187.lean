import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203661546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211203661546 : Closed e1211203661546 ∧ code e1211203661546 = 5609250172650 := by decide
theorem cert_e1211203661546 : check e1211203661546 [[],[]] .chain = true := by decide
def e1211203661654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203661654 : Closed e1211203661654 ∧ code e1211203661654 = 5609250172758 := by decide
theorem cert_e1211203661654 : check e1211203661654 [[],[]] .chain = true := by decide
def e1211203661658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203661658 : Closed e1211203661658 ∧ code e1211203661658 = 5609250172762 := by decide
theorem cert_e1211203661658 : check e1211203661658 [[],[]] .chain = true := by decide
def e1211203661674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203661674 : Closed e1211203661674 ∧ code e1211203661674 = 5609250172778 := by decide
theorem cert_e1211203661674 : check e1211203661674 [[],[]] .chain = true := by decide
def e1211203661934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211203661934 : Closed e1211203661934 ∧ code e1211203661934 = 5609250173038 := by decide
theorem cert_e1211203661934 : check e1211203661934 [[],[]] .chain = true := by decide
def e1211203662110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211203662110 : Closed e1211203662110 ∧ code e1211203662110 = 5609250173214 := by decide
theorem cert_e1211203662110 : check e1211203662110 [[],[]] .chain = true := by decide
def e1211203662306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211203662306 : Closed e1211203662306 ∧ code e1211203662306 = 5609250173410 := by decide
theorem cert_e1211203662306 : check e1211203662306 [[],[]] .chain = true := by decide
def e1211203662318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211203662318 : Closed e1211203662318 ∧ code e1211203662318 = 5609250173422 := by decide
theorem cert_e1211203662318 : check e1211203662318 [[],[]] .sourceHead = true := by decide
def e1211203662702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211203662702 : Closed e1211203662702 ∧ code e1211203662702 = 5609250173806 := by decide
theorem cert_e1211203662702 : check e1211203662702 [[],[]] .chain = true := by decide
def e1211203662710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211203662710 : Closed e1211203662710 ∧ code e1211203662710 = 5609250173814 := by decide
theorem cert_e1211203662710 : check e1211203662710 [[],[]] .chain = true := by decide
def e1211203662766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211203662766 : Closed e1211203662766 ∧ code e1211203662766 = 5609250173870 := by decide
theorem cert_e1211203662766 : check e1211203662766 [[],[]] .chain = true := by decide
def e1211203662778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211203662778 : Closed e1211203662778 ∧ code e1211203662778 = 5609250173882 := by decide
theorem cert_e1211203662778 : check e1211203662778 [[],[]] .chain = true := by decide
def e1211203662806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211203662806 : Closed e1211203662806 ∧ code e1211203662806 = 5609250173910 := by decide
theorem cert_e1211203662806 : check e1211203662806 [[],[]] .chain = true := by decide
def e1211203662810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211203662810 : Closed e1211203662810 ∧ code e1211203662810 = 5609250173914 := by decide
theorem cert_e1211203662810 : check e1211203662810 [[],[]] .chain = true := by decide
def e1211203663086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203663086 : Closed e1211203663086 ∧ code e1211203663086 = 5609250174190 := by decide
theorem cert_e1211203663086 : check e1211203663086 [[],[]] .chain = true := by decide
def e1211203663094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203663094 : Closed e1211203663094 ∧ code e1211203663094 = 5609250174198 := by decide
theorem cert_e1211203663094 : check e1211203663094 [[],[]] .chain = true := by decide
def e1211203663470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203663470 : Closed e1211203663470 ∧ code e1211203663470 = 5609250174574 := by decide
theorem cert_e1211203663470 : check e1211203663470 [[],[]] .chain = true := by decide
def e1211203663482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203663482 : Closed e1211203663482 ∧ code e1211203663482 = 5609250174586 := by decide
theorem cert_e1211203663482 : check e1211203663482 [[],[]] .chain = true := by decide
def e1211203663622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203663622 : Closed e1211203663622 ∧ code e1211203663622 = 5609250174726 := by decide
theorem cert_e1211203663622 : check e1211203663622 [[],[]] .chain = true := by decide
def e1211203663646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211203663646 : Closed e1211203663646 ∧ code e1211203663646 = 5609250174750 := by decide
theorem cert_e1211203663646 : check e1211203663646 [[],[]] .sourceHead = true := by decide
def e1211203663670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203663670 : Closed e1211203663670 ∧ code e1211203663670 = 5609250174774 := by decide
theorem cert_e1211203663670 : check e1211203663670 [[],[]] .chain = true := by decide
def e1211203663674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203663674 : Closed e1211203663674 ∧ code e1211203663674 = 5609250174778 := by decide
theorem cert_e1211203663674 : check e1211203663674 [[],[]] .chain = true := by decide
def e1211203663918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203663918 : Closed e1211203663918 ∧ code e1211203663918 = 5609250175022 := by decide
theorem cert_e1211203663918 : check e1211203663918 [[],[]] .chain = true := by decide
def e1211203664110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203664110 : Closed e1211203664110 ∧ code e1211203664110 = 5609250175214 := by decide
theorem cert_e1211203664110 : check e1211203664110 [[],[]] .chain = true := by decide
def e1211203664118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203664118 : Closed e1211203664118 ∧ code e1211203664118 = 5609250175222 := by decide
theorem cert_e1211203664118 : check e1211203664118 [[],[]] .chain = true := by decide
def e1211203664302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211203664302 : Closed e1211203664302 ∧ code e1211203664302 = 5609250175406 := by decide
theorem cert_e1211203664302 : check e1211203664302 [[],[]] .chain = true := by decide
def e1211203664314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211203664314 : Closed e1211203664314 ∧ code e1211203664314 = 5609250175418 := by decide
theorem cert_e1211203664314 : check e1211203664314 [[],[]] .chain = true := by decide
def e1211203664362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211203664362 : Closed e1211203664362 ∧ code e1211203664362 = 5609250175466 := by decide
theorem cert_e1211203664362 : check e1211203664362 [[],[]] .chain = true := by decide
def e1211203664494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203664494 : Closed e1211203664494 ∧ code e1211203664494 = 5609250175598 := by decide
theorem cert_e1211203664494 : check e1211203664494 [[],[]] .chain = true := by decide
def e1211203664506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203664506 : Closed e1211203664506 ∧ code e1211203664506 = 5609250175610 := by decide
theorem cert_e1211203664506 : check e1211203664506 [[],[]] .chain = true := by decide
def e1211203664670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203664670 : Closed e1211203664670 ∧ code e1211203664670 = 5609250175774 := by decide
theorem cert_e1211203664670 : check e1211203664670 [[],[]] .chain = true := by decide
def e1211203664770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203664770 : Closed e1211203664770 ∧ code e1211203664770 = 5609250175874 := by decide
theorem cert_e1211203664770 : check e1211203664770 [[],[]] .chain = true := by decide
def e1211203664782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203664782 : Closed e1211203664782 ∧ code e1211203664782 = 5609250175886 := by decide
theorem cert_e1211203664782 : check e1211203664782 [[],[]] .chain = true := by decide
def e1211203664794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203664794 : Closed e1211203664794 ∧ code e1211203664794 = 5609250175898 := by decide
theorem cert_e1211203664794 : check e1211203664794 [[],[]] .chain = true := by decide
def e1211203664918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203664918 : Closed e1211203664918 ∧ code e1211203664918 = 5609250176022 := by decide
theorem cert_e1211203664918 : check e1211203664918 [[],[]] .chain = true := by decide
def e1211203664922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203664922 : Closed e1211203664922 ∧ code e1211203664922 = 5609250176026 := by decide
theorem cert_e1211203664922 : check e1211203664922 [[],[]] .chain = true := by decide
def e1211203664966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203664966 : Closed e1211203664966 ∧ code e1211203664966 = 5609250176070 := by decide
theorem cert_e1211203664966 : check e1211203664966 [[],[]] .chain = true := by decide
def e1211203664994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203664994 : Closed e1211203664994 ∧ code e1211203664994 = 5609250176098 := by decide
theorem cert_e1211203664994 : check e1211203664994 [[],[]] .chain = true := by decide
def e1211203665006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203665006 : Closed e1211203665006 ∧ code e1211203665006 = 5609250176110 := by decide
theorem cert_e1211203665006 : check e1211203665006 [[],[]] .sourceHead = true := by decide
def e1211203665014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203665014 : Closed e1211203665014 ∧ code e1211203665014 = 5609250176118 := by decide
theorem cert_e1211203665014 : check e1211203665014 [[],[]] .chain = true := by decide
def e1211203665018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203665018 : Closed e1211203665018 ∧ code e1211203665018 = 5609250176122 := by decide
theorem cert_e1211203665018 : check e1211203665018 [[],[]] .sourceHead = true := by decide
def e1211203665110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203665110 : Closed e1211203665110 ∧ code e1211203665110 = 5609250176214 := by decide
theorem cert_e1211203665110 : check e1211203665110 [[],[]] .chain = true := by decide
def e1211203665114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203665114 : Closed e1211203665114 ∧ code e1211203665114 = 5609250176218 := by decide
theorem cert_e1211203665114 : check e1211203665114 [[],[]] .chain = true := by decide
def e1211203665130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203665130 : Closed e1211203665130 ∧ code e1211203665130 = 5609250176234 := by decide
theorem cert_e1211203665130 : check e1211203665130 [[],[]] .chain = true := by decide
def e1211203665158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203665158 : Closed e1211203665158 ∧ code e1211203665158 = 5609250176262 := by decide
theorem cert_e1211203665158 : check e1211203665158 [[],[]] .chain = true := by decide
def e1211203665182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203665182 : Closed e1211203665182 ∧ code e1211203665182 = 5609250176286 := by decide
theorem cert_e1211203665182 : check e1211203665182 [[],[]] .sourceHead = true := by decide
def e1211203665206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203665206 : Closed e1211203665206 ∧ code e1211203665206 = 5609250176310 := by decide
theorem cert_e1211203665206 : check e1211203665206 [[],[]] .chain = true := by decide
def e1211203665210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203665210 : Closed e1211203665210 ∧ code e1211203665210 = 5609250176314 := by decide
theorem cert_e1211203665210 : check e1211203665210 [[],[]] .chain = true := by decide
def e1211203665282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203665282 : Closed e1211203665282 ∧ code e1211203665282 = 5609250176386 := by decide
theorem cert_e1211203665282 : check e1211203665282 [[],[]] .chain = true := by decide
def e1211203665294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203665294 : Closed e1211203665294 ∧ code e1211203665294 = 5609250176398 := by decide
theorem cert_e1211203665294 : check e1211203665294 [[],[]] .chain = true := by decide
def e1211203665306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203665306 : Closed e1211203665306 ∧ code e1211203665306 = 5609250176410 := by decide
theorem cert_e1211203665306 : check e1211203665306 [[],[]] .chain = true := by decide
def e1211203665350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203665350 : Closed e1211203665350 ∧ code e1211203665350 = 5609250176454 := by decide
theorem cert_e1211203665350 : check e1211203665350 [[],[]] .sourceHead = true := by decide
def e1211203666046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211203666046 : Closed e1211203666046 ∧ code e1211203666046 = 5609250177150 := by decide
theorem cert_e1211203666046 : check e1211203666046 [[],[]] .chain = true := by decide
def e1211203666910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211203666910 : Closed e1211203666910 ∧ code e1211203666910 = 5609250178014 := by decide
theorem cert_e1211203666910 : check e1211203666910 [[],[]] .chain = true := by decide
def e1211203666914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211203666914 : Closed e1211203666914 ∧ code e1211203666914 = 5609250178018 := by decide
theorem cert_e1211203666914 : check e1211203666914 [[],[]] .chain = true := by decide
def e1211203666926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211203666926 : Closed e1211203666926 ∧ code e1211203666926 = 5609250178030 := by decide
theorem cert_e1211203666926 : check e1211203666926 [[],[]] .chain = true := by decide
def e1211203668846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211203668846 : Closed e1211203668846 ∧ code e1211203668846 = 5609250179950 := by decide
theorem cert_e1211203668846 : check e1211203668846 [[],[]] .chain = true := by decide
def e1211203668854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211203668854 : Closed e1211203668854 ∧ code e1211203668854 = 5609250179958 := by decide
theorem cert_e1211203668854 : check e1211203668854 [[],[]] .chain = true := by decide
def e1211203668910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211203668910 : Closed e1211203668910 ∧ code e1211203668910 = 5609250180014 := by decide
theorem cert_e1211203668910 : check e1211203668910 [[],[]] .chain = true := by decide
def e1211203668922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211203668922 : Closed e1211203668922 ∧ code e1211203668922 = 5609250180026 := by decide
theorem cert_e1211203668922 : check e1211203668922 [[],[]] .chain = true := by decide
def e1211203668950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211203668950 : Closed e1211203668950 ∧ code e1211203668950 = 5609250180054 := by decide
theorem cert_e1211203668950 : check e1211203668950 [[],[]] .chain = true := by decide
def e1211203668954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211203668954 : Closed e1211203668954 ∧ code e1211203668954 = 5609250180058 := by decide
theorem cert_e1211203668954 : check e1211203668954 [[],[]] .chain = true := by decide
def e1211203669230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203669230 : Closed e1211203669230 ∧ code e1211203669230 = 5609250180334 := by decide
theorem cert_e1211203669230 : check e1211203669230 [[],[]] .chain = true := by decide
def e1211203669238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203669238 : Closed e1211203669238 ∧ code e1211203669238 = 5609250180342 := by decide
theorem cert_e1211203669238 : check e1211203669238 [[],[]] .chain = true := by decide
def e1211203669614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203669614 : Closed e1211203669614 ∧ code e1211203669614 = 5609250180718 := by decide
theorem cert_e1211203669614 : check e1211203669614 [[],[]] .chain = true := by decide
def e1211203669626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203669626 : Closed e1211203669626 ∧ code e1211203669626 = 5609250180730 := by decide
theorem cert_e1211203669626 : check e1211203669626 [[],[]] .chain = true := by decide
def e1211203669766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203669766 : Closed e1211203669766 ∧ code e1211203669766 = 5609250180870 := by decide
theorem cert_e1211203669766 : check e1211203669766 [[],[]] .chain = true := by decide
def e1211203669790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211203669790 : Closed e1211203669790 ∧ code e1211203669790 = 5609250180894 := by decide
theorem cert_e1211203669790 : check e1211203669790 [[],[]] .sourceHead = true := by decide
def e1211203669814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203669814 : Closed e1211203669814 ∧ code e1211203669814 = 5609250180918 := by decide
theorem cert_e1211203669814 : check e1211203669814 [[],[]] .chain = true := by decide
def e1211203669818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203669818 : Closed e1211203669818 ∧ code e1211203669818 = 5609250180922 := by decide
theorem cert_e1211203669818 : check e1211203669818 [[],[]] .chain = true := by decide
def e1211203674590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211203674590 : Closed e1211203674590 ∧ code e1211203674590 = 5609250185694 := by decide
theorem cert_e1211203674590 : check e1211203674590 [[],[]] .chain = true := by decide
def e1211203674614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211203674614 : Closed e1211203674614 ∧ code e1211203674614 = 5609250185718 := by decide
theorem cert_e1211203674614 : check e1211203674614 [[],[]] .chain = true := by decide
def e1211203675566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211203675566 : Closed e1211203675566 ∧ code e1211203675566 = 5609250186670 := by decide
theorem cert_e1211203675566 : check e1211203675566 [[],[]] .chain = true := by decide
def e1211203675578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211203675578 : Closed e1211203675578 ∧ code e1211203675578 = 5609250186682 := by decide
theorem cert_e1211203675578 : check e1211203675578 [[],[]] .chain = true := by decide
def e1211203675626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211203675626 : Closed e1211203675626 ∧ code e1211203675626 = 5609250186730 := by decide
theorem cert_e1211203675626 : check e1211203675626 [[],[]] .chain = true := by decide
def e1211203675758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203675758 : Closed e1211203675758 ∧ code e1211203675758 = 5609250186862 := by decide
theorem cert_e1211203675758 : check e1211203675758 [[],[]] .chain = true := by decide
def e1211203675770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203675770 : Closed e1211203675770 ∧ code e1211203675770 = 5609250186874 := by decide
theorem cert_e1211203675770 : check e1211203675770 [[],[]] .chain = true := by decide
def e1211203675934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203675934 : Closed e1211203675934 ∧ code e1211203675934 = 5609250187038 := by decide
theorem cert_e1211203675934 : check e1211203675934 [[],[]] .chain = true := by decide
def e1211203676034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203676034 : Closed e1211203676034 ∧ code e1211203676034 = 5609250187138 := by decide
theorem cert_e1211203676034 : check e1211203676034 [[],[]] .chain = true := by decide
def e1211203676046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203676046 : Closed e1211203676046 ∧ code e1211203676046 = 5609250187150 := by decide
theorem cert_e1211203676046 : check e1211203676046 [[],[]] .chain = true := by decide
def e1211203676058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203676058 : Closed e1211203676058 ∧ code e1211203676058 = 5609250187162 := by decide
theorem cert_e1211203676058 : check e1211203676058 [[],[]] .chain = true := by decide
def e1211203678238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203678238 : Closed e1211203678238 ∧ code e1211203678238 = 5609250189342 := by decide
theorem cert_e1211203678238 : check e1211203678238 [[],[]] .chain = true := by decide
def e1211203678406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203678406 : Closed e1211203678406 ∧ code e1211203678406 = 5609250189510 := by decide
theorem cert_e1211203678406 : check e1211203678406 [[],[]] .sourceHead = true := by decide
def e1211203678430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203678430 : Closed e1211203678430 ∧ code e1211203678430 = 5609250189534 := by decide
theorem cert_e1211203678430 : check e1211203678430 [[],[]] .sourceHead = true := by decide
def e1211203678434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203678434 : Closed e1211203678434 ∧ code e1211203678434 = 5609250189538 := by decide
theorem cert_e1211203678434 : check e1211203678434 [[],[]] .chain = true := by decide
def e1211203678446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203678446 : Closed e1211203678446 ∧ code e1211203678446 = 5609250189550 := by decide
theorem cert_e1211203678446 : check e1211203678446 [[],[]] .chain = true := by decide
def e1211203678454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203678454 : Closed e1211203678454 ∧ code e1211203678454 = 5609250189558 := by decide
theorem cert_e1211203678454 : check e1211203678454 [[],[]] .chain = true := by decide
def e1211203678458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203678458 : Closed e1211203678458 ∧ code e1211203678458 = 5609250189562 := by decide
theorem cert_e1211203678458 : check e1211203678458 [[],[]] .sourceHead = true := by decide
def e1211203678934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203678934 : Closed e1211203678934 ∧ code e1211203678934 = 5609250190038 := by decide
theorem cert_e1211203678934 : check e1211203678934 [[],[]] .chain = true := by decide
def e1211203678938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203678938 : Closed e1211203678938 ∧ code e1211203678938 = 5609250190042 := by decide
theorem cert_e1211203678938 : check e1211203678938 [[],[]] .chain = true := by decide
def e1211203678954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203678954 : Closed e1211203678954 ∧ code e1211203678954 = 5609250190058 := by decide
theorem cert_e1211203678954 : check e1211203678954 [[],[]] .chain = true := by decide
def e1211203678982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203678982 : Closed e1211203678982 ∧ code e1211203678982 = 5609250190086 := by decide
theorem cert_e1211203678982 : check e1211203678982 [[],[]] .chain = true := by decide
def e1211203679006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203679006 : Closed e1211203679006 ∧ code e1211203679006 = 5609250190110 := by decide
theorem cert_e1211203679006 : check e1211203679006 [[],[]] .sourceHead = true := by decide
def e1211203679030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203679030 : Closed e1211203679030 ∧ code e1211203679030 = 5609250190134 := by decide
theorem cert_e1211203679030 : check e1211203679030 [[],[]] .chain = true := by decide
def e1211203679034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203679034 : Closed e1211203679034 ∧ code e1211203679034 = 5609250190138 := by decide
theorem cert_e1211203679034 : check e1211203679034 [[],[]] .chain = true := by decide
def e1211203679106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203679106 : Closed e1211203679106 ∧ code e1211203679106 = 5609250190210 := by decide
theorem cert_e1211203679106 : check e1211203679106 [[],[]] .chain = true := by decide
def e1211203679118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203679118 : Closed e1211203679118 ∧ code e1211203679118 = 5609250190222 := by decide
theorem cert_e1211203679118 : check e1211203679118 [[],[]] .chain = true := by decide
def e1211203679130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203679130 : Closed e1211203679130 ∧ code e1211203679130 = 5609250190234 := by decide
theorem cert_e1211203679130 : check e1211203679130 [[],[]] .chain = true := by decide
def e1211203679174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203679174 : Closed e1211203679174 ∧ code e1211203679174 = 5609250190278 := by decide
theorem cert_e1211203679174 : check e1211203679174 [[],[]] .sourceHead = true := by decide
def e1211203682926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203682926 : Closed e1211203682926 ∧ code e1211203682926 = 5609250194030 := by decide
theorem cert_e1211203682926 : check e1211203682926 [[],[]] .chain = true := by decide
def e1211203682938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203682938 : Closed e1211203682938 ∧ code e1211203682938 = 5609250194042 := by decide
theorem cert_e1211203682938 : check e1211203682938 [[],[]] .chain = true := by decide
def e1211203684206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1211203684206 : Closed e1211203684206 ∧ code e1211203684206 = 5609250195310 := by decide
theorem cert_e1211203684206 : check e1211203684206 [[],[]] .chain = true := by decide
def e1211203684218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e1211203684218 : Closed e1211203684218 ∧ code e1211203684218 = 5609250195322 := by decide
theorem cert_e1211203684218 : check e1211203684218 [[],[]] .chain = true := by decide
def e1211203684314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e1211203684314 : Closed e1211203684314 ∧ code e1211203684314 = 5609250195418 := by decide
theorem cert_e1211203684314 : check e1211203684314 [[],[]] .chain = true := by decide
def e1211203685614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203685614 : Closed e1211203685614 ∧ code e1211203685614 = 5609250196718 := by decide
theorem cert_e1211203685614 : check e1211203685614 [[],[]] .chain = true := by decide
def e1211203685622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203685622 : Closed e1211203685622 ∧ code e1211203685622 = 5609250196726 := by decide
theorem cert_e1211203685622 : check e1211203685622 [[],[]] .chain = true := by decide
def e1211203685998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203685998 : Closed e1211203685998 ∧ code e1211203685998 = 5609250197102 := by decide
theorem cert_e1211203685998 : check e1211203685998 [[],[]] .chain = true := by decide
def e1211203686010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203686010 : Closed e1211203686010 ∧ code e1211203686010 = 5609250197114 := by decide
theorem cert_e1211203686010 : check e1211203686010 [[],[]] .chain = true := by decide
def e1211203686198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203686198 : Closed e1211203686198 ∧ code e1211203686198 = 5609250197302 := by decide
theorem cert_e1211203686198 : check e1211203686198 [[],[]] .chain = true := by decide
def e1211203686202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203686202 : Closed e1211203686202 ∧ code e1211203686202 = 5609250197306 := by decide
theorem cert_e1211203686202 : check e1211203686202 [[],[]] .chain = true := by decide
def e1211203688110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211203688110 : Closed e1211203688110 ∧ code e1211203688110 = 5609250199214 := by decide
theorem cert_e1211203688110 : check e1211203688110 [[],[]] .chain = true := by decide
def e1211203688122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211203688122 : Closed e1211203688122 ∧ code e1211203688122 = 5609250199226 := by decide
theorem cert_e1211203688122 : check e1211203688122 [[],[]] .chain = true := by decide
def e1211203688170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211203688170 : Closed e1211203688170 ∧ code e1211203688170 = 5609250199274 := by decide
theorem cert_e1211203688170 : check e1211203688170 [[],[]] .chain = true := by decide
def e1211203688362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211203688362 : Closed e1211203688362 ∧ code e1211203688362 = 5609250199466 := by decide
theorem cert_e1211203688362 : check e1211203688362 [[],[]] .chain = true := by decide
def e1211203688494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203688494 : Closed e1211203688494 ∧ code e1211203688494 = 5609250199598 := by decide
theorem cert_e1211203688494 : check e1211203688494 [[],[]] .chain = true := by decide
def e1211203688686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203688686 : Closed e1211203688686 ∧ code e1211203688686 = 5609250199790 := by decide
theorem cert_e1211203688686 : check e1211203688686 [[],[]] .chain = true := by decide
def e1211203688694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203688694 : Closed e1211203688694 ∧ code e1211203688694 = 5609250199798 := by decide
theorem cert_e1211203688694 : check e1211203688694 [[],[]] .chain = true := by decide
def e1211203688878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211203688878 : Closed e1211203688878 ∧ code e1211203688878 = 5609250199982 := by decide
theorem cert_e1211203688878 : check e1211203688878 [[],[]] .chain = true := by decide
def e1211203688890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211203688890 : Closed e1211203688890 ∧ code e1211203688890 = 5609250199994 := by decide
theorem cert_e1211203688890 : check e1211203688890 [[],[]] .chain = true := by decide
def e1211203688938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211203688938 : Closed e1211203688938 ∧ code e1211203688938 = 5609250200042 := by decide
theorem cert_e1211203688938 : check e1211203688938 [[],[]] .chain = true := by decide
def e1211203689070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203689070 : Closed e1211203689070 ∧ code e1211203689070 = 5609250200174 := by decide
theorem cert_e1211203689070 : check e1211203689070 [[],[]] .chain = true := by decide
def e1211203689082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203689082 : Closed e1211203689082 ∧ code e1211203689082 = 5609250200186 := by decide
theorem cert_e1211203689082 : check e1211203689082 [[],[]] .chain = true := by decide
def e1211203689246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203689246 : Closed e1211203689246 ∧ code e1211203689246 = 5609250200350 := by decide
theorem cert_e1211203689246 : check e1211203689246 [[],[]] .chain = true := by decide
def e1211203689346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203689346 : Closed e1211203689346 ∧ code e1211203689346 = 5609250200450 := by decide
theorem cert_e1211203689346 : check e1211203689346 [[],[]] .chain = true := by decide
def e1211203689358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203689358 : Closed e1211203689358 ∧ code e1211203689358 = 5609250200462 := by decide
theorem cert_e1211203689358 : check e1211203689358 [[],[]] .chain = true := by decide
def e1211203689370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203689370 : Closed e1211203689370 ∧ code e1211203689370 = 5609250200474 := by decide
theorem cert_e1211203689370 : check e1211203689370 [[],[]] .chain = true := by decide
def e1211203689582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203689582 : Closed e1211203689582 ∧ code e1211203689582 = 5609250200686 := by decide
theorem cert_e1211203689582 : check e1211203689582 [[],[]] .chain = true := by decide
def e1211203689594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203689594 : Closed e1211203689594 ∧ code e1211203689594 = 5609250200698 := by decide
theorem cert_e1211203689594 : check e1211203689594 [[],[]] .chain = true := by decide
def e1211203689758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203689758 : Closed e1211203689758 ∧ code e1211203689758 = 5609250200862 := by decide
theorem cert_e1211203689758 : check e1211203689758 [[],[]] .chain = true := by decide
def e1211203689926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203689926 : Closed e1211203689926 ∧ code e1211203689926 = 5609250201030 := by decide
theorem cert_e1211203689926 : check e1211203689926 [[],[]] .chain = true := by decide
def e1211203689994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203689994 : Closed e1211203689994 ∧ code e1211203689994 = 5609250201098 := by decide
theorem cert_e1211203689994 : check e1211203689994 [[],[]] .chain = true := by decide
def e1211203690038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203690038 : Closed e1211203690038 ∧ code e1211203690038 = 5609250201142 := by decide
theorem cert_e1211203690038 : check e1211203690038 [[],[]] .chain = true := by decide
def e1211203690042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203690042 : Closed e1211203690042 ∧ code e1211203690042 = 5609250201146 := by decide
theorem cert_e1211203690042 : check e1211203690042 [[],[]] .chain = true := by decide
def e1211203690090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211203690090 : Closed e1211203690090 ∧ code e1211203690090 = 5609250201194 := by decide
theorem cert_e1211203690090 : check e1211203690090 [[],[]] .chain = true := by decide
def e1211203690114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203690114 : Closed e1211203690114 ∧ code e1211203690114 = 5609250201218 := by decide
theorem cert_e1211203690114 : check e1211203690114 [[],[]] .chain = true := by decide
def e1211203690126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203690126 : Closed e1211203690126 ∧ code e1211203690126 = 5609250201230 := by decide
theorem cert_e1211203690126 : check e1211203690126 [[],[]] .chain = true := by decide
def e1211203690138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203690138 : Closed e1211203690138 ∧ code e1211203690138 = 5609250201242 := by decide
theorem cert_e1211203690138 : check e1211203690138 [[],[]] .chain = true := by decide
def e1211203690182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203690182 : Closed e1211203690182 ∧ code e1211203690182 = 5609250201286 := by decide
theorem cert_e1211203690182 : check e1211203690182 [[],[]] .chain = true := by decide
def e1211203690974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211203690974 : Closed e1211203690974 ∧ code e1211203690974 = 5609250202078 := by decide
theorem cert_e1211203690974 : check e1211203690974 [[],[]] .chain = true := by decide
def e1211203690998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211203690998 : Closed e1211203690998 ∧ code e1211203690998 = 5609250202102 := by decide
theorem cert_e1211203690998 : check e1211203690998 [[],[]] .chain = true := by decide
def e1211203691950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211203691950 : Closed e1211203691950 ∧ code e1211203691950 = 5609250203054 := by decide
theorem cert_e1211203691950 : check e1211203691950 [[],[]] .chain = true := by decide
def e1211203691962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211203691962 : Closed e1211203691962 ∧ code e1211203691962 = 5609250203066 := by decide
theorem cert_e1211203691962 : check e1211203691962 [[],[]] .chain = true := by decide
def e1211203692010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211203692010 : Closed e1211203692010 ∧ code e1211203692010 = 5609250203114 := by decide
theorem cert_e1211203692010 : check e1211203692010 [[],[]] .chain = true := by decide
def e1211203692142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203692142 : Closed e1211203692142 ∧ code e1211203692142 = 5609250203246 := by decide
theorem cert_e1211203692142 : check e1211203692142 [[],[]] .chain = true := by decide
def e1211203692154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203692154 : Closed e1211203692154 ∧ code e1211203692154 = 5609250203258 := by decide
theorem cert_e1211203692154 : check e1211203692154 [[],[]] .chain = true := by decide
def e1211203692318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203692318 : Closed e1211203692318 ∧ code e1211203692318 = 5609250203422 := by decide
theorem cert_e1211203692318 : check e1211203692318 [[],[]] .chain = true := by decide
def e1211203692418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203692418 : Closed e1211203692418 ∧ code e1211203692418 = 5609250203522 := by decide
theorem cert_e1211203692418 : check e1211203692418 [[],[]] .chain = true := by decide
def e1211203692430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203692430 : Closed e1211203692430 ∧ code e1211203692430 = 5609250203534 := by decide
theorem cert_e1211203692430 : check e1211203692430 [[],[]] .chain = true := by decide
def e1211203692442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203692442 : Closed e1211203692442 ∧ code e1211203692442 = 5609250203546 := by decide
theorem cert_e1211203692442 : check e1211203692442 [[],[]] .chain = true := by decide
def e1211203695390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203695390 : Closed e1211203695390 ∧ code e1211203695390 = 5609250206494 := by decide
theorem cert_e1211203695390 : check e1211203695390 [[],[]] .chain = true := by decide
def e1211203695558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203695558 : Closed e1211203695558 ∧ code e1211203695558 = 5609250206662 := by decide
theorem cert_e1211203695558 : check e1211203695558 [[],[]] .chain = true := by decide
def e1211203696758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211203696758 : Closed e1211203696758 ∧ code e1211203696758 = 5609250207862 := by decide
theorem cert_e1211203696758 : check e1211203696758 [[],[]] .chain = true := by decide
def e1211203697002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211203697002 : Closed e1211203697002 ∧ code e1211203697002 = 5609250208106 := by decide
theorem cert_e1211203697002 : check e1211203697002 [[],[]] .chain = true := by decide
def e1211203697026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203697026 : Closed e1211203697026 ∧ code e1211203697026 = 5609250208130 := by decide
theorem cert_e1211203697026 : check e1211203697026 [[],[]] .chain = true := by decide
def e1211203697038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203697038 : Closed e1211203697038 ∧ code e1211203697038 = 5609250208142 := by decide
theorem cert_e1211203697038 : check e1211203697038 [[],[]] .chain = true := by decide
def e1211203697050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203697050 : Closed e1211203697050 ∧ code e1211203697050 = 5609250208154 := by decide
theorem cert_e1211203697050 : check e1211203697050 [[],[]] .chain = true := by decide
def e1211203697094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203697094 : Closed e1211203697094 ∧ code e1211203697094 = 5609250208198 := by decide
theorem cert_e1211203697094 : check e1211203697094 [[],[]] .chain = true := by decide
def e1211203698810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211203698810 : Closed e1211203698810 ∧ code e1211203698810 = 5609250209914 := by decide
theorem cert_e1211203698810 : check e1211203698810 [[],[]] .chain = true := by decide
def e1211203698998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203698998 : Closed e1211203698998 ∧ code e1211203698998 = 5609250210102 := by decide
theorem cert_e1211203698998 : check e1211203698998 [[],[]] .chain = true := by decide
def e1211203699002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203699002 : Closed e1211203699002 ∧ code e1211203699002 = 5609250210106 := by decide
theorem cert_e1211203699002 : check e1211203699002 [[],[]] .chain = true := by decide
end Blc.Floor42
