import Tables
import Batch119
namespace Blc.Floor42.Grades119
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1208664657518 : ¬ IsSelfInterpreter e1208664657518 := cutM1_2 (by decide)
#print axioms ex_e1208664657518
theorem ex_e1208664657718 : ¬ IsSelfInterpreter e1208664657718 := cutM10_0 (by decide)
#print axioms ex_e1208664657718
end Blc.Floor42.Grades119
