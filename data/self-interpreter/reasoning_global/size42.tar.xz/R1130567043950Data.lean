import R1130567043950V0
import R1130567043950K0
import R1130567043950st0
import R1130567043950st12
import R1130567043950hs0
import R1130567043950hs12
import CodeBridge
import Batch054
namespace Certgen.R1130567043950
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 21,.app 2 20,.app 3 10,.lam 4,.lam 5,.app 6 7,.var 1,.app 8 9,.var 1,.var 1,.lam 11,.app 12 13,.var 0,.lam 14,.lam 15,.app 16 19,.app 17 18,.var 0,.var 1,.var 2,.opaque,.lam 22,.app 23 28,.app 24 25,.var 0,.lam 26,.lam 27,.var 1,.lam 29,.app 30 35,.app 31 32,.var 0,.lam 33,.lam 34,.var 1,.lam 36,.app 37 42,.app 38 39,.var 0,.lam 40,.lam 41,.var 0,.lam 43,.app 44 49,.app 45 46,.var 0,.lam 47,.lam 48,.var 1,.opaque]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 293 then (if i < 140 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 100 then (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)) else (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)))) else (if i < 220 then (if i < 180 then (if i < 160 then (st140[i-140]?.getD entry) else (st160[i-160]?.getD entry)) else (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry))) else (if i < 260 then (if i < 240 then (st220[i-220]?.getD entry) else (st240[i-240]?.getD entry)) else (if i < 280 then (st260[i-260]?.getD entry) else (st280[i-280]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 140 then (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 100 then (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])) else (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])))) else (if i < 220 then (if i < 180 then (if i < 160 then (hs140[i-140]?.getD []) else (hs160[i-160]?.getD [])) else (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD []))) else (if i < 260 then (if i < 240 then (hs220[i-220]?.getD []) else (hs240[i-240]?.getD [])) else (if i < 280 then (hs260[i-260]?.getD []) else (hs280[i-280]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R1130567043950
