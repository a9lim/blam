import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1107663478810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107663478810 : Closed e1107663478810 ∧ code e1107663478810 = 5505709989914 := by decide
theorem cert_e1107663478810 : check e1107663478810 [[]] .width = true := by decide
def e1107663478902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107663478902 : Closed e1107663478902 ∧ code e1107663478902 = 5505709990006 := by decide
theorem cert_e1107663478902 : check e1107663478902 [[]] .width = true := by decide
def e1107663479146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107663479146 : Closed e1107663479146 ∧ code e1107663479146 = 5505709990250 := by decide
theorem cert_e1107663479146 : check e1107663479146 [[]] .width = true := by decide
def e1107663479194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107663479194 : Closed e1107663479194 ∧ code e1107663479194 = 5505709990298 := by decide
theorem cert_e1107663479194 : check e1107663479194 [[]] .width = true := by decide
def e1107663495194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107663495194 : Closed e1107663495194 ∧ code e1107663495194 = 5505710006298 := by decide
theorem cert_e1107663495194 : check e1107663495194 [[]] .width = true := by decide
def e1107663495286 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107663495286 : Closed e1107663495286 ∧ code e1107663495286 = 5505710006390 := by decide
theorem cert_e1107663495286 : check e1107663495286 [[]] .width = true := by decide
def e1107663495530 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107663495530 : Closed e1107663495530 ∧ code e1107663495530 = 5505710006634 := by decide
theorem cert_e1107663495530 : check e1107663495530 [[]] .width = true := by decide
def e1107663495578 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107663495578 : Closed e1107663495578 ∧ code e1107663495578 = 5505710006682 := by decide
theorem cert_e1107663495578 : check e1107663495578 [[]] .width = true := by decide
def e1107663839258 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107663839258 : Closed e1107663839258 ∧ code e1107663839258 = 5505710350362 := by decide
theorem cert_e1107663839258 : check e1107663839258 [[]] .width = true := by decide
def e1107663839350 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107663839350 : Closed e1107663839350 ∧ code e1107663839350 = 5505710350454 := by decide
theorem cert_e1107663839350 : check e1107663839350 [[]] .width = true := by decide
def e1107663839594 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107663839594 : Closed e1107663839594 ∧ code e1107663839594 = 5505710350698 := by decide
theorem cert_e1107663839594 : check e1107663839594 [[]] .width = true := by decide
def e1107663839642 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107663839642 : Closed e1107663839642 ∧ code e1107663839642 = 5505710350746 := by decide
theorem cert_e1107663839642 : check e1107663839642 [[]] .width = true := by decide
def e1107663978694 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107663978694 : Closed e1107663978694 ∧ code e1107663978694 = 5505710489798 := by decide
theorem cert_e1107663978694 : check e1107663978694 [[]] .width = true := by decide
def e1107663979222 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107663979222 : Closed e1107663979222 ∧ code e1107663979222 = 5505710490326 := by decide
theorem cert_e1107663979222 : check e1107663979222 [[]] .width = true := by decide
def e1107663979226 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107663979226 : Closed e1107663979226 ∧ code e1107663979226 = 5505710490330 := by decide
theorem cert_e1107663979226 : check e1107663979226 [[]] .width = true := by decide
def e1107663979242 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107663979242 : Closed e1107663979242 ∧ code e1107663979242 = 5505710490346 := by decide
theorem cert_e1107663979242 : check e1107663979242 [[]] .width = true := by decide
def e1107663979318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107663979318 : Closed e1107663979318 ∧ code e1107663979318 = 5505710490422 := by decide
theorem cert_e1107663979318 : check e1107663979318 [[]] .width = true := by decide
def e1107663979322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107663979322 : Closed e1107663979322 ∧ code e1107663979322 = 5505710490426 := by decide
theorem cert_e1107663979322 : check e1107663979322 [[]] .width = true := by decide
def e1107663979406 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107663979406 : Closed e1107663979406 ∧ code e1107663979406 = 5505710490510 := by decide
theorem cert_e1107663979406 : check e1107663979406 [[]] .width = true := by decide
def e1107663979418 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107663979418 : Closed e1107663979418 ∧ code e1107663979418 = 5505710490522 := by decide
theorem cert_e1107663979418 : check e1107663979418 [[]] .width = true := by decide
def e1107663981338 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107663981338 : Closed e1107663981338 ∧ code e1107663981338 = 5505710492442 := by decide
theorem cert_e1107663981338 : check e1107663981338 [[]] .width = true := by decide
def e1107663981382 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107663981382 : Closed e1107663981382 ∧ code e1107663981382 = 5505710492486 := by decide
theorem cert_e1107663981382 : check e1107663981382 [[]] .width = true := by decide
def e1107663981622 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107663981622 : Closed e1107663981622 ∧ code e1107663981622 = 5505710492726 := by decide
theorem cert_e1107663981622 : check e1107663981622 [[]] .width = true := by decide
def e1107663981626 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107663981626 : Closed e1107663981626 ∧ code e1107663981626 = 5505710492730 := by decide
theorem cert_e1107663981626 : check e1107663981626 [[]] .width = true := by decide
def e1107663981766 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107663981766 : Closed e1107663981766 ∧ code e1107663981766 = 5505710492870 := by decide
theorem cert_e1107663981766 : check e1107663981766 [[]] .width = true := by decide
def e1107664068634 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107664068634 : Closed e1107664068634 ∧ code e1107664068634 = 5505710579738 := by decide
theorem cert_e1107664068634 : check e1107664068634 [[]] .width = true := by decide
def e1107664068726 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107664068726 : Closed e1107664068726 ∧ code e1107664068726 = 5505710579830 := by decide
theorem cert_e1107664068726 : check e1107664068726 [[]] .width = true := by decide
def e1107664068970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107664068970 : Closed e1107664068970 ∧ code e1107664068970 = 5505710580074 := by decide
theorem cert_e1107664068970 : check e1107664068970 [[]] .width = true := by decide
def e1107664069018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107664069018 : Closed e1107664069018 ∧ code e1107664069018 = 5505710580122 := by decide
theorem cert_e1107664069018 : check e1107664069018 [[]] .width = true := by decide
def e1107664109766 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107664109766 : Closed e1107664109766 ∧ code e1107664109766 = 5505710620870 := by decide
theorem cert_e1107664109766 : check e1107664109766 [[]] .width = true := by decide
def e1107664110294 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107664110294 : Closed e1107664110294 ∧ code e1107664110294 = 5505710621398 := by decide
theorem cert_e1107664110294 : check e1107664110294 [[]] .width = true := by decide
def e1107664110298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107664110298 : Closed e1107664110298 ∧ code e1107664110298 = 5505710621402 := by decide
theorem cert_e1107664110298 : check e1107664110298 [[]] .width = true := by decide
def e1107664110314 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107664110314 : Closed e1107664110314 ∧ code e1107664110314 = 5505710621418 := by decide
theorem cert_e1107664110314 : check e1107664110314 [[]] .width = true := by decide
def e1107664110390 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107664110390 : Closed e1107664110390 ∧ code e1107664110390 = 5505710621494 := by decide
theorem cert_e1107664110390 : check e1107664110390 [[]] .width = true := by decide
def e1107664110394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107664110394 : Closed e1107664110394 ∧ code e1107664110394 = 5505710621498 := by decide
theorem cert_e1107664110394 : check e1107664110394 [[]] .width = true := by decide
def e1107664110478 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107664110478 : Closed e1107664110478 ∧ code e1107664110478 = 5505710621582 := by decide
theorem cert_e1107664110478 : check e1107664110478 [[]] .width = true := by decide
def e1107664110490 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107664110490 : Closed e1107664110490 ∧ code e1107664110490 = 5505710621594 := by decide
theorem cert_e1107664110490 : check e1107664110490 [[]] .width = true := by decide
def e1107664112410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107664112410 : Closed e1107664112410 ∧ code e1107664112410 = 5505710623514 := by decide
theorem cert_e1107664112410 : check e1107664112410 [[]] .width = true := by decide
def e1107664112454 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107664112454 : Closed e1107664112454 ∧ code e1107664112454 = 5505710623558 := by decide
theorem cert_e1107664112454 : check e1107664112454 [[]] .width = true := by decide
def e1107664112694 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107664112694 : Closed e1107664112694 ∧ code e1107664112694 = 5505710623798 := by decide
theorem cert_e1107664112694 : check e1107664112694 [[]] .width = true := by decide
def e1107664112698 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107664112698 : Closed e1107664112698 ∧ code e1107664112698 = 5505710623802 := by decide
theorem cert_e1107664112698 : check e1107664112698 [[]] .width = true := by decide
def e1107664112838 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107664112838 : Closed e1107664112838 ∧ code e1107664112838 = 5505710623942 := by decide
theorem cert_e1107664112838 : check e1107664112838 [[]] .width = true := by decide
def e1107673153734 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107673153734 : Closed e1107673153734 ∧ code e1107673153734 = 5505719664838 := by decide
theorem cert_e1107673153734 : check e1107673153734 [[]] .width = true := by decide
def e1107673154262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107673154262 : Closed e1107673154262 ∧ code e1107673154262 = 5505719665366 := by decide
theorem cert_e1107673154262 : check e1107673154262 [[]] .width = true := by decide
def e1107673154266 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107673154266 : Closed e1107673154266 ∧ code e1107673154266 = 5505719665370 := by decide
theorem cert_e1107673154266 : check e1107673154266 [[]] .width = true := by decide
def e1107673154282 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107673154282 : Closed e1107673154282 ∧ code e1107673154282 = 5505719665386 := by decide
theorem cert_e1107673154282 : check e1107673154282 [[]] .width = true := by decide
def e1107673154358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107673154358 : Closed e1107673154358 ∧ code e1107673154358 = 5505719665462 := by decide
theorem cert_e1107673154358 : check e1107673154358 [[]] .width = true := by decide
def e1107673154362 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107673154362 : Closed e1107673154362 ∧ code e1107673154362 = 5505719665466 := by decide
theorem cert_e1107673154362 : check e1107673154362 [[]] .width = true := by decide
def e1107673154446 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107673154446 : Closed e1107673154446 ∧ code e1107673154446 = 5505719665550 := by decide
theorem cert_e1107673154446 : check e1107673154446 [[]] .width = true := by decide
def e1107673154458 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107673154458 : Closed e1107673154458 ∧ code e1107673154458 = 5505719665562 := by decide
theorem cert_e1107673154458 : check e1107673154458 [[]] .width = true := by decide
def e1107673156378 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107673156378 : Closed e1107673156378 ∧ code e1107673156378 = 5505719667482 := by decide
theorem cert_e1107673156378 : check e1107673156378 [[]] .width = true := by decide
def e1107673156422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107673156422 : Closed e1107673156422 ∧ code e1107673156422 = 5505719667526 := by decide
theorem cert_e1107673156422 : check e1107673156422 [[]] .width = true := by decide
def e1107673156662 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107673156662 : Closed e1107673156662 ∧ code e1107673156662 = 5505719667766 := by decide
theorem cert_e1107673156662 : check e1107673156662 [[]] .width = true := by decide
def e1107673156666 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107673156666 : Closed e1107673156666 ∧ code e1107673156666 = 5505719667770 := by decide
theorem cert_e1107673156666 : check e1107673156666 [[]] .width = true := by decide
def e1107673156806 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107673156806 : Closed e1107673156806 ∧ code e1107673156806 = 5505719667910 := by decide
theorem cert_e1107673156806 : check e1107673156806 [[]] .width = true := by decide
def e1107673276442 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107673276442 : Closed e1107673276442 ∧ code e1107673276442 = 5505719787546 := by decide
theorem cert_e1107673276442 : check e1107673276442 [[]] .width = true := by decide
def e1107673276534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107673276534 : Closed e1107673276534 ∧ code e1107673276534 = 5505719787638 := by decide
theorem cert_e1107673276534 : check e1107673276534 [[]] .width = true := by decide
def e1107673276778 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107673276778 : Closed e1107673276778 ∧ code e1107673276778 = 5505719787882 := by decide
theorem cert_e1107673276778 : check e1107673276778 [[]] .width = true := by decide
def e1107673276826 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107673276826 : Closed e1107673276826 ∧ code e1107673276826 = 5505719787930 := by decide
theorem cert_e1107673276826 : check e1107673276826 [[]] .width = true := by decide
def e1107673415878 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107673415878 : Closed e1107673415878 ∧ code e1107673415878 = 5505719926982 := by decide
theorem cert_e1107673415878 : check e1107673415878 [[]] .width = true := by decide
def e1107673416406 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107673416406 : Closed e1107673416406 ∧ code e1107673416406 = 5505719927510 := by decide
theorem cert_e1107673416406 : check e1107673416406 [[]] .width = true := by decide
def e1107673416410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107673416410 : Closed e1107673416410 ∧ code e1107673416410 = 5505719927514 := by decide
theorem cert_e1107673416410 : check e1107673416410 [[]] .width = true := by decide
def e1107673416426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107673416426 : Closed e1107673416426 ∧ code e1107673416426 = 5505719927530 := by decide
theorem cert_e1107673416426 : check e1107673416426 [[]] .width = true := by decide
def e1107673416502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107673416502 : Closed e1107673416502 ∧ code e1107673416502 = 5505719927606 := by decide
theorem cert_e1107673416502 : check e1107673416502 [[]] .width = true := by decide
def e1107673416506 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107673416506 : Closed e1107673416506 ∧ code e1107673416506 = 5505719927610 := by decide
theorem cert_e1107673416506 : check e1107673416506 [[]] .width = true := by decide
def e1107673416590 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107673416590 : Closed e1107673416590 ∧ code e1107673416590 = 5505719927694 := by decide
theorem cert_e1107673416590 : check e1107673416590 [[]] .width = true := by decide
def e1107673416602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107673416602 : Closed e1107673416602 ∧ code e1107673416602 = 5505719927706 := by decide
theorem cert_e1107673416602 : check e1107673416602 [[]] .width = true := by decide
def e1107673418522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107673418522 : Closed e1107673418522 ∧ code e1107673418522 = 5505719929626 := by decide
theorem cert_e1107673418522 : check e1107673418522 [[]] .width = true := by decide
def e1107673418566 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107673418566 : Closed e1107673418566 ∧ code e1107673418566 = 5505719929670 := by decide
theorem cert_e1107673418566 : check e1107673418566 [[]] .width = true := by decide
def e1107673418806 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107673418806 : Closed e1107673418806 ∧ code e1107673418806 = 5505719929910 := by decide
theorem cert_e1107673418806 : check e1107673418806 [[]] .width = true := by decide
def e1107673418810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107673418810 : Closed e1107673418810 ∧ code e1107673418810 = 5505719929914 := by decide
theorem cert_e1107673418810 : check e1107673418810 [[]] .width = true := by decide
def e1107673418950 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107673418950 : Closed e1107673418950 ∧ code e1107673418950 = 5505719930054 := by decide
theorem cert_e1107673418950 : check e1107673418950 [[]] .width = true := by decide
def e1107685736646 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107685736646 : Closed e1107685736646 ∧ code e1107685736646 = 5505732247750 := by decide
theorem cert_e1107685736646 : check e1107685736646 [[]] .width = true := by decide
def e1107685737174 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107685737174 : Closed e1107685737174 ∧ code e1107685737174 = 5505732248278 := by decide
theorem cert_e1107685737174 : check e1107685737174 [[]] .width = true := by decide
def e1107685737178 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107685737178 : Closed e1107685737178 ∧ code e1107685737178 = 5505732248282 := by decide
theorem cert_e1107685737178 : check e1107685737178 [[]] .width = true := by decide
def e1107685737194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107685737194 : Closed e1107685737194 ∧ code e1107685737194 = 5505732248298 := by decide
theorem cert_e1107685737194 : check e1107685737194 [[]] .width = true := by decide
def e1107685737270 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107685737270 : Closed e1107685737270 ∧ code e1107685737270 = 5505732248374 := by decide
theorem cert_e1107685737270 : check e1107685737270 [[]] .width = true := by decide
def e1107685737274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107685737274 : Closed e1107685737274 ∧ code e1107685737274 = 5505732248378 := by decide
theorem cert_e1107685737274 : check e1107685737274 [[]] .width = true := by decide
def e1107685737358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107685737358 : Closed e1107685737358 ∧ code e1107685737358 = 5505732248462 := by decide
theorem cert_e1107685737358 : check e1107685737358 [[]] .width = true := by decide
def e1107685737370 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107685737370 : Closed e1107685737370 ∧ code e1107685737370 = 5505732248474 := by decide
theorem cert_e1107685737370 : check e1107685737370 [[]] .width = true := by decide
def e1107685739290 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107685739290 : Closed e1107685739290 ∧ code e1107685739290 = 5505732250394 := by decide
theorem cert_e1107685739290 : check e1107685739290 [[]] .width = true := by decide
def e1107685739334 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107685739334 : Closed e1107685739334 ∧ code e1107685739334 = 5505732250438 := by decide
theorem cert_e1107685739334 : check e1107685739334 [[]] .width = true := by decide
def e1107685739574 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107685739574 : Closed e1107685739574 ∧ code e1107685739574 = 5505732250678 := by decide
theorem cert_e1107685739574 : check e1107685739574 [[]] .width = true := by decide
def e1107685739578 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107685739578 : Closed e1107685739578 ∧ code e1107685739578 = 5505732250682 := by decide
theorem cert_e1107685739578 : check e1107685739578 [[]] .width = true := by decide
def e1107685739718 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107685739718 : Closed e1107685739718 ∧ code e1107685739718 = 5505732250822 := by decide
theorem cert_e1107685739718 : check e1107685739718 [[]] .width = true := by decide
def e1107686088730 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107686088730 : Closed e1107686088730 ∧ code e1107686088730 = 5505732599834 := by decide
theorem cert_e1107686088730 : check e1107686088730 [[]] .width = true := by decide
def e1107686088822 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107686088822 : Closed e1107686088822 ∧ code e1107686088822 = 5505732599926 := by decide
theorem cert_e1107686088822 : check e1107686088822 [[]] .width = true := by decide
def e1107686089066 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107686089066 : Closed e1107686089066 ∧ code e1107686089066 = 5505732600170 := by decide
theorem cert_e1107686089066 : check e1107686089066 [[]] .width = true := by decide
def e1107686089114 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107686089114 : Closed e1107686089114 ∧ code e1107686089114 = 5505732600218 := by decide
theorem cert_e1107686089114 : check e1107686089114 [[]] .width = true := by decide
def e1107686129862 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107686129862 : Closed e1107686129862 ∧ code e1107686129862 = 5505732640966 := by decide
theorem cert_e1107686129862 : check e1107686129862 [[]] .width = true := by decide
def e1107686130390 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107686130390 : Closed e1107686130390 ∧ code e1107686130390 = 5505732641494 := by decide
theorem cert_e1107686130390 : check e1107686130390 [[]] .width = true := by decide
def e1107686130394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107686130394 : Closed e1107686130394 ∧ code e1107686130394 = 5505732641498 := by decide
theorem cert_e1107686130394 : check e1107686130394 [[]] .width = true := by decide
def e1107686130410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107686130410 : Closed e1107686130410 ∧ code e1107686130410 = 5505732641514 := by decide
theorem cert_e1107686130410 : check e1107686130410 [[]] .width = true := by decide
def e1107686130486 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107686130486 : Closed e1107686130486 ∧ code e1107686130486 = 5505732641590 := by decide
theorem cert_e1107686130486 : check e1107686130486 [[]] .width = true := by decide
def e1107686130490 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107686130490 : Closed e1107686130490 ∧ code e1107686130490 = 5505732641594 := by decide
theorem cert_e1107686130490 : check e1107686130490 [[]] .width = true := by decide
def e1107686130574 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107686130574 : Closed e1107686130574 ∧ code e1107686130574 = 5505732641678 := by decide
theorem cert_e1107686130574 : check e1107686130574 [[]] .width = true := by decide
def e1107686130586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107686130586 : Closed e1107686130586 ∧ code e1107686130586 = 5505732641690 := by decide
theorem cert_e1107686130586 : check e1107686130586 [[]] .width = true := by decide
def e1107686132506 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107686132506 : Closed e1107686132506 ∧ code e1107686132506 = 5505732643610 := by decide
theorem cert_e1107686132506 : check e1107686132506 [[]] .width = true := by decide
def e1107686132550 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107686132550 : Closed e1107686132550 ∧ code e1107686132550 = 5505732643654 := by decide
theorem cert_e1107686132550 : check e1107686132550 [[]] .width = true := by decide
def e1107686132790 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107686132790 : Closed e1107686132790 ∧ code e1107686132790 = 5505732643894 := by decide
theorem cert_e1107686132790 : check e1107686132790 [[]] .width = true := by decide
def e1107686132794 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107686132794 : Closed e1107686132794 ∧ code e1107686132794 = 5505732643898 := by decide
theorem cert_e1107686132794 : check e1107686132794 [[]] .width = true := by decide
def e1107686132934 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107686132934 : Closed e1107686132934 ∧ code e1107686132934 = 5505732644038 := by decide
theorem cert_e1107686132934 : check e1107686132934 [[]] .width = true := by decide
def e1107692150810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107692150810 : Closed e1107692150810 ∧ code e1107692150810 = 5505738661914 := by decide
theorem cert_e1107692150810 : check e1107692150810 [[]] .width = true := by decide
def e1107692150902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107692150902 : Closed e1107692150902 ∧ code e1107692150902 = 5505738662006 := by decide
theorem cert_e1107692150902 : check e1107692150902 [[]] .width = true := by decide
def e1107692151146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107692151146 : Closed e1107692151146 ∧ code e1107692151146 = 5505738662250 := by decide
theorem cert_e1107692151146 : check e1107692151146 [[]] .width = true := by decide
def e1107692151194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107692151194 : Closed e1107692151194 ∧ code e1107692151194 = 5505738662298 := by decide
theorem cert_e1107692151194 : check e1107692151194 [[]] .width = true := by decide
def e1107692290246 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107692290246 : Closed e1107692290246 ∧ code e1107692290246 = 5505738801350 := by decide
theorem cert_e1107692290246 : check e1107692290246 [[]] .width = true := by decide
def e1107692290774 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107692290774 : Closed e1107692290774 ∧ code e1107692290774 = 5505738801878 := by decide
theorem cert_e1107692290774 : check e1107692290774 [[]] .width = true := by decide
def e1107692290778 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107692290778 : Closed e1107692290778 ∧ code e1107692290778 = 5505738801882 := by decide
theorem cert_e1107692290778 : check e1107692290778 [[]] .width = true := by decide
def e1107692290794 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107692290794 : Closed e1107692290794 ∧ code e1107692290794 = 5505738801898 := by decide
theorem cert_e1107692290794 : check e1107692290794 [[]] .width = true := by decide
def e1107692290870 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107692290870 : Closed e1107692290870 ∧ code e1107692290870 = 5505738801974 := by decide
theorem cert_e1107692290870 : check e1107692290870 [[]] .width = true := by decide
def e1107692290874 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107692290874 : Closed e1107692290874 ∧ code e1107692290874 = 5505738801978 := by decide
theorem cert_e1107692290874 : check e1107692290874 [[]] .width = true := by decide
def e1107692290958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107692290958 : Closed e1107692290958 ∧ code e1107692290958 = 5505738802062 := by decide
theorem cert_e1107692290958 : check e1107692290958 [[]] .width = true := by decide
def e1107692290970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107692290970 : Closed e1107692290970 ∧ code e1107692290970 = 5505738802074 := by decide
theorem cert_e1107692290970 : check e1107692290970 [[]] .width = true := by decide
def e1107692292890 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107692292890 : Closed e1107692292890 ∧ code e1107692292890 = 5505738803994 := by decide
theorem cert_e1107692292890 : check e1107692292890 [[]] .width = true := by decide
def e1107692292934 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107692292934 : Closed e1107692292934 ∧ code e1107692292934 = 5505738804038 := by decide
theorem cert_e1107692292934 : check e1107692292934 [[]] .width = true := by decide
def e1107692293174 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107692293174 : Closed e1107692293174 ∧ code e1107692293174 = 5505738804278 := by decide
theorem cert_e1107692293174 : check e1107692293174 [[]] .width = true := by decide
def e1107692293178 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107692293178 : Closed e1107692293178 ∧ code e1107692293178 = 5505738804282 := by decide
theorem cert_e1107692293178 : check e1107692293178 [[]] .width = true := by decide
def e1107692293318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107692293318 : Closed e1107692293318 ∧ code e1107692293318 = 5505738804422 := by decide
theorem cert_e1107692293318 : check e1107692293318 [[]] .width = true := by decide
def e1107692380186 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107692380186 : Closed e1107692380186 ∧ code e1107692380186 = 5505738891290 := by decide
theorem cert_e1107692380186 : check e1107692380186 [[]] .width = true := by decide
def e1107692380278 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107692380278 : Closed e1107692380278 ∧ code e1107692380278 = 5505738891382 := by decide
theorem cert_e1107692380278 : check e1107692380278 [[]] .width = true := by decide
def e1107692380522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107692380522 : Closed e1107692380522 ∧ code e1107692380522 = 5505738891626 := by decide
theorem cert_e1107692380522 : check e1107692380522 [[]] .width = true := by decide
def e1107692380570 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107692380570 : Closed e1107692380570 ∧ code e1107692380570 = 5505738891674 := by decide
theorem cert_e1107692380570 : check e1107692380570 [[]] .width = true := by decide
def e1107692421318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107692421318 : Closed e1107692421318 ∧ code e1107692421318 = 5505738932422 := by decide
theorem cert_e1107692421318 : check e1107692421318 [[]] .width = true := by decide
def e1107692421846 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107692421846 : Closed e1107692421846 ∧ code e1107692421846 = 5505738932950 := by decide
theorem cert_e1107692421846 : check e1107692421846 [[]] .width = true := by decide
def e1107692421850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107692421850 : Closed e1107692421850 ∧ code e1107692421850 = 5505738932954 := by decide
theorem cert_e1107692421850 : check e1107692421850 [[]] .width = true := by decide
def e1107692421866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107692421866 : Closed e1107692421866 ∧ code e1107692421866 = 5505738932970 := by decide
theorem cert_e1107692421866 : check e1107692421866 [[]] .width = true := by decide
def e1107692421942 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107692421942 : Closed e1107692421942 ∧ code e1107692421942 = 5505738933046 := by decide
theorem cert_e1107692421942 : check e1107692421942 [[]] .width = true := by decide
def e1107692421946 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107692421946 : Closed e1107692421946 ∧ code e1107692421946 = 5505738933050 := by decide
theorem cert_e1107692421946 : check e1107692421946 [[]] .width = true := by decide
def e1107692422030 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107692422030 : Closed e1107692422030 ∧ code e1107692422030 = 5505738933134 := by decide
theorem cert_e1107692422030 : check e1107692422030 [[]] .width = true := by decide
def e1107692422042 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107692422042 : Closed e1107692422042 ∧ code e1107692422042 = 5505738933146 := by decide
theorem cert_e1107692422042 : check e1107692422042 [[]] .width = true := by decide
def e1107692423962 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107692423962 : Closed e1107692423962 ∧ code e1107692423962 = 5505738935066 := by decide
theorem cert_e1107692423962 : check e1107692423962 [[]] .width = true := by decide
def e1107692424006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107692424006 : Closed e1107692424006 ∧ code e1107692424006 = 5505738935110 := by decide
theorem cert_e1107692424006 : check e1107692424006 [[]] .width = true := by decide
def e1107692424246 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107692424246 : Closed e1107692424246 ∧ code e1107692424246 = 5505738935350 := by decide
theorem cert_e1107692424246 : check e1107692424246 [[]] .width = true := by decide
def e1107692424250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107692424250 : Closed e1107692424250 ∧ code e1107692424250 = 5505738935354 := by decide
theorem cert_e1107692424250 : check e1107692424250 [[]] .width = true := by decide
def e1107692424390 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107692424390 : Closed e1107692424390 ∧ code e1107692424390 = 5505738935494 := by decide
theorem cert_e1107692424390 : check e1107692424390 [[]] .width = true := by decide
def e1107799661422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1107799661422 : Closed e1107799661422 ∧ code e1107799661422 = 5505846172526 := by decide
theorem cert_e1107799661422 : check e1107799661422 [[],[.under,.under]] .three = true := by decide
def e1107799661430 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1107799661430 : Closed e1107799661430 ∧ code e1107799661430 = 5505846172534 := by decide
theorem cert_e1107799661430 : check e1107799661430 [[],[.under,.under]] .three = true := by decide
def e1107799661494 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1107799661494 : Closed e1107799661494 ∧ code e1107799661494 = 5505846172598 := by decide
theorem cert_e1107799661494 : check e1107799661494 [[],[.under,.under]] .three = true := by decide
def e1107799661934 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1107799661934 : Closed e1107799661934 ∧ code e1107799661934 = 5505846173038 := by decide
theorem cert_e1107799661934 : check e1107799661934 [[],[.under,.under]] .three = true := by decide
def e1107799661942 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1107799661942 : Closed e1107799661942 ∧ code e1107799661942 = 5505846173046 := by decide
theorem cert_e1107799661942 : check e1107799661942 [[],[.under,.under]] .three = true := by decide
def e1107799661998 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1107799661998 : Closed e1107799661998 ∧ code e1107799661998 = 5505846173102 := by decide
theorem cert_e1107799661998 : check e1107799661998 [[],[.under,.under]] .three = true := by decide
def e1107799662010 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1107799662010 : Closed e1107799662010 ∧ code e1107799662010 = 5505846173114 := by decide
theorem cert_e1107799662010 : check e1107799662010 [[],[.under,.under]] .three = true := by decide
def e1107799662038 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1107799662038 : Closed e1107799662038 ∧ code e1107799662038 = 5505846173142 := by decide
theorem cert_e1107799662038 : check e1107799662038 [[],[.under,.under]] .three = true := by decide
def e1107799662042 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1107799662042 : Closed e1107799662042 ∧ code e1107799662042 = 5505846173146 := by decide
theorem cert_e1107799662042 : check e1107799662042 [[],[.under,.under]] .three = true := by decide
def e1107799662262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1107799662262 : Closed e1107799662262 ∧ code e1107799662262 = 5505846173366 := by decide
theorem cert_e1107799662262 : check e1107799662262 [[],[.under,.under]] .three = true := by decide
def e1107799662294 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1107799662294 : Closed e1107799662294 ∧ code e1107799662294 = 5505846173398 := by decide
theorem cert_e1107799662294 : check e1107799662294 [[],[.under,.under]] .three = true := by decide
def e1107799662298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1107799662298 : Closed e1107799662298 ∧ code e1107799662298 = 5505846173402 := by decide
theorem cert_e1107799662298 : check e1107799662298 [[],[.under,.under]] .three = true := by decide
def e1107799664494 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1107799664494 : Closed e1107799664494 ∧ code e1107799664494 = 5505846175598 := by decide
theorem cert_e1107799664494 : check e1107799664494 [[],[.under,.under]] .three = true := by decide
def e1107799664502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1107799664502 : Closed e1107799664502 ∧ code e1107799664502 = 5505846175606 := by decide
theorem cert_e1107799664502 : check e1107799664502 [[],[.under,.under]] .three = true := by decide
def e1107799664566 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1107799664566 : Closed e1107799664566 ∧ code e1107799664566 = 5505846175670 := by decide
theorem cert_e1107799664566 : check e1107799664566 [[],[.under,.under]] .three = true := by decide
def e1107799665902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1107799665902 : Closed e1107799665902 ∧ code e1107799665902 = 5505846177006 := by decide
theorem cert_e1107799665902 : check e1107799665902 [[],[.under,.under]] .three = true := by decide
def e1107799665910 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1107799665910 : Closed e1107799665910 ∧ code e1107799665910 = 5505846177014 := by decide
theorem cert_e1107799665910 : check e1107799665910 [[],[.under,.under]] .three = true := by decide
def e1107799666294 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1107799666294 : Closed e1107799666294 ∧ code e1107799666294 = 5505846177398 := by decide
theorem cert_e1107799666294 : check e1107799666294 [[],[.under,.under]] .three = true := by decide
def e1107799667566 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1107799667566 : Closed e1107799667566 ∧ code e1107799667566 = 5505846178670 := by decide
theorem cert_e1107799667566 : check e1107799667566 [[],[.under,.under]] .three = true := by decide
def e1107799667574 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1107799667574 : Closed e1107799667574 ∧ code e1107799667574 = 5505846178678 := by decide
theorem cert_e1107799667574 : check e1107799667574 [[],[.under,.under]] .three = true := by decide
def e1107799667630 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1107799667630 : Closed e1107799667630 ∧ code e1107799667630 = 5505846178734 := by decide
theorem cert_e1107799667630 : check e1107799667630 [[],[.under,.under]] .three = true := by decide
def e1107799667642 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1107799667642 : Closed e1107799667642 ∧ code e1107799667642 = 5505846178746 := by decide
theorem cert_e1107799667642 : check e1107799667642 [[],[.under,.under]] .three = true := by decide
def e1107799667670 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1107799667670 : Closed e1107799667670 ∧ code e1107799667670 = 5505846178774 := by decide
theorem cert_e1107799667670 : check e1107799667670 [[],[.under,.under]] .three = true := by decide
def e1107799667674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1107799667674 : Closed e1107799667674 ∧ code e1107799667674 = 5505846178778 := by decide
theorem cert_e1107799667674 : check e1107799667674 [[],[.under,.under]] .three = true := by decide
end Blc.Floor42
