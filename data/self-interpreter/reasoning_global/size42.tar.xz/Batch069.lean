import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1195779382714 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1195779382714 : Closed e1195779382714 ∧ code e1195779382714 = 5593825893818 := by decide
def e1195779382742 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1195779382742 : Closed e1195779382742 ∧ code e1195779382742 = 5593825893846 := by decide
theorem cert_e1195779382742 : check e1195779382742 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1195779382746 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1195779382746 : Closed e1195779382746 ∧ code e1195779382746 = 5593825893850 := by decide
def e1195779382966 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1195779382966 : Closed e1195779382966 ∧ code e1195779382966 = 5593825894070 := by decide
theorem cert_e1195779382966 : check e1195779382966 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1195779382998 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1195779382998 : Closed e1195779382998 ∧ code e1195779382998 = 5593825894102 := by decide
theorem cert_e1195779382998 : check e1195779382998 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1195779383002 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1195779383002 : Closed e1195779383002 ∧ code e1195779383002 = 5593825894106 := by decide
def e1195779385198 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1195779385198 : Closed e1195779385198 ∧ code e1195779385198 = 5593825896302 := by decide
theorem cert_e1195779385198 : check e1195779385198 [[],[.left],[]] .sourceHead = true := by decide
def e1195779385206 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1195779385206 : Closed e1195779385206 ∧ code e1195779385206 = 5593825896310 := by decide
theorem cert_e1195779385206 : check e1195779385206 [[],[.left],[]] .sourceHead = true := by decide
def e1195779385270 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1195779385270 : Closed e1195779385270 ∧ code e1195779385270 = 5593825896374 := by decide
theorem cert_e1195779385270 : check e1195779385270 [[],[.left],[]] .sourceHead = true := by decide
def e1195779386606 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1195779386606 : Closed e1195779386606 ∧ code e1195779386606 = 5593825897710 := by decide
theorem cert_e1195779386606 : check e1195779386606 [[],[.left],[]] .sourceHead = true := by decide
def e1195779386614 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1195779386614 : Closed e1195779386614 ∧ code e1195779386614 = 5593825897718 := by decide
theorem cert_e1195779386614 : check e1195779386614 [[],[.left],[]] .sourceHead = true := by decide
def e1195779386998 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1195779386998 : Closed e1195779386998 ∧ code e1195779386998 = 5593825898102 := by decide
theorem cert_e1195779386998 : check e1195779386998 [[],[.left],[]] .sourceHead = true := by decide
def e1195779388270 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1195779388270 : Closed e1195779388270 ∧ code e1195779388270 = 5593825899374 := by decide
theorem cert_e1195779388270 : checkPay e1195779388270 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1195779388278 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1195779388278 : Closed e1195779388278 ∧ code e1195779388278 = 5593825899382 := by decide
theorem cert_e1195779388278 : check e1195779388278 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1195779388334 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1195779388334 : Closed e1195779388334 ∧ code e1195779388334 = 5593825899438 := by decide
theorem cert_e1195779388334 : check e1195779388334 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left,.left]] .identityHead = true := by decide
def e1195779388346 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1195779388346 : Closed e1195779388346 ∧ code e1195779388346 = 5593825899450 := by decide
theorem cert_e1195779388346 : checkPay e1195779388346 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e1195779388374 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1195779388374 : Closed e1195779388374 ∧ code e1195779388374 = 5593825899478 := by decide
theorem cert_e1195779388374 : check e1195779388374 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1195779388378 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1195779388378 : Closed e1195779388378 ∧ code e1195779388378 = 5593825899482 := by decide
theorem cert_e1195779388378 : checkPay e1195779388378 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1195779388654 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1195779388654 : Closed e1195779388654 ∧ code e1195779388654 = 5593825899758 := by decide
theorem cert_e1195779388654 : check e1195779388654 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1195779388662 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1195779388662 : Closed e1195779388662 ∧ code e1195779388662 = 5593825899766 := by decide
theorem cert_e1195779388662 : check e1195779388662 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1195779389038 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1195779389038 : Closed e1195779389038 ∧ code e1195779389038 = 5593825900142 := by decide
theorem cert_e1195779389038 : check e1195779389038 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1195779389050 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1195779389050 : Closed e1195779389050 ∧ code e1195779389050 = 5593825900154 := by decide
theorem cert_e1195779389050 : check e1195779389050 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1195779389238 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1195779389238 : Closed e1195779389238 ∧ code e1195779389238 = 5593825900342 := by decide
theorem cert_e1195779389238 : check e1195779389238 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1195779389242 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1195779389242 : Closed e1195779389242 ∧ code e1195779389242 = 5593825900346 := by decide
theorem cert_e1195779389242 : checkPay e1195779389242 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1195779389878 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1195779389878 : Closed e1195779389878 ∧ code e1195779389878 = 5593825900982 := by decide
theorem cert_e1195779389878 : check e1195779389878 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1195779389910 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1195779389910 : Closed e1195779389910 ∧ code e1195779389910 = 5593825901014 := by decide
theorem cert_e1195779389910 : check e1195779389910 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1195779389914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1195779389914 : Closed e1195779389914 ∧ code e1195779389914 = 5593825901018 := by decide
def e1195779390070 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1195779390070 : Closed e1195779390070 ∧ code e1195779390070 = 5593825901174 := by decide
theorem cert_e1195779390070 : check e1195779390070 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1195779390262 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1195779390262 : Closed e1195779390262 ∧ code e1195779390262 = 5593825901366 := by decide
theorem cert_e1195779390262 : check e1195779390262 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1195779390266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1195779390266 : Closed e1195779390266 ∧ code e1195779390266 = 5593825901370 := by decide
theorem cert_e1195779390266 : check e1195779390266 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1195779397486 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1195779397486 : Closed e1195779397486 ∧ code e1195779397486 = 5593825908590 := by decide
theorem cert_e1195779397486 : check e1195779397486 [[],[.left],[]] .sourceHead = true := by decide
def e1195779397494 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1195779397494 : Closed e1195779397494 ∧ code e1195779397494 = 5593825908598 := by decide
theorem cert_e1195779397494 : check e1195779397494 [[],[.left],[]] .sourceHead = true := by decide
def e1195779397558 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1195779397558 : Closed e1195779397558 ∧ code e1195779397558 = 5593825908662 := by decide
theorem cert_e1195779397558 : check e1195779397558 [[],[.left],[]] .sourceHead = true := by decide
def e1195779398894 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1195779398894 : Closed e1195779398894 ∧ code e1195779398894 = 5593825909998 := by decide
theorem cert_e1195779398894 : check e1195779398894 [[],[.left],[]] .sourceHead = true := by decide
def e1195779398902 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1195779398902 : Closed e1195779398902 ∧ code e1195779398902 = 5593825910006 := by decide
theorem cert_e1195779398902 : check e1195779398902 [[],[.left],[]] .sourceHead = true := by decide
def e1195779399286 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1195779399286 : Closed e1195779399286 ∧ code e1195779399286 = 5593825910390 := by decide
theorem cert_e1195779399286 : check e1195779399286 [[],[.left],[]] .sourceHead = true := by decide
def e1195779410798 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1195779410798 : Closed e1195779410798 ∧ code e1195779410798 = 5593825921902 := by decide
theorem cert_e1195779410798 : check e1195779410798 [[],[.left],[],[.under]] .three = true := by decide
def e1195779410806 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1195779410806 : Closed e1195779410806 ∧ code e1195779410806 = 5593825921910 := by decide
theorem cert_e1195779410806 : check e1195779410806 [[],[.left],[],[.under]] .three = true := by decide
def e1195779410862 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1195779410862 : Closed e1195779410862 ∧ code e1195779410862 = 5593825921966 := by decide
theorem cert_e1195779410862 : check e1195779410862 [[],[.left],[],[.under]] .three = true := by decide
def e1195779410874 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1195779410874 : Closed e1195779410874 ∧ code e1195779410874 = 5593825921978 := by decide
theorem cert_e1195779410874 : check e1195779410874 [[],[.left],[],[.under]] .three = true := by decide
def e1195779410902 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1195779410902 : Closed e1195779410902 ∧ code e1195779410902 = 5593825922006 := by decide
theorem cert_e1195779410902 : check e1195779410902 [[],[.left],[],[.under]] .three = true := by decide
def e1195779410906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1195779410906 : Closed e1195779410906 ∧ code e1195779410906 = 5593825922010 := by decide
theorem cert_e1195779410906 : check e1195779410906 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411182 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1195779411182 : Closed e1195779411182 ∧ code e1195779411182 = 5593825922286 := by decide
theorem cert_e1195779411182 : check e1195779411182 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411190 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1195779411190 : Closed e1195779411190 ∧ code e1195779411190 = 5593825922294 := by decide
theorem cert_e1195779411190 : check e1195779411190 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411566 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1195779411566 : Closed e1195779411566 ∧ code e1195779411566 = 5593825922670 := by decide
theorem cert_e1195779411566 : check e1195779411566 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411578 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1195779411578 : Closed e1195779411578 ∧ code e1195779411578 = 5593825922682 := by decide
theorem cert_e1195779411578 : check e1195779411578 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411766 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1195779411766 : Closed e1195779411766 ∧ code e1195779411766 = 5593825922870 := by decide
theorem cert_e1195779411766 : check e1195779411766 [[],[.left],[],[.under]] .three = true := by decide
def e1195779411770 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1195779411770 : Closed e1195779411770 ∧ code e1195779411770 = 5593825922874 := by decide
theorem cert_e1195779411770 : check e1195779411770 [[],[.left],[],[.under]] .three = true := by decide
def e1195779417526 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1195779417526 : Closed e1195779417526 ∧ code e1195779417526 = 5593825928630 := by decide
theorem cert_e1195779417526 : check e1195779417526 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779417558 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1195779417558 : Closed e1195779417558 ∧ code e1195779417558 = 5593825928662 := by decide
theorem cert_e1195779417558 : check e1195779417558 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779417562 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1195779417562 : Closed e1195779417562 ∧ code e1195779417562 = 5593825928666 := by decide
theorem cert_e1195779417562 : check e1195779417562 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779417718 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1195779417718 : Closed e1195779417718 ∧ code e1195779417718 = 5593825928822 := by decide
theorem cert_e1195779417718 : check e1195779417718 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779417910 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1195779417910 : Closed e1195779417910 ∧ code e1195779417910 = 5593825929014 := by decide
theorem cert_e1195779417910 : check e1195779417910 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779417914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1195779417914 : Closed e1195779417914 ∧ code e1195779417914 = 5593825929018 := by decide
theorem cert_e1195779417914 : check e1195779417914 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1195779754862 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1195779754862 : Closed e1195779754862 ∧ code e1195779754862 = 5593826265966 := by decide
theorem cert_e1195779754862 : check e1195779754862 [[],[.left],[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1195779754870 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1195779754870 : Closed e1195779754870 ∧ code e1195779754870 = 5593826265974 := by decide
private def t_e1195779754870 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1195779754870 : ¬ IsSelfInterpreter e1195779754870 :=
  wSource (t := t_e1195779754870) (replay_sound (ps := []) (t := e1195779754870) (by decide)) (by decide)
def e1195779754926 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1195779754926 : Closed e1195779754926 ∧ code e1195779754926 = 5593826266030 := by decide
theorem cert_e1195779754926 : check e1195779754926 [[],[.left],[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1195779754938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1195779754938 : Closed e1195779754938 ∧ code e1195779754938 = 5593826266042 := by decide
def e1195779754966 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1195779754966 : Closed e1195779754966 ∧ code e1195779754966 = 5593826266070 := by decide
private def t_e1195779754966 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1195779754966 : ¬ IsSelfInterpreter e1195779754966 :=
  wSource (t := t_e1195779754966) (replay_sound (ps := []) (t := e1195779754966) (by decide)) (by decide)
def e1195779754970 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1195779754970 : Closed e1195779754970 ∧ code e1195779754970 = 5593826266074 := by decide
def e1195779755246 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1195779755246 : Closed e1195779755246 ∧ code e1195779755246 = 5593826266350 := by decide
def e1195779755254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1195779755254 : Closed e1195779755254 ∧ code e1195779755254 = 5593826266358 := by decide
def e1195779755630 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1195779755630 : Closed e1195779755630 ∧ code e1195779755630 = 5593826266734 := by decide
theorem cert_e1195779755630 : check e1195779755630 [[],[.left],[],[.left],[],[],[.under],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1195779755642 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1195779755642 : Closed e1195779755642 ∧ code e1195779755642 = 5593826266746 := by decide
theorem cert_e1195779755642 : check e1195779755642 [[],[.left],[],[.left],[],[],[.under],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1195779755830 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1195779755830 : Closed e1195779755830 ∧ code e1195779755830 = 5593826266934 := by decide
def e1195779755834 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1195779755834 : Closed e1195779755834 ∧ code e1195779755834 = 5593826266938 := by decide
def e1196149890586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149890586 : Closed e1196149890586 ∧ code e1196149890586 = 5594196401690 := by decide
private def t_e1196149890586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149890586 : ¬ IsSelfInterpreter e1196149890586 :=
  wSource (t := t_e1196149890586) (replay_sound (ps := []) (t := e1196149890586) (by decide)) (by decide)
def e1196149896730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149896730 : Closed e1196149896730 ∧ code e1196149896730 = 5594196407834 := by decide
private def t_e1196149896730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149896730 : ¬ IsSelfInterpreter e1196149896730 :=
  wSource (t := t_e1196149896730) (replay_sound (ps := []) (t := e1196149896730) (by decide)) (by decide)
def e1196149923354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149923354 : Closed e1196149923354 ∧ code e1196149923354 = 5594196434458 := by decide
private def t_e1196149923354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149923354 : ¬ IsSelfInterpreter e1196149923354 :=
  wSource (t := t_e1196149923354) (replay_sound (ps := []) (t := e1196149923354) (by decide)) (by decide)
def e1196149930522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149930522 : Closed e1196149930522 ∧ code e1196149930522 = 5594196441626 := by decide
private def t_e1196149930522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149930522 : ¬ IsSelfInterpreter e1196149930522 :=
  wSource (t := t_e1196149930522) (replay_sound (ps := []) (t := e1196149930522) (by decide)) (by decide)
def e1196149954074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149954074 : Closed e1196149954074 ∧ code e1196149954074 = 5594196465178 := by decide
private def t_e1196149954074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149954074 : ¬ IsSelfInterpreter e1196149954074 :=
  wSource (t := t_e1196149954074) (replay_sound (ps := []) (t := e1196149954074) (by decide)) (by decide)
def e1196149955098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196149955098 : Closed e1196149955098 ∧ code e1196149955098 = 5594196466202 := by decide
private def t_e1196149955098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196149955098 : ¬ IsSelfInterpreter e1196149955098 :=
  wSource (t := t_e1196149955098) (replay_sound (ps := []) (t := e1196149955098) (by decide)) (by decide)
def e1196150087194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150087194 : Closed e1196150087194 ∧ code e1196150087194 = 5594196598298 := by decide
private def t_e1196150087194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150087194 : ¬ IsSelfInterpreter e1196150087194 :=
  wSource (t := t_e1196150087194) (replay_sound (ps := []) (t := e1196150087194) (by decide)) (by decide)
def e1196150093338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150093338 : Closed e1196150093338 ∧ code e1196150093338 = 5594196604442 := by decide
private def t_e1196150093338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150093338 : ¬ IsSelfInterpreter e1196150093338 :=
  wSource (t := t_e1196150093338) (replay_sound (ps := []) (t := e1196150093338) (by decide)) (by decide)
def e1196150283802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150283802 : Closed e1196150283802 ∧ code e1196150283802 = 5594196794906 := by decide
private def t_e1196150283802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150283802 : ¬ IsSelfInterpreter e1196150283802 :=
  wSource (t := t_e1196150283802) (replay_sound (ps := []) (t := e1196150283802) (by decide)) (by decide)
def e1196150290970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150290970 : Closed e1196150290970 ∧ code e1196150290970 = 5594196802074 := by decide
private def t_e1196150290970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150290970 : ¬ IsSelfInterpreter e1196150290970 :=
  wSource (t := t_e1196150290970) (replay_sound (ps := []) (t := e1196150290970) (by decide)) (by decide)
def e1196150437402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150437402 : Closed e1196150437402 ∧ code e1196150437402 = 5594196948506 := by decide
private def t_e1196150437402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150437402 : ¬ IsSelfInterpreter e1196150437402 :=
  wSource (t := t_e1196150437402) (replay_sound (ps := []) (t := e1196150437402) (by decide)) (by decide)
def e1196150438426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196150438426 : Closed e1196150438426 ∧ code e1196150438426 = 5594196949530 := by decide
private def t_e1196150438426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196150438426 : ¬ IsSelfInterpreter e1196150438426 :=
  wSource (t := t_e1196150438426) (replay_sound (ps := []) (t := e1196150438426) (by decide)) (by decide)
def e1196154220058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154220058 : Closed e1196154220058 ∧ code e1196154220058 = 5594200731162 := by decide
private def t_e1196154220058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154220058 : ¬ IsSelfInterpreter e1196154220058 :=
  wSource (t := t_e1196154220058) (replay_sound (ps := []) (t := e1196154220058) (by decide)) (by decide)
def e1196154222106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154222106 : Closed e1196154222106 ∧ code e1196154222106 = 5594200733210 := by decide
private def t_e1196154222106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154222106 : ¬ IsSelfInterpreter e1196154222106 :=
  wSource (t := t_e1196154222106) (replay_sound (ps := []) (t := e1196154222106) (by decide)) (by decide)
def e1196154363418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154363418 : Closed e1196154363418 ∧ code e1196154363418 = 5594200874522 := by decide
private def t_e1196154363418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154363418 : ¬ IsSelfInterpreter e1196154363418 :=
  wSource (t := t_e1196154363418) (replay_sound (ps := []) (t := e1196154363418) (by decide)) (by decide)
def e1196154384582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154384582 : Closed e1196154384582 ∧ code e1196154384582 = 5594200895686 := by decide
theorem cert_e1196154384582 : check e1196154384582 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154386458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154386458 : Closed e1196154386458 ∧ code e1196154386458 = 5594200897562 := by decide
theorem cert_e1196154386458 : check e1196154386458 [[]] .width = true := by decide
def e1196154392090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154392090 : Closed e1196154392090 ∧ code e1196154392090 = 5594200903194 := by decide
private def t_e1196154392090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154392090 : ¬ IsSelfInterpreter e1196154392090 :=
  wSource (t := t_e1196154392090) (replay_sound (ps := []) (t := e1196154392090) (by decide)) (by decide)
def e1196154400966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154400966 : Closed e1196154400966 ∧ code e1196154400966 = 5594200912070 := by decide
theorem cert_e1196154400966 : check e1196154400966 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154411034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154411034 : Closed e1196154411034 ∧ code e1196154411034 = 5594200922138 := by decide
theorem cert_e1196154411034 : check e1196154411034 [[]] .width = true := by decide
def e1196154449434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154449434 : Closed e1196154449434 ∧ code e1196154449434 = 5594200960538 := by decide
private def t_e1196154449434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154449434 : ¬ IsSelfInterpreter e1196154449434 :=
  wSource (t := t_e1196154449434) (replay_sound (ps := []) (t := e1196154449434) (by decide)) (by decide)
def e1196154452506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154452506 : Closed e1196154452506 ∧ code e1196154452506 = 5594200963610 := by decide
private def t_e1196154452506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154452506 : ¬ IsSelfInterpreter e1196154452506 :=
  wSource (t := t_e1196154452506) (replay_sound (ps := []) (t := e1196154452506) (by decide)) (by decide)
def e1196154494490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154494490 : Closed e1196154494490 ∧ code e1196154494490 = 5594201005594 := by decide
private def t_e1196154494490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154494490 : ¬ IsSelfInterpreter e1196154494490 :=
  wSource (t := t_e1196154494490) (replay_sound (ps := []) (t := e1196154494490) (by decide)) (by decide)
def e1196154515654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154515654 : Closed e1196154515654 ∧ code e1196154515654 = 5594201026758 := by decide
theorem cert_e1196154515654 : check e1196154515654 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154517530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154517530 : Closed e1196154517530 ∧ code e1196154517530 = 5594201028634 := by decide
theorem cert_e1196154517530 : check e1196154517530 [[]] .width = true := by decide
def e1196154537498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154537498 : Closed e1196154537498 ∧ code e1196154537498 = 5594201048602 := by decide
private def t_e1196154537498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154537498 : ¬ IsSelfInterpreter e1196154537498 :=
  wSource (t := t_e1196154537498) (replay_sound (ps := []) (t := e1196154537498) (by decide)) (by decide)
def e1196154540230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154540230 : Closed e1196154540230 ∧ code e1196154540230 = 5594201051334 := by decide
theorem cert_e1196154540230 : check e1196154540230 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154543642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154543642 : Closed e1196154543642 ∧ code e1196154543642 = 5594201054746 := by decide
private def t_e1196154543642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154543642 : ¬ IsSelfInterpreter e1196154543642 :=
  wSource (t := t_e1196154543642) (replay_sound (ps := []) (t := e1196154543642) (by decide)) (by decide)
def e1196154546202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154546202 : Closed e1196154546202 ∧ code e1196154546202 = 5594201057306 := by decide
theorem cert_e1196154546202 : check e1196154546202 [[]] .width = true := by decide
def e1196154547738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154547738 : Closed e1196154547738 ∧ code e1196154547738 = 5594201058842 := by decide
private def t_e1196154547738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154547738 : ¬ IsSelfInterpreter e1196154547738 :=
  wSource (t := t_e1196154547738) (replay_sound (ps := []) (t := e1196154547738) (by decide)) (by decide)
def e1196154566170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154566170 : Closed e1196154566170 ∧ code e1196154566170 = 5594201077274 := by decide
private def t_e1196154566170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154566170 : ¬ IsSelfInterpreter e1196154566170 :=
  wSource (t := t_e1196154566170) (replay_sound (ps := []) (t := e1196154566170) (by decide)) (by decide)
def e1196154567194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154567194 : Closed e1196154567194 ∧ code e1196154567194 = 5594201078298 := by decide
private def t_e1196154567194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154567194 : ¬ IsSelfInterpreter e1196154567194 :=
  wSource (t := t_e1196154567194) (replay_sound (ps := []) (t := e1196154567194) (by decide)) (by decide)
def e1196154588698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154588698 : Closed e1196154588698 ∧ code e1196154588698 = 5594201099802 := by decide
private def t_e1196154588698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154588698 : ¬ IsSelfInterpreter e1196154588698 :=
  wSource (t := t_e1196154588698) (replay_sound (ps := []) (t := e1196154588698) (by decide)) (by decide)
def e1196154597574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154597574 : Closed e1196154597574 ∧ code e1196154597574 = 5594201108678 := by decide
theorem cert_e1196154597574 : check e1196154597574 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154603034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154603034 : Closed e1196154603034 ∧ code e1196154603034 = 5594201114138 := by decide
private def t_e1196154603034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154603034 : ¬ IsSelfInterpreter e1196154603034 :=
  wSource (t := t_e1196154603034) (replay_sound (ps := []) (t := e1196154603034) (by decide)) (by decide)
def e1196154605766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196154605766 : Closed e1196154605766 ∧ code e1196154605766 = 5594201116870 := by decide
theorem cert_e1196154605766 : check e1196154605766 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196154609178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154609178 : Closed e1196154609178 ∧ code e1196154609178 = 5594201120282 := by decide
private def t_e1196154609178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154609178 : ¬ IsSelfInterpreter e1196154609178 :=
  wSource (t := t_e1196154609178) (replay_sound (ps := []) (t := e1196154609178) (by decide)) (by decide)
def e1196154615322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154615322 : Closed e1196154615322 ∧ code e1196154615322 = 5594201126426 := by decide
private def t_e1196154615322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154615322 : ¬ IsSelfInterpreter e1196154615322 :=
  wSource (t := t_e1196154615322) (replay_sound (ps := []) (t := e1196154615322) (by decide)) (by decide)
def e1196154640410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154640410 : Closed e1196154640410 ∧ code e1196154640410 = 5594201151514 := by decide
theorem cert_e1196154640410 : check e1196154640410 [[]] .width = true := by decide
def e1196154644506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196154644506 : Closed e1196154644506 ∧ code e1196154644506 = 5594201155610 := by decide
theorem cert_e1196154644506 : check e1196154644506 [[]] .width = true := by decide
def e1196154646042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154646042 : Closed e1196154646042 ∧ code e1196154646042 = 5594201157146 := by decide
private def t_e1196154646042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154646042 : ¬ IsSelfInterpreter e1196154646042 :=
  wSource (t := t_e1196154646042) (replay_sound (ps := []) (t := e1196154646042) (by decide)) (by decide)
def e1196154648090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196154648090 : Closed e1196154648090 ∧ code e1196154648090 = 5594201159194 := by decide
private def t_e1196154648090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196154648090 : ¬ IsSelfInterpreter e1196154648090 :=
  wSource (t := t_e1196154648090) (replay_sound (ps := []) (t := e1196154648090) (by decide)) (by decide)
def e1196155149850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155149850 : Closed e1196155149850 ∧ code e1196155149850 = 5594201660954 := by decide
private def t_e1196155149850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155149850 : ¬ IsSelfInterpreter e1196155149850 :=
  wSource (t := t_e1196155149850) (replay_sound (ps := []) (t := e1196155149850) (by decide)) (by decide)
def e1196155171014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196155171014 : Closed e1196155171014 ∧ code e1196155171014 = 5594201682118 := by decide
theorem cert_e1196155171014 : check e1196155171014 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196155172890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196155172890 : Closed e1196155172890 ∧ code e1196155172890 = 5594201683994 := by decide
theorem cert_e1196155172890 : check e1196155172890 [[]] .width = true := by decide
def e1196155178522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155178522 : Closed e1196155178522 ∧ code e1196155178522 = 5594201689626 := by decide
private def t_e1196155178522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155178522 : ¬ IsSelfInterpreter e1196155178522 :=
  wSource (t := t_e1196155178522) (replay_sound (ps := []) (t := e1196155178522) (by decide)) (by decide)
def e1196155187398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196155187398 : Closed e1196155187398 ∧ code e1196155187398 = 5594201698502 := by decide
theorem cert_e1196155187398 : check e1196155187398 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196155197466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196155197466 : Closed e1196155197466 ∧ code e1196155197466 = 5594201708570 := by decide
theorem cert_e1196155197466 : check e1196155197466 [[]] .width = true := by decide
def e1196155936282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155936282 : Closed e1196155936282 ∧ code e1196155936282 = 5594202447386 := by decide
private def t_e1196155936282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155936282 : ¬ IsSelfInterpreter e1196155936282 :=
  wSource (t := t_e1196155936282) (replay_sound (ps := []) (t := e1196155936282) (by decide)) (by decide)
def e1196155957446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196155957446 : Closed e1196155957446 ∧ code e1196155957446 = 5594202468550 := by decide
theorem cert_e1196155957446 : check e1196155957446 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196155959322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196155959322 : Closed e1196155959322 ∧ code e1196155959322 = 5594202470426 := by decide
theorem cert_e1196155959322 : check e1196155959322 [[]] .width = true := by decide
def e1196155979290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155979290 : Closed e1196155979290 ∧ code e1196155979290 = 5594202490394 := by decide
private def t_e1196155979290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155979290 : ¬ IsSelfInterpreter e1196155979290 :=
  wSource (t := t_e1196155979290) (replay_sound (ps := []) (t := e1196155979290) (by decide)) (by decide)
def e1196155982022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196155982022 : Closed e1196155982022 ∧ code e1196155982022 = 5594202493126 := by decide
theorem cert_e1196155982022 : check e1196155982022 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196155985434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155985434 : Closed e1196155985434 ∧ code e1196155985434 = 5594202496538 := by decide
private def t_e1196155985434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155985434 : ¬ IsSelfInterpreter e1196155985434 :=
  wSource (t := t_e1196155985434) (replay_sound (ps := []) (t := e1196155985434) (by decide)) (by decide)
def e1196155987994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196155987994 : Closed e1196155987994 ∧ code e1196155987994 = 5594202499098 := by decide
theorem cert_e1196155987994 : check e1196155987994 [[]] .width = true := by decide
def e1196155989530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196155989530 : Closed e1196155989530 ∧ code e1196155989530 = 5594202500634 := by decide
private def t_e1196155989530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196155989530 : ¬ IsSelfInterpreter e1196155989530 :=
  wSource (t := t_e1196155989530) (replay_sound (ps := []) (t := e1196155989530) (by decide)) (by decide)
def e1196156358170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156358170 : Closed e1196156358170 ∧ code e1196156358170 = 5594202869274 := by decide
private def t_e1196156358170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156358170 : ¬ IsSelfInterpreter e1196156358170 :=
  wSource (t := t_e1196156358170) (replay_sound (ps := []) (t := e1196156358170) (by decide)) (by decide)
def e1196156367046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196156367046 : Closed e1196156367046 ∧ code e1196156367046 = 5594202878150 := by decide
theorem cert_e1196156367046 : check e1196156367046 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196156372506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156372506 : Closed e1196156372506 ∧ code e1196156372506 = 5594202883610 := by decide
private def t_e1196156372506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156372506 : ¬ IsSelfInterpreter e1196156372506 :=
  wSource (t := t_e1196156372506) (replay_sound (ps := []) (t := e1196156372506) (by decide)) (by decide)
def e1196156375238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1196156375238 : Closed e1196156375238 ∧ code e1196156375238 = 5594202886342 := by decide
theorem cert_e1196156375238 : check e1196156375238 [[],[.left],[.left],[.left]] .smaller = true := by decide
def e1196156378650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156378650 : Closed e1196156378650 ∧ code e1196156378650 = 5594202889754 := by decide
private def t_e1196156378650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156378650 : ¬ IsSelfInterpreter e1196156378650 :=
  wSource (t := t_e1196156378650) (replay_sound (ps := []) (t := e1196156378650) (by decide)) (by decide)
def e1196156384794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156384794 : Closed e1196156384794 ∧ code e1196156384794 = 5594202895898 := by decide
private def t_e1196156384794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156384794 : ¬ IsSelfInterpreter e1196156384794 :=
  wSource (t := t_e1196156384794) (replay_sound (ps := []) (t := e1196156384794) (by decide)) (by decide)
def e1196156573722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196156573722 : Closed e1196156573722 ∧ code e1196156573722 = 5594203084826 := by decide
theorem cert_e1196156573722 : check e1196156573722 [[]] .width = true := by decide
def e1196156577818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196156577818 : Closed e1196156577818 ∧ code e1196156577818 = 5594203088922 := by decide
theorem cert_e1196156577818 : check e1196156577818 [[]] .width = true := by decide
def e1196156579354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156579354 : Closed e1196156579354 ∧ code e1196156579354 = 5594203090458 := by decide
private def t_e1196156579354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156579354 : ¬ IsSelfInterpreter e1196156579354 :=
  wSource (t := t_e1196156579354) (replay_sound (ps := []) (t := e1196156579354) (by decide)) (by decide)
def e1196156581402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196156581402 : Closed e1196156581402 ∧ code e1196156581402 = 5594203092506 := by decide
private def t_e1196156581402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196156581402 : ¬ IsSelfInterpreter e1196156581402 :=
  wSource (t := t_e1196156581402) (replay_sound (ps := []) (t := e1196156581402) (by decide)) (by decide)
def e1196171161114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171161114 : Closed e1196171161114 ∧ code e1196171161114 = 5594217672218 := by decide
private def t_e1196171161114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171161114 : ¬ IsSelfInterpreter e1196171161114 :=
  wSource (t := t_e1196171161114) (replay_sound (ps := []) (t := e1196171161114) (by decide)) (by decide)
def e1196171163162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171163162 : Closed e1196171163162 ∧ code e1196171163162 = 5594217674266 := by decide
private def t_e1196171163162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171163162 : ¬ IsSelfInterpreter e1196171163162 :=
  wSource (t := t_e1196171163162) (replay_sound (ps := []) (t := e1196171163162) (by decide)) (by decide)
def e1196171179546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171179546 : Closed e1196171179546 ∧ code e1196171179546 = 5594217690650 := by decide
private def t_e1196171179546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171179546 : ¬ IsSelfInterpreter e1196171179546 :=
  wSource (t := t_e1196171179546) (replay_sound (ps := []) (t := e1196171179546) (by decide)) (by decide)
def e1196171292186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171292186 : Closed e1196171292186 ∧ code e1196171292186 = 5594217803290 := by decide
private def t_e1196171292186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171292186 : ¬ IsSelfInterpreter e1196171292186 :=
  wSource (t := t_e1196171292186) (replay_sound (ps := []) (t := e1196171292186) (by decide)) (by decide)
def e1196171294234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171294234 : Closed e1196171294234 ∧ code e1196171294234 = 5594217805338 := by decide
private def t_e1196171294234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171294234 : ¬ IsSelfInterpreter e1196171294234 :=
  wSource (t := t_e1196171294234) (replay_sound (ps := []) (t := e1196171294234) (by decide)) (by decide)
def e1196171308570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171308570 : Closed e1196171308570 ∧ code e1196171308570 = 5594217819674 := by decide
private def t_e1196171308570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171308570 : ¬ IsSelfInterpreter e1196171308570 :=
  wSource (t := t_e1196171308570) (replay_sound (ps := []) (t := e1196171308570) (by decide)) (by decide)
def e1196171311642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171311642 : Closed e1196171311642 ∧ code e1196171311642 = 5594217822746 := by decide
private def t_e1196171311642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171311642 : ¬ IsSelfInterpreter e1196171311642 :=
  wSource (t := t_e1196171311642) (replay_sound (ps := []) (t := e1196171311642) (by decide)) (by decide)
def e1196171318810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171318810 : Closed e1196171318810 ∧ code e1196171318810 = 5594217829914 := by decide
private def t_e1196171318810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171318810 : ¬ IsSelfInterpreter e1196171318810 :=
  wSource (t := t_e1196171318810) (replay_sound (ps := []) (t := e1196171318810) (by decide)) (by decide)
def e1196171319834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171319834 : Closed e1196171319834 ∧ code e1196171319834 = 5594217830938 := by decide
private def t_e1196171319834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171319834 : ¬ IsSelfInterpreter e1196171319834 :=
  wSource (t := t_e1196171319834) (replay_sound (ps := []) (t := e1196171319834) (by decide)) (by decide)
def e1196171376154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171376154 : Closed e1196171376154 ∧ code e1196171376154 = 5594217887258 := by decide
private def t_e1196171376154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171376154 : ¬ IsSelfInterpreter e1196171376154 :=
  wSource (t := t_e1196171376154) (replay_sound (ps := []) (t := e1196171376154) (by decide)) (by decide)
def e1196171384346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171384346 : Closed e1196171384346 ∧ code e1196171384346 = 5594217895450 := by decide
private def t_e1196171384346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171384346 : ¬ IsSelfInterpreter e1196171384346 :=
  wSource (t := t_e1196171384346) (replay_sound (ps := []) (t := e1196171384346) (by decide)) (by decide)
def e1196171385370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171385370 : Closed e1196171385370 ∧ code e1196171385370 = 5594217896474 := by decide
private def t_e1196171385370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171385370 : ¬ IsSelfInterpreter e1196171385370 :=
  wSource (t := t_e1196171385370) (replay_sound (ps := []) (t := e1196171385370) (by decide)) (by decide)
def e1196171704346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196171704346 : Closed e1196171704346 ∧ code e1196171704346 = 5594218215450 := by decide
theorem cert_e1196171704346 : check e1196171704346 [[]] .width = true := by decide
def e1196171712538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196171712538 : Closed e1196171712538 ∧ code e1196171712538 = 5594218223642 := by decide
theorem cert_e1196171712538 : check e1196171712538 [[]] .width = true := by decide
def e1196171947546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171947546 : Closed e1196171947546 ∧ code e1196171947546 = 5594218458650 := by decide
private def t_e1196171947546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171947546 : ¬ IsSelfInterpreter e1196171947546 :=
  wSource (t := t_e1196171947546) (replay_sound (ps := []) (t := e1196171947546) (by decide)) (by decide)
def e1196171949594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171949594 : Closed e1196171949594 ∧ code e1196171949594 = 5594218460698 := by decide
private def t_e1196171949594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171949594 : ¬ IsSelfInterpreter e1196171949594 :=
  wSource (t := t_e1196171949594) (replay_sound (ps := []) (t := e1196171949594) (by decide)) (by decide)
def e1196171965978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196171965978 : Closed e1196171965978 ∧ code e1196171965978 = 5594218477082 := by decide
private def t_e1196171965978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196171965978 : ¬ IsSelfInterpreter e1196171965978 :=
  wSource (t := t_e1196171965978) (replay_sound (ps := []) (t := e1196171965978) (by decide)) (by decide)
def e1196172277786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172277786 : Closed e1196172277786 ∧ code e1196172277786 = 5594218788890 := by decide
theorem cert_e1196172277786 : check e1196172277786 [[]] .width = true := by decide
def e1196172307994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172307994 : Closed e1196172307994 ∧ code e1196172307994 = 5594218819098 := by decide
private def t_e1196172307994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172307994 : ¬ IsSelfInterpreter e1196172307994 :=
  wSource (t := t_e1196172307994) (replay_sound (ps := []) (t := e1196172307994) (by decide)) (by decide)
def e1196172310042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172310042 : Closed e1196172310042 ∧ code e1196172310042 = 5594218821146 := by decide
private def t_e1196172310042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172310042 : ¬ IsSelfInterpreter e1196172310042 :=
  wSource (t := t_e1196172310042) (replay_sound (ps := []) (t := e1196172310042) (by decide)) (by decide)
def e1196172361926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196172361926 : Closed e1196172361926 ∧ code e1196172361926 = 5594218873030 := by decide
theorem cert_e1196172361926 : check e1196172361926 [[]] .width = true := by decide
def e1196172392474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172392474 : Closed e1196172392474 ∧ code e1196172392474 = 5594218903578 := by decide
theorem cert_e1196172392474 : check e1196172392474 [[]] .width = true := by decide
def e1196172408346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172408346 : Closed e1196172408346 ∧ code e1196172408346 = 5594218919450 := by decide
private def t_e1196172408346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172408346 : ¬ IsSelfInterpreter e1196172408346 :=
  wSource (t := t_e1196172408346) (replay_sound (ps := []) (t := e1196172408346) (by decide)) (by decide)
def e1196172427462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196172427462 : Closed e1196172427462 ∧ code e1196172427462 = 5594218938566 := by decide
theorem cert_e1196172427462 : check e1196172427462 [[]] .width = true := by decide
def e1196172621850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172621850 : Closed e1196172621850 ∧ code e1196172621850 = 5594219132954 := by decide
theorem cert_e1196172621850 : check e1196172621850 [[]] .width = true := by decide
def e1196172634138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172634138 : Closed e1196172634138 ∧ code e1196172634138 = 5594219145242 := by decide
theorem cert_e1196172634138 : check e1196172634138 [[]] .width = true := by decide
def e1196172733978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172733978 : Closed e1196172733978 ∧ code e1196172733978 = 5594219245082 := by decide
private def t_e1196172733978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172733978 : ¬ IsSelfInterpreter e1196172733978 :=
  wSource (t := t_e1196172733978) (replay_sound (ps := []) (t := e1196172733978) (by decide)) (by decide)
def e1196172736026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172736026 : Closed e1196172736026 ∧ code e1196172736026 = 5594219247130 := by decide
private def t_e1196172736026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172736026 : ¬ IsSelfInterpreter e1196172736026 :=
  wSource (t := t_e1196172736026) (replay_sound (ps := []) (t := e1196172736026) (by decide)) (by decide)
end Blc.Floor42
