import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211271679598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211271679598 : Closed e1211271679598 ∧ code e1211271679598 = 5609318190702 := by decide
theorem cert_e1211271679598 : check e1211271679598 [[],[]] .sourceHead = true := by decide
def e1211271679610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211271679610 : Closed e1211271679610 ∧ code e1211271679610 = 5609318190714 := by decide
theorem cert_e1211271679610 : check e1211271679610 [[],[]] .sourceHead = true := by decide
def e1211271679798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211271679798 : Closed e1211271679798 ∧ code e1211271679798 = 5609318190902 := by decide
theorem cert_e1211271679798 : check e1211271679798 [[],[]] .sourceHead = true := by decide
def e1211271679802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211271679802 : Closed e1211271679802 ∧ code e1211271679802 = 5609318190906 := by decide
theorem cert_e1211271679802 : check e1211271679802 [[],[]] .sourceHead = true := by decide
def e1211271753146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1211271753146 : Closed e1211271753146 ∧ code e1211271753146 = 5609318264250 := by decide
theorem cert_e1211271753146 : check e1211271753146 [[],[]] .sourceHead = true := by decide
def e1211271753178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1211271753178 : Closed e1211271753178 ∧ code e1211271753178 = 5609318264282 := by decide
theorem cert_e1211271753178 : check e1211271753178 [[],[]] .sourceHead = true := by decide
def e1211271753402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1211271753402 : Closed e1211271753402 ∧ code e1211271753402 = 5609318264506 := by decide
theorem cert_e1211271753402 : check e1211271753402 [[],[]] .sourceHead = true := by decide
def e1211271753450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1211271753450 : Closed e1211271753450 ∧ code e1211271753450 = 5609318264554 := by decide
theorem cert_e1211271753450 : check e1211271753450 [[],[]] .sourceHead = true := by decide
def e1211271753562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211271753562 : Closed e1211271753562 ∧ code e1211271753562 = 5609318264666 := by decide
theorem cert_e1211271753562 : check e1211271753562 [[],[]] .sourceHead = true := by decide
def e1211271753578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211271753578 : Closed e1211271753578 ∧ code e1211271753578 = 5609318264682 := by decide
theorem cert_e1211271753578 : check e1211271753578 [[],[]] .sourceHead = true := by decide
def e1211271754682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1211271754682 : Closed e1211271754682 ∧ code e1211271754682 = 5609318265786 := by decide
theorem cert_e1211271754682 : check e1211271754682 [[],[]] .sourceHead = true := by decide
def e1211271754714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1211271754714 : Closed e1211271754714 ∧ code e1211271754714 = 5609318265818 := by decide
theorem cert_e1211271754714 : check e1211271754714 [[],[]] .sourceHead = true := by decide
def e1211271756218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1211271756218 : Closed e1211271756218 ∧ code e1211271756218 = 5609318267322 := by decide
theorem cert_e1211271756218 : check e1211271756218 [[],[]] .sourceHead = true := by decide
def e1211271756266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1211271756266 : Closed e1211271756266 ∧ code e1211271756266 = 5609318267370 := by decide
theorem cert_e1211271756266 : check e1211271756266 [[],[]] .sourceHead = true := by decide
def e1211271757018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211271757018 : Closed e1211271757018 ∧ code e1211271757018 = 5609318268122 := by decide
theorem cert_e1211271757018 : check e1211271757018 [[],[]] .sourceHead = true := by decide
def e1211271757034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211271757034 : Closed e1211271757034 ∧ code e1211271757034 = 5609318268138 := by decide
theorem cert_e1211271757034 : check e1211271757034 [[],[]] .sourceHead = true := by decide
def e1211271809902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211271809902 : Closed e1211271809902 ∧ code e1211271809902 = 5609318321006 := by decide
theorem cert_e1211271809902 : check e1211271809902 [[],[]] .sourceHead = true := by decide
def e1211271809910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211271809910 : Closed e1211271809910 ∧ code e1211271809910 = 5609318321014 := by decide
theorem cert_e1211271809910 : check e1211271809910 [[],[]] .sourceHead = true := by decide
def e1211271809966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211271809966 : Closed e1211271809966 ∧ code e1211271809966 = 5609318321070 := by decide
theorem cert_e1211271809966 : check e1211271809966 [[],[]] .sourceHead = true := by decide
def e1211271809978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211271809978 : Closed e1211271809978 ∧ code e1211271809978 = 5609318321082 := by decide
theorem cert_e1211271809978 : check e1211271809978 [[],[]] .sourceHead = true := by decide
def e1211271810006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211271810006 : Closed e1211271810006 ∧ code e1211271810006 = 5609318321110 := by decide
theorem cert_e1211271810006 : check e1211271810006 [[],[]] .sourceHead = true := by decide
def e1211271810010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211271810010 : Closed e1211271810010 ∧ code e1211271810010 = 5609318321114 := by decide
theorem cert_e1211271810010 : check e1211271810010 [[],[]] .sourceHead = true := by decide
def e1211271810286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211271810286 : Closed e1211271810286 ∧ code e1211271810286 = 5609318321390 := by decide
theorem cert_e1211271810286 : check e1211271810286 [[],[]] .sourceHead = true := by decide
def e1211271810294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211271810294 : Closed e1211271810294 ∧ code e1211271810294 = 5609318321398 := by decide
theorem cert_e1211271810294 : check e1211271810294 [[],[]] .sourceHead = true := by decide
def e1211271810670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211271810670 : Closed e1211271810670 ∧ code e1211271810670 = 5609318321774 := by decide
theorem cert_e1211271810670 : check e1211271810670 [[],[]] .sourceHead = true := by decide
def e1211271810682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211271810682 : Closed e1211271810682 ∧ code e1211271810682 = 5609318321786 := by decide
theorem cert_e1211271810682 : check e1211271810682 [[],[]] .sourceHead = true := by decide
def e1211271810870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211271810870 : Closed e1211271810870 ∧ code e1211271810870 = 5609318321974 := by decide
theorem cert_e1211271810870 : check e1211271810870 [[],[]] .sourceHead = true := by decide
def e1211271810874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211271810874 : Closed e1211271810874 ∧ code e1211271810874 = 5609318321978 := by decide
theorem cert_e1211271810874 : check e1211271810874 [[],[]] .sourceHead = true := by decide
def e1211272050410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)) (.var 0)))))
theorem wire_e1211272050410 : Closed e1211272050410 ∧ code e1211272050410 = 5609318561514 := by decide
theorem cert_e1211272050410 : check e1211272050410 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211272050538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 0)))))
theorem wire_e1211272050538 : Closed e1211272050538 ∧ code e1211272050538 = 5609318561642 := by decide
private def t_e1211272050538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 0)))))
theorem cert_e1211272050538 : ¬ IsSelfInterpreter e1211272050538 :=
  wSource (t := t_e1211272050538) (replay_sound (ps := []) (t := e1211272050538) (by decide)) (by decide)
def e1211272051434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)) (.var 0)))))
theorem wire_e1211272051434 : Closed e1211272051434 ∧ code e1211272051434 = 5609318562538 := by decide
theorem cert_e1211272051434 : check e1211272051434 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272051626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)) (.var 0)))))
theorem wire_e1211272051626 : Closed e1211272051626 ∧ code e1211272051626 = 5609318562730 := by decide
theorem cert_e1211272051626 : check e1211272051626 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272052074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 0)))))
theorem wire_e1211272052074 : Closed e1211272052074 ∧ code e1211272052074 = 5609318563178 := by decide
private def t_e1211272052074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 0)))))
theorem cert_e1211272052074 : ¬ IsSelfInterpreter e1211272052074 :=
  wSource (t := t_e1211272052074) (replay_sound (ps := []) (t := e1211272052074) (by decide)) (by decide)
def e1211272052138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)) (.var 0)))))
theorem wire_e1211272052138 : Closed e1211272052138 ∧ code e1211272052138 = 5609318563242 := by decide
theorem cert_e1211272052138 : check e1211272052138 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272056554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)) (.var 0)))))
theorem wire_e1211272056554 : Closed e1211272056554 ∧ code e1211272056554 = 5609318567658 := by decide
theorem cert_e1211272056554 : check e1211272056554 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272056682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)) (.var 0)))))
theorem wire_e1211272056682 : Closed e1211272056682 ∧ code e1211272056682 = 5609318567786 := by decide
theorem cert_e1211272056682 : check e1211272056682 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272062698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)) (.var 0)))))
theorem wire_e1211272062698 : Closed e1211272062698 ∧ code e1211272062698 = 5609318573802 := by decide
theorem cert_e1211272062698 : check e1211272062698 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272062890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)) (.var 0)))))
theorem wire_e1211272062890 : Closed e1211272062890 ∧ code e1211272062890 = 5609318573994 := by decide
theorem cert_e1211272062890 : check e1211272062890 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211272065898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)) (.var 0)))))
theorem wire_e1211272065898 : Closed e1211272065898 ∧ code e1211272065898 = 5609318577002 := by decide
theorem cert_e1211272065898 : check e1211272065898 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211272065962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)) (.var 0)))))
theorem wire_e1211272065962 : Closed e1211272065962 ∧ code e1211272065962 = 5609318577066 := by decide
theorem cert_e1211272065962 : check e1211272065962 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211272277434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1211272277434 : Closed e1211272277434 ∧ code e1211272277434 = 5609318788538 := by decide
theorem cert_e1211272277434 : check e1211272277434 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272277466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1211272277466 : Closed e1211272277466 ∧ code e1211272277466 = 5609318788570 := by decide
theorem cert_e1211272277466 : check e1211272277466 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272277690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1211272277690 : Closed e1211272277690 ∧ code e1211272277690 = 5609318788794 := by decide
theorem cert_e1211272277690 : check e1211272277690 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272277738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1211272277738 : Closed e1211272277738 ∧ code e1211272277738 = 5609318788842 := by decide
theorem cert_e1211272277738 : check e1211272277738 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272277850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211272277850 : Closed e1211272277850 ∧ code e1211272277850 = 5609318788954 := by decide
theorem cert_e1211272277850 : check e1211272277850 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272277866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211272277866 : Closed e1211272277866 ∧ code e1211272277866 = 5609318788970 := by decide
theorem cert_e1211272277866 : check e1211272277866 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272278970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1211272278970 : Closed e1211272278970 ∧ code e1211272278970 = 5609318790074 := by decide
theorem cert_e1211272278970 : check e1211272278970 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272279002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1211272279002 : Closed e1211272279002 ∧ code e1211272279002 = 5609318790106 := by decide
theorem cert_e1211272279002 : check e1211272279002 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272280506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1211272280506 : Closed e1211272280506 ∧ code e1211272280506 = 5609318791610 := by decide
theorem cert_e1211272280506 : check e1211272280506 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272280554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1211272280554 : Closed e1211272280554 ∧ code e1211272280554 = 5609318791658 := by decide
theorem cert_e1211272280554 : check e1211272280554 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272281306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211272281306 : Closed e1211272281306 ∧ code e1211272281306 = 5609318792410 := by decide
theorem cert_e1211272281306 : check e1211272281306 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272281322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211272281322 : Closed e1211272281322 ∧ code e1211272281322 = 5609318792426 := by decide
theorem cert_e1211272281322 : check e1211272281322 [[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211272334190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211272334190 : Closed e1211272334190 ∧ code e1211272334190 = 5609318845294 := by decide
theorem cert_e1211272334190 : check e1211272334190 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211272334198 : Closed e1211272334198 ∧ code e1211272334198 = 5609318845302 := by decide
theorem cert_e1211272334198 : check e1211272334198 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211272334254 : Closed e1211272334254 ∧ code e1211272334254 = 5609318845358 := by decide
theorem cert_e1211272334254 : check e1211272334254 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211272334266 : Closed e1211272334266 ∧ code e1211272334266 = 5609318845370 := by decide
theorem cert_e1211272334266 : check e1211272334266 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211272334294 : Closed e1211272334294 ∧ code e1211272334294 = 5609318845398 := by decide
theorem cert_e1211272334294 : check e1211272334294 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211272334298 : Closed e1211272334298 ∧ code e1211272334298 = 5609318845402 := by decide
theorem cert_e1211272334298 : check e1211272334298 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211272334574 : Closed e1211272334574 ∧ code e1211272334574 = 5609318845678 := by decide
theorem cert_e1211272334574 : check e1211272334574 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211272334582 : Closed e1211272334582 ∧ code e1211272334582 = 5609318845686 := by decide
theorem cert_e1211272334582 : check e1211272334582 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211272334958 : Closed e1211272334958 ∧ code e1211272334958 = 5609318846062 := by decide
theorem cert_e1211272334958 : check e1211272334958 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272334970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211272334970 : Closed e1211272334970 ∧ code e1211272334970 = 5609318846074 := by decide
theorem cert_e1211272334970 : check e1211272334970 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272335158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211272335158 : Closed e1211272335158 ∧ code e1211272335158 = 5609318846262 := by decide
theorem cert_e1211272335158 : check e1211272335158 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211272335162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211272335162 : Closed e1211272335162 ∧ code e1211272335162 = 5609318846266 := by decide
theorem cert_e1211272335162 : check e1211272335162 [[],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211273075578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0)))))
theorem wire_e1211273075578 : Closed e1211273075578 ∧ code e1211273075578 = 5609319586682 := by decide
theorem cert_e1211273075578 : check e1211273075578 [[],[]] .smaller = true := by decide
def e1211273075674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0)))))
theorem wire_e1211273075674 : Closed e1211273075674 ∧ code e1211273075674 = 5609319586778 := by decide
theorem cert_e1211273075674 : check e1211273075674 [[],[]] .smaller = true := by decide
def e1211273076090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0)))))
theorem wire_e1211273076090 : Closed e1211273076090 ∧ code e1211273076090 = 5609319587194 := by decide
theorem cert_e1211273076090 : check e1211273076090 [[],[]] .smaller = true := by decide
def e1211273076202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0)))))
theorem wire_e1211273076202 : Closed e1211273076202 ∧ code e1211273076202 = 5609319587306 := by decide
theorem cert_e1211273076202 : check e1211273076202 [[],[]] .smaller = true := by decide
def e1211273076570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e1211273076570 : Closed e1211273076570 ∧ code e1211273076570 = 5609319587674 := by decide
theorem cert_e1211273076570 : check e1211273076570 [[],[]] .smaller = true := by decide
def e1211273076586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e1211273076586 : Closed e1211273076586 ∧ code e1211273076586 = 5609319587690 := by decide
theorem cert_e1211273076586 : check e1211273076586 [[],[]] .smaller = true := by decide
def e1211273078650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0)))))
theorem wire_e1211273078650 : Closed e1211273078650 ∧ code e1211273078650 = 5609319589754 := by decide
theorem cert_e1211273078650 : check e1211273078650 [[],[]] .smaller = true := by decide
def e1211273078746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0)))))
theorem wire_e1211273078746 : Closed e1211273078746 ∧ code e1211273078746 = 5609319589850 := by decide
theorem cert_e1211273078746 : check e1211273078746 [[],[]] .smaller = true := by decide
def e1211273081722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0)))))
theorem wire_e1211273081722 : Closed e1211273081722 ∧ code e1211273081722 = 5609319592826 := by decide
theorem cert_e1211273081722 : check e1211273081722 [[],[]] .smaller = true := by decide
def e1211273081834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0)))))
theorem wire_e1211273081834 : Closed e1211273081834 ∧ code e1211273081834 = 5609319592938 := by decide
theorem cert_e1211273081834 : check e1211273081834 [[],[]] .smaller = true := by decide
def e1211273084122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e1211273084122 : Closed e1211273084122 ∧ code e1211273084122 = 5609319595226 := by decide
theorem cert_e1211273084122 : check e1211273084122 [[],[]] .smaller = true := by decide
def e1211273084138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e1211273084138 : Closed e1211273084138 ∧ code e1211273084138 = 5609319595242 := by decide
theorem cert_e1211273084138 : check e1211273084138 [[],[]] .smaller = true := by decide
def e1211273143226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0)))))
theorem wire_e1211273143226 : Closed e1211273143226 ∧ code e1211273143226 = 5609319654330 := by decide
theorem cert_e1211273143226 : check e1211273143226 [[],[]] .smaller = true := by decide
def e1211273143258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0)))))
theorem wire_e1211273143258 : Closed e1211273143258 ∧ code e1211273143258 = 5609319654362 := by decide
theorem cert_e1211273143258 : check e1211273143258 [[],[]] .smaller = true := by decide
def e1211273145466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e1211273145466 : Closed e1211273145466 ∧ code e1211273145466 = 5609319656570 := by decide
theorem cert_e1211273145466 : check e1211273145466 [[],[]] .smaller = true := by decide
def e1211273145798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1))))))
theorem wire_e1211273145798 : Closed e1211273145798 ∧ code e1211273145798 = 5609319656902 := by decide
theorem cert_e1211273145798 : check e1211273145798 [[],[]] .smaller = true := by decide
def e1211273145914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e1211273145914 : Closed e1211273145914 ∧ code e1211273145914 = 5609319657018 := by decide
theorem cert_e1211273145914 : check e1211273145914 [[],[]] .smaller = true := by decide
def e1211273146054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1))))))
theorem wire_e1211273146054 : Closed e1211273146054 ∧ code e1211273146054 = 5609319657158 := by decide
theorem cert_e1211273146054 : check e1211273146054 [[],[]] .smaller = true := by decide
def e1211273146102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))) (.var 1)))))
theorem wire_e1211273146102 : Closed e1211273146102 ∧ code e1211273146102 = 5609319657206 := by decide
theorem cert_e1211273146102 : check e1211273146102 [[],[]] .sourceHead = true := by decide
def e1211273146230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))) (.var 1)))))
theorem wire_e1211273146230 : Closed e1211273146230 ∧ code e1211273146230 = 5609319657334 := by decide
theorem cert_e1211273146230 : check e1211273146230 [[],[]] .sourceHead = true := by decide
def e1211273146810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0)))))
theorem wire_e1211273146810 : Closed e1211273146810 ∧ code e1211273146810 = 5609319657914 := by decide
theorem cert_e1211273146810 : check e1211273146810 [[],[]] .smaller = true := by decide
def e1211273146858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0)))))
theorem wire_e1211273146858 : Closed e1211273146858 ∧ code e1211273146858 = 5609319657962 := by decide
theorem cert_e1211273146858 : check e1211273146858 [[],[]] .smaller = true := by decide
def e1211273147514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e1211273147514 : Closed e1211273147514 ∧ code e1211273147514 = 5609319658618 := by decide
theorem cert_e1211273147514 : check e1211273147514 [[],[]] .smaller = true := by decide
def e1211273147846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1))))))
theorem wire_e1211273147846 : Closed e1211273147846 ∧ code e1211273147846 = 5609319658950 := by decide
theorem cert_e1211273147846 : check e1211273147846 [[],[]] .smaller = true := by decide
def e1211273148186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e1211273148186 : Closed e1211273148186 ∧ code e1211273148186 = 5609319659290 := by decide
theorem cert_e1211273148186 : check e1211273148186 [[],[]] .smaller = true := by decide
def e1211273148230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1))))))
theorem wire_e1211273148230 : Closed e1211273148230 ∧ code e1211273148230 = 5609319659334 := by decide
theorem cert_e1211273148230 : check e1211273148230 [[],[]] .smaller = true := by decide
def e1211273148282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))) (.var 0)))))
theorem wire_e1211273148282 : Closed e1211273148282 ∧ code e1211273148282 = 5609319659386 := by decide
theorem cert_e1211273148282 : check e1211273148282 [[],[]] .chain = true := by decide
def e1211273148346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))) (.var 0)))))
theorem wire_e1211273148346 : Closed e1211273148346 ∧ code e1211273148346 = 5609319659450 := by decide
theorem cert_e1211273148346 : check e1211273148346 [[],[]] .chain = true := by decide
def e1211273148634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0)))))
theorem wire_e1211273148634 : Closed e1211273148634 ∧ code e1211273148634 = 5609319659738 := by decide
theorem cert_e1211273148634 : check e1211273148634 [[],[]] .smaller = true := by decide
def e1211273148650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0)))))
theorem wire_e1211273148650 : Closed e1211273148650 ∧ code e1211273148650 = 5609319659754 := by decide
theorem cert_e1211273148650 : check e1211273148650 [[],[]] .smaller = true := by decide
def e1211273148986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e1211273148986 : Closed e1211273148986 ∧ code e1211273148986 = 5609319660090 := by decide
theorem cert_e1211273148986 : check e1211273148986 [[],[]] .smaller = true := by decide
def e1211273149126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1))))))
theorem wire_e1211273149126 : Closed e1211273149126 ∧ code e1211273149126 = 5609319660230 := by decide
theorem cert_e1211273149126 : check e1211273149126 [[],[]] .smaller = true := by decide
def e1211273149174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))) (.var 1)))))
theorem wire_e1211273149174 : Closed e1211273149174 ∧ code e1211273149174 = 5609319660278 := by decide
theorem cert_e1211273149174 : check e1211273149174 [[],[]] .sourceHead = true := by decide
def e1211273149210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e1211273149210 : Closed e1211273149210 ∧ code e1211273149210 = 5609319660314 := by decide
theorem cert_e1211273149210 : check e1211273149210 [[],[]] .smaller = true := by decide
def e1211273149254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1))))))
theorem wire_e1211273149254 : Closed e1211273149254 ∧ code e1211273149254 = 5609319660358 := by decide
theorem cert_e1211273149254 : check e1211273149254 [[],[]] .smaller = true := by decide
def e1211273149306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))) (.var 0)))))
theorem wire_e1211273149306 : Closed e1211273149306 ∧ code e1211273149306 = 5609319660410 := by decide
theorem cert_e1211273149306 : check e1211273149306 [[],[]] .chain = true := by decide
def e1211273149398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))) (.var 1)))))
theorem wire_e1211273149398 : Closed e1211273149398 ∧ code e1211273149398 = 5609319660502 := by decide
theorem cert_e1211273149398 : check e1211273149398 [[],[]] .sourceHead = true := by decide
def e1211273149402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))) (.var 0)))))
theorem wire_e1211273149402 : Closed e1211273149402 ∧ code e1211273149402 = 5609319660506 := by decide
theorem cert_e1211273149402 : check e1211273149402 [[],[]] .chain = true := by decide
def e1211273149814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e1211273149814 : Closed e1211273149814 ∧ code e1211273149814 = 5609319660918 := by decide
theorem cert_e1211273149814 : check e1211273149814 [[],[]] .sourceHead = true := by decide
def e1211273149882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211273149882 : Closed e1211273149882 ∧ code e1211273149882 = 5609319660986 := by decide
theorem cert_e1211273149882 : check e1211273149882 [[],[]] .chain = true := by decide
def e1211273149910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e1211273149910 : Closed e1211273149910 ∧ code e1211273149910 = 5609319661014 := by decide
theorem cert_e1211273149910 : check e1211273149910 [[],[]] .sourceHead = true := by decide
def e1211273149914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211273149914 : Closed e1211273149914 ∧ code e1211273149914 = 5609319661018 := by decide
theorem cert_e1211273149914 : check e1211273149914 [[],[]] .chain = true := by decide
def e1211273157754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0)))))
theorem wire_e1211273157754 : Closed e1211273157754 ∧ code e1211273157754 = 5609319668858 := by decide
theorem cert_e1211273157754 : check e1211273157754 [[],[]] .smaller = true := by decide
def e1211273158086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1))))))
theorem wire_e1211273158086 : Closed e1211273158086 ∧ code e1211273158086 = 5609319669190 := by decide
theorem cert_e1211273158086 : check e1211273158086 [[],[]] .smaller = true := by decide
def e1211273158202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0)))))
theorem wire_e1211273158202 : Closed e1211273158202 ∧ code e1211273158202 = 5609319669306 := by decide
theorem cert_e1211273158202 : check e1211273158202 [[],[]] .smaller = true := by decide
def e1211273158342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1))))))
theorem wire_e1211273158342 : Closed e1211273158342 ∧ code e1211273158342 = 5609319669446 := by decide
theorem cert_e1211273158342 : check e1211273158342 [[],[]] .smaller = true := by decide
def e1211273158390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))) (.var 1)))))
theorem wire_e1211273158390 : Closed e1211273158390 ∧ code e1211273158390 = 5609319669494 := by decide
theorem cert_e1211273158390 : check e1211273158390 [[],[]] .sourceHead = true := by decide
def e1211273158518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))) (.var 1)))))
theorem wire_e1211273158518 : Closed e1211273158518 ∧ code e1211273158518 = 5609319669622 := by decide
theorem cert_e1211273158518 : check e1211273158518 [[],[]] .sourceHead = true := by decide
def e1211273170042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0)))))
theorem wire_e1211273170042 : Closed e1211273170042 ∧ code e1211273170042 = 5609319681146 := by decide
theorem cert_e1211273170042 : check e1211273170042 [[],[]] .smaller = true := by decide
def e1211273170374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1))))))
theorem wire_e1211273170374 : Closed e1211273170374 ∧ code e1211273170374 = 5609319681478 := by decide
theorem cert_e1211273170374 : check e1211273170374 [[],[]] .smaller = true := by decide
def e1211273170714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0)))))
theorem wire_e1211273170714 : Closed e1211273170714 ∧ code e1211273170714 = 5609319681818 := by decide
theorem cert_e1211273170714 : check e1211273170714 [[],[]] .smaller = true := by decide
def e1211273170758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1))))))
theorem wire_e1211273170758 : Closed e1211273170758 ∧ code e1211273170758 = 5609319681862 := by decide
theorem cert_e1211273170758 : check e1211273170758 [[],[]] .smaller = true := by decide
def e1211273170810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))) (.var 0)))))
theorem wire_e1211273170810 : Closed e1211273170810 ∧ code e1211273170810 = 5609319681914 := by decide
theorem cert_e1211273170810 : check e1211273170810 [[],[]] .chain = true := by decide
def e1211273170874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))) (.var 0)))))
theorem wire_e1211273170874 : Closed e1211273170874 ∧ code e1211273170874 = 5609319681978 := by decide
theorem cert_e1211273170874 : check e1211273170874 [[],[]] .chain = true := by decide
def e1211273176634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0)))))
theorem wire_e1211273176634 : Closed e1211273176634 ∧ code e1211273176634 = 5609319687738 := by decide
theorem cert_e1211273176634 : check e1211273176634 [[],[]] .smaller = true := by decide
def e1211273176774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1))))))
theorem wire_e1211273176774 : Closed e1211273176774 ∧ code e1211273176774 = 5609319687878 := by decide
theorem cert_e1211273176774 : check e1211273176774 [[],[]] .smaller = true := by decide
def e1211273176822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))) (.var 1)))))
theorem wire_e1211273176822 : Closed e1211273176822 ∧ code e1211273176822 = 5609319687926 := by decide
theorem cert_e1211273176822 : check e1211273176822 [[],[]] .sourceHead = true := by decide
def e1211273176858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0)))))
theorem wire_e1211273176858 : Closed e1211273176858 ∧ code e1211273176858 = 5609319687962 := by decide
theorem cert_e1211273176858 : check e1211273176858 [[],[]] .smaller = true := by decide
def e1211273176902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1))))))
theorem wire_e1211273176902 : Closed e1211273176902 ∧ code e1211273176902 = 5609319688006 := by decide
theorem cert_e1211273176902 : check e1211273176902 [[],[]] .smaller = true := by decide
def e1211273176954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e1211273176954 : Closed e1211273176954 ∧ code e1211273176954 = 5609319688058 := by decide
theorem cert_e1211273176954 : check e1211273176954 [[],[]] .chain = true := by decide
def e1211273177046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))) (.var 1)))))
theorem wire_e1211273177046 : Closed e1211273177046 ∧ code e1211273177046 = 5609319688150 := by decide
theorem cert_e1211273177046 : check e1211273177046 [[],[]] .sourceHead = true := by decide
def e1211273177050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e1211273177050 : Closed e1211273177050 ∧ code e1211273177050 = 5609319688154 := by decide
theorem cert_e1211273177050 : check e1211273177050 [[],[]] .chain = true := by decide
def e1211273180022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e1211273180022 : Closed e1211273180022 ∧ code e1211273180022 = 5609319691126 := by decide
theorem cert_e1211273180022 : check e1211273180022 [[],[]] .sourceHead = true := by decide
def e1211273180090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211273180090 : Closed e1211273180090 ∧ code e1211273180090 = 5609319691194 := by decide
theorem cert_e1211273180090 : check e1211273180090 [[],[]] .chain = true := by decide
def e1211273180118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e1211273180118 : Closed e1211273180118 ∧ code e1211273180118 = 5609319691222 := by decide
theorem cert_e1211273180118 : check e1211273180118 [[],[]] .sourceHead = true := by decide
def e1211273180122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211273180122 : Closed e1211273180122 ∧ code e1211273180122 = 5609319691226 := by decide
theorem cert_e1211273180122 : check e1211273180122 [[],[]] .chain = true := by decide
def e1211273251694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211273251694 : Closed e1211273251694 ∧ code e1211273251694 = 5609319762798 := by decide
theorem cert_e1211273251694 : check e1211273251694 [[],[]] .chain = true := by decide
def e1211273251702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211273251702 : Closed e1211273251702 ∧ code e1211273251702 = 5609319762806 := by decide
theorem cert_e1211273251702 : check e1211273251702 [[],[]] .chain = true := by decide
def e1211273251758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211273251758 : Closed e1211273251758 ∧ code e1211273251758 = 5609319762862 := by decide
theorem cert_e1211273251758 : check e1211273251758 [[],[]] .chain = true := by decide
def e1211273251770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211273251770 : Closed e1211273251770 ∧ code e1211273251770 = 5609319762874 := by decide
theorem cert_e1211273251770 : check e1211273251770 [[],[]] .chain = true := by decide
def e1211273251798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211273251798 : Closed e1211273251798 ∧ code e1211273251798 = 5609319762902 := by decide
theorem cert_e1211273251798 : check e1211273251798 [[],[]] .chain = true := by decide
def e1211273251802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211273251802 : Closed e1211273251802 ∧ code e1211273251802 = 5609319762906 := by decide
theorem cert_e1211273251802 : check e1211273251802 [[],[]] .chain = true := by decide
def e1211273252078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211273252078 : Closed e1211273252078 ∧ code e1211273252078 = 5609319763182 := by decide
theorem cert_e1211273252078 : check e1211273252078 [[],[]] .chain = true := by decide
def e1211273252086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211273252086 : Closed e1211273252086 ∧ code e1211273252086 = 5609319763190 := by decide
theorem cert_e1211273252086 : check e1211273252086 [[],[]] .chain = true := by decide
def e1211273252462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211273252462 : Closed e1211273252462 ∧ code e1211273252462 = 5609319763566 := by decide
theorem cert_e1211273252462 : check e1211273252462 [[],[]] .chain = true := by decide
def e1211273252474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211273252474 : Closed e1211273252474 ∧ code e1211273252474 = 5609319763578 := by decide
theorem cert_e1211273252474 : check e1211273252474 [[],[]] .chain = true := by decide
def e1211273252662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211273252662 : Closed e1211273252662 ∧ code e1211273252662 = 5609319763766 := by decide
theorem cert_e1211273252662 : check e1211273252662 [[],[]] .chain = true := by decide
def e1211273252666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211273252666 : Closed e1211273252666 ∧ code e1211273252666 = 5609319763770 := by decide
theorem cert_e1211273252666 : check e1211273252666 [[],[]] .chain = true := by decide
def e1211273407350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1211273407350 : Closed e1211273407350 ∧ code e1211273407350 = 5609319918454 := by decide
theorem cert_e1211273407350 : check e1211273407350 [[],[]] .sourceHead = true := by decide
def e1211273407414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1211273407414 : Closed e1211273407414 ∧ code e1211273407414 = 5609319918518 := by decide
theorem cert_e1211273407414 : check e1211273407414 [[],[]] .sourceHead = true := by decide
def e1211273407862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1211273407862 : Closed e1211273407862 ∧ code e1211273407862 = 5609319918966 := by decide
theorem cert_e1211273407862 : check e1211273407862 [[],[]] .sourceHead = true := by decide
def e1211273407930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1211273407930 : Closed e1211273407930 ∧ code e1211273407930 = 5609319919034 := by decide
theorem cert_e1211273407930 : check e1211273407930 [[],[]] .chain = true := by decide
def e1211273407958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1211273407958 : Closed e1211273407958 ∧ code e1211273407958 = 5609319919062 := by decide
theorem cert_e1211273407958 : check e1211273407958 [[],[]] .sourceHead = true := by decide
def e1211273407962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1211273407962 : Closed e1211273407962 ∧ code e1211273407962 = 5609319919066 := by decide
theorem cert_e1211273407962 : check e1211273407962 [[],[]] .chain = true := by decide
def e1211273408182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1211273408182 : Closed e1211273408182 ∧ code e1211273408182 = 5609319919286 := by decide
theorem cert_e1211273408182 : check e1211273408182 [[],[]] .sourceHead = true := by decide
def e1211273408214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1211273408214 : Closed e1211273408214 ∧ code e1211273408214 = 5609319919318 := by decide
theorem cert_e1211273408214 : check e1211273408214 [[],[]] .sourceHead = true := by decide
def e1211273408218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))) (.var 0)))))
theorem wire_e1211273408218 : Closed e1211273408218 ∧ code e1211273408218 = 5609319919322 := by decide
theorem cert_e1211273408218 : check e1211273408218 [[],[]] .chain = true := by decide
def e1211273409910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1211273409910 : Closed e1211273409910 ∧ code e1211273409910 = 5609319921014 := by decide
theorem cert_e1211273409910 : check e1211273409910 [[],[]] .sourceHead = true := by decide
def e1211273409978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1211273409978 : Closed e1211273409978 ∧ code e1211273409978 = 5609319921082 := by decide
theorem cert_e1211273409978 : check e1211273409978 [[],[]] .chain = true := by decide
def e1211273410006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1211273410006 : Closed e1211273410006 ∧ code e1211273410006 = 5609319921110 := by decide
theorem cert_e1211273410006 : check e1211273410006 [[],[]] .sourceHead = true := by decide
def e1211273410010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1211273410010 : Closed e1211273410010 ∧ code e1211273410010 = 5609319921114 := by decide
theorem cert_e1211273410010 : check e1211273410010 [[],[]] .chain = true := by decide
def e1211273410234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1211273410234 : Closed e1211273410234 ∧ code e1211273410234 = 5609319921338 := by decide
theorem cert_e1211273410234 : check e1211273410234 [[],[]] .chain = true := by decide
def e1211273410282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1211273410282 : Closed e1211273410282 ∧ code e1211273410282 = 5609319921386 := by decide
theorem cert_e1211273410282 : check e1211273410282 [[],[]] .chain = true := by decide
def e1211273410390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 1)))))
theorem wire_e1211273410390 : Closed e1211273410390 ∧ code e1211273410390 = 5609319921494 := by decide
theorem cert_e1211273410390 : check e1211273410390 [[],[]] .sourceHead = true := by decide
def e1211273410394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211273410394 : Closed e1211273410394 ∧ code e1211273410394 = 5609319921498 := by decide
theorem cert_e1211273410394 : check e1211273410394 [[],[]] .chain = true := by decide
def e1211273410410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211273410410 : Closed e1211273410410 ∧ code e1211273410410 = 5609319921514 := by decide
theorem cert_e1211273410410 : check e1211273410410 [[],[]] .chain = true := by decide
end Blc.Floor42
