import CodeBridge
import R1209577550766Blk0
import R1209577550766Blk6
import R1209577550766Blk12
import R1209577550766Blk18
import R1209577550766Blk24
import R1209577550766Blk30
import R1209577550766Blk36
import R1209577550766Blk42
import R1209577550766Blk48
import R1209577550766Blk54
import R1209577550766Blk60
import R1209577550766Blk66
import R1209577550766Blk72
import R1209577550766Blk78
import R1209577550766Blk84
import R1209577550766Blk90
import R1209577550766Blk96
import R1209577550766Blk102
namespace Certgen.R1209577550766
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor42 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit146 : Term := .var 0
def lit109 : Term := .var 1
def lit64 : Term := .var 2
def lit101 : Term := .lam lit146
def lit108 : Term := .lam lit109
def lit100 : Term := .lam lit101
def lit144 : Term := .app lit146 lit146
def lit61 : Term := .app lit109 lit146
def lit107 : Term := .lam lit108
def lit110 : Term := .var 6
def lit143 : Term := .lam lit144
def lit98 : Term := .app lit146 lit100
def lit59 : Term := .app lit146 lit61
def lit105 : Term := .app lit146 lit107
def lit58 : Term := .app lit59 lit64
def lit138 : Term := .app lit143 lit143
def lit57 : Term := .lam lit58
def lit104 : Term := .app lit105 lit110
def lit103 : Term := .lam lit104
def lit55 : Term := .app lit109 lit57
def lit54 : Term := .lam lit55
def lit53 : Term := .lam lit54
def lit97 : Term := .app lit98 lit103
def lit96 : Term := .lam lit97
def lit90 : Term := .app lit105 lit96
def lit89 : Term := .lam lit90
def lit40 : Term := .app lit53 lit53
def lit83 : Term := .app lit105 lit89
def lit82 : Term := .lam lit83
def lit34 : Term := .app lit59 lit40
def lit33 : Term := .lam lit34
def lit76 : Term := .app lit105 lit82
def lit75 : Term := .lam lit76
def lit69 : Term := .app lit105 lit75
def lit68 : Term := .lam lit69
def lit7 : Term := .app lit40 lit33
def lit6 : Term := .lam lit7
def lit5 : Term := .app lit6 lit100
def lit4 : Term := .app lit5 lit68
def lit3 : Term := .app lit4 lit138
def lit2 : Term := .app lit3 lit138
def lit1 : Term := .app lit2 lit138
def lit0 : Term := .app lit1 lit138
def filling : Nat → Term := fun p => if p = 110 then Term.var 6 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub146 : model.term 146 = lit146 := model.var_eq 146 0 (by rfl)
theorem sub145 : model.term 145 = lit146 := model.var_eq 145 0 (by rfl)
theorem sub144 : model.term 144 = lit144 := by rw [model.app_eq 144 145 146 (by rfl), sub145, sub146]; rfl
theorem sub143 : model.term 143 = lit143 := by rw [model.lam_eq 143 144 (by rfl), sub144]; rfl
theorem sub142 : model.term 142 = lit146 := model.var_eq 142 0 (by rfl)
theorem sub141 : model.term 141 = lit146 := model.var_eq 141 0 (by rfl)
theorem sub140 : model.term 140 = lit144 := by rw [model.app_eq 140 141 142 (by rfl), sub141, sub142]; rfl
theorem sub139 : model.term 139 = lit143 := by rw [model.lam_eq 139 140 (by rfl), sub140]; rfl
theorem sub138 : model.term 138 = lit138 := by rw [model.app_eq 138 139 143 (by rfl), sub139, sub143]; rfl
theorem sub137 : model.term 137 = lit146 := model.var_eq 137 0 (by rfl)
theorem sub136 : model.term 136 = lit146 := model.var_eq 136 0 (by rfl)
theorem sub135 : model.term 135 = lit144 := by rw [model.app_eq 135 136 137 (by rfl), sub136, sub137]; rfl
theorem sub134 : model.term 134 = lit143 := by rw [model.lam_eq 134 135 (by rfl), sub135]; rfl
theorem sub133 : model.term 133 = lit146 := model.var_eq 133 0 (by rfl)
theorem sub132 : model.term 132 = lit146 := model.var_eq 132 0 (by rfl)
theorem sub131 : model.term 131 = lit144 := by rw [model.app_eq 131 132 133 (by rfl), sub132, sub133]; rfl
theorem sub130 : model.term 130 = lit143 := by rw [model.lam_eq 130 131 (by rfl), sub131]; rfl
theorem sub129 : model.term 129 = lit138 := by rw [model.app_eq 129 130 134 (by rfl), sub130, sub134]; rfl
theorem sub128 : model.term 128 = lit146 := model.var_eq 128 0 (by rfl)
theorem sub127 : model.term 127 = lit146 := model.var_eq 127 0 (by rfl)
theorem sub126 : model.term 126 = lit144 := by rw [model.app_eq 126 127 128 (by rfl), sub127, sub128]; rfl
theorem sub125 : model.term 125 = lit143 := by rw [model.lam_eq 125 126 (by rfl), sub126]; rfl
theorem sub124 : model.term 124 = lit146 := model.var_eq 124 0 (by rfl)
theorem sub123 : model.term 123 = lit146 := model.var_eq 123 0 (by rfl)
theorem sub122 : model.term 122 = lit144 := by rw [model.app_eq 122 123 124 (by rfl), sub123, sub124]; rfl
theorem sub121 : model.term 121 = lit143 := by rw [model.lam_eq 121 122 (by rfl), sub122]; rfl
theorem sub120 : model.term 120 = lit138 := by rw [model.app_eq 120 121 125 (by rfl), sub121, sub125]; rfl
theorem sub119 : model.term 119 = lit146 := model.var_eq 119 0 (by rfl)
theorem sub118 : model.term 118 = lit146 := model.var_eq 118 0 (by rfl)
theorem sub117 : model.term 117 = lit144 := by rw [model.app_eq 117 118 119 (by rfl), sub118, sub119]; rfl
theorem sub116 : model.term 116 = lit143 := by rw [model.lam_eq 116 117 (by rfl), sub117]; rfl
theorem sub115 : model.term 115 = lit146 := model.var_eq 115 0 (by rfl)
theorem sub114 : model.term 114 = lit146 := model.var_eq 114 0 (by rfl)
theorem sub113 : model.term 113 = lit144 := by rw [model.app_eq 113 114 115 (by rfl), sub114, sub115]; rfl
theorem sub112 : model.term 112 = lit143 := by rw [model.lam_eq 112 113 (by rfl), sub113]; rfl
theorem sub111 : model.term 111 = lit138 := by rw [model.app_eq 111 112 116 (by rfl), sub112, sub116]; rfl
theorem sub110 : model.term 110 = lit110 := (opaqueTerm (rankedCode code ordered_code) filling (p := 110) (by rfl)).trans (by rfl)
theorem sub109 : model.term 109 = lit109 := model.var_eq 109 1 (by rfl)
theorem sub108 : model.term 108 = lit108 := by rw [model.lam_eq 108 109 (by rfl), sub109]; rfl
theorem sub107 : model.term 107 = lit107 := by rw [model.lam_eq 107 108 (by rfl), sub108]; rfl
theorem sub106 : model.term 106 = lit146 := model.var_eq 106 0 (by rfl)
theorem sub105 : model.term 105 = lit105 := by rw [model.app_eq 105 106 107 (by rfl), sub106, sub107]; rfl
theorem sub104 : model.term 104 = lit104 := by rw [model.app_eq 104 105 110 (by rfl), sub105, sub110]; rfl
theorem sub103 : model.term 103 = lit103 := by rw [model.lam_eq 103 104 (by rfl), sub104]; rfl
theorem sub102 : model.term 102 = lit146 := model.var_eq 102 0 (by rfl)
theorem sub101 : model.term 101 = lit101 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit100 := by rw [model.lam_eq 100 101 (by rfl), sub101]; rfl
theorem sub99 : model.term 99 = lit146 := model.var_eq 99 0 (by rfl)
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 100 (by rfl), sub99, sub100]; rfl
theorem sub97 : model.term 97 = lit97 := by rw [model.app_eq 97 98 103 (by rfl), sub98, sub103]; rfl
theorem sub96 : model.term 96 = lit96 := by rw [model.lam_eq 96 97 (by rfl), sub97]; rfl
theorem sub95 : model.term 95 = lit109 := model.var_eq 95 1 (by rfl)
theorem sub94 : model.term 94 = lit108 := by rw [model.lam_eq 94 95 (by rfl), sub95]; rfl
theorem sub93 : model.term 93 = lit107 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit146 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit105 := by rw [model.app_eq 91 92 93 (by rfl), sub92, sub93]; rfl
theorem sub90 : model.term 90 = lit90 := by rw [model.app_eq 90 91 96 (by rfl), sub91, sub96]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit109 := model.var_eq 88 1 (by rfl)
theorem sub87 : model.term 87 = lit108 := by rw [model.lam_eq 87 88 (by rfl), sub88]; rfl
theorem sub86 : model.term 86 = lit107 := by rw [model.lam_eq 86 87 (by rfl), sub87]; rfl
theorem sub85 : model.term 85 = lit146 := model.var_eq 85 0 (by rfl)
theorem sub84 : model.term 84 = lit105 := by rw [model.app_eq 84 85 86 (by rfl), sub85, sub86]; rfl
theorem sub83 : model.term 83 = lit83 := by rw [model.app_eq 83 84 89 (by rfl), sub84, sub89]; rfl
theorem sub82 : model.term 82 = lit82 := by rw [model.lam_eq 82 83 (by rfl), sub83]; rfl
theorem sub81 : model.term 81 = lit109 := model.var_eq 81 1 (by rfl)
theorem sub80 : model.term 80 = lit108 := by rw [model.lam_eq 80 81 (by rfl), sub81]; rfl
theorem sub79 : model.term 79 = lit107 := by rw [model.lam_eq 79 80 (by rfl), sub80]; rfl
theorem sub78 : model.term 78 = lit146 := model.var_eq 78 0 (by rfl)
theorem sub77 : model.term 77 = lit105 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit76 := by rw [model.app_eq 76 77 82 (by rfl), sub77, sub82]; rfl
theorem sub75 : model.term 75 = lit75 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit109 := model.var_eq 74 1 (by rfl)
theorem sub73 : model.term 73 = lit108 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit107 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit146 := model.var_eq 71 0 (by rfl)
theorem sub70 : model.term 70 = lit105 := by rw [model.app_eq 70 71 72 (by rfl), sub71, sub72]; rfl
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 75 (by rfl), sub70, sub75]; rfl
theorem sub68 : model.term 68 = lit68 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit146 := model.var_eq 67 0 (by rfl)
theorem sub66 : model.term 66 = lit101 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit100 := by rw [model.lam_eq 65 66 (by rfl), sub66]; rfl
theorem sub64 : model.term 64 = lit64 := model.var_eq 64 2 (by rfl)
theorem sub63 : model.term 63 = lit146 := model.var_eq 63 0 (by rfl)
theorem sub62 : model.term 62 = lit109 := model.var_eq 62 1 (by rfl)
theorem sub61 : model.term 61 = lit61 := by rw [model.app_eq 61 62 63 (by rfl), sub62, sub63]; rfl
theorem sub60 : model.term 60 = lit146 := model.var_eq 60 0 (by rfl)
theorem sub59 : model.term 59 = lit59 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit58 := by rw [model.app_eq 58 59 64 (by rfl), sub59, sub64]; rfl
theorem sub57 : model.term 57 = lit57 := by rw [model.lam_eq 57 58 (by rfl), sub58]; rfl
theorem sub56 : model.term 56 = lit109 := model.var_eq 56 1 (by rfl)
theorem sub55 : model.term 55 = lit55 := by rw [model.app_eq 55 56 57 (by rfl), sub56, sub57]; rfl
theorem sub54 : model.term 54 = lit54 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit53 := by rw [model.lam_eq 53 54 (by rfl), sub54]; rfl
theorem sub52 : model.term 52 = lit64 := model.var_eq 52 2 (by rfl)
theorem sub51 : model.term 51 = lit146 := model.var_eq 51 0 (by rfl)
theorem sub50 : model.term 50 = lit109 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit61 := by rw [model.app_eq 49 50 51 (by rfl), sub50, sub51]; rfl
theorem sub48 : model.term 48 = lit146 := model.var_eq 48 0 (by rfl)
theorem sub47 : model.term 47 = lit59 := by rw [model.app_eq 47 48 49 (by rfl), sub48, sub49]; rfl
theorem sub46 : model.term 46 = lit58 := by rw [model.app_eq 46 47 52 (by rfl), sub47, sub52]; rfl
theorem sub45 : model.term 45 = lit57 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit109 := model.var_eq 44 1 (by rfl)
theorem sub43 : model.term 43 = lit55 := by rw [model.app_eq 43 44 45 (by rfl), sub44, sub45]; rfl
theorem sub42 : model.term 42 = lit54 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit53 := by rw [model.lam_eq 41 42 (by rfl), sub42]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.app_eq 40 41 53 (by rfl), sub41, sub53]; rfl
theorem sub39 : model.term 39 = lit146 := model.var_eq 39 0 (by rfl)
theorem sub38 : model.term 38 = lit109 := model.var_eq 38 1 (by rfl)
theorem sub37 : model.term 37 = lit61 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit146 := model.var_eq 36 0 (by rfl)
theorem sub35 : model.term 35 = lit59 := by rw [model.app_eq 35 36 37 (by rfl), sub36, sub37]; rfl
theorem sub34 : model.term 34 = lit34 := by rw [model.app_eq 34 35 40 (by rfl), sub35, sub40]; rfl
theorem sub33 : model.term 33 = lit33 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit64 := model.var_eq 32 2 (by rfl)
theorem sub31 : model.term 31 = lit146 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit109 := model.var_eq 30 1 (by rfl)
theorem sub29 : model.term 29 = lit61 := by rw [model.app_eq 29 30 31 (by rfl), sub30, sub31]; rfl
theorem sub28 : model.term 28 = lit146 := model.var_eq 28 0 (by rfl)
theorem sub27 : model.term 27 = lit59 := by rw [model.app_eq 27 28 29 (by rfl), sub28, sub29]; rfl
theorem sub26 : model.term 26 = lit58 := by rw [model.app_eq 26 27 32 (by rfl), sub27, sub32]; rfl
theorem sub25 : model.term 25 = lit57 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit109 := model.var_eq 24 1 (by rfl)
theorem sub23 : model.term 23 = lit55 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit54 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit53 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit64 := model.var_eq 20 2 (by rfl)
theorem sub19 : model.term 19 = lit146 := model.var_eq 19 0 (by rfl)
theorem sub18 : model.term 18 = lit109 := model.var_eq 18 1 (by rfl)
theorem sub17 : model.term 17 = lit61 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit146 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit59 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit58 := by rw [model.app_eq 14 15 20 (by rfl), sub15, sub20]; rfl
theorem sub13 : model.term 13 = lit57 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit109 := model.var_eq 12 1 (by rfl)
theorem sub11 : model.term 11 = lit55 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit54 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit53 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit40 := by rw [model.app_eq 8 9 21 (by rfl), sub9, sub21]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.app_eq 7 8 33 (by rfl), sub8, sub33]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 65 (by rfl), sub6, sub65]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 68 (by rfl), sub5, sub68]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 111 (by rfl), sub4, sub111]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 120 (by rfl), sub3, sub120]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 129 (by rfl), sub2, sub129]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 138 (by rfl), sub1, sub138]; rfl
theorem allValid (i : Nat) (h : i < 1265) : validState i = true := by
 by_cases h636 : i < 636
 · by_cases h312 : i < 312
   · by_cases h156 : i < 156
     · by_cases h72 : i < 72
       · by_cases h36 : i < 36
         · by_cases h12 : i < 12
           · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
           · by_cases h24 : i < 24
             · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
         · by_cases h48 : i < 48
           · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
           · by_cases h60 : i < 60
             · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
       · by_cases h108 : i < 108
         · by_cases h84 : i < 84
           · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
           · by_cases h96 : i < 96
             · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
         · by_cases h132 : i < 132
           · by_cases h120 : i < 120
             · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
           · by_cases h144 : i < 144
             · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
     · by_cases h228 : i < 228
       · by_cases h192 : i < 192
         · by_cases h168 : i < 168
           · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
           · by_cases h180 : i < 180
             · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
         · by_cases h204 : i < 204
           · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
           · by_cases h216 : i < 216
             · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
       · by_cases h264 : i < 264
         · by_cases h240 : i < 240
           · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
           · by_cases h252 : i < 252
             · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
         · by_cases h288 : i < 288
           · by_cases h276 : i < 276
             · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
           · by_cases h300 : i < 300
             · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
   · by_cases h468 : i < 468
     · by_cases h384 : i < 384
       · by_cases h348 : i < 348
         · by_cases h324 : i < 324
           · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
           · by_cases h336 : i < 336
             · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
         · by_cases h360 : i < 360
           · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
           · by_cases h372 : i < 372
             · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
       · by_cases h420 : i < 420
         · by_cases h396 : i < 396
           · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
           · by_cases h408 : i < 408
             · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
         · by_cases h444 : i < 444
           · by_cases h432 : i < 432
             · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
           · by_cases h456 : i < 456
             · exact FloorIndex.rangeOK_at bl444 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl456 (by omega) (by omega)
     · by_cases h552 : i < 552
       · by_cases h504 : i < 504
         · by_cases h480 : i < 480
           · exact FloorIndex.rangeOK_at bl468 (by omega) (by omega)
           · by_cases h492 : i < 492
             · exact FloorIndex.rangeOK_at bl480 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl492 (by omega) (by omega)
         · by_cases h528 : i < 528
           · by_cases h516 : i < 516
             · exact FloorIndex.rangeOK_at bl504 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl516 (by omega) (by omega)
           · by_cases h540 : i < 540
             · exact FloorIndex.rangeOK_at bl528 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl540 (by omega) (by omega)
       · by_cases h588 : i < 588
         · by_cases h564 : i < 564
           · exact FloorIndex.rangeOK_at bl552 (by omega) (by omega)
           · by_cases h576 : i < 576
             · exact FloorIndex.rangeOK_at bl564 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl576 (by omega) (by omega)
         · by_cases h612 : i < 612
           · by_cases h600 : i < 600
             · exact FloorIndex.rangeOK_at bl588 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl600 (by omega) (by omega)
           · by_cases h624 : i < 624
             · exact FloorIndex.rangeOK_at bl612 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl624 (by omega) (by omega)
 · by_cases h948 : i < 948
   · by_cases h792 : i < 792
     · by_cases h708 : i < 708
       · by_cases h672 : i < 672
         · by_cases h648 : i < 648
           · exact FloorIndex.rangeOK_at bl636 (by omega) (by omega)
           · by_cases h660 : i < 660
             · exact FloorIndex.rangeOK_at bl648 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl660 (by omega) (by omega)
         · by_cases h684 : i < 684
           · exact FloorIndex.rangeOK_at bl672 (by omega) (by omega)
           · by_cases h696 : i < 696
             · exact FloorIndex.rangeOK_at bl684 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl696 (by omega) (by omega)
       · by_cases h744 : i < 744
         · by_cases h720 : i < 720
           · exact FloorIndex.rangeOK_at bl708 (by omega) (by omega)
           · by_cases h732 : i < 732
             · exact FloorIndex.rangeOK_at bl720 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl732 (by omega) (by omega)
         · by_cases h768 : i < 768
           · by_cases h756 : i < 756
             · exact FloorIndex.rangeOK_at bl744 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl756 (by omega) (by omega)
           · by_cases h780 : i < 780
             · exact FloorIndex.rangeOK_at bl768 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl780 (by omega) (by omega)
     · by_cases h864 : i < 864
       · by_cases h828 : i < 828
         · by_cases h804 : i < 804
           · exact FloorIndex.rangeOK_at bl792 (by omega) (by omega)
           · by_cases h816 : i < 816
             · exact FloorIndex.rangeOK_at bl804 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl816 (by omega) (by omega)
         · by_cases h840 : i < 840
           · exact FloorIndex.rangeOK_at bl828 (by omega) (by omega)
           · by_cases h852 : i < 852
             · exact FloorIndex.rangeOK_at bl840 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl852 (by omega) (by omega)
       · by_cases h900 : i < 900
         · by_cases h876 : i < 876
           · exact FloorIndex.rangeOK_at bl864 (by omega) (by omega)
           · by_cases h888 : i < 888
             · exact FloorIndex.rangeOK_at bl876 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl888 (by omega) (by omega)
         · by_cases h924 : i < 924
           · by_cases h912 : i < 912
             · exact FloorIndex.rangeOK_at bl900 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl912 (by omega) (by omega)
           · by_cases h936 : i < 936
             · exact FloorIndex.rangeOK_at bl924 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl936 (by omega) (by omega)
   · by_cases h1104 : i < 1104
     · by_cases h1020 : i < 1020
       · by_cases h984 : i < 984
         · by_cases h960 : i < 960
           · exact FloorIndex.rangeOK_at bl948 (by omega) (by omega)
           · by_cases h972 : i < 972
             · exact FloorIndex.rangeOK_at bl960 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl972 (by omega) (by omega)
         · by_cases h996 : i < 996
           · exact FloorIndex.rangeOK_at bl984 (by omega) (by omega)
           · by_cases h1008 : i < 1008
             · exact FloorIndex.rangeOK_at bl996 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1008 (by omega) (by omega)
       · by_cases h1056 : i < 1056
         · by_cases h1032 : i < 1032
           · exact FloorIndex.rangeOK_at bl1020 (by omega) (by omega)
           · by_cases h1044 : i < 1044
             · exact FloorIndex.rangeOK_at bl1032 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1044 (by omega) (by omega)
         · by_cases h1080 : i < 1080
           · by_cases h1068 : i < 1068
             · exact FloorIndex.rangeOK_at bl1056 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1068 (by omega) (by omega)
           · by_cases h1092 : i < 1092
             · exact FloorIndex.rangeOK_at bl1080 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1092 (by omega) (by omega)
     · by_cases h1188 : i < 1188
       · by_cases h1140 : i < 1140
         · by_cases h1116 : i < 1116
           · exact FloorIndex.rangeOK_at bl1104 (by omega) (by omega)
           · by_cases h1128 : i < 1128
             · exact FloorIndex.rangeOK_at bl1116 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1128 (by omega) (by omega)
         · by_cases h1164 : i < 1164
           · by_cases h1152 : i < 1152
             · exact FloorIndex.rangeOK_at bl1140 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1152 (by omega) (by omega)
           · by_cases h1176 : i < 1176
             · exact FloorIndex.rangeOK_at bl1164 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1176 (by omega) (by omega)
       · by_cases h1224 : i < 1224
         · by_cases h1200 : i < 1200
           · exact FloorIndex.rangeOK_at bl1188 (by omega) (by omega)
           · by_cases h1212 : i < 1212
             · exact FloorIndex.rangeOK_at bl1200 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1212 (by omega) (by omega)
         · by_cases h1248 : i < 1248
           · by_cases h1236 : i < 1236
             · exact FloorIndex.rangeOK_at bl1224 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1236 (by omega) (by omega)
           · by_cases h1260 : i < 1260
             · exact FloorIndex.rangeOK_at bl1248 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1260 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 1265
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e1209577550766 := by
 intro he
 have hp : replay [[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] (call e1209577550766 (.lam (.lam (.var 0))) (.lam (.lam (.var 0))) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R1209577550766
