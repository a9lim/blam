import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204083322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204083322 : Closed e1211204083322 ∧ code e1211204083322 = 5609250594426 := by decide
theorem cert_e1211204083322 : checkPay e1211204083322 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204092894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211204092894 : Closed e1211204092894 ∧ code e1211204092894 = 5609250603998 := by decide
theorem cert_e1211204092894 : check e1211204092894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204092910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211204092910 : Closed e1211204092910 ∧ code e1211204092910 = 5609250604014 := by decide
theorem cert_e1211204092910 : check e1211204092910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211204094742 : Closed e1211204094742 ∧ code e1211204094742 = 5609250605846 := by decide
theorem cert_e1211204094742 : check e1211204094742 [[],[]] .chain = true := by decide
def e1211204094818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211204094818 : Closed e1211204094818 ∧ code e1211204094818 = 5609250605922 := by decide
theorem cert_e1211204094818 : check e1211204094818 [[],[]] .chain = true := by decide
def e1211204094830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211204094830 : Closed e1211204094830 ∧ code e1211204094830 = 5609250605934 := by decide
theorem cert_e1211204094830 : check e1211204094830 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211204094838 : Closed e1211204094838 ∧ code e1211204094838 = 5609250605942 := by decide
theorem cert_e1211204094838 : check e1211204094838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211204094858 : Closed e1211204094858 ∧ code e1211204094858 = 5609250605962 := by decide
theorem cert_e1211204094858 : check e1211204094858 [[],[]] .chain = true := by decide
def e1211204094882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211204094882 : Closed e1211204094882 ∧ code e1211204094882 = 5609250605986 := by decide
theorem cert_e1211204094882 : check e1211204094882 [[],[]] .chain = true := by decide
def e1211204094894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211204094894 : Closed e1211204094894 ∧ code e1211204094894 = 5609250605998 := by decide
theorem cert_e1211204094894 : check e1211204094894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e1211204094902 : Closed e1211204094902 ∧ code e1211204094902 = 5609250606006 := by decide
theorem cert_e1211204094902 : check e1211204094902 [[],[]] .chain = true := by decide
def e1211204094906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211204094906 : Closed e1211204094906 ∧ code e1211204094906 = 5609250606010 := by decide
theorem cert_e1211204094906 : check e1211204094906 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211204094934 : Closed e1211204094934 ∧ code e1211204094934 = 5609250606038 := by decide
theorem cert_e1211204094934 : check e1211204094934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204094938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211204094938 : Closed e1211204094938 ∧ code e1211204094938 = 5609250606042 := by decide
theorem cert_e1211204094938 : check e1211204094938 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e1211204095006 : Closed e1211204095006 ∧ code e1211204095006 = 5609250606110 := by decide
theorem cert_e1211204095006 : check e1211204095006 [[],[]] .chain = true := by decide
def e1211204095202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211204095202 : Closed e1211204095202 ∧ code e1211204095202 = 5609250606306 := by decide
theorem cert_e1211204095202 : check e1211204095202 [[],[]] .chain = true := by decide
def e1211204095214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204095214 : Closed e1211204095214 ∧ code e1211204095214 = 5609250606318 := by decide
theorem cert_e1211204095214 : check e1211204095214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204095222 : Closed e1211204095222 ∧ code e1211204095222 = 5609250606326 := by decide
theorem cert_e1211204095222 : check e1211204095222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e1211204095502 : Closed e1211204095502 ∧ code e1211204095502 = 5609250606606 := by decide
theorem cert_e1211204095502 : check e1211204095502 [[],[]] .chain = true := by decide
def e1211204095514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211204095514 : Closed e1211204095514 ∧ code e1211204095514 = 5609250606618 := by decide
theorem cert_e1211204095514 : check e1211204095514 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211204095586 : Closed e1211204095586 ∧ code e1211204095586 = 5609250606690 := by decide
theorem cert_e1211204095586 : check e1211204095586 [[],[]] .chain = true := by decide
def e1211204095598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204095598 : Closed e1211204095598 ∧ code e1211204095598 = 5609250606702 := by decide
theorem cert_e1211204095598 : check e1211204095598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204095606 : Closed e1211204095606 ∧ code e1211204095606 = 5609250606710 := by decide
theorem cert_e1211204095606 : check e1211204095606 [[],[]] .chain = true := by decide
def e1211204095610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204095610 : Closed e1211204095610 ∧ code e1211204095610 = 5609250606714 := by decide
theorem cert_e1211204095610 : check e1211204095610 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204095798 : Closed e1211204095798 ∧ code e1211204095798 = 5609250606902 := by decide
theorem cert_e1211204095798 : check e1211204095798 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204095802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204095802 : Closed e1211204095802 ∧ code e1211204095802 = 5609250606906 := by decide
theorem cert_e1211204095802 : check e1211204095802 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204201326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1211204201326 : Closed e1211204201326 ∧ code e1211204201326 = 5609250712430 := by decide
theorem cert_e1211204201326 : check e1211204201326 [[],[]] .chain = true := by decide
def e1211204201334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1211204201334 : Closed e1211204201334 ∧ code e1211204201334 = 5609250712438 := by decide
theorem cert_e1211204201334 : check e1211204201334 [[],[]] .chain = true := by decide
def e1211204201398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1211204201398 : Closed e1211204201398 ∧ code e1211204201398 = 5609250712502 := by decide
theorem cert_e1211204201398 : check e1211204201398 [[],[]] .chain = true := by decide
def e1211204201838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211204201838 : Closed e1211204201838 ∧ code e1211204201838 = 5609250712942 := by decide
theorem cert_e1211204201838 : check e1211204201838 [[],[]] .chain = true := by decide
def e1211204201846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211204201846 : Closed e1211204201846 ∧ code e1211204201846 = 5609250712950 := by decide
theorem cert_e1211204201846 : check e1211204201846 [[],[]] .chain = true := by decide
def e1211204201902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211204201902 : Closed e1211204201902 ∧ code e1211204201902 = 5609250713006 := by decide
theorem cert_e1211204201902 : check e1211204201902 [[],[]] .chain = true := by decide
def e1211204201914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211204201914 : Closed e1211204201914 ∧ code e1211204201914 = 5609250713018 := by decide
theorem cert_e1211204201914 : check e1211204201914 [[],[]] .chain = true := by decide
def e1211204201942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211204201942 : Closed e1211204201942 ∧ code e1211204201942 = 5609250713046 := by decide
theorem cert_e1211204201942 : check e1211204201942 [[],[]] .chain = true := by decide
def e1211204201946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211204201946 : Closed e1211204201946 ∧ code e1211204201946 = 5609250713050 := by decide
theorem cert_e1211204201946 : check e1211204201946 [[],[]] .chain = true := by decide
def e1211204202166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211204202166 : Closed e1211204202166 ∧ code e1211204202166 = 5609250713270 := by decide
theorem cert_e1211204202166 : check e1211204202166 [[],[]] .chain = true := by decide
def e1211204202198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211204202198 : Closed e1211204202198 ∧ code e1211204202198 = 5609250713302 := by decide
theorem cert_e1211204202198 : check e1211204202198 [[],[]] .chain = true := by decide
def e1211204202202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211204202202 : Closed e1211204202202 ∧ code e1211204202202 = 5609250713306 := by decide
theorem cert_e1211204202202 : check e1211204202202 [[],[]] .chain = true := by decide
def e1211204203886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211204203886 : Closed e1211204203886 ∧ code e1211204203886 = 5609250714990 := by decide
theorem cert_e1211204203886 : check e1211204203886 [[],[]] .chain = true := by decide
def e1211204203894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211204203894 : Closed e1211204203894 ∧ code e1211204203894 = 5609250714998 := by decide
theorem cert_e1211204203894 : check e1211204203894 [[],[]] .chain = true := by decide
def e1211204203950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211204203950 : Closed e1211204203950 ∧ code e1211204203950 = 5609250715054 := by decide
theorem cert_e1211204203950 : check e1211204203950 [[],[]] .chain = true := by decide
def e1211204203962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211204203962 : Closed e1211204203962 ∧ code e1211204203962 = 5609250715066 := by decide
theorem cert_e1211204203962 : check e1211204203962 [[],[]] .chain = true := by decide
def e1211204203990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211204203990 : Closed e1211204203990 ∧ code e1211204203990 = 5609250715094 := by decide
theorem cert_e1211204203990 : check e1211204203990 [[],[]] .chain = true := by decide
def e1211204203994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211204203994 : Closed e1211204203994 ∧ code e1211204203994 = 5609250715098 := by decide
theorem cert_e1211204203994 : check e1211204203994 [[],[]] .chain = true := by decide
def e1211204204206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211204204206 : Closed e1211204204206 ∧ code e1211204204206 = 5609250715310 := by decide
theorem cert_e1211204204206 : check e1211204204206 [[],[]] .chain = true := by decide
def e1211204204218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211204204218 : Closed e1211204204218 ∧ code e1211204204218 = 5609250715322 := by decide
theorem cert_e1211204204218 : check e1211204204218 [[],[]] .chain = true := by decide
def e1211204204266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211204204266 : Closed e1211204204266 ∧ code e1211204204266 = 5609250715370 := by decide
theorem cert_e1211204204266 : check e1211204204266 [[],[]] .chain = true := by decide
def e1211204204374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211204204374 : Closed e1211204204374 ∧ code e1211204204374 = 5609250715478 := by decide
theorem cert_e1211204204374 : check e1211204204374 [[],[]] .chain = true := by decide
def e1211204204378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211204204378 : Closed e1211204204378 ∧ code e1211204204378 = 5609250715482 := by decide
theorem cert_e1211204204378 : check e1211204204378 [[],[]] .chain = true := by decide
def e1211204204394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211204204394 : Closed e1211204204394 ∧ code e1211204204394 = 5609250715498 := by decide
theorem cert_e1211204204394 : check e1211204204394 [[],[]] .chain = true := by decide
def e1211204205238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211204205238 : Closed e1211204205238 ∧ code e1211204205238 = 5609250716342 := by decide
theorem cert_e1211204205238 : check e1211204205238 [[],[]] .chain = true := by decide
def e1211204205270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211204205270 : Closed e1211204205270 ∧ code e1211204205270 = 5609250716374 := by decide
theorem cert_e1211204205270 : check e1211204205270 [[],[]] .chain = true := by decide
def e1211204205274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211204205274 : Closed e1211204205274 ∧ code e1211204205274 = 5609250716378 := by decide
theorem cert_e1211204205274 : check e1211204205274 [[],[]] .chain = true := by decide
def e1211204205398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211204205398 : Closed e1211204205398 ∧ code e1211204205398 = 5609250716502 := by decide
theorem cert_e1211204205398 : check e1211204205398 [[],[]] .chain = true := by decide
def e1211204205402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211204205402 : Closed e1211204205402 ∧ code e1211204205402 = 5609250716506 := by decide
theorem cert_e1211204205402 : check e1211204205402 [[],[]] .chain = true := by decide
def e1211204205418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211204205418 : Closed e1211204205418 ∧ code e1211204205418 = 5609250716522 := by decide
theorem cert_e1211204205418 : check e1211204205418 [[],[]] .chain = true := by decide
def e1211204207470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))) (.var 2))))))
theorem wire_e1211204207470 : Closed e1211204207470 ∧ code e1211204207470 = 5609250718574 := by decide
theorem cert_e1211204207470 : check e1211204207470 [[],[]] .chain = true := by decide
def e1211204207478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))) (.var 1))))))
theorem wire_e1211204207478 : Closed e1211204207478 ∧ code e1211204207478 = 5609250718582 := by decide
theorem cert_e1211204207478 : check e1211204207478 [[],[]] .chain = true := by decide
def e1211204208878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211204208878 : Closed e1211204208878 ∧ code e1211204208878 = 5609250719982 := by decide
theorem cert_e1211204208878 : check e1211204208878 [[],[]] .chain = true := by decide
def e1211204208886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211204208886 : Closed e1211204208886 ∧ code e1211204208886 = 5609250719990 := by decide
theorem cert_e1211204208886 : check e1211204208886 [[],[]] .chain = true := by decide
def e1211204209438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211204209438 : Closed e1211204209438 ∧ code e1211204209438 = 5609250720542 := by decide
theorem cert_e1211204209438 : check e1211204209438 [[],[]] .chain = true := by decide
def e1211204209550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211204209550 : Closed e1211204209550 ∧ code e1211204209550 = 5609250720654 := by decide
theorem cert_e1211204209550 : check e1211204209550 [[],[]] .chain = true := by decide
def e1211204210222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211204210222 : Closed e1211204210222 ∧ code e1211204210222 = 5609250721326 := by decide
theorem cert_e1211204210222 : check e1211204210222 [[],[]] .chain = true := by decide
def e1211204210402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211204210402 : Closed e1211204210402 ∧ code e1211204210402 = 5609250721506 := by decide
theorem cert_e1211204210402 : check e1211204210402 [[],[]] .chain = true := by decide
def e1211204210414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 2))))))
theorem wire_e1211204210414 : Closed e1211204210414 ∧ code e1211204210414 = 5609250721518 := by decide
theorem cert_e1211204210414 : check e1211204210414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204210454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211204210454 : Closed e1211204210454 ∧ code e1211204210454 = 5609250721558 := by decide
theorem cert_e1211204210454 : check e1211204210454 [[],[]] .chain = true := by decide
def e1211204210530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211204210530 : Closed e1211204210530 ∧ code e1211204210530 = 5609250721634 := by decide
theorem cert_e1211204210530 : check e1211204210530 [[],[]] .chain = true := by decide
def e1211204210542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 2))))))
theorem wire_e1211204210542 : Closed e1211204210542 ∧ code e1211204210542 = 5609250721646 := by decide
theorem cert_e1211204210542 : check e1211204210542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211204210550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))) (.var 1))))))
theorem wire_e1211204210550 : Closed e1211204210550 ∧ code e1211204210550 = 5609250721654 := by decide
theorem cert_e1211204210550 : checkPay e1211204210550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204213614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e1211204213614 : Closed e1211204213614 ∧ code e1211204213614 = 5609250724718 := by decide
theorem cert_e1211204213614 : check e1211204213614 [[],[]] .chain = true := by decide
def e1211204213622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e1211204213622 : Closed e1211204213622 ∧ code e1211204213622 = 5609250724726 := by decide
theorem cert_e1211204213622 : check e1211204213622 [[],[]] .chain = true := by decide
def e1211204213686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.var 1))))))
theorem wire_e1211204213686 : Closed e1211204213686 ∧ code e1211204213686 = 5609250724790 := by decide
theorem cert_e1211204213686 : check e1211204213686 [[],[]] .chain = true := by decide
def e1211204214126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e1211204214126 : Closed e1211204214126 ∧ code e1211204214126 = 5609250725230 := by decide
theorem cert_e1211204214126 : check e1211204214126 [[],[]] .chain = true := by decide
def e1211204214134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e1211204214134 : Closed e1211204214134 ∧ code e1211204214134 = 5609250725238 := by decide
theorem cert_e1211204214134 : check e1211204214134 [[],[]] .chain = true := by decide
def e1211204214190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e1211204214190 : Closed e1211204214190 ∧ code e1211204214190 = 5609250725294 := by decide
theorem cert_e1211204214190 : check e1211204214190 [[],[]] .chain = true := by decide
def e1211204214202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e1211204214202 : Closed e1211204214202 ∧ code e1211204214202 = 5609250725306 := by decide
theorem cert_e1211204214202 : check e1211204214202 [[],[]] .chain = true := by decide
def e1211204214230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e1211204214230 : Closed e1211204214230 ∧ code e1211204214230 = 5609250725334 := by decide
theorem cert_e1211204214230 : check e1211204214230 [[],[]] .chain = true := by decide
def e1211204214234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e1211204214234 : Closed e1211204214234 ∧ code e1211204214234 = 5609250725338 := by decide
theorem cert_e1211204214234 : check e1211204214234 [[],[]] .chain = true := by decide
def e1211204214454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e1211204214454 : Closed e1211204214454 ∧ code e1211204214454 = 5609250725558 := by decide
theorem cert_e1211204214454 : check e1211204214454 [[],[]] .chain = true := by decide
def e1211204214486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e1211204214486 : Closed e1211204214486 ∧ code e1211204214486 = 5609250725590 := by decide
theorem cert_e1211204214486 : check e1211204214486 [[],[]] .chain = true := by decide
def e1211204214490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e1211204214490 : Closed e1211204214490 ∧ code e1211204214490 = 5609250725594 := by decide
theorem cert_e1211204214490 : check e1211204214490 [[],[]] .chain = true := by decide
def e1211204216686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1211204216686 : Closed e1211204216686 ∧ code e1211204216686 = 5609250727790 := by decide
theorem cert_e1211204216686 : check e1211204216686 [[],[]] .chain = true := by decide
def e1211204216694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1211204216694 : Closed e1211204216694 ∧ code e1211204216694 = 5609250727798 := by decide
theorem cert_e1211204216694 : check e1211204216694 [[],[]] .chain = true := by decide
def e1211204216758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1211204216758 : Closed e1211204216758 ∧ code e1211204216758 = 5609250727862 := by decide
theorem cert_e1211204216758 : check e1211204216758 [[],[]] .chain = true := by decide
def e1211204218094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204218094 : Closed e1211204218094 ∧ code e1211204218094 = 5609250729198 := by decide
theorem cert_e1211204218094 : check e1211204218094 [[],[]] .chain = true := by decide
def e1211204218102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204218102 : Closed e1211204218102 ∧ code e1211204218102 = 5609250729206 := by decide
theorem cert_e1211204218102 : check e1211204218102 [[],[]] .chain = true := by decide
def e1211204218486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204218486 : Closed e1211204218486 ∧ code e1211204218486 = 5609250729590 := by decide
theorem cert_e1211204218486 : check e1211204218486 [[],[]] .chain = true := by decide
def e1211204218990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211204218990 : Closed e1211204218990 ∧ code e1211204218990 = 5609250730094 := by decide
theorem cert_e1211204218990 : check e1211204218990 [[],[]] .chain = true := by decide
def e1211204219166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211204219166 : Closed e1211204219166 ∧ code e1211204219166 = 5609250730270 := by decide
theorem cert_e1211204219166 : check e1211204219166 [[],[]] .chain = true := by decide
def e1211204219362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211204219362 : Closed e1211204219362 ∧ code e1211204219362 = 5609250730466 := by decide
theorem cert_e1211204219362 : check e1211204219362 [[],[]] .chain = true := by decide
def e1211204219374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211204219374 : Closed e1211204219374 ∧ code e1211204219374 = 5609250730478 := by decide
theorem cert_e1211204219374 : check e1211204219374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204219758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211204219758 : Closed e1211204219758 ∧ code e1211204219758 = 5609250730862 := by decide
theorem cert_e1211204219758 : check e1211204219758 [[],[]] .chain = true := by decide
def e1211204219766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211204219766 : Closed e1211204219766 ∧ code e1211204219766 = 5609250730870 := by decide
theorem cert_e1211204219766 : check e1211204219766 [[],[]] .chain = true := by decide
def e1211204219822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211204219822 : Closed e1211204219822 ∧ code e1211204219822 = 5609250730926 := by decide
theorem cert_e1211204219822 : check e1211204219822 [[],[]] .chain = true := by decide
def e1211204219834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211204219834 : Closed e1211204219834 ∧ code e1211204219834 = 5609250730938 := by decide
theorem cert_e1211204219834 : check e1211204219834 [[],[]] .chain = true := by decide
def e1211204219862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211204219862 : Closed e1211204219862 ∧ code e1211204219862 = 5609250730966 := by decide
theorem cert_e1211204219862 : check e1211204219862 [[],[]] .chain = true := by decide
def e1211204219866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211204219866 : Closed e1211204219866 ∧ code e1211204219866 = 5609250730970 := by decide
theorem cert_e1211204219866 : check e1211204219866 [[],[]] .chain = true := by decide
def e1211204220142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204220142 : Closed e1211204220142 ∧ code e1211204220142 = 5609250731246 := by decide
theorem cert_e1211204220142 : check e1211204220142 [[],[]] .chain = true := by decide
def e1211204220150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204220150 : Closed e1211204220150 ∧ code e1211204220150 = 5609250731254 := by decide
theorem cert_e1211204220150 : check e1211204220150 [[],[]] .chain = true := by decide
def e1211204220526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204220526 : Closed e1211204220526 ∧ code e1211204220526 = 5609250731630 := by decide
theorem cert_e1211204220526 : check e1211204220526 [[],[]] .chain = true := by decide
def e1211204220538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204220538 : Closed e1211204220538 ∧ code e1211204220538 = 5609250731642 := by decide
theorem cert_e1211204220538 : check e1211204220538 [[],[]] .chain = true := by decide
def e1211204220678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204220678 : Closed e1211204220678 ∧ code e1211204220678 = 5609250731782 := by decide
theorem cert_e1211204220678 : check e1211204220678 [[],[]] .chain = true := by decide
def e1211204220702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211204220702 : Closed e1211204220702 ∧ code e1211204220702 = 5609250731806 := by decide
theorem cert_e1211204220702 : check e1211204220702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204220726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204220726 : Closed e1211204220726 ∧ code e1211204220726 = 5609250731830 := by decide
theorem cert_e1211204220726 : check e1211204220726 [[],[]] .chain = true := by decide
def e1211204220730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204220730 : Closed e1211204220730 ∧ code e1211204220730 = 5609250731834 := by decide
theorem cert_e1211204220730 : check e1211204220730 [[],[]] .chain = true := by decide
def e1211204220982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211204220982 : Closed e1211204220982 ∧ code e1211204220982 = 5609250732086 := by decide
theorem cert_e1211204220982 : check e1211204220982 [[],[]] .chain = true := by decide
def e1211204221070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211204221070 : Closed e1211204221070 ∧ code e1211204221070 = 5609250732174 := by decide
theorem cert_e1211204221070 : check e1211204221070 [[],[]] .chain = true := by decide
def e1211204221154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211204221154 : Closed e1211204221154 ∧ code e1211204221154 = 5609250732258 := by decide
theorem cert_e1211204221154 : check e1211204221154 [[],[]] .chain = true := by decide
def e1211204221166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211204221166 : Closed e1211204221166 ∧ code e1211204221166 = 5609250732270 := by decide
theorem cert_e1211204221166 : check e1211204221166 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204221174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211204221174 : Closed e1211204221174 ∧ code e1211204221174 = 5609250732278 := by decide
theorem cert_e1211204221174 : check e1211204221174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204221366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211204221366 : Closed e1211204221366 ∧ code e1211204221366 = 5609250732470 := by decide
theorem cert_e1211204221366 : check e1211204221366 [[],[]] .chain = true := by decide
def e1211204221398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211204221398 : Closed e1211204221398 ∧ code e1211204221398 = 5609250732502 := by decide
theorem cert_e1211204221398 : check e1211204221398 [[],[]] .chain = true := by decide
def e1211204221402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211204221402 : Closed e1211204221402 ∧ code e1211204221402 = 5609250732506 := by decide
theorem cert_e1211204221402 : check e1211204221402 [[],[]] .chain = true := by decide
def e1211204221558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204221558 : Closed e1211204221558 ∧ code e1211204221558 = 5609250732662 := by decide
theorem cert_e1211204221558 : check e1211204221558 [[],[]] .chain = true := by decide
def e1211204221702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204221702 : Closed e1211204221702 ∧ code e1211204221702 = 5609250732806 := by decide
theorem cert_e1211204221702 : check e1211204221702 [[],[]] .chain = true := by decide
def e1211204221726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211204221726 : Closed e1211204221726 ∧ code e1211204221726 = 5609250732830 := by decide
theorem cert_e1211204221726 : check e1211204221726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204221750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204221750 : Closed e1211204221750 ∧ code e1211204221750 = 5609250732854 := by decide
theorem cert_e1211204221750 : check e1211204221750 [[],[]] .chain = true := by decide
def e1211204221754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204221754 : Closed e1211204221754 ∧ code e1211204221754 = 5609250732858 := by decide
theorem cert_e1211204221754 : check e1211204221754 [[],[]] .chain = true := by decide
def e1211204221838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211204221838 : Closed e1211204221838 ∧ code e1211204221838 = 5609250732942 := by decide
theorem cert_e1211204221838 : check e1211204221838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204223342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e1211204223342 : Closed e1211204223342 ∧ code e1211204223342 = 5609250734446 := by decide
theorem cert_e1211204223342 : check e1211204223342 [[],[]] .chain = true := by decide
def e1211204223350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e1211204223350 : Closed e1211204223350 ∧ code e1211204223350 = 5609250734454 := by decide
theorem cert_e1211204223350 : check e1211204223350 [[],[]] .chain = true := by decide
def e1211204223406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))) (.var 2))))))
theorem wire_e1211204223406 : Closed e1211204223406 ∧ code e1211204223406 = 5609250734510 := by decide
theorem cert_e1211204223406 : check e1211204223406 [[],[]] .chain = true := by decide
def e1211204223418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2))) (.var 0))))))
theorem wire_e1211204223418 : Closed e1211204223418 ∧ code e1211204223418 = 5609250734522 := by decide
theorem cert_e1211204223418 : check e1211204223418 [[],[]] .chain = true := by decide
def e1211204224110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211204224110 : Closed e1211204224110 ∧ code e1211204224110 = 5609250735214 := by decide
theorem cert_e1211204224110 : check e1211204224110 [[],[]] .chain = true := by decide
def e1211204224122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211204224122 : Closed e1211204224122 ∧ code e1211204224122 = 5609250735226 := by decide
theorem cert_e1211204224122 : check e1211204224122 [[],[]] .chain = true := by decide
def e1211204224286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211204224286 : Closed e1211204224286 ∧ code e1211204224286 = 5609250735390 := by decide
theorem cert_e1211204224286 : check e1211204224286 [[],[]] .chain = true := by decide
def e1211204224454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211204224454 : Closed e1211204224454 ∧ code e1211204224454 = 5609250735558 := by decide
theorem cert_e1211204224454 : check e1211204224454 [[],[]] .chain = true := by decide
def e1211204224558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211204224558 : Closed e1211204224558 ∧ code e1211204224558 = 5609250735662 := by decide
theorem cert_e1211204224558 : check e1211204224558 [[],[]] .chain = true := by decide
def e1211204224738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211204224738 : Closed e1211204224738 ∧ code e1211204224738 = 5609250735842 := by decide
theorem cert_e1211204224738 : check e1211204224738 [[],[]] .chain = true := by decide
def e1211204224750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 2))))))
theorem wire_e1211204224750 : Closed e1211204224750 ∧ code e1211204224750 = 5609250735854 := by decide
theorem cert_e1211204224750 : check e1211204224750 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204224878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 1))) (.var 2))))))
theorem wire_e1211204224878 : Closed e1211204224878 ∧ code e1211204224878 = 5609250735982 := by decide
theorem cert_e1211204224878 : check e1211204224878 [[],[]] .chain = true := by decide
def e1211204224886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.var 1))))))
theorem wire_e1211204224886 : Closed e1211204224886 ∧ code e1211204224886 = 5609250735990 := by decide
theorem cert_e1211204224886 : check e1211204224886 [[],[]] .chain = true := by decide
def e1211204224906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211204224906 : Closed e1211204224906 ∧ code e1211204224906 = 5609250736010 := by decide
theorem cert_e1211204224906 : check e1211204224906 [[],[]] .chain = true := by decide
def e1211204224930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211204224930 : Closed e1211204224930 ∧ code e1211204224930 = 5609250736034 := by decide
theorem cert_e1211204224930 : check e1211204224930 [[],[]] .chain = true := by decide
def e1211204224942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 2))))))
theorem wire_e1211204224942 : Closed e1211204224942 ∧ code e1211204224942 = 5609250736046 := by decide
theorem cert_e1211204224942 : check e1211204224942 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204224950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.var 1))))))
theorem wire_e1211204224950 : Closed e1211204224950 ∧ code e1211204224950 = 5609250736054 := by decide
theorem cert_e1211204224950 : check e1211204224950 [[],[]] .chain = true := by decide
def e1211204224954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))) (.var 0))))))
theorem wire_e1211204224954 : Closed e1211204224954 ∧ code e1211204224954 = 5609250736058 := by decide
theorem cert_e1211204224954 : check e1211204224954 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204226414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e1211204226414 : Closed e1211204226414 ∧ code e1211204226414 = 5609250737518 := by decide
theorem cert_e1211204226414 : check e1211204226414 [[],[]] .chain = true := by decide
def e1211204226422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e1211204226422 : Closed e1211204226422 ∧ code e1211204226422 = 5609250737526 := by decide
theorem cert_e1211204226422 : check e1211204226422 [[],[]] .chain = true := by decide
def e1211204226478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e1211204226478 : Closed e1211204226478 ∧ code e1211204226478 = 5609250737582 := by decide
theorem cert_e1211204226478 : check e1211204226478 [[],[]] .chain = true := by decide
def e1211204226490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e1211204226490 : Closed e1211204226490 ∧ code e1211204226490 = 5609250737594 := by decide
theorem cert_e1211204226490 : check e1211204226490 [[],[]] .chain = true := by decide
def e1211204226518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e1211204226518 : Closed e1211204226518 ∧ code e1211204226518 = 5609250737622 := by decide
theorem cert_e1211204226518 : check e1211204226518 [[],[]] .chain = true := by decide
def e1211204226522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e1211204226522 : Closed e1211204226522 ∧ code e1211204226522 = 5609250737626 := by decide
theorem cert_e1211204226522 : check e1211204226522 [[],[]] .chain = true := by decide
def e1211204226734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e1211204226734 : Closed e1211204226734 ∧ code e1211204226734 = 5609250737838 := by decide
theorem cert_e1211204226734 : check e1211204226734 [[],[]] .chain = true := by decide
def e1211204226746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e1211204226746 : Closed e1211204226746 ∧ code e1211204226746 = 5609250737850 := by decide
theorem cert_e1211204226746 : check e1211204226746 [[],[]] .chain = true := by decide
def e1211204226794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e1211204226794 : Closed e1211204226794 ∧ code e1211204226794 = 5609250737898 := by decide
theorem cert_e1211204226794 : check e1211204226794 [[],[]] .chain = true := by decide
def e1211204226902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211204226902 : Closed e1211204226902 ∧ code e1211204226902 = 5609250738006 := by decide
theorem cert_e1211204226902 : check e1211204226902 [[],[]] .chain = true := by decide
def e1211204226906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211204226906 : Closed e1211204226906 ∧ code e1211204226906 = 5609250738010 := by decide
theorem cert_e1211204226906 : check e1211204226906 [[],[]] .chain = true := by decide
def e1211204226922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211204226922 : Closed e1211204226922 ∧ code e1211204226922 = 5609250738026 := by decide
theorem cert_e1211204226922 : check e1211204226922 [[],[]] .chain = true := by decide
def e1211204227182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211204227182 : Closed e1211204227182 ∧ code e1211204227182 = 5609250738286 := by decide
theorem cert_e1211204227182 : check e1211204227182 [[],[]] .chain = true := by decide
def e1211204227358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211204227358 : Closed e1211204227358 ∧ code e1211204227358 = 5609250738462 := by decide
theorem cert_e1211204227358 : check e1211204227358 [[],[]] .chain = true := by decide
def e1211204227554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211204227554 : Closed e1211204227554 ∧ code e1211204227554 = 5609250738658 := by decide
theorem cert_e1211204227554 : check e1211204227554 [[],[]] .chain = true := by decide
def e1211204227566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211204227566 : Closed e1211204227566 ∧ code e1211204227566 = 5609250738670 := by decide
theorem cert_e1211204227566 : check e1211204227566 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204227950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211204227950 : Closed e1211204227950 ∧ code e1211204227950 = 5609250739054 := by decide
theorem cert_e1211204227950 : check e1211204227950 [[],[]] .chain = true := by decide
def e1211204227958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211204227958 : Closed e1211204227958 ∧ code e1211204227958 = 5609250739062 := by decide
theorem cert_e1211204227958 : check e1211204227958 [[],[]] .chain = true := by decide
def e1211204228014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211204228014 : Closed e1211204228014 ∧ code e1211204228014 = 5609250739118 := by decide
theorem cert_e1211204228014 : check e1211204228014 [[],[]] .chain = true := by decide
def e1211204228026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211204228026 : Closed e1211204228026 ∧ code e1211204228026 = 5609250739130 := by decide
theorem cert_e1211204228026 : check e1211204228026 [[],[]] .chain = true := by decide
def e1211204228054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211204228054 : Closed e1211204228054 ∧ code e1211204228054 = 5609250739158 := by decide
theorem cert_e1211204228054 : check e1211204228054 [[],[]] .chain = true := by decide
def e1211204228058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211204228058 : Closed e1211204228058 ∧ code e1211204228058 = 5609250739162 := by decide
theorem cert_e1211204228058 : check e1211204228058 [[],[]] .chain = true := by decide
def e1211204228334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204228334 : Closed e1211204228334 ∧ code e1211204228334 = 5609250739438 := by decide
theorem cert_e1211204228334 : check e1211204228334 [[],[]] .chain = true := by decide
end Blc.Floor42
