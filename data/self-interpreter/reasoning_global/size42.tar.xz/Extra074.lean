import Batch074
import ExtraBase
namespace Blc.Floor42.Extra074
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196584689082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem ex_e1196584689082 : ¬ IsSelfInterpreter e1196584689082 := by
  intro he
  have hp := replay_sound (t := e1196584689082) (u := t_e1196584689082) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584689082
private def t_e1196584689114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem ex_e1196584689114 : ¬ IsSelfInterpreter e1196584689114 := by
  intro he
  have hp := replay_sound (t := e1196584689114) (u := t_e1196584689114) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584689114
private def t_e1196584689370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem ex_e1196584689370 : ¬ IsSelfInterpreter e1196584689370 := by
  intro he
  have hp := replay_sound (t := e1196584689370) (u := t_e1196584689370) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584689370
private def t_e1196584694714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem ex_e1196584694714 : ¬ IsSelfInterpreter e1196584694714 := by
  intro he
  have hp := replay_sound (t := e1196584694714) (u := t_e1196584694714) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.app (.var 0) (.var 1)))) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 1) (SO.var 2))) (SO.var 0)) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 1))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584694714
private def t_e1196584694746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem ex_e1196584694746 : ¬ IsSelfInterpreter e1196584694746 := by
  intro he
  have hp := replay_sound (t := e1196584694746) (u := t_e1196584694746) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.app (.var 1) (.var 0)))) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 2) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584694746
private def t_e1196584696282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem ex_e1196584696282 : ¬ IsSelfInterpreter e1196584696282 := by
  intro he
  have hp := replay_sound (t := e1196584696282) (u := t_e1196584696282) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196584696282
private def t_e1196585061338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1196585061338 : ¬ IsSelfInterpreter e1196585061338 := by
  intro he
  have hp := replay_sound (t := e1196585061338) (u := t_e1196585061338) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196585061338
private def t_e1196585061622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1196585061622 : ¬ IsSelfInterpreter e1196585061622 := by
  intro he
  have hp := replay_sound (t := e1196585061622) (u := t_e1196585061622) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196585061622
private def t_e1196585062202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))))
theorem ex_e1196585062202 : ¬ IsSelfInterpreter e1196585062202 := by
  intro he
  have hp := replay_sound (t := (call e1196585062202 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1196585062202) (ps := [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.right,.right,.under],[.left,.right,.right,.under,.right,.right],[.left],[],[.right,.under,.right],[.left,.left],[.left],[.left,.right,.under,.right],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := SelfintKnot.occ_betas_zero hr 0 (by decide)
  exact (by decide : ¬ occ 0 (.var 0) = 0) hz
#print axioms ex_e1196585062202
end Blc.Floor42.Extra074
