import Tables
import Batch250
namespace Blc.Floor42.Grades250
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211298991722 : ¬ IsSelfInterpreter e1211298991722 := cutM0_2 (by decide)
#print axioms ex_e1211298991722
end Blc.Floor42.Grades250
