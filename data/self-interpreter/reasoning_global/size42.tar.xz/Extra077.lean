import Batch077
import ExtraBase
namespace Blc.Floor42.Extra077
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196686694890 : Term := (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.lam (.lam (.var 1))) (.var 0))) (.var 0))))) (.lam (.lam (.var 1))))
theorem ex_e1196686694890 : ¬ IsSelfInterpreter e1196686694890 := by
  intro he
  have hp := replay_sound (t := (.app e1196686694890 churchTrue)) (u := t_e1196686694890) (ps := [[.left],[.left,.left],[.left,.left,.under,.under,.left,.right],[.left],[.left,.under,.left,.left],[.left,.under,.left,.left,.under,.under,.left,.right],[],[.left,.right,.under,.under,.left,.right],[.left],[]]) (by decide)
  apply specialized_not_so he hp
  exact (SO.app (SO.app (SO.app (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (r := (.app (.var 0) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (so_dead (by decide) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)) (by decide) (by rfl))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (r := (.app (.var 0) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (so_dead (by decide) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)) (by decide) (by rfl)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.app (.lam (.lam (.var 1))) (.var 0))) (.var 0))) (r := (.app (.var 0) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1))) (SO.var 0))) (SO.var 0)) (SO.app (SO.var 0) (SO.var 0)) (by decide) (by rfl)))) (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1))))
#print axioms ex_e1196686694890
private def t_e1196686695322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem ex_e1196686695322 : ¬ IsSelfInterpreter e1196686695322 := by
  intro he
  have hp := replay_sound (t := e1196686695322) (u := t_e1196686695322) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.var 0)))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2)) (SO.app (SO.var 0) (SO.var 0))) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686695322
private def t_e1196686695834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem ex_e1196686695834 : ¬ IsSelfInterpreter e1196686695834 := by
  intro he
  have hp := replay_sound (t := e1196686695834) (u := t_e1196686695834) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.var 0)))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.app (SO.var 0) (SO.var 0))) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686695834
private def t_e1196686695878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem ex_e1196686695878 : ¬ IsSelfInterpreter e1196686695878 := by
  intro he
  have hp := replay_sound (t := e1196686695878) (u := t_e1196686695878) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.lam (.var 1)))) (r := (.app (.app (.var 0) (.var 1)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 2)) (so_dead (by decide) (SO.var 1))) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686695878
private def t_e1196686699930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem ex_e1196686699930 : ¬ IsSelfInterpreter e1196686699930 := by
  intro he
  have hp := replay_sound (t := e1196686699930) (u := t_e1196686699930) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.var 0)))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.app (SO.var 0) (SO.var 0))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686699930
private def t_e1196686699974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem ex_e1196686699974 : ¬ IsSelfInterpreter e1196686699974 := by
  intro he
  have hp := replay_sound (t := e1196686699974) (u := t_e1196686699974) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.lam (.var 1)))) (r := (.app (.app (.var 1) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 2)) (so_dead (by decide) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686699974
end Blc.Floor42.Extra077
