import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1106465459258 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106465459258 : Closed e1106465459258 ∧ code e1106465459258 = 5504511970362 := by decide
theorem cert_e1106465459258 : check e1106465459258 [[]] .width = true := by decide
def e1106465459398 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106465459398 : Closed e1106465459398 ∧ code e1106465459398 = 5504511970502 := by decide
theorem cert_e1106465459398 : check e1106465459398 [[]] .width = true := by decide
def e1107220168902 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107220168902 : Closed e1107220168902 ∧ code e1107220168902 = 5505266680006 := by decide
theorem cert_e1107220168902 : check e1107220168902 [[]] .width = true := by decide
def e1107220169430 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107220169430 : Closed e1107220169430 ∧ code e1107220169430 = 5505266680534 := by decide
theorem cert_e1107220169430 : check e1107220169430 [[]] .width = true := by decide
def e1107220169434 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107220169434 : Closed e1107220169434 ∧ code e1107220169434 = 5505266680538 := by decide
theorem cert_e1107220169434 : check e1107220169434 [[]] .width = true := by decide
def e1107220169450 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107220169450 : Closed e1107220169450 ∧ code e1107220169450 = 5505266680554 := by decide
theorem cert_e1107220169450 : check e1107220169450 [[]] .width = true := by decide
def e1107220169526 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107220169526 : Closed e1107220169526 ∧ code e1107220169526 = 5505266680630 := by decide
theorem cert_e1107220169526 : check e1107220169526 [[]] .width = true := by decide
def e1107220169530 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107220169530 : Closed e1107220169530 ∧ code e1107220169530 = 5505266680634 := by decide
theorem cert_e1107220169530 : check e1107220169530 [[]] .width = true := by decide
def e1107220169614 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107220169614 : Closed e1107220169614 ∧ code e1107220169614 = 5505266680718 := by decide
theorem cert_e1107220169614 : check e1107220169614 [[]] .width = true := by decide
def e1107220169626 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107220169626 : Closed e1107220169626 ∧ code e1107220169626 = 5505266680730 := by decide
theorem cert_e1107220169626 : check e1107220169626 [[]] .width = true := by decide
def e1107220171546 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107220171546 : Closed e1107220171546 ∧ code e1107220171546 = 5505266682650 := by decide
theorem cert_e1107220171546 : check e1107220171546 [[]] .width = true := by decide
def e1107220171590 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107220171590 : Closed e1107220171590 ∧ code e1107220171590 = 5505266682694 := by decide
theorem cert_e1107220171590 : check e1107220171590 [[]] .width = true := by decide
def e1107220171830 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107220171830 : Closed e1107220171830 ∧ code e1107220171830 = 5505266682934 := by decide
theorem cert_e1107220171830 : check e1107220171830 [[]] .width = true := by decide
def e1107220171834 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107220171834 : Closed e1107220171834 ∧ code e1107220171834 = 5505266682938 := by decide
theorem cert_e1107220171834 : check e1107220171834 [[]] .width = true := by decide
def e1107220171974 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107220171974 : Closed e1107220171974 ∧ code e1107220171974 = 5505266683078 := by decide
theorem cert_e1107220171974 : check e1107220171974 [[]] .width = true := by decide
def e1107225403418 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107225403418 : Closed e1107225403418 ∧ code e1107225403418 = 5505271914522 := by decide
theorem cert_e1107225403418 : check e1107225403418 [[]] .width = true := by decide
def e1107225403510 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107225403510 : Closed e1107225403510 ∧ code e1107225403510 = 5505271914614 := by decide
theorem cert_e1107225403510 : check e1107225403510 [[]] .width = true := by decide
def e1107225403754 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107225403754 : Closed e1107225403754 ∧ code e1107225403754 = 5505271914858 := by decide
theorem cert_e1107225403754 : check e1107225403754 [[]] .width = true := by decide
def e1107225403802 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107225403802 : Closed e1107225403802 ∧ code e1107225403802 = 5505271914906 := by decide
theorem cert_e1107225403802 : check e1107225403802 [[]] .width = true := by decide
def e1107226460358 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107226460358 : Closed e1107226460358 ∧ code e1107226460358 = 5505272971462 := by decide
theorem cert_e1107226460358 : check e1107226460358 [[]] .width = true := by decide
def e1107226460886 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107226460886 : Closed e1107226460886 ∧ code e1107226460886 = 5505272971990 := by decide
theorem cert_e1107226460886 : check e1107226460886 [[]] .width = true := by decide
def e1107226460890 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107226460890 : Closed e1107226460890 ∧ code e1107226460890 = 5505272971994 := by decide
theorem cert_e1107226460890 : check e1107226460890 [[]] .width = true := by decide
def e1107226460906 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107226460906 : Closed e1107226460906 ∧ code e1107226460906 = 5505272972010 := by decide
theorem cert_e1107226460906 : check e1107226460906 [[]] .width = true := by decide
def e1107226460982 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107226460982 : Closed e1107226460982 ∧ code e1107226460982 = 5505272972086 := by decide
theorem cert_e1107226460982 : check e1107226460982 [[]] .width = true := by decide
def e1107226460986 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107226460986 : Closed e1107226460986 ∧ code e1107226460986 = 5505272972090 := by decide
theorem cert_e1107226460986 : check e1107226460986 [[]] .width = true := by decide
def e1107226461070 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107226461070 : Closed e1107226461070 ∧ code e1107226461070 = 5505272972174 := by decide
theorem cert_e1107226461070 : check e1107226461070 [[]] .width = true := by decide
def e1107226461082 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107226461082 : Closed e1107226461082 ∧ code e1107226461082 = 5505272972186 := by decide
theorem cert_e1107226461082 : check e1107226461082 [[]] .width = true := by decide
def e1107226463002 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107226463002 : Closed e1107226463002 ∧ code e1107226463002 = 5505272974106 := by decide
theorem cert_e1107226463002 : check e1107226463002 [[]] .width = true := by decide
def e1107226463046 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107226463046 : Closed e1107226463046 ∧ code e1107226463046 = 5505272974150 := by decide
theorem cert_e1107226463046 : check e1107226463046 [[]] .width = true := by decide
def e1107226463286 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107226463286 : Closed e1107226463286 ∧ code e1107226463286 = 5505272974390 := by decide
theorem cert_e1107226463286 : check e1107226463286 [[]] .width = true := by decide
def e1107226463290 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107226463290 : Closed e1107226463290 ∧ code e1107226463290 = 5505272974394 := by decide
theorem cert_e1107226463290 : check e1107226463290 [[]] .width = true := by decide
def e1107226463430 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107226463430 : Closed e1107226463430 ∧ code e1107226463430 = 5505272974534 := by decide
theorem cert_e1107226463430 : check e1107226463430 [[]] .width = true := by decide
def e1107226812442 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107226812442 : Closed e1107226812442 ∧ code e1107226812442 = 5505273323546 := by decide
theorem cert_e1107226812442 : check e1107226812442 [[]] .width = true := by decide
def e1107226812534 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107226812534 : Closed e1107226812534 ∧ code e1107226812534 = 5505273323638 := by decide
theorem cert_e1107226812534 : check e1107226812534 [[]] .width = true := by decide
def e1107226812778 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107226812778 : Closed e1107226812778 ∧ code e1107226812778 = 5505273323882 := by decide
theorem cert_e1107226812778 : check e1107226812778 [[]] .width = true := by decide
def e1107226812826 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107226812826 : Closed e1107226812826 ∧ code e1107226812826 = 5505273323930 := by decide
theorem cert_e1107226812826 : check e1107226812826 [[]] .width = true := by decide
def e1107226853574 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107226853574 : Closed e1107226853574 ∧ code e1107226853574 = 5505273364678 := by decide
theorem cert_e1107226853574 : check e1107226853574 [[]] .width = true := by decide
def e1107226854102 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107226854102 : Closed e1107226854102 ∧ code e1107226854102 = 5505273365206 := by decide
theorem cert_e1107226854102 : check e1107226854102 [[]] .width = true := by decide
def e1107226854106 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107226854106 : Closed e1107226854106 ∧ code e1107226854106 = 5505273365210 := by decide
theorem cert_e1107226854106 : check e1107226854106 [[]] .width = true := by decide
def e1107226854122 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107226854122 : Closed e1107226854122 ∧ code e1107226854122 = 5505273365226 := by decide
theorem cert_e1107226854122 : check e1107226854122 [[]] .width = true := by decide
def e1107226854198 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107226854198 : Closed e1107226854198 ∧ code e1107226854198 = 5505273365302 := by decide
theorem cert_e1107226854198 : check e1107226854198 [[]] .width = true := by decide
def e1107226854202 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107226854202 : Closed e1107226854202 ∧ code e1107226854202 = 5505273365306 := by decide
theorem cert_e1107226854202 : check e1107226854202 [[]] .width = true := by decide
def e1107226854286 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107226854286 : Closed e1107226854286 ∧ code e1107226854286 = 5505273365390 := by decide
theorem cert_e1107226854286 : check e1107226854286 [[]] .width = true := by decide
def e1107226854298 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107226854298 : Closed e1107226854298 ∧ code e1107226854298 = 5505273365402 := by decide
theorem cert_e1107226854298 : check e1107226854298 [[]] .width = true := by decide
def e1107226856218 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107226856218 : Closed e1107226856218 ∧ code e1107226856218 = 5505273367322 := by decide
theorem cert_e1107226856218 : check e1107226856218 [[]] .width = true := by decide
def e1107226856262 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107226856262 : Closed e1107226856262 ∧ code e1107226856262 = 5505273367366 := by decide
theorem cert_e1107226856262 : check e1107226856262 [[]] .width = true := by decide
def e1107226856502 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107226856502 : Closed e1107226856502 ∧ code e1107226856502 = 5505273367606 := by decide
theorem cert_e1107226856502 : check e1107226856502 [[]] .width = true := by decide
def e1107226856506 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107226856506 : Closed e1107226856506 ∧ code e1107226856506 = 5505273367610 := by decide
theorem cert_e1107226856506 : check e1107226856506 [[]] .width = true := by decide
def e1107226856646 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107226856646 : Closed e1107226856646 ∧ code e1107226856646 = 5505273367750 := by decide
theorem cert_e1107226856646 : check e1107226856646 [[]] .width = true := by decide
def e1107245334726 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107245334726 : Closed e1107245334726 ∧ code e1107245334726 = 5505291845830 := by decide
theorem cert_e1107245334726 : check e1107245334726 [[]] .width = true := by decide
def e1107245335254 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107245335254 : Closed e1107245335254 ∧ code e1107245335254 = 5505291846358 := by decide
theorem cert_e1107245335254 : check e1107245335254 [[]] .width = true := by decide
def e1107245335258 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107245335258 : Closed e1107245335258 ∧ code e1107245335258 = 5505291846362 := by decide
theorem cert_e1107245335258 : check e1107245335258 [[]] .width = true := by decide
def e1107245335274 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107245335274 : Closed e1107245335274 ∧ code e1107245335274 = 5505291846378 := by decide
theorem cert_e1107245335274 : check e1107245335274 [[]] .width = true := by decide
def e1107245335350 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107245335350 : Closed e1107245335350 ∧ code e1107245335350 = 5505291846454 := by decide
theorem cert_e1107245335350 : check e1107245335350 [[]] .width = true := by decide
def e1107245335354 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107245335354 : Closed e1107245335354 ∧ code e1107245335354 = 5505291846458 := by decide
theorem cert_e1107245335354 : check e1107245335354 [[]] .width = true := by decide
def e1107245335438 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107245335438 : Closed e1107245335438 ∧ code e1107245335438 = 5505291846542 := by decide
theorem cert_e1107245335438 : check e1107245335438 [[]] .width = true := by decide
def e1107245335450 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107245335450 : Closed e1107245335450 ∧ code e1107245335450 = 5505291846554 := by decide
theorem cert_e1107245335450 : check e1107245335450 [[]] .width = true := by decide
def e1107245337370 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107245337370 : Closed e1107245337370 ∧ code e1107245337370 = 5505291848474 := by decide
theorem cert_e1107245337370 : check e1107245337370 [[]] .width = true := by decide
def e1107245337414 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107245337414 : Closed e1107245337414 ∧ code e1107245337414 = 5505291848518 := by decide
theorem cert_e1107245337414 : check e1107245337414 [[]] .width = true := by decide
def e1107245337654 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107245337654 : Closed e1107245337654 ∧ code e1107245337654 = 5505291848758 := by decide
theorem cert_e1107245337654 : check e1107245337654 [[]] .width = true := by decide
def e1107245337658 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107245337658 : Closed e1107245337658 ∧ code e1107245337658 = 5505291848762 := by decide
theorem cert_e1107245337658 : check e1107245337658 [[]] .width = true := by decide
def e1107245337798 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107245337798 : Closed e1107245337798 ∧ code e1107245337798 = 5505291848902 := by decide
theorem cert_e1107245337798 : check e1107245337798 [[]] .width = true := by decide
def e1107283083462 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107283083462 : Closed e1107283083462 ∧ code e1107283083462 = 5505329594566 := by decide
theorem cert_e1107283083462 : check e1107283083462 [[]] .width = true := by decide
def e1107283083990 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107283083990 : Closed e1107283083990 ∧ code e1107283083990 = 5505329595094 := by decide
theorem cert_e1107283083990 : check e1107283083990 [[]] .width = true := by decide
def e1107283083994 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107283083994 : Closed e1107283083994 ∧ code e1107283083994 = 5505329595098 := by decide
theorem cert_e1107283083994 : check e1107283083994 [[]] .width = true := by decide
def e1107283084010 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107283084010 : Closed e1107283084010 ∧ code e1107283084010 = 5505329595114 := by decide
theorem cert_e1107283084010 : check e1107283084010 [[]] .width = true := by decide
def e1107283084086 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107283084086 : Closed e1107283084086 ∧ code e1107283084086 = 5505329595190 := by decide
theorem cert_e1107283084086 : check e1107283084086 [[]] .width = true := by decide
def e1107283084090 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107283084090 : Closed e1107283084090 ∧ code e1107283084090 = 5505329595194 := by decide
theorem cert_e1107283084090 : check e1107283084090 [[]] .width = true := by decide
def e1107283084174 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107283084174 : Closed e1107283084174 ∧ code e1107283084174 = 5505329595278 := by decide
theorem cert_e1107283084174 : check e1107283084174 [[]] .width = true := by decide
def e1107283084186 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107283084186 : Closed e1107283084186 ∧ code e1107283084186 = 5505329595290 := by decide
theorem cert_e1107283084186 : check e1107283084186 [[]] .width = true := by decide
def e1107283086106 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107283086106 : Closed e1107283086106 ∧ code e1107283086106 = 5505329597210 := by decide
theorem cert_e1107283086106 : check e1107283086106 [[]] .width = true := by decide
def e1107283086150 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107283086150 : Closed e1107283086150 ∧ code e1107283086150 = 5505329597254 := by decide
theorem cert_e1107283086150 : check e1107283086150 [[]] .width = true := by decide
def e1107283086390 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107283086390 : Closed e1107283086390 ∧ code e1107283086390 = 5505329597494 := by decide
theorem cert_e1107283086390 : check e1107283086390 [[]] .width = true := by decide
def e1107283086394 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107283086394 : Closed e1107283086394 ∧ code e1107283086394 = 5505329597498 := by decide
theorem cert_e1107283086394 : check e1107283086394 [[]] .width = true := by decide
def e1107283086534 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107283086534 : Closed e1107283086534 ∧ code e1107283086534 = 5505329597638 := by decide
theorem cert_e1107283086534 : check e1107283086534 [[]] .width = true := by decide
def e1107283435546 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107283435546 : Closed e1107283435546 ∧ code e1107283435546 = 5505329946650 := by decide
theorem cert_e1107283435546 : check e1107283435546 [[]] .width = true := by decide
def e1107283435638 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107283435638 : Closed e1107283435638 ∧ code e1107283435638 = 5505329946742 := by decide
theorem cert_e1107283435638 : check e1107283435638 [[]] .width = true := by decide
def e1107283435882 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107283435882 : Closed e1107283435882 ∧ code e1107283435882 = 5505329946986 := by decide
theorem cert_e1107283435882 : check e1107283435882 [[]] .width = true := by decide
def e1107283435930 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107283435930 : Closed e1107283435930 ∧ code e1107283435930 = 5505329947034 := by decide
theorem cert_e1107283435930 : check e1107283435930 [[]] .width = true := by decide
def e1107283476678 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107283476678 : Closed e1107283476678 ∧ code e1107283476678 = 5505329987782 := by decide
theorem cert_e1107283476678 : check e1107283476678 [[]] .width = true := by decide
def e1107283477206 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107283477206 : Closed e1107283477206 ∧ code e1107283477206 = 5505329988310 := by decide
theorem cert_e1107283477206 : check e1107283477206 [[]] .width = true := by decide
def e1107283477210 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107283477210 : Closed e1107283477210 ∧ code e1107283477210 = 5505329988314 := by decide
theorem cert_e1107283477210 : check e1107283477210 [[]] .width = true := by decide
def e1107283477226 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107283477226 : Closed e1107283477226 ∧ code e1107283477226 = 5505329988330 := by decide
theorem cert_e1107283477226 : check e1107283477226 [[]] .width = true := by decide
def e1107283477302 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107283477302 : Closed e1107283477302 ∧ code e1107283477302 = 5505329988406 := by decide
theorem cert_e1107283477302 : check e1107283477302 [[]] .width = true := by decide
def e1107283477306 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107283477306 : Closed e1107283477306 ∧ code e1107283477306 = 5505329988410 := by decide
theorem cert_e1107283477306 : check e1107283477306 [[]] .width = true := by decide
def e1107283477390 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107283477390 : Closed e1107283477390 ∧ code e1107283477390 = 5505329988494 := by decide
theorem cert_e1107283477390 : check e1107283477390 [[]] .width = true := by decide
def e1107283477402 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107283477402 : Closed e1107283477402 ∧ code e1107283477402 = 5505329988506 := by decide
theorem cert_e1107283477402 : check e1107283477402 [[]] .width = true := by decide
def e1107283479322 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107283479322 : Closed e1107283479322 ∧ code e1107283479322 = 5505329990426 := by decide
theorem cert_e1107283479322 : check e1107283479322 [[]] .width = true := by decide
def e1107283479366 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107283479366 : Closed e1107283479366 ∧ code e1107283479366 = 5505329990470 := by decide
theorem cert_e1107283479366 : check e1107283479366 [[]] .width = true := by decide
def e1107283479606 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107283479606 : Closed e1107283479606 ∧ code e1107283479606 = 5505329990710 := by decide
theorem cert_e1107283479606 : check e1107283479606 [[]] .width = true := by decide
def e1107283479610 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107283479610 : Closed e1107283479610 ∧ code e1107283479610 = 5505329990714 := by decide
theorem cert_e1107283479610 : check e1107283479610 [[]] .width = true := by decide
def e1107283479750 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107283479750 : Closed e1107283479750 ∧ code e1107283479750 = 5505329990854 := by decide
theorem cert_e1107283479750 : check e1107283479750 [[]] .width = true := by decide
def e1107657941018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107657941018 : Closed e1107657941018 ∧ code e1107657941018 = 5505704452122 := by decide
theorem cert_e1107657941018 : check e1107657941018 [[]] .width = true := by decide
def e1107657941110 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107657941110 : Closed e1107657941110 ∧ code e1107657941110 = 5505704452214 := by decide
theorem cert_e1107657941110 : check e1107657941110 [[]] .width = true := by decide
def e1107657941354 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107657941354 : Closed e1107657941354 ∧ code e1107657941354 = 5505704452458 := by decide
theorem cert_e1107657941354 : check e1107657941354 [[]] .width = true := by decide
def e1107657941402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107657941402 : Closed e1107657941402 ∧ code e1107657941402 = 5505704452506 := by decide
theorem cert_e1107657941402 : check e1107657941402 [[]] .width = true := by decide
def e1107660570822 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107660570822 : Closed e1107660570822 ∧ code e1107660570822 = 5505707081926 := by decide
theorem cert_e1107660570822 : check e1107660570822 [[]] .width = true := by decide
def e1107660571350 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107660571350 : Closed e1107660571350 ∧ code e1107660571350 = 5505707082454 := by decide
theorem cert_e1107660571350 : check e1107660571350 [[]] .width = true := by decide
def e1107660571354 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107660571354 : Closed e1107660571354 ∧ code e1107660571354 = 5505707082458 := by decide
theorem cert_e1107660571354 : check e1107660571354 [[]] .width = true := by decide
def e1107660571370 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107660571370 : Closed e1107660571370 ∧ code e1107660571370 = 5505707082474 := by decide
theorem cert_e1107660571370 : check e1107660571370 [[]] .width = true := by decide
def e1107660571446 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107660571446 : Closed e1107660571446 ∧ code e1107660571446 = 5505707082550 := by decide
theorem cert_e1107660571446 : check e1107660571446 [[]] .width = true := by decide
def e1107660571450 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107660571450 : Closed e1107660571450 ∧ code e1107660571450 = 5505707082554 := by decide
theorem cert_e1107660571450 : check e1107660571450 [[]] .width = true := by decide
def e1107660571534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107660571534 : Closed e1107660571534 ∧ code e1107660571534 = 5505707082638 := by decide
theorem cert_e1107660571534 : check e1107660571534 [[]] .width = true := by decide
def e1107660571546 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107660571546 : Closed e1107660571546 ∧ code e1107660571546 = 5505707082650 := by decide
theorem cert_e1107660571546 : check e1107660571546 [[]] .width = true := by decide
def e1107660573466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107660573466 : Closed e1107660573466 ∧ code e1107660573466 = 5505707084570 := by decide
theorem cert_e1107660573466 : check e1107660573466 [[]] .width = true := by decide
def e1107660573510 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107660573510 : Closed e1107660573510 ∧ code e1107660573510 = 5505707084614 := by decide
theorem cert_e1107660573510 : check e1107660573510 [[]] .width = true := by decide
def e1107660573750 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107660573750 : Closed e1107660573750 ∧ code e1107660573750 = 5505707084854 := by decide
theorem cert_e1107660573750 : check e1107660573750 [[]] .width = true := by decide
def e1107660573754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107660573754 : Closed e1107660573754 ∧ code e1107660573754 = 5505707084858 := by decide
theorem cert_e1107660573754 : check e1107660573754 [[]] .width = true := by decide
def e1107660573894 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107660573894 : Closed e1107660573894 ∧ code e1107660573894 = 5505707084998 := by decide
theorem cert_e1107660573894 : check e1107660573894 [[]] .width = true := by decide
def e1107660693530 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107660693530 : Closed e1107660693530 ∧ code e1107660693530 = 5505707204634 := by decide
theorem cert_e1107660693530 : check e1107660693530 [[]] .width = true := by decide
def e1107660693622 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107660693622 : Closed e1107660693622 ∧ code e1107660693622 = 5505707204726 := by decide
theorem cert_e1107660693622 : check e1107660693622 [[]] .width = true := by decide
def e1107660693866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107660693866 : Closed e1107660693866 ∧ code e1107660693866 = 5505707204970 := by decide
theorem cert_e1107660693866 : check e1107660693866 [[]] .width = true := by decide
def e1107660693914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107660693914 : Closed e1107660693914 ∧ code e1107660693914 = 5505707205018 := by decide
theorem cert_e1107660693914 : check e1107660693914 [[]] .width = true := by decide
def e1107660832966 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107660832966 : Closed e1107660832966 ∧ code e1107660832966 = 5505707344070 := by decide
theorem cert_e1107660832966 : check e1107660832966 [[]] .width = true := by decide
def e1107660833494 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107660833494 : Closed e1107660833494 ∧ code e1107660833494 = 5505707344598 := by decide
theorem cert_e1107660833494 : check e1107660833494 [[]] .width = true := by decide
def e1107660833498 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107660833498 : Closed e1107660833498 ∧ code e1107660833498 = 5505707344602 := by decide
theorem cert_e1107660833498 : check e1107660833498 [[]] .width = true := by decide
def e1107660833514 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107660833514 : Closed e1107660833514 ∧ code e1107660833514 = 5505707344618 := by decide
theorem cert_e1107660833514 : check e1107660833514 [[]] .width = true := by decide
def e1107660833590 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107660833590 : Closed e1107660833590 ∧ code e1107660833590 = 5505707344694 := by decide
theorem cert_e1107660833590 : check e1107660833590 [[]] .width = true := by decide
def e1107660833594 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107660833594 : Closed e1107660833594 ∧ code e1107660833594 = 5505707344698 := by decide
theorem cert_e1107660833594 : check e1107660833594 [[]] .width = true := by decide
def e1107660833678 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107660833678 : Closed e1107660833678 ∧ code e1107660833678 = 5505707344782 := by decide
theorem cert_e1107660833678 : check e1107660833678 [[]] .width = true := by decide
def e1107660833690 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107660833690 : Closed e1107660833690 ∧ code e1107660833690 = 5505707344794 := by decide
theorem cert_e1107660833690 : check e1107660833690 [[]] .width = true := by decide
def e1107660835610 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107660835610 : Closed e1107660835610 ∧ code e1107660835610 = 5505707346714 := by decide
theorem cert_e1107660835610 : check e1107660835610 [[]] .width = true := by decide
def e1107660835654 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107660835654 : Closed e1107660835654 ∧ code e1107660835654 = 5505707346758 := by decide
theorem cert_e1107660835654 : check e1107660835654 [[]] .width = true := by decide
def e1107660835894 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107660835894 : Closed e1107660835894 ∧ code e1107660835894 = 5505707346998 := by decide
theorem cert_e1107660835894 : check e1107660835894 [[]] .width = true := by decide
def e1107660835898 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107660835898 : Closed e1107660835898 ∧ code e1107660835898 = 5505707347002 := by decide
theorem cert_e1107660835898 : check e1107660835898 [[]] .width = true := by decide
def e1107660836038 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107660836038 : Closed e1107660836038 ∧ code e1107660836038 = 5505707347142 := by decide
theorem cert_e1107660836038 : check e1107660836038 [[]] .width = true := by decide
def e1107661611034 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107661611034 : Closed e1107661611034 ∧ code e1107661611034 = 5505708122138 := by decide
theorem cert_e1107661611034 : check e1107661611034 [[]] .width = true := by decide
def e1107661611126 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107661611126 : Closed e1107661611126 ∧ code e1107661611126 = 5505708122230 := by decide
theorem cert_e1107661611126 : check e1107661611126 [[]] .width = true := by decide
def e1107661611370 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107661611370 : Closed e1107661611370 ∧ code e1107661611370 = 5505708122474 := by decide
theorem cert_e1107661611370 : check e1107661611370 [[]] .width = true := by decide
def e1107661611418 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107661611418 : Closed e1107661611418 ∧ code e1107661611418 = 5505708122522 := by decide
theorem cert_e1107661611418 : check e1107661611418 [[]] .width = true := by decide
def e1107662667974 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107662667974 : Closed e1107662667974 ∧ code e1107662667974 = 5505709179078 := by decide
theorem cert_e1107662667974 : check e1107662667974 [[]] .width = true := by decide
def e1107662668502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107662668502 : Closed e1107662668502 ∧ code e1107662668502 = 5505709179606 := by decide
theorem cert_e1107662668502 : check e1107662668502 [[]] .width = true := by decide
def e1107662668506 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107662668506 : Closed e1107662668506 ∧ code e1107662668506 = 5505709179610 := by decide
theorem cert_e1107662668506 : check e1107662668506 [[]] .width = true := by decide
def e1107662668522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107662668522 : Closed e1107662668522 ∧ code e1107662668522 = 5505709179626 := by decide
theorem cert_e1107662668522 : check e1107662668522 [[]] .width = true := by decide
def e1107662668598 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107662668598 : Closed e1107662668598 ∧ code e1107662668598 = 5505709179702 := by decide
theorem cert_e1107662668598 : check e1107662668598 [[]] .width = true := by decide
def e1107662668602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107662668602 : Closed e1107662668602 ∧ code e1107662668602 = 5505709179706 := by decide
theorem cert_e1107662668602 : check e1107662668602 [[]] .width = true := by decide
def e1107662668686 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107662668686 : Closed e1107662668686 ∧ code e1107662668686 = 5505709179790 := by decide
theorem cert_e1107662668686 : check e1107662668686 [[]] .width = true := by decide
def e1107662668698 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107662668698 : Closed e1107662668698 ∧ code e1107662668698 = 5505709179802 := by decide
theorem cert_e1107662668698 : check e1107662668698 [[]] .width = true := by decide
def e1107662670618 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107662670618 : Closed e1107662670618 ∧ code e1107662670618 = 5505709181722 := by decide
theorem cert_e1107662670618 : check e1107662670618 [[]] .width = true := by decide
def e1107662670662 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107662670662 : Closed e1107662670662 ∧ code e1107662670662 = 5505709181766 := by decide
theorem cert_e1107662670662 : check e1107662670662 [[]] .width = true := by decide
def e1107662670902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107662670902 : Closed e1107662670902 ∧ code e1107662670902 = 5505709182006 := by decide
theorem cert_e1107662670902 : check e1107662670902 [[]] .width = true := by decide
def e1107662670906 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107662670906 : Closed e1107662670906 ∧ code e1107662670906 = 5505709182010 := by decide
theorem cert_e1107662670906 : check e1107662670906 [[]] .width = true := by decide
def e1107662671046 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107662671046 : Closed e1107662671046 ∧ code e1107662671046 = 5505709182150 := by decide
theorem cert_e1107662671046 : check e1107662671046 [[]] .width = true := by decide
def e1107663020058 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1107663020058 : Closed e1107663020058 ∧ code e1107663020058 = 5505709531162 := by decide
theorem cert_e1107663020058 : check e1107663020058 [[]] .width = true := by decide
def e1107663020150 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1107663020150 : Closed e1107663020150 ∧ code e1107663020150 = 5505709531254 := by decide
theorem cert_e1107663020150 : check e1107663020150 [[]] .width = true := by decide
def e1107663020394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1107663020394 : Closed e1107663020394 ∧ code e1107663020394 = 5505709531498 := by decide
theorem cert_e1107663020394 : check e1107663020394 [[]] .width = true := by decide
def e1107663020442 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1107663020442 : Closed e1107663020442 ∧ code e1107663020442 = 5505709531546 := by decide
theorem cert_e1107663020442 : check e1107663020442 [[]] .width = true := by decide
def e1107663061190 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1107663061190 : Closed e1107663061190 ∧ code e1107663061190 = 5505709572294 := by decide
theorem cert_e1107663061190 : check e1107663061190 [[]] .width = true := by decide
def e1107663061718 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1107663061718 : Closed e1107663061718 ∧ code e1107663061718 = 5505709572822 := by decide
theorem cert_e1107663061718 : check e1107663061718 [[]] .width = true := by decide
def e1107663061722 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1107663061722 : Closed e1107663061722 ∧ code e1107663061722 = 5505709572826 := by decide
theorem cert_e1107663061722 : check e1107663061722 [[]] .width = true := by decide
def e1107663061738 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1107663061738 : Closed e1107663061738 ∧ code e1107663061738 = 5505709572842 := by decide
theorem cert_e1107663061738 : check e1107663061738 [[]] .width = true := by decide
def e1107663061814 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1107663061814 : Closed e1107663061814 ∧ code e1107663061814 = 5505709572918 := by decide
theorem cert_e1107663061814 : check e1107663061814 [[]] .width = true := by decide
def e1107663061818 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1107663061818 : Closed e1107663061818 ∧ code e1107663061818 = 5505709572922 := by decide
theorem cert_e1107663061818 : check e1107663061818 [[]] .width = true := by decide
def e1107663061902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1107663061902 : Closed e1107663061902 ∧ code e1107663061902 = 5505709573006 := by decide
theorem cert_e1107663061902 : check e1107663061902 [[]] .width = true := by decide
def e1107663061914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1107663061914 : Closed e1107663061914 ∧ code e1107663061914 = 5505709573018 := by decide
theorem cert_e1107663061914 : check e1107663061914 [[]] .width = true := by decide
def e1107663063834 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1107663063834 : Closed e1107663063834 ∧ code e1107663063834 = 5505709574938 := by decide
theorem cert_e1107663063834 : check e1107663063834 [[]] .width = true := by decide
def e1107663063878 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1107663063878 : Closed e1107663063878 ∧ code e1107663063878 = 5505709574982 := by decide
theorem cert_e1107663063878 : check e1107663063878 [[]] .width = true := by decide
def e1107663064118 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1107663064118 : Closed e1107663064118 ∧ code e1107663064118 = 5505709575222 := by decide
theorem cert_e1107663064118 : check e1107663064118 [[]] .width = true := by decide
def e1107663064122 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1107663064122 : Closed e1107663064122 ∧ code e1107663064122 = 5505709575226 := by decide
theorem cert_e1107663064122 : check e1107663064122 [[]] .width = true := by decide
def e1107663064262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1107663064262 : Closed e1107663064262 ∧ code e1107663064262 = 5505709575366 := by decide
theorem cert_e1107663064262 : check e1107663064262 [[]] .width = true := by decide
end Blc.Floor42
