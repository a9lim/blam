import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196685357918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1196685357918 : Closed e1196685357918 ∧ code e1196685357918 = 5594731869022 := by decide
theorem cert_e1196685357918 : check e1196685357918 [[],[.left],[]] .three = true := by decide
def e1196685357934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1196685357934 : Closed e1196685357934 ∧ code e1196685357934 = 5594731869038 := by decide
theorem cert_e1196685357934 : check e1196685357934 [[],[.left],[]] .smaller = true := by decide
def e1196685357942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1196685357942 : Closed e1196685357942 ∧ code e1196685357942 = 5594731869046 := by decide
theorem cert_e1196685357942 : check e1196685357942 [[],[.left],[]] .smaller = true := by decide
def e1196685357946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1196685357946 : Closed e1196685357946 ∧ code e1196685357946 = 5594731869050 := by decide
theorem cert_e1196685357946 : check e1196685357946 [[],[.left],[]] .three = true := by decide
def e1196685357998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1196685357998 : Closed e1196685357998 ∧ code e1196685357998 = 5594731869102 := by decide
theorem cert_e1196685357998 : check e1196685357998 [[],[.left],[]] .smaller = true := by decide
def e1196685358010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1196685358010 : Closed e1196685358010 ∧ code e1196685358010 = 5594731869114 := by decide
theorem cert_e1196685358010 : check e1196685358010 [[],[.left],[]] .smaller = true := by decide
def e1196685358038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1196685358038 : Closed e1196685358038 ∧ code e1196685358038 = 5594731869142 := by decide
theorem cert_e1196685358038 : check e1196685358038 [[],[.left],[]] .smaller = true := by decide
def e1196685358042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1196685358042 : Closed e1196685358042 ∧ code e1196685358042 = 5594731869146 := by decide
theorem cert_e1196685358042 : check e1196685358042 [[],[.left],[]] .smaller = true := by decide
def e1196685358058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1196685358058 : Closed e1196685358058 ∧ code e1196685358058 = 5594731869162 := by decide
theorem cert_e1196685358058 : check e1196685358058 [[],[.left],[]] .three = true := by decide
def e1196685358302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196685358302 : Closed e1196685358302 ∧ code e1196685358302 = 5594731869406 := by decide
theorem cert_e1196685358302 : check e1196685358302 [[],[.left],[]] .three = true := by decide
def e1196685358318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196685358318 : Closed e1196685358318 ∧ code e1196685358318 = 5594731869422 := by decide
theorem cert_e1196685358318 : check e1196685358318 [[],[.left],[]] .smaller = true := by decide
def e1196685358326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196685358326 : Closed e1196685358326 ∧ code e1196685358326 = 5594731869430 := by decide
theorem cert_e1196685358326 : check e1196685358326 [[],[.left],[]] .smaller = true := by decide
def e1196685358330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196685358330 : Closed e1196685358330 ∧ code e1196685358330 = 5594731869434 := by decide
theorem cert_e1196685358330 : check e1196685358330 [[],[.left],[]] .three = true := by decide
def e1196685358702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196685358702 : Closed e1196685358702 ∧ code e1196685358702 = 5594731869806 := by decide
theorem cert_e1196685358702 : check e1196685358702 [[],[.left],[]] .smaller = true := by decide
def e1196685358714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196685358714 : Closed e1196685358714 ∧ code e1196685358714 = 5594731869818 := by decide
theorem cert_e1196685358714 : check e1196685358714 [[],[.left],[]] .smaller = true := by decide
def e1196685358902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196685358902 : Closed e1196685358902 ∧ code e1196685358902 = 5594731870006 := by decide
theorem cert_e1196685358902 : check e1196685358902 [[],[.left],[]] .smaller = true := by decide
def e1196685358906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196685358906 : Closed e1196685358906 ∧ code e1196685358906 = 5594731870010 := by decide
theorem cert_e1196685358906 : check e1196685358906 [[],[.left],[]] .smaller = true := by decide
def e1196685359002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196685359002 : Closed e1196685359002 ∧ code e1196685359002 = 5594731870106 := by decide
theorem cert_e1196685359002 : check e1196685359002 [[],[.left],[]] .three = true := by decide
def e1196685359542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1196685359542 : Closed e1196685359542 ∧ code e1196685359542 = 5594731870646 := by decide
theorem cert_e1196685359542 : check e1196685359542 [[],[.left],[]] .smaller = true := by decide
def e1196685359574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1196685359574 : Closed e1196685359574 ∧ code e1196685359574 = 5594731870678 := by decide
theorem cert_e1196685359574 : check e1196685359574 [[],[.left],[]] .smaller = true := by decide
def e1196685359578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1196685359578 : Closed e1196685359578 ∧ code e1196685359578 = 5594731870682 := by decide
theorem cert_e1196685359578 : check e1196685359578 [[],[.left],[]] .smaller = true := by decide
def e1196685359734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196685359734 : Closed e1196685359734 ∧ code e1196685359734 = 5594731870838 := by decide
theorem cert_e1196685359734 : check e1196685359734 [[],[.left],[]] .smaller = true := by decide
def e1196685359926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196685359926 : Closed e1196685359926 ∧ code e1196685359926 = 5594731871030 := by decide
theorem cert_e1196685359926 : check e1196685359926 [[],[.left],[]] .smaller = true := by decide
def e1196685359930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196685359930 : Closed e1196685359930 ∧ code e1196685359930 = 5594731871034 := by decide
theorem cert_e1196685359930 : check e1196685359930 [[],[.left],[]] .smaller = true := by decide
def e1196685360342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1196685360342 : Closed e1196685360342 ∧ code e1196685360342 = 5594731871446 := by decide
theorem cert_e1196685360342 : check e1196685360342 [[],[.left],[]] .three = true := by decide
def e1196685360346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1196685360346 : Closed e1196685360346 ∧ code e1196685360346 = 5594731871450 := by decide
theorem cert_e1196685360346 : check e1196685360346 [[],[.left],[]] .three = true := by decide
def e1196685360362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1196685360362 : Closed e1196685360362 ∧ code e1196685360362 = 5594731871466 := by decide
theorem cert_e1196685360362 : check e1196685360362 [[],[.left],[]] .three = true := by decide
def e1196685360438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196685360438 : Closed e1196685360438 ∧ code e1196685360438 = 5594731871542 := by decide
theorem cert_e1196685360438 : check e1196685360438 [[],[.left],[]] .three = true := by decide
def e1196685360442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196685360442 : Closed e1196685360442 ∧ code e1196685360442 = 5594731871546 := by decide
theorem cert_e1196685360442 : check e1196685360442 [[],[.left],[]] .three = true := by decide
def e1196685360538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196685360538 : Closed e1196685360538 ∧ code e1196685360538 = 5594731871642 := by decide
theorem cert_e1196685360538 : check e1196685360538 [[],[.left],[]] .three = true := by decide
def e1196685367006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1196685367006 : Closed e1196685367006 ∧ code e1196685367006 = 5594731878110 := by decide
theorem cert_e1196685367006 : check e1196685367006 [[],[.left],[]] .three = true := by decide
def e1196685367030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1196685367030 : Closed e1196685367030 ∧ code e1196685367030 = 5594731878134 := by decide
theorem cert_e1196685367030 : check e1196685367030 [[],[.left],[]] .three = true := by decide
def e1196685367134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1196685367134 : Closed e1196685367134 ∧ code e1196685367134 = 5594731878238 := by decide
theorem cert_e1196685367134 : check e1196685367134 [[],[.left],[]] .three = true := by decide
def e1196685367150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1196685367150 : Closed e1196685367150 ∧ code e1196685367150 = 5594731878254 := by decide
theorem cert_e1196685367150 : check e1196685367150 [[],[.left],[]] .smaller = true := by decide
def e1196685367158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1196685367158 : Closed e1196685367158 ∧ code e1196685367158 = 5594731878262 := by decide
theorem cert_e1196685367158 : check e1196685367158 [[],[.left],[]] .smaller = true := by decide
def e1196685367162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1196685367162 : Closed e1196685367162 ∧ code e1196685367162 = 5594731878266 := by decide
theorem cert_e1196685367162 : check e1196685367162 [[],[.left],[]] .three = true := by decide
def e1196685367222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1196685367222 : Closed e1196685367222 ∧ code e1196685367222 = 5594731878326 := by decide
theorem cert_e1196685367222 : check e1196685367222 [[],[.left],[]] .smaller = true := by decide
def e1196685367254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1196685367254 : Closed e1196685367254 ∧ code e1196685367254 = 5594731878358 := by decide
theorem cert_e1196685367254 : check e1196685367254 [[],[.left],[]] .three = true := by decide
def e1196685367258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1196685367258 : Closed e1196685367258 ∧ code e1196685367258 = 5594731878362 := by decide
theorem cert_e1196685367258 : check e1196685367258 [[],[.left],[]] .three = true := by decide
def e1196685367774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1196685367774 : Closed e1196685367774 ∧ code e1196685367774 = 5594731878878 := by decide
theorem cert_e1196685367774 : check e1196685367774 [[],[.left],[]] .three = true := by decide
def e1196685367798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1196685367798 : Closed e1196685367798 ∧ code e1196685367798 = 5594731878902 := by decide
theorem cert_e1196685367798 : check e1196685367798 [[],[.left],[]] .three = true := by decide
def e1196685368542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1196685368542 : Closed e1196685368542 ∧ code e1196685368542 = 5594731879646 := by decide
theorem cert_e1196685368542 : check e1196685368542 [[],[.left],[]] .three = true := by decide
def e1196685368558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1196685368558 : Closed e1196685368558 ∧ code e1196685368558 = 5594731879662 := by decide
theorem cert_e1196685368558 : check e1196685368558 [[],[.left],[]] .smaller = true := by decide
def e1196685368566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1196685368566 : Closed e1196685368566 ∧ code e1196685368566 = 5594731879670 := by decide
theorem cert_e1196685368566 : check e1196685368566 [[],[.left],[]] .smaller = true := by decide
def e1196685368570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1196685368570 : Closed e1196685368570 ∧ code e1196685368570 = 5594731879674 := by decide
theorem cert_e1196685368570 : check e1196685368570 [[],[.left],[]] .three = true := by decide
def e1196685368950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1196685368950 : Closed e1196685368950 ∧ code e1196685368950 = 5594731880054 := by decide
theorem cert_e1196685368950 : check e1196685368950 [[],[.left],[]] .smaller = true := by decide
def e1196685369142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685369142 : Closed e1196685369142 ∧ code e1196685369142 = 5594731880246 := by decide
theorem cert_e1196685369142 : check e1196685369142 [[],[.left],[]] .three = true := by decide
def e1196685369146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685369146 : Closed e1196685369146 ∧ code e1196685369146 = 5594731880250 := by decide
theorem cert_e1196685369146 : check e1196685369146 [[],[.left],[]] .three = true := by decide
def e1196685380446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1196685380446 : Closed e1196685380446 ∧ code e1196685380446 = 5594731891550 := by decide
theorem cert_e1196685380446 : check e1196685380446 [[],[.left],[]] .three = true := by decide
def e1196685380462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1196685380462 : Closed e1196685380462 ∧ code e1196685380462 = 5594731891566 := by decide
theorem cert_e1196685380462 : check e1196685380462 [[],[.left],[]] .smaller = true := by decide
def e1196685380470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1196685380470 : Closed e1196685380470 ∧ code e1196685380470 = 5594731891574 := by decide
theorem cert_e1196685380470 : check e1196685380470 [[],[.left],[]] .smaller = true := by decide
def e1196685380474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1196685380474 : Closed e1196685380474 ∧ code e1196685380474 = 5594731891578 := by decide
theorem cert_e1196685380474 : check e1196685380474 [[],[.left],[]] .three = true := by decide
def e1196685380526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1196685380526 : Closed e1196685380526 ∧ code e1196685380526 = 5594731891630 := by decide
theorem cert_e1196685380526 : check e1196685380526 [[],[.left],[]] .smaller = true := by decide
def e1196685380538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1196685380538 : Closed e1196685380538 ∧ code e1196685380538 = 5594731891642 := by decide
theorem cert_e1196685380538 : check e1196685380538 [[],[.left],[]] .smaller = true := by decide
def e1196685380566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1196685380566 : Closed e1196685380566 ∧ code e1196685380566 = 5594731891670 := by decide
theorem cert_e1196685380566 : check e1196685380566 [[],[.left],[]] .smaller = true := by decide
def e1196685380570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1196685380570 : Closed e1196685380570 ∧ code e1196685380570 = 5594731891674 := by decide
theorem cert_e1196685380570 : check e1196685380570 [[],[.left],[]] .smaller = true := by decide
def e1196685380586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1196685380586 : Closed e1196685380586 ∧ code e1196685380586 = 5594731891690 := by decide
theorem cert_e1196685380586 : check e1196685380586 [[],[.left],[]] .three = true := by decide
def e1196685380830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1196685380830 : Closed e1196685380830 ∧ code e1196685380830 = 5594731891934 := by decide
theorem cert_e1196685380830 : check e1196685380830 [[],[.left],[]] .three = true := by decide
def e1196685380846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1196685380846 : Closed e1196685380846 ∧ code e1196685380846 = 5594731891950 := by decide
theorem cert_e1196685380846 : check e1196685380846 [[],[.left],[]] .smaller = true := by decide
def e1196685380854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1196685380854 : Closed e1196685380854 ∧ code e1196685380854 = 5594731891958 := by decide
theorem cert_e1196685380854 : check e1196685380854 [[],[.left],[]] .smaller = true := by decide
def e1196685380858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1196685380858 : Closed e1196685380858 ∧ code e1196685380858 = 5594731891962 := by decide
theorem cert_e1196685380858 : check e1196685380858 [[],[.left],[]] .three = true := by decide
def e1196685381230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1196685381230 : Closed e1196685381230 ∧ code e1196685381230 = 5594731892334 := by decide
theorem cert_e1196685381230 : check e1196685381230 [[],[.left],[]] .smaller = true := by decide
def e1196685381242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1196685381242 : Closed e1196685381242 ∧ code e1196685381242 = 5594731892346 := by decide
theorem cert_e1196685381242 : check e1196685381242 [[],[.left],[]] .smaller = true := by decide
def e1196685381430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685381430 : Closed e1196685381430 ∧ code e1196685381430 = 5594731892534 := by decide
theorem cert_e1196685381430 : check e1196685381430 [[],[.left],[]] .smaller = true := by decide
def e1196685381434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685381434 : Closed e1196685381434 ∧ code e1196685381434 = 5594731892538 := by decide
theorem cert_e1196685381434 : check e1196685381434 [[],[.left],[]] .smaller = true := by decide
def e1196685381530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1196685381530 : Closed e1196685381530 ∧ code e1196685381530 = 5594731892634 := by decide
theorem cert_e1196685381530 : check e1196685381530 [[],[.left],[]] .three = true := by decide
def e1196685387190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1196685387190 : Closed e1196685387190 ∧ code e1196685387190 = 5594731898294 := by decide
theorem cert_e1196685387190 : check e1196685387190 [[],[.left],[]] .smaller = true := by decide
def e1196685387222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1196685387222 : Closed e1196685387222 ∧ code e1196685387222 = 5594731898326 := by decide
theorem cert_e1196685387222 : check e1196685387222 [[],[.left],[]] .smaller = true := by decide
def e1196685387226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1196685387226 : Closed e1196685387226 ∧ code e1196685387226 = 5594731898330 := by decide
theorem cert_e1196685387226 : check e1196685387226 [[],[.left],[]] .smaller = true := by decide
def e1196685387382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1196685387382 : Closed e1196685387382 ∧ code e1196685387382 = 5594731898486 := by decide
theorem cert_e1196685387382 : check e1196685387382 [[],[.left],[]] .smaller = true := by decide
def e1196685387574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685387574 : Closed e1196685387574 ∧ code e1196685387574 = 5594731898678 := by decide
theorem cert_e1196685387574 : check e1196685387574 [[],[.left],[]] .smaller = true := by decide
def e1196685387578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685387578 : Closed e1196685387578 ∧ code e1196685387578 = 5594731898682 := by decide
theorem cert_e1196685387578 : check e1196685387578 [[],[.left],[]] .smaller = true := by decide
def e1196685390550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1196685390550 : Closed e1196685390550 ∧ code e1196685390550 = 5594731901654 := by decide
theorem cert_e1196685390550 : check e1196685390550 [[],[.left],[]] .three = true := by decide
def e1196685390554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1196685390554 : Closed e1196685390554 ∧ code e1196685390554 = 5594731901658 := by decide
theorem cert_e1196685390554 : check e1196685390554 [[],[.left],[]] .three = true := by decide
def e1196685390570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1196685390570 : Closed e1196685390570 ∧ code e1196685390570 = 5594731901674 := by decide
theorem cert_e1196685390570 : check e1196685390570 [[],[.left],[]] .three = true := by decide
def e1196685390646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685390646 : Closed e1196685390646 ∧ code e1196685390646 = 5594731901750 := by decide
theorem cert_e1196685390646 : check e1196685390646 [[],[.left],[]] .three = true := by decide
def e1196685390650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685390650 : Closed e1196685390650 ∧ code e1196685390650 = 5594731901754 := by decide
theorem cert_e1196685390650 : check e1196685390650 [[],[.left],[]] .three = true := by decide
def e1196685390746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1196685390746 : Closed e1196685390746 ∧ code e1196685390746 = 5594731901850 := by decide
theorem cert_e1196685390746 : check e1196685390746 [[],[.left],[]] .three = true := by decide
def e1196685615982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1196685615982 : Closed e1196685615982 ∧ code e1196685615982 = 5594732127086 := by decide
theorem cert_e1196685615982 : check e1196685615982 [[],[.left],[]] .chain = true := by decide
def e1196685615990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1196685615990 : Closed e1196685615990 ∧ code e1196685615990 = 5594732127094 := by decide
theorem cert_e1196685615990 : check e1196685615990 [[],[.left],[]] .chain = true := by decide
def e1196685616046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1196685616046 : Closed e1196685616046 ∧ code e1196685616046 = 5594732127150 := by decide
theorem cert_e1196685616046 : check e1196685616046 [[],[.left],[]] .chain = true := by decide
def e1196685616058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1196685616058 : Closed e1196685616058 ∧ code e1196685616058 = 5594732127162 := by decide
theorem cert_e1196685616058 : check e1196685616058 [[],[.left],[]] .chain = true := by decide
def e1196685616086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1196685616086 : Closed e1196685616086 ∧ code e1196685616086 = 5594732127190 := by decide
theorem cert_e1196685616086 : check e1196685616086 [[],[.left],[]] .chain = true := by decide
def e1196685616090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1196685616090 : Closed e1196685616090 ∧ code e1196685616090 = 5594732127194 := by decide
theorem cert_e1196685616090 : check e1196685616090 [[],[.left],[]] .chain = true := by decide
def e1196685617390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196685617390 : Closed e1196685617390 ∧ code e1196685617390 = 5594732128494 := by decide
theorem cert_e1196685617390 : check e1196685617390 [[],[.left],[]] .chain = true := by decide
def e1196685617398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196685617398 : Closed e1196685617398 ∧ code e1196685617398 = 5594732128502 := by decide
theorem cert_e1196685617398 : check e1196685617398 [[],[.left],[]] .chain = true := by decide
def e1196685617950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196685617950 : Closed e1196685617950 ∧ code e1196685617950 = 5594732129054 := by decide
theorem cert_e1196685617950 : check e1196685617950 [[],[.left],[]] .chain = true := by decide
def e1196685618062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196685618062 : Closed e1196685618062 ∧ code e1196685618062 = 5594732129166 := by decide
theorem cert_e1196685618062 : check e1196685618062 [[],[.left],[]] .chain = true := by decide
def e1196685618286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196685618286 : Closed e1196685618286 ∧ code e1196685618286 = 5594732129390 := by decide
theorem cert_e1196685618286 : check e1196685618286 [[],[.left],[]] .chain = true := by decide
def e1196685618298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196685618298 : Closed e1196685618298 ∧ code e1196685618298 = 5594732129402 := by decide
theorem cert_e1196685618298 : check e1196685618298 [[],[.left],[]] .chain = true := by decide
def e1196685618462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196685618462 : Closed e1196685618462 ∧ code e1196685618462 = 5594732129566 := by decide
theorem cert_e1196685618462 : check e1196685618462 [[],[.left],[]] .chain = true := by decide
def e1196685618630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196685618630 : Closed e1196685618630 ∧ code e1196685618630 = 5594732129734 := by decide
theorem cert_e1196685618630 : check e1196685618630 [[],[.left],[]] .chain = true := by decide
def e1196685618742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196685618742 : Closed e1196685618742 ∧ code e1196685618742 = 5594732129846 := by decide
theorem cert_e1196685618742 : check e1196685618742 [[],[.left],[]] .chain = true := by decide
def e1196685618746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196685618746 : Closed e1196685618746 ∧ code e1196685618746 = 5594732129850 := by decide
theorem cert_e1196685618746 : check e1196685618746 [[],[.left],[]] .chain = true := by decide
def e1196685618830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196685618830 : Closed e1196685618830 ∧ code e1196685618830 = 5594732129934 := by decide
theorem cert_e1196685618830 : check e1196685618830 [[],[.left],[]] .chain = true := by decide
def e1196685618886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196685618886 : Closed e1196685618886 ∧ code e1196685618886 = 5594732129990 := by decide
theorem cert_e1196685618886 : check e1196685618886 [[],[.left],[]] .chain = true := by decide
def e1196685619630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1196685619630 : Closed e1196685619630 ∧ code e1196685619630 = 5594732130734 := by decide
theorem cert_e1196685619630 : check e1196685619630 [[],[.left],[]] .chain = true := by decide
def e1196685619642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1196685619642 : Closed e1196685619642 ∧ code e1196685619642 = 5594732130746 := by decide
theorem cert_e1196685619642 : check e1196685619642 [[],[.left],[]] .chain = true := by decide
def e1196685619690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1196685619690 : Closed e1196685619690 ∧ code e1196685619690 = 5594732130794 := by decide
theorem cert_e1196685619690 : check e1196685619690 [[],[.left],[]] .chain = true := by decide
def e1196685620334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196685620334 : Closed e1196685620334 ∧ code e1196685620334 = 5594732131438 := by decide
theorem cert_e1196685620334 : check e1196685620334 [[],[.left],[]] .chain = true := by decide
def e1196685620346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196685620346 : Closed e1196685620346 ∧ code e1196685620346 = 5594732131450 := by decide
theorem cert_e1196685620346 : check e1196685620346 [[],[.left],[]] .chain = true := by decide
def e1196685620510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196685620510 : Closed e1196685620510 ∧ code e1196685620510 = 5594732131614 := by decide
theorem cert_e1196685620510 : check e1196685620510 [[],[.left],[]] .chain = true := by decide
def e1196685620678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196685620678 : Closed e1196685620678 ∧ code e1196685620678 = 5594732131782 := by decide
theorem cert_e1196685620678 : check e1196685620678 [[],[.left],[]] .chain = true := by decide
def e1196685621018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1196685621018 : Closed e1196685621018 ∧ code e1196685621018 = 5594732132122 := by decide
theorem cert_e1196685621018 : check e1196685621018 [[],[.left],[]] .chain = true := by decide
def e1196685621062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1196685621062 : Closed e1196685621062 ∧ code e1196685621062 = 5594732132166 := by decide
theorem cert_e1196685621062 : check e1196685621062 [[],[.left],[]] .chain = true := by decide
def e1196685621462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1196685621462 : Closed e1196685621462 ∧ code e1196685621462 = 5594732132566 := by decide
theorem cert_e1196685621462 : check e1196685621462 [[],[.left],[]] .chain = true := by decide
def e1196685621466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1196685621466 : Closed e1196685621466 ∧ code e1196685621466 = 5594732132570 := by decide
theorem cert_e1196685621466 : check e1196685621466 [[],[.left],[]] .chain = true := by decide
def e1196685621482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1196685621482 : Closed e1196685621482 ∧ code e1196685621482 = 5594732132586 := by decide
theorem cert_e1196685621482 : check e1196685621482 [[],[.left],[]] .chain = true := by decide
def e1196685621814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196685621814 : Closed e1196685621814 ∧ code e1196685621814 = 5594732132918 := by decide
theorem cert_e1196685621814 : check e1196685621814 [[],[.left],[]] .chain = true := by decide
def e1196685621818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196685621818 : Closed e1196685621818 ∧ code e1196685621818 = 5594732132922 := by decide
theorem cert_e1196685621818 : check e1196685621818 [[],[.left],[]] .chain = true := by decide
def e1196685621902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196685621902 : Closed e1196685621902 ∧ code e1196685621902 = 5594732133006 := by decide
theorem cert_e1196685621902 : check e1196685621902 [[],[.left],[]] .chain = true := by decide
def e1196685621958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196685621958 : Closed e1196685621958 ∧ code e1196685621958 = 5594732133062 := by decide
theorem cert_e1196685621958 : check e1196685621958 [[],[.left],[]] .chain = true := by decide
def e1196685622042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1196685622042 : Closed e1196685622042 ∧ code e1196685622042 = 5594732133146 := by decide
theorem cert_e1196685622042 : check e1196685622042 [[],[.left],[]] .chain = true := by decide
def e1196685622086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1196685622086 : Closed e1196685622086 ∧ code e1196685622086 = 5594732133190 := by decide
theorem cert_e1196685622086 : check e1196685622086 [[],[.left],[]] .chain = true := by decide
def e1196685626606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1196685626606 : Closed e1196685626606 ∧ code e1196685626606 = 5594732137710 := by decide
theorem cert_e1196685626606 : check e1196685626606 [[],[.left],[]] .chain = true := by decide
def e1196685626614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1196685626614 : Closed e1196685626614 ∧ code e1196685626614 = 5594732137718 := by decide
theorem cert_e1196685626614 : check e1196685626614 [[],[.left],[]] .chain = true := by decide
def e1196685626990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1196685626990 : Closed e1196685626990 ∧ code e1196685626990 = 5594732138094 := by decide
theorem cert_e1196685626990 : check e1196685626990 [[],[.left],[]] .chain = true := by decide
def e1196685627002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1196685627002 : Closed e1196685627002 ∧ code e1196685627002 = 5594732138106 := by decide
theorem cert_e1196685627002 : check e1196685627002 [[],[.left],[]] .chain = true := by decide
def e1196685627190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1196685627190 : Closed e1196685627190 ∧ code e1196685627190 = 5594732138294 := by decide
theorem cert_e1196685627190 : check e1196685627190 [[],[.left],[]] .chain = true := by decide
def e1196685627194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1196685627194 : Closed e1196685627194 ∧ code e1196685627194 = 5594732138298 := by decide
theorem cert_e1196685627194 : check e1196685627194 [[],[.left],[]] .chain = true := by decide
def e1196685629678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1196685629678 : Closed e1196685629678 ∧ code e1196685629678 = 5594732140782 := by decide
theorem cert_e1196685629678 : check e1196685629678 [[],[.left],[]] .chain = true := by decide
def e1196685629686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1196685629686 : Closed e1196685629686 ∧ code e1196685629686 = 5594732140790 := by decide
theorem cert_e1196685629686 : check e1196685629686 [[],[.left],[]] .chain = true := by decide
def e1196685630238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1196685630238 : Closed e1196685630238 ∧ code e1196685630238 = 5594732141342 := by decide
theorem cert_e1196685630238 : check e1196685630238 [[],[.left],[]] .chain = true := by decide
def e1196685630350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1196685630350 : Closed e1196685630350 ∧ code e1196685630350 = 5594732141454 := by decide
theorem cert_e1196685630350 : check e1196685630350 [[],[.left],[]] .chain = true := by decide
def e1196685630574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1196685630574 : Closed e1196685630574 ∧ code e1196685630574 = 5594732141678 := by decide
theorem cert_e1196685630574 : check e1196685630574 [[],[.left],[]] .chain = true := by decide
def e1196685630586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1196685630586 : Closed e1196685630586 ∧ code e1196685630586 = 5594732141690 := by decide
theorem cert_e1196685630586 : check e1196685630586 [[],[.left],[]] .chain = true := by decide
def e1196685630750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1196685630750 : Closed e1196685630750 ∧ code e1196685630750 = 5594732141854 := by decide
theorem cert_e1196685630750 : check e1196685630750 [[],[.left],[]] .chain = true := by decide
def e1196685630918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1196685630918 : Closed e1196685630918 ∧ code e1196685630918 = 5594732142022 := by decide
theorem cert_e1196685630918 : check e1196685630918 [[],[.left],[]] .chain = true := by decide
def e1196685631030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1196685631030 : Closed e1196685631030 ∧ code e1196685631030 = 5594732142134 := by decide
theorem cert_e1196685631030 : check e1196685631030 [[],[.left],[]] .chain = true := by decide
def e1196685631034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1196685631034 : Closed e1196685631034 ∧ code e1196685631034 = 5594732142138 := by decide
theorem cert_e1196685631034 : check e1196685631034 [[],[.left],[]] .chain = true := by decide
def e1196685631118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1196685631118 : Closed e1196685631118 ∧ code e1196685631118 = 5594732142222 := by decide
theorem cert_e1196685631118 : check e1196685631118 [[],[.left],[]] .chain = true := by decide
def e1196685631174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1196685631174 : Closed e1196685631174 ∧ code e1196685631174 = 5594732142278 := by decide
theorem cert_e1196685631174 : check e1196685631174 [[],[.left],[]] .chain = true := by decide
def e1196685633310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196685633310 : Closed e1196685633310 ∧ code e1196685633310 = 5594732144414 := by decide
theorem cert_e1196685633310 : check e1196685633310 [[],[.left],[]] .chain = true := by decide
def e1196685633422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196685633422 : Closed e1196685633422 ∧ code e1196685633422 = 5594732144526 := by decide
theorem cert_e1196685633422 : check e1196685633422 [[],[.left],[]] .chain = true := by decide
def e1196685636382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196685636382 : Closed e1196685636382 ∧ code e1196685636382 = 5594732147486 := by decide
theorem cert_e1196685636382 : check e1196685636382 [[],[.left],[]] .chain = true := by decide
def e1196685636550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196685636550 : Closed e1196685636550 ∧ code e1196685636550 = 5594732147654 := by decide
theorem cert_e1196685636550 : check e1196685636550 [[],[.left],[]] .chain = true := by decide
def e1196685638030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196685638030 : Closed e1196685638030 ∧ code e1196685638030 = 5594732149134 := by decide
theorem cert_e1196685638030 : check e1196685638030 [[],[.left],[]] .chain = true := by decide
def e1196685638086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196685638086 : Closed e1196685638086 ∧ code e1196685638086 = 5594732149190 := by decide
theorem cert_e1196685638086 : check e1196685638086 [[],[.left],[]] .chain = true := by decide
def e1196685641326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1196685641326 : Closed e1196685641326 ∧ code e1196685641326 = 5594732152430 := by decide
theorem cert_e1196685641326 : check e1196685641326 [[],[.left],[]] .chain = true := by decide
def e1196685641338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1196685641338 : Closed e1196685641338 ∧ code e1196685641338 = 5594732152442 := by decide
theorem cert_e1196685641338 : check e1196685641338 [[],[.left],[]] .chain = true := by decide
def e1196685641626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1196685641626 : Closed e1196685641626 ∧ code e1196685641626 = 5594732152730 := by decide
theorem cert_e1196685641626 : check e1196685641626 [[],[.left],[]] .chain = true := by decide
def e1196685642862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1196685642862 : Closed e1196685642862 ∧ code e1196685642862 = 5594732153966 := by decide
theorem cert_e1196685642862 : check e1196685642862 [[],[.left],[]] .chain = true := by decide
def e1196685642874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1196685642874 : Closed e1196685642874 ∧ code e1196685642874 = 5594732153978 := by decide
theorem cert_e1196685642874 : check e1196685642874 [[],[.left],[]] .chain = true := by decide
def e1196685643038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1196685643038 : Closed e1196685643038 ∧ code e1196685643038 = 5594732154142 := by decide
theorem cert_e1196685643038 : check e1196685643038 [[],[.left],[]] .chain = true := by decide
def e1196685643206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1196685643206 : Closed e1196685643206 ∧ code e1196685643206 = 5594732154310 := by decide
theorem cert_e1196685643206 : check e1196685643206 [[],[.left],[]] .chain = true := by decide
def e1196685643546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1196685643546 : Closed e1196685643546 ∧ code e1196685643546 = 5594732154650 := by decide
theorem cert_e1196685643546 : check e1196685643546 [[],[.left],[]] .chain = true := by decide
def e1196685643590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1196685643590 : Closed e1196685643590 ∧ code e1196685643590 = 5594732154694 := by decide
theorem cert_e1196685643590 : check e1196685643590 [[],[.left],[]] .chain = true := by decide
def e1196685644574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196685644574 : Closed e1196685644574 ∧ code e1196685644574 = 5594732155678 := by decide
theorem cert_e1196685644574 : check e1196685644574 [[],[.left],[]] .chain = true := by decide
def e1196685644742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196685644742 : Closed e1196685644742 ∧ code e1196685644742 = 5594732155846 := by decide
theorem cert_e1196685644742 : check e1196685644742 [[],[.left],[]] .chain = true := by decide
def e1196685647046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1196685647046 : Closed e1196685647046 ∧ code e1196685647046 = 5594732158150 := by decide
theorem cert_e1196685647046 : check e1196685647046 [[],[.left],[]] .chain = true := by decide
def e1196685648694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1196685648694 : Closed e1196685648694 ∧ code e1196685648694 = 5594732159798 := by decide
theorem cert_e1196685648694 : check e1196685648694 [[],[.left],[]] .chain = true := by decide
def e1196685648698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1196685648698 : Closed e1196685648698 ∧ code e1196685648698 = 5594732159802 := by decide
theorem cert_e1196685648698 : check e1196685648698 [[],[.left],[]] .chain = true := by decide
def e1196685648794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1196685648794 : Closed e1196685648794 ∧ code e1196685648794 = 5594732159898 := by decide
theorem cert_e1196685648794 : check e1196685648794 [[],[.left],[]] .chain = true := by decide
def e1196685649462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1196685649462 : Closed e1196685649462 ∧ code e1196685649462 = 5594732160566 := by decide
theorem cert_e1196685649462 : check e1196685649462 [[],[.left],[]] .chain = true := by decide
def e1196685649466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1196685649466 : Closed e1196685649466 ∧ code e1196685649466 = 5594732160570 := by decide
theorem cert_e1196685649466 : check e1196685649466 [[],[.left],[]] .chain = true := by decide
def e1196685649550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1196685649550 : Closed e1196685649550 ∧ code e1196685649550 = 5594732160654 := by decide
theorem cert_e1196685649550 : check e1196685649550 [[],[.left],[]] .chain = true := by decide
def e1196685649606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1196685649606 : Closed e1196685649606 ∧ code e1196685649606 = 5594732160710 := by decide
theorem cert_e1196685649606 : check e1196685649606 [[],[.left],[]] .chain = true := by decide
def e1196685649690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1196685649690 : Closed e1196685649690 ∧ code e1196685649690 = 5594732160794 := by decide
theorem cert_e1196685649690 : check e1196685649690 [[],[.left],[]] .chain = true := by decide
def e1196685649734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1196685649734 : Closed e1196685649734 ∧ code e1196685649734 = 5594732160838 := by decide
theorem cert_e1196685649734 : check e1196685649734 [[],[.left],[]] .chain = true := by decide
def e1196685650318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196685650318 : Closed e1196685650318 ∧ code e1196685650318 = 5594732161422 := by decide
theorem cert_e1196685650318 : check e1196685650318 [[],[.left],[]] .chain = true := by decide
end Blc.Floor42
