import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131188688822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1131188688822 : Closed e1131188688822 ∧ code e1131188688822 = 5529235199926 := by decide
theorem cert_e1131188688822 : check e1131188688822 [[],[.under]] .three = true := by decide
def e1131188690158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188690158 : Closed e1131188690158 ∧ code e1131188690158 = 5529235201262 := by decide
theorem cert_e1131188690158 : check e1131188690158 [[],[.under]] .three = true := by decide
def e1131188690166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188690166 : Closed e1131188690166 ∧ code e1131188690166 = 5529235201270 := by decide
theorem cert_e1131188690166 : check e1131188690166 [[],[.under]] .three = true := by decide
def e1131188690550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131188690550 : Closed e1131188690550 ∧ code e1131188690550 = 5529235201654 := by decide
theorem cert_e1131188690550 : check e1131188690550 [[],[.under]] .three = true := by decide
def e1131188700126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1131188700126 : Closed e1131188700126 ∧ code e1131188700126 = 5529235211230 := by decide
theorem cert_e1131188700126 : check e1131188700126 [[],[.under]] .three = true := by decide
def e1131188700142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1131188700142 : Closed e1131188700142 ∧ code e1131188700142 = 5529235211246 := by decide
theorem cert_e1131188700142 : check e1131188700142 [[],[.under]] .three = true := by decide
def e1131188702062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131188702062 : Closed e1131188702062 ∧ code e1131188702062 = 5529235213166 := by decide
theorem cert_e1131188702062 : check e1131188702062 [[],[.under]] .three = true := by decide
def e1131188702070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131188702070 : Closed e1131188702070 ∧ code e1131188702070 = 5529235213174 := by decide
theorem cert_e1131188702070 : check e1131188702070 [[],[.under]] .three = true := by decide
def e1131188702126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131188702126 : Closed e1131188702126 ∧ code e1131188702126 = 5529235213230 := by decide
theorem cert_e1131188702126 : check e1131188702126 [[],[.under]] .three = true := by decide
def e1131188702138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131188702138 : Closed e1131188702138 ∧ code e1131188702138 = 5529235213242 := by decide
theorem cert_e1131188702138 : check e1131188702138 [[],[.under]] .three = true := by decide
def e1131188702166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131188702166 : Closed e1131188702166 ∧ code e1131188702166 = 5529235213270 := by decide
theorem cert_e1131188702166 : check e1131188702166 [[],[.under]] .three = true := by decide
def e1131188702170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131188702170 : Closed e1131188702170 ∧ code e1131188702170 = 5529235213274 := by decide
theorem cert_e1131188702170 : check e1131188702170 [[],[.under]] .three = true := by decide
def e1131188702446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188702446 : Closed e1131188702446 ∧ code e1131188702446 = 5529235213550 := by decide
theorem cert_e1131188702446 : check e1131188702446 [[],[.under]] .three = true := by decide
def e1131188702454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188702454 : Closed e1131188702454 ∧ code e1131188702454 = 5529235213558 := by decide
theorem cert_e1131188702454 : check e1131188702454 [[],[.under]] .three = true := by decide
def e1131188702830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131188702830 : Closed e1131188702830 ∧ code e1131188702830 = 5529235213934 := by decide
theorem cert_e1131188702830 : check e1131188702830 [[],[.under]] .three = true := by decide
def e1131188702842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131188702842 : Closed e1131188702842 ∧ code e1131188702842 = 5529235213946 := by decide
theorem cert_e1131188702842 : check e1131188702842 [[],[.under]] .three = true := by decide
def e1131188703006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1131188703006 : Closed e1131188703006 ∧ code e1131188703006 = 5529235214110 := by decide
theorem cert_e1131188703006 : check e1131188703006 [[],[.under]] .three = true := by decide
def e1131188703030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131188703030 : Closed e1131188703030 ∧ code e1131188703030 = 5529235214134 := by decide
theorem cert_e1131188703030 : check e1131188703030 [[],[.under]] .three = true := by decide
def e1131188703034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131188703034 : Closed e1131188703034 ∧ code e1131188703034 = 5529235214138 := by decide
theorem cert_e1131188703034 : check e1131188703034 [[],[.under]] .three = true := by decide
def e1131188707822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1131188707822 : Closed e1131188707822 ∧ code e1131188707822 = 5529235218926 := by decide
theorem cert_e1131188707822 : check e1131188707822 [[],[.under]] .three = true := by decide
def e1131188708790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1131188708790 : Closed e1131188708790 ∧ code e1131188708790 = 5529235219894 := by decide
theorem cert_e1131188708790 : check e1131188708790 [[],[.under]] .three = true := by decide
def e1131188708822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1131188708822 : Closed e1131188708822 ∧ code e1131188708822 = 5529235219926 := by decide
theorem cert_e1131188708822 : check e1131188708822 [[],[.under]] .three = true := by decide
def e1131188708826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1131188708826 : Closed e1131188708826 ∧ code e1131188708826 = 5529235219930 := by decide
theorem cert_e1131188708826 : check e1131188708826 [[],[.under]] .three = true := by decide
def e1131188708982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131188708982 : Closed e1131188708982 ∧ code e1131188708982 = 5529235220086 := by decide
theorem cert_e1131188708982 : check e1131188708982 [[],[.under]] .three = true := by decide
def e1131188709150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1131188709150 : Closed e1131188709150 ∧ code e1131188709150 = 5529235220254 := by decide
theorem cert_e1131188709150 : check e1131188709150 [[],[.under]] .three = true := by decide
def e1131188709174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131188709174 : Closed e1131188709174 ∧ code e1131188709174 = 5529235220278 := by decide
theorem cert_e1131188709174 : check e1131188709174 [[],[.under]] .three = true := by decide
def e1131188709178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131188709178 : Closed e1131188709178 ∧ code e1131188709178 = 5529235220282 := by decide
theorem cert_e1131188709178 : check e1131188709178 [[],[.under]] .three = true := by decide
def e1131188709262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1131188709262 : Closed e1131188709262 ∧ code e1131188709262 = 5529235220366 := by decide
theorem cert_e1131188709262 : check e1131188709262 [[],[.under]] .three = true := by decide
def e1131188858334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1131188858334 : Closed e1131188858334 ∧ code e1131188858334 = 5529235369438 := by decide
theorem cert_e1131188858334 : check e1131188858334 [[],[.under]] .three = true := by decide
def e1131188858350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1131188858350 : Closed e1131188858350 ∧ code e1131188858350 = 5529235369454 := by decide
theorem cert_e1131188858350 : check e1131188858350 [[],[.under]] .three = true := by decide
def e1131188858590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1131188858590 : Closed e1131188858590 ∧ code e1131188858590 = 5529235369694 := by decide
theorem cert_e1131188858590 : check e1131188858590 [[],[.under]] .three = true := by decide
def e1131188858614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1131188858614 : Closed e1131188858614 ∧ code e1131188858614 = 5529235369718 := by decide
theorem cert_e1131188858614 : check e1131188858614 [[],[.under]] .three = true := by decide
def e1131188858718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1131188858718 : Closed e1131188858718 ∧ code e1131188858718 = 5529235369822 := by decide
theorem cert_e1131188858718 : check e1131188858718 [[],[.under]] .three = true := by decide
def e1131188858746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1131188858746 : Closed e1131188858746 ∧ code e1131188858746 = 5529235369850 := by decide
theorem cert_e1131188858746 : check e1131188858746 [[],[.under]] .three = true := by decide
def e1131188858798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1131188858798 : Closed e1131188858798 ∧ code e1131188858798 = 5529235369902 := by decide
theorem cert_e1131188858798 : check e1131188858798 [[],[.under]] .three = true := by decide
def e1131188858806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1131188858806 : Closed e1131188858806 ∧ code e1131188858806 = 5529235369910 := by decide
theorem cert_e1131188858806 : check e1131188858806 [[],[.under]] .three = true := by decide
def e1131188858810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1131188858810 : Closed e1131188858810 ∧ code e1131188858810 = 5529235369914 := by decide
theorem cert_e1131188858810 : check e1131188858810 [[],[.under]] .three = true := by decide
def e1131188859870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1131188859870 : Closed e1131188859870 ∧ code e1131188859870 = 5529235370974 := by decide
theorem cert_e1131188859870 : check e1131188859870 [[],[.under]] .three = true := by decide
def e1131188859886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1131188859886 : Closed e1131188859886 ∧ code e1131188859886 = 5529235370990 := by decide
theorem cert_e1131188859886 : check e1131188859886 [[],[.under]] .three = true := by decide
def e1131188861406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131188861406 : Closed e1131188861406 ∧ code e1131188861406 = 5529235372510 := by decide
theorem cert_e1131188861406 : check e1131188861406 [[],[.under]] .three = true := by decide
def e1131188861430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131188861430 : Closed e1131188861430 ∧ code e1131188861430 = 5529235372534 := by decide
theorem cert_e1131188861430 : check e1131188861430 [[],[.under]] .three = true := by decide
def e1131188862174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1131188862174 : Closed e1131188862174 ∧ code e1131188862174 = 5529235373278 := by decide
theorem cert_e1131188862174 : check e1131188862174 [[],[.under]] .three = true := by decide
def e1131188862202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1131188862202 : Closed e1131188862202 ∧ code e1131188862202 = 5529235373306 := by decide
theorem cert_e1131188862202 : check e1131188862202 [[],[.under]] .three = true := by decide
def e1131188862574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131188862574 : Closed e1131188862574 ∧ code e1131188862574 = 5529235373678 := by decide
theorem cert_e1131188862574 : check e1131188862574 [[],[.under]] .three = true := by decide
def e1131188862582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131188862582 : Closed e1131188862582 ∧ code e1131188862582 = 5529235373686 := by decide
theorem cert_e1131188862582 : check e1131188862582 [[],[.under]] .three = true := by decide
def e1131188862586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131188862586 : Closed e1131188862586 ∧ code e1131188862586 = 5529235373690 := by decide
theorem cert_e1131188862586 : check e1131188862586 [[],[.under]] .three = true := by decide
def e1131188890990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1131188890990 : Closed e1131188890990 ∧ code e1131188890990 = 5529235402094 := by decide
theorem cert_e1131188890990 : check e1131188890990 [[],[.under]] .three = true := by decide
def e1131188890998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1131188890998 : Closed e1131188890998 ∧ code e1131188890998 = 5529235402102 := by decide
theorem cert_e1131188890998 : check e1131188890998 [[],[.under]] .three = true := by decide
def e1131188891054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1131188891054 : Closed e1131188891054 ∧ code e1131188891054 = 5529235402158 := by decide
theorem cert_e1131188891054 : check e1131188891054 [[],[.under]] .three = true := by decide
def e1131188891066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1131188891066 : Closed e1131188891066 ∧ code e1131188891066 = 5529235402170 := by decide
theorem cert_e1131188891066 : check e1131188891066 [[],[.under]] .three = true := by decide
def e1131188891094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1131188891094 : Closed e1131188891094 ∧ code e1131188891094 = 5529235402198 := by decide
theorem cert_e1131188891094 : check e1131188891094 [[],[.under]] .three = true := by decide
def e1131188891098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1131188891098 : Closed e1131188891098 ∧ code e1131188891098 = 5529235402202 := by decide
theorem cert_e1131188891098 : check e1131188891098 [[],[.under]] .three = true := by decide
def e1131188891310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1131188891310 : Closed e1131188891310 ∧ code e1131188891310 = 5529235402414 := by decide
theorem cert_e1131188891310 : check e1131188891310 [[],[.under]] .three = true := by decide
def e1131188891322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1131188891322 : Closed e1131188891322 ∧ code e1131188891322 = 5529235402426 := by decide
theorem cert_e1131188891322 : check e1131188891322 [[],[.under]] .three = true := by decide
def e1131188891370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1131188891370 : Closed e1131188891370 ∧ code e1131188891370 = 5529235402474 := by decide
theorem cert_e1131188891370 : check e1131188891370 [[],[.under]] .three = true := by decide
def e1131188891478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1131188891478 : Closed e1131188891478 ∧ code e1131188891478 = 5529235402582 := by decide
theorem cert_e1131188891478 : check e1131188891478 [[],[.under]] .three = true := by decide
def e1131188891482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1131188891482 : Closed e1131188891482 ∧ code e1131188891482 = 5529235402586 := by decide
theorem cert_e1131188891482 : check e1131188891482 [[],[.under]] .three = true := by decide
def e1131188891498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1131188891498 : Closed e1131188891498 ∧ code e1131188891498 = 5529235402602 := by decide
theorem cert_e1131188891498 : check e1131188891498 [[],[.under]] .three = true := by decide
def e1131188892142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1131188892142 : Closed e1131188892142 ∧ code e1131188892142 = 5529235403246 := by decide
theorem cert_e1131188892142 : check e1131188892142 [[],[.under]] .three = true := by decide
def e1131188892526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1131188892526 : Closed e1131188892526 ∧ code e1131188892526 = 5529235403630 := by decide
theorem cert_e1131188892526 : check e1131188892526 [[],[.under]] .three = true := by decide
def e1131188892534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1131188892534 : Closed e1131188892534 ∧ code e1131188892534 = 5529235403638 := by decide
theorem cert_e1131188892534 : check e1131188892534 [[],[.under]] .three = true := by decide
def e1131188892590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1131188892590 : Closed e1131188892590 ∧ code e1131188892590 = 5529235403694 := by decide
theorem cert_e1131188892590 : check e1131188892590 [[],[.under]] .three = true := by decide
def e1131188892602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1131188892602 : Closed e1131188892602 ∧ code e1131188892602 = 5529235403706 := by decide
theorem cert_e1131188892602 : check e1131188892602 [[],[.under]] .three = true := by decide
def e1131188892630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1131188892630 : Closed e1131188892630 ∧ code e1131188892630 = 5529235403734 := by decide
theorem cert_e1131188892630 : check e1131188892630 [[],[.under]] .three = true := by decide
def e1131188892634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1131188892634 : Closed e1131188892634 ∧ code e1131188892634 = 5529235403738 := by decide
theorem cert_e1131188892634 : check e1131188892634 [[],[.under]] .three = true := by decide
def e1131188892910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188892910 : Closed e1131188892910 ∧ code e1131188892910 = 5529235404014 := by decide
theorem cert_e1131188892910 : check e1131188892910 [[],[.under]] .three = true := by decide
def e1131188892918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188892918 : Closed e1131188892918 ∧ code e1131188892918 = 5529235404022 := by decide
theorem cert_e1131188892918 : check e1131188892918 [[],[.under]] .three = true := by decide
def e1131188893294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188893294 : Closed e1131188893294 ∧ code e1131188893294 = 5529235404398 := by decide
theorem cert_e1131188893294 : check e1131188893294 [[],[.under]] .three = true := by decide
def e1131188893306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188893306 : Closed e1131188893306 ∧ code e1131188893306 = 5529235404410 := by decide
theorem cert_e1131188893306 : check e1131188893306 [[],[.under]] .three = true := by decide
def e1131188893470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1131188893470 : Closed e1131188893470 ∧ code e1131188893470 = 5529235404574 := by decide
theorem cert_e1131188893470 : check e1131188893470 [[],[.under]] .three = true := by decide
def e1131188893494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188893494 : Closed e1131188893494 ∧ code e1131188893494 = 5529235404598 := by decide
theorem cert_e1131188893494 : check e1131188893494 [[],[.under]] .three = true := by decide
def e1131188893498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188893498 : Closed e1131188893498 ∧ code e1131188893498 = 5529235404602 := by decide
theorem cert_e1131188893498 : check e1131188893498 [[],[.under]] .three = true := by decide
def e1131188894126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1131188894126 : Closed e1131188894126 ∧ code e1131188894126 = 5529235405230 := by decide
theorem cert_e1131188894126 : check e1131188894126 [[],[.under]] .three = true := by decide
def e1131188894138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1131188894138 : Closed e1131188894138 ∧ code e1131188894138 = 5529235405242 := by decide
theorem cert_e1131188894138 : check e1131188894138 [[],[.under]] .three = true := by decide
def e1131188894186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1131188894186 : Closed e1131188894186 ∧ code e1131188894186 = 5529235405290 := by decide
theorem cert_e1131188894186 : check e1131188894186 [[],[.under]] .three = true := by decide
def e1131188894318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188894318 : Closed e1131188894318 ∧ code e1131188894318 = 5529235405422 := by decide
theorem cert_e1131188894318 : check e1131188894318 [[],[.under]] .three = true := by decide
def e1131188894330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188894330 : Closed e1131188894330 ∧ code e1131188894330 = 5529235405434 := by decide
theorem cert_e1131188894330 : check e1131188894330 [[],[.under]] .three = true := by decide
def e1131188894618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1131188894618 : Closed e1131188894618 ∧ code e1131188894618 = 5529235405722 := by decide
theorem cert_e1131188894618 : check e1131188894618 [[],[.under]] .three = true := by decide
def e1131188894830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1131188894830 : Closed e1131188894830 ∧ code e1131188894830 = 5529235405934 := by decide
theorem cert_e1131188894830 : check e1131188894830 [[],[.under]] .three = true := by decide
def e1131188894842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1131188894842 : Closed e1131188894842 ∧ code e1131188894842 = 5529235405946 := by decide
theorem cert_e1131188894842 : check e1131188894842 [[],[.under]] .three = true := by decide
def e1131188894934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1131188894934 : Closed e1131188894934 ∧ code e1131188894934 = 5529235406038 := by decide
theorem cert_e1131188894934 : check e1131188894934 [[],[.under]] .three = true := by decide
def e1131188894938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1131188894938 : Closed e1131188894938 ∧ code e1131188894938 = 5529235406042 := by decide
theorem cert_e1131188894938 : check e1131188894938 [[],[.under]] .three = true := by decide
def e1131188894954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1131188894954 : Closed e1131188894954 ∧ code e1131188894954 = 5529235406058 := by decide
theorem cert_e1131188894954 : check e1131188894954 [[],[.under]] .three = true := by decide
def e1131188895006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1131188895006 : Closed e1131188895006 ∧ code e1131188895006 = 5529235406110 := by decide
theorem cert_e1131188895006 : check e1131188895006 [[],[.under]] .three = true := by decide
def e1131188895030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188895030 : Closed e1131188895030 ∧ code e1131188895030 = 5529235406134 := by decide
theorem cert_e1131188895030 : check e1131188895030 [[],[.under]] .three = true := by decide
def e1131188895034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188895034 : Closed e1131188895034 ∧ code e1131188895034 = 5529235406138 := by decide
theorem cert_e1131188895034 : check e1131188895034 [[],[.under]] .three = true := by decide
def e1131188895130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1131188895130 : Closed e1131188895130 ∧ code e1131188895130 = 5529235406234 := by decide
theorem cert_e1131188895130 : check e1131188895130 [[],[.under]] .three = true := by decide
def e1131188895174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1131188895174 : Closed e1131188895174 ∧ code e1131188895174 = 5529235406278 := by decide
theorem cert_e1131188895174 : check e1131188895174 [[],[.under]] .three = true := by decide
def e1131188896734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1131188896734 : Closed e1131188896734 ∧ code e1131188896734 = 5529235407838 := by decide
theorem cert_e1131188896734 : check e1131188896734 [[],[.under]] .three = true := by decide
def e1131188896750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1131188896750 : Closed e1131188896750 ∧ code e1131188896750 = 5529235407854 := by decide
theorem cert_e1131188896750 : check e1131188896750 [[],[.under]] .three = true := by decide
def e1131188898670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131188898670 : Closed e1131188898670 ∧ code e1131188898670 = 5529235409774 := by decide
theorem cert_e1131188898670 : check e1131188898670 [[],[.under]] .three = true := by decide
def e1131188898678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131188898678 : Closed e1131188898678 ∧ code e1131188898678 = 5529235409782 := by decide
theorem cert_e1131188898678 : check e1131188898678 [[],[.under]] .three = true := by decide
def e1131188898734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131188898734 : Closed e1131188898734 ∧ code e1131188898734 = 5529235409838 := by decide
theorem cert_e1131188898734 : check e1131188898734 [[],[.under]] .three = true := by decide
def e1131188898746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131188898746 : Closed e1131188898746 ∧ code e1131188898746 = 5529235409850 := by decide
theorem cert_e1131188898746 : check e1131188898746 [[],[.under]] .three = true := by decide
def e1131188898774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131188898774 : Closed e1131188898774 ∧ code e1131188898774 = 5529235409878 := by decide
theorem cert_e1131188898774 : check e1131188898774 [[],[.under]] .three = true := by decide
def e1131188898778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131188898778 : Closed e1131188898778 ∧ code e1131188898778 = 5529235409882 := by decide
theorem cert_e1131188898778 : check e1131188898778 [[],[.under]] .three = true := by decide
def e1131188899054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188899054 : Closed e1131188899054 ∧ code e1131188899054 = 5529235410158 := by decide
theorem cert_e1131188899054 : check e1131188899054 [[],[.under]] .three = true := by decide
def e1131188899062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188899062 : Closed e1131188899062 ∧ code e1131188899062 = 5529235410166 := by decide
theorem cert_e1131188899062 : check e1131188899062 [[],[.under]] .three = true := by decide
def e1131188899438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131188899438 : Closed e1131188899438 ∧ code e1131188899438 = 5529235410542 := by decide
theorem cert_e1131188899438 : check e1131188899438 [[],[.under]] .three = true := by decide
def e1131188899450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131188899450 : Closed e1131188899450 ∧ code e1131188899450 = 5529235410554 := by decide
theorem cert_e1131188899450 : check e1131188899450 [[],[.under]] .three = true := by decide
def e1131188899614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1131188899614 : Closed e1131188899614 ∧ code e1131188899614 = 5529235410718 := by decide
theorem cert_e1131188899614 : check e1131188899614 [[],[.under]] .three = true := by decide
def e1131188899638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131188899638 : Closed e1131188899638 ∧ code e1131188899638 = 5529235410742 := by decide
theorem cert_e1131188899638 : check e1131188899638 [[],[.under]] .three = true := by decide
def e1131188899642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131188899642 : Closed e1131188899642 ∧ code e1131188899642 = 5529235410746 := by decide
theorem cert_e1131188899642 : check e1131188899642 [[],[.under]] .three = true := by decide
def e1131188904414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1131188904414 : Closed e1131188904414 ∧ code e1131188904414 = 5529235415518 := by decide
theorem cert_e1131188904414 : check e1131188904414 [[],[.under]] .three = true := by decide
def e1131188904438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1131188904438 : Closed e1131188904438 ∧ code e1131188904438 = 5529235415542 := by decide
theorem cert_e1131188904438 : check e1131188904438 [[],[.under]] .three = true := by decide
def e1131188905390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1131188905390 : Closed e1131188905390 ∧ code e1131188905390 = 5529235416494 := by decide
theorem cert_e1131188905390 : check e1131188905390 [[],[.under]] .three = true := by decide
def e1131188905402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1131188905402 : Closed e1131188905402 ∧ code e1131188905402 = 5529235416506 := by decide
theorem cert_e1131188905402 : check e1131188905402 [[],[.under]] .three = true := by decide
def e1131188905450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1131188905450 : Closed e1131188905450 ∧ code e1131188905450 = 5529235416554 := by decide
theorem cert_e1131188905450 : check e1131188905450 [[],[.under]] .three = true := by decide
def e1131188905582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131188905582 : Closed e1131188905582 ∧ code e1131188905582 = 5529235416686 := by decide
theorem cert_e1131188905582 : check e1131188905582 [[],[.under]] .three = true := by decide
def e1131188905594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131188905594 : Closed e1131188905594 ∧ code e1131188905594 = 5529235416698 := by decide
theorem cert_e1131188905594 : check e1131188905594 [[],[.under]] .three = true := by decide
def e1131188905882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131188905882 : Closed e1131188905882 ∧ code e1131188905882 = 5529235416986 := by decide
theorem cert_e1131188905882 : check e1131188905882 [[],[.under]] .three = true := by decide
def e1131188908270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188908270 : Closed e1131188908270 ∧ code e1131188908270 = 5529235419374 := by decide
theorem cert_e1131188908270 : check e1131188908270 [[],[.under]] .three = true := by decide
def e1131188908278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188908278 : Closed e1131188908278 ∧ code e1131188908278 = 5529235419382 := by decide
theorem cert_e1131188908278 : check e1131188908278 [[],[.under]] .three = true := by decide
def e1131188908758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1131188908758 : Closed e1131188908758 ∧ code e1131188908758 = 5529235419862 := by decide
theorem cert_e1131188908758 : check e1131188908758 [[],[.under]] .three = true := by decide
def e1131188908762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1131188908762 : Closed e1131188908762 ∧ code e1131188908762 = 5529235419866 := by decide
theorem cert_e1131188908762 : check e1131188908762 [[],[.under]] .three = true := by decide
def e1131188908778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1131188908778 : Closed e1131188908778 ∧ code e1131188908778 = 5529235419882 := by decide
theorem cert_e1131188908778 : check e1131188908778 [[],[.under]] .three = true := by decide
def e1131188908830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1131188908830 : Closed e1131188908830 ∧ code e1131188908830 = 5529235419934 := by decide
theorem cert_e1131188908830 : check e1131188908830 [[],[.under]] .three = true := by decide
def e1131188908854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131188908854 : Closed e1131188908854 ∧ code e1131188908854 = 5529235419958 := by decide
theorem cert_e1131188908854 : check e1131188908854 [[],[.under]] .three = true := by decide
def e1131188908858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131188908858 : Closed e1131188908858 ∧ code e1131188908858 = 5529235419962 := by decide
theorem cert_e1131188908858 : check e1131188908858 [[],[.under]] .three = true := by decide
def e1131188908954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131188908954 : Closed e1131188908954 ∧ code e1131188908954 = 5529235420058 := by decide
theorem cert_e1131188908954 : check e1131188908954 [[],[.under]] .three = true := by decide
def e1131188908998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1131188908998 : Closed e1131188908998 ∧ code e1131188908998 = 5529235420102 := by decide
theorem cert_e1131188908998 : check e1131188908998 [[],[.under]] .three = true := by decide
def e1131188983518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1131188983518 : Closed e1131188983518 ∧ code e1131188983518 = 5529235494622 := by decide
theorem cert_e1131188983518 : check e1131188983518 [[],[.under]] .three = true := by decide
def e1131188983542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1131188983542 : Closed e1131188983542 ∧ code e1131188983542 = 5529235494646 := by decide
private def t_e1131188983542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e1131188983542 : ¬ IsSelfInterpreter e1131188983542 :=
  wSource (t := t_e1131188983542) (replay_sound (ps := []) (t := e1131188983542) (by decide)) (by decide)
def e1131188983646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1131188983646 : Closed e1131188983646 ∧ code e1131188983646 = 5529235494750 := by decide
theorem cert_e1131188983646 : check e1131188983646 [[],[.under]] .three = true := by decide
def e1131188983662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1131188983662 : Closed e1131188983662 ∧ code e1131188983662 = 5529235494766 := by decide
theorem cert_e1131188983662 : check e1131188983662 [[],[.under]] .three = true := by decide
def e1131188983670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1131188983670 : Closed e1131188983670 ∧ code e1131188983670 = 5529235494774 := by decide
theorem cert_e1131188983670 : check e1131188983670 [[],[.under]] .three = true := by decide
def e1131188983674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1131188983674 : Closed e1131188983674 ∧ code e1131188983674 = 5529235494778 := by decide
theorem cert_e1131188983674 : check e1131188983674 [[],[.under]] .three = true := by decide
def e1131188983734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1131188983734 : Closed e1131188983734 ∧ code e1131188983734 = 5529235494838 := by decide
theorem cert_e1131188983734 : check e1131188983734 [[],[.under]] .three = true := by decide
def e1131188983766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1131188983766 : Closed e1131188983766 ∧ code e1131188983766 = 5529235494870 := by decide
private def t_e1131188983766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e1131188983766 : ¬ IsSelfInterpreter e1131188983766 :=
  wSource (t := t_e1131188983766) (replay_sound (ps := []) (t := e1131188983766) (by decide)) (by decide)
def e1131188983770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1131188983770 : Closed e1131188983770 ∧ code e1131188983770 = 5529235494874 := by decide
theorem cert_e1131188983770 : check e1131188983770 [[],[.under]] .three = true := by decide
def e1131188984286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131188984286 : Closed e1131188984286 ∧ code e1131188984286 = 5529235495390 := by decide
theorem cert_e1131188984286 : check e1131188984286 [[],[.under]] .three = true := by decide
def e1131188984310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131188984310 : Closed e1131188984310 ∧ code e1131188984310 = 5529235495414 := by decide
theorem cert_e1131188984310 : check e1131188984310 [[],[.under]] .three = true := by decide
def e1131188985054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1131188985054 : Closed e1131188985054 ∧ code e1131188985054 = 5529235496158 := by decide
theorem cert_e1131188985054 : check e1131188985054 [[],[.under]] .three = true := by decide
def e1131188985070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188985070 : Closed e1131188985070 ∧ code e1131188985070 = 5529235496174 := by decide
theorem cert_e1131188985070 : check e1131188985070 [[],[.under]] .three = true := by decide
def e1131188985078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188985078 : Closed e1131188985078 ∧ code e1131188985078 = 5529235496182 := by decide
theorem cert_e1131188985078 : check e1131188985078 [[],[.under]] .three = true := by decide
def e1131188985082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1131188985082 : Closed e1131188985082 ∧ code e1131188985082 = 5529235496186 := by decide
theorem cert_e1131188985082 : check e1131188985082 [[],[.under]] .three = true := by decide
def e1131188985462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131188985462 : Closed e1131188985462 ∧ code e1131188985462 = 5529235496566 := by decide
theorem cert_e1131188985462 : check e1131188985462 [[],[.under]] .three = true := by decide
def e1131188985654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131188985654 : Closed e1131188985654 ∧ code e1131188985654 = 5529235496758 := by decide
theorem cert_e1131188985654 : check e1131188985654 [[],[.under]] .three = true := by decide
def e1131188985658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131188985658 : Closed e1131188985658 ∧ code e1131188985658 = 5529235496762 := by decide
theorem cert_e1131188985658 : check e1131188985658 [[],[.under]] .three = true := by decide
def e1131188999862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1131188999862 : Closed e1131188999862 ∧ code e1131188999862 = 5529235510966 := by decide
theorem cert_e1131188999862 : check e1131188999862 [[],[.under]] .three = true := by decide
def e1131188999894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1131188999894 : Closed e1131188999894 ∧ code e1131188999894 = 5529235510998 := by decide
theorem cert_e1131188999894 : check e1131188999894 [[],[.under]] .three = true := by decide
def e1131188999898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1131188999898 : Closed e1131188999898 ∧ code e1131188999898 = 5529235511002 := by decide
theorem cert_e1131188999898 : check e1131188999898 [[],[.under]] .three = true := by decide
def e1131189000022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1131189000022 : Closed e1131189000022 ∧ code e1131189000022 = 5529235511126 := by decide
theorem cert_e1131189000022 : check e1131189000022 [[],[.under]] .three = true := by decide
def e1131189000026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1131189000026 : Closed e1131189000026 ∧ code e1131189000026 = 5529235511130 := by decide
theorem cert_e1131189000026 : check e1131189000026 [[],[.under]] .three = true := by decide
def e1131189000042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1131189000042 : Closed e1131189000042 ∧ code e1131189000042 = 5529235511146 := by decide
theorem cert_e1131189000042 : check e1131189000042 [[],[.under]] .three = true := by decide
def e1131189000430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1131189000430 : Closed e1131189000430 ∧ code e1131189000430 = 5529235511534 := by decide
theorem cert_e1131189000430 : check e1131189000430 [[],[.under]] .three = true := by decide
def e1131189000438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1131189000438 : Closed e1131189000438 ∧ code e1131189000438 = 5529235511542 := by decide
theorem cert_e1131189000438 : check e1131189000438 [[],[.under]] .three = true := by decide
def e1131189000630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1131189000630 : Closed e1131189000630 ∧ code e1131189000630 = 5529235511734 := by decide
theorem cert_e1131189000630 : check e1131189000630 [[],[.under]] .three = true := by decide
def e1131189000662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1131189000662 : Closed e1131189000662 ∧ code e1131189000662 = 5529235511766 := by decide
theorem cert_e1131189000662 : check e1131189000662 [[],[.under]] .three = true := by decide
def e1131189000666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1131189000666 : Closed e1131189000666 ∧ code e1131189000666 = 5529235511770 := by decide
theorem cert_e1131189000666 : check e1131189000666 [[],[.under]] .three = true := by decide
def e1131189000822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131189000822 : Closed e1131189000822 ∧ code e1131189000822 = 5529235511926 := by decide
theorem cert_e1131189000822 : check e1131189000822 [[],[.under]] .three = true := by decide
def e1131189000990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1131189000990 : Closed e1131189000990 ∧ code e1131189000990 = 5529235512094 := by decide
theorem cert_e1131189000990 : check e1131189000990 [[],[.under]] .three = true := by decide
def e1131189001014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131189001014 : Closed e1131189001014 ∧ code e1131189001014 = 5529235512118 := by decide
theorem cert_e1131189001014 : check e1131189001014 [[],[.under]] .three = true := by decide
def e1131189001018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131189001018 : Closed e1131189001018 ∧ code e1131189001018 = 5529235512122 := by decide
theorem cert_e1131189001018 : check e1131189001018 [[],[.under]] .three = true := by decide
def e1131189001102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1131189001102 : Closed e1131189001102 ∧ code e1131189001102 = 5529235512206 := by decide
theorem cert_e1131189001102 : check e1131189001102 [[],[.under]] .three = true := by decide
def e1131189001326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1131189001326 : Closed e1131189001326 ∧ code e1131189001326 = 5529235512430 := by decide
theorem cert_e1131189001326 : check e1131189001326 [[],[.under]] .three = true := by decide
def e1131189001338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1131189001338 : Closed e1131189001338 ∧ code e1131189001338 = 5529235512442 := by decide
theorem cert_e1131189001338 : check e1131189001338 [[],[.under]] .three = true := by decide
def e1131189001430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1131189001430 : Closed e1131189001430 ∧ code e1131189001430 = 5529235512534 := by decide
theorem cert_e1131189001430 : check e1131189001430 [[],[.under]] .three = true := by decide
def e1131189001434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1131189001434 : Closed e1131189001434 ∧ code e1131189001434 = 5529235512538 := by decide
theorem cert_e1131189001434 : check e1131189001434 [[],[.under]] .three = true := by decide
def e1131189001450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1131189001450 : Closed e1131189001450 ∧ code e1131189001450 = 5529235512554 := by decide
theorem cert_e1131189001450 : check e1131189001450 [[],[.under]] .three = true := by decide
end Blc.Floor42
