import Tables
import Batch253
namespace Blc.Floor42.Grades253
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211550234074 : ¬ IsSelfInterpreter e1211550234074 := cutM0_2 (by decide)
#print axioms ex_e1211550234074
theorem ex_e1211550256602 : ¬ IsSelfInterpreter e1211550256602 := cutM0_2 (by decide)
#print axioms ex_e1211550256602
theorem ex_e1211550256986 : ¬ IsSelfInterpreter e1211550256986 := cutM0_2 (by decide)
#print axioms ex_e1211550256986
theorem ex_e1211550263130 : ¬ IsSelfInterpreter e1211550263130 := cutM0_2 (by decide)
#print axioms ex_e1211550263130
theorem ex_e1211550346938 : ¬ IsSelfInterpreter e1211550346938 := cutM0_2 (by decide)
#print axioms ex_e1211550346938
theorem ex_e1211550349754 : ¬ IsSelfInterpreter e1211550349754 := cutM0_2 (by decide)
#print axioms ex_e1211550349754
theorem ex_e1211550349802 : ¬ IsSelfInterpreter e1211550349802 := cutM0_2 (by decide)
#print axioms ex_e1211550349802
theorem ex_e1211550350570 : ¬ IsSelfInterpreter e1211550350570 := cutM0_2 (by decide)
#print axioms ex_e1211550350570
theorem ex_e1211550346682 : ¬ IsSelfInterpreter e1211550346682 := cutM1_2 (by decide)
#print axioms ex_e1211550346682
theorem ex_e1211550346714 : ¬ IsSelfInterpreter e1211550346714 := cutM1_2 (by decide)
#print axioms ex_e1211550346714
theorem ex_e1211550347098 : ¬ IsSelfInterpreter e1211550347098 := cutM1_2 (by decide)
#print axioms ex_e1211550347098
theorem ex_e1211550348218 : ¬ IsSelfInterpreter e1211550348218 := cutM1_2 (by decide)
#print axioms ex_e1211550348218
theorem ex_e1211550348250 : ¬ IsSelfInterpreter e1211550348250 := cutM1_2 (by decide)
#print axioms ex_e1211550348250
theorem ex_e1211550350554 : ¬ IsSelfInterpreter e1211550350554 := cutM1_2 (by decide)
#print axioms ex_e1211550350554
theorem ex_e1211549973946 : ¬ IsSelfInterpreter e1211549973946 := cutM3_1 (by decide)
#print axioms ex_e1211549973946
theorem ex_e1211550232026 : ¬ IsSelfInterpreter e1211550232026 := cutM3_1 (by decide)
#print axioms ex_e1211550232026
theorem ex_e1211550232282 : ¬ IsSelfInterpreter e1211550232282 := cutM3_1 (by decide)
#print axioms ex_e1211550232282
theorem ex_e1211550235354 : ¬ IsSelfInterpreter e1211550235354 := cutM3_1 (by decide)
#print axioms ex_e1211550235354
theorem ex_e1211550244314 : ¬ IsSelfInterpreter e1211550244314 := cutM3_1 (by decide)
#print axioms ex_e1211550244314
theorem ex_e1211550244570 : ¬ IsSelfInterpreter e1211550244570 := cutM3_1 (by decide)
#print axioms ex_e1211550244570
theorem ex_e1211550263002 : ¬ IsSelfInterpreter e1211550263002 := cutM3_1 (by decide)
#print axioms ex_e1211550263002
end Blc.Floor42.Grades253
