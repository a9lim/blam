import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204270554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e1211204270554 : Closed e1211204270554 ∧ code e1211204270554 = 5609250781658 := by decide
theorem cert_e1211204270554 : check e1211204270554 [[],[]] .chain = true := by decide
def e1211204270710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204270710 : Closed e1211204270710 ∧ code e1211204270710 = 5609250781814 := by decide
theorem cert_e1211204270710 : check e1211204270710 [[],[]] .chain = true := by decide
def e1211204270854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204270854 : Closed e1211204270854 ∧ code e1211204270854 = 5609250781958 := by decide
theorem cert_e1211204270854 : check e1211204270854 [[],[]] .chain = true := by decide
def e1211204270878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211204270878 : Closed e1211204270878 ∧ code e1211204270878 = 5609250781982 := by decide
theorem cert_e1211204270878 : check e1211204270878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204270902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204270902 : Closed e1211204270902 ∧ code e1211204270902 = 5609250782006 := by decide
theorem cert_e1211204270902 : check e1211204270902 [[],[]] .chain = true := by decide
def e1211204270906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204270906 : Closed e1211204270906 ∧ code e1211204270906 = 5609250782010 := by decide
theorem cert_e1211204270906 : check e1211204270906 [[],[]] .chain = true := by decide
def e1211204270990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211204270990 : Closed e1211204270990 ∧ code e1211204270990 = 5609250782094 := by decide
theorem cert_e1211204270990 : check e1211204270990 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204278126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1211204278126 : Closed e1211204278126 ∧ code e1211204278126 = 5609250789230 := by decide
theorem cert_e1211204278126 : check e1211204278126 [[],[]] .chain = true := by decide
def e1211204278134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1211204278134 : Closed e1211204278134 ∧ code e1211204278134 = 5609250789238 := by decide
theorem cert_e1211204278134 : check e1211204278134 [[],[]] .chain = true := by decide
def e1211204278198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1211204278198 : Closed e1211204278198 ∧ code e1211204278198 = 5609250789302 := by decide
theorem cert_e1211204278198 : check e1211204278198 [[],[]] .chain = true := by decide
def e1211204279534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204279534 : Closed e1211204279534 ∧ code e1211204279534 = 5609250790638 := by decide
theorem cert_e1211204279534 : check e1211204279534 [[],[]] .chain = true := by decide
def e1211204279542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204279542 : Closed e1211204279542 ∧ code e1211204279542 = 5609250790646 := by decide
theorem cert_e1211204279542 : check e1211204279542 [[],[]] .chain = true := by decide
def e1211204279926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204279926 : Closed e1211204279926 ∧ code e1211204279926 = 5609250791030 := by decide
theorem cert_e1211204279926 : check e1211204279926 [[],[]] .chain = true := by decide
def e1211204288638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211204288638 : Closed e1211204288638 ∧ code e1211204288638 = 5609250799742 := by decide
theorem cert_e1211204288638 : check e1211204288638 [[],[]] .chain = true := by decide
def e1211204289502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211204289502 : Closed e1211204289502 ∧ code e1211204289502 = 5609250800606 := by decide
theorem cert_e1211204289502 : check e1211204289502 [[],[]] .chain = true := by decide
def e1211204289506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211204289506 : Closed e1211204289506 ∧ code e1211204289506 = 5609250800610 := by decide
theorem cert_e1211204289506 : check e1211204289506 [[],[]] .chain = true := by decide
def e1211204289518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211204289518 : Closed e1211204289518 ∧ code e1211204289518 = 5609250800622 := by decide
theorem cert_e1211204289518 : check e1211204289518 [[],[]] .chain = true := by decide
def e1211204291438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211204291438 : Closed e1211204291438 ∧ code e1211204291438 = 5609250802542 := by decide
theorem cert_e1211204291438 : check e1211204291438 [[],[]] .chain = true := by decide
def e1211204291446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211204291446 : Closed e1211204291446 ∧ code e1211204291446 = 5609250802550 := by decide
theorem cert_e1211204291446 : check e1211204291446 [[],[]] .chain = true := by decide
def e1211204291502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211204291502 : Closed e1211204291502 ∧ code e1211204291502 = 5609250802606 := by decide
theorem cert_e1211204291502 : check e1211204291502 [[],[]] .chain = true := by decide
def e1211204291514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211204291514 : Closed e1211204291514 ∧ code e1211204291514 = 5609250802618 := by decide
theorem cert_e1211204291514 : check e1211204291514 [[],[]] .chain = true := by decide
def e1211204291542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211204291542 : Closed e1211204291542 ∧ code e1211204291542 = 5609250802646 := by decide
theorem cert_e1211204291542 : check e1211204291542 [[],[]] .chain = true := by decide
def e1211204291546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211204291546 : Closed e1211204291546 ∧ code e1211204291546 = 5609250802650 := by decide
theorem cert_e1211204291546 : check e1211204291546 [[],[]] .chain = true := by decide
def e1211204291822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204291822 : Closed e1211204291822 ∧ code e1211204291822 = 5609250802926 := by decide
theorem cert_e1211204291822 : check e1211204291822 [[],[]] .chain = true := by decide
def e1211204291830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204291830 : Closed e1211204291830 ∧ code e1211204291830 = 5609250802934 := by decide
theorem cert_e1211204291830 : check e1211204291830 [[],[]] .chain = true := by decide
def e1211204292206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204292206 : Closed e1211204292206 ∧ code e1211204292206 = 5609250803310 := by decide
theorem cert_e1211204292206 : check e1211204292206 [[],[]] .chain = true := by decide
def e1211204292218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204292218 : Closed e1211204292218 ∧ code e1211204292218 = 5609250803322 := by decide
theorem cert_e1211204292218 : check e1211204292218 [[],[]] .chain = true := by decide
def e1211204292358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204292358 : Closed e1211204292358 ∧ code e1211204292358 = 5609250803462 := by decide
theorem cert_e1211204292358 : check e1211204292358 [[],[]] .chain = true := by decide
def e1211204292382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211204292382 : Closed e1211204292382 ∧ code e1211204292382 = 5609250803486 := by decide
theorem cert_e1211204292382 : check e1211204292382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204292406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204292406 : Closed e1211204292406 ∧ code e1211204292406 = 5609250803510 := by decide
theorem cert_e1211204292406 : check e1211204292406 [[],[]] .chain = true := by decide
def e1211204292410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204292410 : Closed e1211204292410 ∧ code e1211204292410 = 5609250803514 := by decide
theorem cert_e1211204292410 : check e1211204292410 [[],[]] .chain = true := by decide
def e1211204296766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211204296766 : Closed e1211204296766 ∧ code e1211204296766 = 5609250807870 := by decide
theorem cert_e1211204296766 : check e1211204296766 [[],[]] .chain = true := by decide
def e1211204297186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211204297186 : Closed e1211204297186 ∧ code e1211204297186 = 5609250808290 := by decide
theorem cert_e1211204297186 : check e1211204297186 [[],[]] .chain = true := by decide
def e1211204297198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211204297198 : Closed e1211204297198 ∧ code e1211204297198 = 5609250808302 := by decide
theorem cert_e1211204297198 : check e1211204297198 [[],[]] .chain = true := by decide
def e1211204298166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211204298166 : Closed e1211204298166 ∧ code e1211204298166 = 5609250809270 := by decide
theorem cert_e1211204298166 : check e1211204298166 [[],[]] .chain = true := by decide
def e1211204298198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211204298198 : Closed e1211204298198 ∧ code e1211204298198 = 5609250809302 := by decide
theorem cert_e1211204298198 : check e1211204298198 [[],[]] .chain = true := by decide
def e1211204298202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211204298202 : Closed e1211204298202 ∧ code e1211204298202 = 5609250809306 := by decide
theorem cert_e1211204298202 : check e1211204298202 [[],[]] .chain = true := by decide
def e1211204298358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204298358 : Closed e1211204298358 ∧ code e1211204298358 = 5609250809462 := by decide
theorem cert_e1211204298358 : check e1211204298358 [[],[]] .chain = true := by decide
def e1211204298502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204298502 : Closed e1211204298502 ∧ code e1211204298502 = 5609250809606 := by decide
theorem cert_e1211204298502 : check e1211204298502 [[],[]] .chain = true := by decide
def e1211204298526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211204298526 : Closed e1211204298526 ∧ code e1211204298526 = 5609250809630 := by decide
theorem cert_e1211204298526 : check e1211204298526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204298550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204298550 : Closed e1211204298550 ∧ code e1211204298550 = 5609250809654 := by decide
theorem cert_e1211204298550 : check e1211204298550 [[],[]] .chain = true := by decide
def e1211204298554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204298554 : Closed e1211204298554 ∧ code e1211204298554 = 5609250809658 := by decide
theorem cert_e1211204298554 : check e1211204298554 [[],[]] .chain = true := by decide
def e1211204298638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211204298638 : Closed e1211204298638 ∧ code e1211204298638 = 5609250809742 := by decide
theorem cert_e1211204298638 : check e1211204298638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1211204305390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))) (.var 2))))))
theorem wire_e1211204305390 : Closed e1211204305390 ∧ code e1211204305390 = 5609250816494 := by decide
theorem cert_e1211204305390 : check e1211204305390 [[],[]] .chain = true := by decide
def e1211204305402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 5)))))) (.var 0))))))
theorem wire_e1211204305402 : Closed e1211204305402 ∧ code e1211204305402 = 5609250816506 := by decide
theorem cert_e1211204305402 : check e1211204305402 [[],[]] .chain = true := by decide
def e1211204306158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204306158 : Closed e1211204306158 ∧ code e1211204306158 = 5609250817262 := by decide
theorem cert_e1211204306158 : check e1211204306158 [[],[]] .chain = true := by decide
def e1211204306166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204306166 : Closed e1211204306166 ∧ code e1211204306166 = 5609250817270 := by decide
theorem cert_e1211204306166 : check e1211204306166 [[],[]] .chain = true := by decide
def e1211204306542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204306542 : Closed e1211204306542 ∧ code e1211204306542 = 5609250817646 := by decide
theorem cert_e1211204306542 : check e1211204306542 [[],[]] .chain = true := by decide
def e1211204306554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204306554 : Closed e1211204306554 ∧ code e1211204306554 = 5609250817658 := by decide
theorem cert_e1211204306554 : check e1211204306554 [[],[]] .chain = true := by decide
def e1211204306718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.lam (.var 3)))))))
theorem wire_e1211204306718 : Closed e1211204306718 ∧ code e1211204306718 = 5609250817822 := by decide
theorem cert_e1211204306718 : check e1211204306718 [[],[]] .chain = true := by decide
def e1211204306886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.lam (.var 1)))))))
theorem wire_e1211204306886 : Closed e1211204306886 ∧ code e1211204306886 = 5609250817990 := by decide
theorem cert_e1211204306886 : check e1211204306886 [[],[]] .chain = true := by decide
def e1211204308078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e1211204308078 : Closed e1211204308078 ∧ code e1211204308078 = 5609250819182 := by decide
theorem cert_e1211204308078 : check e1211204308078 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204308254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e1211204308254 : Closed e1211204308254 ∧ code e1211204308254 = 5609250819358 := by decide
theorem cert_e1211204308254 : check e1211204308254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204308462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 2))))))
theorem wire_e1211204308462 : Closed e1211204308462 ∧ code e1211204308462 = 5609250819566 := by decide
theorem cert_e1211204308462 : check e1211204308462 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204308526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211204308526 : Closed e1211204308526 ∧ code e1211204308526 = 5609250819630 := by decide
theorem cert_e1211204308526 : check e1211204308526 [[],[]] .chain = true := by decide
def e1211204308718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e1211204308718 : Closed e1211204308718 ∧ code e1211204308718 = 5609250819822 := by decide
theorem cert_e1211204308718 : check e1211204308718 [[],[]] .chain = true := by decide
def e1211204308726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e1211204308726 : Closed e1211204308726 ∧ code e1211204308726 = 5609250819830 := by decide
theorem cert_e1211204308726 : check e1211204308726 [[],[]] .chain = true := by decide
def e1211204308846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e1211204308846 : Closed e1211204308846 ∧ code e1211204308846 = 5609250819950 := by decide
theorem cert_e1211204308846 : check e1211204308846 [[],[]] .chain = true := by decide
def e1211204308858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e1211204308858 : Closed e1211204308858 ∧ code e1211204308858 = 5609250819962 := by decide
theorem cert_e1211204308858 : check e1211204308858 [[],[]] .chain = true := by decide
def e1211204308874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211204308874 : Closed e1211204308874 ∧ code e1211204308874 = 5609250819978 := by decide
theorem cert_e1211204308874 : check e1211204308874 [[],[]] .chain = true := by decide
def e1211204308910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 2))))))
theorem wire_e1211204308910 : Closed e1211204308910 ∧ code e1211204308910 = 5609250820014 := by decide
theorem cert_e1211204308910 : check e1211204308910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204308918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e1211204308918 : Closed e1211204308918 ∧ code e1211204308918 = 5609250820022 := by decide
theorem cert_e1211204308918 : check e1211204308918 [[],[]] .chain = true := by decide
def e1211204308922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e1211204308922 : Closed e1211204308922 ∧ code e1211204308922 = 5609250820026 := by decide
theorem cert_e1211204308922 : check e1211204308922 [[],[]] .chain = true := by decide
def e1211204309790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211204309790 : Closed e1211204309790 ∧ code e1211204309790 = 5609250820894 := by decide
theorem cert_e1211204309790 : check e1211204309790 [[],[]] .chain = true := by decide
def e1211204309958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211204309958 : Closed e1211204309958 ∧ code e1211204309958 = 5609250821062 := by decide
theorem cert_e1211204309958 : check e1211204309958 [[],[]] .chain = true := by decide
def e1211204311102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.lam (.var 4))))))))
theorem wire_e1211204311102 : Closed e1211204311102 ∧ code e1211204311102 = 5609250822206 := by decide
theorem cert_e1211204311102 : check e1211204311102 [[],[]] .chain = true := by decide
def e1211204311522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211204311522 : Closed e1211204311522 ∧ code e1211204311522 = 5609250822626 := by decide
theorem cert_e1211204311522 : check e1211204311522 [[],[]] .chain = true := by decide
def e1211204311534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211204311534 : Closed e1211204311534 ∧ code e1211204311534 = 5609250822638 := by decide
theorem cert_e1211204311534 : check e1211204311534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204312302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204312302 : Closed e1211204312302 ∧ code e1211204312302 = 5609250823406 := by decide
theorem cert_e1211204312302 : check e1211204312302 [[],[]] .chain = true := by decide
def e1211204312310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204312310 : Closed e1211204312310 ∧ code e1211204312310 = 5609250823414 := by decide
theorem cert_e1211204312310 : check e1211204312310 [[],[]] .chain = true := by decide
def e1211204312590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211204312590 : Closed e1211204312590 ∧ code e1211204312590 = 5609250823694 := by decide
theorem cert_e1211204312590 : check e1211204312590 [[],[]] .chain = true := by decide
def e1211204312602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211204312602 : Closed e1211204312602 ∧ code e1211204312602 = 5609250823706 := by decide
theorem cert_e1211204312602 : check e1211204312602 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204312674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211204312674 : Closed e1211204312674 ∧ code e1211204312674 = 5609250823778 := by decide
theorem cert_e1211204312674 : check e1211204312674 [[],[]] .chain = true := by decide
def e1211204312686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204312686 : Closed e1211204312686 ∧ code e1211204312686 = 5609250823790 := by decide
theorem cert_e1211204312686 : check e1211204312686 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204312694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204312694 : Closed e1211204312694 ∧ code e1211204312694 = 5609250823798 := by decide
theorem cert_e1211204312694 : check e1211204312694 [[],[]] .chain = true := by decide
def e1211204312698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204312698 : Closed e1211204312698 ∧ code e1211204312698 = 5609250823802 := by decide
theorem cert_e1211204312698 : check e1211204312698 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204316526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e1211204316526 : Closed e1211204316526 ∧ code e1211204316526 = 5609250827630 := by decide
theorem cert_e1211204316526 : check e1211204316526 [[],[]] .chain = true := by decide
def e1211204316534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211204316534 : Closed e1211204316534 ∧ code e1211204316534 = 5609250827638 := by decide
theorem cert_e1211204316534 : check e1211204316534 [[],[]] .chain = true := by decide
def e1211204316590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e1211204316590 : Closed e1211204316590 ∧ code e1211204316590 = 5609250827694 := by decide
theorem cert_e1211204316590 : check e1211204316590 [[],[]] .chain = true := by decide
def e1211204316602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211204316602 : Closed e1211204316602 ∧ code e1211204316602 = 5609250827706 := by decide
theorem cert_e1211204316602 : check e1211204316602 [[],[]] .chain = true := by decide
def e1211204316630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211204316630 : Closed e1211204316630 ∧ code e1211204316630 = 5609250827734 := by decide
theorem cert_e1211204316630 : check e1211204316630 [[],[]] .chain = true := by decide
def e1211204316634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211204316634 : Closed e1211204316634 ∧ code e1211204316634 = 5609250827738 := by decide
theorem cert_e1211204316634 : check e1211204316634 [[],[]] .chain = true := by decide
def e1211204316846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e1211204316846 : Closed e1211204316846 ∧ code e1211204316846 = 5609250827950 := by decide
theorem cert_e1211204316846 : check e1211204316846 [[],[]] .chain = true := by decide
def e1211204316858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211204316858 : Closed e1211204316858 ∧ code e1211204316858 = 5609250827962 := by decide
theorem cert_e1211204316858 : check e1211204316858 [[],[]] .chain = true := by decide
def e1211204316906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211204316906 : Closed e1211204316906 ∧ code e1211204316906 = 5609250828010 := by decide
theorem cert_e1211204316906 : check e1211204316906 [[],[]] .chain = true := by decide
def e1211204317014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211204317014 : Closed e1211204317014 ∧ code e1211204317014 = 5609250828118 := by decide
theorem cert_e1211204317014 : check e1211204317014 [[],[]] .chain = true := by decide
def e1211204317018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211204317018 : Closed e1211204317018 ∧ code e1211204317018 = 5609250828122 := by decide
theorem cert_e1211204317018 : check e1211204317018 [[],[]] .chain = true := by decide
def e1211204317034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211204317034 : Closed e1211204317034 ∧ code e1211204317034 = 5609250828138 := by decide
theorem cert_e1211204317034 : check e1211204317034 [[],[]] .chain = true := by decide
def e1211204317294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 2))))))
theorem wire_e1211204317294 : Closed e1211204317294 ∧ code e1211204317294 = 5609250828398 := by decide
theorem cert_e1211204317294 : check e1211204317294 [[],[]] .chain = true := by decide
def e1211204317470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 3)))))))
theorem wire_e1211204317470 : Closed e1211204317470 ∧ code e1211204317470 = 5609250828574 := by decide
theorem cert_e1211204317470 : check e1211204317470 [[],[]] .chain = true := by decide
def e1211204317666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.lam (.var 0)))))))
theorem wire_e1211204317666 : Closed e1211204317666 ∧ code e1211204317666 = 5609250828770 := by decide
theorem cert_e1211204317666 : check e1211204317666 [[],[]] .chain = true := by decide
def e1211204317678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211204317678 : Closed e1211204317678 ∧ code e1211204317678 = 5609250828782 := by decide
theorem cert_e1211204317678 : check e1211204317678 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204318062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211204318062 : Closed e1211204318062 ∧ code e1211204318062 = 5609250829166 := by decide
theorem cert_e1211204318062 : check e1211204318062 [[],[]] .chain = true := by decide
def e1211204318070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211204318070 : Closed e1211204318070 ∧ code e1211204318070 = 5609250829174 := by decide
theorem cert_e1211204318070 : check e1211204318070 [[],[]] .chain = true := by decide
def e1211204318126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211204318126 : Closed e1211204318126 ∧ code e1211204318126 = 5609250829230 := by decide
theorem cert_e1211204318126 : check e1211204318126 [[],[]] .chain = true := by decide
def e1211204318138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211204318138 : Closed e1211204318138 ∧ code e1211204318138 = 5609250829242 := by decide
theorem cert_e1211204318138 : check e1211204318138 [[],[]] .chain = true := by decide
def e1211204318166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211204318166 : Closed e1211204318166 ∧ code e1211204318166 = 5609250829270 := by decide
theorem cert_e1211204318166 : check e1211204318166 [[],[]] .chain = true := by decide
def e1211204318170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211204318170 : Closed e1211204318170 ∧ code e1211204318170 = 5609250829274 := by decide
theorem cert_e1211204318170 : check e1211204318170 [[],[]] .chain = true := by decide
def e1211204318446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204318446 : Closed e1211204318446 ∧ code e1211204318446 = 5609250829550 := by decide
theorem cert_e1211204318446 : check e1211204318446 [[],[]] .chain = true := by decide
def e1211204318454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204318454 : Closed e1211204318454 ∧ code e1211204318454 = 5609250829558 := by decide
theorem cert_e1211204318454 : check e1211204318454 [[],[]] .chain = true := by decide
def e1211204318830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204318830 : Closed e1211204318830 ∧ code e1211204318830 = 5609250829934 := by decide
theorem cert_e1211204318830 : check e1211204318830 [[],[]] .chain = true := by decide
def e1211204318842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204318842 : Closed e1211204318842 ∧ code e1211204318842 = 5609250829946 := by decide
theorem cert_e1211204318842 : check e1211204318842 [[],[]] .chain = true := by decide
def e1211204318982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204318982 : Closed e1211204318982 ∧ code e1211204318982 = 5609250830086 := by decide
theorem cert_e1211204318982 : check e1211204318982 [[],[]] .chain = true := by decide
def e1211204319006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211204319006 : Closed e1211204319006 ∧ code e1211204319006 = 5609250830110 := by decide
theorem cert_e1211204319006 : check e1211204319006 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204319030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204319030 : Closed e1211204319030 ∧ code e1211204319030 = 5609250830134 := by decide
theorem cert_e1211204319030 : check e1211204319030 [[],[]] .chain = true := by decide
def e1211204319034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204319034 : Closed e1211204319034 ∧ code e1211204319034 = 5609250830138 := by decide
theorem cert_e1211204319034 : check e1211204319034 [[],[]] .chain = true := by decide
def e1211204319278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211204319278 : Closed e1211204319278 ∧ code e1211204319278 = 5609250830382 := by decide
theorem cert_e1211204319278 : check e1211204319278 [[],[]] .chain = true := by decide
def e1211204319470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211204319470 : Closed e1211204319470 ∧ code e1211204319470 = 5609250830574 := by decide
theorem cert_e1211204319470 : check e1211204319470 [[],[]] .chain = true := by decide
def e1211204319478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211204319478 : Closed e1211204319478 ∧ code e1211204319478 = 5609250830582 := by decide
theorem cert_e1211204319478 : check e1211204319478 [[],[]] .chain = true := by decide
def e1211204319662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e1211204319662 : Closed e1211204319662 ∧ code e1211204319662 = 5609250830766 := by decide
theorem cert_e1211204319662 : check e1211204319662 [[],[]] .chain = true := by decide
def e1211204319674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211204319674 : Closed e1211204319674 ∧ code e1211204319674 = 5609250830778 := by decide
theorem cert_e1211204319674 : check e1211204319674 [[],[]] .chain = true := by decide
def e1211204319722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211204319722 : Closed e1211204319722 ∧ code e1211204319722 = 5609250830826 := by decide
theorem cert_e1211204319722 : check e1211204319722 [[],[]] .chain = true := by decide
def e1211204319854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204319854 : Closed e1211204319854 ∧ code e1211204319854 = 5609250830958 := by decide
theorem cert_e1211204319854 : check e1211204319854 [[],[]] .chain = true := by decide
def e1211204319866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204319866 : Closed e1211204319866 ∧ code e1211204319866 = 5609250830970 := by decide
theorem cert_e1211204319866 : check e1211204319866 [[],[]] .chain = true := by decide
def e1211204320030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211204320030 : Closed e1211204320030 ∧ code e1211204320030 = 5609250831134 := by decide
theorem cert_e1211204320030 : check e1211204320030 [[],[]] .chain = true := by decide
def e1211204320130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204320130 : Closed e1211204320130 ∧ code e1211204320130 = 5609250831234 := by decide
theorem cert_e1211204320130 : check e1211204320130 [[],[]] .chain = true := by decide
def e1211204320142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211204320142 : Closed e1211204320142 ∧ code e1211204320142 = 5609250831246 := by decide
theorem cert_e1211204320142 : check e1211204320142 [[],[]] .chain = true := by decide
def e1211204320154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204320154 : Closed e1211204320154 ∧ code e1211204320154 = 5609250831258 := by decide
theorem cert_e1211204320154 : check e1211204320154 [[],[]] .chain = true := by decide
def e1211204320278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211204320278 : Closed e1211204320278 ∧ code e1211204320278 = 5609250831382 := by decide
theorem cert_e1211204320278 : check e1211204320278 [[],[]] .chain = true := by decide
def e1211204320282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211204320282 : Closed e1211204320282 ∧ code e1211204320282 = 5609250831386 := by decide
theorem cert_e1211204320282 : check e1211204320282 [[],[]] .chain = true := by decide
def e1211204320326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211204320326 : Closed e1211204320326 ∧ code e1211204320326 = 5609250831430 := by decide
theorem cert_e1211204320326 : check e1211204320326 [[],[]] .chain = true := by decide
def e1211204320354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211204320354 : Closed e1211204320354 ∧ code e1211204320354 = 5609250831458 := by decide
theorem cert_e1211204320354 : check e1211204320354 [[],[]] .chain = true := by decide
def e1211204320366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211204320366 : Closed e1211204320366 ∧ code e1211204320366 = 5609250831470 := by decide
theorem cert_e1211204320366 : check e1211204320366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204320374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211204320374 : Closed e1211204320374 ∧ code e1211204320374 = 5609250831478 := by decide
theorem cert_e1211204320374 : check e1211204320374 [[],[]] .chain = true := by decide
def e1211204320378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211204320378 : Closed e1211204320378 ∧ code e1211204320378 = 5609250831482 := by decide
theorem cert_e1211204320378 : check e1211204320378 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204320470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211204320470 : Closed e1211204320470 ∧ code e1211204320470 = 5609250831574 := by decide
theorem cert_e1211204320470 : check e1211204320470 [[],[]] .chain = true := by decide
def e1211204320474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211204320474 : Closed e1211204320474 ∧ code e1211204320474 = 5609250831578 := by decide
theorem cert_e1211204320474 : check e1211204320474 [[],[]] .chain = true := by decide
def e1211204320490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211204320490 : Closed e1211204320490 ∧ code e1211204320490 = 5609250831594 := by decide
theorem cert_e1211204320490 : check e1211204320490 [[],[]] .chain = true := by decide
def e1211204320518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204320518 : Closed e1211204320518 ∧ code e1211204320518 = 5609250831622 := by decide
theorem cert_e1211204320518 : check e1211204320518 [[],[]] .chain = true := by decide
def e1211204320542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211204320542 : Closed e1211204320542 ∧ code e1211204320542 = 5609250831646 := by decide
theorem cert_e1211204320542 : check e1211204320542 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204320566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204320566 : Closed e1211204320566 ∧ code e1211204320566 = 5609250831670 := by decide
theorem cert_e1211204320566 : check e1211204320566 [[],[]] .chain = true := by decide
def e1211204320570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204320570 : Closed e1211204320570 ∧ code e1211204320570 = 5609250831674 := by decide
theorem cert_e1211204320570 : check e1211204320570 [[],[]] .chain = true := by decide
def e1211204320642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204320642 : Closed e1211204320642 ∧ code e1211204320642 = 5609250831746 := by decide
theorem cert_e1211204320642 : check e1211204320642 [[],[]] .chain = true := by decide
def e1211204320654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211204320654 : Closed e1211204320654 ∧ code e1211204320654 = 5609250831758 := by decide
theorem cert_e1211204320654 : check e1211204320654 [[],[]] .chain = true := by decide
def e1211204320666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204320666 : Closed e1211204320666 ∧ code e1211204320666 = 5609250831770 := by decide
theorem cert_e1211204320666 : check e1211204320666 [[],[]] .chain = true := by decide
def e1211204320710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211204320710 : Closed e1211204320710 ∧ code e1211204320710 = 5609250831814 := by decide
theorem cert_e1211204320710 : check e1211204320710 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204321406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211204321406 : Closed e1211204321406 ∧ code e1211204321406 = 5609250832510 := by decide
theorem cert_e1211204321406 : check e1211204321406 [[],[]] .chain = true := by decide
def e1211204322270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211204322270 : Closed e1211204322270 ∧ code e1211204322270 = 5609250833374 := by decide
theorem cert_e1211204322270 : check e1211204322270 [[],[]] .chain = true := by decide
def e1211204322274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211204322274 : Closed e1211204322274 ∧ code e1211204322274 = 5609250833378 := by decide
theorem cert_e1211204322274 : check e1211204322274 [[],[]] .chain = true := by decide
def e1211204322286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211204322286 : Closed e1211204322286 ∧ code e1211204322286 = 5609250833390 := by decide
theorem cert_e1211204322286 : check e1211204322286 [[],[]] .chain = true := by decide
def e1211204324206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211204324206 : Closed e1211204324206 ∧ code e1211204324206 = 5609250835310 := by decide
theorem cert_e1211204324206 : check e1211204324206 [[],[]] .chain = true := by decide
def e1211204324214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211204324214 : Closed e1211204324214 ∧ code e1211204324214 = 5609250835318 := by decide
theorem cert_e1211204324214 : check e1211204324214 [[],[]] .chain = true := by decide
def e1211204324270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211204324270 : Closed e1211204324270 ∧ code e1211204324270 = 5609250835374 := by decide
theorem cert_e1211204324270 : check e1211204324270 [[],[]] .chain = true := by decide
def e1211204324282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211204324282 : Closed e1211204324282 ∧ code e1211204324282 = 5609250835386 := by decide
theorem cert_e1211204324282 : check e1211204324282 [[],[]] .chain = true := by decide
def e1211204324310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211204324310 : Closed e1211204324310 ∧ code e1211204324310 = 5609250835414 := by decide
theorem cert_e1211204324310 : check e1211204324310 [[],[]] .chain = true := by decide
def e1211204324314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211204324314 : Closed e1211204324314 ∧ code e1211204324314 = 5609250835418 := by decide
theorem cert_e1211204324314 : check e1211204324314 [[],[]] .chain = true := by decide
def e1211204324590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204324590 : Closed e1211204324590 ∧ code e1211204324590 = 5609250835694 := by decide
theorem cert_e1211204324590 : check e1211204324590 [[],[]] .chain = true := by decide
def e1211204324598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204324598 : Closed e1211204324598 ∧ code e1211204324598 = 5609250835702 := by decide
theorem cert_e1211204324598 : check e1211204324598 [[],[]] .chain = true := by decide
def e1211204324974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204324974 : Closed e1211204324974 ∧ code e1211204324974 = 5609250836078 := by decide
theorem cert_e1211204324974 : check e1211204324974 [[],[]] .chain = true := by decide
def e1211204324986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204324986 : Closed e1211204324986 ∧ code e1211204324986 = 5609250836090 := by decide
theorem cert_e1211204324986 : check e1211204324986 [[],[]] .chain = true := by decide
def e1211204325126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204325126 : Closed e1211204325126 ∧ code e1211204325126 = 5609250836230 := by decide
theorem cert_e1211204325126 : check e1211204325126 [[],[]] .chain = true := by decide
def e1211204325150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211204325150 : Closed e1211204325150 ∧ code e1211204325150 = 5609250836254 := by decide
theorem cert_e1211204325150 : check e1211204325150 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204325174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204325174 : Closed e1211204325174 ∧ code e1211204325174 = 5609250836278 := by decide
theorem cert_e1211204325174 : check e1211204325174 [[],[]] .chain = true := by decide
def e1211204325178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204325178 : Closed e1211204325178 ∧ code e1211204325178 = 5609250836282 := by decide
theorem cert_e1211204325178 : check e1211204325178 [[],[]] .chain = true := by decide
def e1211204329950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211204329950 : Closed e1211204329950 ∧ code e1211204329950 = 5609250841054 := by decide
theorem cert_e1211204329950 : check e1211204329950 [[],[]] .chain = true := by decide
def e1211204329974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211204329974 : Closed e1211204329974 ∧ code e1211204329974 = 5609250841078 := by decide
theorem cert_e1211204329974 : check e1211204329974 [[],[]] .chain = true := by decide
def e1211204330926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211204330926 : Closed e1211204330926 ∧ code e1211204330926 = 5609250842030 := by decide
theorem cert_e1211204330926 : check e1211204330926 [[],[]] .chain = true := by decide
def e1211204330938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211204330938 : Closed e1211204330938 ∧ code e1211204330938 = 5609250842042 := by decide
theorem cert_e1211204330938 : check e1211204330938 [[],[]] .chain = true := by decide
def e1211204330986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211204330986 : Closed e1211204330986 ∧ code e1211204330986 = 5609250842090 := by decide
theorem cert_e1211204330986 : check e1211204330986 [[],[]] .chain = true := by decide
def e1211204331118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204331118 : Closed e1211204331118 ∧ code e1211204331118 = 5609250842222 := by decide
theorem cert_e1211204331118 : check e1211204331118 [[],[]] .chain = true := by decide
end Blc.Floor42
