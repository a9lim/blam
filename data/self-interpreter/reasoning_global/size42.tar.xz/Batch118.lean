import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205862579566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205862579566 : Closed e1205862579566 ∧ code e1205862579566 = 5603909090670 := by decide
theorem cert_e1205862579566 : check e1205862579566 [[],[],[]] .smaller = true := by decide
def e1205862579574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205862579574 : Closed e1205862579574 ∧ code e1205862579574 = 5603909090678 := by decide
theorem cert_e1205862579574 : check e1205862579574 [[],[],[]] .smaller = true := by decide
def e1205862579594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205862579594 : Closed e1205862579594 ∧ code e1205862579594 = 5603909090698 := by decide
theorem cert_e1205862579594 : check e1205862579594 [[],[],[]] .smaller = true := by decide
def e1205862579618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205862579618 : Closed e1205862579618 ∧ code e1205862579618 = 5603909090722 := by decide
theorem cert_e1205862579618 : check e1205862579618 [[],[],[]] .smaller = true := by decide
def e1205862579630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205862579630 : Closed e1205862579630 ∧ code e1205862579630 = 5603909090734 := by decide
theorem cert_e1205862579630 : check e1205862579630 [[],[],[]] .smaller = true := by decide
def e1205862579642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205862579642 : Closed e1205862579642 ∧ code e1205862579642 = 5603909090746 := by decide
theorem cert_e1205862579642 : check e1205862579642 [[],[],[]] .smaller = true := by decide
def e1205862579670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205862579670 : Closed e1205862579670 ∧ code e1205862579670 = 5603909090774 := by decide
theorem cert_e1205862579670 : check e1205862579670 [[],[],[]] .smaller = true := by decide
def e1205862579674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205862579674 : Closed e1205862579674 ∧ code e1205862579674 = 5603909090778 := by decide
theorem cert_e1205862579674 : check e1205862579674 [[],[],[]] .smaller = true := by decide
def e1205862580718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1205862580718 : Closed e1205862580718 ∧ code e1205862580718 = 5603909091822 := by decide
theorem cert_e1205862580718 : check e1205862580718 [[],[],[]] .smaller = true := by decide
def e1205862580726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1205862580726 : Closed e1205862580726 ∧ code e1205862580726 = 5603909091830 := by decide
theorem cert_e1205862580726 : check e1205862580726 [[],[],[]] .smaller = true := by decide
def e1205862581486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205862581486 : Closed e1205862581486 ∧ code e1205862581486 = 5603909092590 := by decide
theorem cert_e1205862581486 : check e1205862581486 [[],[],[]] .smaller = true := by decide
def e1205862581494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205862581494 : Closed e1205862581494 ∧ code e1205862581494 = 5603909092598 := by decide
theorem cert_e1205862581494 : check e1205862581494 [[],[],[]] .smaller = true := by decide
def e1205862582046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e1205862582046 : Closed e1205862582046 ∧ code e1205862582046 = 5603909093150 := by decide
theorem cert_e1205862582046 : check e1205862582046 [[],[],[]] .smaller = true := by decide
def e1205862582158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e1205862582158 : Closed e1205862582158 ∧ code e1205862582158 = 5603909093262 := by decide
theorem cert_e1205862582158 : check e1205862582158 [[],[],[]] .smaller = true := by decide
def e1205862583854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205862583854 : Closed e1205862583854 ∧ code e1205862583854 = 5603909094958 := by decide
theorem cert_e1205862583854 : check e1205862583854 [[],[],[]] .smaller = true := by decide
def e1205862584034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205862584034 : Closed e1205862584034 ∧ code e1205862584034 = 5603909095138 := by decide
theorem cert_e1205862584034 : check e1205862584034 [[],[],[]] .smaller = true := by decide
def e1205862584046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e1205862584046 : Closed e1205862584046 ∧ code e1205862584046 = 5603909095150 := by decide
theorem cert_e1205862584046 : check e1205862584046 [[],[],[]] .smaller = true := by decide
def e1205862584086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205862584086 : Closed e1205862584086 ∧ code e1205862584086 = 5603909095190 := by decide
theorem cert_e1205862584086 : check e1205862584086 [[],[],[]] .smaller = true := by decide
def e1205862584162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205862584162 : Closed e1205862584162 ∧ code e1205862584162 = 5603909095266 := by decide
theorem cert_e1205862584162 : check e1205862584162 [[],[],[]] .smaller = true := by decide
def e1205862584174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e1205862584174 : Closed e1205862584174 ∧ code e1205862584174 = 5603909095278 := by decide
theorem cert_e1205862584174 : check e1205862584174 [[],[],[]] .smaller = true := by decide
def e1205862584182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e1205862584182 : Closed e1205862584182 ∧ code e1205862584182 = 5603909095286 := by decide
theorem cert_e1205862584182 : check e1205862584182 [[],[],[]] .smaller = true := by decide
def e1205862586430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205862586430 : Closed e1205862586430 ∧ code e1205862586430 = 5603909097534 := by decide
theorem cert_e1205862586430 : check e1205862586430 [[],[],[]] .smaller = true := by decide
def e1205862586850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205862586850 : Closed e1205862586850 ∧ code e1205862586850 = 5603909097954 := by decide
theorem cert_e1205862586850 : check e1205862586850 [[],[],[]] .smaller = true := by decide
def e1205862586862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205862586862 : Closed e1205862586862 ∧ code e1205862586862 = 5603909097966 := by decide
theorem cert_e1205862586862 : check e1205862586862 [[],[],[]] .smaller = true := by decide
def e1205862587422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205862587422 : Closed e1205862587422 ∧ code e1205862587422 = 5603909098526 := by decide
theorem cert_e1205862587422 : check e1205862587422 [[],[],[]] .smaller = true := by decide
def e1205862587618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205862587618 : Closed e1205862587618 ∧ code e1205862587618 = 5603909098722 := by decide
theorem cert_e1205862587618 : check e1205862587618 [[],[],[]] .smaller = true := by decide
def e1205862587630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205862587630 : Closed e1205862587630 ∧ code e1205862587630 = 5603909098734 := by decide
theorem cert_e1205862587630 : check e1205862587630 [[],[],[]] .smaller = true := by decide
def e1205862587638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205862587638 : Closed e1205862587638 ∧ code e1205862587638 = 5603909098742 := by decide
theorem cert_e1205862587638 : check e1205862587638 [[],[],[]] .smaller = true := by decide
def e1205862588654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205862588654 : Closed e1205862588654 ∧ code e1205862588654 = 5603909099758 := by decide
theorem cert_e1205862588654 : check e1205862588654 [[],[],[]] .smaller = true := by decide
def e1205862588666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205862588666 : Closed e1205862588666 ∧ code e1205862588666 = 5603909099770 := by decide
theorem cert_e1205862588666 : check e1205862588666 [[],[],[]] .smaller = true := by decide
def e1205862589038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205862589038 : Closed e1205862589038 ∧ code e1205862589038 = 5603909100142 := by decide
theorem cert_e1205862589038 : check e1205862589038 [[],[],[]] .smaller = true := by decide
def e1205862589050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205862589050 : Closed e1205862589050 ∧ code e1205862589050 = 5603909100154 := by decide
theorem cert_e1205862589050 : check e1205862589050 [[],[],[]] .smaller = true := by decide
def e1205862589214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205862589214 : Closed e1205862589214 ∧ code e1205862589214 = 5603909100318 := by decide
theorem cert_e1205862589214 : check e1205862589214 [[],[],[]] .smaller = true := by decide
def e1205862589382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205862589382 : Closed e1205862589382 ∧ code e1205862589382 = 5603909100486 := by decide
theorem cert_e1205862589382 : check e1205862589382 [[],[],[]] .smaller = true := by decide
def e1205862589998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205862589998 : Closed e1205862589998 ∧ code e1205862589998 = 5603909101102 := by decide
theorem cert_e1205862589998 : check e1205862589998 [[],[],[]] .smaller = true := by decide
def e1205862590178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205862590178 : Closed e1205862590178 ∧ code e1205862590178 = 5603909101282 := by decide
theorem cert_e1205862590178 : check e1205862590178 [[],[],[]] .smaller = true := by decide
def e1205862590190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1205862590190 : Closed e1205862590190 ∧ code e1205862590190 = 5603909101294 := by decide
theorem cert_e1205862590190 : check e1205862590190 [[],[],[]] .smaller = true := by decide
def e1205862590346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205862590346 : Closed e1205862590346 ∧ code e1205862590346 = 5603909101450 := by decide
theorem cert_e1205862590346 : check e1205862590346 [[],[],[]] .smaller = true := by decide
def e1205862590370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205862590370 : Closed e1205862590370 ∧ code e1205862590370 = 5603909101474 := by decide
theorem cert_e1205862590370 : check e1205862590370 [[],[],[]] .smaller = true := by decide
def e1205862590382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1205862590382 : Closed e1205862590382 ∧ code e1205862590382 = 5603909101486 := by decide
theorem cert_e1205862590382 : check e1205862590382 [[],[],[]] .smaller = true := by decide
def e1205862590394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1205862590394 : Closed e1205862590394 ∧ code e1205862590394 = 5603909101498 := by decide
theorem cert_e1205862590394 : check e1205862590394 [[],[],[]] .smaller = true := by decide
def e1205862590526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205862590526 : Closed e1205862590526 ∧ code e1205862590526 = 5603909101630 := by decide
theorem cert_e1205862590526 : check e1205862590526 [[],[],[]] .smaller = true := by decide
def e1205862590946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205862590946 : Closed e1205862590946 ∧ code e1205862590946 = 5603909102050 := by decide
theorem cert_e1205862590946 : check e1205862590946 [[],[],[]] .smaller = true := by decide
def e1205862590958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205862590958 : Closed e1205862590958 ∧ code e1205862590958 = 5603909102062 := by decide
theorem cert_e1205862590958 : check e1205862590958 [[],[],[]] .smaller = true := by decide
def e1205862592014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205862592014 : Closed e1205862592014 ∧ code e1205862592014 = 5603909103118 := by decide
theorem cert_e1205862592014 : check e1205862592014 [[],[],[]] .smaller = true := by decide
def e1205862592098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205862592098 : Closed e1205862592098 ∧ code e1205862592098 = 5603909103202 := by decide
theorem cert_e1205862592098 : check e1205862592098 [[],[],[]] .smaller = true := by decide
def e1205862592110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205862592110 : Closed e1205862592110 ∧ code e1205862592110 = 5603909103214 := by decide
theorem cert_e1205862592110 : check e1205862592110 [[],[],[]] .smaller = true := by decide
def e1205862592122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205862592122 : Closed e1205862592122 ∧ code e1205862592122 = 5603909103226 := by decide
theorem cert_e1205862592122 : check e1205862592122 [[],[],[]] .smaller = true := by decide
def e1205862592630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205862592630 : Closed e1205862592630 ∧ code e1205862592630 = 5603909103734 := by decide
theorem cert_e1205862592630 : check e1205862592630 [[],[],[]] .smaller = true := by decide
def e1205862592634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1205862592634 : Closed e1205862592634 ∧ code e1205862592634 = 5603909103738 := by decide
theorem cert_e1205862592634 : check e1205862592634 [[],[],[]] .smaller = true := by decide
def e1205862592822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205862592822 : Closed e1205862592822 ∧ code e1205862592822 = 5603909103926 := by decide
theorem cert_e1205862592822 : check e1205862592822 [[],[],[]] .smaller = true := by decide
def e1205862592826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205862592826 : Closed e1205862592826 ∧ code e1205862592826 = 5603909103930 := by decide
theorem cert_e1205862592826 : check e1205862592826 [[],[],[]] .smaller = true := by decide
def e1205862592910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205862592910 : Closed e1205862592910 ∧ code e1205862592910 = 5603909104014 := by decide
theorem cert_e1205862592910 : check e1205862592910 [[],[],[]] .smaller = true := by decide
def e1205862592966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1205862592966 : Closed e1205862592966 ∧ code e1205862592966 = 5603909104070 := by decide
theorem cert_e1205862592966 : check e1205862592966 [[],[],[]] .smaller = true := by decide
def e1205862593302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205862593302 : Closed e1205862593302 ∧ code e1205862593302 = 5603909104406 := by decide
theorem cert_e1205862593302 : check e1205862593302 [[],[],[]] .smaller = true := by decide
def e1205862593378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205862593378 : Closed e1205862593378 ∧ code e1205862593378 = 5603909104482 := by decide
theorem cert_e1205862593378 : check e1205862593378 [[],[],[]] .smaller = true := by decide
def e1205862593390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205862593390 : Closed e1205862593390 ∧ code e1205862593390 = 5603909104494 := by decide
theorem cert_e1205862593390 : check e1205862593390 [[],[],[]] .smaller = true := by decide
def e1205862593398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205862593398 : Closed e1205862593398 ∧ code e1205862593398 = 5603909104502 := by decide
theorem cert_e1205862593398 : check e1205862593398 [[],[],[]] .smaller = true := by decide
def e1205862593418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205862593418 : Closed e1205862593418 ∧ code e1205862593418 = 5603909104522 := by decide
theorem cert_e1205862593418 : check e1205862593418 [[],[],[]] .smaller = true := by decide
def e1205862593442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205862593442 : Closed e1205862593442 ∧ code e1205862593442 = 5603909104546 := by decide
theorem cert_e1205862593442 : check e1205862593442 [[],[],[]] .smaller = true := by decide
def e1205862593454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205862593454 : Closed e1205862593454 ∧ code e1205862593454 = 5603909104558 := by decide
theorem cert_e1205862593454 : check e1205862593454 [[],[],[]] .smaller = true := by decide
def e1205862593466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205862593466 : Closed e1205862593466 ∧ code e1205862593466 = 5603909104570 := by decide
theorem cert_e1205862593466 : check e1205862593466 [[],[],[]] .smaller = true := by decide
def e1205862593494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205862593494 : Closed e1205862593494 ∧ code e1205862593494 = 5603909104598 := by decide
theorem cert_e1205862593494 : check e1205862593494 [[],[],[]] .smaller = true := by decide
def e1205862593498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205862593498 : Closed e1205862593498 ∧ code e1205862593498 = 5603909104602 := by decide
theorem cert_e1205862593498 : check e1205862593498 [[],[],[]] .smaller = true := by decide
def e1205862593566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205862593566 : Closed e1205862593566 ∧ code e1205862593566 = 5603909104670 := by decide
theorem cert_e1205862593566 : check e1205862593566 [[],[],[]] .smaller = true := by decide
def e1205862593762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205862593762 : Closed e1205862593762 ∧ code e1205862593762 = 5603909104866 := by decide
theorem cert_e1205862593762 : check e1205862593762 [[],[],[]] .smaller = true := by decide
def e1205862593774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205862593774 : Closed e1205862593774 ∧ code e1205862593774 = 5603909104878 := by decide
theorem cert_e1205862593774 : check e1205862593774 [[],[],[]] .smaller = true := by decide
def e1205862593782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205862593782 : Closed e1205862593782 ∧ code e1205862593782 = 5603909104886 := by decide
theorem cert_e1205862593782 : check e1205862593782 [[],[],[]] .smaller = true := by decide
def e1205862594062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205862594062 : Closed e1205862594062 ∧ code e1205862594062 = 5603909105166 := by decide
theorem cert_e1205862594062 : check e1205862594062 [[],[],[]] .smaller = true := by decide
def e1205862594146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205862594146 : Closed e1205862594146 ∧ code e1205862594146 = 5603909105250 := by decide
theorem cert_e1205862594146 : check e1205862594146 [[],[],[]] .smaller = true := by decide
def e1205862594158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205862594158 : Closed e1205862594158 ∧ code e1205862594158 = 5603909105262 := by decide
theorem cert_e1205862594158 : check e1205862594158 [[],[],[]] .smaller = true := by decide
def e1205862594170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205862594170 : Closed e1205862594170 ∧ code e1205862594170 = 5603909105274 := by decide
theorem cert_e1205862594170 : check e1205862594170 [[],[],[]] .smaller = true := by decide
def e1205862594358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205862594358 : Closed e1205862594358 ∧ code e1205862594358 = 5603909105462 := by decide
theorem cert_e1205862594358 : check e1205862594358 [[],[],[]] .smaller = true := by decide
def e1205862594362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205862594362 : Closed e1205862594362 ∧ code e1205862594362 = 5603909105466 := by decide
theorem cert_e1205862594362 : check e1205862594362 [[],[],[]] .smaller = true := by decide
def e1205862599534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205862599534 : Closed e1205862599534 ∧ code e1205862599534 = 5603909110638 := by decide
theorem cert_e1205862599534 : check e1205862599534 [[],[],[]] .smaller = true := by decide
def e1205862599542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205862599542 : Closed e1205862599542 ∧ code e1205862599542 = 5603909110646 := by decide
theorem cert_e1205862599542 : check e1205862599542 [[],[],[]] .smaller = true := by decide
def e1205862599598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205862599598 : Closed e1205862599598 ∧ code e1205862599598 = 5603909110702 := by decide
theorem cert_e1205862599598 : check e1205862599598 [[],[],[]] .smaller = true := by decide
def e1205862599610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205862599610 : Closed e1205862599610 ∧ code e1205862599610 = 5603909110714 := by decide
theorem cert_e1205862599610 : check e1205862599610 [[],[],[]] .smaller = true := by decide
def e1205862599638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205862599638 : Closed e1205862599638 ∧ code e1205862599638 = 5603909110742 := by decide
theorem cert_e1205862599638 : check e1205862599638 [[],[],[]] .smaller = true := by decide
def e1205862599642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205862599642 : Closed e1205862599642 ∧ code e1205862599642 = 5603909110746 := by decide
theorem cert_e1205862599642 : check e1205862599642 [[],[],[]] .smaller = true := by decide
def e1205862599918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205862599918 : Closed e1205862599918 ∧ code e1205862599918 = 5603909111022 := by decide
theorem cert_e1205862599918 : check e1205862599918 [[],[],[]] .smaller = true := by decide
def e1205862599926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205862599926 : Closed e1205862599926 ∧ code e1205862599926 = 5603909111030 := by decide
theorem cert_e1205862599926 : check e1205862599926 [[],[],[]] .smaller = true := by decide
def e1205862600302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205862600302 : Closed e1205862600302 ∧ code e1205862600302 = 5603909111406 := by decide
theorem cert_e1205862600302 : check e1205862600302 [[],[],[]] .smaller = true := by decide
def e1205862600314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205862600314 : Closed e1205862600314 ∧ code e1205862600314 = 5603909111418 := by decide
theorem cert_e1205862600314 : check e1205862600314 [[],[],[]] .smaller = true := by decide
def e1205862600502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205862600502 : Closed e1205862600502 ∧ code e1205862600502 = 5603909111606 := by decide
theorem cert_e1205862600502 : check e1205862600502 [[],[],[]] .smaller = true := by decide
def e1205862600506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205862600506 : Closed e1205862600506 ∧ code e1205862600506 = 5603909111610 := by decide
theorem cert_e1205862600506 : check e1205862600506 [[],[],[]] .smaller = true := by decide
def e1205862608430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205862608430 : Closed e1205862608430 ∧ code e1205862608430 = 5603909119534 := by decide
theorem cert_e1205862608430 : check e1205862608430 [[],[],[]] .smaller = true := by decide
def e1205862608610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205862608610 : Closed e1205862608610 ∧ code e1205862608610 = 5603909119714 := by decide
theorem cert_e1205862608610 : check e1205862608610 [[],[],[]] .smaller = true := by decide
def e1205862608622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1205862608622 : Closed e1205862608622 ∧ code e1205862608622 = 5603909119726 := by decide
theorem cert_e1205862608622 : check e1205862608622 [[],[],[]] .smaller = true := by decide
def e1205862608662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205862608662 : Closed e1205862608662 ∧ code e1205862608662 = 5603909119766 := by decide
theorem cert_e1205862608662 : check e1205862608662 [[],[],[]] .smaller = true := by decide
def e1205862608738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205862608738 : Closed e1205862608738 ∧ code e1205862608738 = 5603909119842 := by decide
theorem cert_e1205862608738 : check e1205862608738 [[],[],[]] .smaller = true := by decide
def e1205862608750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1205862608750 : Closed e1205862608750 ∧ code e1205862608750 = 5603909119854 := by decide
theorem cert_e1205862608750 : check e1205862608750 [[],[],[]] .smaller = true := by decide
def e1205862608758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1205862608758 : Closed e1205862608758 ∧ code e1205862608758 = 5603909119862 := by decide
theorem cert_e1205862608758 : check e1205862608758 [[],[],[]] .smaller = true := by decide
def e1205862611006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e1205862611006 : Closed e1205862611006 ∧ code e1205862611006 = 5603909122110 := by decide
theorem cert_e1205862611006 : check e1205862611006 [[],[],[]] .smaller = true := by decide
def e1205862611426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205862611426 : Closed e1205862611426 ∧ code e1205862611426 = 5603909122530 := by decide
theorem cert_e1205862611426 : check e1205862611426 [[],[],[]] .smaller = true := by decide
def e1205862611438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205862611438 : Closed e1205862611438 ∧ code e1205862611438 = 5603909122542 := by decide
theorem cert_e1205862611438 : check e1205862611438 [[],[],[]] .smaller = true := by decide
def e1205862611998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e1205862611998 : Closed e1205862611998 ∧ code e1205862611998 = 5603909123102 := by decide
theorem cert_e1205862611998 : check e1205862611998 [[],[],[]] .smaller = true := by decide
def e1205862612194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205862612194 : Closed e1205862612194 ∧ code e1205862612194 = 5603909123298 := by decide
theorem cert_e1205862612194 : check e1205862612194 [[],[],[]] .smaller = true := by decide
def e1205862612206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205862612206 : Closed e1205862612206 ∧ code e1205862612206 = 5603909123310 := by decide
theorem cert_e1205862612206 : check e1205862612206 [[],[],[]] .smaller = true := by decide
def e1205862612214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205862612214 : Closed e1205862612214 ∧ code e1205862612214 = 5603909123318 := by decide
theorem cert_e1205862612214 : check e1205862612214 [[],[],[]] .smaller = true := by decide
def e1205862635054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205862635054 : Closed e1205862635054 ∧ code e1205862635054 = 5603909146158 := by decide
theorem cert_e1205862635054 : check e1205862635054 [[],[],[]] .smaller = true := by decide
def e1205862635234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205862635234 : Closed e1205862635234 ∧ code e1205862635234 = 5603909146338 := by decide
theorem cert_e1205862635234 : check e1205862635234 [[],[],[]] .smaller = true := by decide
def e1205862635246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1205862635246 : Closed e1205862635246 ∧ code e1205862635246 = 5603909146350 := by decide
theorem cert_e1205862635246 : check e1205862635246 [[],[],[]] .smaller = true := by decide
def e1205862635402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205862635402 : Closed e1205862635402 ∧ code e1205862635402 = 5603909146506 := by decide
theorem cert_e1205862635402 : check e1205862635402 [[],[],[]] .smaller = true := by decide
def e1205862635426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205862635426 : Closed e1205862635426 ∧ code e1205862635426 = 5603909146530 := by decide
theorem cert_e1205862635426 : check e1205862635426 [[],[],[]] .smaller = true := by decide
def e1205862635438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1205862635438 : Closed e1205862635438 ∧ code e1205862635438 = 5603909146542 := by decide
theorem cert_e1205862635438 : check e1205862635438 [[],[],[]] .smaller = true := by decide
def e1205862635450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1205862635450 : Closed e1205862635450 ∧ code e1205862635450 = 5603909146554 := by decide
theorem cert_e1205862635450 : check e1205862635450 [[],[],[]] .smaller = true := by decide
def e1205862635582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e1205862635582 : Closed e1205862635582 ∧ code e1205862635582 = 5603909146686 := by decide
theorem cert_e1205862635582 : check e1205862635582 [[],[],[]] .smaller = true := by decide
def e1205862636002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205862636002 : Closed e1205862636002 ∧ code e1205862636002 = 5603909147106 := by decide
theorem cert_e1205862636002 : check e1205862636002 [[],[],[]] .smaller = true := by decide
def e1205862636014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205862636014 : Closed e1205862636014 ∧ code e1205862636014 = 5603909147118 := by decide
theorem cert_e1205862636014 : check e1205862636014 [[],[],[]] .smaller = true := by decide
def e1205862637070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e1205862637070 : Closed e1205862637070 ∧ code e1205862637070 = 5603909148174 := by decide
theorem cert_e1205862637070 : check e1205862637070 [[],[],[]] .smaller = true := by decide
def e1205862637154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205862637154 : Closed e1205862637154 ∧ code e1205862637154 = 5603909148258 := by decide
theorem cert_e1205862637154 : check e1205862637154 [[],[],[]] .smaller = true := by decide
def e1205862637166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205862637166 : Closed e1205862637166 ∧ code e1205862637166 = 5603909148270 := by decide
theorem cert_e1205862637166 : check e1205862637166 [[],[],[]] .smaller = true := by decide
def e1205862637178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205862637178 : Closed e1205862637178 ∧ code e1205862637178 = 5603909148282 := by decide
theorem cert_e1205862637178 : check e1205862637178 [[],[],[]] .smaller = true := by decide
def e1205862648598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205862648598 : Closed e1205862648598 ∧ code e1205862648598 = 5603909159702 := by decide
theorem cert_e1205862648598 : check e1205862648598 [[],[],[]] .smaller = true := by decide
def e1205862648674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205862648674 : Closed e1205862648674 ∧ code e1205862648674 = 5603909159778 := by decide
theorem cert_e1205862648674 : check e1205862648674 [[],[],[]] .smaller = true := by decide
def e1205862648686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205862648686 : Closed e1205862648686 ∧ code e1205862648686 = 5603909159790 := by decide
theorem cert_e1205862648686 : check e1205862648686 [[],[],[]] .smaller = true := by decide
def e1205862648694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205862648694 : Closed e1205862648694 ∧ code e1205862648694 = 5603909159798 := by decide
theorem cert_e1205862648694 : check e1205862648694 [[],[],[]] .smaller = true := by decide
def e1205862648714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205862648714 : Closed e1205862648714 ∧ code e1205862648714 = 5603909159818 := by decide
theorem cert_e1205862648714 : check e1205862648714 [[],[],[]] .smaller = true := by decide
def e1205862648738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205862648738 : Closed e1205862648738 ∧ code e1205862648738 = 5603909159842 := by decide
theorem cert_e1205862648738 : check e1205862648738 [[],[],[]] .smaller = true := by decide
def e1205862648750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205862648750 : Closed e1205862648750 ∧ code e1205862648750 = 5603909159854 := by decide
theorem cert_e1205862648750 : check e1205862648750 [[],[],[]] .smaller = true := by decide
def e1205862648762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205862648762 : Closed e1205862648762 ∧ code e1205862648762 = 5603909159866 := by decide
theorem cert_e1205862648762 : check e1205862648762 [[],[],[]] .smaller = true := by decide
def e1205862648790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205862648790 : Closed e1205862648790 ∧ code e1205862648790 = 5603909159894 := by decide
theorem cert_e1205862648790 : check e1205862648790 [[],[],[]] .smaller = true := by decide
def e1205862648794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205862648794 : Closed e1205862648794 ∧ code e1205862648794 = 5603909159898 := by decide
theorem cert_e1205862648794 : check e1205862648794 [[],[],[]] .smaller = true := by decide
def e1205862648862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1205862648862 : Closed e1205862648862 ∧ code e1205862648862 = 5603909159966 := by decide
theorem cert_e1205862648862 : check e1205862648862 [[],[],[]] .smaller = true := by decide
def e1205862649058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205862649058 : Closed e1205862649058 ∧ code e1205862649058 = 5603909160162 := by decide
theorem cert_e1205862649058 : check e1205862649058 [[],[],[]] .smaller = true := by decide
def e1205862649070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205862649070 : Closed e1205862649070 ∧ code e1205862649070 = 5603909160174 := by decide
theorem cert_e1205862649070 : check e1205862649070 [[],[],[]] .smaller = true := by decide
def e1205862649078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205862649078 : Closed e1205862649078 ∧ code e1205862649078 = 5603909160182 := by decide
theorem cert_e1205862649078 : check e1205862649078 [[],[],[]] .smaller = true := by decide
def e1205862649358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1205862649358 : Closed e1205862649358 ∧ code e1205862649358 = 5603909160462 := by decide
theorem cert_e1205862649358 : check e1205862649358 [[],[],[]] .smaller = true := by decide
def e1205862649442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205862649442 : Closed e1205862649442 ∧ code e1205862649442 = 5603909160546 := by decide
theorem cert_e1205862649442 : check e1205862649442 [[],[],[]] .smaller = true := by decide
def e1205862649454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205862649454 : Closed e1205862649454 ∧ code e1205862649454 = 5603909160558 := by decide
theorem cert_e1205862649454 : check e1205862649454 [[],[],[]] .smaller = true := by decide
def e1205862649466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205862649466 : Closed e1205862649466 ∧ code e1205862649466 = 5603909160570 := by decide
theorem cert_e1205862649466 : check e1205862649466 [[],[],[]] .smaller = true := by decide
def e1205862649654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205862649654 : Closed e1205862649654 ∧ code e1205862649654 = 5603909160758 := by decide
theorem cert_e1205862649654 : check e1205862649654 [[],[],[]] .smaller = true := by decide
def e1205862649658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205862649658 : Closed e1205862649658 ∧ code e1205862649658 = 5603909160762 := by decide
theorem cert_e1205862649658 : check e1205862649658 [[],[],[]] .smaller = true := by decide
def e1205863189358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205863189358 : Closed e1205863189358 ∧ code e1205863189358 = 5603909700462 := by decide
theorem cert_e1205863189358 : check e1205863189358 [[],[],[]] .smaller = true := by decide
def e1205863189366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205863189366 : Closed e1205863189366 ∧ code e1205863189366 = 5603909700470 := by decide
theorem cert_e1205863189366 : check e1205863189366 [[],[],[]] .smaller = true := by decide
def e1205863189422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205863189422 : Closed e1205863189422 ∧ code e1205863189422 = 5603909700526 := by decide
theorem cert_e1205863189422 : check e1205863189422 [[],[],[]] .smaller = true := by decide
def e1205863189434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205863189434 : Closed e1205863189434 ∧ code e1205863189434 = 5603909700538 := by decide
theorem cert_e1205863189434 : check e1205863189434 [[],[],[]] .smaller = true := by decide
def e1205863189462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205863189462 : Closed e1205863189462 ∧ code e1205863189462 = 5603909700566 := by decide
theorem cert_e1205863189462 : check e1205863189462 [[],[],[]] .smaller = true := by decide
def e1205863189466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205863189466 : Closed e1205863189466 ∧ code e1205863189466 = 5603909700570 := by decide
theorem cert_e1205863189466 : check e1205863189466 [[],[],[]] .smaller = true := by decide
def e1205863189742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205863189742 : Closed e1205863189742 ∧ code e1205863189742 = 5603909700846 := by decide
theorem cert_e1205863189742 : check e1205863189742 [[],[],[]] .smaller = true := by decide
def e1205863189750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205863189750 : Closed e1205863189750 ∧ code e1205863189750 = 5603909700854 := by decide
theorem cert_e1205863189750 : check e1205863189750 [[],[],[]] .smaller = true := by decide
def e1205863190126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205863190126 : Closed e1205863190126 ∧ code e1205863190126 = 5603909701230 := by decide
theorem cert_e1205863190126 : check e1205863190126 [[],[],[]] .smaller = true := by decide
def e1205863190138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205863190138 : Closed e1205863190138 ∧ code e1205863190138 = 5603909701242 := by decide
theorem cert_e1205863190138 : check e1205863190138 [[],[],[]] .smaller = true := by decide
def e1205863190326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205863190326 : Closed e1205863190326 ∧ code e1205863190326 = 5603909701430 := by decide
theorem cert_e1205863190326 : check e1205863190326 [[],[],[]] .smaller = true := by decide
def e1205863190330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205863190330 : Closed e1205863190330 ∧ code e1205863190330 = 5603909701434 := by decide
theorem cert_e1205863190330 : check e1205863190330 [[],[],[]] .smaller = true := by decide
def e1205865548654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205865548654 : Closed e1205865548654 ∧ code e1205865548654 = 5603912059758 := by decide
theorem cert_e1205865548654 : check e1205865548654 [[],[],[]] .smaller = true := by decide
def e1205865548662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205865548662 : Closed e1205865548662 ∧ code e1205865548662 = 5603912059766 := by decide
theorem cert_e1205865548662 : check e1205865548662 [[],[],[]] .smaller = true := by decide
def e1205865548718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205865548718 : Closed e1205865548718 ∧ code e1205865548718 = 5603912059822 := by decide
theorem cert_e1205865548718 : check e1205865548718 [[],[],[]] .smaller = true := by decide
def e1205865548730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205865548730 : Closed e1205865548730 ∧ code e1205865548730 = 5603912059834 := by decide
theorem cert_e1205865548730 : check e1205865548730 [[],[],[]] .smaller = true := by decide
def e1205865548758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205865548758 : Closed e1205865548758 ∧ code e1205865548758 = 5603912059862 := by decide
theorem cert_e1205865548758 : check e1205865548758 [[],[],[]] .smaller = true := by decide
def e1205865548762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205865548762 : Closed e1205865548762 ∧ code e1205865548762 = 5603912059866 := by decide
theorem cert_e1205865548762 : check e1205865548762 [[],[],[]] .smaller = true := by decide
def e1205865549038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205865549038 : Closed e1205865549038 ∧ code e1205865549038 = 5603912060142 := by decide
theorem cert_e1205865549038 : check e1205865549038 [[],[],[]] .smaller = true := by decide
def e1205865549046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205865549046 : Closed e1205865549046 ∧ code e1205865549046 = 5603912060150 := by decide
theorem cert_e1205865549046 : check e1205865549046 [[],[],[]] .smaller = true := by decide
def e1205865549422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205865549422 : Closed e1205865549422 ∧ code e1205865549422 = 5603912060526 := by decide
theorem cert_e1205865549422 : check e1205865549422 [[],[],[]] .smaller = true := by decide
def e1205865549434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205865549434 : Closed e1205865549434 ∧ code e1205865549434 = 5603912060538 := by decide
theorem cert_e1205865549434 : check e1205865549434 [[],[],[]] .smaller = true := by decide
def e1205865549622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205865549622 : Closed e1205865549622 ∧ code e1205865549622 = 5603912060726 := by decide
theorem cert_e1205865549622 : check e1205865549622 [[],[],[]] .smaller = true := by decide
def e1205865549626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205865549626 : Closed e1205865549626 ∧ code e1205865549626 = 5603912060730 := by decide
theorem cert_e1205865549626 : check e1205865549626 [[],[],[]] .smaller = true := by decide
def e1205959920494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205959920494 : Closed e1205959920494 ∧ code e1205959920494 = 5604006431598 := by decide
theorem cert_e1205959920494 : check e1205959920494 [[],[.left]] .chain = true := by decide
def e1205959920502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205959920502 : Closed e1205959920502 ∧ code e1205959920502 = 5604006431606 := by decide
theorem cert_e1205959920502 : check e1205959920502 [[],[.left]] .chain = true := by decide
end Blc.Floor42
