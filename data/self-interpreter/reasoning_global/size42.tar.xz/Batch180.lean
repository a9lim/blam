import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203302854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203302854 : Closed e1211203302854 ∧ code e1211203302854 = 5609249813958 := by decide
theorem cert_e1211203302854 : check e1211203302854 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211203302922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203302922 : Closed e1211203302922 ∧ code e1211203302922 = 5609249814026 := by decide
theorem cert_e1211203302922 : check e1211203302922 [[],[]] .chain = true := by decide
def e1211203302966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203302966 : Closed e1211203302966 ∧ code e1211203302966 = 5609249814070 := by decide
theorem cert_e1211203302966 : check e1211203302966 [[],[]] .chain = true := by decide
def e1211203302970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203302970 : Closed e1211203302970 ∧ code e1211203302970 = 5609249814074 := by decide
theorem cert_e1211203302970 : check e1211203302970 [[],[]] .chain = true := by decide
def e1211203303018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203303018 : Closed e1211203303018 ∧ code e1211203303018 = 5609249814122 := by decide
theorem cert_e1211203303018 : check e1211203303018 [[],[]] .chain = true := by decide
def e1211203303042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203303042 : Closed e1211203303042 ∧ code e1211203303042 = 5609249814146 := by decide
theorem cert_e1211203303042 : check e1211203303042 [[],[]] .chain = true := by decide
def e1211203303054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203303054 : Closed e1211203303054 ∧ code e1211203303054 = 5609249814158 := by decide
theorem cert_e1211203303054 : check e1211203303054 [[],[]] .chain = true := by decide
def e1211203303066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203303066 : Closed e1211203303066 ∧ code e1211203303066 = 5609249814170 := by decide
theorem cert_e1211203303066 : check e1211203303066 [[],[]] .chain = true := by decide
def e1211203303110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203303110 : Closed e1211203303110 ∧ code e1211203303110 = 5609249814214 := by decide
theorem cert_e1211203303110 : check e1211203303110 [[],[]] .chain = true := by decide
def e1211203303194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203303194 : Closed e1211203303194 ∧ code e1211203303194 = 5609249814298 := by decide
theorem cert_e1211203303194 : check e1211203303194 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203303238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203303238 : Closed e1211203303238 ∧ code e1211203303238 = 5609249814342 := by decide
theorem cert_e1211203303238 : check e1211203303238 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203303638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203303638 : Closed e1211203303638 ∧ code e1211203303638 = 5609249814742 := by decide
private def t_e1211203303638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem cert_e1211203303638 : ¬ IsSelfInterpreter e1211203303638 :=
  wSource (t := t_e1211203303638) (replay_sound (ps := []) (t := e1211203303638) (by decide)) (by decide)
def e1211203303642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203303642 : Closed e1211203303642 ∧ code e1211203303642 = 5609249814746 := by decide
private def t_e1211203303642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem cert_e1211203303642 : ¬ IsSelfInterpreter e1211203303642 :=
  wSource (t := t_e1211203303642) (replay_sound (ps := []) (t := e1211203303642) (by decide)) (by decide)
def e1211203303658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203303658 : Closed e1211203303658 ∧ code e1211203303658 = 5609249814762 := by decide
private def t_e1211203303658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem cert_e1211203303658 : ¬ IsSelfInterpreter e1211203303658 :=
  wSource (t := t_e1211203303658) (replay_sound (ps := []) (t := e1211203303658) (by decide)) (by decide)
def e1211203303990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203303990 : Closed e1211203303990 ∧ code e1211203303990 = 5609249815094 := by decide
private def t_e1211203303990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem cert_e1211203303990 : ¬ IsSelfInterpreter e1211203303990 :=
  wSource (t := t_e1211203303990) (replay_sound (ps := []) (t := e1211203303990) (by decide)) (by decide)
def e1211203303994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203303994 : Closed e1211203303994 ∧ code e1211203303994 = 5609249815098 := by decide
private def t_e1211203303994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem cert_e1211203303994 : ¬ IsSelfInterpreter e1211203303994 :=
  wSource (t := t_e1211203303994) (replay_sound (ps := []) (t := e1211203303994) (by decide)) (by decide)
def e1211203304078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203304078 : Closed e1211203304078 ∧ code e1211203304078 = 5609249815182 := by decide
private def t_e1211203304078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1211203304078 : ¬ IsSelfInterpreter e1211203304078 :=
  wSource (t := t_e1211203304078) (replay_sound (ps := []) (t := e1211203304078) (by decide)) (by decide)
def e1211203304134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203304134 : Closed e1211203304134 ∧ code e1211203304134 = 5609249815238 := by decide
private def t_e1211203304134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1211203304134 : ¬ IsSelfInterpreter e1211203304134 :=
  wSource (t := t_e1211203304134) (replay_sound (ps := []) (t := e1211203304134) (by decide)) (by decide)
def e1211203304218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203304218 : Closed e1211203304218 ∧ code e1211203304218 = 5609249815322 := by decide
private def t_e1211203304218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem cert_e1211203304218 : ¬ IsSelfInterpreter e1211203304218 :=
  wSource (t := t_e1211203304218) (replay_sound (ps := []) (t := e1211203304218) (by decide)) (by decide)
def e1211203304262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203304262 : Closed e1211203304262 ∧ code e1211203304262 = 5609249815366 := by decide
private def t_e1211203304262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem cert_e1211203304262 : ¬ IsSelfInterpreter e1211203304262 :=
  wSource (t := t_e1211203304262) (replay_sound (ps := []) (t := e1211203304262) (by decide)) (by decide)
def e1211203325806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 1)) (.var 2))))))
theorem wire_e1211203325806 : Closed e1211203325806 ∧ code e1211203325806 = 5609249836910 := by decide
theorem cert_e1211203325806 : check e1211203325806 [[],[]] .chain = true := by decide
def e1211203325814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 2)) (.var 1))))))
theorem wire_e1211203325814 : Closed e1211203325814 ∧ code e1211203325814 = 5609249836918 := by decide
theorem cert_e1211203325814 : check e1211203325814 [[],[]] .chain = true := by decide
def e1211203325870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 0)) (.var 2))))))
theorem wire_e1211203325870 : Closed e1211203325870 ∧ code e1211203325870 = 5609249836974 := by decide
theorem cert_e1211203325870 : check e1211203325870 [[],[]] .chain = true := by decide
def e1211203325882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 2)) (.var 0))))))
theorem wire_e1211203325882 : Closed e1211203325882 ∧ code e1211203325882 = 5609249836986 := by decide
theorem cert_e1211203325882 : check e1211203325882 [[],[]] .chain = true := by decide
def e1211203325910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 0)) (.var 1))))))
theorem wire_e1211203325910 : Closed e1211203325910 ∧ code e1211203325910 = 5609249837014 := by decide
theorem cert_e1211203325910 : check e1211203325910 [[],[]] .chain = true := by decide
def e1211203325914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 1)) (.var 0))))))
theorem wire_e1211203325914 : Closed e1211203325914 ∧ code e1211203325914 = 5609249837018 := by decide
theorem cert_e1211203325914 : check e1211203325914 [[],[]] .chain = true := by decide
def e1211203331950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1211203331950 : Closed e1211203331950 ∧ code e1211203331950 = 5609249843054 := by decide
theorem cert_e1211203331950 : check e1211203331950 [[],[]] .chain = true := by decide
def e1211203331958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1211203331958 : Closed e1211203331958 ∧ code e1211203331958 = 5609249843062 := by decide
theorem cert_e1211203331958 : check e1211203331958 [[],[]] .chain = true := by decide
def e1211203332022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1211203332022 : Closed e1211203332022 ∧ code e1211203332022 = 5609249843126 := by decide
theorem cert_e1211203332022 : check e1211203332022 [[],[]] .chain = true := by decide
def e1211203333358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203333358 : Closed e1211203333358 ∧ code e1211203333358 = 5609249844462 := by decide
theorem cert_e1211203333358 : check e1211203333358 [[],[]] .chain = true := by decide
def e1211203333366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203333366 : Closed e1211203333366 ∧ code e1211203333366 = 5609249844470 := by decide
theorem cert_e1211203333366 : check e1211203333366 [[],[]] .chain = true := by decide
def e1211203333750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203333750 : Closed e1211203333750 ∧ code e1211203333750 = 5609249844854 := by decide
theorem cert_e1211203333750 : check e1211203333750 [[],[]] .chain = true := by decide
def e1211203335022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203335022 : Closed e1211203335022 ∧ code e1211203335022 = 5609249846126 := by decide
theorem cert_e1211203335022 : check e1211203335022 [[],[]] .chain = true := by decide
def e1211203335030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203335030 : Closed e1211203335030 ∧ code e1211203335030 = 5609249846134 := by decide
theorem cert_e1211203335030 : check e1211203335030 [[],[]] .chain = true := by decide
def e1211203335086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203335086 : Closed e1211203335086 ∧ code e1211203335086 = 5609249846190 := by decide
theorem cert_e1211203335086 : check e1211203335086 [[],[]] .chain = true := by decide
def e1211203335098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203335098 : Closed e1211203335098 ∧ code e1211203335098 = 5609249846202 := by decide
theorem cert_e1211203335098 : check e1211203335098 [[],[]] .chain = true := by decide
def e1211203335126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203335126 : Closed e1211203335126 ∧ code e1211203335126 = 5609249846230 := by decide
theorem cert_e1211203335126 : check e1211203335126 [[],[]] .chain = true := by decide
def e1211203335130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203335130 : Closed e1211203335130 ∧ code e1211203335130 = 5609249846234 := by decide
theorem cert_e1211203335130 : check e1211203335130 [[],[]] .chain = true := by decide
def e1211203335406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203335406 : Closed e1211203335406 ∧ code e1211203335406 = 5609249846510 := by decide
theorem cert_e1211203335406 : check e1211203335406 [[],[]] .chain = true := by decide
def e1211203335414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203335414 : Closed e1211203335414 ∧ code e1211203335414 = 5609249846518 := by decide
theorem cert_e1211203335414 : check e1211203335414 [[],[]] .chain = true := by decide
def e1211203335790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203335790 : Closed e1211203335790 ∧ code e1211203335790 = 5609249846894 := by decide
theorem cert_e1211203335790 : check e1211203335790 [[],[]] .chain = true := by decide
def e1211203335802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203335802 : Closed e1211203335802 ∧ code e1211203335802 = 5609249846906 := by decide
theorem cert_e1211203335802 : check e1211203335802 [[],[]] .chain = true := by decide
def e1211203335990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203335990 : Closed e1211203335990 ∧ code e1211203335990 = 5609249847094 := by decide
theorem cert_e1211203335990 : check e1211203335990 [[],[]] .chain = true := by decide
def e1211203335994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203335994 : Closed e1211203335994 ∧ code e1211203335994 = 5609249847098 := by decide
theorem cert_e1211203335994 : check e1211203335994 [[],[]] .chain = true := by decide
def e1211203336430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203336430 : Closed e1211203336430 ∧ code e1211203336430 = 5609249847534 := by decide
theorem cert_e1211203336430 : check e1211203336430 [[],[]] .chain = true := by decide
def e1211203336438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203336438 : Closed e1211203336438 ∧ code e1211203336438 = 5609249847542 := by decide
theorem cert_e1211203336438 : check e1211203336438 [[],[]] .chain = true := by decide
def e1211203336990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203336990 : Closed e1211203336990 ∧ code e1211203336990 = 5609249848094 := by decide
theorem cert_e1211203336990 : check e1211203336990 [[],[]] .chain = true := by decide
def e1211203337102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203337102 : Closed e1211203337102 ∧ code e1211203337102 = 5609249848206 := by decide
theorem cert_e1211203337102 : check e1211203337102 [[],[]] .chain = true := by decide
def e1211203337326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203337326 : Closed e1211203337326 ∧ code e1211203337326 = 5609249848430 := by decide
theorem cert_e1211203337326 : check e1211203337326 [[],[]] .chain = true := by decide
def e1211203337338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203337338 : Closed e1211203337338 ∧ code e1211203337338 = 5609249848442 := by decide
theorem cert_e1211203337338 : check e1211203337338 [[],[]] .chain = true := by decide
def e1211203337502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203337502 : Closed e1211203337502 ∧ code e1211203337502 = 5609249848606 := by decide
theorem cert_e1211203337502 : check e1211203337502 [[],[]] .chain = true := by decide
def e1211203337670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203337670 : Closed e1211203337670 ∧ code e1211203337670 = 5609249848774 := by decide
theorem cert_e1211203337670 : check e1211203337670 [[],[]] .chain = true := by decide
def e1211203337782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203337782 : Closed e1211203337782 ∧ code e1211203337782 = 5609249848886 := by decide
theorem cert_e1211203337782 : check e1211203337782 [[],[]] .chain = true := by decide
def e1211203337786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203337786 : Closed e1211203337786 ∧ code e1211203337786 = 5609249848890 := by decide
theorem cert_e1211203337786 : check e1211203337786 [[],[]] .chain = true := by decide
def e1211203337870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203337870 : Closed e1211203337870 ∧ code e1211203337870 = 5609249848974 := by decide
theorem cert_e1211203337870 : check e1211203337870 [[],[]] .chain = true := by decide
def e1211203337926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203337926 : Closed e1211203337926 ∧ code e1211203337926 = 5609249849030 := by decide
theorem cert_e1211203337926 : check e1211203337926 [[],[]] .chain = true := by decide
def e1211203347310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e1211203347310 : Closed e1211203347310 ∧ code e1211203347310 = 5609249858414 := by decide
theorem cert_e1211203347310 : check e1211203347310 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203347318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e1211203347318 : Closed e1211203347318 ∧ code e1211203347318 = 5609249858422 := by decide
theorem cert_e1211203347318 : check e1211203347318 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203348718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203348718 : Closed e1211203348718 ∧ code e1211203348718 = 5609249859822 := by decide
theorem cert_e1211203348718 : check e1211203348718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203348726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203348726 : Closed e1211203348726 ∧ code e1211203348726 = 5609249859830 := by decide
theorem cert_e1211203348726 : check e1211203348726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203349278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203349278 : Closed e1211203349278 ∧ code e1211203349278 = 5609249860382 := by decide
theorem cert_e1211203349278 : check e1211203349278 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203349390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203349390 : Closed e1211203349390 ∧ code e1211203349390 = 5609249860494 := by decide
theorem cert_e1211203349390 : check e1211203349390 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203350254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e1211203350254 : Closed e1211203350254 ∧ code e1211203350254 = 5609249861358 := by decide
theorem cert_e1211203350254 : checkPay e1211203350254 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e1211203350382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e1211203350382 : Closed e1211203350382 ∧ code e1211203350382 = 5609249861486 := by decide
theorem cert_e1211203350382 : check e1211203350382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203350390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e1211203350390 : Closed e1211203350390 ∧ code e1211203350390 = 5609249861494 := by decide
theorem cert_e1211203350390 : check e1211203350390 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203350894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e1211203350894 : Closed e1211203350894 ∧ code e1211203350894 = 5609249861998 := by decide
theorem cert_e1211203350894 : check e1211203350894 [[],[]] .chain = true := by decide
def e1211203350902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e1211203350902 : Closed e1211203350902 ∧ code e1211203350902 = 5609249862006 := by decide
theorem cert_e1211203350902 : check e1211203350902 [[],[]] .chain = true := by decide
def e1211203352430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e1211203352430 : Closed e1211203352430 ∧ code e1211203352430 = 5609249863534 := by decide
theorem cert_e1211203352430 : check e1211203352430 [[],[]] .chain = true := by decide
def e1211203352438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e1211203352438 : Closed e1211203352438 ∧ code e1211203352438 = 5609249863542 := by decide
theorem cert_e1211203352438 : check e1211203352438 [[],[]] .chain = true := by decide
def e1211203352502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e1211203352502 : Closed e1211203352502 ∧ code e1211203352502 = 5609249863606 := by decide
theorem cert_e1211203352502 : check e1211203352502 [[],[]] .chain = true := by decide
def e1211203352750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e1211203352750 : Closed e1211203352750 ∧ code e1211203352750 = 5609249863854 := by decide
theorem cert_e1211203352750 : check e1211203352750 [[],[]] .chain = true := by decide
def e1211203352762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e1211203352762 : Closed e1211203352762 ∧ code e1211203352762 = 5609249863866 := by decide
theorem cert_e1211203352762 : check e1211203352762 [[],[]] .chain = true := by decide
def e1211203353326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e1211203353326 : Closed e1211203353326 ∧ code e1211203353326 = 5609249864430 := by decide
theorem cert_e1211203353326 : check e1211203353326 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203353454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203353454 : Closed e1211203353454 ∧ code e1211203353454 = 5609249864558 := by decide
theorem cert_e1211203353454 : check e1211203353454 [[],[]] .chain = true := by decide
def e1211203353462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203353462 : Closed e1211203353462 ∧ code e1211203353462 = 5609249864566 := by decide
theorem cert_e1211203353462 : check e1211203353462 [[],[]] .chain = true := by decide
def e1211203353518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203353518 : Closed e1211203353518 ∧ code e1211203353518 = 5609249864622 := by decide
theorem cert_e1211203353518 : check e1211203353518 [[],[]] .chain = true := by decide
def e1211203353530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203353530 : Closed e1211203353530 ∧ code e1211203353530 = 5609249864634 := by decide
theorem cert_e1211203353530 : check e1211203353530 [[],[]] .chain = true := by decide
def e1211203353558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203353558 : Closed e1211203353558 ∧ code e1211203353558 = 5609249864662 := by decide
theorem cert_e1211203353558 : check e1211203353558 [[],[]] .chain = true := by decide
def e1211203353562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203353562 : Closed e1211203353562 ∧ code e1211203353562 = 5609249864666 := by decide
theorem cert_e1211203353562 : check e1211203353562 [[],[]] .chain = true := by decide
def e1211203353686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e1211203353686 : Closed e1211203353686 ∧ code e1211203353686 = 5609249864790 := by decide
theorem cert_e1211203353686 : check e1211203353686 [[],[]] .chain = true := by decide
def e1211203353690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e1211203353690 : Closed e1211203353690 ∧ code e1211203353690 = 5609249864794 := by decide
theorem cert_e1211203353690 : check e1211203353690 [[],[]] .chain = true := by decide
def e1211203353966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203353966 : Closed e1211203353966 ∧ code e1211203353966 = 5609249865070 := by decide
theorem cert_e1211203353966 : check e1211203353966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203353974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203353974 : Closed e1211203353974 ∧ code e1211203353974 = 5609249865078 := by decide
theorem cert_e1211203353974 : check e1211203353974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211203354038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e1211203354038 : Closed e1211203354038 ∧ code e1211203354038 = 5609249865142 := by decide
theorem cert_e1211203354038 : check e1211203354038 [[],[]] .chain = true := by decide
def e1211203354070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203354070 : Closed e1211203354070 ∧ code e1211203354070 = 5609249865174 := by decide
theorem cert_e1211203354070 : check e1211203354070 [[],[]] .chain = true := by decide
def e1211203354074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203354074 : Closed e1211203354074 ∧ code e1211203354074 = 5609249865178 := by decide
theorem cert_e1211203354074 : check e1211203354074 [[],[]] .chain = true := by decide
def e1211203357934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203357934 : Closed e1211203357934 ∧ code e1211203357934 = 5609249869038 := by decide
theorem cert_e1211203357934 : check e1211203357934 [[],[]] .chain = true := by decide
def e1211203357942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203357942 : Closed e1211203357942 ∧ code e1211203357942 = 5609249869046 := by decide
theorem cert_e1211203357942 : check e1211203357942 [[],[]] .chain = true := by decide
def e1211203358318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203358318 : Closed e1211203358318 ∧ code e1211203358318 = 5609249869422 := by decide
theorem cert_e1211203358318 : check e1211203358318 [[],[]] .chain = true := by decide
def e1211203358330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203358330 : Closed e1211203358330 ∧ code e1211203358330 = 5609249869434 := by decide
theorem cert_e1211203358330 : check e1211203358330 [[],[]] .chain = true := by decide
def e1211203358518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203358518 : Closed e1211203358518 ∧ code e1211203358518 = 5609249869622 := by decide
theorem cert_e1211203358518 : check e1211203358518 [[],[]] .chain = true := by decide
def e1211203358522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203358522 : Closed e1211203358522 ∧ code e1211203358522 = 5609249869626 := by decide
theorem cert_e1211203358522 : check e1211203358522 [[],[]] .chain = true := by decide
def e1211203361006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203361006 : Closed e1211203361006 ∧ code e1211203361006 = 5609249872110 := by decide
theorem cert_e1211203361006 : check e1211203361006 [[],[]] .chain = true := by decide
def e1211203361014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203361014 : Closed e1211203361014 ∧ code e1211203361014 = 5609249872118 := by decide
theorem cert_e1211203361014 : check e1211203361014 [[],[]] .chain = true := by decide
def e1211203361566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203361566 : Closed e1211203361566 ∧ code e1211203361566 = 5609249872670 := by decide
theorem cert_e1211203361566 : check e1211203361566 [[],[]] .chain = true := by decide
def e1211203361678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203361678 : Closed e1211203361678 ∧ code e1211203361678 = 5609249872782 := by decide
theorem cert_e1211203361678 : check e1211203361678 [[],[]] .chain = true := by decide
def e1211203361902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203361902 : Closed e1211203361902 ∧ code e1211203361902 = 5609249873006 := by decide
theorem cert_e1211203361902 : check e1211203361902 [[],[]] .chain = true := by decide
def e1211203361914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203361914 : Closed e1211203361914 ∧ code e1211203361914 = 5609249873018 := by decide
theorem cert_e1211203361914 : check e1211203361914 [[],[]] .chain = true := by decide
def e1211203362078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203362078 : Closed e1211203362078 ∧ code e1211203362078 = 5609249873182 := by decide
theorem cert_e1211203362078 : check e1211203362078 [[],[]] .chain = true := by decide
def e1211203362246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203362246 : Closed e1211203362246 ∧ code e1211203362246 = 5609249873350 := by decide
theorem cert_e1211203362246 : check e1211203362246 [[],[]] .chain = true := by decide
def e1211203362358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203362358 : Closed e1211203362358 ∧ code e1211203362358 = 5609249873462 := by decide
theorem cert_e1211203362358 : check e1211203362358 [[],[]] .chain = true := by decide
def e1211203362362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203362362 : Closed e1211203362362 ∧ code e1211203362362 = 5609249873466 := by decide
theorem cert_e1211203362362 : check e1211203362362 [[],[]] .chain = true := by decide
def e1211203362446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203362446 : Closed e1211203362446 ∧ code e1211203362446 = 5609249873550 := by decide
theorem cert_e1211203362446 : check e1211203362446 [[],[]] .chain = true := by decide
def e1211203362502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203362502 : Closed e1211203362502 ∧ code e1211203362502 = 5609249873606 := by decide
theorem cert_e1211203362502 : check e1211203362502 [[],[]] .chain = true := by decide
def e1211203364638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203364638 : Closed e1211203364638 ∧ code e1211203364638 = 5609249875742 := by decide
theorem cert_e1211203364638 : check e1211203364638 [[],[]] .chain = true := by decide
def e1211203364750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203364750 : Closed e1211203364750 ∧ code e1211203364750 = 5609249875854 := by decide
theorem cert_e1211203364750 : check e1211203364750 [[],[]] .chain = true := by decide
def e1211203367710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203367710 : Closed e1211203367710 ∧ code e1211203367710 = 5609249878814 := by decide
theorem cert_e1211203367710 : check e1211203367710 [[],[]] .chain = true := by decide
def e1211203367878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203367878 : Closed e1211203367878 ∧ code e1211203367878 = 5609249878982 := by decide
theorem cert_e1211203367878 : check e1211203367878 [[],[]] .chain = true := by decide
def e1211203369358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203369358 : Closed e1211203369358 ∧ code e1211203369358 = 5609249880462 := by decide
theorem cert_e1211203369358 : check e1211203369358 [[],[]] .chain = true := by decide
def e1211203369414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203369414 : Closed e1211203369414 ∧ code e1211203369414 = 5609249880518 := by decide
theorem cert_e1211203369414 : check e1211203369414 [[],[]] .chain = true := by decide
def e1211203371502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211203371502 : Closed e1211203371502 ∧ code e1211203371502 = 5609249882606 := by decide
theorem cert_e1211203371502 : check e1211203371502 [[],[]] .chain = true := by decide
def e1211203371510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e1211203371510 : Closed e1211203371510 ∧ code e1211203371510 = 5609249882614 := by decide
theorem cert_e1211203371510 : check e1211203371510 [[],[]] .chain = true := by decide
def e1211203372270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203372270 : Closed e1211203372270 ∧ code e1211203372270 = 5609249883374 := by decide
theorem cert_e1211203372270 : check e1211203372270 [[],[]] .chain = true := by decide
def e1211203372278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203372278 : Closed e1211203372278 ∧ code e1211203372278 = 5609249883382 := by decide
theorem cert_e1211203372278 : check e1211203372278 [[],[]] .chain = true := by decide
def e1211203372830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211203372830 : Closed e1211203372830 ∧ code e1211203372830 = 5609249883934 := by decide
theorem cert_e1211203372830 : check e1211203372830 [[],[]] .chain = true := by decide
def e1211203372942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e1211203372942 : Closed e1211203372942 ∧ code e1211203372942 = 5609249884046 := by decide
theorem cert_e1211203372942 : check e1211203372942 [[],[]] .chain = true := by decide
def e1211203374638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203374638 : Closed e1211203374638 ∧ code e1211203374638 = 5609249885742 := by decide
theorem cert_e1211203374638 : check e1211203374638 [[],[]] .chain = true := by decide
def e1211203374818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203374818 : Closed e1211203374818 ∧ code e1211203374818 = 5609249885922 := by decide
theorem cert_e1211203374818 : check e1211203374818 [[],[]] .chain = true := by decide
def e1211203374830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1211203374830 : Closed e1211203374830 ∧ code e1211203374830 = 5609249885934 := by decide
theorem cert_e1211203374830 : check e1211203374830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203374870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203374870 : Closed e1211203374870 ∧ code e1211203374870 = 5609249885974 := by decide
theorem cert_e1211203374870 : check e1211203374870 [[],[]] .chain = true := by decide
def e1211203374946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203374946 : Closed e1211203374946 ∧ code e1211203374946 = 5609249886050 := by decide
theorem cert_e1211203374946 : check e1211203374946 [[],[]] .chain = true := by decide
def e1211203374958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1211203374958 : Closed e1211203374958 ∧ code e1211203374958 = 5609249886062 := by decide
theorem cert_e1211203374958 : check e1211203374958 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203374966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1211203374966 : Closed e1211203374966 ∧ code e1211203374966 = 5609249886070 := by decide
theorem cert_e1211203374966 : checkPay e1211203374966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211203377214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e1211203377214 : Closed e1211203377214 ∧ code e1211203377214 = 5609249888318 := by decide
theorem cert_e1211203377214 : check e1211203377214 [[],[]] .chain = true := by decide
def e1211203377634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203377634 : Closed e1211203377634 ∧ code e1211203377634 = 5609249888738 := by decide
theorem cert_e1211203377634 : check e1211203377634 [[],[]] .chain = true := by decide
def e1211203377646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203377646 : Closed e1211203377646 ∧ code e1211203377646 = 5609249888750 := by decide
theorem cert_e1211203377646 : check e1211203377646 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203378206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e1211203378206 : Closed e1211203378206 ∧ code e1211203378206 = 5609249889310 := by decide
theorem cert_e1211203378206 : check e1211203378206 [[],[]] .chain = true := by decide
def e1211203378402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203378402 : Closed e1211203378402 ∧ code e1211203378402 = 5609249889506 := by decide
theorem cert_e1211203378402 : check e1211203378402 [[],[]] .chain = true := by decide
def e1211203378414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203378414 : Closed e1211203378414 ∧ code e1211203378414 = 5609249889518 := by decide
theorem cert_e1211203378414 : check e1211203378414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203378422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203378422 : Closed e1211203378422 ∧ code e1211203378422 = 5609249889526 := by decide
theorem cert_e1211203378422 : check e1211203378422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203379438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203379438 : Closed e1211203379438 ∧ code e1211203379438 = 5609249890542 := by decide
theorem cert_e1211203379438 : check e1211203379438 [[],[]] .chain = true := by decide
def e1211203379450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e1211203379450 : Closed e1211203379450 ∧ code e1211203379450 = 5609249890554 := by decide
theorem cert_e1211203379450 : check e1211203379450 [[],[]] .chain = true := by decide
def e1211203379630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211203379630 : Closed e1211203379630 ∧ code e1211203379630 = 5609249890734 := by decide
theorem cert_e1211203379630 : check e1211203379630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203379822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203379822 : Closed e1211203379822 ∧ code e1211203379822 = 5609249890926 := by decide
theorem cert_e1211203379822 : check e1211203379822 [[],[]] .chain = true := by decide
def e1211203379834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203379834 : Closed e1211203379834 ∧ code e1211203379834 = 5609249890938 := by decide
theorem cert_e1211203379834 : check e1211203379834 [[],[]] .chain = true := by decide
def e1211203379998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203379998 : Closed e1211203379998 ∧ code e1211203379998 = 5609249891102 := by decide
theorem cert_e1211203379998 : check e1211203379998 [[],[]] .chain = true := by decide
def e1211203380166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e1211203380166 : Closed e1211203380166 ∧ code e1211203380166 = 5609249891270 := by decide
theorem cert_e1211203380166 : check e1211203380166 [[],[]] .chain = true := by decide
def e1211203380782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203380782 : Closed e1211203380782 ∧ code e1211203380782 = 5609249891886 := by decide
theorem cert_e1211203380782 : check e1211203380782 [[],[]] .chain = true := by decide
def e1211203380962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203380962 : Closed e1211203380962 ∧ code e1211203380962 = 5609249892066 := by decide
theorem cert_e1211203380962 : check e1211203380962 [[],[]] .chain = true := by decide
def e1211203380974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1211203380974 : Closed e1211203380974 ∧ code e1211203380974 = 5609249892078 := by decide
theorem cert_e1211203380974 : check e1211203380974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203381102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1211203381102 : Closed e1211203381102 ∧ code e1211203381102 = 5609249892206 := by decide
theorem cert_e1211203381102 : check e1211203381102 [[],[]] .chain = true := by decide
def e1211203381110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1211203381110 : Closed e1211203381110 ∧ code e1211203381110 = 5609249892214 := by decide
theorem cert_e1211203381110 : check e1211203381110 [[],[]] .chain = true := by decide
def e1211203381130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203381130 : Closed e1211203381130 ∧ code e1211203381130 = 5609249892234 := by decide
theorem cert_e1211203381130 : check e1211203381130 [[],[]] .chain = true := by decide
def e1211203381154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203381154 : Closed e1211203381154 ∧ code e1211203381154 = 5609249892258 := by decide
theorem cert_e1211203381154 : check e1211203381154 [[],[]] .chain = true := by decide
def e1211203381166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1211203381166 : Closed e1211203381166 ∧ code e1211203381166 = 5609249892270 := by decide
theorem cert_e1211203381166 : check e1211203381166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203381174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1211203381174 : Closed e1211203381174 ∧ code e1211203381174 = 5609249892278 := by decide
theorem cert_e1211203381174 : check e1211203381174 [[],[]] .chain = true := by decide
def e1211203381178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1211203381178 : Closed e1211203381178 ∧ code e1211203381178 = 5609249892282 := by decide
theorem cert_e1211203381178 : check e1211203381178 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203381310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e1211203381310 : Closed e1211203381310 ∧ code e1211203381310 = 5609249892414 := by decide
theorem cert_e1211203381310 : check e1211203381310 [[],[]] .chain = true := by decide
def e1211203381730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203381730 : Closed e1211203381730 ∧ code e1211203381730 = 5609249892834 := by decide
theorem cert_e1211203381730 : check e1211203381730 [[],[]] .chain = true := by decide
def e1211203381742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203381742 : Closed e1211203381742 ∧ code e1211203381742 = 5609249892846 := by decide
theorem cert_e1211203381742 : check e1211203381742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203382510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203382510 : Closed e1211203382510 ∧ code e1211203382510 = 5609249893614 := by decide
theorem cert_e1211203382510 : check e1211203382510 [[],[]] .chain = true := by decide
def e1211203382518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203382518 : Closed e1211203382518 ∧ code e1211203382518 = 5609249893622 := by decide
theorem cert_e1211203382518 : check e1211203382518 [[],[]] .chain = true := by decide
def e1211203382798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203382798 : Closed e1211203382798 ∧ code e1211203382798 = 5609249893902 := by decide
theorem cert_e1211203382798 : check e1211203382798 [[],[]] .chain = true := by decide
def e1211203382810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203382810 : Closed e1211203382810 ∧ code e1211203382810 = 5609249893914 := by decide
theorem cert_e1211203382810 : check e1211203382810 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203382882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203382882 : Closed e1211203382882 ∧ code e1211203382882 = 5609249893986 := by decide
theorem cert_e1211203382882 : check e1211203382882 [[],[]] .chain = true := by decide
def e1211203382894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203382894 : Closed e1211203382894 ∧ code e1211203382894 = 5609249893998 := by decide
theorem cert_e1211203382894 : check e1211203382894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203382902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203382902 : Closed e1211203382902 ∧ code e1211203382902 = 5609249894006 := by decide
theorem cert_e1211203382902 : check e1211203382902 [[],[]] .chain = true := by decide
def e1211203382906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203382906 : Closed e1211203382906 ∧ code e1211203382906 = 5609249894010 := by decide
theorem cert_e1211203382906 : check e1211203382906 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203383414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203383414 : Closed e1211203383414 ∧ code e1211203383414 = 5609249894518 := by decide
theorem cert_e1211203383414 : check e1211203383414 [[],[]] .chain = true := by decide
def e1211203383418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203383418 : Closed e1211203383418 ∧ code e1211203383418 = 5609249894522 := by decide
theorem cert_e1211203383418 : check e1211203383418 [[],[]] .chain = true := by decide
end Blc.Floor42
