import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182210502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211182210502 : Closed e1211182210502 ∧ code e1211182210502 = 5609228721606 := by decide
theorem cert_e1211182210502 : check e1211182210502 [[],[]] .smaller = true := by decide
def e1211182210526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 3))))))))
theorem wire_e1211182210526 : Closed e1211182210526 ∧ code e1211182210526 = 5609228721630 := by decide
theorem cert_e1211182210526 : check e1211182210526 [[],[]] .smaller = true := by decide
def e1211182210542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 2))))))))
theorem wire_e1211182210542 : Closed e1211182210542 ∧ code e1211182210542 = 5609228721646 := by decide
theorem cert_e1211182210542 : check e1211182210542 [[],[]] .smaller = true := by decide
def e1211182210550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 4)) (.var 1))))))))
theorem wire_e1211182210550 : Closed e1211182210550 ∧ code e1211182210550 = 5609228721654 := by decide
theorem cert_e1211182210550 : check e1211182210550 [[],[]] .three = true := by decide
def e1211182210614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211182210614 : Closed e1211182210614 ∧ code e1211182210614 = 5609228721718 := by decide
theorem cert_e1211182210614 : check e1211182210614 [[],[]] .smaller = true := by decide
def e1211182210618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211182210618 : Closed e1211182210618 ∧ code e1211182210618 = 5609228721722 := by decide
theorem cert_e1211182210618 : check e1211182210618 [[],[]] .smaller = true := by decide
def e1211182210666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211182210666 : Closed e1211182210666 ∧ code e1211182210666 = 5609228721770 := by decide
theorem cert_e1211182210666 : check e1211182210666 [[],[]] .smaller = true := by decide
def e1211182210702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211182210702 : Closed e1211182210702 ∧ code e1211182210702 = 5609228721806 := by decide
theorem cert_e1211182210702 : check e1211182210702 [[],[]] .smaller = true := by decide
def e1211182210714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182210714 : Closed e1211182210714 ∧ code e1211182210714 = 5609228721818 := by decide
theorem cert_e1211182210714 : check e1211182210714 [[],[]] .smaller = true := by decide
def e1211182210758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211182210758 : Closed e1211182210758 ∧ code e1211182210758 = 5609228721862 := by decide
theorem cert_e1211182210758 : check e1211182210758 [[],[]] .smaller = true := by decide
def e1211182210798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 2))))))))
theorem wire_e1211182210798 : Closed e1211182210798 ∧ code e1211182210798 = 5609228721902 := by decide
theorem cert_e1211182210798 : check e1211182210798 [[],[]] .smaller = true := by decide
def e1211182210842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211182210842 : Closed e1211182210842 ∧ code e1211182210842 = 5609228721946 := by decide
theorem cert_e1211182210842 : check e1211182210842 [[],[]] .three = true := by decide
def e1211182210886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211182210886 : Closed e1211182210886 ∧ code e1211182210886 = 5609228721990 := by decide
theorem cert_e1211182210886 : check e1211182210886 [[],[]] .three = true := by decide
def e1211182210926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.var 2))))))))
theorem wire_e1211182210926 : Closed e1211182210926 ∧ code e1211182210926 = 5609228722030 := by decide
theorem cert_e1211182210926 : check e1211182210926 [[],[]] .three = true := by decide
def e1211182210934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 2)) (.var 1))))))))
theorem wire_e1211182210934 : Closed e1211182210934 ∧ code e1211182210934 = 5609228722038 := by decide
theorem cert_e1211182210934 : check e1211182210934 [[],[]] .three = true := by decide
def e1211182211934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e1211182211934 : Closed e1211182211934 ∧ code e1211182211934 = 5609228723038 := by decide
theorem cert_e1211182211934 : check e1211182211934 [[],[]] .smaller = true := by decide
def e1211182211950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211182211950 : Closed e1211182211950 ∧ code e1211182211950 = 5609228723054 := by decide
theorem cert_e1211182211950 : check e1211182211950 [[],[]] .smaller = true := by decide
def e1211182211958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211182211958 : Closed e1211182211958 ∧ code e1211182211958 = 5609228723062 := by decide
theorem cert_e1211182211958 : check e1211182211958 [[],[]] .smaller = true := by decide
def e1211182211962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e1211182211962 : Closed e1211182211962 ∧ code e1211182211962 = 5609228723066 := by decide
theorem cert_e1211182211962 : check e1211182211962 [[],[]] .smaller = true := by decide
def e1211182212014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e1211182212014 : Closed e1211182212014 ∧ code e1211182212014 = 5609228723118 := by decide
theorem cert_e1211182212014 : check e1211182212014 [[],[]] .smaller = true := by decide
def e1211182212026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e1211182212026 : Closed e1211182212026 ∧ code e1211182212026 = 5609228723130 := by decide
theorem cert_e1211182212026 : check e1211182212026 [[],[]] .smaller = true := by decide
def e1211182212054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211182212054 : Closed e1211182212054 ∧ code e1211182212054 = 5609228723158 := by decide
theorem cert_e1211182212054 : check e1211182212054 [[],[]] .smaller = true := by decide
def e1211182212058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211182212058 : Closed e1211182212058 ∧ code e1211182212058 = 5609228723162 := by decide
theorem cert_e1211182212058 : check e1211182212058 [[],[]] .smaller = true := by decide
def e1211182212074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e1211182212074 : Closed e1211182212074 ∧ code e1211182212074 = 5609228723178 := by decide
theorem cert_e1211182212074 : check e1211182212074 [[],[]] .smaller = true := by decide
def e1211182212790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e1211182212790 : Closed e1211182212790 ∧ code e1211182212790 = 5609228723894 := by decide
theorem cert_e1211182212790 : check e1211182212790 [[],[]] .smaller = true := by decide
def e1211182212822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211182212822 : Closed e1211182212822 ∧ code e1211182212822 = 5609228723926 := by decide
theorem cert_e1211182212822 : check e1211182212822 [[],[]] .smaller = true := by decide
def e1211182212826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211182212826 : Closed e1211182212826 ∧ code e1211182212826 = 5609228723930 := by decide
theorem cert_e1211182212826 : check e1211182212826 [[],[]] .smaller = true := by decide
def e1211182212950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211182212950 : Closed e1211182212950 ∧ code e1211182212950 = 5609228724054 := by decide
theorem cert_e1211182212950 : check e1211182212950 [[],[]] .smaller = true := by decide
def e1211182212954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211182212954 : Closed e1211182212954 ∧ code e1211182212954 = 5609228724058 := by decide
theorem cert_e1211182212954 : check e1211182212954 [[],[]] .smaller = true := by decide
def e1211182212970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211182212970 : Closed e1211182212970 ∧ code e1211182212970 = 5609228724074 := by decide
theorem cert_e1211182212970 : check e1211182212970 [[],[]] .smaller = true := by decide
def e1211182213342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211182213342 : Closed e1211182213342 ∧ code e1211182213342 = 5609228724446 := by decide
theorem cert_e1211182213342 : check e1211182213342 [[],[]] .smaller = true := by decide
def e1211182213358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211182213358 : Closed e1211182213358 ∧ code e1211182213358 = 5609228724462 := by decide
theorem cert_e1211182213358 : check e1211182213358 [[],[]] .smaller = true := by decide
def e1211182213366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211182213366 : Closed e1211182213366 ∧ code e1211182213366 = 5609228724470 := by decide
theorem cert_e1211182213366 : check e1211182213366 [[],[]] .smaller = true := by decide
def e1211182213370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211182213370 : Closed e1211182213370 ∧ code e1211182213370 = 5609228724474 := by decide
theorem cert_e1211182213370 : check e1211182213370 [[],[]] .smaller = true := by decide
def e1211182213558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211182213558 : Closed e1211182213558 ∧ code e1211182213558 = 5609228724662 := by decide
theorem cert_e1211182213558 : check e1211182213558 [[],[]] .smaller = true := by decide
def e1211182213590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211182213590 : Closed e1211182213590 ∧ code e1211182213590 = 5609228724694 := by decide
theorem cert_e1211182213590 : check e1211182213590 [[],[]] .smaller = true := by decide
def e1211182213594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211182213594 : Closed e1211182213594 ∧ code e1211182213594 = 5609228724698 := by decide
theorem cert_e1211182213594 : check e1211182213594 [[],[]] .smaller = true := by decide
def e1211182213694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211182213694 : Closed e1211182213694 ∧ code e1211182213694 = 5609228724798 := by decide
theorem cert_e1211182213694 : check e1211182213694 [[],[]] .smaller = true := by decide
def e1211182213750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182213750 : Closed e1211182213750 ∧ code e1211182213750 = 5609228724854 := by decide
theorem cert_e1211182213750 : check e1211182213750 [[],[]] .smaller = true := by decide
def e1211182213918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211182213918 : Closed e1211182213918 ∧ code e1211182213918 = 5609228725022 := by decide
theorem cert_e1211182213918 : check e1211182213918 [[],[]] .smaller = true := by decide
def e1211182213942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182213942 : Closed e1211182213942 ∧ code e1211182213942 = 5609228725046 := by decide
theorem cert_e1211182213942 : check e1211182213942 [[],[]] .smaller = true := by decide
def e1211182213946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182213946 : Closed e1211182213946 ∧ code e1211182213946 = 5609228725050 := by decide
theorem cert_e1211182213946 : check e1211182213946 [[],[]] .smaller = true := by decide
def e1211182214030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211182214030 : Closed e1211182214030 ∧ code e1211182214030 = 5609228725134 := by decide
theorem cert_e1211182214030 : check e1211182214030 [[],[]] .smaller = true := by decide
def e1211182214078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 4))))))))
theorem wire_e1211182214078 : Closed e1211182214078 ∧ code e1211182214078 = 5609228725182 := by decide
theorem cert_e1211182214078 : check e1211182214078 [[],[]] .three = true := by decide
def e1211182214086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211182214086 : Closed e1211182214086 ∧ code e1211182214086 = 5609228725190 := by decide
theorem cert_e1211182214086 : check e1211182214086 [[],[]] .smaller = true := by decide
def e1211182214110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 3))))))))
theorem wire_e1211182214110 : Closed e1211182214110 ∧ code e1211182214110 = 5609228725214 := by decide
theorem cert_e1211182214110 : check e1211182214110 [[],[]] .smaller = true := by decide
def e1211182214126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 4)) (.var 2))))))))
theorem wire_e1211182214126 : Closed e1211182214126 ∧ code e1211182214126 = 5609228725230 := by decide
theorem cert_e1211182214126 : check e1211182214126 [[],[]] .three = true := by decide
def e1211182214254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211182214254 : Closed e1211182214254 ∧ code e1211182214254 = 5609228725358 := by decide
theorem cert_e1211182214254 : check e1211182214254 [[],[]] .smaller = true := by decide
def e1211182214266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211182214266 : Closed e1211182214266 ∧ code e1211182214266 = 5609228725370 := by decide
theorem cert_e1211182214266 : check e1211182214266 [[],[]] .smaller = true := by decide
def e1211182214358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211182214358 : Closed e1211182214358 ∧ code e1211182214358 = 5609228725462 := by decide
theorem cert_e1211182214358 : check e1211182214358 [[],[]] .smaller = true := by decide
def e1211182214362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211182214362 : Closed e1211182214362 ∧ code e1211182214362 = 5609228725466 := by decide
theorem cert_e1211182214362 : check e1211182214362 [[],[]] .smaller = true := by decide
def e1211182214378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211182214378 : Closed e1211182214378 ∧ code e1211182214378 = 5609228725482 := by decide
theorem cert_e1211182214378 : check e1211182214378 [[],[]] .smaller = true := by decide
def e1211182214430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211182214430 : Closed e1211182214430 ∧ code e1211182214430 = 5609228725534 := by decide
theorem cert_e1211182214430 : check e1211182214430 [[],[]] .smaller = true := by decide
def e1211182214454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182214454 : Closed e1211182214454 ∧ code e1211182214454 = 5609228725558 := by decide
theorem cert_e1211182214454 : check e1211182214454 [[],[]] .smaller = true := by decide
def e1211182214458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182214458 : Closed e1211182214458 ∧ code e1211182214458 = 5609228725562 := by decide
theorem cert_e1211182214458 : check e1211182214458 [[],[]] .smaller = true := by decide
def e1211182214554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182214554 : Closed e1211182214554 ∧ code e1211182214554 = 5609228725658 := by decide
theorem cert_e1211182214554 : check e1211182214554 [[],[]] .smaller = true := by decide
def e1211182214590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 4))))))))
theorem wire_e1211182214590 : Closed e1211182214590 ∧ code e1211182214590 = 5609228725694 := by decide
theorem cert_e1211182214590 : check e1211182214590 [[],[]] .three = true := by decide
def e1211182214598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211182214598 : Closed e1211182214598 ∧ code e1211182214598 = 5609228725702 := by decide
theorem cert_e1211182214598 : check e1211182214598 [[],[]] .smaller = true := by decide
def e1211182214622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e1211182214622 : Closed e1211182214622 ∧ code e1211182214622 = 5609228725726 := by decide
theorem cert_e1211182214622 : check e1211182214622 [[],[]] .smaller = true := by decide
def e1211182214638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e1211182214638 : Closed e1211182214638 ∧ code e1211182214638 = 5609228725742 := by decide
theorem cert_e1211182214638 : check e1211182214638 [[],[]] .smaller = true := by decide
def e1211182214646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 4)) (.var 1))))))))
theorem wire_e1211182214646 : Closed e1211182214646 ∧ code e1211182214646 = 5609228725750 := by decide
theorem cert_e1211182214646 : check e1211182214646 [[],[]] .three = true := by decide
def e1211182214710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211182214710 : Closed e1211182214710 ∧ code e1211182214710 = 5609228725814 := by decide
theorem cert_e1211182214710 : check e1211182214710 [[],[]] .smaller = true := by decide
def e1211182214714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211182214714 : Closed e1211182214714 ∧ code e1211182214714 = 5609228725818 := by decide
theorem cert_e1211182214714 : check e1211182214714 [[],[]] .smaller = true := by decide
def e1211182214798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211182214798 : Closed e1211182214798 ∧ code e1211182214798 = 5609228725902 := by decide
theorem cert_e1211182214798 : check e1211182214798 [[],[]] .smaller = true := by decide
def e1211182214846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 4))))))))
theorem wire_e1211182214846 : Closed e1211182214846 ∧ code e1211182214846 = 5609228725950 := by decide
theorem cert_e1211182214846 : check e1211182214846 [[],[]] .three = true := by decide
def e1211182214854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211182214854 : Closed e1211182214854 ∧ code e1211182214854 = 5609228725958 := by decide
theorem cert_e1211182214854 : check e1211182214854 [[],[]] .smaller = true := by decide
def e1211182214878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e1211182214878 : Closed e1211182214878 ∧ code e1211182214878 = 5609228725982 := by decide
theorem cert_e1211182214878 : check e1211182214878 [[],[]] .smaller = true := by decide
def e1211182214902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e1211182214902 : Closed e1211182214902 ∧ code e1211182214902 = 5609228726006 := by decide
theorem cert_e1211182214902 : check e1211182214902 [[],[]] .smaller = true := by decide
def e1211182214906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 4)) (.var 0))))))))
theorem wire_e1211182214906 : Closed e1211182214906 ∧ code e1211182214906 = 5609228726010 := by decide
theorem cert_e1211182214906 : check e1211182214906 [[],[]] .three = true := by decide
def e1211182214938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211182214938 : Closed e1211182214938 ∧ code e1211182214938 = 5609228726042 := by decide
theorem cert_e1211182214938 : check e1211182214938 [[],[]] .smaller = true := by decide
def e1211182214982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211182214982 : Closed e1211182214982 ∧ code e1211182214982 = 5609228726086 := by decide
theorem cert_e1211182214982 : check e1211182214982 [[],[]] .smaller = true := by decide
def e1211182215006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 3))))))))
theorem wire_e1211182215006 : Closed e1211182215006 ∧ code e1211182215006 = 5609228726110 := by decide
theorem cert_e1211182215006 : check e1211182215006 [[],[]] .smaller = true := by decide
def e1211182215022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e1211182215022 : Closed e1211182215022 ∧ code e1211182215022 = 5609228726126 := by decide
theorem cert_e1211182215022 : check e1211182215022 [[],[]] .smaller = true := by decide
def e1211182215030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e1211182215030 : Closed e1211182215030 ∧ code e1211182215030 = 5609228726134 := by decide
theorem cert_e1211182215030 : check e1211182215030 [[],[]] .smaller = true := by decide
def e1211182215034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.var 0))))))))
theorem wire_e1211182215034 : Closed e1211182215034 ∧ code e1211182215034 = 5609228726138 := by decide
theorem cert_e1211182215034 : check e1211182215034 [[],[]] .smaller = true := by decide
def e1211182215086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 0)) (.var 2))))))))
theorem wire_e1211182215086 : Closed e1211182215086 ∧ code e1211182215086 = 5609228726190 := by decide
theorem cert_e1211182215086 : check e1211182215086 [[],[]] .three = true := by decide
def e1211182215094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 1)) (.var 1))))))))
theorem wire_e1211182215094 : Closed e1211182215094 ∧ code e1211182215094 = 5609228726198 := by decide
theorem cert_e1211182215094 : check e1211182215094 [[],[]] .three = true := by decide
def e1211182215098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 2)) (.var 0))))))))
theorem wire_e1211182215098 : Closed e1211182215098 ∧ code e1211182215098 = 5609228726202 := by decide
theorem cert_e1211182215098 : check e1211182215098 [[],[]] .three = true := by decide
def e1211182215598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211182215598 : Closed e1211182215598 ∧ code e1211182215598 = 5609228726702 := by decide
theorem cert_e1211182215598 : check e1211182215598 [[],[]] .smaller = true := by decide
def e1211182215606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e1211182215606 : Closed e1211182215606 ∧ code e1211182215606 = 5609228726710 := by decide
theorem cert_e1211182215606 : check e1211182215606 [[],[]] .smaller = true := by decide
def e1211182215610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211182215610 : Closed e1211182215610 ∧ code e1211182215610 = 5609228726714 := by decide
theorem cert_e1211182215610 : check e1211182215610 [[],[]] .smaller = true := by decide
def e1211182215638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e1211182215638 : Closed e1211182215638 ∧ code e1211182215638 = 5609228726742 := by decide
theorem cert_e1211182215638 : check e1211182215638 [[],[]] .smaller = true := by decide
def e1211182215642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e1211182215642 : Closed e1211182215642 ∧ code e1211182215642 = 5609228726746 := by decide
theorem cert_e1211182215642 : check e1211182215642 [[],[]] .smaller = true := by decide
def e1211182215658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211182215658 : Closed e1211182215658 ∧ code e1211182215658 = 5609228726762 := by decide
theorem cert_e1211182215658 : check e1211182215658 [[],[]] .smaller = true := by decide
def e1211182216022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211182216022 : Closed e1211182216022 ∧ code e1211182216022 = 5609228727126 := by decide
theorem cert_e1211182216022 : check e1211182216022 [[],[]] .smaller = true := by decide
def e1211182216026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211182216026 : Closed e1211182216026 ∧ code e1211182216026 = 5609228727130 := by decide
theorem cert_e1211182216026 : check e1211182216026 [[],[]] .smaller = true := by decide
def e1211182216042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211182216042 : Closed e1211182216042 ∧ code e1211182216042 = 5609228727146 := by decide
theorem cert_e1211182216042 : check e1211182216042 [[],[]] .smaller = true := by decide
def e1211182216106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e1211182216106 : Closed e1211182216106 ∧ code e1211182216106 = 5609228727210 := by decide
theorem cert_e1211182216106 : check e1211182216106 [[],[]] .smaller = true := by decide
def e1211182216302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211182216302 : Closed e1211182216302 ∧ code e1211182216302 = 5609228727406 := by decide
theorem cert_e1211182216302 : check e1211182216302 [[],[]] .smaller = true := by decide
def e1211182216310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211182216310 : Closed e1211182216310 ∧ code e1211182216310 = 5609228727414 := by decide
theorem cert_e1211182216310 : check e1211182216310 [[],[]] .smaller = true := by decide
def e1211182216314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211182216314 : Closed e1211182216314 ∧ code e1211182216314 = 5609228727418 := by decide
theorem cert_e1211182216314 : check e1211182216314 [[],[]] .smaller = true := by decide
def e1211182216406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211182216406 : Closed e1211182216406 ∧ code e1211182216406 = 5609228727510 := by decide
theorem cert_e1211182216406 : check e1211182216406 [[],[]] .smaller = true := by decide
def e1211182216410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211182216410 : Closed e1211182216410 ∧ code e1211182216410 = 5609228727514 := by decide
theorem cert_e1211182216410 : check e1211182216410 [[],[]] .smaller = true := by decide
def e1211182216426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211182216426 : Closed e1211182216426 ∧ code e1211182216426 = 5609228727530 := by decide
theorem cert_e1211182216426 : check e1211182216426 [[],[]] .smaller = true := by decide
def e1211182216478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211182216478 : Closed e1211182216478 ∧ code e1211182216478 = 5609228727582 := by decide
theorem cert_e1211182216478 : check e1211182216478 [[],[]] .smaller = true := by decide
def e1211182216502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182216502 : Closed e1211182216502 ∧ code e1211182216502 = 5609228727606 := by decide
theorem cert_e1211182216502 : check e1211182216502 [[],[]] .smaller = true := by decide
def e1211182216506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182216506 : Closed e1211182216506 ∧ code e1211182216506 = 5609228727610 := by decide
theorem cert_e1211182216506 : check e1211182216506 [[],[]] .smaller = true := by decide
def e1211182216590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211182216590 : Closed e1211182216590 ∧ code e1211182216590 = 5609228727694 := by decide
theorem cert_e1211182216590 : check e1211182216590 [[],[]] .smaller = true := by decide
def e1211182216602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182216602 : Closed e1211182216602 ∧ code e1211182216602 = 5609228727706 := by decide
theorem cert_e1211182216602 : check e1211182216602 [[],[]] .smaller = true := by decide
def e1211182216646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211182216646 : Closed e1211182216646 ∧ code e1211182216646 = 5609228727750 := by decide
theorem cert_e1211182216646 : check e1211182216646 [[],[]] .smaller = true := by decide
def e1211182216670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211182216670 : Closed e1211182216670 ∧ code e1211182216670 = 5609228727774 := by decide
theorem cert_e1211182216670 : check e1211182216670 [[],[]] .smaller = true := by decide
def e1211182216686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211182216686 : Closed e1211182216686 ∧ code e1211182216686 = 5609228727790 := by decide
theorem cert_e1211182216686 : check e1211182216686 [[],[]] .smaller = true := by decide
def e1211182216758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211182216758 : Closed e1211182216758 ∧ code e1211182216758 = 5609228727862 := by decide
theorem cert_e1211182216758 : check e1211182216758 [[],[]] .smaller = true := by decide
def e1211182216762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211182216762 : Closed e1211182216762 ∧ code e1211182216762 = 5609228727866 := by decide
theorem cert_e1211182216762 : check e1211182216762 [[],[]] .smaller = true := by decide
def e1211182216810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211182216810 : Closed e1211182216810 ∧ code e1211182216810 = 5609228727914 := by decide
theorem cert_e1211182216810 : check e1211182216810 [[],[]] .smaller = true := by decide
def e1211182216846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211182216846 : Closed e1211182216846 ∧ code e1211182216846 = 5609228727950 := by decide
theorem cert_e1211182216846 : check e1211182216846 [[],[]] .smaller = true := by decide
def e1211182216858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182216858 : Closed e1211182216858 ∧ code e1211182216858 = 5609228727962 := by decide
theorem cert_e1211182216858 : check e1211182216858 [[],[]] .smaller = true := by decide
def e1211182216902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211182216902 : Closed e1211182216902 ∧ code e1211182216902 = 5609228728006 := by decide
theorem cert_e1211182216902 : check e1211182216902 [[],[]] .smaller = true := by decide
def e1211182216942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1211182216942 : Closed e1211182216942 ∧ code e1211182216942 = 5609228728046 := by decide
theorem cert_e1211182216942 : check e1211182216942 [[],[]] .smaller = true := by decide
def e1211182216986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211182216986 : Closed e1211182216986 ∧ code e1211182216986 = 5609228728090 := by decide
theorem cert_e1211182216986 : check e1211182216986 [[],[]] .smaller = true := by decide
def e1211182217030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211182217030 : Closed e1211182217030 ∧ code e1211182217030 = 5609228728134 := by decide
theorem cert_e1211182217030 : check e1211182217030 [[],[]] .smaller = true := by decide
def e1211182217054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211182217054 : Closed e1211182217054 ∧ code e1211182217054 = 5609228728158 := by decide
theorem cert_e1211182217054 : check e1211182217054 [[],[]] .smaller = true := by decide
def e1211182217070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1211182217070 : Closed e1211182217070 ∧ code e1211182217070 = 5609228728174 := by decide
theorem cert_e1211182217070 : check e1211182217070 [[],[]] .smaller = true := by decide
def e1211182217078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1211182217078 : Closed e1211182217078 ∧ code e1211182217078 = 5609228728182 := by decide
theorem cert_e1211182217078 : check e1211182217078 [[],[]] .smaller = true := by decide
def e1211182217082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211182217082 : Closed e1211182217082 ∧ code e1211182217082 = 5609228728186 := by decide
theorem cert_e1211182217082 : check e1211182217082 [[],[]] .smaller = true := by decide
def e1211182217134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211182217134 : Closed e1211182217134 ∧ code e1211182217134 = 5609228728238 := by decide
theorem cert_e1211182217134 : check e1211182217134 [[],[]] .smaller = true := by decide
def e1211182217146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211182217146 : Closed e1211182217146 ∧ code e1211182217146 = 5609228728250 := by decide
theorem cert_e1211182217146 : check e1211182217146 [[],[]] .smaller = true := by decide
def e1211182217430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211182217430 : Closed e1211182217430 ∧ code e1211182217430 = 5609228728534 := by decide
theorem cert_e1211182217430 : check e1211182217430 [[],[]] .three = true := by decide
def e1211182217434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211182217434 : Closed e1211182217434 ∧ code e1211182217434 = 5609228728538 := by decide
theorem cert_e1211182217434 : check e1211182217434 [[],[]] .three = true := by decide
def e1211182217450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211182217450 : Closed e1211182217450 ∧ code e1211182217450 = 5609228728554 := by decide
theorem cert_e1211182217450 : check e1211182217450 [[],[]] .three = true := by decide
def e1211182217782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211182217782 : Closed e1211182217782 ∧ code e1211182217782 = 5609228728886 := by decide
theorem cert_e1211182217782 : check e1211182217782 [[],[]] .three = true := by decide
def e1211182217786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211182217786 : Closed e1211182217786 ∧ code e1211182217786 = 5609228728890 := by decide
theorem cert_e1211182217786 : check e1211182217786 [[],[]] .three = true := by decide
def e1211182217870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211182217870 : Closed e1211182217870 ∧ code e1211182217870 = 5609228728974 := by decide
theorem cert_e1211182217870 : check e1211182217870 [[],[]] .three = true := by decide
def e1211182217926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211182217926 : Closed e1211182217926 ∧ code e1211182217926 = 5609228729030 := by decide
theorem cert_e1211182217926 : check e1211182217926 [[],[]] .three = true := by decide
def e1211182217966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e1211182217966 : Closed e1211182217966 ∧ code e1211182217966 = 5609228729070 := by decide
theorem cert_e1211182217966 : check e1211182217966 [[],[]] .three = true := by decide
def e1211182218010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211182218010 : Closed e1211182218010 ∧ code e1211182218010 = 5609228729114 := by decide
theorem cert_e1211182218010 : check e1211182218010 [[],[]] .three = true := by decide
def e1211182218054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211182218054 : Closed e1211182218054 ∧ code e1211182218054 = 5609228729158 := by decide
theorem cert_e1211182218054 : check e1211182218054 [[],[]] .three = true := by decide
def e1211182218094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211182218094 : Closed e1211182218094 ∧ code e1211182218094 = 5609228729198 := by decide
theorem cert_e1211182218094 : check e1211182218094 [[],[]] .three = true := by decide
def e1211182218102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211182218102 : Closed e1211182218102 ∧ code e1211182218102 = 5609228729206 := by decide
theorem cert_e1211182218102 : check e1211182218102 [[],[]] .three = true := by decide
def e1211182218158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e1211182218158 : Closed e1211182218158 ∧ code e1211182218158 = 5609228729262 := by decide
theorem cert_e1211182218158 : check e1211182218158 [[],[]] .three = true := by decide
def e1211182218166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211182218166 : Closed e1211182218166 ∧ code e1211182218166 = 5609228729270 := by decide
theorem cert_e1211182218166 : check e1211182218166 [[],[]] .three = true := by decide
def e1211182218170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e1211182218170 : Closed e1211182218170 ∧ code e1211182218170 = 5609228729274 := by decide
theorem cert_e1211182218170 : check e1211182218170 [[],[]] .three = true := by decide
def e1211182226910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 3))))))))
theorem wire_e1211182226910 : Closed e1211182226910 ∧ code e1211182226910 = 5609228738014 := by decide
theorem cert_e1211182226910 : check e1211182226910 [[],[]] .smaller = true := by decide
def e1211182226934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.var 1))))))))
theorem wire_e1211182226934 : Closed e1211182226934 ∧ code e1211182226934 = 5609228738038 := by decide
theorem cert_e1211182226934 : check e1211182226934 [[],[]] .smaller = true := by decide
def e1211182227166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 3))))))))
theorem wire_e1211182227166 : Closed e1211182227166 ∧ code e1211182227166 = 5609228738270 := by decide
theorem cert_e1211182227166 : check e1211182227166 [[],[]] .smaller = true := by decide
def e1211182227182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))))
theorem wire_e1211182227182 : Closed e1211182227182 ∧ code e1211182227182 = 5609228738286 := by decide
theorem cert_e1211182227182 : check e1211182227182 [[],[]] .smaller = true := by decide
def e1211182227190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))))
theorem wire_e1211182227190 : Closed e1211182227190 ∧ code e1211182227190 = 5609228738294 := by decide
theorem cert_e1211182227190 : check e1211182227190 [[],[]] .smaller = true := by decide
def e1211182227194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 0))))))))
theorem wire_e1211182227194 : Closed e1211182227194 ∧ code e1211182227194 = 5609228738298 := by decide
theorem cert_e1211182227194 : check e1211182227194 [[],[]] .smaller = true := by decide
def e1211182227318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))))
theorem wire_e1211182227318 : Closed e1211182227318 ∧ code e1211182227318 = 5609228738422 := by decide
theorem cert_e1211182227318 : check e1211182227318 [[],[]] .smaller = true := by decide
def e1211182227382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.var 1))))))))
theorem wire_e1211182227382 : Closed e1211182227382 ∧ code e1211182227382 = 5609228738486 := by decide
theorem cert_e1211182227382 : check e1211182227382 [[],[]] .smaller = true := by decide
def e1211182227386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 0))))))))
theorem wire_e1211182227386 : Closed e1211182227386 ∧ code e1211182227386 = 5609228738490 := by decide
theorem cert_e1211182227386 : check e1211182227386 [[],[]] .smaller = true := by decide
def e1211182232510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 4)))))))))
theorem wire_e1211182232510 : Closed e1211182232510 ∧ code e1211182232510 = 5609228743614 := by decide
theorem cert_e1211182232510 : check e1211182232510 [[],[]] .three = true := by decide
def e1211182232542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211182232542 : Closed e1211182232542 ∧ code e1211182232542 = 5609228743646 := by decide
theorem cert_e1211182232542 : check e1211182232542 [[],[]] .smaller = true := by decide
def e1211182232558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211182232558 : Closed e1211182232558 ∧ code e1211182232558 = 5609228743662 := by decide
theorem cert_e1211182232558 : check e1211182232558 [[],[]] .smaller = true := by decide
def e1211182232566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 4) (.var 1)))))))))
theorem wire_e1211182232566 : Closed e1211182232566 ∧ code e1211182232566 = 5609228743670 := by decide
theorem cert_e1211182232566 : check e1211182232566 [[],[]] .three = true := by decide
def e1211182234046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 4)))))))))
theorem wire_e1211182234046 : Closed e1211182234046 ∧ code e1211182234046 = 5609228745150 := by decide
theorem cert_e1211182234046 : check e1211182234046 [[],[]] .three = true := by decide
def e1211182234078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211182234078 : Closed e1211182234078 ∧ code e1211182234078 = 5609228745182 := by decide
theorem cert_e1211182234078 : check e1211182234078 [[],[]] .smaller = true := by decide
def e1211182234094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182234094 : Closed e1211182234094 ∧ code e1211182234094 = 5609228745198 := by decide
theorem cert_e1211182234094 : check e1211182234094 [[],[]] .smaller = true := by decide
def e1211182234102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211182234102 : Closed e1211182234102 ∧ code e1211182234102 = 5609228745206 := by decide
theorem cert_e1211182234102 : check e1211182234102 [[],[]] .smaller = true := by decide
def e1211182234106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 4) (.var 0)))))))))
theorem wire_e1211182234106 : Closed e1211182234106 ∧ code e1211182234106 = 5609228745210 := by decide
theorem cert_e1211182234106 : check e1211182234106 [[],[]] .three = true := by decide
def e1211182234846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182234846 : Closed e1211182234846 ∧ code e1211182234846 = 5609228745950 := by decide
theorem cert_e1211182234846 : check e1211182234846 [[],[]] .smaller = true := by decide
def e1211182234862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182234862 : Closed e1211182234862 ∧ code e1211182234862 = 5609228745966 := by decide
theorem cert_e1211182234862 : check e1211182234862 [[],[]] .smaller = true := by decide
def e1211182234870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182234870 : Closed e1211182234870 ∧ code e1211182234870 = 5609228745974 := by decide
theorem cert_e1211182234870 : check e1211182234870 [[],[]] .smaller = true := by decide
def e1211182234874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182234874 : Closed e1211182234874 ∧ code e1211182234874 = 5609228745978 := by decide
theorem cert_e1211182234874 : check e1211182234874 [[],[]] .smaller = true := by decide
def e1211182235246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182235246 : Closed e1211182235246 ∧ code e1211182235246 = 5609228746350 := by decide
theorem cert_e1211182235246 : check e1211182235246 [[],[]] .smaller = true := by decide
def e1211182235254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182235254 : Closed e1211182235254 ∧ code e1211182235254 = 5609228746358 := by decide
theorem cert_e1211182235254 : check e1211182235254 [[],[]] .smaller = true := by decide
def e1211182235258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182235258 : Closed e1211182235258 ∧ code e1211182235258 = 5609228746362 := by decide
theorem cert_e1211182235258 : check e1211182235258 [[],[]] .smaller = true := by decide
def e1211182235446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182235446 : Closed e1211182235446 ∧ code e1211182235446 = 5609228746550 := by decide
theorem cert_e1211182235446 : check e1211182235446 [[],[]] .three = true := by decide
def e1211182235450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182235450 : Closed e1211182235450 ∧ code e1211182235450 = 5609228746554 := by decide
theorem cert_e1211182235450 : check e1211182235450 [[],[]] .three = true := by decide
def e1211182242526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3))))))))
theorem wire_e1211182242526 : Closed e1211182242526 ∧ code e1211182242526 = 5609228753630 := by decide
theorem cert_e1211182242526 : check e1211182242526 [[],[]] .smaller = true := by decide
end Blc.Floor42
