import Tables
import Batch175
namespace Blc.Floor42.Grades175
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211202155382 : ¬ IsSelfInterpreter e1211202155382 := cutM11_2 (by decide)
#print axioms ex_e1211202155382
end Blc.Floor42.Grades175
