import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209571768718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1209571768718 : Closed e1209571768718 ∧ code e1209571768718 = 5607618279822 := by decide
theorem cert_e1209571768718 : check e1209571768718 [[],[]] .smaller = true := by decide
def e1209571768774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1209571768774 : Closed e1209571768774 ∧ code e1209571768774 = 5607618279878 := by decide
theorem cert_e1209571768774 : check e1209571768774 [[],[]] .smaller = true := by decide
def e1209571768798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209571768798 : Closed e1209571768798 ∧ code e1209571768798 = 5607618279902 := by decide
theorem cert_e1209571768798 : checkPay e1209571768798 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 0 [[],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left],[],[.under,.right,.under]] = true := by decide
def e1209571768822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209571768822 : Closed e1209571768822 ∧ code e1209571768822 = 5607618279926 := by decide
theorem cert_e1209571768822 : checkPay e1209571768822 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 0 [[.left],[],[.under,.right,.under],[.under,.right,.under,.left,.left],[.under,.right,.under,.left],[.under,.right,.under],[.under,.right,.under],[.under,.right,.under,.left],[.under,.right,.under,.left],[.under,.right,.under]] = true := by decide
def e1209571769582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209571769582 : Closed e1209571769582 ∧ code e1209571769582 = 5607618280686 := by decide
theorem cert_e1209571769582 : check e1209571769582 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e1209571769590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209571769590 : Closed e1209571769590 ∧ code e1209571769590 = 5607618280694 := by decide
theorem cert_e1209571769590 : check e1209571769590 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e1209571826542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1209571826542 : Closed e1209571826542 ∧ code e1209571826542 = 5607618337646 := by decide
theorem cert_e1209571826542 : check e1209571826542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571826550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1209571826550 : Closed e1209571826550 ∧ code e1209571826550 = 5607618337654 := by decide
theorem cert_e1209571826550 : check e1209571826550 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571826614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1209571826614 : Closed e1209571826614 ∧ code e1209571826614 = 5607618337718 := by decide
theorem cert_e1209571826614 : check e1209571826614 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571827054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209571827054 : Closed e1209571827054 ∧ code e1209571827054 = 5607618338158 := by decide
theorem cert_e1209571827054 : check e1209571827054 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209571827062 : Closed e1209571827062 ∧ code e1209571827062 = 5607618338166 := by decide
theorem cert_e1209571827062 : check e1209571827062 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209571827118 : Closed e1209571827118 ∧ code e1209571827118 = 5607618338222 := by decide
theorem cert_e1209571827118 : check e1209571827118 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209571827130 : Closed e1209571827130 ∧ code e1209571827130 = 5607618338234 := by decide
theorem cert_e1209571827130 : check e1209571827130 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209571827158 : Closed e1209571827158 ∧ code e1209571827158 = 5607618338262 := by decide
theorem cert_e1209571827158 : check e1209571827158 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209571827162 : Closed e1209571827162 ∧ code e1209571827162 = 5607618338266 := by decide
theorem cert_e1209571827162 : check e1209571827162 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571827382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1209571827382 : Closed e1209571827382 ∧ code e1209571827382 = 5607618338486 := by decide
theorem cert_e1209571827382 : check e1209571827382 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571827414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1209571827414 : Closed e1209571827414 ∧ code e1209571827414 = 5607618338518 := by decide
theorem cert_e1209571827414 : check e1209571827414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571827418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1209571827418 : Closed e1209571827418 ∧ code e1209571827418 = 5607618338522 := by decide
theorem cert_e1209571827418 : check e1209571827418 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571829614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1209571829614 : Closed e1209571829614 ∧ code e1209571829614 = 5607618340718 := by decide
theorem cert_e1209571829614 : check e1209571829614 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571829622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1209571829622 : Closed e1209571829622 ∧ code e1209571829622 = 5607618340726 := by decide
theorem cert_e1209571829622 : check e1209571829622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571829686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1209571829686 : Closed e1209571829686 ∧ code e1209571829686 = 5607618340790 := by decide
theorem cert_e1209571829686 : check e1209571829686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209571831022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209571831022 : Closed e1209571831022 ∧ code e1209571831022 = 5607618342126 := by decide
theorem cert_e1209571831022 : check e1209571831022 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571831030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209571831030 : Closed e1209571831030 ∧ code e1209571831030 = 5607618342134 := by decide
theorem cert_e1209571831030 : check e1209571831030 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571831414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209571831414 : Closed e1209571831414 ∧ code e1209571831414 = 5607618342518 := by decide
theorem cert_e1209571831414 : checkPay e1209571831414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e1209571832302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1209571832302 : Closed e1209571832302 ∧ code e1209571832302 = 5607618343406 := by decide
theorem cert_e1209571832302 : check e1209571832302 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209571832686 : Closed e1209571832686 ∧ code e1209571832686 = 5607618343790 := by decide
theorem cert_e1209571832686 : check e1209571832686 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209571832694 : Closed e1209571832694 ∧ code e1209571832694 = 5607618343798 := by decide
theorem cert_e1209571832694 : check e1209571832694 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209571832750 : Closed e1209571832750 ∧ code e1209571832750 = 5607618343854 := by decide
theorem cert_e1209571832750 : check e1209571832750 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209571832762 : Closed e1209571832762 ∧ code e1209571832762 = 5607618343866 := by decide
theorem cert_e1209571832762 : check e1209571832762 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209571832790 : Closed e1209571832790 ∧ code e1209571832790 = 5607618343894 := by decide
theorem cert_e1209571832790 : check e1209571832790 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571832794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209571832794 : Closed e1209571832794 ∧ code e1209571832794 = 5607618343898 := by decide
theorem cert_e1209571832794 : check e1209571832794 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209571833070 : Closed e1209571833070 ∧ code e1209571833070 = 5607618344174 := by decide
theorem cert_e1209571833070 : check e1209571833070 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209571833078 : Closed e1209571833078 ∧ code e1209571833078 = 5607618344182 := by decide
theorem cert_e1209571833078 : check e1209571833078 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209571833454 : Closed e1209571833454 ∧ code e1209571833454 = 5607618344558 := by decide
theorem cert_e1209571833454 : check e1209571833454 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209571833466 : Closed e1209571833466 ∧ code e1209571833466 = 5607618344570 := by decide
theorem cert_e1209571833466 : check e1209571833466 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1209571833630 : Closed e1209571833630 ∧ code e1209571833630 = 5607618344734 := by decide
theorem cert_e1209571833630 : check e1209571833630 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571833654 : Closed e1209571833654 ∧ code e1209571833654 = 5607618344758 := by decide
theorem cert_e1209571833654 : check e1209571833654 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571833658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571833658 : Closed e1209571833658 ∧ code e1209571833658 = 5607618344762 := by decide
theorem cert_e1209571833658 : check e1209571833658 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571834094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209571834094 : Closed e1209571834094 ∧ code e1209571834094 = 5607618345198 := by decide
theorem cert_e1209571834094 : check e1209571834094 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209571834102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209571834102 : Closed e1209571834102 ∧ code e1209571834102 = 5607618345206 := by decide
theorem cert_e1209571834102 : check e1209571834102 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1209571834294 : Closed e1209571834294 ∧ code e1209571834294 = 5607618345398 := by decide
theorem cert_e1209571834294 : check e1209571834294 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1209571834326 : Closed e1209571834326 ∧ code e1209571834326 = 5607618345430 := by decide
theorem cert_e1209571834326 : check e1209571834326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1209571834330 : Closed e1209571834330 ∧ code e1209571834330 = 5607618345434 := by decide
theorem cert_e1209571834330 : check e1209571834330 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209571834486 : Closed e1209571834486 ∧ code e1209571834486 = 5607618345590 := by decide
theorem cert_e1209571834486 : check e1209571834486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209571834654 : Closed e1209571834654 ∧ code e1209571834654 = 5607618345758 := by decide
theorem cert_e1209571834654 : check e1209571834654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209571834678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571834678 : Closed e1209571834678 ∧ code e1209571834678 = 5607618345782 := by decide
theorem cert_e1209571834678 : check e1209571834678 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571834682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571834682 : Closed e1209571834682 ∧ code e1209571834682 = 5607618345786 := by decide
theorem cert_e1209571834682 : check e1209571834682 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571834766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209571834766 : Closed e1209571834766 ∧ code e1209571834766 = 5607618345870 := by decide
theorem cert_e1209571834766 : checkPay e1209571834766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e1209571841902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1209571841902 : Closed e1209571841902 ∧ code e1209571841902 = 5607618353006 := by decide
theorem cert_e1209571841902 : check e1209571841902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1209571841910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1209571841910 : Closed e1209571841910 ∧ code e1209571841910 = 5607618353014 := by decide
theorem cert_e1209571841910 : check e1209571841910 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1209571841974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1209571841974 : Closed e1209571841974 ∧ code e1209571841974 = 5607618353078 := by decide
theorem cert_e1209571841974 : check e1209571841974 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571843310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209571843310 : Closed e1209571843310 ∧ code e1209571843310 = 5607618354414 := by decide
theorem cert_e1209571843310 : check e1209571843310 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1209571843318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209571843318 : Closed e1209571843318 ∧ code e1209571843318 = 5607618354422 := by decide
theorem cert_e1209571843318 : check e1209571843318 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1209571843702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209571843702 : Closed e1209571843702 ∧ code e1209571843702 = 5607618354806 := by decide
theorem cert_e1209571843702 : check e1209571843702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1209571853278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1209571853278 : Closed e1209571853278 ∧ code e1209571853278 = 5607618364382 := by decide
theorem cert_e1209571853278 : check e1209571853278 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571853294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1209571853294 : Closed e1209571853294 ∧ code e1209571853294 = 5607618364398 := by decide
theorem cert_e1209571853294 : check e1209571853294 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209571855214 : Closed e1209571855214 ∧ code e1209571855214 = 5607618366318 := by decide
theorem cert_e1209571855214 : check e1209571855214 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209571855222 : Closed e1209571855222 ∧ code e1209571855222 = 5607618366326 := by decide
theorem cert_e1209571855222 : check e1209571855222 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209571855278 : Closed e1209571855278 ∧ code e1209571855278 = 5607618366382 := by decide
theorem cert_e1209571855278 : check e1209571855278 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209571855290 : Closed e1209571855290 ∧ code e1209571855290 = 5607618366394 := by decide
theorem cert_e1209571855290 : check e1209571855290 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209571855318 : Closed e1209571855318 ∧ code e1209571855318 = 5607618366422 := by decide
theorem cert_e1209571855318 : check e1209571855318 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209571855322 : Closed e1209571855322 ∧ code e1209571855322 = 5607618366426 := by decide
theorem cert_e1209571855322 : check e1209571855322 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209571855598 : Closed e1209571855598 ∧ code e1209571855598 = 5607618366702 := by decide
theorem cert_e1209571855598 : check e1209571855598 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209571855606 : Closed e1209571855606 ∧ code e1209571855606 = 5607618366710 := by decide
theorem cert_e1209571855606 : check e1209571855606 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209571855982 : Closed e1209571855982 ∧ code e1209571855982 = 5607618367086 := by decide
theorem cert_e1209571855982 : check e1209571855982 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571855994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209571855994 : Closed e1209571855994 ∧ code e1209571855994 = 5607618367098 := by decide
theorem cert_e1209571855994 : check e1209571855994 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571856158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1209571856158 : Closed e1209571856158 ∧ code e1209571856158 = 5607618367262 := by decide
theorem cert_e1209571856158 : check e1209571856158 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571856182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209571856182 : Closed e1209571856182 ∧ code e1209571856182 = 5607618367286 := by decide
theorem cert_e1209571856182 : check e1209571856182 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571856186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209571856186 : Closed e1209571856186 ∧ code e1209571856186 = 5607618367290 := by decide
theorem cert_e1209571856186 : check e1209571856186 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571860974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1209571860974 : Closed e1209571860974 ∧ code e1209571860974 = 5607618372078 := by decide
theorem cert_e1209571860974 : check e1209571860974 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571861942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1209571861942 : Closed e1209571861942 ∧ code e1209571861942 = 5607618373046 := by decide
theorem cert_e1209571861942 : check e1209571861942 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571861974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1209571861974 : Closed e1209571861974 ∧ code e1209571861974 = 5607618373078 := by decide
theorem cert_e1209571861974 : check e1209571861974 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571861978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1209571861978 : Closed e1209571861978 ∧ code e1209571861978 = 5607618373082 := by decide
theorem cert_e1209571861978 : check e1209571861978 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571862134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209571862134 : Closed e1209571862134 ∧ code e1209571862134 = 5607618373238 := by decide
theorem cert_e1209571862134 : check e1209571862134 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571862302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209571862302 : Closed e1209571862302 ∧ code e1209571862302 = 5607618373406 := by decide
theorem cert_e1209571862302 : check e1209571862302 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571862326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209571862326 : Closed e1209571862326 ∧ code e1209571862326 = 5607618373430 := by decide
theorem cert_e1209571862326 : check e1209571862326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571862330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209571862330 : Closed e1209571862330 ∧ code e1209571862330 = 5607618373434 := by decide
theorem cert_e1209571862330 : check e1209571862330 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209571862414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209571862414 : Closed e1209571862414 ∧ code e1209571862414 = 5607618373518 := by decide
theorem cert_e1209571862414 : check e1209571862414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209572011486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1209572011486 : Closed e1209572011486 ∧ code e1209572011486 = 5607618522590 := by decide
theorem cert_e1209572011486 : check e1209572011486 [[],[]] .sourceHead = true := by decide
def e1209572011502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1209572011502 : Closed e1209572011502 ∧ code e1209572011502 = 5607618522606 := by decide
theorem cert_e1209572011502 : check e1209572011502 [[],[]] .sourceHead = true := by decide
def e1209572011742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1209572011742 : Closed e1209572011742 ∧ code e1209572011742 = 5607618522846 := by decide
theorem cert_e1209572011742 : check e1209572011742 [[],[]] .sourceHead = true := by decide
def e1209572011766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1209572011766 : Closed e1209572011766 ∧ code e1209572011766 = 5607618522870 := by decide
theorem cert_e1209572011766 : check e1209572011766 [[],[]] .sourceHead = true := by decide
def e1209572011870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1209572011870 : Closed e1209572011870 ∧ code e1209572011870 = 5607618522974 := by decide
theorem cert_e1209572011870 : check e1209572011870 [[],[]] .sourceHead = true := by decide
def e1209572011898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1209572011898 : Closed e1209572011898 ∧ code e1209572011898 = 5607618523002 := by decide
theorem cert_e1209572011898 : check e1209572011898 [[],[]] .sourceHead = true := by decide
def e1209572011950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1209572011950 : Closed e1209572011950 ∧ code e1209572011950 = 5607618523054 := by decide
theorem cert_e1209572011950 : check e1209572011950 [[],[]] .sourceHead = true := by decide
def e1209572011958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1209572011958 : Closed e1209572011958 ∧ code e1209572011958 = 5607618523062 := by decide
theorem cert_e1209572011958 : check e1209572011958 [[],[]] .sourceHead = true := by decide
def e1209572011962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1209572011962 : Closed e1209572011962 ∧ code e1209572011962 = 5607618523066 := by decide
theorem cert_e1209572011962 : check e1209572011962 [[],[]] .sourceHead = true := by decide
def e1209572013022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1209572013022 : Closed e1209572013022 ∧ code e1209572013022 = 5607618524126 := by decide
theorem cert_e1209572013022 : check e1209572013022 [[],[]] .sourceHead = true := by decide
def e1209572013038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1209572013038 : Closed e1209572013038 ∧ code e1209572013038 = 5607618524142 := by decide
theorem cert_e1209572013038 : check e1209572013038 [[],[]] .sourceHead = true := by decide
def e1209572014558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209572014558 : Closed e1209572014558 ∧ code e1209572014558 = 5607618525662 := by decide
theorem cert_e1209572014558 : check e1209572014558 [[],[]] .sourceHead = true := by decide
def e1209572014582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209572014582 : Closed e1209572014582 ∧ code e1209572014582 = 5607618525686 := by decide
theorem cert_e1209572014582 : check e1209572014582 [[],[]] .sourceHead = true := by decide
def e1209572015326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209572015326 : Closed e1209572015326 ∧ code e1209572015326 = 5607618526430 := by decide
theorem cert_e1209572015326 : check e1209572015326 [[],[]] .sourceHead = true := by decide
def e1209572015354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209572015354 : Closed e1209572015354 ∧ code e1209572015354 = 5607618526458 := by decide
theorem cert_e1209572015354 : check e1209572015354 [[],[]] .sourceHead = true := by decide
def e1209572015726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209572015726 : Closed e1209572015726 ∧ code e1209572015726 = 5607618526830 := by decide
theorem cert_e1209572015726 : check e1209572015726 [[],[]] .sourceHead = true := by decide
def e1209572015734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209572015734 : Closed e1209572015734 ∧ code e1209572015734 = 5607618526838 := by decide
theorem cert_e1209572015734 : check e1209572015734 [[],[]] .sourceHead = true := by decide
def e1209572015738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209572015738 : Closed e1209572015738 ∧ code e1209572015738 = 5607618526842 := by decide
theorem cert_e1209572015738 : check e1209572015738 [[],[]] .sourceHead = true := by decide
def e1209572044142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209572044142 : Closed e1209572044142 ∧ code e1209572044142 = 5607618555246 := by decide
theorem cert_e1209572044142 : check e1209572044142 [[],[]] .sourceHead = true := by decide
def e1209572044150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209572044150 : Closed e1209572044150 ∧ code e1209572044150 = 5607618555254 := by decide
theorem cert_e1209572044150 : check e1209572044150 [[],[]] .sourceHead = true := by decide
def e1209572044206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209572044206 : Closed e1209572044206 ∧ code e1209572044206 = 5607618555310 := by decide
theorem cert_e1209572044206 : check e1209572044206 [[],[]] .sourceHead = true := by decide
def e1209572044218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209572044218 : Closed e1209572044218 ∧ code e1209572044218 = 5607618555322 := by decide
theorem cert_e1209572044218 : check e1209572044218 [[],[]] .sourceHead = true := by decide
def e1209572044246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209572044246 : Closed e1209572044246 ∧ code e1209572044246 = 5607618555350 := by decide
theorem cert_e1209572044246 : check e1209572044246 [[],[]] .sourceHead = true := by decide
def e1209572044250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209572044250 : Closed e1209572044250 ∧ code e1209572044250 = 5607618555354 := by decide
theorem cert_e1209572044250 : check e1209572044250 [[],[]] .sourceHead = true := by decide
def e1209572044462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1209572044462 : Closed e1209572044462 ∧ code e1209572044462 = 5607618555566 := by decide
theorem cert_e1209572044462 : check e1209572044462 [[],[]] .sourceHead = true := by decide
def e1209572044474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1209572044474 : Closed e1209572044474 ∧ code e1209572044474 = 5607618555578 := by decide
theorem cert_e1209572044474 : check e1209572044474 [[],[]] .sourceHead = true := by decide
def e1209572044522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1209572044522 : Closed e1209572044522 ∧ code e1209572044522 = 5607618555626 := by decide
theorem cert_e1209572044522 : check e1209572044522 [[],[]] .sourceHead = true := by decide
def e1209572044630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1209572044630 : Closed e1209572044630 ∧ code e1209572044630 = 5607618555734 := by decide
theorem cert_e1209572044630 : check e1209572044630 [[],[]] .sourceHead = true := by decide
def e1209572044634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1209572044634 : Closed e1209572044634 ∧ code e1209572044634 = 5607618555738 := by decide
theorem cert_e1209572044634 : check e1209572044634 [[],[]] .sourceHead = true := by decide
def e1209572044650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1209572044650 : Closed e1209572044650 ∧ code e1209572044650 = 5607618555754 := by decide
theorem cert_e1209572044650 : check e1209572044650 [[],[]] .sourceHead = true := by decide
def e1209572045294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1209572045294 : Closed e1209572045294 ∧ code e1209572045294 = 5607618556398 := by decide
theorem cert_e1209572045294 : check e1209572045294 [[],[]] .sourceHead = true := by decide
def e1209572045678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209572045678 : Closed e1209572045678 ∧ code e1209572045678 = 5607618556782 := by decide
theorem cert_e1209572045678 : check e1209572045678 [[],[]] .sourceHead = true := by decide
def e1209572045686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209572045686 : Closed e1209572045686 ∧ code e1209572045686 = 5607618556790 := by decide
theorem cert_e1209572045686 : check e1209572045686 [[],[]] .sourceHead = true := by decide
def e1209572045742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209572045742 : Closed e1209572045742 ∧ code e1209572045742 = 5607618556846 := by decide
theorem cert_e1209572045742 : check e1209572045742 [[],[]] .sourceHead = true := by decide
def e1209572045754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209572045754 : Closed e1209572045754 ∧ code e1209572045754 = 5607618556858 := by decide
theorem cert_e1209572045754 : check e1209572045754 [[],[]] .sourceHead = true := by decide
def e1209572045782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209572045782 : Closed e1209572045782 ∧ code e1209572045782 = 5607618556886 := by decide
theorem cert_e1209572045782 : check e1209572045782 [[],[]] .sourceHead = true := by decide
def e1209572045786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209572045786 : Closed e1209572045786 ∧ code e1209572045786 = 5607618556890 := by decide
theorem cert_e1209572045786 : check e1209572045786 [[],[]] .sourceHead = true := by decide
def e1209572046062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209572046062 : Closed e1209572046062 ∧ code e1209572046062 = 5607618557166 := by decide
theorem cert_e1209572046062 : check e1209572046062 [[],[]] .sourceHead = true := by decide
def e1209572046070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209572046070 : Closed e1209572046070 ∧ code e1209572046070 = 5607618557174 := by decide
theorem cert_e1209572046070 : check e1209572046070 [[],[]] .sourceHead = true := by decide
def e1209572046446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209572046446 : Closed e1209572046446 ∧ code e1209572046446 = 5607618557550 := by decide
theorem cert_e1209572046446 : check e1209572046446 [[],[]] .sourceHead = true := by decide
def e1209572046458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209572046458 : Closed e1209572046458 ∧ code e1209572046458 = 5607618557562 := by decide
theorem cert_e1209572046458 : check e1209572046458 [[],[]] .sourceHead = true := by decide
def e1209572046622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1209572046622 : Closed e1209572046622 ∧ code e1209572046622 = 5607618557726 := by decide
theorem cert_e1209572046622 : check e1209572046622 [[],[]] .sourceHead = true := by decide
def e1209572046646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209572046646 : Closed e1209572046646 ∧ code e1209572046646 = 5607618557750 := by decide
theorem cert_e1209572046646 : check e1209572046646 [[],[]] .sourceHead = true := by decide
def e1209572046650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209572046650 : Closed e1209572046650 ∧ code e1209572046650 = 5607618557754 := by decide
theorem cert_e1209572046650 : check e1209572046650 [[],[]] .sourceHead = true := by decide
def e1209572047278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1209572047278 : Closed e1209572047278 ∧ code e1209572047278 = 5607618558382 := by decide
theorem cert_e1209572047278 : check e1209572047278 [[],[]] .sourceHead = true := by decide
def e1209572047290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1209572047290 : Closed e1209572047290 ∧ code e1209572047290 = 5607618558394 := by decide
theorem cert_e1209572047290 : check e1209572047290 [[],[]] .sourceHead = true := by decide
def e1209572047338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1209572047338 : Closed e1209572047338 ∧ code e1209572047338 = 5607618558442 := by decide
theorem cert_e1209572047338 : check e1209572047338 [[],[]] .sourceHead = true := by decide
def e1209572047470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209572047470 : Closed e1209572047470 ∧ code e1209572047470 = 5607618558574 := by decide
theorem cert_e1209572047470 : check e1209572047470 [[],[]] .sourceHead = true := by decide
def e1209572047482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209572047482 : Closed e1209572047482 ∧ code e1209572047482 = 5607618558586 := by decide
theorem cert_e1209572047482 : check e1209572047482 [[],[]] .sourceHead = true := by decide
def e1209572047770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209572047770 : Closed e1209572047770 ∧ code e1209572047770 = 5607618558874 := by decide
theorem cert_e1209572047770 : check e1209572047770 [[],[]] .sourceHead = true := by decide
def e1209572047982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209572047982 : Closed e1209572047982 ∧ code e1209572047982 = 5607618559086 := by decide
theorem cert_e1209572047982 : check e1209572047982 [[],[]] .sourceHead = true := by decide
def e1209572047994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209572047994 : Closed e1209572047994 ∧ code e1209572047994 = 5607618559098 := by decide
theorem cert_e1209572047994 : check e1209572047994 [[],[]] .sourceHead = true := by decide
def e1209572048086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1209572048086 : Closed e1209572048086 ∧ code e1209572048086 = 5607618559190 := by decide
theorem cert_e1209572048086 : check e1209572048086 [[],[]] .sourceHead = true := by decide
def e1209572048090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1209572048090 : Closed e1209572048090 ∧ code e1209572048090 = 5607618559194 := by decide
theorem cert_e1209572048090 : check e1209572048090 [[],[]] .sourceHead = true := by decide
def e1209572048106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1209572048106 : Closed e1209572048106 ∧ code e1209572048106 = 5607618559210 := by decide
theorem cert_e1209572048106 : check e1209572048106 [[],[]] .sourceHead = true := by decide
def e1209572048158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209572048158 : Closed e1209572048158 ∧ code e1209572048158 = 5607618559262 := by decide
theorem cert_e1209572048158 : check e1209572048158 [[],[]] .sourceHead = true := by decide
def e1209572048182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209572048182 : Closed e1209572048182 ∧ code e1209572048182 = 5607618559286 := by decide
theorem cert_e1209572048182 : check e1209572048182 [[],[]] .sourceHead = true := by decide
def e1209572048186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209572048186 : Closed e1209572048186 ∧ code e1209572048186 = 5607618559290 := by decide
theorem cert_e1209572048186 : check e1209572048186 [[],[]] .sourceHead = true := by decide
def e1209572048282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209572048282 : Closed e1209572048282 ∧ code e1209572048282 = 5607618559386 := by decide
theorem cert_e1209572048282 : check e1209572048282 [[],[]] .sourceHead = true := by decide
def e1209572048326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209572048326 : Closed e1209572048326 ∧ code e1209572048326 = 5607618559430 := by decide
theorem cert_e1209572048326 : check e1209572048326 [[],[]] .sourceHead = true := by decide
def e1209572049886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1209572049886 : Closed e1209572049886 ∧ code e1209572049886 = 5607618560990 := by decide
theorem cert_e1209572049886 : check e1209572049886 [[],[]] .sourceHead = true := by decide
def e1209572049902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1209572049902 : Closed e1209572049902 ∧ code e1209572049902 = 5607618561006 := by decide
theorem cert_e1209572049902 : check e1209572049902 [[],[]] .sourceHead = true := by decide
def e1209572051822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209572051822 : Closed e1209572051822 ∧ code e1209572051822 = 5607618562926 := by decide
theorem cert_e1209572051822 : check e1209572051822 [[],[]] .sourceHead = true := by decide
def e1209572051830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209572051830 : Closed e1209572051830 ∧ code e1209572051830 = 5607618562934 := by decide
theorem cert_e1209572051830 : check e1209572051830 [[],[]] .sourceHead = true := by decide
def e1209572051886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209572051886 : Closed e1209572051886 ∧ code e1209572051886 = 5607618562990 := by decide
theorem cert_e1209572051886 : check e1209572051886 [[],[]] .sourceHead = true := by decide
def e1209572051898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209572051898 : Closed e1209572051898 ∧ code e1209572051898 = 5607618563002 := by decide
theorem cert_e1209572051898 : check e1209572051898 [[],[]] .sourceHead = true := by decide
def e1209572051926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209572051926 : Closed e1209572051926 ∧ code e1209572051926 = 5607618563030 := by decide
theorem cert_e1209572051926 : check e1209572051926 [[],[]] .sourceHead = true := by decide
def e1209572051930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209572051930 : Closed e1209572051930 ∧ code e1209572051930 = 5607618563034 := by decide
theorem cert_e1209572051930 : check e1209572051930 [[],[]] .sourceHead = true := by decide
def e1209572052206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209572052206 : Closed e1209572052206 ∧ code e1209572052206 = 5607618563310 := by decide
theorem cert_e1209572052206 : check e1209572052206 [[],[]] .sourceHead = true := by decide
def e1209572052214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209572052214 : Closed e1209572052214 ∧ code e1209572052214 = 5607618563318 := by decide
theorem cert_e1209572052214 : check e1209572052214 [[],[]] .sourceHead = true := by decide
def e1209572052590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209572052590 : Closed e1209572052590 ∧ code e1209572052590 = 5607618563694 := by decide
theorem cert_e1209572052590 : check e1209572052590 [[],[]] .sourceHead = true := by decide
def e1209572052602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209572052602 : Closed e1209572052602 ∧ code e1209572052602 = 5607618563706 := by decide
theorem cert_e1209572052602 : check e1209572052602 [[],[]] .sourceHead = true := by decide
def e1209572052766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1209572052766 : Closed e1209572052766 ∧ code e1209572052766 = 5607618563870 := by decide
theorem cert_e1209572052766 : check e1209572052766 [[],[]] .sourceHead = true := by decide
def e1209572052790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209572052790 : Closed e1209572052790 ∧ code e1209572052790 = 5607618563894 := by decide
theorem cert_e1209572052790 : check e1209572052790 [[],[]] .sourceHead = true := by decide
def e1209572052794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209572052794 : Closed e1209572052794 ∧ code e1209572052794 = 5607618563898 := by decide
theorem cert_e1209572052794 : check e1209572052794 [[],[]] .sourceHead = true := by decide
def e1209572057566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1209572057566 : Closed e1209572057566 ∧ code e1209572057566 = 5607618568670 := by decide
theorem cert_e1209572057566 : check e1209572057566 [[],[]] .sourceHead = true := by decide
def e1209572057590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1209572057590 : Closed e1209572057590 ∧ code e1209572057590 = 5607618568694 := by decide
theorem cert_e1209572057590 : check e1209572057590 [[],[]] .sourceHead = true := by decide
def e1209572058542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1209572058542 : Closed e1209572058542 ∧ code e1209572058542 = 5607618569646 := by decide
theorem cert_e1209572058542 : check e1209572058542 [[],[]] .sourceHead = true := by decide
def e1209572058554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1209572058554 : Closed e1209572058554 ∧ code e1209572058554 = 5607618569658 := by decide
theorem cert_e1209572058554 : check e1209572058554 [[],[]] .sourceHead = true := by decide
def e1209572058602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1209572058602 : Closed e1209572058602 ∧ code e1209572058602 = 5607618569706 := by decide
theorem cert_e1209572058602 : check e1209572058602 [[],[]] .sourceHead = true := by decide
def e1209572058734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209572058734 : Closed e1209572058734 ∧ code e1209572058734 = 5607618569838 := by decide
theorem cert_e1209572058734 : check e1209572058734 [[],[]] .sourceHead = true := by decide
def e1209572058746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209572058746 : Closed e1209572058746 ∧ code e1209572058746 = 5607618569850 := by decide
theorem cert_e1209572058746 : check e1209572058746 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
