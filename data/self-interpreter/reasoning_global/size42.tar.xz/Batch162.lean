import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186965562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186965562 : Closed e1211186965562 ∧ code e1211186965562 = 5609233476666 := by decide
theorem cert_e1211186965562 : check e1211186965562 [[],[]] .smaller = true := by decide
def e1211186965702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186965702 : Closed e1211186965702 ∧ code e1211186965702 = 5609233476806 := by decide
theorem cert_e1211186965702 : check e1211186965702 [[],[]] .smaller = true := by decide
def e1211186965726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186965726 : Closed e1211186965726 ∧ code e1211186965726 = 5609233476830 := by decide
theorem cert_e1211186965726 : check e1211186965726 [[],[]] .three = true := by decide
def e1211186965730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186965730 : Closed e1211186965730 ∧ code e1211186965730 = 5609233476834 := by decide
theorem cert_e1211186965730 : check e1211186965730 [[],[]] .smaller = true := by decide
def e1211186965742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186965742 : Closed e1211186965742 ∧ code e1211186965742 = 5609233476846 := by decide
theorem cert_e1211186965742 : check e1211186965742 [[],[]] .smaller = true := by decide
def e1211186965750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186965750 : Closed e1211186965750 ∧ code e1211186965750 = 5609233476854 := by decide
theorem cert_e1211186965750 : check e1211186965750 [[],[]] .smaller = true := by decide
def e1211186965754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186965754 : Closed e1211186965754 ∧ code e1211186965754 = 5609233476858 := by decide
theorem cert_e1211186965754 : check e1211186965754 [[],[]] .three = true := by decide
def e1211186966078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 4))))))))
theorem wire_e1211186966078 : Closed e1211186966078 ∧ code e1211186966078 = 5609233477182 := by decide
theorem cert_e1211186966078 : check e1211186966078 [[],[]] .three = true := by decide
def e1211186966134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186966134 : Closed e1211186966134 ∧ code e1211186966134 = 5609233477238 := by decide
theorem cert_e1211186966134 : check e1211186966134 [[],[]] .smaller = true := by decide
def e1211186966302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 3))))))))
theorem wire_e1211186966302 : Closed e1211186966302 ∧ code e1211186966302 = 5609233477406 := by decide
theorem cert_e1211186966302 : check e1211186966302 [[],[]] .three = true := by decide
def e1211186966326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186966326 : Closed e1211186966326 ∧ code e1211186966326 = 5609233477430 := by decide
theorem cert_e1211186966326 : check e1211186966326 [[],[]] .three = true := by decide
def e1211186966330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186966330 : Closed e1211186966330 ∧ code e1211186966330 = 5609233477434 := by decide
theorem cert_e1211186966330 : check e1211186966330 [[],[]] .three = true := by decide
def e1211186966646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211186966646 : Closed e1211186966646 ∧ code e1211186966646 = 5609233477750 := by decide
theorem cert_e1211186966646 : check e1211186966646 [[],[]] .smaller = true := by decide
def e1211186966650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186966650 : Closed e1211186966650 ∧ code e1211186966650 = 5609233477754 := by decide
theorem cert_e1211186966650 : check e1211186966650 [[],[]] .smaller = true := by decide
def e1211186966746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e1211186966746 : Closed e1211186966746 ∧ code e1211186966746 = 5609233477850 := by decide
theorem cert_e1211186966746 : check e1211186966746 [[],[]] .smaller = true := by decide
def e1211186966762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e1211186966762 : Closed e1211186966762 ∧ code e1211186966762 = 5609233477866 := by decide
theorem cert_e1211186966762 : check e1211186966762 [[],[]] .smaller = true := by decide
def e1211186966838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186966838 : Closed e1211186966838 ∧ code e1211186966838 = 5609233477942 := by decide
theorem cert_e1211186966838 : check e1211186966838 [[],[]] .smaller = true := by decide
def e1211186966842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186966842 : Closed e1211186966842 ∧ code e1211186966842 = 5609233477946 := by decide
theorem cert_e1211186966842 : check e1211186966842 [[],[]] .smaller = true := by decide
def e1211186966926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211186966926 : Closed e1211186966926 ∧ code e1211186966926 = 5609233478030 := by decide
theorem cert_e1211186966926 : check e1211186966926 [[],[]] .smaller = true := by decide
def e1211186966938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186966938 : Closed e1211186966938 ∧ code e1211186966938 = 5609233478042 := by decide
theorem cert_e1211186966938 : check e1211186966938 [[],[]] .smaller = true := by decide
def e1211186966982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186966982 : Closed e1211186966982 ∧ code e1211186966982 = 5609233478086 := by decide
theorem cert_e1211186966982 : check e1211186966982 [[],[]] .smaller = true := by decide
def e1211186967006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211186967006 : Closed e1211186967006 ∧ code e1211186967006 = 5609233478110 := by decide
theorem cert_e1211186967006 : check e1211186967006 [[],[]] .three = true := by decide
def e1211186967030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211186967030 : Closed e1211186967030 ∧ code e1211186967030 = 5609233478134 := by decide
theorem cert_e1211186967030 : check e1211186967030 [[],[]] .three = true := by decide
def e1211186967318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186967318 : Closed e1211186967318 ∧ code e1211186967318 = 5609233478422 := by decide
theorem cert_e1211186967318 : check e1211186967318 [[],[]] .smaller = true := by decide
def e1211186967322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186967322 : Closed e1211186967322 ∧ code e1211186967322 = 5609233478426 := by decide
theorem cert_e1211186967322 : check e1211186967322 [[],[]] .smaller = true := by decide
def e1211186967366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186967366 : Closed e1211186967366 ∧ code e1211186967366 = 5609233478470 := by decide
theorem cert_e1211186967366 : check e1211186967366 [[],[]] .smaller = true := by decide
def e1211186967390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e1211186967390 : Closed e1211186967390 ∧ code e1211186967390 = 5609233478494 := by decide
theorem cert_e1211186967390 : check e1211186967390 [[],[]] .three = true := by decide
def e1211186967394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186967394 : Closed e1211186967394 ∧ code e1211186967394 = 5609233478498 := by decide
theorem cert_e1211186967394 : check e1211186967394 [[],[]] .smaller = true := by decide
def e1211186967406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211186967406 : Closed e1211186967406 ∧ code e1211186967406 = 5609233478510 := by decide
theorem cert_e1211186967406 : check e1211186967406 [[],[]] .smaller = true := by decide
def e1211186967414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211186967414 : Closed e1211186967414 ∧ code e1211186967414 = 5609233478518 := by decide
theorem cert_e1211186967414 : check e1211186967414 [[],[]] .smaller = true := by decide
def e1211186967418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211186967418 : Closed e1211186967418 ∧ code e1211186967418 = 5609233478522 := by decide
theorem cert_e1211186967418 : check e1211186967418 [[],[]] .three = true := by decide
def e1211186967434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186967434 : Closed e1211186967434 ∧ code e1211186967434 = 5609233478538 := by decide
theorem cert_e1211186967434 : check e1211186967434 [[],[]] .smaller = true := by decide
def e1211186967458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186967458 : Closed e1211186967458 ∧ code e1211186967458 = 5609233478562 := by decide
theorem cert_e1211186967458 : check e1211186967458 [[],[]] .smaller = true := by decide
def e1211186967470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211186967470 : Closed e1211186967470 ∧ code e1211186967470 = 5609233478574 := by decide
theorem cert_e1211186967470 : check e1211186967470 [[],[]] .smaller = true := by decide
def e1211186967482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211186967482 : Closed e1211186967482 ∧ code e1211186967482 = 5609233478586 := by decide
theorem cert_e1211186967482 : check e1211186967482 [[],[]] .smaller = true := by decide
def e1211186967510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211186967510 : Closed e1211186967510 ∧ code e1211186967510 = 5609233478614 := by decide
theorem cert_e1211186967510 : check e1211186967510 [[],[]] .smaller = true := by decide
def e1211186967514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211186967514 : Closed e1211186967514 ∧ code e1211186967514 = 5609233478618 := by decide
theorem cert_e1211186967514 : check e1211186967514 [[],[]] .smaller = true := by decide
def e1211186967530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211186967530 : Closed e1211186967530 ∧ code e1211186967530 = 5609233478634 := by decide
theorem cert_e1211186967530 : check e1211186967530 [[],[]] .three = true := by decide
def e1211186967582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186967582 : Closed e1211186967582 ∧ code e1211186967582 = 5609233478686 := by decide
theorem cert_e1211186967582 : check e1211186967582 [[],[]] .smaller = true := by decide
def e1211186967606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186967606 : Closed e1211186967606 ∧ code e1211186967606 = 5609233478710 := by decide
theorem cert_e1211186967606 : check e1211186967606 [[],[]] .smaller = true := by decide
def e1211186967610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186967610 : Closed e1211186967610 ∧ code e1211186967610 = 5609233478714 := by decide
theorem cert_e1211186967610 : check e1211186967610 [[],[]] .smaller = true := by decide
def e1211186967750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186967750 : Closed e1211186967750 ∧ code e1211186967750 = 5609233478854 := by decide
theorem cert_e1211186967750 : check e1211186967750 [[],[]] .smaller = true := by decide
def e1211186967774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186967774 : Closed e1211186967774 ∧ code e1211186967774 = 5609233478878 := by decide
theorem cert_e1211186967774 : check e1211186967774 [[],[]] .three = true := by decide
def e1211186967778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186967778 : Closed e1211186967778 ∧ code e1211186967778 = 5609233478882 := by decide
theorem cert_e1211186967778 : check e1211186967778 [[],[]] .smaller = true := by decide
def e1211186967790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186967790 : Closed e1211186967790 ∧ code e1211186967790 = 5609233478894 := by decide
theorem cert_e1211186967790 : check e1211186967790 [[],[]] .smaller = true := by decide
def e1211186967798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186967798 : Closed e1211186967798 ∧ code e1211186967798 = 5609233478902 := by decide
theorem cert_e1211186967798 : check e1211186967798 [[],[]] .smaller = true := by decide
def e1211186967802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186967802 : Closed e1211186967802 ∧ code e1211186967802 = 5609233478906 := by decide
theorem cert_e1211186967802 : check e1211186967802 [[],[]] .three = true := by decide
def e1211186968078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186968078 : Closed e1211186968078 ∧ code e1211186968078 = 5609233479182 := by decide
theorem cert_e1211186968078 : check e1211186968078 [[],[]] .smaller = true := by decide
def e1211186968126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211186968126 : Closed e1211186968126 ∧ code e1211186968126 = 5609233479230 := by decide
theorem cert_e1211186968126 : check e1211186968126 [[],[]] .three = true := by decide
def e1211186968162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186968162 : Closed e1211186968162 ∧ code e1211186968162 = 5609233479266 := by decide
theorem cert_e1211186968162 : check e1211186968162 [[],[]] .smaller = true := by decide
def e1211186968174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186968174 : Closed e1211186968174 ∧ code e1211186968174 = 5609233479278 := by decide
theorem cert_e1211186968174 : check e1211186968174 [[],[]] .smaller = true := by decide
def e1211186968186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186968186 : Closed e1211186968186 ∧ code e1211186968186 = 5609233479290 := by decide
theorem cert_e1211186968186 : check e1211186968186 [[],[]] .smaller = true := by decide
def e1211186968374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186968374 : Closed e1211186968374 ∧ code e1211186968374 = 5609233479478 := by decide
theorem cert_e1211186968374 : check e1211186968374 [[],[]] .smaller = true := by decide
def e1211186968378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186968378 : Closed e1211186968378 ∧ code e1211186968378 = 5609233479482 := by decide
theorem cert_e1211186968378 : check e1211186968378 [[],[]] .smaller = true := by decide
def e1211186968462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211186968462 : Closed e1211186968462 ∧ code e1211186968462 = 5609233479566 := by decide
theorem cert_e1211186968462 : check e1211186968462 [[],[]] .three = true := by decide
def e1211186968474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186968474 : Closed e1211186968474 ∧ code e1211186968474 = 5609233479578 := by decide
theorem cert_e1211186968474 : check e1211186968474 [[],[]] .three = true := by decide
def e1211186968798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e1211186968798 : Closed e1211186968798 ∧ code e1211186968798 = 5609233479902 := by decide
theorem cert_e1211186968798 : check e1211186968798 [[],[]] .three = true := by decide
def e1211186968826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1211186968826 : Closed e1211186968826 ∧ code e1211186968826 = 5609233479930 := by decide
theorem cert_e1211186968826 : check e1211186968826 [[],[]] .three = true := by decide
def e1211186969014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211186969014 : Closed e1211186969014 ∧ code e1211186969014 = 5609233480118 := by decide
theorem cert_e1211186969014 : check e1211186969014 [[],[]] .smaller = true := by decide
def e1211186969046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211186969046 : Closed e1211186969046 ∧ code e1211186969046 = 5609233480150 := by decide
theorem cert_e1211186969046 : check e1211186969046 [[],[]] .smaller = true := by decide
def e1211186969050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211186969050 : Closed e1211186969050 ∧ code e1211186969050 = 5609233480154 := by decide
theorem cert_e1211186969050 : check e1211186969050 [[],[]] .smaller = true := by decide
def e1211186969150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 4))))))))
theorem wire_e1211186969150 : Closed e1211186969150 ∧ code e1211186969150 = 5609233480254 := by decide
theorem cert_e1211186969150 : check e1211186969150 [[],[]] .three = true := by decide
def e1211186969206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186969206 : Closed e1211186969206 ∧ code e1211186969206 = 5609233480310 := by decide
theorem cert_e1211186969206 : check e1211186969206 [[],[]] .smaller = true := by decide
def e1211186969398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186969398 : Closed e1211186969398 ∧ code e1211186969398 = 5609233480502 := by decide
theorem cert_e1211186969398 : check e1211186969398 [[],[]] .smaller = true := by decide
def e1211186969402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186969402 : Closed e1211186969402 ∧ code e1211186969402 = 5609233480506 := by decide
theorem cert_e1211186969402 : check e1211186969402 [[],[]] .smaller = true := by decide
def e1211186969542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.lam (.var 1))))))))
theorem wire_e1211186969542 : Closed e1211186969542 ∧ code e1211186969542 = 5609233480646 := by decide
theorem cert_e1211186969542 : check e1211186969542 [[],[]] .three = true := by decide
def e1211186969710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186969710 : Closed e1211186969710 ∧ code e1211186969710 = 5609233480814 := by decide
theorem cert_e1211186969710 : check e1211186969710 [[],[]] .three = true := by decide
def e1211186969718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211186969718 : Closed e1211186969718 ∧ code e1211186969718 = 5609233480822 := by decide
theorem cert_e1211186969718 : check e1211186969718 [[],[]] .three = true := by decide
def e1211186969722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186969722 : Closed e1211186969722 ∧ code e1211186969722 = 5609233480826 := by decide
theorem cert_e1211186969722 : check e1211186969722 [[],[]] .three = true := by decide
def e1211186969814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211186969814 : Closed e1211186969814 ∧ code e1211186969814 = 5609233480918 := by decide
theorem cert_e1211186969814 : check e1211186969814 [[],[]] .three = true := by decide
def e1211186969818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211186969818 : Closed e1211186969818 ∧ code e1211186969818 = 5609233480922 := by decide
theorem cert_e1211186969818 : check e1211186969818 [[],[]] .three = true := by decide
def e1211186969834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211186969834 : Closed e1211186969834 ∧ code e1211186969834 = 5609233480938 := by decide
theorem cert_e1211186969834 : check e1211186969834 [[],[]] .three = true := by decide
def e1211186969886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186969886 : Closed e1211186969886 ∧ code e1211186969886 = 5609233480990 := by decide
theorem cert_e1211186969886 : check e1211186969886 [[],[]] .three = true := by decide
def e1211186969910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186969910 : Closed e1211186969910 ∧ code e1211186969910 = 5609233481014 := by decide
theorem cert_e1211186969910 : check e1211186969910 [[],[]] .three = true := by decide
def e1211186969914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186969914 : Closed e1211186969914 ∧ code e1211186969914 = 5609233481018 := by decide
theorem cert_e1211186969914 : check e1211186969914 [[],[]] .three = true := by decide
def e1211186969998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211186969998 : Closed e1211186969998 ∧ code e1211186969998 = 5609233481102 := by decide
theorem cert_e1211186969998 : check e1211186969998 [[],[]] .three = true := by decide
def e1211186970010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186970010 : Closed e1211186970010 ∧ code e1211186970010 = 5609233481114 := by decide
theorem cert_e1211186970010 : check e1211186970010 [[],[]] .three = true := by decide
def e1211186970054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186970054 : Closed e1211186970054 ∧ code e1211186970054 = 5609233481158 := by decide
theorem cert_e1211186970054 : check e1211186970054 [[],[]] .three = true := by decide
def e1211186972078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211186972078 : Closed e1211186972078 ∧ code e1211186972078 = 5609233483182 := by decide
theorem cert_e1211186972078 : check e1211186972078 [[],[]] .smaller = true := by decide
def e1211186972090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211186972090 : Closed e1211186972090 ∧ code e1211186972090 = 5609233483194 := by decide
theorem cert_e1211186972090 : check e1211186972090 [[],[]] .smaller = true := by decide
def e1211186972138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211186972138 : Closed e1211186972138 ∧ code e1211186972138 = 5609233483242 := by decide
theorem cert_e1211186972138 : check e1211186972138 [[],[]] .smaller = true := by decide
def e1211186972270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186972270 : Closed e1211186972270 ∧ code e1211186972270 = 5609233483374 := by decide
theorem cert_e1211186972270 : check e1211186972270 [[],[]] .smaller = true := by decide
def e1211186972282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186972282 : Closed e1211186972282 ∧ code e1211186972282 = 5609233483386 := by decide
theorem cert_e1211186972282 : check e1211186972282 [[],[]] .smaller = true := by decide
def e1211186972446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211186972446 : Closed e1211186972446 ∧ code e1211186972446 = 5609233483550 := by decide
theorem cert_e1211186972446 : check e1211186972446 [[],[]] .smaller = true := by decide
def e1211186972558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211186972558 : Closed e1211186972558 ∧ code e1211186972558 = 5609233483662 := by decide
theorem cert_e1211186972558 : check e1211186972558 [[],[]] .smaller = true := by decide
def e1211186972570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186972570 : Closed e1211186972570 ∧ code e1211186972570 = 5609233483674 := by decide
theorem cert_e1211186972570 : check e1211186972570 [[],[]] .smaller = true := by decide
def e1211186976310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211186976310 : Closed e1211186976310 ∧ code e1211186976310 = 5609233487414 := by decide
theorem cert_e1211186976310 : check e1211186976310 [[],[]] .smaller = true := by decide
def e1211186976314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211186976314 : Closed e1211186976314 ∧ code e1211186976314 = 5609233487418 := by decide
theorem cert_e1211186976314 : check e1211186976314 [[],[]] .smaller = true := by decide
def e1211186976398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211186976398 : Closed e1211186976398 ∧ code e1211186976398 = 5609233487502 := by decide
theorem cert_e1211186976398 : check e1211186976398 [[],[]] .smaller = true := by decide
def e1211186976454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211186976454 : Closed e1211186976454 ∧ code e1211186976454 = 5609233487558 := by decide
theorem cert_e1211186976454 : check e1211186976454 [[],[]] .smaller = true := by decide
def e1211186976478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211186976478 : Closed e1211186976478 ∧ code e1211186976478 = 5609233487582 := by decide
theorem cert_e1211186976478 : check e1211186976478 [[],[]] .three = true := by decide
def e1211186976502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211186976502 : Closed e1211186976502 ∧ code e1211186976502 = 5609233487606 := by decide
theorem cert_e1211186976502 : check e1211186976502 [[],[]] .three = true := by decide
def e1211186976534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186976534 : Closed e1211186976534 ∧ code e1211186976534 = 5609233487638 := by decide
theorem cert_e1211186976534 : check e1211186976534 [[],[]] .smaller = true := by decide
def e1211186976538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186976538 : Closed e1211186976538 ∧ code e1211186976538 = 5609233487642 := by decide
theorem cert_e1211186976538 : check e1211186976538 [[],[]] .smaller = true := by decide
def e1211186976582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186976582 : Closed e1211186976582 ∧ code e1211186976582 = 5609233487686 := by decide
theorem cert_e1211186976582 : check e1211186976582 [[],[]] .smaller = true := by decide
def e1211186976606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211186976606 : Closed e1211186976606 ∧ code e1211186976606 = 5609233487710 := by decide
theorem cert_e1211186976606 : check e1211186976606 [[],[]] .three = true := by decide
def e1211186976610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186976610 : Closed e1211186976610 ∧ code e1211186976610 = 5609233487714 := by decide
theorem cert_e1211186976610 : check e1211186976610 [[],[]] .smaller = true := by decide
def e1211186976622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211186976622 : Closed e1211186976622 ∧ code e1211186976622 = 5609233487726 := by decide
theorem cert_e1211186976622 : check e1211186976622 [[],[]] .smaller = true := by decide
def e1211186976630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211186976630 : Closed e1211186976630 ∧ code e1211186976630 = 5609233487734 := by decide
theorem cert_e1211186976630 : check e1211186976630 [[],[]] .smaller = true := by decide
def e1211186976634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211186976634 : Closed e1211186976634 ∧ code e1211186976634 = 5609233487738 := by decide
theorem cert_e1211186976634 : check e1211186976634 [[],[]] .three = true := by decide
def e1211186976694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211186976694 : Closed e1211186976694 ∧ code e1211186976694 = 5609233487798 := by decide
theorem cert_e1211186976694 : check e1211186976694 [[],[]] .smaller = true := by decide
def e1211186976726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211186976726 : Closed e1211186976726 ∧ code e1211186976726 = 5609233487830 := by decide
theorem cert_e1211186976726 : check e1211186976726 [[],[]] .three = true := by decide
def e1211186976730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211186976730 : Closed e1211186976730 ∧ code e1211186976730 = 5609233487834 := by decide
theorem cert_e1211186976730 : check e1211186976730 [[],[]] .three = true := by decide
def e1211186976878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186976878 : Closed e1211186976878 ∧ code e1211186976878 = 5609233487982 := by decide
theorem cert_e1211186976878 : check e1211186976878 [[],[]] .smaller = true := by decide
def e1211186976890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186976890 : Closed e1211186976890 ∧ code e1211186976890 = 5609233487994 := by decide
theorem cert_e1211186976890 : check e1211186976890 [[],[]] .smaller = true := by decide
def e1211186977166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211186977166 : Closed e1211186977166 ∧ code e1211186977166 = 5609233488270 := by decide
theorem cert_e1211186977166 : check e1211186977166 [[],[]] .smaller = true := by decide
def e1211186977222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211186977222 : Closed e1211186977222 ∧ code e1211186977222 = 5609233488326 := by decide
theorem cert_e1211186977222 : check e1211186977222 [[],[]] .smaller = true := by decide
def e1211186977246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186977246 : Closed e1211186977246 ∧ code e1211186977246 = 5609233488350 := by decide
theorem cert_e1211186977246 : check e1211186977246 [[],[]] .three = true := by decide
def e1211186977270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186977270 : Closed e1211186977270 ∧ code e1211186977270 = 5609233488374 := by decide
theorem cert_e1211186977270 : check e1211186977270 [[],[]] .three = true := by decide
def e1211186977822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186977822 : Closed e1211186977822 ∧ code e1211186977822 = 5609233488926 := by decide
theorem cert_e1211186977822 : check e1211186977822 [[],[]] .smaller = true := by decide
def e1211186977846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186977846 : Closed e1211186977846 ∧ code e1211186977846 = 5609233488950 := by decide
theorem cert_e1211186977846 : check e1211186977846 [[],[]] .smaller = true := by decide
def e1211186977850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186977850 : Closed e1211186977850 ∧ code e1211186977850 = 5609233488954 := by decide
theorem cert_e1211186977850 : check e1211186977850 [[],[]] .smaller = true := by decide
def e1211186977990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186977990 : Closed e1211186977990 ∧ code e1211186977990 = 5609233489094 := by decide
theorem cert_e1211186977990 : check e1211186977990 [[],[]] .smaller = true := by decide
def e1211186978014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186978014 : Closed e1211186978014 ∧ code e1211186978014 = 5609233489118 := by decide
theorem cert_e1211186978014 : check e1211186978014 [[],[]] .three = true := by decide
def e1211186978018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186978018 : Closed e1211186978018 ∧ code e1211186978018 = 5609233489122 := by decide
theorem cert_e1211186978018 : check e1211186978018 [[],[]] .smaller = true := by decide
def e1211186978030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186978030 : Closed e1211186978030 ∧ code e1211186978030 = 5609233489134 := by decide
theorem cert_e1211186978030 : check e1211186978030 [[],[]] .smaller = true := by decide
def e1211186978038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186978038 : Closed e1211186978038 ∧ code e1211186978038 = 5609233489142 := by decide
theorem cert_e1211186978038 : check e1211186978038 [[],[]] .smaller = true := by decide
def e1211186978042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186978042 : Closed e1211186978042 ∧ code e1211186978042 = 5609233489146 := by decide
theorem cert_e1211186978042 : check e1211186978042 [[],[]] .three = true := by decide
def e1211186978366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e1211186978366 : Closed e1211186978366 ∧ code e1211186978366 = 5609233489470 := by decide
theorem cert_e1211186978366 : check e1211186978366 [[],[]] .three = true := by decide
def e1211186978422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186978422 : Closed e1211186978422 ∧ code e1211186978422 = 5609233489526 := by decide
theorem cert_e1211186978422 : check e1211186978422 [[],[]] .smaller = true := by decide
def e1211186978590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e1211186978590 : Closed e1211186978590 ∧ code e1211186978590 = 5609233489694 := by decide
theorem cert_e1211186978590 : check e1211186978590 [[],[]] .three = true := by decide
def e1211186978614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186978614 : Closed e1211186978614 ∧ code e1211186978614 = 5609233489718 := by decide
theorem cert_e1211186978614 : check e1211186978614 [[],[]] .three = true := by decide
def e1211186978618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186978618 : Closed e1211186978618 ∧ code e1211186978618 = 5609233489722 := by decide
theorem cert_e1211186978618 : check e1211186978618 [[],[]] .three = true := by decide
def e1211186987734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211186987734 : Closed e1211186987734 ∧ code e1211186987734 = 5609233498838 := by decide
theorem cert_e1211186987734 : check e1211186987734 [[],[]] .smaller = true := by decide
def e1211186987738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211186987738 : Closed e1211186987738 ∧ code e1211186987738 = 5609233498842 := by decide
theorem cert_e1211186987738 : check e1211186987738 [[],[]] .smaller = true := by decide
def e1211186987754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211186987754 : Closed e1211186987754 ∧ code e1211186987754 = 5609233498858 := by decide
theorem cert_e1211186987754 : check e1211186987754 [[],[]] .smaller = true := by decide
def e1211186987830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186987830 : Closed e1211186987830 ∧ code e1211186987830 = 5609233498934 := by decide
theorem cert_e1211186987830 : check e1211186987830 [[],[]] .smaller = true := by decide
def e1211186987834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186987834 : Closed e1211186987834 ∧ code e1211186987834 = 5609233498938 := by decide
theorem cert_e1211186987834 : check e1211186987834 [[],[]] .smaller = true := by decide
def e1211186987918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211186987918 : Closed e1211186987918 ∧ code e1211186987918 = 5609233499022 := by decide
theorem cert_e1211186987918 : check e1211186987918 [[],[]] .smaller = true := by decide
def e1211186987930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186987930 : Closed e1211186987930 ∧ code e1211186987930 = 5609233499034 := by decide
theorem cert_e1211186987930 : check e1211186987930 [[],[]] .smaller = true := by decide
def e1211186989846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186989846 : Closed e1211186989846 ∧ code e1211186989846 = 5609233500950 := by decide
theorem cert_e1211186989846 : check e1211186989846 [[],[]] .smaller = true := by decide
def e1211186989850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186989850 : Closed e1211186989850 ∧ code e1211186989850 = 5609233500954 := by decide
theorem cert_e1211186989850 : check e1211186989850 [[],[]] .smaller = true := by decide
def e1211186989894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186989894 : Closed e1211186989894 ∧ code e1211186989894 = 5609233500998 := by decide
theorem cert_e1211186989894 : check e1211186989894 [[],[]] .smaller = true := by decide
def e1211186989918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1211186989918 : Closed e1211186989918 ∧ code e1211186989918 = 5609233501022 := by decide
theorem cert_e1211186989918 : check e1211186989918 [[],[]] .three = true := by decide
def e1211186989922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186989922 : Closed e1211186989922 ∧ code e1211186989922 = 5609233501026 := by decide
theorem cert_e1211186989922 : check e1211186989922 [[],[]] .smaller = true := by decide
def e1211186989934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211186989934 : Closed e1211186989934 ∧ code e1211186989934 = 5609233501038 := by decide
theorem cert_e1211186989934 : check e1211186989934 [[],[]] .smaller = true := by decide
def e1211186989942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211186989942 : Closed e1211186989942 ∧ code e1211186989942 = 5609233501046 := by decide
theorem cert_e1211186989942 : check e1211186989942 [[],[]] .smaller = true := by decide
def e1211186989946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1211186989946 : Closed e1211186989946 ∧ code e1211186989946 = 5609233501050 := by decide
theorem cert_e1211186989946 : check e1211186989946 [[],[]] .three = true := by decide
def e1211186989962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186989962 : Closed e1211186989962 ∧ code e1211186989962 = 5609233501066 := by decide
theorem cert_e1211186989962 : check e1211186989962 [[],[]] .smaller = true := by decide
def e1211186989986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186989986 : Closed e1211186989986 ∧ code e1211186989986 = 5609233501090 := by decide
theorem cert_e1211186989986 : check e1211186989986 [[],[]] .smaller = true := by decide
def e1211186989998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211186989998 : Closed e1211186989998 ∧ code e1211186989998 = 5609233501102 := by decide
theorem cert_e1211186989998 : check e1211186989998 [[],[]] .smaller = true := by decide
def e1211186990010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211186990010 : Closed e1211186990010 ∧ code e1211186990010 = 5609233501114 := by decide
theorem cert_e1211186990010 : check e1211186990010 [[],[]] .smaller = true := by decide
def e1211186990038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211186990038 : Closed e1211186990038 ∧ code e1211186990038 = 5609233501142 := by decide
theorem cert_e1211186990038 : check e1211186990038 [[],[]] .smaller = true := by decide
def e1211186990042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211186990042 : Closed e1211186990042 ∧ code e1211186990042 = 5609233501146 := by decide
theorem cert_e1211186990042 : check e1211186990042 [[],[]] .smaller = true := by decide
def e1211186990058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1211186990058 : Closed e1211186990058 ∧ code e1211186990058 = 5609233501162 := by decide
theorem cert_e1211186990058 : check e1211186990058 [[],[]] .three = true := by decide
def e1211186990110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186990110 : Closed e1211186990110 ∧ code e1211186990110 = 5609233501214 := by decide
theorem cert_e1211186990110 : check e1211186990110 [[],[]] .smaller = true := by decide
def e1211186990134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186990134 : Closed e1211186990134 ∧ code e1211186990134 = 5609233501238 := by decide
theorem cert_e1211186990134 : check e1211186990134 [[],[]] .smaller = true := by decide
def e1211186990138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186990138 : Closed e1211186990138 ∧ code e1211186990138 = 5609233501242 := by decide
theorem cert_e1211186990138 : check e1211186990138 [[],[]] .smaller = true := by decide
def e1211186990278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186990278 : Closed e1211186990278 ∧ code e1211186990278 = 5609233501382 := by decide
theorem cert_e1211186990278 : check e1211186990278 [[],[]] .smaller = true := by decide
def e1211186990302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186990302 : Closed e1211186990302 ∧ code e1211186990302 = 5609233501406 := by decide
theorem cert_e1211186990302 : check e1211186990302 [[],[]] .three = true := by decide
def e1211186990306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186990306 : Closed e1211186990306 ∧ code e1211186990306 = 5609233501410 := by decide
theorem cert_e1211186990306 : check e1211186990306 [[],[]] .smaller = true := by decide
def e1211186990318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186990318 : Closed e1211186990318 ∧ code e1211186990318 = 5609233501422 := by decide
theorem cert_e1211186990318 : check e1211186990318 [[],[]] .smaller = true := by decide
def e1211186990326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186990326 : Closed e1211186990326 ∧ code e1211186990326 = 5609233501430 := by decide
theorem cert_e1211186990326 : check e1211186990326 [[],[]] .smaller = true := by decide
def e1211186990330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186990330 : Closed e1211186990330 ∧ code e1211186990330 = 5609233501434 := by decide
theorem cert_e1211186990330 : check e1211186990330 [[],[]] .three = true := by decide
def e1211186990606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186990606 : Closed e1211186990606 ∧ code e1211186990606 = 5609233501710 := by decide
theorem cert_e1211186990606 : check e1211186990606 [[],[]] .smaller = true := by decide
def e1211186990654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211186990654 : Closed e1211186990654 ∧ code e1211186990654 = 5609233501758 := by decide
theorem cert_e1211186990654 : check e1211186990654 [[],[]] .three = true := by decide
def e1211186990690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186990690 : Closed e1211186990690 ∧ code e1211186990690 = 5609233501794 := by decide
theorem cert_e1211186990690 : check e1211186990690 [[],[]] .smaller = true := by decide
def e1211186990702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186990702 : Closed e1211186990702 ∧ code e1211186990702 = 5609233501806 := by decide
theorem cert_e1211186990702 : check e1211186990702 [[],[]] .smaller = true := by decide
def e1211186990714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186990714 : Closed e1211186990714 ∧ code e1211186990714 = 5609233501818 := by decide
theorem cert_e1211186990714 : check e1211186990714 [[],[]] .smaller = true := by decide
def e1211186990902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186990902 : Closed e1211186990902 ∧ code e1211186990902 = 5609233502006 := by decide
theorem cert_e1211186990902 : check e1211186990902 [[],[]] .smaller = true := by decide
end Blc.Floor42
