import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211283021022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211283021022 : Closed e1211283021022 ∧ code e1211283021022 = 5609329532126 := by decide
theorem cert_e1211283021022 : check e1211283021022 [[],[]] .smaller = true := by decide
def e1211283021050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211283021050 : Closed e1211283021050 ∧ code e1211283021050 = 5609329532154 := by decide
theorem cert_e1211283021050 : check e1211283021050 [[],[]] .smaller = true := by decide
def e1211283021622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211283021622 : Closed e1211283021622 ∧ code e1211283021622 = 5609329532726 := by decide
theorem cert_e1211283021622 : check e1211283021622 [[],[]] .smaller = true := by decide
def e1211283021626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211283021626 : Closed e1211283021626 ∧ code e1211283021626 = 5609329532730 := by decide
theorem cert_e1211283021626 : check e1211283021626 [[],[]] .smaller = true := by decide
def e1211283036398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211283036398 : Closed e1211283036398 ∧ code e1211283036398 = 5609329547502 := by decide
theorem cert_e1211283036398 : check e1211283036398 [[],[]] .smaller = true := by decide
def e1211283036406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211283036406 : Closed e1211283036406 ∧ code e1211283036406 = 5609329547510 := by decide
theorem cert_e1211283036406 : check e1211283036406 [[],[]] .smaller = true := by decide
def e1211283036958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211283036958 : Closed e1211283036958 ∧ code e1211283036958 = 5609329548062 := by decide
theorem cert_e1211283036958 : check e1211283036958 [[],[]] .smaller = true := by decide
def e1211283037070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211283037070 : Closed e1211283037070 ∧ code e1211283037070 = 5609329548174 := by decide
theorem cert_e1211283037070 : check e1211283037070 [[],[]] .smaller = true := by decide
def e1211283037294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211283037294 : Closed e1211283037294 ∧ code e1211283037294 = 5609329548398 := by decide
theorem cert_e1211283037294 : check e1211283037294 [[],[]] .smaller = true := by decide
def e1211283037306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211283037306 : Closed e1211283037306 ∧ code e1211283037306 = 5609329548410 := by decide
theorem cert_e1211283037306 : check e1211283037306 [[],[]] .smaller = true := by decide
def e1211283037470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211283037470 : Closed e1211283037470 ∧ code e1211283037470 = 5609329548574 := by decide
theorem cert_e1211283037470 : check e1211283037470 [[],[]] .smaller = true := by decide
def e1211283037638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211283037638 : Closed e1211283037638 ∧ code e1211283037638 = 5609329548742 := by decide
theorem cert_e1211283037638 : check e1211283037638 [[],[]] .smaller = true := by decide
def e1211283037662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211283037662 : Closed e1211283037662 ∧ code e1211283037662 = 5609329548766 := by decide
theorem cert_e1211283037662 : check e1211283037662 [[],[]] .chain = true := by decide
def e1211283037678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211283037678 : Closed e1211283037678 ∧ code e1211283037678 = 5609329548782 := by decide
theorem cert_e1211283037678 : check e1211283037678 [[],[]] .chain = true := by decide
def e1211283037750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211283037750 : Closed e1211283037750 ∧ code e1211283037750 = 5609329548854 := by decide
theorem cert_e1211283037750 : check e1211283037750 [[],[]] .smaller = true := by decide
def e1211283037754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211283037754 : Closed e1211283037754 ∧ code e1211283037754 = 5609329548858 := by decide
theorem cert_e1211283037754 : check e1211283037754 [[],[]] .smaller = true := by decide
def e1211283037838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211283037838 : Closed e1211283037838 ∧ code e1211283037838 = 5609329548942 := by decide
theorem cert_e1211283037838 : check e1211283037838 [[],[]] .smaller = true := by decide
def e1211283037894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211283037894 : Closed e1211283037894 ∧ code e1211283037894 = 5609329548998 := by decide
theorem cert_e1211283037894 : check e1211283037894 [[],[]] .smaller = true := by decide
def e1211283037918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211283037918 : Closed e1211283037918 ∧ code e1211283037918 = 5609329549022 := by decide
theorem cert_e1211283037918 : check e1211283037918 [[],[]] .chain = true := by decide
def e1211283037942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211283037942 : Closed e1211283037942 ∧ code e1211283037942 = 5609329549046 := by decide
theorem cert_e1211283037942 : check e1211283037942 [[],[]] .chain = true := by decide
def e1211283038062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211283038062 : Closed e1211283038062 ∧ code e1211283038062 = 5609329549166 := by decide
theorem cert_e1211283038062 : check e1211283038062 [[],[]] .chain = true := by decide
def e1211283038070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211283038070 : Closed e1211283038070 ∧ code e1211283038070 = 5609329549174 := by decide
theorem cert_e1211283038070 : check e1211283038070 [[],[]] .chain = true := by decide
def e1211283040030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211283040030 : Closed e1211283040030 ∧ code e1211283040030 = 5609329551134 := by decide
theorem cert_e1211283040030 : check e1211283040030 [[],[]] .smaller = true := by decide
def e1211283040142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211283040142 : Closed e1211283040142 ∧ code e1211283040142 = 5609329551246 := by decide
theorem cert_e1211283040142 : check e1211283040142 [[],[]] .smaller = true := by decide
def e1211283043102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211283043102 : Closed e1211283043102 ∧ code e1211283043102 = 5609329554206 := by decide
theorem cert_e1211283043102 : check e1211283043102 [[],[]] .smaller = true := by decide
def e1211283043270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211283043270 : Closed e1211283043270 ∧ code e1211283043270 = 5609329554374 := by decide
theorem cert_e1211283043270 : check e1211283043270 [[],[]] .smaller = true := by decide
def e1211283043294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211283043294 : Closed e1211283043294 ∧ code e1211283043294 = 5609329554398 := by decide
theorem cert_e1211283043294 : check e1211283043294 [[],[]] .chain = true := by decide
def e1211283043310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211283043310 : Closed e1211283043310 ∧ code e1211283043310 = 5609329554414 := by decide
theorem cert_e1211283043310 : check e1211283043310 [[],[]] .chain = true := by decide
def e1211283044750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211283044750 : Closed e1211283044750 ∧ code e1211283044750 = 5609329555854 := by decide
theorem cert_e1211283044750 : check e1211283044750 [[],[]] .smaller = true := by decide
def e1211283044806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211283044806 : Closed e1211283044806 ∧ code e1211283044806 = 5609329555910 := by decide
theorem cert_e1211283044806 : check e1211283044806 [[],[]] .smaller = true := by decide
def e1211283044830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211283044830 : Closed e1211283044830 ∧ code e1211283044830 = 5609329555934 := by decide
theorem cert_e1211283044830 : check e1211283044830 [[],[]] .chain = true := by decide
def e1211283044854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211283044854 : Closed e1211283044854 ∧ code e1211283044854 = 5609329555958 := by decide
theorem cert_e1211283044854 : check e1211283044854 [[],[]] .chain = true := by decide
def e1211283045614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283045614 : Closed e1211283045614 ∧ code e1211283045614 = 5609329556718 := by decide
theorem cert_e1211283045614 : check e1211283045614 [[],[]] .chain = true := by decide
def e1211283045622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283045622 : Closed e1211283045622 ∧ code e1211283045622 = 5609329556726 := by decide
theorem cert_e1211283045622 : check e1211283045622 [[],[]] .chain = true := by decide
def e1211283102574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211283102574 : Closed e1211283102574 ∧ code e1211283102574 = 5609329613678 := by decide
theorem cert_e1211283102574 : check e1211283102574 [[],[]] .chain = true := by decide
def e1211283102582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211283102582 : Closed e1211283102582 ∧ code e1211283102582 = 5609329613686 := by decide
theorem cert_e1211283102582 : check e1211283102582 [[],[]] .chain = true := by decide
def e1211283102646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211283102646 : Closed e1211283102646 ∧ code e1211283102646 = 5609329613750 := by decide
theorem cert_e1211283102646 : check e1211283102646 [[],[]] .chain = true := by decide
def e1211283103086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211283103086 : Closed e1211283103086 ∧ code e1211283103086 = 5609329614190 := by decide
theorem cert_e1211283103086 : check e1211283103086 [[],[]] .chain = true := by decide
def e1211283103094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211283103094 : Closed e1211283103094 ∧ code e1211283103094 = 5609329614198 := by decide
theorem cert_e1211283103094 : check e1211283103094 [[],[]] .chain = true := by decide
def e1211283103150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211283103150 : Closed e1211283103150 ∧ code e1211283103150 = 5609329614254 := by decide
theorem cert_e1211283103150 : check e1211283103150 [[],[]] .chain = true := by decide
def e1211283103162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211283103162 : Closed e1211283103162 ∧ code e1211283103162 = 5609329614266 := by decide
theorem cert_e1211283103162 : check e1211283103162 [[],[]] .chain = true := by decide
def e1211283103190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211283103190 : Closed e1211283103190 ∧ code e1211283103190 = 5609329614294 := by decide
theorem cert_e1211283103190 : check e1211283103190 [[],[]] .chain = true := by decide
def e1211283103194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211283103194 : Closed e1211283103194 ∧ code e1211283103194 = 5609329614298 := by decide
theorem cert_e1211283103194 : check e1211283103194 [[],[]] .chain = true := by decide
def e1211283103414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211283103414 : Closed e1211283103414 ∧ code e1211283103414 = 5609329614518 := by decide
theorem cert_e1211283103414 : check e1211283103414 [[],[]] .chain = true := by decide
def e1211283103446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211283103446 : Closed e1211283103446 ∧ code e1211283103446 = 5609329614550 := by decide
theorem cert_e1211283103446 : check e1211283103446 [[],[]] .chain = true := by decide
def e1211283103450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211283103450 : Closed e1211283103450 ∧ code e1211283103450 = 5609329614554 := by decide
theorem cert_e1211283103450 : check e1211283103450 [[],[]] .chain = true := by decide
def e1211283105646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211283105646 : Closed e1211283105646 ∧ code e1211283105646 = 5609329616750 := by decide
theorem cert_e1211283105646 : check e1211283105646 [[],[]] .chain = true := by decide
def e1211283105654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211283105654 : Closed e1211283105654 ∧ code e1211283105654 = 5609329616758 := by decide
theorem cert_e1211283105654 : check e1211283105654 [[],[]] .chain = true := by decide
def e1211283105718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211283105718 : Closed e1211283105718 ∧ code e1211283105718 = 5609329616822 := by decide
theorem cert_e1211283105718 : check e1211283105718 [[],[]] .chain = true := by decide
def e1211283107054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211283107054 : Closed e1211283107054 ∧ code e1211283107054 = 5609329618158 := by decide
theorem cert_e1211283107054 : check e1211283107054 [[],[]] .chain = true := by decide
def e1211283107062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211283107062 : Closed e1211283107062 ∧ code e1211283107062 = 5609329618166 := by decide
theorem cert_e1211283107062 : check e1211283107062 [[],[]] .chain = true := by decide
def e1211283107446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211283107446 : Closed e1211283107446 ∧ code e1211283107446 = 5609329618550 := by decide
theorem cert_e1211283107446 : check e1211283107446 [[],[]] .chain = true := by decide
def e1211283107950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211283107950 : Closed e1211283107950 ∧ code e1211283107950 = 5609329619054 := by decide
theorem cert_e1211283107950 : check e1211283107950 [[],[]] .chain = true := by decide
def e1211283108126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211283108126 : Closed e1211283108126 ∧ code e1211283108126 = 5609329619230 := by decide
theorem cert_e1211283108126 : check e1211283108126 [[],[]] .chain = true := by decide
def e1211283108322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211283108322 : Closed e1211283108322 ∧ code e1211283108322 = 5609329619426 := by decide
theorem cert_e1211283108322 : check e1211283108322 [[],[]] .chain = true := by decide
def e1211283108334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211283108334 : Closed e1211283108334 ∧ code e1211283108334 = 5609329619438 := by decide
theorem cert_e1211283108334 : check e1211283108334 [[],[]] .sourceHead = true := by decide
def e1211283108718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211283108718 : Closed e1211283108718 ∧ code e1211283108718 = 5609329619822 := by decide
theorem cert_e1211283108718 : check e1211283108718 [[],[]] .chain = true := by decide
def e1211283108726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211283108726 : Closed e1211283108726 ∧ code e1211283108726 = 5609329619830 := by decide
theorem cert_e1211283108726 : check e1211283108726 [[],[]] .chain = true := by decide
def e1211283108782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211283108782 : Closed e1211283108782 ∧ code e1211283108782 = 5609329619886 := by decide
theorem cert_e1211283108782 : check e1211283108782 [[],[]] .chain = true := by decide
def e1211283108794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211283108794 : Closed e1211283108794 ∧ code e1211283108794 = 5609329619898 := by decide
theorem cert_e1211283108794 : check e1211283108794 [[],[]] .chain = true := by decide
def e1211283108822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211283108822 : Closed e1211283108822 ∧ code e1211283108822 = 5609329619926 := by decide
theorem cert_e1211283108822 : check e1211283108822 [[],[]] .chain = true := by decide
def e1211283108826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211283108826 : Closed e1211283108826 ∧ code e1211283108826 = 5609329619930 := by decide
theorem cert_e1211283108826 : check e1211283108826 [[],[]] .chain = true := by decide
def e1211283109102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211283109102 : Closed e1211283109102 ∧ code e1211283109102 = 5609329620206 := by decide
theorem cert_e1211283109102 : check e1211283109102 [[],[]] .chain = true := by decide
def e1211283109110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211283109110 : Closed e1211283109110 ∧ code e1211283109110 = 5609329620214 := by decide
theorem cert_e1211283109110 : check e1211283109110 [[],[]] .chain = true := by decide
def e1211283109486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211283109486 : Closed e1211283109486 ∧ code e1211283109486 = 5609329620590 := by decide
theorem cert_e1211283109486 : check e1211283109486 [[],[]] .chain = true := by decide
def e1211283109498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211283109498 : Closed e1211283109498 ∧ code e1211283109498 = 5609329620602 := by decide
theorem cert_e1211283109498 : check e1211283109498 [[],[]] .chain = true := by decide
def e1211283109638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283109638 : Closed e1211283109638 ∧ code e1211283109638 = 5609329620742 := by decide
theorem cert_e1211283109638 : check e1211283109638 [[],[]] .chain = true := by decide
def e1211283109662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211283109662 : Closed e1211283109662 ∧ code e1211283109662 = 5609329620766 := by decide
theorem cert_e1211283109662 : check e1211283109662 [[],[]] .sourceHead = true := by decide
def e1211283109686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283109686 : Closed e1211283109686 ∧ code e1211283109686 = 5609329620790 := by decide
theorem cert_e1211283109686 : check e1211283109686 [[],[]] .chain = true := by decide
def e1211283109690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283109690 : Closed e1211283109690 ∧ code e1211283109690 = 5609329620794 := by decide
theorem cert_e1211283109690 : check e1211283109690 [[],[]] .chain = true := by decide
def e1211283109942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211283109942 : Closed e1211283109942 ∧ code e1211283109942 = 5609329621046 := by decide
theorem cert_e1211283109942 : check e1211283109942 [[],[]] .chain = true := by decide
def e1211283110030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211283110030 : Closed e1211283110030 ∧ code e1211283110030 = 5609329621134 := by decide
theorem cert_e1211283110030 : check e1211283110030 [[],[]] .chain = true := by decide
def e1211283110114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211283110114 : Closed e1211283110114 ∧ code e1211283110114 = 5609329621218 := by decide
theorem cert_e1211283110114 : check e1211283110114 [[],[]] .chain = true := by decide
def e1211283110126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211283110126 : Closed e1211283110126 ∧ code e1211283110126 = 5609329621230 := by decide
theorem cert_e1211283110126 : check e1211283110126 [[],[]] .sourceHead = true := by decide
def e1211283110134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211283110134 : Closed e1211283110134 ∧ code e1211283110134 = 5609329621238 := by decide
theorem cert_e1211283110134 : check e1211283110134 [[],[]] .sourceHead = true := by decide
def e1211283110326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211283110326 : Closed e1211283110326 ∧ code e1211283110326 = 5609329621430 := by decide
theorem cert_e1211283110326 : check e1211283110326 [[],[]] .chain = true := by decide
def e1211283110358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211283110358 : Closed e1211283110358 ∧ code e1211283110358 = 5609329621462 := by decide
theorem cert_e1211283110358 : check e1211283110358 [[],[]] .chain = true := by decide
def e1211283110362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211283110362 : Closed e1211283110362 ∧ code e1211283110362 = 5609329621466 := by decide
theorem cert_e1211283110362 : check e1211283110362 [[],[]] .chain = true := by decide
def e1211283110518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211283110518 : Closed e1211283110518 ∧ code e1211283110518 = 5609329621622 := by decide
theorem cert_e1211283110518 : check e1211283110518 [[],[]] .chain = true := by decide
def e1211283110662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283110662 : Closed e1211283110662 ∧ code e1211283110662 = 5609329621766 := by decide
theorem cert_e1211283110662 : check e1211283110662 [[],[]] .chain = true := by decide
def e1211283110686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211283110686 : Closed e1211283110686 ∧ code e1211283110686 = 5609329621790 := by decide
theorem cert_e1211283110686 : check e1211283110686 [[],[]] .sourceHead = true := by decide
def e1211283110710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283110710 : Closed e1211283110710 ∧ code e1211283110710 = 5609329621814 := by decide
theorem cert_e1211283110710 : check e1211283110710 [[],[]] .chain = true := by decide
def e1211283110714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283110714 : Closed e1211283110714 ∧ code e1211283110714 = 5609329621818 := by decide
theorem cert_e1211283110714 : check e1211283110714 [[],[]] .chain = true := by decide
def e1211283110798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211283110798 : Closed e1211283110798 ∧ code e1211283110798 = 5609329621902 := by decide
theorem cert_e1211283110798 : check e1211283110798 [[],[]] .sourceHead = true := by decide
def e1211283117934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211283117934 : Closed e1211283117934 ∧ code e1211283117934 = 5609329629038 := by decide
theorem cert_e1211283117934 : check e1211283117934 [[],[]] .chain = true := by decide
def e1211283117942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211283117942 : Closed e1211283117942 ∧ code e1211283117942 = 5609329629046 := by decide
theorem cert_e1211283117942 : check e1211283117942 [[],[]] .chain = true := by decide
def e1211283118006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211283118006 : Closed e1211283118006 ∧ code e1211283118006 = 5609329629110 := by decide
theorem cert_e1211283118006 : check e1211283118006 [[],[]] .chain = true := by decide
def e1211283119342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283119342 : Closed e1211283119342 ∧ code e1211283119342 = 5609329630446 := by decide
theorem cert_e1211283119342 : check e1211283119342 [[],[]] .chain = true := by decide
def e1211283119350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283119350 : Closed e1211283119350 ∧ code e1211283119350 = 5609329630454 := by decide
theorem cert_e1211283119350 : check e1211283119350 [[],[]] .chain = true := by decide
def e1211283119734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211283119734 : Closed e1211283119734 ∧ code e1211283119734 = 5609329630838 := by decide
theorem cert_e1211283119734 : check e1211283119734 [[],[]] .chain = true := by decide
def e1211283128446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211283128446 : Closed e1211283128446 ∧ code e1211283128446 = 5609329639550 := by decide
theorem cert_e1211283128446 : check e1211283128446 [[],[]] .chain = true := by decide
def e1211283129310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211283129310 : Closed e1211283129310 ∧ code e1211283129310 = 5609329640414 := by decide
theorem cert_e1211283129310 : check e1211283129310 [[],[]] .chain = true := by decide
def e1211283129314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211283129314 : Closed e1211283129314 ∧ code e1211283129314 = 5609329640418 := by decide
theorem cert_e1211283129314 : check e1211283129314 [[],[]] .chain = true := by decide
def e1211283129326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211283129326 : Closed e1211283129326 ∧ code e1211283129326 = 5609329640430 := by decide
theorem cert_e1211283129326 : check e1211283129326 [[],[]] .chain = true := by decide
def e1211283131246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211283131246 : Closed e1211283131246 ∧ code e1211283131246 = 5609329642350 := by decide
theorem cert_e1211283131246 : check e1211283131246 [[],[]] .chain = true := by decide
def e1211283131254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211283131254 : Closed e1211283131254 ∧ code e1211283131254 = 5609329642358 := by decide
theorem cert_e1211283131254 : check e1211283131254 [[],[]] .chain = true := by decide
def e1211283131310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211283131310 : Closed e1211283131310 ∧ code e1211283131310 = 5609329642414 := by decide
theorem cert_e1211283131310 : check e1211283131310 [[],[]] .chain = true := by decide
def e1211283131322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211283131322 : Closed e1211283131322 ∧ code e1211283131322 = 5609329642426 := by decide
theorem cert_e1211283131322 : check e1211283131322 [[],[]] .chain = true := by decide
def e1211283131350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211283131350 : Closed e1211283131350 ∧ code e1211283131350 = 5609329642454 := by decide
theorem cert_e1211283131350 : check e1211283131350 [[],[]] .chain = true := by decide
def e1211283131354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211283131354 : Closed e1211283131354 ∧ code e1211283131354 = 5609329642458 := by decide
theorem cert_e1211283131354 : check e1211283131354 [[],[]] .chain = true := by decide
def e1211283131630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283131630 : Closed e1211283131630 ∧ code e1211283131630 = 5609329642734 := by decide
theorem cert_e1211283131630 : check e1211283131630 [[],[]] .chain = true := by decide
def e1211283131638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283131638 : Closed e1211283131638 ∧ code e1211283131638 = 5609329642742 := by decide
theorem cert_e1211283131638 : check e1211283131638 [[],[]] .chain = true := by decide
def e1211283132014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211283132014 : Closed e1211283132014 ∧ code e1211283132014 = 5609329643118 := by decide
theorem cert_e1211283132014 : check e1211283132014 [[],[]] .chain = true := by decide
def e1211283132026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211283132026 : Closed e1211283132026 ∧ code e1211283132026 = 5609329643130 := by decide
theorem cert_e1211283132026 : check e1211283132026 [[],[]] .chain = true := by decide
def e1211283132166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283132166 : Closed e1211283132166 ∧ code e1211283132166 = 5609329643270 := by decide
theorem cert_e1211283132166 : check e1211283132166 [[],[]] .chain = true := by decide
def e1211283132190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211283132190 : Closed e1211283132190 ∧ code e1211283132190 = 5609329643294 := by decide
theorem cert_e1211283132190 : check e1211283132190 [[],[]] .sourceHead = true := by decide
def e1211283132214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283132214 : Closed e1211283132214 ∧ code e1211283132214 = 5609329643318 := by decide
theorem cert_e1211283132214 : check e1211283132214 [[],[]] .chain = true := by decide
def e1211283132218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283132218 : Closed e1211283132218 ∧ code e1211283132218 = 5609329643322 := by decide
theorem cert_e1211283132218 : check e1211283132218 [[],[]] .chain = true := by decide
def e1211283136574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211283136574 : Closed e1211283136574 ∧ code e1211283136574 = 5609329647678 := by decide
theorem cert_e1211283136574 : check e1211283136574 [[],[]] .chain = true := by decide
def e1211283136994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211283136994 : Closed e1211283136994 ∧ code e1211283136994 = 5609329648098 := by decide
theorem cert_e1211283136994 : check e1211283136994 [[],[]] .chain = true := by decide
def e1211283137006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211283137006 : Closed e1211283137006 ∧ code e1211283137006 = 5609329648110 := by decide
theorem cert_e1211283137006 : check e1211283137006 [[],[]] .chain = true := by decide
def e1211283137974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211283137974 : Closed e1211283137974 ∧ code e1211283137974 = 5609329649078 := by decide
theorem cert_e1211283137974 : check e1211283137974 [[],[]] .chain = true := by decide
def e1211283138006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211283138006 : Closed e1211283138006 ∧ code e1211283138006 = 5609329649110 := by decide
theorem cert_e1211283138006 : check e1211283138006 [[],[]] .chain = true := by decide
def e1211283138010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211283138010 : Closed e1211283138010 ∧ code e1211283138010 = 5609329649114 := by decide
theorem cert_e1211283138010 : check e1211283138010 [[],[]] .chain = true := by decide
def e1211283138166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211283138166 : Closed e1211283138166 ∧ code e1211283138166 = 5609329649270 := by decide
theorem cert_e1211283138166 : check e1211283138166 [[],[]] .chain = true := by decide
def e1211283138310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283138310 : Closed e1211283138310 ∧ code e1211283138310 = 5609329649414 := by decide
theorem cert_e1211283138310 : check e1211283138310 [[],[]] .chain = true := by decide
def e1211283138334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211283138334 : Closed e1211283138334 ∧ code e1211283138334 = 5609329649438 := by decide
theorem cert_e1211283138334 : check e1211283138334 [[],[]] .sourceHead = true := by decide
def e1211283138358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283138358 : Closed e1211283138358 ∧ code e1211283138358 = 5609329649462 := by decide
theorem cert_e1211283138358 : check e1211283138358 [[],[]] .chain = true := by decide
def e1211283138362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283138362 : Closed e1211283138362 ∧ code e1211283138362 = 5609329649466 := by decide
theorem cert_e1211283138362 : check e1211283138362 [[],[]] .chain = true := by decide
def e1211283138446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211283138446 : Closed e1211283138446 ∧ code e1211283138446 = 5609329649550 := by decide
theorem cert_e1211283138446 : check e1211283138446 [[],[]] .sourceHead = true := by decide
def e1211283278702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211283278702 : Closed e1211283278702 ∧ code e1211283278702 = 5609329789806 := by decide
theorem cert_e1211283278702 : check e1211283278702 [[],[]] .smaller = true := by decide
def e1211283278710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211283278710 : Closed e1211283278710 ∧ code e1211283278710 = 5609329789814 := by decide
theorem cert_e1211283278710 : check e1211283278710 [[],[]] .smaller = true := by decide
def e1211283278766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211283278766 : Closed e1211283278766 ∧ code e1211283278766 = 5609329789870 := by decide
theorem cert_e1211283278766 : check e1211283278766 [[],[]] .smaller = true := by decide
def e1211283278778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211283278778 : Closed e1211283278778 ∧ code e1211283278778 = 5609329789882 := by decide
theorem cert_e1211283278778 : check e1211283278778 [[],[]] .smaller = true := by decide
def e1211283278806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211283278806 : Closed e1211283278806 ∧ code e1211283278806 = 5609329789910 := by decide
theorem cert_e1211283278806 : check e1211283278806 [[],[]] .smaller = true := by decide
def e1211283278810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211283278810 : Closed e1211283278810 ∧ code e1211283278810 = 5609329789914 := by decide
theorem cert_e1211283278810 : check e1211283278810 [[],[]] .smaller = true := by decide
def e1211283279086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211283279086 : Closed e1211283279086 ∧ code e1211283279086 = 5609329790190 := by decide
theorem cert_e1211283279086 : check e1211283279086 [[],[]] .smaller = true := by decide
def e1211283279094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211283279094 : Closed e1211283279094 ∧ code e1211283279094 = 5609329790198 := by decide
theorem cert_e1211283279094 : check e1211283279094 [[],[]] .smaller = true := by decide
def e1211283279470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211283279470 : Closed e1211283279470 ∧ code e1211283279470 = 5609329790574 := by decide
theorem cert_e1211283279470 : check e1211283279470 [[],[]] .smaller = true := by decide
def e1211283279482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211283279482 : Closed e1211283279482 ∧ code e1211283279482 = 5609329790586 := by decide
theorem cert_e1211283279482 : check e1211283279482 [[],[]] .smaller = true := by decide
def e1211283279670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211283279670 : Closed e1211283279670 ∧ code e1211283279670 = 5609329790774 := by decide
theorem cert_e1211283279670 : check e1211283279670 [[],[]] .smaller = true := by decide
def e1211283279674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211283279674 : Closed e1211283279674 ∧ code e1211283279674 = 5609329790778 := by decide
theorem cert_e1211283279674 : check e1211283279674 [[],[]] .smaller = true := by decide
def e1211283287518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211283287518 : Closed e1211283287518 ∧ code e1211283287518 = 5609329798622 := by decide
theorem cert_e1211283287518 : check e1211283287518 [[],[]] .chain = true := by decide
def e1211283287534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211283287534 : Closed e1211283287534 ∧ code e1211283287534 = 5609329798638 := by decide
theorem cert_e1211283287534 : check e1211283287534 [[],[]] .chain = true := by decide
def e1211283287774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211283287774 : Closed e1211283287774 ∧ code e1211283287774 = 5609329798878 := by decide
theorem cert_e1211283287774 : check e1211283287774 [[],[]] .chain = true := by decide
def e1211283287798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211283287798 : Closed e1211283287798 ∧ code e1211283287798 = 5609329798902 := by decide
theorem cert_e1211283287798 : check e1211283287798 [[],[]] .chain = true := by decide
def e1211283287902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211283287902 : Closed e1211283287902 ∧ code e1211283287902 = 5609329799006 := by decide
theorem cert_e1211283287902 : check e1211283287902 [[],[]] .chain = true := by decide
def e1211283287930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211283287930 : Closed e1211283287930 ∧ code e1211283287930 = 5609329799034 := by decide
theorem cert_e1211283287930 : check e1211283287930 [[],[]] .chain = true := by decide
def e1211283287982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211283287982 : Closed e1211283287982 ∧ code e1211283287982 = 5609329799086 := by decide
theorem cert_e1211283287982 : check e1211283287982 [[],[]] .chain = true := by decide
def e1211283287990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211283287990 : Closed e1211283287990 ∧ code e1211283287990 = 5609329799094 := by decide
theorem cert_e1211283287990 : check e1211283287990 [[],[]] .chain = true := by decide
def e1211283287994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211283287994 : Closed e1211283287994 ∧ code e1211283287994 = 5609329799098 := by decide
theorem cert_e1211283287994 : check e1211283287994 [[],[]] .chain = true := by decide
def e1211283289054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211283289054 : Closed e1211283289054 ∧ code e1211283289054 = 5609329800158 := by decide
theorem cert_e1211283289054 : check e1211283289054 [[],[]] .chain = true := by decide
def e1211283289070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211283289070 : Closed e1211283289070 ∧ code e1211283289070 = 5609329800174 := by decide
theorem cert_e1211283289070 : check e1211283289070 [[],[]] .chain = true := by decide
def e1211283290590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211283290590 : Closed e1211283290590 ∧ code e1211283290590 = 5609329801694 := by decide
theorem cert_e1211283290590 : check e1211283290590 [[],[]] .chain = true := by decide
def e1211283290614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211283290614 : Closed e1211283290614 ∧ code e1211283290614 = 5609329801718 := by decide
theorem cert_e1211283290614 : check e1211283290614 [[],[]] .chain = true := by decide
def e1211283291358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211283291358 : Closed e1211283291358 ∧ code e1211283291358 = 5609329802462 := by decide
theorem cert_e1211283291358 : check e1211283291358 [[],[]] .chain = true := by decide
def e1211283291386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211283291386 : Closed e1211283291386 ∧ code e1211283291386 = 5609329802490 := by decide
theorem cert_e1211283291386 : check e1211283291386 [[],[]] .chain = true := by decide
def e1211283291758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211283291758 : Closed e1211283291758 ∧ code e1211283291758 = 5609329802862 := by decide
theorem cert_e1211283291758 : check e1211283291758 [[],[]] .chain = true := by decide
def e1211283291766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211283291766 : Closed e1211283291766 ∧ code e1211283291766 = 5609329802870 := by decide
theorem cert_e1211283291766 : check e1211283291766 [[],[]] .chain = true := by decide
def e1211283291770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211283291770 : Closed e1211283291770 ∧ code e1211283291770 = 5609329802874 := by decide
theorem cert_e1211283291770 : check e1211283291770 [[],[]] .chain = true := by decide
def e1211283320174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211283320174 : Closed e1211283320174 ∧ code e1211283320174 = 5609329831278 := by decide
theorem cert_e1211283320174 : check e1211283320174 [[],[]] .chain = true := by decide
def e1211283320182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211283320182 : Closed e1211283320182 ∧ code e1211283320182 = 5609329831286 := by decide
theorem cert_e1211283320182 : check e1211283320182 [[],[]] .chain = true := by decide
def e1211283320238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211283320238 : Closed e1211283320238 ∧ code e1211283320238 = 5609329831342 := by decide
theorem cert_e1211283320238 : check e1211283320238 [[],[]] .chain = true := by decide
def e1211283320250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211283320250 : Closed e1211283320250 ∧ code e1211283320250 = 5609329831354 := by decide
theorem cert_e1211283320250 : check e1211283320250 [[],[]] .chain = true := by decide
def e1211283320278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211283320278 : Closed e1211283320278 ∧ code e1211283320278 = 5609329831382 := by decide
theorem cert_e1211283320278 : check e1211283320278 [[],[]] .chain = true := by decide
def e1211283320282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211283320282 : Closed e1211283320282 ∧ code e1211283320282 = 5609329831386 := by decide
theorem cert_e1211283320282 : check e1211283320282 [[],[]] .chain = true := by decide
def e1211283320494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211283320494 : Closed e1211283320494 ∧ code e1211283320494 = 5609329831598 := by decide
theorem cert_e1211283320494 : check e1211283320494 [[],[]] .chain = true := by decide
def e1211283320506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211283320506 : Closed e1211283320506 ∧ code e1211283320506 = 5609329831610 := by decide
theorem cert_e1211283320506 : check e1211283320506 [[],[]] .chain = true := by decide
def e1211283320554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211283320554 : Closed e1211283320554 ∧ code e1211283320554 = 5609329831658 := by decide
theorem cert_e1211283320554 : check e1211283320554 [[],[]] .chain = true := by decide
def e1211283320662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211283320662 : Closed e1211283320662 ∧ code e1211283320662 = 5609329831766 := by decide
theorem cert_e1211283320662 : check e1211283320662 [[],[]] .chain = true := by decide
end Blc.Floor42
