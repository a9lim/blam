import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194588155310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1194588155310 : Closed e1194588155310 ∧ code e1194588155310 = 5592634666414 := by decide
theorem cert_e1194588155310 : check e1194588155310 [[],[.left],[]] .smaller = true := by decide
def e1194588155322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1194588155322 : Closed e1194588155322 ∧ code e1194588155322 = 5592634666426 := by decide
theorem cert_e1194588155322 : check e1194588155322 [[],[.left],[]] .smaller = true := by decide
def e1194588155350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1194588155350 : Closed e1194588155350 ∧ code e1194588155350 = 5592634666454 := by decide
theorem cert_e1194588155350 : check e1194588155350 [[],[.left],[]] .smaller = true := by decide
def e1194588155354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1194588155354 : Closed e1194588155354 ∧ code e1194588155354 = 5592634666458 := by decide
theorem cert_e1194588155354 : check e1194588155354 [[],[.left],[]] .smaller = true := by decide
def e1194588155566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1194588155566 : Closed e1194588155566 ∧ code e1194588155566 = 5592634666670 := by decide
theorem cert_e1194588155566 : check e1194588155566 [[],[.left],[]] .smaller = true := by decide
def e1194588155578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1194588155578 : Closed e1194588155578 ∧ code e1194588155578 = 5592634666682 := by decide
theorem cert_e1194588155578 : check e1194588155578 [[],[.left],[]] .smaller = true := by decide
def e1194588155626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1194588155626 : Closed e1194588155626 ∧ code e1194588155626 = 5592634666730 := by decide
theorem cert_e1194588155626 : check e1194588155626 [[],[.left],[]] .smaller = true := by decide
def e1194588155734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1194588155734 : Closed e1194588155734 ∧ code e1194588155734 = 5592634666838 := by decide
theorem cert_e1194588155734 : check e1194588155734 [[],[.left],[]] .smaller = true := by decide
def e1194588155738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1194588155738 : Closed e1194588155738 ∧ code e1194588155738 = 5592634666842 := by decide
theorem cert_e1194588155738 : check e1194588155738 [[],[.left],[]] .smaller = true := by decide
def e1194588155754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1194588155754 : Closed e1194588155754 ∧ code e1194588155754 = 5592634666858 := by decide
theorem cert_e1194588155754 : check e1194588155754 [[],[.left],[]] .smaller = true := by decide
def e1194588156782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1194588156782 : Closed e1194588156782 ∧ code e1194588156782 = 5592634667886 := by decide
theorem cert_e1194588156782 : check e1194588156782 [[],[.left],[]] .smaller = true := by decide
def e1194588156790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1194588156790 : Closed e1194588156790 ∧ code e1194588156790 = 5592634667894 := by decide
theorem cert_e1194588156790 : check e1194588156790 [[],[.left],[]] .smaller = true := by decide
def e1194588156846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1194588156846 : Closed e1194588156846 ∧ code e1194588156846 = 5592634667950 := by decide
theorem cert_e1194588156846 : check e1194588156846 [[],[.left],[]] .smaller = true := by decide
def e1194588156858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1194588156858 : Closed e1194588156858 ∧ code e1194588156858 = 5592634667962 := by decide
theorem cert_e1194588156858 : check e1194588156858 [[],[.left],[]] .smaller = true := by decide
def e1194588156886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1194588156886 : Closed e1194588156886 ∧ code e1194588156886 = 5592634667990 := by decide
theorem cert_e1194588156886 : check e1194588156886 [[],[.left],[]] .smaller = true := by decide
def e1194588156890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1194588156890 : Closed e1194588156890 ∧ code e1194588156890 = 5592634667994 := by decide
theorem cert_e1194588156890 : check e1194588156890 [[],[.left],[]] .smaller = true := by decide
def e1194588157166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194588157166 : Closed e1194588157166 ∧ code e1194588157166 = 5592634668270 := by decide
theorem cert_e1194588157166 : check e1194588157166 [[],[.left],[]] .smaller = true := by decide
def e1194588157174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194588157174 : Closed e1194588157174 ∧ code e1194588157174 = 5592634668278 := by decide
theorem cert_e1194588157174 : check e1194588157174 [[],[.left],[]] .smaller = true := by decide
def e1194588157550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194588157550 : Closed e1194588157550 ∧ code e1194588157550 = 5592634668654 := by decide
theorem cert_e1194588157550 : check e1194588157550 [[],[.left],[]] .smaller = true := by decide
def e1194588157562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194588157562 : Closed e1194588157562 ∧ code e1194588157562 = 5592634668666 := by decide
theorem cert_e1194588157562 : check e1194588157562 [[],[.left],[]] .smaller = true := by decide
def e1194588157750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194588157750 : Closed e1194588157750 ∧ code e1194588157750 = 5592634668854 := by decide
theorem cert_e1194588157750 : check e1194588157750 [[],[.left],[]] .smaller = true := by decide
def e1194588157754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194588157754 : Closed e1194588157754 ∧ code e1194588157754 = 5592634668858 := by decide
theorem cert_e1194588157754 : check e1194588157754 [[],[.left],[]] .smaller = true := by decide
def e1194588158382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1194588158382 : Closed e1194588158382 ∧ code e1194588158382 = 5592634669486 := by decide
theorem cert_e1194588158382 : check e1194588158382 [[],[.left],[]] .smaller = true := by decide
def e1194588158394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1194588158394 : Closed e1194588158394 ∧ code e1194588158394 = 5592634669498 := by decide
theorem cert_e1194588158394 : check e1194588158394 [[],[.left],[]] .smaller = true := by decide
def e1194588158442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1194588158442 : Closed e1194588158442 ∧ code e1194588158442 = 5592634669546 := by decide
theorem cert_e1194588158442 : check e1194588158442 [[],[.left],[]] .smaller = true := by decide
def e1194588158574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194588158574 : Closed e1194588158574 ∧ code e1194588158574 = 5592634669678 := by decide
theorem cert_e1194588158574 : check e1194588158574 [[],[.left],[]] .smaller = true := by decide
def e1194588158586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194588158586 : Closed e1194588158586 ∧ code e1194588158586 = 5592634669690 := by decide
theorem cert_e1194588158586 : check e1194588158586 [[],[.left],[]] .smaller = true := by decide
def e1194588158874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194588158874 : Closed e1194588158874 ∧ code e1194588158874 = 5592634669978 := by decide
theorem cert_e1194588158874 : check e1194588158874 [[],[.left],[]] .smaller = true := by decide
def e1194588159190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1194588159190 : Closed e1194588159190 ∧ code e1194588159190 = 5592634670294 := by decide
theorem cert_e1194588159190 : check e1194588159190 [[],[.left],[]] .smaller = true := by decide
def e1194588159194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1194588159194 : Closed e1194588159194 ∧ code e1194588159194 = 5592634670298 := by decide
theorem cert_e1194588159194 : check e1194588159194 [[],[.left],[]] .smaller = true := by decide
def e1194588159210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1194588159210 : Closed e1194588159210 ∧ code e1194588159210 = 5592634670314 := by decide
theorem cert_e1194588159210 : check e1194588159210 [[],[.left],[]] .smaller = true := by decide
def e1194588159286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194588159286 : Closed e1194588159286 ∧ code e1194588159286 = 5592634670390 := by decide
theorem cert_e1194588159286 : check e1194588159286 [[],[.left],[]] .smaller = true := by decide
def e1194588159290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194588159290 : Closed e1194588159290 ∧ code e1194588159290 = 5592634670394 := by decide
theorem cert_e1194588159290 : check e1194588159290 [[],[.left],[]] .smaller = true := by decide
def e1194588159386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194588159386 : Closed e1194588159386 ∧ code e1194588159386 = 5592634670490 := by decide
theorem cert_e1194588159386 : check e1194588159386 [[],[.left],[]] .smaller = true := by decide
def e1194588162926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194588162926 : Closed e1194588162926 ∧ code e1194588162926 = 5592634674030 := by decide
theorem cert_e1194588162926 : check e1194588162926 [[],[.left],[]] .smaller = true := by decide
def e1194588162934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194588162934 : Closed e1194588162934 ∧ code e1194588162934 = 5592634674038 := by decide
theorem cert_e1194588162934 : check e1194588162934 [[],[.left],[]] .smaller = true := by decide
def e1194588162990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194588162990 : Closed e1194588162990 ∧ code e1194588162990 = 5592634674094 := by decide
theorem cert_e1194588162990 : check e1194588162990 [[],[.left],[]] .smaller = true := by decide
def e1194588163002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194588163002 : Closed e1194588163002 ∧ code e1194588163002 = 5592634674106 := by decide
theorem cert_e1194588163002 : check e1194588163002 [[],[.left],[]] .smaller = true := by decide
def e1194588163030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194588163030 : Closed e1194588163030 ∧ code e1194588163030 = 5592634674134 := by decide
theorem cert_e1194588163030 : check e1194588163030 [[],[.left],[]] .smaller = true := by decide
def e1194588163034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194588163034 : Closed e1194588163034 ∧ code e1194588163034 = 5592634674138 := by decide
theorem cert_e1194588163034 : check e1194588163034 [[],[.left],[]] .smaller = true := by decide
def e1194588163310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194588163310 : Closed e1194588163310 ∧ code e1194588163310 = 5592634674414 := by decide
theorem cert_e1194588163310 : check e1194588163310 [[],[.left],[]] .smaller = true := by decide
def e1194588163318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194588163318 : Closed e1194588163318 ∧ code e1194588163318 = 5592634674422 := by decide
theorem cert_e1194588163318 : check e1194588163318 [[],[.left],[]] .smaller = true := by decide
def e1194588163694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194588163694 : Closed e1194588163694 ∧ code e1194588163694 = 5592634674798 := by decide
theorem cert_e1194588163694 : check e1194588163694 [[],[.left],[]] .smaller = true := by decide
def e1194588163706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194588163706 : Closed e1194588163706 ∧ code e1194588163706 = 5592634674810 := by decide
theorem cert_e1194588163706 : check e1194588163706 [[],[.left],[]] .smaller = true := by decide
def e1194588163894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194588163894 : Closed e1194588163894 ∧ code e1194588163894 = 5592634674998 := by decide
theorem cert_e1194588163894 : check e1194588163894 [[],[.left],[]] .smaller = true := by decide
def e1194588163898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194588163898 : Closed e1194588163898 ∧ code e1194588163898 = 5592634675002 := by decide
theorem cert_e1194588163898 : check e1194588163898 [[],[.left],[]] .smaller = true := by decide
def e1194588169646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1194588169646 : Closed e1194588169646 ∧ code e1194588169646 = 5592634680750 := by decide
theorem cert_e1194588169646 : check e1194588169646 [[],[.left],[]] .smaller = true := by decide
def e1194588169658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1194588169658 : Closed e1194588169658 ∧ code e1194588169658 = 5592634680762 := by decide
theorem cert_e1194588169658 : check e1194588169658 [[],[.left],[]] .smaller = true := by decide
def e1194588169706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1194588169706 : Closed e1194588169706 ∧ code e1194588169706 = 5592634680810 := by decide
theorem cert_e1194588169706 : check e1194588169706 [[],[.left],[]] .smaller = true := by decide
def e1194588169838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1194588169838 : Closed e1194588169838 ∧ code e1194588169838 = 5592634680942 := by decide
theorem cert_e1194588169838 : check e1194588169838 [[],[.left],[]] .smaller = true := by decide
def e1194588169850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1194588169850 : Closed e1194588169850 ∧ code e1194588169850 = 5592634680954 := by decide
theorem cert_e1194588169850 : check e1194588169850 [[],[.left],[]] .smaller = true := by decide
def e1194588170138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1194588170138 : Closed e1194588170138 ∧ code e1194588170138 = 5592634681242 := by decide
theorem cert_e1194588170138 : check e1194588170138 [[],[.left],[]] .smaller = true := by decide
def e1194588173014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1194588173014 : Closed e1194588173014 ∧ code e1194588173014 = 5592634684118 := by decide
theorem cert_e1194588173014 : check e1194588173014 [[],[.left],[]] .smaller = true := by decide
def e1194588173018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1194588173018 : Closed e1194588173018 ∧ code e1194588173018 = 5592634684122 := by decide
theorem cert_e1194588173018 : check e1194588173018 [[],[.left],[]] .smaller = true := by decide
def e1194588173034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1194588173034 : Closed e1194588173034 ∧ code e1194588173034 = 5592634684138 := by decide
theorem cert_e1194588173034 : check e1194588173034 [[],[.left],[]] .smaller = true := by decide
def e1194588173110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1194588173110 : Closed e1194588173110 ∧ code e1194588173110 = 5592634684214 := by decide
theorem cert_e1194588173110 : check e1194588173110 [[],[.left],[]] .smaller = true := by decide
def e1194588173114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1194588173114 : Closed e1194588173114 ∧ code e1194588173114 = 5592634684218 := by decide
theorem cert_e1194588173114 : check e1194588173114 [[],[.left],[]] .smaller = true := by decide
def e1194588173210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1194588173210 : Closed e1194588173210 ∧ code e1194588173210 = 5592634684314 := by decide
theorem cert_e1194588173210 : check e1194588173210 [[],[.left],[]] .smaller = true := by decide
def e1194588310382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194588310382 : Closed e1194588310382 ∧ code e1194588310382 = 5592634821486 := by decide
theorem cert_e1194588310382 : check e1194588310382 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194588310390 : Closed e1194588310390 ∧ code e1194588310390 = 5592634821494 := by decide
theorem cert_e1194588310390 : check e1194588310390 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194588310446 : Closed e1194588310446 ∧ code e1194588310446 = 5592634821550 := by decide
theorem cert_e1194588310446 : check e1194588310446 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194588310458 : Closed e1194588310458 ∧ code e1194588310458 = 5592634821562 := by decide
theorem cert_e1194588310458 : check e1194588310458 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194588310486 : Closed e1194588310486 ∧ code e1194588310486 = 5592634821590 := by decide
theorem cert_e1194588310486 : check e1194588310486 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194588310490 : Closed e1194588310490 ∧ code e1194588310490 = 5592634821594 := by decide
theorem cert_e1194588310490 : check e1194588310490 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194588310766 : Closed e1194588310766 ∧ code e1194588310766 = 5592634821870 := by decide
theorem cert_e1194588310766 : check e1194588310766 [[],[.left],[],[]] .smaller = true := by decide
def e1194588310774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194588310774 : Closed e1194588310774 ∧ code e1194588310774 = 5592634821878 := by decide
theorem cert_e1194588310774 : check e1194588310774 [[],[.left],[],[]] .smaller = true := by decide
def e1194588311150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194588311150 : Closed e1194588311150 ∧ code e1194588311150 = 5592634822254 := by decide
theorem cert_e1194588311150 : check e1194588311150 [[],[.left],[],[]] .smaller = true := by decide
def e1194588311162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194588311162 : Closed e1194588311162 ∧ code e1194588311162 = 5592634822266 := by decide
theorem cert_e1194588311162 : check e1194588311162 [[],[.left],[],[]] .smaller = true := by decide
def e1194588311350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194588311350 : Closed e1194588311350 ∧ code e1194588311350 = 5592634822454 := by decide
theorem cert_e1194588311350 : check e1194588311350 [[],[.left],[],[]] .smaller = true := by decide
def e1194588311354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194588311354 : Closed e1194588311354 ∧ code e1194588311354 = 5592634822458 := by decide
theorem cert_e1194588311354 : check e1194588311354 [[],[.left],[],[]] .smaller = true := by decide
def e1194588900206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194588900206 : Closed e1194588900206 ∧ code e1194588900206 = 5592635411310 := by decide
theorem cert_e1194588900206 : check e1194588900206 [[],[.left]] .chain = true := by decide
def e1194588900214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194588900214 : Closed e1194588900214 ∧ code e1194588900214 = 5592635411318 := by decide
theorem cert_e1194588900214 : check e1194588900214 [[],[.left]] .chain = true := by decide
def e1194588900270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194588900270 : Closed e1194588900270 ∧ code e1194588900270 = 5592635411374 := by decide
theorem cert_e1194588900270 : check e1194588900270 [[],[.left]] .chain = true := by decide
def e1194588900282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194588900282 : Closed e1194588900282 ∧ code e1194588900282 = 5592635411386 := by decide
theorem cert_e1194588900282 : check e1194588900282 [[],[.left]] .chain = true := by decide
def e1194588900310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194588900310 : Closed e1194588900310 ∧ code e1194588900310 = 5592635411414 := by decide
theorem cert_e1194588900310 : check e1194588900310 [[],[.left]] .chain = true := by decide
def e1194588900314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194588900314 : Closed e1194588900314 ∧ code e1194588900314 = 5592635411418 := by decide
theorem cert_e1194588900314 : check e1194588900314 [[],[.left]] .chain = true := by decide
def e1194588900590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194588900590 : Closed e1194588900590 ∧ code e1194588900590 = 5592635411694 := by decide
theorem cert_e1194588900590 : check e1194588900590 [[],[.left]] .chain = true := by decide
def e1194588900598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194588900598 : Closed e1194588900598 ∧ code e1194588900598 = 5592635411702 := by decide
theorem cert_e1194588900598 : check e1194588900598 [[],[.left]] .chain = true := by decide
def e1194588900974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194588900974 : Closed e1194588900974 ∧ code e1194588900974 = 5592635412078 := by decide
theorem cert_e1194588900974 : check e1194588900974 [[],[.left]] .chain = true := by decide
def e1194588900986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194588900986 : Closed e1194588900986 ∧ code e1194588900986 = 5592635412090 := by decide
theorem cert_e1194588900986 : check e1194588900986 [[],[.left]] .chain = true := by decide
def e1194588901174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194588901174 : Closed e1194588901174 ∧ code e1194588901174 = 5592635412278 := by decide
theorem cert_e1194588901174 : check e1194588901174 [[],[.left]] .chain = true := by decide
def e1194588901178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194588901178 : Closed e1194588901178 ∧ code e1194588901178 = 5592635412282 := by decide
theorem cert_e1194588901178 : check e1194588901178 [[],[.left]] .chain = true := by decide
def e1194672085726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1194672085726 : Closed e1194672085726 ∧ code e1194672085726 = 5592718596830 := by decide
theorem cert_e1194672085726 : check e1194672085726 [[],[.left],[]] .smaller = true := by decide
def e1194672085750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1194672085750 : Closed e1194672085750 ∧ code e1194672085750 = 5592718596854 := by decide
theorem cert_e1194672085750 : check e1194672085750 [[],[.left],[]] .smaller = true := by decide
def e1194672085854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1194672085854 : Closed e1194672085854 ∧ code e1194672085854 = 5592718596958 := by decide
theorem cert_e1194672085854 : check e1194672085854 [[],[.left],[]] .smaller = true := by decide
def e1194672085870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1194672085870 : Closed e1194672085870 ∧ code e1194672085870 = 5592718596974 := by decide
theorem cert_e1194672085870 : check e1194672085870 [[],[.left],[]] .chain = true := by decide
def e1194672085878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1194672085878 : Closed e1194672085878 ∧ code e1194672085878 = 5592718596982 := by decide
theorem cert_e1194672085878 : check e1194672085878 [[],[.left],[]] .chain = true := by decide
def e1194672085882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1194672085882 : Closed e1194672085882 ∧ code e1194672085882 = 5592718596986 := by decide
theorem cert_e1194672085882 : check e1194672085882 [[],[.left],[]] .smaller = true := by decide
def e1194672085942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1194672085942 : Closed e1194672085942 ∧ code e1194672085942 = 5592718597046 := by decide
theorem cert_e1194672085942 : check e1194672085942 [[],[.left],[]] .chain = true := by decide
def e1194672085974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1194672085974 : Closed e1194672085974 ∧ code e1194672085974 = 5592718597078 := by decide
theorem cert_e1194672085974 : check e1194672085974 [[],[.left],[]] .smaller = true := by decide
def e1194672085978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1194672085978 : Closed e1194672085978 ∧ code e1194672085978 = 5592718597082 := by decide
theorem cert_e1194672085978 : check e1194672085978 [[],[.left],[]] .smaller = true := by decide
def e1194672086366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1194672086366 : Closed e1194672086366 ∧ code e1194672086366 = 5592718597470 := by decide
theorem cert_e1194672086366 : check e1194672086366 [[],[.left],[]] .smaller = true := by decide
def e1194672086382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1194672086382 : Closed e1194672086382 ∧ code e1194672086382 = 5592718597486 := by decide
theorem cert_e1194672086382 : check e1194672086382 [[],[.left],[]] .chain = true := by decide
def e1194672086390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1194672086390 : Closed e1194672086390 ∧ code e1194672086390 = 5592718597494 := by decide
theorem cert_e1194672086390 : check e1194672086390 [[],[.left],[]] .chain = true := by decide
def e1194672086394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1194672086394 : Closed e1194672086394 ∧ code e1194672086394 = 5592718597498 := by decide
theorem cert_e1194672086394 : check e1194672086394 [[],[.left],[]] .smaller = true := by decide
def e1194672086446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1194672086446 : Closed e1194672086446 ∧ code e1194672086446 = 5592718597550 := by decide
theorem cert_e1194672086446 : check e1194672086446 [[],[.left],[]] .chain = true := by decide
def e1194672086458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1194672086458 : Closed e1194672086458 ∧ code e1194672086458 = 5592718597562 := by decide
theorem cert_e1194672086458 : check e1194672086458 [[],[.left],[]] .chain = true := by decide
def e1194672086486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1194672086486 : Closed e1194672086486 ∧ code e1194672086486 = 5592718597590 := by decide
theorem cert_e1194672086486 : check e1194672086486 [[],[.left],[]] .chain = true := by decide
def e1194672086490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1194672086490 : Closed e1194672086490 ∧ code e1194672086490 = 5592718597594 := by decide
theorem cert_e1194672086490 : check e1194672086490 [[],[.left],[]] .chain = true := by decide
def e1194672086506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1194672086506 : Closed e1194672086506 ∧ code e1194672086506 = 5592718597610 := by decide
theorem cert_e1194672086506 : check e1194672086506 [[],[.left],[]] .smaller = true := by decide
def e1194672086710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1194672086710 : Closed e1194672086710 ∧ code e1194672086710 = 5592718597814 := by decide
theorem cert_e1194672086710 : check e1194672086710 [[],[.left],[]] .chain = true := by decide
def e1194672086742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1194672086742 : Closed e1194672086742 ∧ code e1194672086742 = 5592718597846 := by decide
theorem cert_e1194672086742 : check e1194672086742 [[],[.left],[]] .chain = true := by decide
def e1194672086746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1194672086746 : Closed e1194672086746 ∧ code e1194672086746 = 5592718597850 := by decide
theorem cert_e1194672086746 : check e1194672086746 [[],[.left],[]] .chain = true := by decide
def e1194672086870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1194672086870 : Closed e1194672086870 ∧ code e1194672086870 = 5592718597974 := by decide
theorem cert_e1194672086870 : check e1194672086870 [[],[.left],[]] .smaller = true := by decide
def e1194672086874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1194672086874 : Closed e1194672086874 ∧ code e1194672086874 = 5592718597978 := by decide
theorem cert_e1194672086874 : check e1194672086874 [[],[.left],[]] .smaller = true := by decide
def e1194672086890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1194672086890 : Closed e1194672086890 ∧ code e1194672086890 = 5592718597994 := by decide
theorem cert_e1194672086890 : check e1194672086890 [[],[.left],[]] .smaller = true := by decide
def e1194672088798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1194672088798 : Closed e1194672088798 ∧ code e1194672088798 = 5592718599902 := by decide
theorem cert_e1194672088798 : check e1194672088798 [[],[.left],[]] .smaller = true := by decide
def e1194672088822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1194672088822 : Closed e1194672088822 ∧ code e1194672088822 = 5592718599926 := by decide
theorem cert_e1194672088822 : check e1194672088822 [[],[.left],[]] .smaller = true := by decide
def e1194672088926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1194672088926 : Closed e1194672088926 ∧ code e1194672088926 = 5592718600030 := by decide
theorem cert_e1194672088926 : check e1194672088926 [[],[.left],[]] .smaller = true := by decide
def e1194672088942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1194672088942 : Closed e1194672088942 ∧ code e1194672088942 = 5592718600046 := by decide
theorem cert_e1194672088942 : check e1194672088942 [[],[.left],[]] .chain = true := by decide
def e1194672088950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1194672088950 : Closed e1194672088950 ∧ code e1194672088950 = 5592718600054 := by decide
theorem cert_e1194672088950 : check e1194672088950 [[],[.left],[]] .chain = true := by decide
def e1194672088954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1194672088954 : Closed e1194672088954 ∧ code e1194672088954 = 5592718600058 := by decide
theorem cert_e1194672088954 : check e1194672088954 [[],[.left],[]] .smaller = true := by decide
def e1194672089014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1194672089014 : Closed e1194672089014 ∧ code e1194672089014 = 5592718600118 := by decide
theorem cert_e1194672089014 : check e1194672089014 [[],[.left],[]] .chain = true := by decide
def e1194672089046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1194672089046 : Closed e1194672089046 ∧ code e1194672089046 = 5592718600150 := by decide
theorem cert_e1194672089046 : check e1194672089046 [[],[.left],[]] .smaller = true := by decide
def e1194672089050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1194672089050 : Closed e1194672089050 ∧ code e1194672089050 = 5592718600154 := by decide
theorem cert_e1194672089050 : check e1194672089050 [[],[.left],[]] .smaller = true := by decide
def e1194672089566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1194672089566 : Closed e1194672089566 ∧ code e1194672089566 = 5592718600670 := by decide
theorem cert_e1194672089566 : check e1194672089566 [[],[.left],[]] .smaller = true := by decide
def e1194672089590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1194672089590 : Closed e1194672089590 ∧ code e1194672089590 = 5592718600694 := by decide
theorem cert_e1194672089590 : check e1194672089590 [[],[.left],[]] .smaller = true := by decide
def e1194672090334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1194672090334 : Closed e1194672090334 ∧ code e1194672090334 = 5592718601438 := by decide
theorem cert_e1194672090334 : check e1194672090334 [[],[.left],[]] .smaller = true := by decide
def e1194672090350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1194672090350 : Closed e1194672090350 ∧ code e1194672090350 = 5592718601454 := by decide
theorem cert_e1194672090350 : check e1194672090350 [[],[.left],[]] .chain = true := by decide
def e1194672090358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1194672090358 : Closed e1194672090358 ∧ code e1194672090358 = 5592718601462 := by decide
theorem cert_e1194672090358 : check e1194672090358 [[],[.left],[]] .chain = true := by decide
def e1194672090362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1194672090362 : Closed e1194672090362 ∧ code e1194672090362 = 5592718601466 := by decide
theorem cert_e1194672090362 : check e1194672090362 [[],[.left],[]] .smaller = true := by decide
def e1194672090742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1194672090742 : Closed e1194672090742 ∧ code e1194672090742 = 5592718601846 := by decide
theorem cert_e1194672090742 : check e1194672090742 [[],[.left],[]] .chain = true := by decide
def e1194672090934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194672090934 : Closed e1194672090934 ∧ code e1194672090934 = 5592718602038 := by decide
theorem cert_e1194672090934 : check e1194672090934 [[],[.left],[]] .smaller = true := by decide
def e1194672090938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194672090938 : Closed e1194672090938 ∧ code e1194672090938 = 5592718602042 := by decide
theorem cert_e1194672090938 : check e1194672090938 [[],[.left],[]] .smaller = true := by decide
def e1194672091998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1194672091998 : Closed e1194672091998 ∧ code e1194672091998 = 5592718603102 := by decide
theorem cert_e1194672091998 : check e1194672091998 [[],[.left],[]] .smaller = true := by decide
def e1194672092014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1194672092014 : Closed e1194672092014 ∧ code e1194672092014 = 5592718603118 := by decide
theorem cert_e1194672092014 : check e1194672092014 [[],[.left],[]] .chain = true := by decide
def e1194672092022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1194672092022 : Closed e1194672092022 ∧ code e1194672092022 = 5592718603126 := by decide
theorem cert_e1194672092022 : check e1194672092022 [[],[.left],[]] .chain = true := by decide
def e1194672092026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1194672092026 : Closed e1194672092026 ∧ code e1194672092026 = 5592718603130 := by decide
theorem cert_e1194672092026 : check e1194672092026 [[],[.left],[]] .smaller = true := by decide
def e1194672092078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1194672092078 : Closed e1194672092078 ∧ code e1194672092078 = 5592718603182 := by decide
theorem cert_e1194672092078 : check e1194672092078 [[],[.left],[]] .chain = true := by decide
def e1194672092090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1194672092090 : Closed e1194672092090 ∧ code e1194672092090 = 5592718603194 := by decide
theorem cert_e1194672092090 : check e1194672092090 [[],[.left],[]] .chain = true := by decide
def e1194672092118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1194672092118 : Closed e1194672092118 ∧ code e1194672092118 = 5592718603222 := by decide
theorem cert_e1194672092118 : check e1194672092118 [[],[.left],[]] .chain = true := by decide
def e1194672092122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1194672092122 : Closed e1194672092122 ∧ code e1194672092122 = 5592718603226 := by decide
theorem cert_e1194672092122 : check e1194672092122 [[],[.left],[]] .chain = true := by decide
def e1194672092138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1194672092138 : Closed e1194672092138 ∧ code e1194672092138 = 5592718603242 := by decide
theorem cert_e1194672092138 : check e1194672092138 [[],[.left],[]] .smaller = true := by decide
def e1194672092382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1194672092382 : Closed e1194672092382 ∧ code e1194672092382 = 5592718603486 := by decide
theorem cert_e1194672092382 : check e1194672092382 [[],[.left],[]] .smaller = true := by decide
def e1194672092398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1194672092398 : Closed e1194672092398 ∧ code e1194672092398 = 5592718603502 := by decide
theorem cert_e1194672092398 : check e1194672092398 [[],[.left],[]] .chain = true := by decide
def e1194672092406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1194672092406 : Closed e1194672092406 ∧ code e1194672092406 = 5592718603510 := by decide
theorem cert_e1194672092406 : check e1194672092406 [[],[.left],[]] .chain = true := by decide
def e1194672092410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1194672092410 : Closed e1194672092410 ∧ code e1194672092410 = 5592718603514 := by decide
theorem cert_e1194672092410 : check e1194672092410 [[],[.left],[]] .smaller = true := by decide
def e1194672092782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1194672092782 : Closed e1194672092782 ∧ code e1194672092782 = 5592718603886 := by decide
theorem cert_e1194672092782 : check e1194672092782 [[],[.left],[]] .chain = true := by decide
def e1194672092794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1194672092794 : Closed e1194672092794 ∧ code e1194672092794 = 5592718603898 := by decide
theorem cert_e1194672092794 : check e1194672092794 [[],[.left],[]] .chain = true := by decide
def e1194672092982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194672092982 : Closed e1194672092982 ∧ code e1194672092982 = 5592718604086 := by decide
theorem cert_e1194672092982 : check e1194672092982 [[],[.left],[]] .chain = true := by decide
def e1194672092986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194672092986 : Closed e1194672092986 ∧ code e1194672092986 = 5592718604090 := by decide
theorem cert_e1194672092986 : check e1194672092986 [[],[.left],[]] .chain = true := by decide
def e1194672093082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1194672093082 : Closed e1194672093082 ∧ code e1194672093082 = 5592718604186 := by decide
theorem cert_e1194672093082 : check e1194672093082 [[],[.left],[]] .smaller = true := by decide
def e1194672093622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1194672093622 : Closed e1194672093622 ∧ code e1194672093622 = 5592718604726 := by decide
theorem cert_e1194672093622 : check e1194672093622 [[],[.left],[]] .chain = true := by decide
def e1194672093654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1194672093654 : Closed e1194672093654 ∧ code e1194672093654 = 5592718604758 := by decide
theorem cert_e1194672093654 : check e1194672093654 [[],[.left],[]] .chain = true := by decide
def e1194672093658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1194672093658 : Closed e1194672093658 ∧ code e1194672093658 = 5592718604762 := by decide
theorem cert_e1194672093658 : check e1194672093658 [[],[.left],[]] .chain = true := by decide
def e1194672093814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1194672093814 : Closed e1194672093814 ∧ code e1194672093814 = 5592718604918 := by decide
theorem cert_e1194672093814 : check e1194672093814 [[],[.left],[]] .chain = true := by decide
def e1194672094006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194672094006 : Closed e1194672094006 ∧ code e1194672094006 = 5592718605110 := by decide
theorem cert_e1194672094006 : check e1194672094006 [[],[.left],[]] .chain = true := by decide
def e1194672094010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194672094010 : Closed e1194672094010 ∧ code e1194672094010 = 5592718605114 := by decide
theorem cert_e1194672094010 : check e1194672094010 [[],[.left],[]] .chain = true := by decide
def e1194672094422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1194672094422 : Closed e1194672094422 ∧ code e1194672094422 = 5592718605526 := by decide
theorem cert_e1194672094422 : check e1194672094422 [[],[.left],[]] .smaller = true := by decide
def e1194672094426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1194672094426 : Closed e1194672094426 ∧ code e1194672094426 = 5592718605530 := by decide
theorem cert_e1194672094426 : check e1194672094426 [[],[.left],[]] .smaller = true := by decide
def e1194672094442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1194672094442 : Closed e1194672094442 ∧ code e1194672094442 = 5592718605546 := by decide
theorem cert_e1194672094442 : check e1194672094442 [[],[.left],[]] .smaller = true := by decide
def e1194672094518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1194672094518 : Closed e1194672094518 ∧ code e1194672094518 = 5592718605622 := by decide
theorem cert_e1194672094518 : check e1194672094518 [[],[.left],[]] .smaller = true := by decide
def e1194672094522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1194672094522 : Closed e1194672094522 ∧ code e1194672094522 = 5592718605626 := by decide
theorem cert_e1194672094522 : check e1194672094522 [[],[.left],[]] .smaller = true := by decide
def e1194672094618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1194672094618 : Closed e1194672094618 ∧ code e1194672094618 = 5592718605722 := by decide
theorem cert_e1194672094618 : check e1194672094618 [[],[.left],[]] .smaller = true := by decide
def e1194672101086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1194672101086 : Closed e1194672101086 ∧ code e1194672101086 = 5592718612190 := by decide
theorem cert_e1194672101086 : check e1194672101086 [[],[.left],[]] .smaller = true := by decide
def e1194672101110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1194672101110 : Closed e1194672101110 ∧ code e1194672101110 = 5592718612214 := by decide
theorem cert_e1194672101110 : check e1194672101110 [[],[.left],[]] .smaller = true := by decide
def e1194672101214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1194672101214 : Closed e1194672101214 ∧ code e1194672101214 = 5592718612318 := by decide
theorem cert_e1194672101214 : check e1194672101214 [[],[.left],[]] .smaller = true := by decide
def e1194672101230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1194672101230 : Closed e1194672101230 ∧ code e1194672101230 = 5592718612334 := by decide
theorem cert_e1194672101230 : check e1194672101230 [[],[.left],[]] .chain = true := by decide
def e1194672101238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1194672101238 : Closed e1194672101238 ∧ code e1194672101238 = 5592718612342 := by decide
theorem cert_e1194672101238 : check e1194672101238 [[],[.left],[]] .chain = true := by decide
def e1194672101242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1194672101242 : Closed e1194672101242 ∧ code e1194672101242 = 5592718612346 := by decide
theorem cert_e1194672101242 : check e1194672101242 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor42
