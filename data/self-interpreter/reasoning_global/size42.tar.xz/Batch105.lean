import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205814892342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814892342 : Closed e1205814892342 ∧ code e1205814892342 = 5603861403446 := by decide
theorem cert_e1205814892342 : check e1205814892342 [[],[]] .chain = true := by decide
def e1205814892346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814892346 : Closed e1205814892346 ∧ code e1205814892346 = 5603861403450 := by decide
theorem cert_e1205814892346 : check e1205814892346 [[],[]] .chain = true := by decide
def e1205814892782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1205814892782 : Closed e1205814892782 ∧ code e1205814892782 = 5603861403886 := by decide
theorem cert_e1205814892782 : check e1205814892782 [[],[]] .chain = true := by decide
def e1205814892790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1205814892790 : Closed e1205814892790 ∧ code e1205814892790 = 5603861403894 := by decide
theorem cert_e1205814892790 : check e1205814892790 [[],[]] .chain = true := by decide
def e1205814893342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1205814893342 : Closed e1205814893342 ∧ code e1205814893342 = 5603861404446 := by decide
theorem cert_e1205814893342 : check e1205814893342 [[],[]] .chain = true := by decide
def e1205814893454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1205814893454 : Closed e1205814893454 ∧ code e1205814893454 = 5603861404558 := by decide
theorem cert_e1205814893454 : check e1205814893454 [[],[]] .chain = true := by decide
def e1205814893678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1205814893678 : Closed e1205814893678 ∧ code e1205814893678 = 5603861404782 := by decide
theorem cert_e1205814893678 : check e1205814893678 [[],[]] .chain = true := by decide
def e1205814893690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1205814893690 : Closed e1205814893690 ∧ code e1205814893690 = 5603861404794 := by decide
theorem cert_e1205814893690 : check e1205814893690 [[],[]] .chain = true := by decide
def e1205814893854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1205814893854 : Closed e1205814893854 ∧ code e1205814893854 = 5603861404958 := by decide
theorem cert_e1205814893854 : check e1205814893854 [[],[]] .chain = true := by decide
def e1205814894022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1205814894022 : Closed e1205814894022 ∧ code e1205814894022 = 5603861405126 := by decide
theorem cert_e1205814894022 : check e1205814894022 [[],[]] .chain = true := by decide
def e1205814894134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1205814894134 : Closed e1205814894134 ∧ code e1205814894134 = 5603861405238 := by decide
theorem cert_e1205814894134 : check e1205814894134 [[],[]] .chain = true := by decide
def e1205814894138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1205814894138 : Closed e1205814894138 ∧ code e1205814894138 = 5603861405242 := by decide
theorem cert_e1205814894138 : check e1205814894138 [[],[]] .chain = true := by decide
def e1205814894222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1205814894222 : Closed e1205814894222 ∧ code e1205814894222 = 5603861405326 := by decide
theorem cert_e1205814894222 : check e1205814894222 [[],[]] .chain = true := by decide
def e1205814894278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1205814894278 : Closed e1205814894278 ∧ code e1205814894278 = 5603861405382 := by decide
theorem cert_e1205814894278 : check e1205814894278 [[],[]] .chain = true := by decide
def e1205814899054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1205814899054 : Closed e1205814899054 ∧ code e1205814899054 = 5603861410158 := by decide
theorem cert_e1205814899054 : check e1205814899054 [[],[]] .chain = true := by decide
def e1205814899062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1205814899062 : Closed e1205814899062 ∧ code e1205814899062 = 5603861410166 := by decide
theorem cert_e1205814899062 : check e1205814899062 [[],[]] .chain = true := by decide
def e1205814900270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814900270 : Closed e1205814900270 ∧ code e1205814900270 = 5603861411374 := by decide
theorem cert_e1205814900270 : check e1205814900270 [[],[]] .chain = true := by decide
def e1205814900450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814900450 : Closed e1205814900450 ∧ code e1205814900450 = 5603861411554 := by decide
theorem cert_e1205814900450 : check e1205814900450 [[],[]] .chain = true := by decide
def e1205814900462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1205814900462 : Closed e1205814900462 ∧ code e1205814900462 = 5603861411566 := by decide
theorem cert_e1205814900462 : check e1205814900462 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205814900502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814900502 : Closed e1205814900502 ∧ code e1205814900502 = 5603861411606 := by decide
theorem cert_e1205814900502 : check e1205814900502 [[],[]] .chain = true := by decide
def e1205814900578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814900578 : Closed e1205814900578 ∧ code e1205814900578 = 5603861411682 := by decide
theorem cert_e1205814900578 : check e1205814900578 [[],[]] .chain = true := by decide
def e1205814900590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e1205814900590 : Closed e1205814900590 ∧ code e1205814900590 = 5603861411694 := by decide
theorem cert_e1205814900590 : check e1205814900590 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1205814900598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e1205814900598 : Closed e1205814900598 ∧ code e1205814900598 = 5603861411702 := by decide
theorem cert_e1205814900598 : check e1205814900598 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1205814900910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1205814900910 : Closed e1205814900910 ∧ code e1205814900910 = 5603861412014 := by decide
theorem cert_e1205814900910 : check e1205814900910 [[],[]] .chain = true := by decide
def e1205814900922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1205814900922 : Closed e1205814900922 ∧ code e1205814900922 = 5603861412026 := by decide
theorem cert_e1205814900922 : check e1205814900922 [[],[]] .chain = true := by decide
def e1205814901294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814901294 : Closed e1205814901294 ∧ code e1205814901294 = 5603861412398 := by decide
theorem cert_e1205814901294 : check e1205814901294 [[],[]] .chain = true := by decide
def e1205814901474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814901474 : Closed e1205814901474 ∧ code e1205814901474 = 5603861412578 := by decide
theorem cert_e1205814901474 : check e1205814901474 [[],[]] .chain = true := by decide
def e1205814901486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e1205814901486 : Closed e1205814901486 ∧ code e1205814901486 = 5603861412590 := by decide
theorem cert_e1205814901486 : check e1205814901486 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814901614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1205814901614 : Closed e1205814901614 ∧ code e1205814901614 = 5603861412718 := by decide
theorem cert_e1205814901614 : check e1205814901614 [[],[]] .chain = true := by decide
def e1205814901622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1205814901622 : Closed e1205814901622 ∧ code e1205814901622 = 5603861412726 := by decide
theorem cert_e1205814901622 : check e1205814901622 [[],[]] .chain = true := by decide
def e1205814901642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814901642 : Closed e1205814901642 ∧ code e1205814901642 = 5603861412746 := by decide
theorem cert_e1205814901642 : check e1205814901642 [[],[]] .chain = true := by decide
def e1205814901666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814901666 : Closed e1205814901666 ∧ code e1205814901666 = 5603861412770 := by decide
theorem cert_e1205814901666 : check e1205814901666 [[],[]] .chain = true := by decide
def e1205814901678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1205814901678 : Closed e1205814901678 ∧ code e1205814901678 = 5603861412782 := by decide
theorem cert_e1205814901678 : check e1205814901678 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814901686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1205814901686 : Closed e1205814901686 ∧ code e1205814901686 = 5603861412790 := by decide
theorem cert_e1205814901686 : check e1205814901686 [[],[]] .chain = true := by decide
def e1205814901690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1205814901690 : Closed e1205814901690 ∧ code e1205814901690 = 5603861412794 := by decide
theorem cert_e1205814901690 : check e1205814901690 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814901846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1205814901846 : Closed e1205814901846 ∧ code e1205814901846 = 5603861412950 := by decide
theorem cert_e1205814901846 : check e1205814901846 [[],[]] .chain = true := by decide
def e1205814901850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1205814901850 : Closed e1205814901850 ∧ code e1205814901850 = 5603861412954 := by decide
theorem cert_e1205814901850 : check e1205814901850 [[],[]] .chain = true := by decide
def e1205814902038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814902038 : Closed e1205814902038 ∧ code e1205814902038 = 5603861413142 := by decide
theorem cert_e1205814902038 : check e1205814902038 [[],[]] .chain = true := by decide
def e1205814902114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814902114 : Closed e1205814902114 ∧ code e1205814902114 = 5603861413218 := by decide
theorem cert_e1205814902114 : check e1205814902114 [[],[]] .chain = true := by decide
def e1205814902126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1205814902126 : Closed e1205814902126 ∧ code e1205814902126 = 5603861413230 := by decide
theorem cert_e1205814902126 : check e1205814902126 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814902134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1205814902134 : Closed e1205814902134 ∧ code e1205814902134 = 5603861413238 := by decide
theorem cert_e1205814902134 : check e1205814902134 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814902154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814902154 : Closed e1205814902154 ∧ code e1205814902154 = 5603861413258 := by decide
theorem cert_e1205814902154 : check e1205814902154 [[],[]] .chain = true := by decide
def e1205814902178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814902178 : Closed e1205814902178 ∧ code e1205814902178 = 5603861413282 := by decide
theorem cert_e1205814902178 : check e1205814902178 [[],[]] .chain = true := by decide
def e1205814902190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1205814902190 : Closed e1205814902190 ∧ code e1205814902190 = 5603861413294 := by decide
theorem cert_e1205814902190 : check e1205814902190 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814902198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e1205814902198 : Closed e1205814902198 ∧ code e1205814902198 = 5603861413302 := by decide
theorem cert_e1205814902198 : check e1205814902198 [[],[]] .chain = true := by decide
def e1205814902202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1205814902202 : Closed e1205814902202 ∧ code e1205814902202 = 5603861413306 := by decide
theorem cert_e1205814902202 : check e1205814902202 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814902230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1205814902230 : Closed e1205814902230 ∧ code e1205814902230 = 5603861413334 := by decide
theorem cert_e1205814902230 : check e1205814902230 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814902234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1205814902234 : Closed e1205814902234 ∧ code e1205814902234 = 5603861413338 := by decide
theorem cert_e1205814902234 : check e1205814902234 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814903278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e1205814903278 : Closed e1205814903278 ∧ code e1205814903278 = 5603861414382 := by decide
theorem cert_e1205814903278 : check e1205814903278 [[],[]] .chain = true := by decide
def e1205814903286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e1205814903286 : Closed e1205814903286 ∧ code e1205814903286 = 5603861414390 := by decide
theorem cert_e1205814903286 : check e1205814903286 [[],[]] .chain = true := by decide
def e1205814904046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814904046 : Closed e1205814904046 ∧ code e1205814904046 = 5603861415150 := by decide
theorem cert_e1205814904046 : check e1205814904046 [[],[]] .chain = true := by decide
def e1205814904054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814904054 : Closed e1205814904054 ∧ code e1205814904054 = 5603861415158 := by decide
theorem cert_e1205814904054 : check e1205814904054 [[],[]] .chain = true := by decide
def e1205814904606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e1205814904606 : Closed e1205814904606 ∧ code e1205814904606 = 5603861415710 := by decide
theorem cert_e1205814904606 : check e1205814904606 [[],[]] .chain = true := by decide
def e1205814904718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e1205814904718 : Closed e1205814904718 ∧ code e1205814904718 = 5603861415822 := by decide
theorem cert_e1205814904718 : check e1205814904718 [[],[]] .chain = true := by decide
def e1205814906414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205814906414 : Closed e1205814906414 ∧ code e1205814906414 = 5603861417518 := by decide
theorem cert_e1205814906414 : check e1205814906414 [[],[]] .chain = true := by decide
def e1205814906594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205814906594 : Closed e1205814906594 ∧ code e1205814906594 = 5603861417698 := by decide
theorem cert_e1205814906594 : check e1205814906594 [[],[]] .chain = true := by decide
def e1205814906606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1205814906606 : Closed e1205814906606 ∧ code e1205814906606 = 5603861417710 := by decide
theorem cert_e1205814906606 : check e1205814906606 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205814906646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205814906646 : Closed e1205814906646 ∧ code e1205814906646 = 5603861417750 := by decide
theorem cert_e1205814906646 : check e1205814906646 [[],[]] .chain = true := by decide
def e1205814906722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205814906722 : Closed e1205814906722 ∧ code e1205814906722 = 5603861417826 := by decide
theorem cert_e1205814906722 : check e1205814906722 [[],[]] .chain = true := by decide
def e1205814906734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1205814906734 : Closed e1205814906734 ∧ code e1205814906734 = 5603861417838 := by decide
theorem cert_e1205814906734 : check e1205814906734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205814906742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1205814906742 : Closed e1205814906742 ∧ code e1205814906742 = 5603861417846 := by decide
theorem cert_e1205814906742 : checkPay e1205814906742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205814908990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e1205814908990 : Closed e1205814908990 ∧ code e1205814908990 = 5603861420094 := by decide
theorem cert_e1205814908990 : check e1205814908990 [[],[]] .chain = true := by decide
def e1205814909410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205814909410 : Closed e1205814909410 ∧ code e1205814909410 = 5603861420514 := by decide
theorem cert_e1205814909410 : check e1205814909410 [[],[]] .chain = true := by decide
def e1205814909422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1205814909422 : Closed e1205814909422 ∧ code e1205814909422 = 5603861420526 := by decide
theorem cert_e1205814909422 : check e1205814909422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814909982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e1205814909982 : Closed e1205814909982 ∧ code e1205814909982 = 5603861421086 := by decide
theorem cert_e1205814909982 : check e1205814909982 [[],[]] .chain = true := by decide
def e1205814910178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205814910178 : Closed e1205814910178 ∧ code e1205814910178 = 5603861421282 := by decide
theorem cert_e1205814910178 : check e1205814910178 [[],[]] .chain = true := by decide
def e1205814910190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814910190 : Closed e1205814910190 ∧ code e1205814910190 = 5603861421294 := by decide
theorem cert_e1205814910190 : check e1205814910190 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814910198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814910198 : Closed e1205814910198 ∧ code e1205814910198 = 5603861421302 := by decide
theorem cert_e1205814910198 : check e1205814910198 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814911214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e1205814911214 : Closed e1205814911214 ∧ code e1205814911214 = 5603861422318 := by decide
theorem cert_e1205814911214 : check e1205814911214 [[],[]] .chain = true := by decide
def e1205814911226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e1205814911226 : Closed e1205814911226 ∧ code e1205814911226 = 5603861422330 := by decide
theorem cert_e1205814911226 : check e1205814911226 [[],[]] .chain = true := by decide
def e1205814911406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1205814911406 : Closed e1205814911406 ∧ code e1205814911406 = 5603861422510 := by decide
theorem cert_e1205814911406 : check e1205814911406 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814911598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814911598 : Closed e1205814911598 ∧ code e1205814911598 = 5603861422702 := by decide
theorem cert_e1205814911598 : check e1205814911598 [[],[]] .chain = true := by decide
def e1205814911610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814911610 : Closed e1205814911610 ∧ code e1205814911610 = 5603861422714 := by decide
theorem cert_e1205814911610 : check e1205814911610 [[],[]] .chain = true := by decide
def e1205814911774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e1205814911774 : Closed e1205814911774 ∧ code e1205814911774 = 5603861422878 := by decide
theorem cert_e1205814911774 : check e1205814911774 [[],[]] .chain = true := by decide
def e1205814911942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e1205814911942 : Closed e1205814911942 ∧ code e1205814911942 = 5603861423046 := by decide
theorem cert_e1205814911942 : check e1205814911942 [[],[]] .chain = true := by decide
def e1205814912558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205814912558 : Closed e1205814912558 ∧ code e1205814912558 = 5603861423662 := by decide
theorem cert_e1205814912558 : check e1205814912558 [[],[]] .chain = true := by decide
def e1205814912738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205814912738 : Closed e1205814912738 ∧ code e1205814912738 = 5603861423842 := by decide
theorem cert_e1205814912738 : check e1205814912738 [[],[]] .chain = true := by decide
def e1205814912750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1205814912750 : Closed e1205814912750 ∧ code e1205814912750 = 5603861423854 := by decide
theorem cert_e1205814912750 : check e1205814912750 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814912878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1205814912878 : Closed e1205814912878 ∧ code e1205814912878 = 5603861423982 := by decide
theorem cert_e1205814912878 : check e1205814912878 [[],[]] .chain = true := by decide
def e1205814912886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1205814912886 : Closed e1205814912886 ∧ code e1205814912886 = 5603861423990 := by decide
theorem cert_e1205814912886 : check e1205814912886 [[],[]] .chain = true := by decide
def e1205814912906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814912906 : Closed e1205814912906 ∧ code e1205814912906 = 5603861424010 := by decide
theorem cert_e1205814912906 : check e1205814912906 [[],[]] .chain = true := by decide
def e1205814912930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814912930 : Closed e1205814912930 ∧ code e1205814912930 = 5603861424034 := by decide
theorem cert_e1205814912930 : check e1205814912930 [[],[]] .chain = true := by decide
def e1205814912942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1205814912942 : Closed e1205814912942 ∧ code e1205814912942 = 5603861424046 := by decide
theorem cert_e1205814912942 : check e1205814912942 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814912950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1205814912950 : Closed e1205814912950 ∧ code e1205814912950 = 5603861424054 := by decide
theorem cert_e1205814912950 : check e1205814912950 [[],[]] .chain = true := by decide
def e1205814912954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1205814912954 : Closed e1205814912954 ∧ code e1205814912954 = 5603861424058 := by decide
theorem cert_e1205814912954 : check e1205814912954 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814913086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e1205814913086 : Closed e1205814913086 ∧ code e1205814913086 = 5603861424190 := by decide
theorem cert_e1205814913086 : check e1205814913086 [[],[]] .chain = true := by decide
def e1205814913506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205814913506 : Closed e1205814913506 ∧ code e1205814913506 = 5603861424610 := by decide
theorem cert_e1205814913506 : check e1205814913506 [[],[]] .chain = true := by decide
def e1205814913518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1205814913518 : Closed e1205814913518 ∧ code e1205814913518 = 5603861424622 := by decide
theorem cert_e1205814913518 : check e1205814913518 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814914286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814914286 : Closed e1205814914286 ∧ code e1205814914286 = 5603861425390 := by decide
theorem cert_e1205814914286 : check e1205814914286 [[],[]] .chain = true := by decide
def e1205814914294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814914294 : Closed e1205814914294 ∧ code e1205814914294 = 5603861425398 := by decide
theorem cert_e1205814914294 : check e1205814914294 [[],[]] .chain = true := by decide
def e1205814914574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814914574 : Closed e1205814914574 ∧ code e1205814914574 = 5603861425678 := by decide
theorem cert_e1205814914574 : check e1205814914574 [[],[]] .chain = true := by decide
def e1205814914586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814914586 : Closed e1205814914586 ∧ code e1205814914586 = 5603861425690 := by decide
theorem cert_e1205814914586 : check e1205814914586 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814914658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814914658 : Closed e1205814914658 ∧ code e1205814914658 = 5603861425762 := by decide
theorem cert_e1205814914658 : check e1205814914658 [[],[]] .chain = true := by decide
def e1205814914670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814914670 : Closed e1205814914670 ∧ code e1205814914670 = 5603861425774 := by decide
theorem cert_e1205814914670 : check e1205814914670 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814914678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814914678 : Closed e1205814914678 ∧ code e1205814914678 = 5603861425782 := by decide
theorem cert_e1205814914678 : check e1205814914678 [[],[]] .chain = true := by decide
def e1205814914682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814914682 : Closed e1205814914682 ∧ code e1205814914682 = 5603861425786 := by decide
theorem cert_e1205814914682 : check e1205814914682 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205814915190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e1205814915190 : Closed e1205814915190 ∧ code e1205814915190 = 5603861426294 := by decide
theorem cert_e1205814915190 : check e1205814915190 [[],[]] .chain = true := by decide
def e1205814915194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e1205814915194 : Closed e1205814915194 ∧ code e1205814915194 = 5603861426298 := by decide
theorem cert_e1205814915194 : check e1205814915194 [[],[]] .chain = true := by decide
def e1205814915286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1205814915286 : Closed e1205814915286 ∧ code e1205814915286 = 5603861426390 := by decide
theorem cert_e1205814915286 : check e1205814915286 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814915382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814915382 : Closed e1205814915382 ∧ code e1205814915382 = 5603861426486 := by decide
theorem cert_e1205814915382 : check e1205814915382 [[],[]] .chain = true := by decide
def e1205814915386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814915386 : Closed e1205814915386 ∧ code e1205814915386 = 5603861426490 := by decide
theorem cert_e1205814915386 : check e1205814915386 [[],[]] .chain = true := by decide
def e1205814915470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e1205814915470 : Closed e1205814915470 ∧ code e1205814915470 = 5603861426574 := by decide
theorem cert_e1205814915470 : check e1205814915470 [[],[]] .chain = true := by decide
def e1205814915526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e1205814915526 : Closed e1205814915526 ∧ code e1205814915526 = 5603861426630 := by decide
theorem cert_e1205814915526 : check e1205814915526 [[],[]] .chain = true := by decide
def e1205814915862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205814915862 : Closed e1205814915862 ∧ code e1205814915862 = 5603861426966 := by decide
theorem cert_e1205814915862 : check e1205814915862 [[],[]] .chain = true := by decide
def e1205814915938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205814915938 : Closed e1205814915938 ∧ code e1205814915938 = 5603861427042 := by decide
theorem cert_e1205814915938 : check e1205814915938 [[],[]] .chain = true := by decide
def e1205814915950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1205814915950 : Closed e1205814915950 ∧ code e1205814915950 = 5603861427054 := by decide
theorem cert_e1205814915950 : check e1205814915950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814915958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1205814915958 : Closed e1205814915958 ∧ code e1205814915958 = 5603861427062 := by decide
theorem cert_e1205814915958 : check e1205814915958 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814915978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814915978 : Closed e1205814915978 ∧ code e1205814915978 = 5603861427082 := by decide
theorem cert_e1205814915978 : check e1205814915978 [[],[]] .chain = true := by decide
def e1205814916002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814916002 : Closed e1205814916002 ∧ code e1205814916002 = 5603861427106 := by decide
theorem cert_e1205814916002 : check e1205814916002 [[],[]] .chain = true := by decide
def e1205814916014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1205814916014 : Closed e1205814916014 ∧ code e1205814916014 = 5603861427118 := by decide
theorem cert_e1205814916014 : check e1205814916014 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814916022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e1205814916022 : Closed e1205814916022 ∧ code e1205814916022 = 5603861427126 := by decide
theorem cert_e1205814916022 : check e1205814916022 [[],[]] .chain = true := by decide
def e1205814916026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1205814916026 : Closed e1205814916026 ∧ code e1205814916026 = 5603861427130 := by decide
theorem cert_e1205814916026 : check e1205814916026 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814916054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1205814916054 : Closed e1205814916054 ∧ code e1205814916054 = 5603861427158 := by decide
theorem cert_e1205814916054 : check e1205814916054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814916058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1205814916058 : Closed e1205814916058 ∧ code e1205814916058 = 5603861427162 := by decide
theorem cert_e1205814916058 : check e1205814916058 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814916126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e1205814916126 : Closed e1205814916126 ∧ code e1205814916126 = 5603861427230 := by decide
theorem cert_e1205814916126 : check e1205814916126 [[],[]] .chain = true := by decide
def e1205814916322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205814916322 : Closed e1205814916322 ∧ code e1205814916322 = 5603861427426 := by decide
theorem cert_e1205814916322 : check e1205814916322 [[],[]] .chain = true := by decide
def e1205814916334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814916334 : Closed e1205814916334 ∧ code e1205814916334 = 5603861427438 := by decide
theorem cert_e1205814916334 : check e1205814916334 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814916342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814916342 : Closed e1205814916342 ∧ code e1205814916342 = 5603861427446 := by decide
theorem cert_e1205814916342 : check e1205814916342 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1205814916622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814916622 : Closed e1205814916622 ∧ code e1205814916622 = 5603861427726 := by decide
theorem cert_e1205814916622 : check e1205814916622 [[],[]] .chain = true := by decide
def e1205814916634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814916634 : Closed e1205814916634 ∧ code e1205814916634 = 5603861427738 := by decide
theorem cert_e1205814916634 : check e1205814916634 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1205814916706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814916706 : Closed e1205814916706 ∧ code e1205814916706 = 5603861427810 := by decide
theorem cert_e1205814916706 : check e1205814916706 [[],[]] .chain = true := by decide
def e1205814916718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814916718 : Closed e1205814916718 ∧ code e1205814916718 = 5603861427822 := by decide
theorem cert_e1205814916718 : check e1205814916718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814916726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814916726 : Closed e1205814916726 ∧ code e1205814916726 = 5603861427830 := by decide
theorem cert_e1205814916726 : check e1205814916726 [[],[]] .chain = true := by decide
def e1205814916730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814916730 : Closed e1205814916730 ∧ code e1205814916730 = 5603861427834 := by decide
theorem cert_e1205814916730 : check e1205814916730 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814916918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814916918 : Closed e1205814916918 ∧ code e1205814916918 = 5603861428022 := by decide
theorem cert_e1205814916918 : check e1205814916918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205814916922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814916922 : Closed e1205814916922 ∧ code e1205814916922 = 5603861428026 := by decide
theorem cert_e1205814916922 : check e1205814916922 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814920110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1205814920110 : Closed e1205814920110 ∧ code e1205814920110 = 5603861431214 := by decide
theorem cert_e1205814920110 : check e1205814920110 [[],[]] .chain = true := by decide
def e1205814920122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1205814920122 : Closed e1205814920122 ∧ code e1205814920122 = 5603861431226 := by decide
theorem cert_e1205814920122 : check e1205814920122 [[],[]] .chain = true := by decide
def e1205814920170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e1205814920170 : Closed e1205814920170 ∧ code e1205814920170 = 5603861431274 := by decide
theorem cert_e1205814920170 : check e1205814920170 [[],[]] .chain = true := by decide
def e1205814920878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1205814920878 : Closed e1205814920878 ∧ code e1205814920878 = 5603861431982 := by decide
theorem cert_e1205814920878 : check e1205814920878 [[],[]] .sourceHead = true := by decide
def e1205814920890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1205814920890 : Closed e1205814920890 ∧ code e1205814920890 = 5603861431994 := by decide
theorem cert_e1205814920890 : check e1205814920890 [[],[]] .sourceHead = true := by decide
def e1205814921646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1205814921646 : Closed e1205814921646 ∧ code e1205814921646 = 5603861432750 := by decide
theorem cert_e1205814921646 : check e1205814921646 [[],[]] .chain = true := by decide
def e1205814921658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1205814921658 : Closed e1205814921658 ∧ code e1205814921658 = 5603861432762 := by decide
theorem cert_e1205814921658 : check e1205814921658 [[],[]] .chain = true := by decide
def e1205814921706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1205814921706 : Closed e1205814921706 ∧ code e1205814921706 = 5603861432810 := by decide
theorem cert_e1205814921706 : check e1205814921706 [[],[]] .chain = true := by decide
def e1205814921838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814921838 : Closed e1205814921838 ∧ code e1205814921838 = 5603861432942 := by decide
theorem cert_e1205814921838 : check e1205814921838 [[],[]] .chain = true := by decide
def e1205814921850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814921850 : Closed e1205814921850 ∧ code e1205814921850 = 5603861432954 := by decide
theorem cert_e1205814921850 : check e1205814921850 [[],[]] .chain = true := by decide
def e1205814922138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814922138 : Closed e1205814922138 ∧ code e1205814922138 = 5603861433242 := by decide
theorem cert_e1205814922138 : check e1205814922138 [[],[]] .chain = true := by decide
def e1205814922350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1205814922350 : Closed e1205814922350 ∧ code e1205814922350 = 5603861433454 := by decide
theorem cert_e1205814922350 : check e1205814922350 [[],[]] .chain = true := by decide
def e1205814922362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1205814922362 : Closed e1205814922362 ∧ code e1205814922362 = 5603861433466 := by decide
theorem cert_e1205814922362 : check e1205814922362 [[],[]] .chain = true := by decide
def e1205814922526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1205814922526 : Closed e1205814922526 ∧ code e1205814922526 = 5603861433630 := by decide
theorem cert_e1205814922526 : check e1205814922526 [[],[]] .chain = true := by decide
def e1205814922694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1205814922694 : Closed e1205814922694 ∧ code e1205814922694 = 5603861433798 := by decide
theorem cert_e1205814922694 : check e1205814922694 [[],[]] .chain = true := by decide
def e1205814923034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1205814923034 : Closed e1205814923034 ∧ code e1205814923034 = 5603861434138 := by decide
theorem cert_e1205814923034 : check e1205814923034 [[],[]] .chain = true := by decide
def e1205814923078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1205814923078 : Closed e1205814923078 ∧ code e1205814923078 = 5603861434182 := by decide
theorem cert_e1205814923078 : check e1205814923078 [[],[]] .chain = true := by decide
def e1205814925486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1205814925486 : Closed e1205814925486 ∧ code e1205814925486 = 5603861436590 := by decide
theorem cert_e1205814925486 : check e1205814925486 [[],[]] .chain = true := by decide
def e1205814925498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1205814925498 : Closed e1205814925498 ∧ code e1205814925498 = 5603861436602 := by decide
theorem cert_e1205814925498 : check e1205814925498 [[],[]] .chain = true := by decide
def e1205814925870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814925870 : Closed e1205814925870 ∧ code e1205814925870 = 5603861436974 := by decide
theorem cert_e1205814925870 : check e1205814925870 [[],[]] .chain = true := by decide
def e1205814926050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814926050 : Closed e1205814926050 ∧ code e1205814926050 = 5603861437154 := by decide
theorem cert_e1205814926050 : check e1205814926050 [[],[]] .chain = true := by decide
def e1205814926062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e1205814926062 : Closed e1205814926062 ∧ code e1205814926062 = 5603861437166 := by decide
theorem cert_e1205814926062 : check e1205814926062 [[],[]] .sourceHead = true := by decide
def e1205814926190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1205814926190 : Closed e1205814926190 ∧ code e1205814926190 = 5603861437294 := by decide
theorem cert_e1205814926190 : check e1205814926190 [[],[]] .chain = true := by decide
def e1205814926198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1205814926198 : Closed e1205814926198 ∧ code e1205814926198 = 5603861437302 := by decide
theorem cert_e1205814926198 : check e1205814926198 [[],[]] .chain = true := by decide
def e1205814926218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814926218 : Closed e1205814926218 ∧ code e1205814926218 = 5603861437322 := by decide
theorem cert_e1205814926218 : check e1205814926218 [[],[]] .chain = true := by decide
def e1205814926242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814926242 : Closed e1205814926242 ∧ code e1205814926242 = 5603861437346 := by decide
theorem cert_e1205814926242 : check e1205814926242 [[],[]] .chain = true := by decide
def e1205814926254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1205814926254 : Closed e1205814926254 ∧ code e1205814926254 = 5603861437358 := by decide
theorem cert_e1205814926254 : check e1205814926254 [[],[]] .sourceHead = true := by decide
def e1205814926262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1205814926262 : Closed e1205814926262 ∧ code e1205814926262 = 5603861437366 := by decide
theorem cert_e1205814926262 : check e1205814926262 [[],[]] .chain = true := by decide
def e1205814926266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1205814926266 : Closed e1205814926266 ∧ code e1205814926266 = 5603861437370 := by decide
theorem cert_e1205814926266 : check e1205814926266 [[],[]] .sourceHead = true := by decide
def e1205814926702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1205814926702 : Closed e1205814926702 ∧ code e1205814926702 = 5603861437806 := by decide
theorem cert_e1205814926702 : check e1205814926702 [[],[]] .chain = true := by decide
def e1205814926710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1205814926710 : Closed e1205814926710 ∧ code e1205814926710 = 5603861437814 := by decide
theorem cert_e1205814926710 : check e1205814926710 [[],[]] .chain = true := by decide
def e1205814926766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1205814926766 : Closed e1205814926766 ∧ code e1205814926766 = 5603861437870 := by decide
theorem cert_e1205814926766 : check e1205814926766 [[],[]] .chain = true := by decide
def e1205814926778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1205814926778 : Closed e1205814926778 ∧ code e1205814926778 = 5603861437882 := by decide
theorem cert_e1205814926778 : check e1205814926778 [[],[]] .chain = true := by decide
def e1205814926806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1205814926806 : Closed e1205814926806 ∧ code e1205814926806 = 5603861437910 := by decide
theorem cert_e1205814926806 : check e1205814926806 [[],[]] .chain = true := by decide
end Blc.Floor42
