import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205366726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211205366726 : Closed e1211205366726 ∧ code e1211205366726 = 5609251877830 := by decide
theorem cert_e1211205366726 : checkPay e1211205366726 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205367926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205367926 : Closed e1211205367926 ∧ code e1211205367926 = 5609251879030 := by decide
theorem cert_e1211205367926 : check e1211205367926 [[],[]] .chain = true := by decide
def e1211205368170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211205368170 : Closed e1211205368170 ∧ code e1211205368170 = 5609251879274 := by decide
theorem cert_e1211205368170 : check e1211205368170 [[],[]] .chain = true := by decide
def e1211205368194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205368194 : Closed e1211205368194 ∧ code e1211205368194 = 5609251879298 := by decide
theorem cert_e1211205368194 : check e1211205368194 [[],[]] .chain = true := by decide
def e1211205368206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205368206 : Closed e1211205368206 ∧ code e1211205368206 = 5609251879310 := by decide
theorem cert_e1211205368206 : check e1211205368206 [[],[]] .chain = true := by decide
def e1211205368218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205368218 : Closed e1211205368218 ∧ code e1211205368218 = 5609251879322 := by decide
theorem cert_e1211205368218 : check e1211205368218 [[],[]] .chain = true := by decide
def e1211205368262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205368262 : Closed e1211205368262 ∧ code e1211205368262 = 5609251879366 := by decide
theorem cert_e1211205368262 : check e1211205368262 [[],[]] .chain = true := by decide
def e1211205368886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205368886 : Closed e1211205368886 ∧ code e1211205368886 = 5609251879990 := by decide
theorem cert_e1211205368886 : checkPay e1211205368886 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205368890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205368890 : Closed e1211205368890 ∧ code e1211205368890 = 5609251879994 := by decide
theorem cert_e1211205368890 : checkPay e1211205368890 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205369030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205369030 : Closed e1211205369030 ∧ code e1211205369030 = 5609251880134 := by decide
theorem cert_e1211205369030 : checkPay e1211205369030 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205422902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205422902 : Closed e1211205422902 ∧ code e1211205422902 = 5609251934006 := by decide
theorem cert_e1211205422902 : check e1211205422902 [[],[]] .chain = true := by decide
def e1211205422906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205422906 : Closed e1211205422906 ∧ code e1211205422906 = 5609251934010 := by decide
theorem cert_e1211205422906 : check e1211205422906 [[],[]] .chain = true := by decide
def e1211205423002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205423002 : Closed e1211205423002 ∧ code e1211205423002 = 5609251934106 := by decide
theorem cert_e1211205423002 : check e1211205423002 [[],[]] .chain = true := by decide
def e1211205426934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 1))))))
theorem wire_e1211205426934 : Closed e1211205426934 ∧ code e1211205426934 = 5609251938038 := by decide
theorem cert_e1211205426934 : check e1211205426934 [[],[]] .chain = true := by decide
def e1211205427062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 1))))))
theorem wire_e1211205427062 : Closed e1211205427062 ∧ code e1211205427062 = 5609251938166 := by decide
theorem cert_e1211205427062 : check e1211205427062 [[],[]] .chain = true := by decide
def e1211205427066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 3))))) (.var 0))))))
theorem wire_e1211205427066 : Closed e1211205427066 ∧ code e1211205427066 = 5609251938170 := by decide
theorem cert_e1211205427066 : check e1211205427066 [[],[]] .chain = true := by decide
def e1211205428662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211205428662 : Closed e1211205428662 ∧ code e1211205428662 = 5609251939766 := by decide
theorem cert_e1211205428662 : check e1211205428662 [[],[]] .chain = true := by decide
def e1211205428694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211205428694 : Closed e1211205428694 ∧ code e1211205428694 = 5609251939798 := by decide
theorem cert_e1211205428694 : check e1211205428694 [[],[]] .chain = true := by decide
def e1211205428698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211205428698 : Closed e1211205428698 ∧ code e1211205428698 = 5609251939802 := by decide
theorem cert_e1211205428698 : check e1211205428698 [[],[]] .chain = true := by decide
def e1211205428854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205428854 : Closed e1211205428854 ∧ code e1211205428854 = 5609251939958 := by decide
theorem cert_e1211205428854 : check e1211205428854 [[],[]] .chain = true := by decide
def e1211205429046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205429046 : Closed e1211205429046 ∧ code e1211205429046 = 5609251940150 := by decide
theorem cert_e1211205429046 : check e1211205429046 [[],[]] .chain = true := by decide
def e1211205429050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205429050 : Closed e1211205429050 ∧ code e1211205429050 = 5609251940154 := by decide
theorem cert_e1211205429050 : check e1211205429050 [[],[]] .chain = true := by decide
def e1211205432022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205432022 : Closed e1211205432022 ∧ code e1211205432022 = 5609251943126 := by decide
theorem cert_e1211205432022 : check e1211205432022 [[],[]] .chain = true := by decide
def e1211205432026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205432026 : Closed e1211205432026 ∧ code e1211205432026 = 5609251943130 := by decide
theorem cert_e1211205432026 : check e1211205432026 [[],[]] .chain = true := by decide
def e1211205432042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205432042 : Closed e1211205432042 ∧ code e1211205432042 = 5609251943146 := by decide
theorem cert_e1211205432042 : check e1211205432042 [[],[]] .chain = true := by decide
def e1211205432118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205432118 : Closed e1211205432118 ∧ code e1211205432118 = 5609251943222 := by decide
theorem cert_e1211205432118 : check e1211205432118 [[],[]] .chain = true := by decide
def e1211205432122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205432122 : Closed e1211205432122 ∧ code e1211205432122 = 5609251943226 := by decide
theorem cert_e1211205432122 : check e1211205432122 [[],[]] .chain = true := by decide
def e1211205432218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205432218 : Closed e1211205432218 ∧ code e1211205432218 = 5609251943322 := by decide
theorem cert_e1211205432218 : check e1211205432218 [[],[]] .chain = true := by decide
def e1211205433742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205433742 : Closed e1211205433742 ∧ code e1211205433742 = 5609251944846 := by decide
theorem cert_e1211205433742 : check e1211205433742 [[],[]] .chain = true := by decide
def e1211205433798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205433798 : Closed e1211205433798 ∧ code e1211205433798 = 5609251944902 := by decide
theorem cert_e1211205433798 : check e1211205433798 [[],[]] .chain = true := by decide
def e1211205434566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205434566 : Closed e1211205434566 ∧ code e1211205434566 = 5609251945670 := by decide
theorem cert_e1211205434566 : check e1211205434566 [[],[]] .chain = true := by decide
def e1211205442422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e1211205442422 : Closed e1211205442422 ∧ code e1211205442422 = 5609251953526 := by decide
theorem cert_e1211205442422 : check e1211205442422 [[],[]] .chain = true := by decide
def e1211205442426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e1211205442426 : Closed e1211205442426 ∧ code e1211205442426 = 5609251953530 := by decide
theorem cert_e1211205442426 : check e1211205442426 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205442486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e1211205442486 : Closed e1211205442486 ∧ code e1211205442486 = 5609251953590 := by decide
theorem cert_e1211205442486 : check e1211205442486 [[],[]] .chain = true := by decide
def e1211205442490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 2)))) (.var 0))))))
theorem wire_e1211205442490 : Closed e1211205442490 ∧ code e1211205442490 = 5609251953594 := by decide
theorem cert_e1211205442490 : check e1211205442490 [[],[]] .chain = true := by decide
def e1211205442522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e1211205442522 : Closed e1211205442522 ∧ code e1211205442522 = 5609251953626 := by decide
private def t_e1211205442522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0))))))
theorem cert_e1211205442522 : ¬ IsSelfInterpreter e1211205442522 :=
  wSource (t := t_e1211205442522) (replay_sound (ps := []) (t := e1211205442522) (by decide)) (by decide)
def e1211205442934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211205442934 : Closed e1211205442934 ∧ code e1211205442934 = 5609251954038 := by decide
theorem cert_e1211205442934 : check e1211205442934 [[],[]] .chain = true := by decide
def e1211205442938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e1211205442938 : Closed e1211205442938 ∧ code e1211205442938 = 5609251954042 := by decide
theorem cert_e1211205442938 : check e1211205442938 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205442998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.var 1))))))
theorem wire_e1211205442998 : Closed e1211205442998 ∧ code e1211205442998 = 5609251954102 := by decide
theorem cert_e1211205442998 : check e1211205442998 [[],[]] .chain = true := by decide
def e1211205443002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211205443002 : Closed e1211205443002 ∧ code e1211205443002 = 5609251954106 := by decide
theorem cert_e1211205443002 : check e1211205443002 [[],[]] .chain = true := by decide
def e1211205443030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211205443030 : Closed e1211205443030 ∧ code e1211205443030 = 5609251954134 := by decide
theorem cert_e1211205443030 : check e1211205443030 [[],[]] .chain = true := by decide
def e1211205443034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211205443034 : Closed e1211205443034 ∧ code e1211205443034 = 5609251954138 := by decide
theorem cert_e1211205443034 : check e1211205443034 [[],[]] .chain = true := by decide
def e1211205443050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e1211205443050 : Closed e1211205443050 ∧ code e1211205443050 = 5609251954154 := by decide
theorem cert_e1211205443050 : check e1211205443050 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205443254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211205443254 : Closed e1211205443254 ∧ code e1211205443254 = 5609251954358 := by decide
theorem cert_e1211205443254 : check e1211205443254 [[],[]] .chain = true := by decide
def e1211205443258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211205443258 : Closed e1211205443258 ∧ code e1211205443258 = 5609251954362 := by decide
theorem cert_e1211205443258 : check e1211205443258 [[],[]] .chain = true := by decide
def e1211205443286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211205443286 : Closed e1211205443286 ∧ code e1211205443286 = 5609251954390 := by decide
theorem cert_e1211205443286 : check e1211205443286 [[],[]] .chain = true := by decide
def e1211205443290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e1211205443290 : Closed e1211205443290 ∧ code e1211205443290 = 5609251954394 := by decide
theorem cert_e1211205443290 : check e1211205443290 [[],[]] .chain = true := by decide
def e1211205443306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211205443306 : Closed e1211205443306 ∧ code e1211205443306 = 5609251954410 := by decide
theorem cert_e1211205443306 : check e1211205443306 [[],[]] .chain = true := by decide
def e1211205443418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211205443418 : Closed e1211205443418 ∧ code e1211205443418 = 5609251954522 := by decide
private def t_e1211205443418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0))))))
theorem cert_e1211205443418 : ¬ IsSelfInterpreter e1211205443418 :=
  wSource (t := t_e1211205443418) (replay_sound (ps := []) (t := e1211205443418) (by decide)) (by decide)
def e1211205443434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211205443434 : Closed e1211205443434 ∧ code e1211205443434 = 5609251954538 := by decide
theorem cert_e1211205443434 : check e1211205443434 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205444406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205444406 : Closed e1211205444406 ∧ code e1211205444406 = 5609251955510 := by decide
theorem cert_e1211205444406 : check e1211205444406 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205444410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205444410 : Closed e1211205444410 ∧ code e1211205444410 = 5609251955514 := by decide
theorem cert_e1211205444410 : check e1211205444410 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205445494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211205445494 : Closed e1211205445494 ∧ code e1211205445494 = 5609251956598 := by decide
theorem cert_e1211205445494 : check e1211205445494 [[],[]] .chain = true := by decide
def e1211205445498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e1211205445498 : Closed e1211205445498 ∧ code e1211205445498 = 5609251956602 := by decide
theorem cert_e1211205445498 : check e1211205445498 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205445558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211205445558 : Closed e1211205445558 ∧ code e1211205445558 = 5609251956662 := by decide
theorem cert_e1211205445558 : check e1211205445558 [[],[]] .chain = true := by decide
def e1211205445562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e1211205445562 : Closed e1211205445562 ∧ code e1211205445562 = 5609251956666 := by decide
theorem cert_e1211205445562 : check e1211205445562 [[],[]] .chain = true := by decide
def e1211205445594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e1211205445594 : Closed e1211205445594 ∧ code e1211205445594 = 5609251956698 := by decide
theorem cert_e1211205445594 : check e1211205445594 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205446030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205446030 : Closed e1211205446030 ∧ code e1211205446030 = 5609251957134 := by decide
private def t_e1211205446030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1211205446030 : ¬ IsSelfInterpreter e1211205446030 :=
  wSource (t := t_e1211205446030) (replay_sound (ps := []) (t := e1211205446030) (by decide)) (by decide)
def e1211205446086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205446086 : Closed e1211205446086 ∧ code e1211205446086 = 5609251957190 := by decide
private def t_e1211205446086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1211205446086 : ¬ IsSelfInterpreter e1211205446086 :=
  wSource (t := t_e1211205446086) (replay_sound (ps := []) (t := e1211205446086) (by decide)) (by decide)
def e1211205446894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205446894 : Closed e1211205446894 ∧ code e1211205446894 = 5609251957998 := by decide
theorem cert_e1211205446894 : check e1211205446894 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205446902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205446902 : Closed e1211205446902 ∧ code e1211205446902 = 5609251958006 := by decide
theorem cert_e1211205446902 : check e1211205446902 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205447278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205447278 : Closed e1211205447278 ∧ code e1211205447278 = 5609251958382 := by decide
theorem cert_e1211205447278 : check e1211205447278 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205447290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205447290 : Closed e1211205447290 ∧ code e1211205447290 = 5609251958394 := by decide
theorem cert_e1211205447290 : check e1211205447290 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205447478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205447478 : Closed e1211205447478 ∧ code e1211205447478 = 5609251958582 := by decide
private def t_e1211205447478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem cert_e1211205447478 : ¬ IsSelfInterpreter e1211205447478 :=
  wSource (t := t_e1211205447478) (replay_sound (ps := []) (t := e1211205447478) (by decide)) (by decide)
def e1211205447482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205447482 : Closed e1211205447482 ∧ code e1211205447482 = 5609251958586 := by decide
private def t_e1211205447482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem cert_e1211205447482 : ¬ IsSelfInterpreter e1211205447482 :=
  wSource (t := t_e1211205447482) (replay_sound (ps := []) (t := e1211205447482) (by decide)) (by decide)
def e1211205447894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e1211205447894 : Closed e1211205447894 ∧ code e1211205447894 = 5609251958998 := by decide
theorem cert_e1211205447894 : check e1211205447894 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205447990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205447990 : Closed e1211205447990 ∧ code e1211205447990 = 5609251959094 := by decide
theorem cert_e1211205447990 : check e1211205447990 [[],[]] .chain = true := by decide
def e1211205447994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205447994 : Closed e1211205447994 ∧ code e1211205447994 = 5609251959098 := by decide
theorem cert_e1211205447994 : check e1211205447994 [[],[]] .chain = true := by decide
def e1211205448174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211205448174 : Closed e1211205448174 ∧ code e1211205448174 = 5609251959278 := by decide
theorem cert_e1211205448174 : check e1211205448174 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205448182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1))))))
theorem wire_e1211205448182 : Closed e1211205448182 ∧ code e1211205448182 = 5609251959286 := by decide
theorem cert_e1211205448182 : check e1211205448182 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205448566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211205448566 : Closed e1211205448566 ∧ code e1211205448566 = 5609251959670 := by decide
theorem cert_e1211205448566 : check e1211205448566 [[],[]] .chain = true := by decide
def e1211205448570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e1211205448570 : Closed e1211205448570 ∧ code e1211205448570 = 5609251959674 := by decide
theorem cert_e1211205448570 : check e1211205448570 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205448630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e1211205448630 : Closed e1211205448630 ∧ code e1211205448630 = 5609251959734 := by decide
theorem cert_e1211205448630 : check e1211205448630 [[],[]] .chain = true := by decide
def e1211205448634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211205448634 : Closed e1211205448634 ∧ code e1211205448634 = 5609251959738 := by decide
theorem cert_e1211205448634 : check e1211205448634 [[],[]] .chain = true := by decide
def e1211205448662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211205448662 : Closed e1211205448662 ∧ code e1211205448662 = 5609251959766 := by decide
theorem cert_e1211205448662 : check e1211205448662 [[],[]] .chain = true := by decide
def e1211205448666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211205448666 : Closed e1211205448666 ∧ code e1211205448666 = 5609251959770 := by decide
theorem cert_e1211205448666 : check e1211205448666 [[],[]] .chain = true := by decide
def e1211205448682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e1211205448682 : Closed e1211205448682 ∧ code e1211205448682 = 5609251959786 := by decide
theorem cert_e1211205448682 : check e1211205448682 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205448942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205448942 : Closed e1211205448942 ∧ code e1211205448942 = 5609251960046 := by decide
theorem cert_e1211205448942 : check e1211205448942 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205448950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205448950 : Closed e1211205448950 ∧ code e1211205448950 = 5609251960054 := by decide
theorem cert_e1211205448950 : check e1211205448950 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205449334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205449334 : Closed e1211205449334 ∧ code e1211205449334 = 5609251960438 := by decide
theorem cert_e1211205449334 : check e1211205449334 [[],[]] .chain = true := by decide
def e1211205449502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211205449502 : Closed e1211205449502 ∧ code e1211205449502 = 5609251960606 := by decide
theorem cert_e1211205449502 : check e1211205449502 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205449526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205449526 : Closed e1211205449526 ∧ code e1211205449526 = 5609251960630 := by decide
theorem cert_e1211205449526 : check e1211205449526 [[],[]] .chain = true := by decide
def e1211205449530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205449530 : Closed e1211205449530 ∧ code e1211205449530 = 5609251960634 := by decide
theorem cert_e1211205449530 : check e1211205449530 [[],[]] .chain = true := by decide
def e1211205449614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e1211205449614 : Closed e1211205449614 ∧ code e1211205449614 = 5609251960718 := by decide
theorem cert_e1211205449614 : check e1211205449614 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205449834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e1211205449834 : Closed e1211205449834 ∧ code e1211205449834 = 5609251960938 := by decide
theorem cert_e1211205449834 : check e1211205449834 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205449882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205449882 : Closed e1211205449882 ∧ code e1211205449882 = 5609251960986 := by decide
theorem cert_e1211205449882 : check e1211205449882 [[],[]] .chain = true := by decide
def e1211205449966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211205449966 : Closed e1211205449966 ∧ code e1211205449966 = 5609251961070 := by decide
theorem cert_e1211205449966 : check e1211205449966 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205449978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0))))))
theorem wire_e1211205449978 : Closed e1211205449978 ∧ code e1211205449978 = 5609251961082 := by decide
theorem cert_e1211205449978 : check e1211205449978 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205450166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211205450166 : Closed e1211205450166 ∧ code e1211205450166 = 5609251961270 := by decide
theorem cert_e1211205450166 : check e1211205450166 [[],[]] .chain = true := by decide
def e1211205450170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211205450170 : Closed e1211205450170 ∧ code e1211205450170 = 5609251961274 := by decide
theorem cert_e1211205450170 : check e1211205450170 [[],[]] .chain = true := by decide
def e1211205450198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211205450198 : Closed e1211205450198 ∧ code e1211205450198 = 5609251961302 := by decide
theorem cert_e1211205450198 : check e1211205450198 [[],[]] .chain = true := by decide
def e1211205450202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e1211205450202 : Closed e1211205450202 ∧ code e1211205450202 = 5609251961306 := by decide
theorem cert_e1211205450202 : check e1211205450202 [[],[]] .chain = true := by decide
def e1211205450218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211205450218 : Closed e1211205450218 ∧ code e1211205450218 = 5609251961322 := by decide
theorem cert_e1211205450218 : check e1211205450218 [[],[]] .chain = true := by decide
def e1211205450350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205450350 : Closed e1211205450350 ∧ code e1211205450350 = 5609251961454 := by decide
theorem cert_e1211205450350 : check e1211205450350 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205450362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205450362 : Closed e1211205450362 ∧ code e1211205450362 = 5609251961466 := by decide
theorem cert_e1211205450362 : check e1211205450362 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205450526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211205450526 : Closed e1211205450526 ∧ code e1211205450526 = 5609251961630 := by decide
theorem cert_e1211205450526 : check e1211205450526 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205450550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205450550 : Closed e1211205450550 ∧ code e1211205450550 = 5609251961654 := by decide
theorem cert_e1211205450550 : check e1211205450550 [[],[]] .chain = true := by decide
def e1211205450554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205450554 : Closed e1211205450554 ∧ code e1211205450554 = 5609251961658 := by decide
theorem cert_e1211205450554 : check e1211205450554 [[],[]] .chain = true := by decide
def e1211205450650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205450650 : Closed e1211205450650 ∧ code e1211205450650 = 5609251961754 := by decide
theorem cert_e1211205450650 : check e1211205450650 [[],[]] .chain = true := by decide
def e1211205450694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1211205450694 : Closed e1211205450694 ∧ code e1211205450694 = 5609251961798 := by decide
theorem cert_e1211205450694 : check e1211205450694 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205450870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211205450870 : Closed e1211205450870 ∧ code e1211205450870 = 5609251961974 := by decide
theorem cert_e1211205450870 : check e1211205450870 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205450874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205450874 : Closed e1211205450874 ∧ code e1211205450874 = 5609251961978 := by decide
theorem cert_e1211205450874 : check e1211205450874 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205450970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211205450970 : Closed e1211205450970 ∧ code e1211205450970 = 5609251962074 := by decide
theorem cert_e1211205450970 : check e1211205450970 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205450986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211205450986 : Closed e1211205450986 ∧ code e1211205450986 = 5609251962090 := by decide
theorem cert_e1211205450986 : check e1211205450986 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205451062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205451062 : Closed e1211205451062 ∧ code e1211205451062 = 5609251962166 := by decide
private def t_e1211205451062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem cert_e1211205451062 : ¬ IsSelfInterpreter e1211205451062 :=
  wSource (t := t_e1211205451062) (replay_sound (ps := []) (t := e1211205451062) (by decide)) (by decide)
def e1211205451066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205451066 : Closed e1211205451066 ∧ code e1211205451066 = 5609251962170 := by decide
private def t_e1211205451066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem cert_e1211205451066 : ¬ IsSelfInterpreter e1211205451066 :=
  wSource (t := t_e1211205451066) (replay_sound (ps := []) (t := e1211205451066) (by decide)) (by decide)
def e1211205451150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211205451150 : Closed e1211205451150 ∧ code e1211205451150 = 5609251962254 := by decide
theorem cert_e1211205451150 : check e1211205451150 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205451206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205451206 : Closed e1211205451206 ∧ code e1211205451206 = 5609251962310 := by decide
theorem cert_e1211205451206 : check e1211205451206 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205457462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205457462 : Closed e1211205457462 ∧ code e1211205457462 = 5609251968566 := by decide
theorem cert_e1211205457462 : check e1211205457462 [[],[]] .chain = true := by decide
def e1211205457466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205457466 : Closed e1211205457466 ∧ code e1211205457466 = 5609251968570 := by decide
theorem cert_e1211205457466 : check e1211205457466 [[],[]] .chain = true := by decide
def e1211205457550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205457550 : Closed e1211205457550 ∧ code e1211205457550 = 5609251968654 := by decide
theorem cert_e1211205457550 : check e1211205457550 [[],[]] .chain = true := by decide
def e1211205457606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205457606 : Closed e1211205457606 ∧ code e1211205457606 = 5609251968710 := by decide
theorem cert_e1211205457606 : check e1211205457606 [[],[]] .chain = true := by decide
def e1211205457690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211205457690 : Closed e1211205457690 ∧ code e1211205457690 = 5609251968794 := by decide
theorem cert_e1211205457690 : check e1211205457690 [[],[]] .chain = true := by decide
def e1211205457734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211205457734 : Closed e1211205457734 ∧ code e1211205457734 = 5609251968838 := by decide
theorem cert_e1211205457734 : check e1211205457734 [[],[]] .chain = true := by decide
def e1211205458318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205458318 : Closed e1211205458318 ∧ code e1211205458318 = 5609251969422 := by decide
theorem cert_e1211205458318 : check e1211205458318 [[],[]] .chain = true := by decide
def e1211205458374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205458374 : Closed e1211205458374 ∧ code e1211205458374 = 5609251969478 := by decide
theorem cert_e1211205458374 : check e1211205458374 [[],[]] .chain = true := by decide
def e1211205459142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205459142 : Closed e1211205459142 ∧ code e1211205459142 = 5609251970246 := by decide
theorem cert_e1211205459142 : check e1211205459142 [[],[]] .chain = true := by decide
def e1211205469150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211205469150 : Closed e1211205469150 ∧ code e1211205469150 = 5609251980254 := by decide
theorem cert_e1211205469150 : check e1211205469150 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205469166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211205469166 : Closed e1211205469166 ∧ code e1211205469166 = 5609251980270 := by decide
theorem cert_e1211205469166 : check e1211205469166 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205470998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211205470998 : Closed e1211205470998 ∧ code e1211205470998 = 5609251982102 := by decide
theorem cert_e1211205470998 : check e1211205470998 [[],[]] .chain = true := by decide
def e1211205471074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211205471074 : Closed e1211205471074 ∧ code e1211205471074 = 5609251982178 := by decide
theorem cert_e1211205471074 : check e1211205471074 [[],[]] .chain = true := by decide
def e1211205471086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211205471086 : Closed e1211205471086 ∧ code e1211205471086 = 5609251982190 := by decide
theorem cert_e1211205471086 : check e1211205471086 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211205471094 : Closed e1211205471094 ∧ code e1211205471094 = 5609251982198 := by decide
theorem cert_e1211205471094 : check e1211205471094 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211205471114 : Closed e1211205471114 ∧ code e1211205471114 = 5609251982218 := by decide
theorem cert_e1211205471114 : check e1211205471114 [[],[]] .chain = true := by decide
def e1211205471138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211205471138 : Closed e1211205471138 ∧ code e1211205471138 = 5609251982242 := by decide
theorem cert_e1211205471138 : check e1211205471138 [[],[]] .chain = true := by decide
def e1211205471150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211205471150 : Closed e1211205471150 ∧ code e1211205471150 = 5609251982254 := by decide
theorem cert_e1211205471150 : check e1211205471150 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e1211205471158 : Closed e1211205471158 ∧ code e1211205471158 = 5609251982262 := by decide
theorem cert_e1211205471158 : check e1211205471158 [[],[]] .chain = true := by decide
def e1211205471162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211205471162 : Closed e1211205471162 ∧ code e1211205471162 = 5609251982266 := by decide
theorem cert_e1211205471162 : check e1211205471162 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211205471190 : Closed e1211205471190 ∧ code e1211205471190 = 5609251982294 := by decide
theorem cert_e1211205471190 : check e1211205471190 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211205471194 : Closed e1211205471194 ∧ code e1211205471194 = 5609251982298 := by decide
theorem cert_e1211205471194 : check e1211205471194 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e1211205471262 : Closed e1211205471262 ∧ code e1211205471262 = 5609251982366 := by decide
theorem cert_e1211205471262 : check e1211205471262 [[],[]] .chain = true := by decide
def e1211205471458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211205471458 : Closed e1211205471458 ∧ code e1211205471458 = 5609251982562 := by decide
theorem cert_e1211205471458 : check e1211205471458 [[],[]] .chain = true := by decide
def e1211205471470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211205471470 : Closed e1211205471470 ∧ code e1211205471470 = 5609251982574 := by decide
theorem cert_e1211205471470 : check e1211205471470 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211205471478 : Closed e1211205471478 ∧ code e1211205471478 = 5609251982582 := by decide
theorem cert_e1211205471478 : check e1211205471478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e1211205471758 : Closed e1211205471758 ∧ code e1211205471758 = 5609251982862 := by decide
theorem cert_e1211205471758 : check e1211205471758 [[],[]] .chain = true := by decide
def e1211205471770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205471770 : Closed e1211205471770 ∧ code e1211205471770 = 5609251982874 := by decide
theorem cert_e1211205471770 : check e1211205471770 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205471842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211205471842 : Closed e1211205471842 ∧ code e1211205471842 = 5609251982946 := by decide
theorem cert_e1211205471842 : check e1211205471842 [[],[]] .chain = true := by decide
def e1211205471854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205471854 : Closed e1211205471854 ∧ code e1211205471854 = 5609251982958 := by decide
theorem cert_e1211205471854 : check e1211205471854 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205471862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205471862 : Closed e1211205471862 ∧ code e1211205471862 = 5609251982966 := by decide
theorem cert_e1211205471862 : check e1211205471862 [[],[]] .chain = true := by decide
def e1211205471866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205471866 : Closed e1211205471866 ∧ code e1211205471866 = 5609251982970 := by decide
theorem cert_e1211205471866 : check e1211205471866 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205472054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205472054 : Closed e1211205472054 ∧ code e1211205472054 = 5609251983158 := by decide
theorem cert_e1211205472054 : check e1211205472054 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205472058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205472058 : Closed e1211205472058 ∧ code e1211205472058 = 5609251983162 := by decide
theorem cert_e1211205472058 : check e1211205472058 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205476830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211205476830 : Closed e1211205476830 ∧ code e1211205476830 = 5609251987934 := by decide
theorem cert_e1211205476830 : check e1211205476830 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205476854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211205476854 : Closed e1211205476854 ∧ code e1211205476854 = 5609251987958 := by decide
theorem cert_e1211205476854 : check e1211205476854 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205477770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211205477770 : Closed e1211205477770 ∧ code e1211205477770 = 5609251988874 := by decide
theorem cert_e1211205477770 : check e1211205477770 [[],[]] .chain = true := by decide
def e1211205477794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211205477794 : Closed e1211205477794 ∧ code e1211205477794 = 5609251988898 := by decide
theorem cert_e1211205477794 : check e1211205477794 [[],[]] .chain = true := by decide
def e1211205477806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211205477806 : Closed e1211205477806 ∧ code e1211205477806 = 5609251988910 := by decide
theorem cert_e1211205477806 : check e1211205477806 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205477814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211205477814 : Closed e1211205477814 ∧ code e1211205477814 = 5609251988918 := by decide
theorem cert_e1211205477814 : check e1211205477814 [[],[]] .chain = true := by decide
def e1211205477818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211205477818 : Closed e1211205477818 ∧ code e1211205477818 = 5609251988922 := by decide
theorem cert_e1211205477818 : check e1211205477818 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205477846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211205477846 : Closed e1211205477846 ∧ code e1211205477846 = 5609251988950 := by decide
theorem cert_e1211205477846 : check e1211205477846 [[],[]] .chain = true := by decide
def e1211205477850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211205477850 : Closed e1211205477850 ∧ code e1211205477850 = 5609251988954 := by decide
theorem cert_e1211205477850 : check e1211205477850 [[],[]] .chain = true := by decide
def e1211205477866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211205477866 : Closed e1211205477866 ∧ code e1211205477866 = 5609251988970 := by decide
theorem cert_e1211205477866 : check e1211205477866 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205477902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e1211205477902 : Closed e1211205477902 ∧ code e1211205477902 = 5609251989006 := by decide
theorem cert_e1211205477902 : check e1211205477902 [[],[]] .chain = true := by decide
def e1211205477914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205477914 : Closed e1211205477914 ∧ code e1211205477914 = 5609251989018 := by decide
theorem cert_e1211205477914 : check e1211205477914 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205477986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211205477986 : Closed e1211205477986 ∧ code e1211205477986 = 5609251989090 := by decide
theorem cert_e1211205477986 : check e1211205477986 [[],[]] .chain = true := by decide
def e1211205477998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205477998 : Closed e1211205477998 ∧ code e1211205477998 = 5609251989102 := by decide
theorem cert_e1211205477998 : check e1211205477998 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205478006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205478006 : Closed e1211205478006 ∧ code e1211205478006 = 5609251989110 := by decide
theorem cert_e1211205478006 : check e1211205478006 [[],[]] .chain = true := by decide
def e1211205478010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205478010 : Closed e1211205478010 ∧ code e1211205478010 = 5609251989114 := by decide
theorem cert_e1211205478010 : check e1211205478010 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205478198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205478198 : Closed e1211205478198 ∧ code e1211205478198 = 5609251989302 := by decide
theorem cert_e1211205478198 : check e1211205478198 [[],[]] .chain = true := by decide
def e1211205478202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205478202 : Closed e1211205478202 ∧ code e1211205478202 = 5609251989306 := by decide
theorem cert_e1211205478202 : check e1211205478202 [[],[]] .chain = true := by decide
end Blc.Floor42
