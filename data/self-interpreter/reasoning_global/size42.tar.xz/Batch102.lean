import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812842138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812842138 : Closed e1205812842138 ∧ code e1205812842138 = 5603859353242 := by decide
theorem cert_e1205812842138 : check e1205812842138 [[],[]] .smaller = true := by decide
def e1205812842182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205812842182 : Closed e1205812842182 ∧ code e1205812842182 = 5603859353286 := by decide
theorem cert_e1205812842182 : check e1205812842182 [[],[]] .smaller = true := by decide
def e1205812842206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e1205812842206 : Closed e1205812842206 ∧ code e1205812842206 = 5603859353310 := by decide
theorem cert_e1205812842206 : check e1205812842206 [[],[]] .three = true := by decide
def e1205812842230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e1205812842230 : Closed e1205812842230 ∧ code e1205812842230 = 5603859353334 := by decide
theorem cert_e1205812842230 : check e1205812842230 [[],[]] .three = true := by decide
def e1205812842334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e1205812842334 : Closed e1205812842334 ∧ code e1205812842334 = 5603859353438 := by decide
theorem cert_e1205812842334 : check e1205812842334 [[],[]] .three = true := by decide
def e1205812842362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e1205812842362 : Closed e1205812842362 ∧ code e1205812842362 = 5603859353466 := by decide
theorem cert_e1205812842362 : check e1205812842362 [[],[]] .three = true := by decide
def e1205812842414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e1205812842414 : Closed e1205812842414 ∧ code e1205812842414 = 5603859353518 := by decide
theorem cert_e1205812842414 : check e1205812842414 [[],[]] .three = true := by decide
def e1205812842422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e1205812842422 : Closed e1205812842422 ∧ code e1205812842422 = 5603859353526 := by decide
theorem cert_e1205812842422 : check e1205812842422 [[],[]] .three = true := by decide
def e1205812842426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e1205812842426 : Closed e1205812842426 ∧ code e1205812842426 = 5603859353530 := by decide
theorem cert_e1205812842426 : check e1205812842426 [[],[]] .three = true := by decide
def e1205812842734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812842734 : Closed e1205812842734 ∧ code e1205812842734 = 5603859353838 := by decide
theorem cert_e1205812842734 : check e1205812842734 [[],[]] .smaller = true := by decide
def e1205812842742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812842742 : Closed e1205812842742 ∧ code e1205812842742 = 5603859353846 := by decide
theorem cert_e1205812842742 : check e1205812842742 [[],[]] .smaller = true := by decide
def e1205812843222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1205812843222 : Closed e1205812843222 ∧ code e1205812843222 = 5603859354326 := by decide
theorem cert_e1205812843222 : check e1205812843222 [[],[]] .smaller = true := by decide
def e1205812843226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1205812843226 : Closed e1205812843226 ∧ code e1205812843226 = 5603859354330 := by decide
theorem cert_e1205812843226 : check e1205812843226 [[],[]] .smaller = true := by decide
def e1205812843242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1205812843242 : Closed e1205812843242 ∧ code e1205812843242 = 5603859354346 := by decide
theorem cert_e1205812843242 : check e1205812843242 [[],[]] .smaller = true := by decide
def e1205812843318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812843318 : Closed e1205812843318 ∧ code e1205812843318 = 5603859354422 := by decide
theorem cert_e1205812843318 : check e1205812843318 [[],[]] .smaller = true := by decide
def e1205812843322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812843322 : Closed e1205812843322 ∧ code e1205812843322 = 5603859354426 := by decide
theorem cert_e1205812843322 : check e1205812843322 [[],[]] .smaller = true := by decide
def e1205812843406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1205812843406 : Closed e1205812843406 ∧ code e1205812843406 = 5603859354510 := by decide
theorem cert_e1205812843406 : check e1205812843406 [[],[]] .smaller = true := by decide
def e1205812843418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812843418 : Closed e1205812843418 ∧ code e1205812843418 = 5603859354522 := by decide
theorem cert_e1205812843418 : check e1205812843418 [[],[]] .smaller = true := by decide
def e1205812843486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e1205812843486 : Closed e1205812843486 ∧ code e1205812843486 = 5603859354590 := by decide
theorem cert_e1205812843486 : check e1205812843486 [[],[]] .three = true := by decide
def e1205812843502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e1205812843502 : Closed e1205812843502 ∧ code e1205812843502 = 5603859354606 := by decide
theorem cert_e1205812843502 : check e1205812843502 [[],[]] .three = true := by decide
def e1205812844662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1205812844662 : Closed e1205812844662 ∧ code e1205812844662 = 5603859355766 := by decide
theorem cert_e1205812844662 : check e1205812844662 [[],[]] .smaller = true := by decide
def e1205812844906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1205812844906 : Closed e1205812844906 ∧ code e1205812844906 = 5603859356010 := by decide
theorem cert_e1205812844906 : check e1205812844906 [[],[]] .smaller = true := by decide
def e1205812844942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1205812844942 : Closed e1205812844942 ∧ code e1205812844942 = 5603859356046 := by decide
theorem cert_e1205812844942 : check e1205812844942 [[],[]] .smaller = true := by decide
def e1205812844954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812844954 : Closed e1205812844954 ∧ code e1205812844954 = 5603859356058 := by decide
theorem cert_e1205812844954 : check e1205812844954 [[],[]] .smaller = true := by decide
def e1205812844998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1205812844998 : Closed e1205812844998 ∧ code e1205812844998 = 5603859356102 := by decide
theorem cert_e1205812844998 : check e1205812844998 [[],[]] .smaller = true := by decide
def e1205812845022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e1205812845022 : Closed e1205812845022 ∧ code e1205812845022 = 5603859356126 := by decide
theorem cert_e1205812845022 : check e1205812845022 [[],[]] .three = true := by decide
def e1205812845046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e1205812845046 : Closed e1205812845046 ∧ code e1205812845046 = 5603859356150 := by decide
theorem cert_e1205812845046 : check e1205812845046 [[],[]] .three = true := by decide
def e1205812845790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e1205812845790 : Closed e1205812845790 ∧ code e1205812845790 = 5603859356894 := by decide
theorem cert_e1205812845790 : check e1205812845790 [[],[]] .three = true := by decide
def e1205812845818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e1205812845818 : Closed e1205812845818 ∧ code e1205812845818 = 5603859356922 := by decide
theorem cert_e1205812845818 : check e1205812845818 [[],[]] .three = true := by decide
def e1205812846190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812846190 : Closed e1205812846190 ∧ code e1205812846190 = 5603859357294 := by decide
theorem cert_e1205812846190 : check e1205812846190 [[],[]] .three = true := by decide
def e1205812846198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205812846198 : Closed e1205812846198 ∧ code e1205812846198 = 5603859357302 := by decide
theorem cert_e1205812846198 : check e1205812846198 [[],[]] .three = true := by decide
def e1205812846202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812846202 : Closed e1205812846202 ∧ code e1205812846202 = 5603859357306 := by decide
theorem cert_e1205812846202 : check e1205812846202 [[],[]] .three = true := by decide
def e1205812847414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812847414 : Closed e1205812847414 ∧ code e1205812847414 = 5603859358518 := by decide
theorem cert_e1205812847414 : check e1205812847414 [[],[]] .three = true := by decide
def e1205812847418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812847418 : Closed e1205812847418 ∧ code e1205812847418 = 5603859358522 := by decide
theorem cert_e1205812847418 : check e1205812847418 [[],[]] .three = true := by decide
def e1205812847514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812847514 : Closed e1205812847514 ∧ code e1205812847514 = 5603859358618 := by decide
theorem cert_e1205812847514 : check e1205812847514 [[],[]] .three = true := by decide
def e1205812848182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1205812848182 : Closed e1205812848182 ∧ code e1205812848182 = 5603859359286 := by decide
theorem cert_e1205812848182 : check e1205812848182 [[],[]] .three = true := by decide
def e1205812848186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205812848186 : Closed e1205812848186 ∧ code e1205812848186 = 5603859359290 := by decide
theorem cert_e1205812848186 : check e1205812848186 [[],[]] .three = true := by decide
def e1205812848270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1205812848270 : Closed e1205812848270 ∧ code e1205812848270 = 5603859359374 := by decide
theorem cert_e1205812848270 : check e1205812848270 [[],[]] .three = true := by decide
def e1205812848326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205812848326 : Closed e1205812848326 ∧ code e1205812848326 = 5603859359430 := by decide
theorem cert_e1205812848326 : check e1205812848326 [[],[]] .three = true := by decide
def e1205812848350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1205812848350 : Closed e1205812848350 ∧ code e1205812848350 = 5603859359454 := by decide
theorem cert_e1205812848350 : check e1205812848350 [[],[]] .three = true := by decide
def e1205812848366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1205812848366 : Closed e1205812848366 ∧ code e1205812848366 = 5603859359470 := by decide
theorem cert_e1205812848366 : check e1205812848366 [[],[]] .three = true := by decide
def e1205812848374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1205812848374 : Closed e1205812848374 ∧ code e1205812848374 = 5603859359478 := by decide
theorem cert_e1205812848374 : check e1205812848374 [[],[]] .three = true := by decide
def e1205812848410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1205812848410 : Closed e1205812848410 ∧ code e1205812848410 = 5603859359514 := by decide
theorem cert_e1205812848410 : check e1205812848410 [[],[]] .three = true := by decide
def e1205812848454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1205812848454 : Closed e1205812848454 ∧ code e1205812848454 = 5603859359558 := by decide
theorem cert_e1205812848454 : check e1205812848454 [[],[]] .three = true := by decide
def e1205812848478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1205812848478 : Closed e1205812848478 ∧ code e1205812848478 = 5603859359582 := by decide
theorem cert_e1205812848478 : check e1205812848478 [[],[]] .three = true := by decide
def e1205812848494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1205812848494 : Closed e1205812848494 ∧ code e1205812848494 = 5603859359598 := by decide
theorem cert_e1205812848494 : check e1205812848494 [[],[]] .three = true := by decide
def e1205812848502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1205812848502 : Closed e1205812848502 ∧ code e1205812848502 = 5603859359606 := by decide
theorem cert_e1205812848502 : check e1205812848502 [[],[]] .three = true := by decide
def e1205812848506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1205812848506 : Closed e1205812848506 ∧ code e1205812848506 = 5603859359610 := by decide
theorem cert_e1205812848506 : check e1205812848506 [[],[]] .three = true := by decide
def e1205812848558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1205812848558 : Closed e1205812848558 ∧ code e1205812848558 = 5603859359662 := by decide
theorem cert_e1205812848558 : check e1205812848558 [[],[]] .three = true := by decide
def e1205812848566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1205812848566 : Closed e1205812848566 ∧ code e1205812848566 = 5603859359670 := by decide
theorem cert_e1205812848566 : check e1205812848566 [[],[]] .three = true := by decide
def e1205812848570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1205812848570 : Closed e1205812848570 ∧ code e1205812848570 = 5603859359674 := by decide
theorem cert_e1205812848570 : check e1205812848570 [[],[]] .three = true := by decide
def e1205812848598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1205812848598 : Closed e1205812848598 ∧ code e1205812848598 = 5603859359702 := by decide
theorem cert_e1205812848598 : check e1205812848598 [[],[]] .three = true := by decide
def e1205812848602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1205812848602 : Closed e1205812848602 ∧ code e1205812848602 = 5603859359706 := by decide
theorem cert_e1205812848602 : check e1205812848602 [[],[]] .three = true := by decide
def e1205812849038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1205812849038 : Closed e1205812849038 ∧ code e1205812849038 = 5603859360142 := by decide
theorem cert_e1205812849038 : check e1205812849038 [[],[]] .three = true := by decide
def e1205812849094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1205812849094 : Closed e1205812849094 ∧ code e1205812849094 = 5603859360198 := by decide
theorem cert_e1205812849094 : check e1205812849094 [[],[]] .three = true := by decide
def e1205812849118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1205812849118 : Closed e1205812849118 ∧ code e1205812849118 = 5603859360222 := by decide
theorem cert_e1205812849118 : check e1205812849118 [[],[]] .three = true := by decide
def e1205812849134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205812849134 : Closed e1205812849134 ∧ code e1205812849134 = 5603859360238 := by decide
theorem cert_e1205812849134 : check e1205812849134 [[],[]] .three = true := by decide
def e1205812849142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1205812849142 : Closed e1205812849142 ∧ code e1205812849142 = 5603859360246 := by decide
theorem cert_e1205812849142 : check e1205812849142 [[],[]] .three = true := by decide
def e1205812849862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1205812849862 : Closed e1205812849862 ∧ code e1205812849862 = 5603859360966 := by decide
theorem cert_e1205812849862 : check e1205812849862 [[],[]] .three = true := by decide
def e1205812849886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1205812849886 : Closed e1205812849886 ∧ code e1205812849886 = 5603859360990 := by decide
theorem cert_e1205812849886 : check e1205812849886 [[],[]] .three = true := by decide
def e1205812849902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812849902 : Closed e1205812849902 ∧ code e1205812849902 = 5603859361006 := by decide
theorem cert_e1205812849902 : check e1205812849902 [[],[]] .three = true := by decide
def e1205812849910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812849910 : Closed e1205812849910 ∧ code e1205812849910 = 5603859361014 := by decide
theorem cert_e1205812849910 : check e1205812849910 [[],[]] .three = true := by decide
def e1205812849914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1205812849914 : Closed e1205812849914 ∧ code e1205812849914 = 5603859361018 := by decide
theorem cert_e1205812849914 : check e1205812849914 [[],[]] .three = true := by decide
def e1205812850286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812850286 : Closed e1205812850286 ∧ code e1205812850286 = 5603859361390 := by decide
theorem cert_e1205812850286 : check e1205812850286 [[],[]] .three = true := by decide
def e1205812850294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205812850294 : Closed e1205812850294 ∧ code e1205812850294 = 5603859361398 := by decide
theorem cert_e1205812850294 : check e1205812850294 [[],[]] .three = true := by decide
def e1205812850298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812850298 : Closed e1205812850298 ∧ code e1205812850298 = 5603859361402 := by decide
theorem cert_e1205812850298 : check e1205812850298 [[],[]] .three = true := by decide
def e1205812850486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812850486 : Closed e1205812850486 ∧ code e1205812850486 = 5603859361590 := by decide
theorem cert_e1205812850486 : check e1205812850486 [[],[]] .three = true := by decide
def e1205812850490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812850490 : Closed e1205812850490 ∧ code e1205812850490 = 5603859361594 := by decide
theorem cert_e1205812850490 : check e1205812850490 [[],[]] .three = true := by decide
def e1205812857710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1205812857710 : Closed e1205812857710 ∧ code e1205812857710 = 5603859368814 := by decide
theorem cert_e1205812857710 : check e1205812857710 [[],[]] .smaller = true := by decide
def e1205812857718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1205812857718 : Closed e1205812857718 ∧ code e1205812857718 = 5603859368822 := by decide
theorem cert_e1205812857718 : check e1205812857718 [[],[]] .smaller = true := by decide
def e1205812857774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1205812857774 : Closed e1205812857774 ∧ code e1205812857774 = 5603859368878 := by decide
theorem cert_e1205812857774 : check e1205812857774 [[],[]] .smaller = true := by decide
def e1205812857786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1205812857786 : Closed e1205812857786 ∧ code e1205812857786 = 5603859368890 := by decide
theorem cert_e1205812857786 : check e1205812857786 [[],[]] .smaller = true := by decide
def e1205812857814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1205812857814 : Closed e1205812857814 ∧ code e1205812857814 = 5603859368918 := by decide
theorem cert_e1205812857814 : check e1205812857814 [[],[]] .smaller = true := by decide
def e1205812857818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1205812857818 : Closed e1205812857818 ∧ code e1205812857818 = 5603859368922 := by decide
theorem cert_e1205812857818 : check e1205812857818 [[],[]] .smaller = true := by decide
def e1205812858094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1205812858094 : Closed e1205812858094 ∧ code e1205812858094 = 5603859369198 := by decide
theorem cert_e1205812858094 : check e1205812858094 [[],[]] .smaller = true := by decide
def e1205812858102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1205812858102 : Closed e1205812858102 ∧ code e1205812858102 = 5603859369206 := by decide
theorem cert_e1205812858102 : check e1205812858102 [[],[]] .smaller = true := by decide
def e1205812858478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1205812858478 : Closed e1205812858478 ∧ code e1205812858478 = 5603859369582 := by decide
theorem cert_e1205812858478 : check e1205812858478 [[],[]] .smaller = true := by decide
def e1205812858490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1205812858490 : Closed e1205812858490 ∧ code e1205812858490 = 5603859369594 := by decide
theorem cert_e1205812858490 : check e1205812858490 [[],[]] .smaller = true := by decide
def e1205812858678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1205812858678 : Closed e1205812858678 ∧ code e1205812858678 = 5603859369782 := by decide
theorem cert_e1205812858678 : check e1205812858678 [[],[]] .smaller = true := by decide
def e1205812858682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1205812858682 : Closed e1205812858682 ∧ code e1205812858682 = 5603859369786 := by decide
theorem cert_e1205812858682 : check e1205812858682 [[],[]] .smaller = true := by decide
def e1205812866494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e1205812866494 : Closed e1205812866494 ∧ code e1205812866494 = 5603859377598 := by decide
theorem cert_e1205812866494 : check e1205812866494 [[],[]] .three = true := by decide
def e1205812866550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e1205812866550 : Closed e1205812866550 ∧ code e1205812866550 = 5603859377654 := by decide
theorem cert_e1205812866550 : check e1205812866550 [[],[]] .three = true := by decide
def e1205812866750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e1205812866750 : Closed e1205812866750 ∧ code e1205812866750 = 5603859377854 := by decide
theorem cert_e1205812866750 : check e1205812866750 [[],[]] .three = true := by decide
def e1205812866810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e1205812866810 : Closed e1205812866810 ∧ code e1205812866810 = 5603859377914 := by decide
theorem cert_e1205812866810 : check e1205812866810 [[],[]] .three = true := by decide
def e1205812867030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e1205812867030 : Closed e1205812867030 ∧ code e1205812867030 = 5603859378134 := by decide
theorem cert_e1205812867030 : check e1205812867030 [[],[]] .three = true := by decide
def e1205812867034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e1205812867034 : Closed e1205812867034 ∧ code e1205812867034 = 5603859378138 := by decide
theorem cert_e1205812867034 : check e1205812867034 [[],[]] .three = true := by decide
def e1205812868030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e1205812868030 : Closed e1205812868030 ∧ code e1205812868030 = 5603859379134 := by decide
theorem cert_e1205812868030 : check e1205812868030 [[],[]] .three = true := by decide
def e1205812868086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e1205812868086 : Closed e1205812868086 ∧ code e1205812868086 = 5603859379190 := by decide
theorem cert_e1205812868086 : check e1205812868086 [[],[]] .three = true := by decide
def e1205812869566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e1205812869566 : Closed e1205812869566 ∧ code e1205812869566 = 5603859380670 := by decide
theorem cert_e1205812869566 : check e1205812869566 [[],[]] .three = true := by decide
def e1205812869626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e1205812869626 : Closed e1205812869626 ∧ code e1205812869626 = 5603859380730 := by decide
theorem cert_e1205812869626 : check e1205812869626 [[],[]] .three = true := by decide
def e1205812870966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812870966 : Closed e1205812870966 ∧ code e1205812870966 = 5603859382070 := by decide
theorem cert_e1205812870966 : check e1205812870966 [[],[]] .three = true := by decide
def e1205812870970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812870970 : Closed e1205812870970 ∧ code e1205812870970 = 5603859382074 := by decide
theorem cert_e1205812870970 : check e1205812870970 [[],[]] .three = true := by decide
def e1205812899182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1205812899182 : Closed e1205812899182 ∧ code e1205812899182 = 5603859410286 := by decide
theorem cert_e1205812899182 : check e1205812899182 [[],[]] .smaller = true := by decide
def e1205812899190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1205812899190 : Closed e1205812899190 ∧ code e1205812899190 = 5603859410294 := by decide
theorem cert_e1205812899190 : check e1205812899190 [[],[]] .smaller = true := by decide
def e1205812899246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1205812899246 : Closed e1205812899246 ∧ code e1205812899246 = 5603859410350 := by decide
theorem cert_e1205812899246 : check e1205812899246 [[],[]] .smaller = true := by decide
def e1205812899258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1205812899258 : Closed e1205812899258 ∧ code e1205812899258 = 5603859410362 := by decide
theorem cert_e1205812899258 : check e1205812899258 [[],[]] .smaller = true := by decide
def e1205812899286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1205812899286 : Closed e1205812899286 ∧ code e1205812899286 = 5603859410390 := by decide
theorem cert_e1205812899286 : check e1205812899286 [[],[]] .smaller = true := by decide
def e1205812899290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1205812899290 : Closed e1205812899290 ∧ code e1205812899290 = 5603859410394 := by decide
theorem cert_e1205812899290 : check e1205812899290 [[],[]] .smaller = true := by decide
def e1205812899502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205812899502 : Closed e1205812899502 ∧ code e1205812899502 = 5603859410606 := by decide
theorem cert_e1205812899502 : check e1205812899502 [[],[]] .smaller = true := by decide
def e1205812899514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205812899514 : Closed e1205812899514 ∧ code e1205812899514 = 5603859410618 := by decide
theorem cert_e1205812899514 : check e1205812899514 [[],[]] .smaller = true := by decide
def e1205812899562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205812899562 : Closed e1205812899562 ∧ code e1205812899562 = 5603859410666 := by decide
theorem cert_e1205812899562 : check e1205812899562 [[],[]] .smaller = true := by decide
def e1205812899670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205812899670 : Closed e1205812899670 ∧ code e1205812899670 = 5603859410774 := by decide
theorem cert_e1205812899670 : check e1205812899670 [[],[]] .smaller = true := by decide
def e1205812899674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205812899674 : Closed e1205812899674 ∧ code e1205812899674 = 5603859410778 := by decide
theorem cert_e1205812899674 : check e1205812899674 [[],[]] .smaller = true := by decide
def e1205812899690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205812899690 : Closed e1205812899690 ∧ code e1205812899690 = 5603859410794 := by decide
theorem cert_e1205812899690 : check e1205812899690 [[],[]] .smaller = true := by decide
def e1205812900318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1205812900318 : Closed e1205812900318 ∧ code e1205812900318 = 5603859411422 := by decide
theorem cert_e1205812900318 : check e1205812900318 [[],[]] .three = true := by decide
def e1205812900342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1205812900342 : Closed e1205812900342 ∧ code e1205812900342 = 5603859411446 := by decide
theorem cert_e1205812900342 : check e1205812900342 [[],[]] .three = true := by decide
def e1205812900718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1205812900718 : Closed e1205812900718 ∧ code e1205812900718 = 5603859411822 := by decide
theorem cert_e1205812900718 : check e1205812900718 [[],[]] .smaller = true := by decide
def e1205812900726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1205812900726 : Closed e1205812900726 ∧ code e1205812900726 = 5603859411830 := by decide
theorem cert_e1205812900726 : check e1205812900726 [[],[]] .smaller = true := by decide
def e1205812900782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1205812900782 : Closed e1205812900782 ∧ code e1205812900782 = 5603859411886 := by decide
theorem cert_e1205812900782 : check e1205812900782 [[],[]] .smaller = true := by decide
def e1205812900794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1205812900794 : Closed e1205812900794 ∧ code e1205812900794 = 5603859411898 := by decide
theorem cert_e1205812900794 : check e1205812900794 [[],[]] .smaller = true := by decide
def e1205812900822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1205812900822 : Closed e1205812900822 ∧ code e1205812900822 = 5603859411926 := by decide
theorem cert_e1205812900822 : check e1205812900822 [[],[]] .smaller = true := by decide
def e1205812900826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1205812900826 : Closed e1205812900826 ∧ code e1205812900826 = 5603859411930 := by decide
theorem cert_e1205812900826 : check e1205812900826 [[],[]] .smaller = true := by decide
def e1205812901102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812901102 : Closed e1205812901102 ∧ code e1205812901102 = 5603859412206 := by decide
theorem cert_e1205812901102 : check e1205812901102 [[],[]] .smaller = true := by decide
def e1205812901110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812901110 : Closed e1205812901110 ∧ code e1205812901110 = 5603859412214 := by decide
theorem cert_e1205812901110 : check e1205812901110 [[],[]] .smaller = true := by decide
def e1205812901438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1205812901438 : Closed e1205812901438 ∧ code e1205812901438 = 5603859412542 := by decide
theorem cert_e1205812901438 : check e1205812901438 [[],[]] .three = true := by decide
def e1205812901486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812901486 : Closed e1205812901486 ∧ code e1205812901486 = 5603859412590 := by decide
theorem cert_e1205812901486 : check e1205812901486 [[],[]] .smaller = true := by decide
def e1205812901498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812901498 : Closed e1205812901498 ∧ code e1205812901498 = 5603859412602 := by decide
theorem cert_e1205812901498 : check e1205812901498 [[],[]] .smaller = true := by decide
def e1205812901686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812901686 : Closed e1205812901686 ∧ code e1205812901686 = 5603859412790 := by decide
theorem cert_e1205812901686 : check e1205812901686 [[],[]] .smaller = true := by decide
def e1205812901690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812901690 : Closed e1205812901690 ∧ code e1205812901690 = 5603859412794 := by decide
theorem cert_e1205812901690 : check e1205812901690 [[],[]] .smaller = true := by decide
def e1205812901774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1205812901774 : Closed e1205812901774 ∧ code e1205812901774 = 5603859412878 := by decide
theorem cert_e1205812901774 : check e1205812901774 [[],[]] .three = true := by decide
def e1205812902110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1205812902110 : Closed e1205812902110 ∧ code e1205812902110 = 5603859413214 := by decide
theorem cert_e1205812902110 : check e1205812902110 [[],[]] .three = true := by decide
def e1205812902126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1205812902126 : Closed e1205812902126 ∧ code e1205812902126 = 5603859413230 := by decide
theorem cert_e1205812902126 : check e1205812902126 [[],[]] .smaller = true := by decide
def e1205812902134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1205812902134 : Closed e1205812902134 ∧ code e1205812902134 = 5603859413238 := by decide
theorem cert_e1205812902134 : check e1205812902134 [[],[]] .smaller = true := by decide
def e1205812902138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1205812902138 : Closed e1205812902138 ∧ code e1205812902138 = 5603859413242 := by decide
theorem cert_e1205812902138 : check e1205812902138 [[],[]] .three = true := by decide
def e1205812902318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205812902318 : Closed e1205812902318 ∧ code e1205812902318 = 5603859413422 := by decide
theorem cert_e1205812902318 : check e1205812902318 [[],[]] .smaller = true := by decide
def e1205812902330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205812902330 : Closed e1205812902330 ∧ code e1205812902330 = 5603859413434 := by decide
theorem cert_e1205812902330 : check e1205812902330 [[],[]] .smaller = true := by decide
def e1205812902378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205812902378 : Closed e1205812902378 ∧ code e1205812902378 = 5603859413482 := by decide
theorem cert_e1205812902378 : check e1205812902378 [[],[]] .smaller = true := by decide
def e1205812902462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1205812902462 : Closed e1205812902462 ∧ code e1205812902462 = 5603859413566 := by decide
theorem cert_e1205812902462 : check e1205812902462 [[],[]] .three = true := by decide
def e1205812902510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812902510 : Closed e1205812902510 ∧ code e1205812902510 = 5603859413614 := by decide
theorem cert_e1205812902510 : check e1205812902510 [[],[]] .smaller = true := by decide
def e1205812902522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812902522 : Closed e1205812902522 ∧ code e1205812902522 = 5603859413626 := by decide
theorem cert_e1205812902522 : check e1205812902522 [[],[]] .smaller = true := by decide
def e1205812902686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1205812902686 : Closed e1205812902686 ∧ code e1205812902686 = 5603859413790 := by decide
theorem cert_e1205812902686 : check e1205812902686 [[],[]] .smaller = true := by decide
def e1205812902798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1205812902798 : Closed e1205812902798 ∧ code e1205812902798 = 5603859413902 := by decide
theorem cert_e1205812902798 : check e1205812902798 [[],[]] .smaller = true := by decide
def e1205812902810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812902810 : Closed e1205812902810 ∧ code e1205812902810 = 5603859413914 := by decide
theorem cert_e1205812902810 : check e1205812902810 [[],[]] .smaller = true := by decide
def e1205812902854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1205812902854 : Closed e1205812902854 ∧ code e1205812902854 = 5603859413958 := by decide
theorem cert_e1205812902854 : check e1205812902854 [[],[]] .three = true := by decide
def e1205812902878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e1205812902878 : Closed e1205812902878 ∧ code e1205812902878 = 5603859413982 := by decide
theorem cert_e1205812902878 : check e1205812902878 [[],[]] .three = true := by decide
def e1205812903030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1205812903030 : Closed e1205812903030 ∧ code e1205812903030 = 5603859414134 := by decide
theorem cert_e1205812903030 : check e1205812903030 [[],[]] .smaller = true := by decide
def e1205812903126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205812903126 : Closed e1205812903126 ∧ code e1205812903126 = 5603859414230 := by decide
theorem cert_e1205812903126 : check e1205812903126 [[],[]] .smaller = true := by decide
def e1205812903130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205812903130 : Closed e1205812903130 ∧ code e1205812903130 = 5603859414234 := by decide
theorem cert_e1205812903130 : check e1205812903130 [[],[]] .smaller = true := by decide
def e1205812903146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205812903146 : Closed e1205812903146 ∧ code e1205812903146 = 5603859414250 := by decide
theorem cert_e1205812903146 : check e1205812903146 [[],[]] .smaller = true := by decide
def e1205812903222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812903222 : Closed e1205812903222 ∧ code e1205812903222 = 5603859414326 := by decide
theorem cert_e1205812903222 : check e1205812903222 [[],[]] .smaller = true := by decide
def e1205812903226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812903226 : Closed e1205812903226 ∧ code e1205812903226 = 5603859414330 := by decide
theorem cert_e1205812903226 : check e1205812903226 [[],[]] .smaller = true := by decide
def e1205812903310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1205812903310 : Closed e1205812903310 ∧ code e1205812903310 = 5603859414414 := by decide
theorem cert_e1205812903310 : check e1205812903310 [[],[]] .smaller = true := by decide
def e1205812903322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812903322 : Closed e1205812903322 ∧ code e1205812903322 = 5603859414426 := by decide
theorem cert_e1205812903322 : check e1205812903322 [[],[]] .smaller = true := by decide
def e1205812903390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e1205812903390 : Closed e1205812903390 ∧ code e1205812903390 = 5603859414494 := by decide
theorem cert_e1205812903390 : check e1205812903390 [[],[]] .three = true := by decide
def e1205812903406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e1205812903406 : Closed e1205812903406 ∧ code e1205812903406 = 5603859414510 := by decide
theorem cert_e1205812903406 : check e1205812903406 [[],[]] .three = true := by decide
def e1205812903478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205812903478 : Closed e1205812903478 ∧ code e1205812903478 = 5603859414582 := by decide
theorem cert_e1205812903478 : check e1205812903478 [[],[]] .three = true := by decide
def e1205812903482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205812903482 : Closed e1205812903482 ∧ code e1205812903482 = 5603859414586 := by decide
theorem cert_e1205812903482 : check e1205812903482 [[],[]] .three = true := by decide
def e1205812903566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205812903566 : Closed e1205812903566 ∧ code e1205812903566 = 5603859414670 := by decide
theorem cert_e1205812903566 : check e1205812903566 [[],[]] .three = true := by decide
def e1205812903622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205812903622 : Closed e1205812903622 ∧ code e1205812903622 = 5603859414726 := by decide
theorem cert_e1205812903622 : check e1205812903622 [[],[]] .three = true := by decide
def e1205812903646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e1205812903646 : Closed e1205812903646 ∧ code e1205812903646 = 5603859414750 := by decide
theorem cert_e1205812903646 : check e1205812903646 [[],[]] .three = true := by decide
def e1205812903662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e1205812903662 : Closed e1205812903662 ∧ code e1205812903662 = 5603859414766 := by decide
theorem cert_e1205812903662 : check e1205812903662 [[],[]] .three = true := by decide
def e1205812903670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e1205812903670 : Closed e1205812903670 ∧ code e1205812903670 = 5603859414774 := by decide
theorem cert_e1205812903670 : check e1205812903670 [[],[]] .three = true := by decide
def e1205812904926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1205812904926 : Closed e1205812904926 ∧ code e1205812904926 = 5603859416030 := by decide
theorem cert_e1205812904926 : check e1205812904926 [[],[]] .smaller = true := by decide
def e1205812904942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1205812904942 : Closed e1205812904942 ∧ code e1205812904942 = 5603859416046 := by decide
theorem cert_e1205812904942 : check e1205812904942 [[],[]] .smaller = true := by decide
def e1205812906862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205812906862 : Closed e1205812906862 ∧ code e1205812906862 = 5603859417966 := by decide
theorem cert_e1205812906862 : check e1205812906862 [[],[]] .smaller = true := by decide
def e1205812906870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205812906870 : Closed e1205812906870 ∧ code e1205812906870 = 5603859417974 := by decide
theorem cert_e1205812906870 : check e1205812906870 [[],[]] .smaller = true := by decide
def e1205812906926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205812906926 : Closed e1205812906926 ∧ code e1205812906926 = 5603859418030 := by decide
theorem cert_e1205812906926 : check e1205812906926 [[],[]] .smaller = true := by decide
def e1205812906938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205812906938 : Closed e1205812906938 ∧ code e1205812906938 = 5603859418042 := by decide
theorem cert_e1205812906938 : check e1205812906938 [[],[]] .smaller = true := by decide
def e1205812906966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205812906966 : Closed e1205812906966 ∧ code e1205812906966 = 5603859418070 := by decide
theorem cert_e1205812906966 : check e1205812906966 [[],[]] .smaller = true := by decide
def e1205812906970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205812906970 : Closed e1205812906970 ∧ code e1205812906970 = 5603859418074 := by decide
theorem cert_e1205812906970 : check e1205812906970 [[],[]] .smaller = true := by decide
end Blc.Floor42
