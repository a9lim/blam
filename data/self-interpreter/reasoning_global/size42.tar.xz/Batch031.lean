import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e417027116854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e417027116854 : Closed e417027116854 ∧ code e417027116854 = 4815073627958 := by decide
theorem cert_e417027116854 : check e417027116854 [] .sourceHead = true := by decide
def e417027116858 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e417027116858 : Closed e417027116858 ∧ code e417027116858 = 4815073627962 := by decide
theorem cert_e417027116858 : check e417027116858 [] .sourceHead = true := by decide
def e417027122606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e417027122606 : Closed e417027122606 ∧ code e417027122606 = 4815073633710 := by decide
theorem cert_e417027122606 : check e417027122606 [] .sourceHead = true := by decide
def e417027122618 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e417027122618 : Closed e417027122618 ∧ code e417027122618 = 4815073633722 := by decide
theorem cert_e417027122618 : check e417027122618 [] .sourceHead = true := by decide
def e417027122666 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e417027122666 : Closed e417027122666 ∧ code e417027122666 = 4815073633770 := by decide
theorem cert_e417027122666 : check e417027122666 [] .sourceHead = true := by decide
def e417027122798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e417027122798 : Closed e417027122798 ∧ code e417027122798 = 4815073633902 := by decide
theorem cert_e417027122798 : check e417027122798 [] .sourceHead = true := by decide
def e417027122810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e417027122810 : Closed e417027122810 ∧ code e417027122810 = 4815073633914 := by decide
theorem cert_e417027122810 : check e417027122810 [] .sourceHead = true := by decide
def e417027123098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e417027123098 : Closed e417027123098 ∧ code e417027123098 = 4815073634202 := by decide
theorem cert_e417027123098 : check e417027123098 [] .sourceHead = true := by decide
def e417027125974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e417027125974 : Closed e417027125974 ∧ code e417027125974 = 4815073637078 := by decide
theorem cert_e417027125974 : check e417027125974 [] .sourceHead = true := by decide
def e417027125978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e417027125978 : Closed e417027125978 ∧ code e417027125978 = 4815073637082 := by decide
theorem cert_e417027125978 : check e417027125978 [] .sourceHead = true := by decide
def e417027125994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e417027125994 : Closed e417027125994 ∧ code e417027125994 = 4815073637098 := by decide
theorem cert_e417027125994 : check e417027125994 [] .sourceHead = true := by decide
def e417027126070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e417027126070 : Closed e417027126070 ∧ code e417027126070 = 4815073637174 := by decide
theorem cert_e417027126070 : check e417027126070 [] .sourceHead = true := by decide
def e417027126074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e417027126074 : Closed e417027126074 ∧ code e417027126074 = 4815073637178 := by decide
theorem cert_e417027126074 : check e417027126074 [] .sourceHead = true := by decide
def e417027126170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e417027126170 : Closed e417027126170 ∧ code e417027126170 = 4815073637274 := by decide
theorem cert_e417027126170 : check e417027126170 [] .sourceHead = true := by decide
def e417027263342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e417027263342 : Closed e417027263342 ∧ code e417027263342 = 4815073774446 := by decide
theorem cert_e417027263342 : check e417027263342 [] .sourceHead = true := by decide
def e417027263350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e417027263350 : Closed e417027263350 ∧ code e417027263350 = 4815073774454 := by decide
theorem cert_e417027263350 : check e417027263350 [] .sourceHead = true := by decide
def e417027263406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e417027263406 : Closed e417027263406 ∧ code e417027263406 = 4815073774510 := by decide
theorem cert_e417027263406 : check e417027263406 [] .sourceHead = true := by decide
def e417027263418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e417027263418 : Closed e417027263418 ∧ code e417027263418 = 4815073774522 := by decide
theorem cert_e417027263418 : check e417027263418 [] .sourceHead = true := by decide
def e417027263446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e417027263446 : Closed e417027263446 ∧ code e417027263446 = 4815073774550 := by decide
theorem cert_e417027263446 : check e417027263446 [] .sourceHead = true := by decide
def e417027263450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e417027263450 : Closed e417027263450 ∧ code e417027263450 = 4815073774554 := by decide
theorem cert_e417027263450 : check e417027263450 [] .sourceHead = true := by decide
def e417027263726 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e417027263726 : Closed e417027263726 ∧ code e417027263726 = 4815073774830 := by decide
theorem cert_e417027263726 : check e417027263726 [] .sourceHead = true := by decide
def e417027263734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e417027263734 : Closed e417027263734 ∧ code e417027263734 = 4815073774838 := by decide
theorem cert_e417027263734 : check e417027263734 [] .sourceHead = true := by decide
def e417027264110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e417027264110 : Closed e417027264110 ∧ code e417027264110 = 4815073775214 := by decide
theorem cert_e417027264110 : check e417027264110 [] .sourceHead = true := by decide
def e417027264122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e417027264122 : Closed e417027264122 ∧ code e417027264122 = 4815073775226 := by decide
theorem cert_e417027264122 : check e417027264122 [] .sourceHead = true := by decide
def e417027264310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e417027264310 : Closed e417027264310 ∧ code e417027264310 = 4815073775414 := by decide
theorem cert_e417027264310 : check e417027264310 [] .sourceHead = true := by decide
def e417027264314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e417027264314 : Closed e417027264314 ∧ code e417027264314 = 4815073775418 := by decide
theorem cert_e417027264314 : check e417027264314 [] .sourceHead = true := by decide
def e417048124126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e417048124126 : Closed e417048124126 ∧ code e417048124126 = 4815094635230 := by decide
theorem cert_e417048124126 : check e417048124126 [] .sourceHead = true := by decide
def e417048124150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e417048124150 : Closed e417048124150 ∧ code e417048124150 = 4815094635254 := by decide
theorem cert_e417048124150 : check e417048124150 [] .sourceHead = true := by decide
def e417048124254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e417048124254 : Closed e417048124254 ∧ code e417048124254 = 4815094635358 := by decide
theorem cert_e417048124254 : check e417048124254 [] .sourceHead = true := by decide
def e417048124270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e417048124270 : Closed e417048124270 ∧ code e417048124270 = 4815094635374 := by decide
theorem cert_e417048124270 : check e417048124270 [] .sourceHead = true := by decide
def e417048124278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e417048124278 : Closed e417048124278 ∧ code e417048124278 = 4815094635382 := by decide
theorem cert_e417048124278 : check e417048124278 [] .sourceHead = true := by decide
def e417048124282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e417048124282 : Closed e417048124282 ∧ code e417048124282 = 4815094635386 := by decide
theorem cert_e417048124282 : check e417048124282 [] .sourceHead = true := by decide
def e417048124342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e417048124342 : Closed e417048124342 ∧ code e417048124342 = 4815094635446 := by decide
theorem cert_e417048124342 : check e417048124342 [] .sourceHead = true := by decide
def e417048124374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e417048124374 : Closed e417048124374 ∧ code e417048124374 = 4815094635478 := by decide
theorem cert_e417048124374 : check e417048124374 [] .sourceHead = true := by decide
def e417048124378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e417048124378 : Closed e417048124378 ∧ code e417048124378 = 4815094635482 := by decide
theorem cert_e417048124378 : check e417048124378 [] .sourceHead = true := by decide
def e417048124766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e417048124766 : Closed e417048124766 ∧ code e417048124766 = 4815094635870 := by decide
theorem cert_e417048124766 : check e417048124766 [] .sourceHead = true := by decide
def e417048124782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e417048124782 : Closed e417048124782 ∧ code e417048124782 = 4815094635886 := by decide
theorem cert_e417048124782 : check e417048124782 [] .sourceHead = true := by decide
def e417048124790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e417048124790 : Closed e417048124790 ∧ code e417048124790 = 4815094635894 := by decide
theorem cert_e417048124790 : check e417048124790 [] .sourceHead = true := by decide
def e417048124794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e417048124794 : Closed e417048124794 ∧ code e417048124794 = 4815094635898 := by decide
theorem cert_e417048124794 : check e417048124794 [] .sourceHead = true := by decide
def e417048124846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e417048124846 : Closed e417048124846 ∧ code e417048124846 = 4815094635950 := by decide
theorem cert_e417048124846 : check e417048124846 [] .sourceHead = true := by decide
def e417048124858 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e417048124858 : Closed e417048124858 ∧ code e417048124858 = 4815094635962 := by decide
theorem cert_e417048124858 : check e417048124858 [] .sourceHead = true := by decide
def e417048124886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e417048124886 : Closed e417048124886 ∧ code e417048124886 = 4815094635990 := by decide
theorem cert_e417048124886 : check e417048124886 [] .sourceHead = true := by decide
def e417048124890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e417048124890 : Closed e417048124890 ∧ code e417048124890 = 4815094635994 := by decide
theorem cert_e417048124890 : check e417048124890 [] .sourceHead = true := by decide
def e417048124906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e417048124906 : Closed e417048124906 ∧ code e417048124906 = 4815094636010 := by decide
theorem cert_e417048124906 : check e417048124906 [] .sourceHead = true := by decide
def e417048125110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e417048125110 : Closed e417048125110 ∧ code e417048125110 = 4815094636214 := by decide
theorem cert_e417048125110 : check e417048125110 [] .sourceHead = true := by decide
def e417048125142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e417048125142 : Closed e417048125142 ∧ code e417048125142 = 4815094636246 := by decide
theorem cert_e417048125142 : check e417048125142 [] .sourceHead = true := by decide
def e417048125146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e417048125146 : Closed e417048125146 ∧ code e417048125146 = 4815094636250 := by decide
theorem cert_e417048125146 : check e417048125146 [] .sourceHead = true := by decide
def e417048125270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e417048125270 : Closed e417048125270 ∧ code e417048125270 = 4815094636374 := by decide
theorem cert_e417048125270 : check e417048125270 [] .sourceHead = true := by decide
def e417048125274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e417048125274 : Closed e417048125274 ∧ code e417048125274 = 4815094636378 := by decide
theorem cert_e417048125274 : check e417048125274 [] .sourceHead = true := by decide
def e417048125290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e417048125290 : Closed e417048125290 ∧ code e417048125290 = 4815094636394 := by decide
theorem cert_e417048125290 : check e417048125290 [] .sourceHead = true := by decide
def e417048127198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e417048127198 : Closed e417048127198 ∧ code e417048127198 = 4815094638302 := by decide
theorem cert_e417048127198 : check e417048127198 [] .sourceHead = true := by decide
def e417048127222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e417048127222 : Closed e417048127222 ∧ code e417048127222 = 4815094638326 := by decide
theorem cert_e417048127222 : check e417048127222 [] .sourceHead = true := by decide
def e417048127326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e417048127326 : Closed e417048127326 ∧ code e417048127326 = 4815094638430 := by decide
theorem cert_e417048127326 : check e417048127326 [] .sourceHead = true := by decide
def e417048127342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e417048127342 : Closed e417048127342 ∧ code e417048127342 = 4815094638446 := by decide
theorem cert_e417048127342 : check e417048127342 [] .sourceHead = true := by decide
def e417048127350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e417048127350 : Closed e417048127350 ∧ code e417048127350 = 4815094638454 := by decide
theorem cert_e417048127350 : check e417048127350 [] .sourceHead = true := by decide
def e417048127354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e417048127354 : Closed e417048127354 ∧ code e417048127354 = 4815094638458 := by decide
theorem cert_e417048127354 : check e417048127354 [] .sourceHead = true := by decide
def e417048127414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e417048127414 : Closed e417048127414 ∧ code e417048127414 = 4815094638518 := by decide
theorem cert_e417048127414 : check e417048127414 [] .sourceHead = true := by decide
def e417048127446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e417048127446 : Closed e417048127446 ∧ code e417048127446 = 4815094638550 := by decide
theorem cert_e417048127446 : check e417048127446 [] .sourceHead = true := by decide
def e417048127450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e417048127450 : Closed e417048127450 ∧ code e417048127450 = 4815094638554 := by decide
theorem cert_e417048127450 : check e417048127450 [] .sourceHead = true := by decide
def e417048127966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e417048127966 : Closed e417048127966 ∧ code e417048127966 = 4815094639070 := by decide
theorem cert_e417048127966 : check e417048127966 [] .sourceHead = true := by decide
def e417048127990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e417048127990 : Closed e417048127990 ∧ code e417048127990 = 4815094639094 := by decide
theorem cert_e417048127990 : check e417048127990 [] .sourceHead = true := by decide
def e417048128734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e417048128734 : Closed e417048128734 ∧ code e417048128734 = 4815094639838 := by decide
theorem cert_e417048128734 : check e417048128734 [] .sourceHead = true := by decide
def e417048128750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e417048128750 : Closed e417048128750 ∧ code e417048128750 = 4815094639854 := by decide
theorem cert_e417048128750 : check e417048128750 [] .sourceHead = true := by decide
def e417048128758 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e417048128758 : Closed e417048128758 ∧ code e417048128758 = 4815094639862 := by decide
theorem cert_e417048128758 : check e417048128758 [] .sourceHead = true := by decide
def e417048128762 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e417048128762 : Closed e417048128762 ∧ code e417048128762 = 4815094639866 := by decide
theorem cert_e417048128762 : check e417048128762 [] .sourceHead = true := by decide
def e417048129142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e417048129142 : Closed e417048129142 ∧ code e417048129142 = 4815094640246 := by decide
theorem cert_e417048129142 : check e417048129142 [] .sourceHead = true := by decide
def e417048129334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e417048129334 : Closed e417048129334 ∧ code e417048129334 = 4815094640438 := by decide
theorem cert_e417048129334 : check e417048129334 [] .sourceHead = true := by decide
def e417048129338 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e417048129338 : Closed e417048129338 ∧ code e417048129338 = 4815094640442 := by decide
theorem cert_e417048129338 : check e417048129338 [] .sourceHead = true := by decide
def e417048130398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e417048130398 : Closed e417048130398 ∧ code e417048130398 = 4815094641502 := by decide
theorem cert_e417048130398 : check e417048130398 [] .sourceHead = true := by decide
def e417048130414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e417048130414 : Closed e417048130414 ∧ code e417048130414 = 4815094641518 := by decide
theorem cert_e417048130414 : check e417048130414 [] .sourceHead = true := by decide
def e417048130422 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e417048130422 : Closed e417048130422 ∧ code e417048130422 = 4815094641526 := by decide
theorem cert_e417048130422 : check e417048130422 [] .sourceHead = true := by decide
def e417048130426 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e417048130426 : Closed e417048130426 ∧ code e417048130426 = 4815094641530 := by decide
theorem cert_e417048130426 : check e417048130426 [] .sourceHead = true := by decide
def e417048130478 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e417048130478 : Closed e417048130478 ∧ code e417048130478 = 4815094641582 := by decide
theorem cert_e417048130478 : check e417048130478 [] .sourceHead = true := by decide
def e417048130490 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e417048130490 : Closed e417048130490 ∧ code e417048130490 = 4815094641594 := by decide
theorem cert_e417048130490 : check e417048130490 [] .sourceHead = true := by decide
def e417048130518 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e417048130518 : Closed e417048130518 ∧ code e417048130518 = 4815094641622 := by decide
theorem cert_e417048130518 : check e417048130518 [] .sourceHead = true := by decide
def e417048130522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e417048130522 : Closed e417048130522 ∧ code e417048130522 = 4815094641626 := by decide
theorem cert_e417048130522 : check e417048130522 [] .sourceHead = true := by decide
def e417048130538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e417048130538 : Closed e417048130538 ∧ code e417048130538 = 4815094641642 := by decide
theorem cert_e417048130538 : check e417048130538 [] .sourceHead = true := by decide
def e417048130782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e417048130782 : Closed e417048130782 ∧ code e417048130782 = 4815094641886 := by decide
theorem cert_e417048130782 : check e417048130782 [] .sourceHead = true := by decide
def e417048130798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e417048130798 : Closed e417048130798 ∧ code e417048130798 = 4815094641902 := by decide
theorem cert_e417048130798 : check e417048130798 [] .sourceHead = true := by decide
def e417048130806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e417048130806 : Closed e417048130806 ∧ code e417048130806 = 4815094641910 := by decide
theorem cert_e417048130806 : check e417048130806 [] .sourceHead = true := by decide
def e417048130810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e417048130810 : Closed e417048130810 ∧ code e417048130810 = 4815094641914 := by decide
theorem cert_e417048130810 : check e417048130810 [] .sourceHead = true := by decide
def e417048131182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e417048131182 : Closed e417048131182 ∧ code e417048131182 = 4815094642286 := by decide
theorem cert_e417048131182 : check e417048131182 [] .sourceHead = true := by decide
def e417048131194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e417048131194 : Closed e417048131194 ∧ code e417048131194 = 4815094642298 := by decide
theorem cert_e417048131194 : check e417048131194 [] .sourceHead = true := by decide
def e417048131382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e417048131382 : Closed e417048131382 ∧ code e417048131382 = 4815094642486 := by decide
theorem cert_e417048131382 : check e417048131382 [] .sourceHead = true := by decide
def e417048131386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e417048131386 : Closed e417048131386 ∧ code e417048131386 = 4815094642490 := by decide
theorem cert_e417048131386 : check e417048131386 [] .sourceHead = true := by decide
def e417048131482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e417048131482 : Closed e417048131482 ∧ code e417048131482 = 4815094642586 := by decide
theorem cert_e417048131482 : check e417048131482 [] .sourceHead = true := by decide
def e417048132022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e417048132022 : Closed e417048132022 ∧ code e417048132022 = 4815094643126 := by decide
theorem cert_e417048132022 : check e417048132022 [] .sourceHead = true := by decide
def e417048132054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e417048132054 : Closed e417048132054 ∧ code e417048132054 = 4815094643158 := by decide
theorem cert_e417048132054 : check e417048132054 [] .sourceHead = true := by decide
def e417048132058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e417048132058 : Closed e417048132058 ∧ code e417048132058 = 4815094643162 := by decide
theorem cert_e417048132058 : check e417048132058 [] .sourceHead = true := by decide
def e417048132214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e417048132214 : Closed e417048132214 ∧ code e417048132214 = 4815094643318 := by decide
theorem cert_e417048132214 : check e417048132214 [] .sourceHead = true := by decide
def e417048132406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e417048132406 : Closed e417048132406 ∧ code e417048132406 = 4815094643510 := by decide
theorem cert_e417048132406 : check e417048132406 [] .sourceHead = true := by decide
def e417048132410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e417048132410 : Closed e417048132410 ∧ code e417048132410 = 4815094643514 := by decide
theorem cert_e417048132410 : check e417048132410 [] .sourceHead = true := by decide
def e417048132822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e417048132822 : Closed e417048132822 ∧ code e417048132822 = 4815094643926 := by decide
theorem cert_e417048132822 : check e417048132822 [] .sourceHead = true := by decide
def e417048132826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e417048132826 : Closed e417048132826 ∧ code e417048132826 = 4815094643930 := by decide
theorem cert_e417048132826 : check e417048132826 [] .sourceHead = true := by decide
def e417048132842 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e417048132842 : Closed e417048132842 ∧ code e417048132842 = 4815094643946 := by decide
theorem cert_e417048132842 : check e417048132842 [] .sourceHead = true := by decide
def e417048132918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e417048132918 : Closed e417048132918 ∧ code e417048132918 = 4815094644022 := by decide
theorem cert_e417048132918 : check e417048132918 [] .sourceHead = true := by decide
def e417048132922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e417048132922 : Closed e417048132922 ∧ code e417048132922 = 4815094644026 := by decide
theorem cert_e417048132922 : check e417048132922 [] .sourceHead = true := by decide
def e417048133018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e417048133018 : Closed e417048133018 ∧ code e417048133018 = 4815094644122 := by decide
theorem cert_e417048133018 : check e417048133018 [] .sourceHead = true := by decide
def e417048139486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e417048139486 : Closed e417048139486 ∧ code e417048139486 = 4815094650590 := by decide
theorem cert_e417048139486 : check e417048139486 [] .sourceHead = true := by decide
def e417048139510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e417048139510 : Closed e417048139510 ∧ code e417048139510 = 4815094650614 := by decide
theorem cert_e417048139510 : check e417048139510 [] .sourceHead = true := by decide
def e417048139614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e417048139614 : Closed e417048139614 ∧ code e417048139614 = 4815094650718 := by decide
theorem cert_e417048139614 : check e417048139614 [] .sourceHead = true := by decide
def e417048139630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e417048139630 : Closed e417048139630 ∧ code e417048139630 = 4815094650734 := by decide
theorem cert_e417048139630 : check e417048139630 [] .sourceHead = true := by decide
def e417048139638 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e417048139638 : Closed e417048139638 ∧ code e417048139638 = 4815094650742 := by decide
theorem cert_e417048139638 : check e417048139638 [] .sourceHead = true := by decide
def e417048139642 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e417048139642 : Closed e417048139642 ∧ code e417048139642 = 4815094650746 := by decide
theorem cert_e417048139642 : check e417048139642 [] .sourceHead = true := by decide
def e417048139702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e417048139702 : Closed e417048139702 ∧ code e417048139702 = 4815094650806 := by decide
theorem cert_e417048139702 : check e417048139702 [] .sourceHead = true := by decide
def e417048139734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e417048139734 : Closed e417048139734 ∧ code e417048139734 = 4815094650838 := by decide
theorem cert_e417048139734 : check e417048139734 [] .sourceHead = true := by decide
def e417048139738 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e417048139738 : Closed e417048139738 ∧ code e417048139738 = 4815094650842 := by decide
theorem cert_e417048139738 : check e417048139738 [] .sourceHead = true := by decide
def e417048140254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e417048140254 : Closed e417048140254 ∧ code e417048140254 = 4815094651358 := by decide
theorem cert_e417048140254 : check e417048140254 [] .sourceHead = true := by decide
def e417048140278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e417048140278 : Closed e417048140278 ∧ code e417048140278 = 4815094651382 := by decide
theorem cert_e417048140278 : check e417048140278 [] .sourceHead = true := by decide
def e417048141022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e417048141022 : Closed e417048141022 ∧ code e417048141022 = 4815094652126 := by decide
theorem cert_e417048141022 : check e417048141022 [] .sourceHead = true := by decide
def e417048141038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e417048141038 : Closed e417048141038 ∧ code e417048141038 = 4815094652142 := by decide
theorem cert_e417048141038 : check e417048141038 [] .sourceHead = true := by decide
def e417048141046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e417048141046 : Closed e417048141046 ∧ code e417048141046 = 4815094652150 := by decide
theorem cert_e417048141046 : check e417048141046 [] .sourceHead = true := by decide
def e417048141050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e417048141050 : Closed e417048141050 ∧ code e417048141050 = 4815094652154 := by decide
theorem cert_e417048141050 : check e417048141050 [] .sourceHead = true := by decide
def e417048141430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e417048141430 : Closed e417048141430 ∧ code e417048141430 = 4815094652534 := by decide
theorem cert_e417048141430 : check e417048141430 [] .sourceHead = true := by decide
def e417048141622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048141622 : Closed e417048141622 ∧ code e417048141622 = 4815094652726 := by decide
theorem cert_e417048141622 : check e417048141622 [] .sourceHead = true := by decide
def e417048141626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048141626 : Closed e417048141626 ∧ code e417048141626 = 4815094652730 := by decide
theorem cert_e417048141626 : check e417048141626 [] .sourceHead = true := by decide
def e417048152926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e417048152926 : Closed e417048152926 ∧ code e417048152926 = 4815094664030 := by decide
theorem cert_e417048152926 : check e417048152926 [] .sourceHead = true := by decide
def e417048152942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e417048152942 : Closed e417048152942 ∧ code e417048152942 = 4815094664046 := by decide
theorem cert_e417048152942 : check e417048152942 [] .sourceHead = true := by decide
def e417048152950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e417048152950 : Closed e417048152950 ∧ code e417048152950 = 4815094664054 := by decide
theorem cert_e417048152950 : check e417048152950 [] .sourceHead = true := by decide
def e417048152954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e417048152954 : Closed e417048152954 ∧ code e417048152954 = 4815094664058 := by decide
theorem cert_e417048152954 : check e417048152954 [] .sourceHead = true := by decide
def e417048153006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e417048153006 : Closed e417048153006 ∧ code e417048153006 = 4815094664110 := by decide
theorem cert_e417048153006 : check e417048153006 [] .sourceHead = true := by decide
def e417048153018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e417048153018 : Closed e417048153018 ∧ code e417048153018 = 4815094664122 := by decide
theorem cert_e417048153018 : check e417048153018 [] .sourceHead = true := by decide
def e417048153046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e417048153046 : Closed e417048153046 ∧ code e417048153046 = 4815094664150 := by decide
theorem cert_e417048153046 : check e417048153046 [] .sourceHead = true := by decide
def e417048153050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e417048153050 : Closed e417048153050 ∧ code e417048153050 = 4815094664154 := by decide
theorem cert_e417048153050 : check e417048153050 [] .sourceHead = true := by decide
def e417048153066 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e417048153066 : Closed e417048153066 ∧ code e417048153066 = 4815094664170 := by decide
theorem cert_e417048153066 : check e417048153066 [] .sourceHead = true := by decide
def e417048153310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e417048153310 : Closed e417048153310 ∧ code e417048153310 = 4815094664414 := by decide
theorem cert_e417048153310 : check e417048153310 [] .sourceHead = true := by decide
def e417048153326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e417048153326 : Closed e417048153326 ∧ code e417048153326 = 4815094664430 := by decide
theorem cert_e417048153326 : check e417048153326 [] .sourceHead = true := by decide
def e417048153334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e417048153334 : Closed e417048153334 ∧ code e417048153334 = 4815094664438 := by decide
theorem cert_e417048153334 : check e417048153334 [] .sourceHead = true := by decide
def e417048153338 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e417048153338 : Closed e417048153338 ∧ code e417048153338 = 4815094664442 := by decide
theorem cert_e417048153338 : check e417048153338 [] .sourceHead = true := by decide
def e417048153710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e417048153710 : Closed e417048153710 ∧ code e417048153710 = 4815094664814 := by decide
theorem cert_e417048153710 : check e417048153710 [] .sourceHead = true := by decide
def e417048153722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e417048153722 : Closed e417048153722 ∧ code e417048153722 = 4815094664826 := by decide
theorem cert_e417048153722 : check e417048153722 [] .sourceHead = true := by decide
def e417048153910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048153910 : Closed e417048153910 ∧ code e417048153910 = 4815094665014 := by decide
theorem cert_e417048153910 : check e417048153910 [] .sourceHead = true := by decide
def e417048153914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048153914 : Closed e417048153914 ∧ code e417048153914 = 4815094665018 := by decide
theorem cert_e417048153914 : check e417048153914 [] .sourceHead = true := by decide
def e417048154010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e417048154010 : Closed e417048154010 ∧ code e417048154010 = 4815094665114 := by decide
theorem cert_e417048154010 : check e417048154010 [] .sourceHead = true := by decide
def e417048159670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e417048159670 : Closed e417048159670 ∧ code e417048159670 = 4815094670774 := by decide
theorem cert_e417048159670 : check e417048159670 [] .sourceHead = true := by decide
def e417048159702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e417048159702 : Closed e417048159702 ∧ code e417048159702 = 4815094670806 := by decide
theorem cert_e417048159702 : check e417048159702 [] .sourceHead = true := by decide
def e417048159706 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e417048159706 : Closed e417048159706 ∧ code e417048159706 = 4815094670810 := by decide
theorem cert_e417048159706 : check e417048159706 [] .sourceHead = true := by decide
def e417048159862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e417048159862 : Closed e417048159862 ∧ code e417048159862 = 4815094670966 := by decide
theorem cert_e417048159862 : check e417048159862 [] .sourceHead = true := by decide
def e417048160054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048160054 : Closed e417048160054 ∧ code e417048160054 = 4815094671158 := by decide
theorem cert_e417048160054 : check e417048160054 [] .sourceHead = true := by decide
def e417048160058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048160058 : Closed e417048160058 ∧ code e417048160058 = 4815094671162 := by decide
theorem cert_e417048160058 : check e417048160058 [] .sourceHead = true := by decide
def e417048163030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e417048163030 : Closed e417048163030 ∧ code e417048163030 = 4815094674134 := by decide
theorem cert_e417048163030 : check e417048163030 [] .sourceHead = true := by decide
def e417048163034 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e417048163034 : Closed e417048163034 ∧ code e417048163034 = 4815094674138 := by decide
theorem cert_e417048163034 : check e417048163034 [] .sourceHead = true := by decide
def e417048163050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e417048163050 : Closed e417048163050 ∧ code e417048163050 = 4815094674154 := by decide
theorem cert_e417048163050 : check e417048163050 [] .sourceHead = true := by decide
def e417048163126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048163126 : Closed e417048163126 ∧ code e417048163126 = 4815094674230 := by decide
theorem cert_e417048163126 : check e417048163126 [] .sourceHead = true := by decide
def e417048163130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048163130 : Closed e417048163130 ∧ code e417048163130 = 4815094674234 := by decide
theorem cert_e417048163130 : check e417048163130 [] .sourceHead = true := by decide
def e417048163226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e417048163226 : Closed e417048163226 ∧ code e417048163226 = 4815094674330 := by decide
theorem cert_e417048163226 : check e417048163226 [] .sourceHead = true := by decide
def e417048388462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e417048388462 : Closed e417048388462 ∧ code e417048388462 = 4815094899566 := by decide
theorem cert_e417048388462 : check e417048388462 [] .sourceHead = true := by decide
def e417048388470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e417048388470 : Closed e417048388470 ∧ code e417048388470 = 4815094899574 := by decide
theorem cert_e417048388470 : check e417048388470 [] .sourceHead = true := by decide
def e417048388526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e417048388526 : Closed e417048388526 ∧ code e417048388526 = 4815094899630 := by decide
theorem cert_e417048388526 : check e417048388526 [] .sourceHead = true := by decide
def e417048388538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e417048388538 : Closed e417048388538 ∧ code e417048388538 = 4815094899642 := by decide
theorem cert_e417048388538 : check e417048388538 [] .sourceHead = true := by decide
def e417048388566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e417048388566 : Closed e417048388566 ∧ code e417048388566 = 4815094899670 := by decide
theorem cert_e417048388566 : check e417048388566 [] .sourceHead = true := by decide
def e417048388570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e417048388570 : Closed e417048388570 ∧ code e417048388570 = 4815094899674 := by decide
theorem cert_e417048388570 : check e417048388570 [] .sourceHead = true := by decide
def e417048389870 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e417048389870 : Closed e417048389870 ∧ code e417048389870 = 4815094900974 := by decide
theorem cert_e417048389870 : check e417048389870 [] .sourceHead = true := by decide
def e417048389878 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e417048389878 : Closed e417048389878 ∧ code e417048389878 = 4815094900982 := by decide
theorem cert_e417048389878 : check e417048389878 [] .sourceHead = true := by decide
def e417048390430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e417048390430 : Closed e417048390430 ∧ code e417048390430 = 4815094901534 := by decide
theorem cert_e417048390430 : check e417048390430 [] .sourceHead = true := by decide
def e417048390542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e417048390542 : Closed e417048390542 ∧ code e417048390542 = 4815094901646 := by decide
theorem cert_e417048390542 : check e417048390542 [] .sourceHead = true := by decide
def e417048390766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e417048390766 : Closed e417048390766 ∧ code e417048390766 = 4815094901870 := by decide
theorem cert_e417048390766 : check e417048390766 [] .sourceHead = true := by decide
def e417048390778 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e417048390778 : Closed e417048390778 ∧ code e417048390778 = 4815094901882 := by decide
theorem cert_e417048390778 : check e417048390778 [] .sourceHead = true := by decide
def e417048390942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e417048390942 : Closed e417048390942 ∧ code e417048390942 = 4815094902046 := by decide
theorem cert_e417048390942 : check e417048390942 [] .sourceHead = true := by decide
def e417048391110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e417048391110 : Closed e417048391110 ∧ code e417048391110 = 4815094902214 := by decide
theorem cert_e417048391110 : check e417048391110 [] .sourceHead = true := by decide
end Blc.Floor42
