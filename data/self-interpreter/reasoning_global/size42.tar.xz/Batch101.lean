import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812805006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205812805006 : Closed e1205812805006 ∧ code e1205812805006 = 5603859316110 := by decide
theorem cert_e1205812805006 : check e1205812805006 [[],[]] .smaller = true := by decide
def e1205812805018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812805018 : Closed e1205812805018 ∧ code e1205812805018 = 5603859316122 := by decide
theorem cert_e1205812805018 : check e1205812805018 [[],[]] .smaller = true := by decide
def e1205812805086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e1205812805086 : Closed e1205812805086 ∧ code e1205812805086 = 5603859316190 := by decide
theorem cert_e1205812805086 : check e1205812805086 [[],[]] .three = true := by decide
def e1205812805102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e1205812805102 : Closed e1205812805102 ∧ code e1205812805102 = 5603859316206 := by decide
theorem cert_e1205812805102 : check e1205812805102 [[],[]] .three = true := by decide
def e1205812805174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1205812805174 : Closed e1205812805174 ∧ code e1205812805174 = 5603859316278 := by decide
theorem cert_e1205812805174 : check e1205812805174 [[],[]] .three = true := by decide
def e1205812805178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205812805178 : Closed e1205812805178 ∧ code e1205812805178 = 5603859316282 := by decide
theorem cert_e1205812805178 : check e1205812805178 [[],[]] .three = true := by decide
def e1205812805262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1205812805262 : Closed e1205812805262 ∧ code e1205812805262 = 5603859316366 := by decide
theorem cert_e1205812805262 : check e1205812805262 [[],[]] .three = true := by decide
def e1205812805318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205812805318 : Closed e1205812805318 ∧ code e1205812805318 = 5603859316422 := by decide
theorem cert_e1205812805318 : check e1205812805318 [[],[]] .three = true := by decide
def e1205812805342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e1205812805342 : Closed e1205812805342 ∧ code e1205812805342 = 5603859316446 := by decide
theorem cert_e1205812805342 : check e1205812805342 [[],[]] .three = true := by decide
def e1205812805358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e1205812805358 : Closed e1205812805358 ∧ code e1205812805358 = 5603859316462 := by decide
theorem cert_e1205812805358 : check e1205812805358 [[],[]] .three = true := by decide
def e1205812805366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e1205812805366 : Closed e1205812805366 ∧ code e1205812805366 = 5603859316470 := by decide
theorem cert_e1205812805366 : check e1205812805366 [[],[]] .three = true := by decide
def e1205812806622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1205812806622 : Closed e1205812806622 ∧ code e1205812806622 = 5603859317726 := by decide
theorem cert_e1205812806622 : check e1205812806622 [[],[]] .smaller = true := by decide
def e1205812806638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1205812806638 : Closed e1205812806638 ∧ code e1205812806638 = 5603859317742 := by decide
theorem cert_e1205812806638 : check e1205812806638 [[],[]] .smaller = true := by decide
def e1205812808558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205812808558 : Closed e1205812808558 ∧ code e1205812808558 = 5603859319662 := by decide
theorem cert_e1205812808558 : check e1205812808558 [[],[]] .smaller = true := by decide
def e1205812808566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205812808566 : Closed e1205812808566 ∧ code e1205812808566 = 5603859319670 := by decide
theorem cert_e1205812808566 : check e1205812808566 [[],[]] .smaller = true := by decide
def e1205812808622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205812808622 : Closed e1205812808622 ∧ code e1205812808622 = 5603859319726 := by decide
theorem cert_e1205812808622 : check e1205812808622 [[],[]] .smaller = true := by decide
def e1205812808634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205812808634 : Closed e1205812808634 ∧ code e1205812808634 = 5603859319738 := by decide
theorem cert_e1205812808634 : check e1205812808634 [[],[]] .smaller = true := by decide
def e1205812808662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205812808662 : Closed e1205812808662 ∧ code e1205812808662 = 5603859319766 := by decide
theorem cert_e1205812808662 : check e1205812808662 [[],[]] .smaller = true := by decide
def e1205812808666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205812808666 : Closed e1205812808666 ∧ code e1205812808666 = 5603859319770 := by decide
theorem cert_e1205812808666 : check e1205812808666 [[],[]] .smaller = true := by decide
def e1205812808942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812808942 : Closed e1205812808942 ∧ code e1205812808942 = 5603859320046 := by decide
theorem cert_e1205812808942 : check e1205812808942 [[],[]] .smaller = true := by decide
def e1205812808950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812808950 : Closed e1205812808950 ∧ code e1205812808950 = 5603859320054 := by decide
theorem cert_e1205812808950 : check e1205812808950 [[],[]] .smaller = true := by decide
def e1205812809278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1205812809278 : Closed e1205812809278 ∧ code e1205812809278 = 5603859320382 := by decide
theorem cert_e1205812809278 : check e1205812809278 [[],[]] .three = true := by decide
def e1205812809326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812809326 : Closed e1205812809326 ∧ code e1205812809326 = 5603859320430 := by decide
theorem cert_e1205812809326 : check e1205812809326 [[],[]] .smaller = true := by decide
def e1205812809338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812809338 : Closed e1205812809338 ∧ code e1205812809338 = 5603859320442 := by decide
theorem cert_e1205812809338 : check e1205812809338 [[],[]] .smaller = true := by decide
def e1205812809526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812809526 : Closed e1205812809526 ∧ code e1205812809526 = 5603859320630 := by decide
theorem cert_e1205812809526 : check e1205812809526 [[],[]] .smaller = true := by decide
def e1205812809530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812809530 : Closed e1205812809530 ∧ code e1205812809530 = 5603859320634 := by decide
theorem cert_e1205812809530 : check e1205812809530 [[],[]] .smaller = true := by decide
def e1205812809614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1205812809614 : Closed e1205812809614 ∧ code e1205812809614 = 5603859320718 := by decide
theorem cert_e1205812809614 : check e1205812809614 [[],[]] .three = true := by decide
def e1205812814302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1205812814302 : Closed e1205812814302 ∧ code e1205812814302 = 5603859325406 := by decide
theorem cert_e1205812814302 : check e1205812814302 [[],[]] .smaller = true := by decide
def e1205812814326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1205812814326 : Closed e1205812814326 ∧ code e1205812814326 = 5603859325430 := by decide
theorem cert_e1205812814326 : check e1205812814326 [[],[]] .smaller = true := by decide
def e1205812815278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1205812815278 : Closed e1205812815278 ∧ code e1205812815278 = 5603859326382 := by decide
theorem cert_e1205812815278 : check e1205812815278 [[],[]] .smaller = true := by decide
def e1205812815290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1205812815290 : Closed e1205812815290 ∧ code e1205812815290 = 5603859326394 := by decide
theorem cert_e1205812815290 : check e1205812815290 [[],[]] .smaller = true := by decide
def e1205812815338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1205812815338 : Closed e1205812815338 ∧ code e1205812815338 = 5603859326442 := by decide
theorem cert_e1205812815338 : check e1205812815338 [[],[]] .smaller = true := by decide
def e1205812815422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1205812815422 : Closed e1205812815422 ∧ code e1205812815422 = 5603859326526 := by decide
theorem cert_e1205812815422 : check e1205812815422 [[],[]] .three = true := by decide
def e1205812815470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812815470 : Closed e1205812815470 ∧ code e1205812815470 = 5603859326574 := by decide
theorem cert_e1205812815470 : check e1205812815470 [[],[]] .smaller = true := by decide
def e1205812815482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812815482 : Closed e1205812815482 ∧ code e1205812815482 = 5603859326586 := by decide
theorem cert_e1205812815482 : check e1205812815482 [[],[]] .smaller = true := by decide
def e1205812815646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1205812815646 : Closed e1205812815646 ∧ code e1205812815646 = 5603859326750 := by decide
theorem cert_e1205812815646 : check e1205812815646 [[],[]] .smaller = true := by decide
def e1205812815758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1205812815758 : Closed e1205812815758 ∧ code e1205812815758 = 5603859326862 := by decide
theorem cert_e1205812815758 : check e1205812815758 [[],[]] .smaller = true := by decide
def e1205812815770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812815770 : Closed e1205812815770 ∧ code e1205812815770 = 5603859326874 := by decide
theorem cert_e1205812815770 : check e1205812815770 [[],[]] .smaller = true := by decide
def e1205812815814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1205812815814 : Closed e1205812815814 ∧ code e1205812815814 = 5603859326918 := by decide
theorem cert_e1205812815814 : check e1205812815814 [[],[]] .three = true := by decide
def e1205812815838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e1205812815838 : Closed e1205812815838 ∧ code e1205812815838 = 5603859326942 := by decide
theorem cert_e1205812815838 : check e1205812815838 [[],[]] .three = true := by decide
def e1205812818158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812818158 : Closed e1205812818158 ∧ code e1205812818158 = 5603859329262 := by decide
theorem cert_e1205812818158 : check e1205812818158 [[],[]] .smaller = true := by decide
def e1205812818166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812818166 : Closed e1205812818166 ∧ code e1205812818166 = 5603859329270 := by decide
theorem cert_e1205812818166 : check e1205812818166 [[],[]] .smaller = true := by decide
def e1205812818646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1205812818646 : Closed e1205812818646 ∧ code e1205812818646 = 5603859329750 := by decide
theorem cert_e1205812818646 : check e1205812818646 [[],[]] .smaller = true := by decide
def e1205812818650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1205812818650 : Closed e1205812818650 ∧ code e1205812818650 = 5603859329754 := by decide
theorem cert_e1205812818650 : check e1205812818650 [[],[]] .smaller = true := by decide
def e1205812818666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1205812818666 : Closed e1205812818666 ∧ code e1205812818666 = 5603859329770 := by decide
theorem cert_e1205812818666 : check e1205812818666 [[],[]] .smaller = true := by decide
def e1205812818742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812818742 : Closed e1205812818742 ∧ code e1205812818742 = 5603859329846 := by decide
theorem cert_e1205812818742 : check e1205812818742 [[],[]] .smaller = true := by decide
def e1205812818746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812818746 : Closed e1205812818746 ∧ code e1205812818746 = 5603859329850 := by decide
theorem cert_e1205812818746 : check e1205812818746 [[],[]] .smaller = true := by decide
def e1205812818830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1205812818830 : Closed e1205812818830 ∧ code e1205812818830 = 5603859329934 := by decide
theorem cert_e1205812818830 : check e1205812818830 [[],[]] .smaller = true := by decide
def e1205812818842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812818842 : Closed e1205812818842 ∧ code e1205812818842 = 5603859329946 := by decide
theorem cert_e1205812818842 : check e1205812818842 [[],[]] .smaller = true := by decide
def e1205812818910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e1205812818910 : Closed e1205812818910 ∧ code e1205812818910 = 5603859330014 := by decide
theorem cert_e1205812818910 : check e1205812818910 [[],[]] .three = true := by decide
def e1205812818926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e1205812818926 : Closed e1205812818926 ∧ code e1205812818926 = 5603859330030 := by decide
theorem cert_e1205812818926 : check e1205812818926 [[],[]] .three = true := by decide
def e1205812820366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1205812820366 : Closed e1205812820366 ∧ code e1205812820366 = 5603859331470 := by decide
theorem cert_e1205812820366 : check e1205812820366 [[],[]] .three = true := by decide
def e1205812820422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1205812820422 : Closed e1205812820422 ∧ code e1205812820422 = 5603859331526 := by decide
theorem cert_e1205812820422 : check e1205812820422 [[],[]] .three = true := by decide
def e1205812820446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e1205812820446 : Closed e1205812820446 ∧ code e1205812820446 = 5603859331550 := by decide
theorem cert_e1205812820446 : check e1205812820446 [[],[]] .three = true := by decide
def e1205812820462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205812820462 : Closed e1205812820462 ∧ code e1205812820462 = 5603859331566 := by decide
theorem cert_e1205812820462 : check e1205812820462 [[],[]] .three = true := by decide
def e1205812820470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e1205812820470 : Closed e1205812820470 ∧ code e1205812820470 = 5603859331574 := by decide
theorem cert_e1205812820470 : check e1205812820470 [[],[]] .three = true := by decide
def e1205812823918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1205812823918 : Closed e1205812823918 ∧ code e1205812823918 = 5603859335022 := by decide
theorem cert_e1205812823918 : check e1205812823918 [[],[]] .smaller = true := by decide
def e1205812823930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1205812823930 : Closed e1205812823930 ∧ code e1205812823930 = 5603859335034 := by decide
theorem cert_e1205812823930 : check e1205812823930 [[],[]] .smaller = true := by decide
def e1205812824026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1205812824026 : Closed e1205812824026 ∧ code e1205812824026 = 5603859335130 := by decide
theorem cert_e1205812824026 : check e1205812824026 [[],[]] .smaller = true := by decide
def e1205812825310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e1205812825310 : Closed e1205812825310 ∧ code e1205812825310 = 5603859336414 := by decide
theorem cert_e1205812825310 : check e1205812825310 [[],[]] .three = true := by decide
def e1205812825326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812825326 : Closed e1205812825326 ∧ code e1205812825326 = 5603859336430 := by decide
theorem cert_e1205812825326 : check e1205812825326 [[],[]] .smaller = true := by decide
def e1205812825334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812825334 : Closed e1205812825334 ∧ code e1205812825334 = 5603859336438 := by decide
theorem cert_e1205812825334 : check e1205812825334 [[],[]] .smaller = true := by decide
def e1205812825338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e1205812825338 : Closed e1205812825338 ∧ code e1205812825338 = 5603859336442 := by decide
theorem cert_e1205812825338 : check e1205812825338 [[],[]] .three = true := by decide
def e1205812825710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812825710 : Closed e1205812825710 ∧ code e1205812825710 = 5603859336814 := by decide
theorem cert_e1205812825710 : check e1205812825710 [[],[]] .smaller = true := by decide
def e1205812825722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812825722 : Closed e1205812825722 ∧ code e1205812825722 = 5603859336826 := by decide
theorem cert_e1205812825722 : check e1205812825722 [[],[]] .smaller = true := by decide
def e1205812825910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812825910 : Closed e1205812825910 ∧ code e1205812825910 = 5603859337014 := by decide
theorem cert_e1205812825910 : check e1205812825910 [[],[]] .smaller = true := by decide
def e1205812825914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812825914 : Closed e1205812825914 ∧ code e1205812825914 = 5603859337018 := by decide
theorem cert_e1205812825914 : check e1205812825914 [[],[]] .smaller = true := by decide
def e1205812826010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812826010 : Closed e1205812826010 ∧ code e1205812826010 = 5603859337114 := by decide
theorem cert_e1205812826010 : check e1205812826010 [[],[]] .three = true := by decide
def e1205812827822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1205812827822 : Closed e1205812827822 ∧ code e1205812827822 = 5603859338926 := by decide
theorem cert_e1205812827822 : check e1205812827822 [[],[]] .smaller = true := by decide
def e1205812827834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1205812827834 : Closed e1205812827834 ∧ code e1205812827834 = 5603859338938 := by decide
theorem cert_e1205812827834 : check e1205812827834 [[],[]] .smaller = true := by decide
def e1205812827882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1205812827882 : Closed e1205812827882 ∧ code e1205812827882 = 5603859338986 := by decide
theorem cert_e1205812827882 : check e1205812827882 [[],[]] .smaller = true := by decide
def e1205812828074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1205812828074 : Closed e1205812828074 ∧ code e1205812828074 = 5603859339178 := by decide
theorem cert_e1205812828074 : check e1205812828074 [[],[]] .smaller = true := by decide
def e1205812828382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e1205812828382 : Closed e1205812828382 ∧ code e1205812828382 = 5603859339486 := by decide
theorem cert_e1205812828382 : check e1205812828382 [[],[]] .three = true := by decide
def e1205812828398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205812828398 : Closed e1205812828398 ∧ code e1205812828398 = 5603859339502 := by decide
theorem cert_e1205812828398 : check e1205812828398 [[],[]] .smaller = true := by decide
def e1205812828406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1205812828406 : Closed e1205812828406 ∧ code e1205812828406 = 5603859339510 := by decide
theorem cert_e1205812828406 : check e1205812828406 [[],[]] .smaller = true := by decide
def e1205812828410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205812828410 : Closed e1205812828410 ∧ code e1205812828410 = 5603859339514 := by decide
theorem cert_e1205812828410 : check e1205812828410 [[],[]] .three = true := by decide
def e1205812828590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1205812828590 : Closed e1205812828590 ∧ code e1205812828590 = 5603859339694 := by decide
theorem cert_e1205812828590 : check e1205812828590 [[],[]] .smaller = true := by decide
def e1205812828602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1205812828602 : Closed e1205812828602 ∧ code e1205812828602 = 5603859339706 := by decide
theorem cert_e1205812828602 : check e1205812828602 [[],[]] .smaller = true := by decide
def e1205812828650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1205812828650 : Closed e1205812828650 ∧ code e1205812828650 = 5603859339754 := by decide
theorem cert_e1205812828650 : check e1205812828650 [[],[]] .smaller = true := by decide
def e1205812828734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e1205812828734 : Closed e1205812828734 ∧ code e1205812828734 = 5603859339838 := by decide
theorem cert_e1205812828734 : check e1205812828734 [[],[]] .three = true := by decide
def e1205812828782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812828782 : Closed e1205812828782 ∧ code e1205812828782 = 5603859339886 := by decide
theorem cert_e1205812828782 : check e1205812828782 [[],[]] .smaller = true := by decide
def e1205812828794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812828794 : Closed e1205812828794 ∧ code e1205812828794 = 5603859339898 := by decide
theorem cert_e1205812828794 : check e1205812828794 [[],[]] .smaller = true := by decide
def e1205812828958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205812828958 : Closed e1205812828958 ∧ code e1205812828958 = 5603859340062 := by decide
theorem cert_e1205812828958 : check e1205812828958 [[],[]] .smaller = true := by decide
def e1205812829070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1205812829070 : Closed e1205812829070 ∧ code e1205812829070 = 5603859340174 := by decide
theorem cert_e1205812829070 : check e1205812829070 [[],[]] .smaller = true := by decide
def e1205812829082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812829082 : Closed e1205812829082 ∧ code e1205812829082 = 5603859340186 := by decide
theorem cert_e1205812829082 : check e1205812829082 [[],[]] .smaller = true := by decide
def e1205812829126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205812829126 : Closed e1205812829126 ∧ code e1205812829126 = 5603859340230 := by decide
theorem cert_e1205812829126 : check e1205812829126 [[],[]] .three = true := by decide
def e1205812829150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e1205812829150 : Closed e1205812829150 ∧ code e1205812829150 = 5603859340254 := by decide
theorem cert_e1205812829150 : check e1205812829150 [[],[]] .three = true := by decide
def e1205812829294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1205812829294 : Closed e1205812829294 ∧ code e1205812829294 = 5603859340398 := by decide
theorem cert_e1205812829294 : check e1205812829294 [[],[]] .smaller = true := by decide
def e1205812829306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1205812829306 : Closed e1205812829306 ∧ code e1205812829306 = 5603859340410 := by decide
theorem cert_e1205812829306 : check e1205812829306 [[],[]] .smaller = true := by decide
def e1205812829470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1205812829470 : Closed e1205812829470 ∧ code e1205812829470 = 5603859340574 := by decide
theorem cert_e1205812829470 : check e1205812829470 [[],[]] .smaller = true := by decide
def e1205812829638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1205812829638 : Closed e1205812829638 ∧ code e1205812829638 = 5603859340742 := by decide
theorem cert_e1205812829638 : check e1205812829638 [[],[]] .smaller = true := by decide
def e1205812829662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e1205812829662 : Closed e1205812829662 ∧ code e1205812829662 = 5603859340766 := by decide
theorem cert_e1205812829662 : check e1205812829662 [[],[]] .three = true := by decide
def e1205812829678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e1205812829678 : Closed e1205812829678 ∧ code e1205812829678 = 5603859340782 := by decide
theorem cert_e1205812829678 : check e1205812829678 [[],[]] .three = true := by decide
def e1205812829750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1205812829750 : Closed e1205812829750 ∧ code e1205812829750 = 5603859340854 := by decide
theorem cert_e1205812829750 : check e1205812829750 [[],[]] .smaller = true := by decide
def e1205812829754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205812829754 : Closed e1205812829754 ∧ code e1205812829754 = 5603859340858 := by decide
theorem cert_e1205812829754 : check e1205812829754 [[],[]] .smaller = true := by decide
def e1205812829802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1205812829802 : Closed e1205812829802 ∧ code e1205812829802 = 5603859340906 := by decide
theorem cert_e1205812829802 : check e1205812829802 [[],[]] .smaller = true := by decide
def e1205812829838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1205812829838 : Closed e1205812829838 ∧ code e1205812829838 = 5603859340942 := by decide
theorem cert_e1205812829838 : check e1205812829838 [[],[]] .smaller = true := by decide
def e1205812829850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812829850 : Closed e1205812829850 ∧ code e1205812829850 = 5603859340954 := by decide
theorem cert_e1205812829850 : check e1205812829850 [[],[]] .smaller = true := by decide
def e1205812829894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205812829894 : Closed e1205812829894 ∧ code e1205812829894 = 5603859340998 := by decide
theorem cert_e1205812829894 : check e1205812829894 [[],[]] .smaller = true := by decide
def e1205812829918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e1205812829918 : Closed e1205812829918 ∧ code e1205812829918 = 5603859341022 := by decide
theorem cert_e1205812829918 : check e1205812829918 [[],[]] .three = true := by decide
def e1205812829942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e1205812829942 : Closed e1205812829942 ∧ code e1205812829942 = 5603859341046 := by decide
theorem cert_e1205812829942 : check e1205812829942 [[],[]] .three = true := by decide
def e1205812829978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1205812829978 : Closed e1205812829978 ∧ code e1205812829978 = 5603859341082 := by decide
theorem cert_e1205812829978 : check e1205812829978 [[],[]] .three = true := by decide
def e1205812830022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1205812830022 : Closed e1205812830022 ∧ code e1205812830022 = 5603859341126 := by decide
theorem cert_e1205812830022 : check e1205812830022 [[],[]] .three = true := by decide
def e1205812830046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e1205812830046 : Closed e1205812830046 ∧ code e1205812830046 = 5603859341150 := by decide
theorem cert_e1205812830046 : check e1205812830046 [[],[]] .three = true := by decide
def e1205812830062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e1205812830062 : Closed e1205812830062 ∧ code e1205812830062 = 5603859341166 := by decide
theorem cert_e1205812830062 : check e1205812830062 [[],[]] .three = true := by decide
def e1205812830070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e1205812830070 : Closed e1205812830070 ∧ code e1205812830070 = 5603859341174 := by decide
theorem cert_e1205812830070 : check e1205812830070 [[],[]] .three = true := by decide
def e1205812830074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e1205812830074 : Closed e1205812830074 ∧ code e1205812830074 = 5603859341178 := by decide
theorem cert_e1205812830074 : check e1205812830074 [[],[]] .three = true := by decide
def e1205812830686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1205812830686 : Closed e1205812830686 ∧ code e1205812830686 = 5603859341790 := by decide
theorem cert_e1205812830686 : check e1205812830686 [[],[]] .smaller = true := by decide
def e1205812830710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1205812830710 : Closed e1205812830710 ∧ code e1205812830710 = 5603859341814 := by decide
theorem cert_e1205812830710 : check e1205812830710 [[],[]] .smaller = true := by decide
def e1205812831662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1205812831662 : Closed e1205812831662 ∧ code e1205812831662 = 5603859342766 := by decide
theorem cert_e1205812831662 : check e1205812831662 [[],[]] .smaller = true := by decide
def e1205812831674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1205812831674 : Closed e1205812831674 ∧ code e1205812831674 = 5603859342778 := by decide
theorem cert_e1205812831674 : check e1205812831674 [[],[]] .smaller = true := by decide
def e1205812831722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1205812831722 : Closed e1205812831722 ∧ code e1205812831722 = 5603859342826 := by decide
theorem cert_e1205812831722 : check e1205812831722 [[],[]] .smaller = true := by decide
def e1205812831806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1205812831806 : Closed e1205812831806 ∧ code e1205812831806 = 5603859342910 := by decide
theorem cert_e1205812831806 : check e1205812831806 [[],[]] .three = true := by decide
def e1205812831854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812831854 : Closed e1205812831854 ∧ code e1205812831854 = 5603859342958 := by decide
theorem cert_e1205812831854 : check e1205812831854 [[],[]] .smaller = true := by decide
def e1205812831866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812831866 : Closed e1205812831866 ∧ code e1205812831866 = 5603859342970 := by decide
theorem cert_e1205812831866 : check e1205812831866 [[],[]] .smaller = true := by decide
def e1205812832030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1205812832030 : Closed e1205812832030 ∧ code e1205812832030 = 5603859343134 := by decide
theorem cert_e1205812832030 : check e1205812832030 [[],[]] .smaller = true := by decide
def e1205812832142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1205812832142 : Closed e1205812832142 ∧ code e1205812832142 = 5603859343246 := by decide
theorem cert_e1205812832142 : check e1205812832142 [[],[]] .smaller = true := by decide
def e1205812832154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812832154 : Closed e1205812832154 ∧ code e1205812832154 = 5603859343258 := by decide
theorem cert_e1205812832154 : check e1205812832154 [[],[]] .smaller = true := by decide
def e1205812832198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1205812832198 : Closed e1205812832198 ∧ code e1205812832198 = 5603859343302 := by decide
theorem cert_e1205812832198 : check e1205812832198 [[],[]] .three = true := by decide
def e1205812832222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e1205812832222 : Closed e1205812832222 ∧ code e1205812832222 = 5603859343326 := by decide
theorem cert_e1205812832222 : check e1205812832222 [[],[]] .three = true := by decide
def e1205812835102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1205812835102 : Closed e1205812835102 ∧ code e1205812835102 = 5603859346206 := by decide
theorem cert_e1205812835102 : check e1205812835102 [[],[]] .smaller = true := by decide
def e1205812835270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1205812835270 : Closed e1205812835270 ∧ code e1205812835270 = 5603859346374 := by decide
theorem cert_e1205812835270 : check e1205812835270 [[],[]] .smaller = true := by decide
def e1205812835294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e1205812835294 : Closed e1205812835294 ∧ code e1205812835294 = 5603859346398 := by decide
theorem cert_e1205812835294 : check e1205812835294 [[],[]] .three = true := by decide
def e1205812835310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e1205812835310 : Closed e1205812835310 ∧ code e1205812835310 = 5603859346414 := by decide
theorem cert_e1205812835310 : check e1205812835310 [[],[]] .three = true := by decide
def e1205812836470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1205812836470 : Closed e1205812836470 ∧ code e1205812836470 = 5603859347574 := by decide
theorem cert_e1205812836470 : check e1205812836470 [[],[]] .smaller = true := by decide
def e1205812836714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1205812836714 : Closed e1205812836714 ∧ code e1205812836714 = 5603859347818 := by decide
theorem cert_e1205812836714 : check e1205812836714 [[],[]] .smaller = true := by decide
def e1205812836750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1205812836750 : Closed e1205812836750 ∧ code e1205812836750 = 5603859347854 := by decide
theorem cert_e1205812836750 : check e1205812836750 [[],[]] .smaller = true := by decide
def e1205812836762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812836762 : Closed e1205812836762 ∧ code e1205812836762 = 5603859347866 := by decide
theorem cert_e1205812836762 : check e1205812836762 [[],[]] .smaller = true := by decide
def e1205812836806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1205812836806 : Closed e1205812836806 ∧ code e1205812836806 = 5603859347910 := by decide
theorem cert_e1205812836806 : check e1205812836806 [[],[]] .smaller = true := by decide
def e1205812836830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e1205812836830 : Closed e1205812836830 ∧ code e1205812836830 = 5603859347934 := by decide
theorem cert_e1205812836830 : check e1205812836830 [[],[]] .three = true := by decide
def e1205812836854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e1205812836854 : Closed e1205812836854 ∧ code e1205812836854 = 5603859347958 := by decide
theorem cert_e1205812836854 : check e1205812836854 [[],[]] .three = true := by decide
def e1205812837574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1205812837574 : Closed e1205812837574 ∧ code e1205812837574 = 5603859348678 := by decide
theorem cert_e1205812837574 : check e1205812837574 [[],[]] .three = true := by decide
def e1205812837598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e1205812837598 : Closed e1205812837598 ∧ code e1205812837598 = 5603859348702 := by decide
theorem cert_e1205812837598 : check e1205812837598 [[],[]] .three = true := by decide
def e1205812837614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812837614 : Closed e1205812837614 ∧ code e1205812837614 = 5603859348718 := by decide
theorem cert_e1205812837614 : check e1205812837614 [[],[]] .three = true := by decide
def e1205812837622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812837622 : Closed e1205812837622 ∧ code e1205812837622 = 5603859348726 := by decide
theorem cert_e1205812837622 : check e1205812837622 [[],[]] .three = true := by decide
def e1205812837626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e1205812837626 : Closed e1205812837626 ∧ code e1205812837626 = 5603859348730 := by decide
theorem cert_e1205812837626 : check e1205812837626 [[],[]] .three = true := by decide
def e1205812839350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1205812839350 : Closed e1205812839350 ∧ code e1205812839350 = 5603859350454 := by decide
theorem cert_e1205812839350 : check e1205812839350 [[],[]] .smaller = true := by decide
def e1205812839354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1205812839354 : Closed e1205812839354 ∧ code e1205812839354 = 5603859350458 := by decide
theorem cert_e1205812839354 : check e1205812839354 [[],[]] .smaller = true := by decide
def e1205812839386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1205812839386 : Closed e1205812839386 ∧ code e1205812839386 = 5603859350490 := by decide
theorem cert_e1205812839386 : check e1205812839386 [[],[]] .smaller = true := by decide
def e1205812840054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1205812840054 : Closed e1205812840054 ∧ code e1205812840054 = 5603859351158 := by decide
theorem cert_e1205812840054 : check e1205812840054 [[],[]] .smaller = true := by decide
def e1205812840246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812840246 : Closed e1205812840246 ∧ code e1205812840246 = 5603859351350 := by decide
theorem cert_e1205812840246 : check e1205812840246 [[],[]] .smaller = true := by decide
def e1205812840250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812840250 : Closed e1205812840250 ∧ code e1205812840250 = 5603859351354 := by decide
theorem cert_e1205812840250 : check e1205812840250 [[],[]] .smaller = true := by decide
def e1205812841302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1205812841302 : Closed e1205812841302 ∧ code e1205812841302 = 5603859352406 := by decide
theorem cert_e1205812841302 : check e1205812841302 [[],[]] .smaller = true := by decide
def e1205812841306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1205812841306 : Closed e1205812841306 ∧ code e1205812841306 = 5603859352410 := by decide
theorem cert_e1205812841306 : check e1205812841306 [[],[]] .smaller = true := by decide
def e1205812841322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1205812841322 : Closed e1205812841322 ∧ code e1205812841322 = 5603859352426 := by decide
theorem cert_e1205812841322 : check e1205812841322 [[],[]] .smaller = true := by decide
def e1205812841386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1205812841386 : Closed e1205812841386 ∧ code e1205812841386 = 5603859352490 := by decide
theorem cert_e1205812841386 : check e1205812841386 [[],[]] .smaller = true := by decide
def e1205812841590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205812841590 : Closed e1205812841590 ∧ code e1205812841590 = 5603859352694 := by decide
theorem cert_e1205812841590 : check e1205812841590 [[],[]] .smaller = true := by decide
def e1205812841686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1205812841686 : Closed e1205812841686 ∧ code e1205812841686 = 5603859352790 := by decide
theorem cert_e1205812841686 : check e1205812841686 [[],[]] .smaller = true := by decide
def e1205812841690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1205812841690 : Closed e1205812841690 ∧ code e1205812841690 = 5603859352794 := by decide
theorem cert_e1205812841690 : check e1205812841690 [[],[]] .smaller = true := by decide
def e1205812841706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1205812841706 : Closed e1205812841706 ∧ code e1205812841706 = 5603859352810 := by decide
theorem cert_e1205812841706 : check e1205812841706 [[],[]] .smaller = true := by decide
def e1205812841782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812841782 : Closed e1205812841782 ∧ code e1205812841782 = 5603859352886 := by decide
theorem cert_e1205812841782 : check e1205812841782 [[],[]] .smaller = true := by decide
def e1205812841786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812841786 : Closed e1205812841786 ∧ code e1205812841786 = 5603859352890 := by decide
theorem cert_e1205812841786 : check e1205812841786 [[],[]] .smaller = true := by decide
def e1205812841870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205812841870 : Closed e1205812841870 ∧ code e1205812841870 = 5603859352974 := by decide
theorem cert_e1205812841870 : check e1205812841870 [[],[]] .smaller = true := by decide
def e1205812841882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812841882 : Closed e1205812841882 ∧ code e1205812841882 = 5603859352986 := by decide
theorem cert_e1205812841882 : check e1205812841882 [[],[]] .smaller = true := by decide
def e1205812841950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e1205812841950 : Closed e1205812841950 ∧ code e1205812841950 = 5603859353054 := by decide
theorem cert_e1205812841950 : check e1205812841950 [[],[]] .three = true := by decide
def e1205812841966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e1205812841966 : Closed e1205812841966 ∧ code e1205812841966 = 5603859353070 := by decide
theorem cert_e1205812841966 : check e1205812841966 [[],[]] .three = true := by decide
def e1205812842038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1205812842038 : Closed e1205812842038 ∧ code e1205812842038 = 5603859353142 := by decide
theorem cert_e1205812842038 : check e1205812842038 [[],[]] .smaller = true := by decide
def e1205812842042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205812842042 : Closed e1205812842042 ∧ code e1205812842042 = 5603859353146 := by decide
theorem cert_e1205812842042 : check e1205812842042 [[],[]] .smaller = true := by decide
def e1205812842090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1205812842090 : Closed e1205812842090 ∧ code e1205812842090 = 5603859353194 := by decide
theorem cert_e1205812842090 : check e1205812842090 [[],[]] .smaller = true := by decide
def e1205812842126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1205812842126 : Closed e1205812842126 ∧ code e1205812842126 = 5603859353230 := by decide
theorem cert_e1205812842126 : check e1205812842126 [[],[]] .smaller = true := by decide
end Blc.Floor42
