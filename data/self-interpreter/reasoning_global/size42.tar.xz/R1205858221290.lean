import CodeBridge
import Batch117
namespace Certgen.R1205858221290
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 6,.lam 2,.app 3 4,.var 0,.lam 5,.var 1,.lam 7,.app 8 18,.app 9 10,.var 0,.lam 11,.lam 12,.lam 13,.app 14 15,.var 2,.app 16 17,.var 1,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨6,[]⟩],[⟨10,[2]⟩],[⟨4,[0]⟩,⟨18,[2]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨6,[]⟩,0⟩],[⟨⟨4,[0]⟩,0⟩],[⟨⟨18,[2]⟩,0⟩],[⟨⟨10,[2]⟩,3⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,2⟩,⟨⟨4,[0]⟩,4⟩,⟨⟨5,[1,0]⟩,3⟩,⟨⟨6,[]⟩,2⟩,⟨⟨6,[]⟩,3⟩,⟨⟨7,[2]⟩,0⟩,⟨⟨8,[2]⟩,3⟩,⟨⟨9,[2]⟩,4⟩,⟨⟨18,[2]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[6],[5],[7],[8],[8],[9],[10],[4,11],[4,11]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<12 := hi
 exact range_sound block0 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor42 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit18 : Term := .var 0
def lit16 : Term := .var 1
def lit14 : Term := .var 2
def lit4 : Term := .lam lit16
def lit15 : Term := .app lit16 lit18
def lit2 : Term := .app lit18 lit4
def lit1 : Term := .lam lit2
def lit13 : Term := .app lit14 lit15
def lit12 : Term := .lam lit13
def lit11 : Term := .lam lit12
def lit10 : Term := .lam lit11
def lit8 : Term := .app lit18 lit10
def lit7 : Term := .app lit8 lit18
def lit6 : Term := .lam lit7
def lit0 : Term := .app lit1 lit6
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 0 (by rfl)
theorem sub17 : model.term 17 = lit18 := model.var_eq 17 0 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 1 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := model.var_eq 14 2 (by rfl)
theorem sub13 : model.term 13 = lit13 := by rw [model.app_eq 13 14 15 (by rfl), sub14, sub15]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit18 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.app_eq 7 8 18 (by rfl), sub8, sub18]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit16 := model.var_eq 5 1 (by rfl)
theorem sub4 : model.term 4 = lit4 := by rw [model.lam_eq 4 5 (by rfl), sub5]; rfl
theorem sub3 : model.term 3 = lit18 := model.var_eq 3 0 (by rfl)
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 4 (by rfl), sub3, sub4]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 6 (by rfl), sub1, sub6]; rfl
theorem excluded : ¬ IsSelfInterpreter e1205858221290 := by
 intro he
 have hp : replay [] e1205858221290 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R1205858221290
