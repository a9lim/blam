import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211281857310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211281857310 : Closed e1211281857310 ∧ code e1211281857310 = 5609328368414 := by decide
theorem cert_e1211281857310 : check e1211281857310 [[],[]] .smaller = true := by decide
def e1211281857422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211281857422 : Closed e1211281857422 ∧ code e1211281857422 = 5609328368526 := by decide
theorem cert_e1211281857422 : check e1211281857422 [[],[]] .smaller = true := by decide
def e1211281857646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211281857646 : Closed e1211281857646 ∧ code e1211281857646 = 5609328368750 := by decide
theorem cert_e1211281857646 : check e1211281857646 [[],[]] .smaller = true := by decide
def e1211281857658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211281857658 : Closed e1211281857658 ∧ code e1211281857658 = 5609328368762 := by decide
theorem cert_e1211281857658 : check e1211281857658 [[],[]] .smaller = true := by decide
def e1211281857822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211281857822 : Closed e1211281857822 ∧ code e1211281857822 = 5609328368926 := by decide
theorem cert_e1211281857822 : check e1211281857822 [[],[]] .smaller = true := by decide
def e1211281857990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211281857990 : Closed e1211281857990 ∧ code e1211281857990 = 5609328369094 := by decide
theorem cert_e1211281857990 : check e1211281857990 [[],[]] .smaller = true := by decide
def e1211281858014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211281858014 : Closed e1211281858014 ∧ code e1211281858014 = 5609328369118 := by decide
theorem cert_e1211281858014 : check e1211281858014 [[],[]] .chain = true := by decide
def e1211281858030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211281858030 : Closed e1211281858030 ∧ code e1211281858030 = 5609328369134 := by decide
theorem cert_e1211281858030 : check e1211281858030 [[],[]] .chain = true := by decide
def e1211281858102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211281858102 : Closed e1211281858102 ∧ code e1211281858102 = 5609328369206 := by decide
theorem cert_e1211281858102 : check e1211281858102 [[],[]] .smaller = true := by decide
def e1211281858106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211281858106 : Closed e1211281858106 ∧ code e1211281858106 = 5609328369210 := by decide
theorem cert_e1211281858106 : check e1211281858106 [[],[]] .smaller = true := by decide
def e1211281858190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211281858190 : Closed e1211281858190 ∧ code e1211281858190 = 5609328369294 := by decide
theorem cert_e1211281858190 : check e1211281858190 [[],[]] .smaller = true := by decide
def e1211281858246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211281858246 : Closed e1211281858246 ∧ code e1211281858246 = 5609328369350 := by decide
theorem cert_e1211281858246 : check e1211281858246 [[],[]] .smaller = true := by decide
def e1211281858270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211281858270 : Closed e1211281858270 ∧ code e1211281858270 = 5609328369374 := by decide
theorem cert_e1211281858270 : check e1211281858270 [[],[]] .chain = true := by decide
def e1211281858294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211281858294 : Closed e1211281858294 ∧ code e1211281858294 = 5609328369398 := by decide
theorem cert_e1211281858294 : check e1211281858294 [[],[]] .chain = true := by decide
def e1211281858414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211281858414 : Closed e1211281858414 ∧ code e1211281858414 = 5609328369518 := by decide
theorem cert_e1211281858414 : check e1211281858414 [[],[]] .chain = true := by decide
def e1211281858422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211281858422 : Closed e1211281858422 ∧ code e1211281858422 = 5609328369526 := by decide
theorem cert_e1211281858422 : check e1211281858422 [[],[]] .chain = true := by decide
def e1211281860382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211281860382 : Closed e1211281860382 ∧ code e1211281860382 = 5609328371486 := by decide
theorem cert_e1211281860382 : check e1211281860382 [[],[]] .smaller = true := by decide
def e1211281860494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211281860494 : Closed e1211281860494 ∧ code e1211281860494 = 5609328371598 := by decide
theorem cert_e1211281860494 : check e1211281860494 [[],[]] .smaller = true := by decide
def e1211281862878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211281862878 : Closed e1211281862878 ∧ code e1211281862878 = 5609328373982 := by decide
theorem cert_e1211281862878 : check e1211281862878 [[],[]] .smaller = true := by decide
def e1211281862906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211281862906 : Closed e1211281862906 ∧ code e1211281862906 = 5609328374010 := by decide
theorem cert_e1211281862906 : check e1211281862906 [[],[]] .smaller = true := by decide
def e1211281863454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211281863454 : Closed e1211281863454 ∧ code e1211281863454 = 5609328374558 := by decide
theorem cert_e1211281863454 : check e1211281863454 [[],[]] .smaller = true := by decide
def e1211281863622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211281863622 : Closed e1211281863622 ∧ code e1211281863622 = 5609328374726 := by decide
theorem cert_e1211281863622 : check e1211281863622 [[],[]] .smaller = true := by decide
def e1211281863646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211281863646 : Closed e1211281863646 ∧ code e1211281863646 = 5609328374750 := by decide
theorem cert_e1211281863646 : check e1211281863646 [[],[]] .chain = true := by decide
def e1211281863662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211281863662 : Closed e1211281863662 ∧ code e1211281863662 = 5609328374766 := by decide
theorem cert_e1211281863662 : check e1211281863662 [[],[]] .chain = true := by decide
def e1211281864814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211281864814 : Closed e1211281864814 ∧ code e1211281864814 = 5609328375918 := by decide
theorem cert_e1211281864814 : check e1211281864814 [[],[]] .smaller = true := by decide
def e1211281864826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211281864826 : Closed e1211281864826 ∧ code e1211281864826 = 5609328375930 := by decide
theorem cert_e1211281864826 : check e1211281864826 [[],[]] .smaller = true := by decide
def e1211281865102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211281865102 : Closed e1211281865102 ∧ code e1211281865102 = 5609328376206 := by decide
theorem cert_e1211281865102 : check e1211281865102 [[],[]] .smaller = true := by decide
def e1211281865158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211281865158 : Closed e1211281865158 ∧ code e1211281865158 = 5609328376262 := by decide
theorem cert_e1211281865158 : check e1211281865158 [[],[]] .smaller = true := by decide
def e1211281865182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211281865182 : Closed e1211281865182 ∧ code e1211281865182 = 5609328376286 := by decide
theorem cert_e1211281865182 : check e1211281865182 [[],[]] .chain = true := by decide
def e1211281865206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211281865206 : Closed e1211281865206 ∧ code e1211281865206 = 5609328376310 := by decide
theorem cert_e1211281865206 : check e1211281865206 [[],[]] .chain = true := by decide
def e1211281865966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211281865966 : Closed e1211281865966 ∧ code e1211281865966 = 5609328377070 := by decide
theorem cert_e1211281865966 : check e1211281865966 [[],[]] .chain = true := by decide
def e1211281865974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211281865974 : Closed e1211281865974 ∧ code e1211281865974 = 5609328377078 := by decide
theorem cert_e1211281865974 : check e1211281865974 [[],[]] .chain = true := by decide
def e1211281902446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211281902446 : Closed e1211281902446 ∧ code e1211281902446 = 5609328413550 := by decide
theorem cert_e1211281902446 : check e1211281902446 [[],[]] .smaller = true := by decide
def e1211281902454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211281902454 : Closed e1211281902454 ∧ code e1211281902454 = 5609328413558 := by decide
theorem cert_e1211281902454 : check e1211281902454 [[],[]] .smaller = true := by decide
def e1211281902510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211281902510 : Closed e1211281902510 ∧ code e1211281902510 = 5609328413614 := by decide
theorem cert_e1211281902510 : check e1211281902510 [[],[]] .smaller = true := by decide
def e1211281902522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211281902522 : Closed e1211281902522 ∧ code e1211281902522 = 5609328413626 := by decide
theorem cert_e1211281902522 : check e1211281902522 [[],[]] .smaller = true := by decide
def e1211281902550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211281902550 : Closed e1211281902550 ∧ code e1211281902550 = 5609328413654 := by decide
theorem cert_e1211281902550 : check e1211281902550 [[],[]] .smaller = true := by decide
def e1211281902554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211281902554 : Closed e1211281902554 ∧ code e1211281902554 = 5609328413658 := by decide
theorem cert_e1211281902554 : check e1211281902554 [[],[]] .smaller = true := by decide
def e1211281902830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211281902830 : Closed e1211281902830 ∧ code e1211281902830 = 5609328413934 := by decide
theorem cert_e1211281902830 : check e1211281902830 [[],[]] .smaller = true := by decide
def e1211281902838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211281902838 : Closed e1211281902838 ∧ code e1211281902838 = 5609328413942 := by decide
theorem cert_e1211281902838 : check e1211281902838 [[],[]] .smaller = true := by decide
def e1211281903166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211281903166 : Closed e1211281903166 ∧ code e1211281903166 = 5609328414270 := by decide
theorem cert_e1211281903166 : check e1211281903166 [[],[]] .smaller = true := by decide
def e1211281903214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211281903214 : Closed e1211281903214 ∧ code e1211281903214 = 5609328414318 := by decide
theorem cert_e1211281903214 : check e1211281903214 [[],[]] .smaller = true := by decide
def e1211281903226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211281903226 : Closed e1211281903226 ∧ code e1211281903226 = 5609328414330 := by decide
theorem cert_e1211281903226 : check e1211281903226 [[],[]] .smaller = true := by decide
def e1211281903414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281903414 : Closed e1211281903414 ∧ code e1211281903414 = 5609328414518 := by decide
theorem cert_e1211281903414 : check e1211281903414 [[],[]] .smaller = true := by decide
def e1211281903418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281903418 : Closed e1211281903418 ∧ code e1211281903418 = 5609328414522 := by decide
theorem cert_e1211281903418 : check e1211281903418 [[],[]] .smaller = true := by decide
def e1211281903502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211281903502 : Closed e1211281903502 ∧ code e1211281903502 = 5609328414606 := by decide
theorem cert_e1211281903502 : check e1211281903502 [[],[]] .smaller = true := by decide
def e1211281903550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211281903550 : Closed e1211281903550 ∧ code e1211281903550 = 5609328414654 := by decide
theorem cert_e1211281903550 : check e1211281903550 [[],[]] .chain = true := by decide
def e1211281903582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211281903582 : Closed e1211281903582 ∧ code e1211281903582 = 5609328414686 := by decide
theorem cert_e1211281903582 : check e1211281903582 [[],[]] .chain = true := by decide
def e1211281910894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211281910894 : Closed e1211281910894 ∧ code e1211281910894 = 5609328421998 := by decide
theorem cert_e1211281910894 : check e1211281910894 [[],[]] .smaller = true := by decide
def e1211281910906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211281910906 : Closed e1211281910906 ∧ code e1211281910906 = 5609328422010 := by decide
theorem cert_e1211281910906 : check e1211281910906 [[],[]] .smaller = true := by decide
def e1211281911070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211281911070 : Closed e1211281911070 ∧ code e1211281911070 = 5609328422174 := by decide
theorem cert_e1211281911070 : check e1211281911070 [[],[]] .smaller = true := by decide
def e1211281911238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211281911238 : Closed e1211281911238 ∧ code e1211281911238 = 5609328422342 := by decide
theorem cert_e1211281911238 : check e1211281911238 [[],[]] .smaller = true := by decide
def e1211281911262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211281911262 : Closed e1211281911262 ∧ code e1211281911262 = 5609328422366 := by decide
theorem cert_e1211281911262 : check e1211281911262 [[],[]] .chain = true := by decide
def e1211281911278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211281911278 : Closed e1211281911278 ∧ code e1211281911278 = 5609328422382 := by decide
theorem cert_e1211281911278 : check e1211281911278 [[],[]] .chain = true := by decide
def e1211281911578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211281911578 : Closed e1211281911578 ∧ code e1211281911578 = 5609328422682 := by decide
theorem cert_e1211281911578 : check e1211281911578 [[],[]] .smaller = true := by decide
def e1211281911622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211281911622 : Closed e1211281911622 ∧ code e1211281911622 = 5609328422726 := by decide
theorem cert_e1211281911622 : check e1211281911622 [[],[]] .smaller = true := by decide
def e1211281911646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211281911646 : Closed e1211281911646 ∧ code e1211281911646 = 5609328422750 := by decide
theorem cert_e1211281911646 : check e1211281911646 [[],[]] .chain = true := by decide
def e1211281911674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211281911674 : Closed e1211281911674 ∧ code e1211281911674 = 5609328422778 := by decide
theorem cert_e1211281911674 : check e1211281911674 [[],[]] .chain = true := by decide
def e1211281911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211281911726 : Closed e1211281911726 ∧ code e1211281911726 = 5609328422830 := by decide
theorem cert_e1211281911726 : check e1211281911726 [[],[]] .chain = true := by decide
def e1211281911738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211281911738 : Closed e1211281911738 ∧ code e1211281911738 = 5609328422842 := by decide
theorem cert_e1211281911738 : check e1211281911738 [[],[]] .chain = true := by decide
def e1211281912030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211281912030 : Closed e1211281912030 ∧ code e1211281912030 = 5609328423134 := by decide
theorem cert_e1211281912030 : check e1211281912030 [[],[]] .smaller = true := by decide
def e1211281912058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211281912058 : Closed e1211281912058 ∧ code e1211281912058 = 5609328423162 := by decide
theorem cert_e1211281912058 : check e1211281912058 [[],[]] .smaller = true := by decide
def e1211281912606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211281912606 : Closed e1211281912606 ∧ code e1211281912606 = 5609328423710 := by decide
theorem cert_e1211281912606 : check e1211281912606 [[],[]] .smaller = true := by decide
def e1211281912774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211281912774 : Closed e1211281912774 ∧ code e1211281912774 = 5609328423878 := by decide
theorem cert_e1211281912774 : check e1211281912774 [[],[]] .smaller = true := by decide
def e1211281912798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211281912798 : Closed e1211281912798 ∧ code e1211281912798 = 5609328423902 := by decide
theorem cert_e1211281912798 : check e1211281912798 [[],[]] .chain = true := by decide
def e1211281912814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211281912814 : Closed e1211281912814 ∧ code e1211281912814 = 5609328423918 := by decide
theorem cert_e1211281912814 : check e1211281912814 [[],[]] .chain = true := by decide
def e1211281914934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281914934 : Closed e1211281914934 ∧ code e1211281914934 = 5609328426038 := by decide
theorem cert_e1211281914934 : check e1211281914934 [[],[]] .smaller = true := by decide
def e1211281914938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281914938 : Closed e1211281914938 ∧ code e1211281914938 = 5609328426042 := by decide
theorem cert_e1211281914938 : check e1211281914938 [[],[]] .smaller = true := by decide
def e1211281915078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211281915078 : Closed e1211281915078 ∧ code e1211281915078 = 5609328426182 := by decide
theorem cert_e1211281915078 : check e1211281915078 [[],[]] .smaller = true := by decide
def e1211281915102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281915102 : Closed e1211281915102 ∧ code e1211281915102 = 5609328426206 := by decide
theorem cert_e1211281915102 : check e1211281915102 [[],[]] .chain = true := by decide
def e1211281915130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281915130 : Closed e1211281915130 ∧ code e1211281915130 = 5609328426234 := by decide
theorem cert_e1211281915130 : check e1211281915130 [[],[]] .chain = true := by decide
def e1211281915502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211281915502 : Closed e1211281915502 ∧ code e1211281915502 = 5609328426606 := by decide
theorem cert_e1211281915502 : check e1211281915502 [[],[]] .chain = true := by decide
def e1211281915514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211281915514 : Closed e1211281915514 ∧ code e1211281915514 = 5609328426618 := by decide
theorem cert_e1211281915514 : check e1211281915514 [[],[]] .chain = true := by decide
def e1211281934110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211281934110 : Closed e1211281934110 ∧ code e1211281934110 = 5609328445214 := by decide
theorem cert_e1211281934110 : check e1211281934110 [[],[]] .smaller = true := by decide
def e1211281934222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211281934222 : Closed e1211281934222 ∧ code e1211281934222 = 5609328445326 := by decide
theorem cert_e1211281934222 : check e1211281934222 [[],[]] .smaller = true := by decide
def e1211281934270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211281934270 : Closed e1211281934270 ∧ code e1211281934270 = 5609328445374 := by decide
theorem cert_e1211281934270 : check e1211281934270 [[],[]] .chain = true := by decide
def e1211281934318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211281934318 : Closed e1211281934318 ∧ code e1211281934318 = 5609328445422 := by decide
theorem cert_e1211281934318 : check e1211281934318 [[],[]] .chain = true := by decide
def e1211281937974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211281937974 : Closed e1211281937974 ∧ code e1211281937974 = 5609328449078 := by decide
theorem cert_e1211281937974 : check e1211281937974 [[],[]] .smaller = true := by decide
def e1211281937978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211281937978 : Closed e1211281937978 ∧ code e1211281937978 = 5609328449082 := by decide
theorem cert_e1211281937978 : check e1211281937978 [[],[]] .smaller = true := by decide
def e1211281938062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211281938062 : Closed e1211281938062 ∧ code e1211281938062 = 5609328449166 := by decide
theorem cert_e1211281938062 : check e1211281938062 [[],[]] .smaller = true := by decide
def e1211281938118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211281938118 : Closed e1211281938118 ∧ code e1211281938118 = 5609328449222 := by decide
theorem cert_e1211281938118 : check e1211281938118 [[],[]] .smaller = true := by decide
def e1211281938142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211281938142 : Closed e1211281938142 ∧ code e1211281938142 = 5609328449246 := by decide
theorem cert_e1211281938142 : check e1211281938142 [[],[]] .chain = true := by decide
def e1211281938166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211281938166 : Closed e1211281938166 ∧ code e1211281938166 = 5609328449270 := by decide
theorem cert_e1211281938166 : check e1211281938166 [[],[]] .chain = true := by decide
def e1211281938202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211281938202 : Closed e1211281938202 ∧ code e1211281938202 = 5609328449306 := by decide
theorem cert_e1211281938202 : check e1211281938202 [[],[]] .smaller = true := by decide
def e1211281938246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211281938246 : Closed e1211281938246 ∧ code e1211281938246 = 5609328449350 := by decide
theorem cert_e1211281938246 : check e1211281938246 [[],[]] .smaller = true := by decide
def e1211281938270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211281938270 : Closed e1211281938270 ∧ code e1211281938270 = 5609328449374 := by decide
theorem cert_e1211281938270 : check e1211281938270 [[],[]] .chain = true := by decide
def e1211281938298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211281938298 : Closed e1211281938298 ∧ code e1211281938298 = 5609328449402 := by decide
theorem cert_e1211281938298 : check e1211281938298 [[],[]] .chain = true := by decide
def e1211281938390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211281938390 : Closed e1211281938390 ∧ code e1211281938390 = 5609328449494 := by decide
theorem cert_e1211281938390 : check e1211281938390 [[],[]] .chain = true := by decide
def e1211281938394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211281938394 : Closed e1211281938394 ∧ code e1211281938394 = 5609328449498 := by decide
theorem cert_e1211281938394 : check e1211281938394 [[],[]] .chain = true := by decide
def e1211281938542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211281938542 : Closed e1211281938542 ∧ code e1211281938542 = 5609328449646 := by decide
theorem cert_e1211281938542 : check e1211281938542 [[],[]] .smaller = true := by decide
def e1211281938554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211281938554 : Closed e1211281938554 ∧ code e1211281938554 = 5609328449658 := by decide
theorem cert_e1211281938554 : check e1211281938554 [[],[]] .smaller = true := by decide
def e1211281938830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211281938830 : Closed e1211281938830 ∧ code e1211281938830 = 5609328449934 := by decide
theorem cert_e1211281938830 : check e1211281938830 [[],[]] .smaller = true := by decide
def e1211281938886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211281938886 : Closed e1211281938886 ∧ code e1211281938886 = 5609328449990 := by decide
theorem cert_e1211281938886 : check e1211281938886 [[],[]] .smaller = true := by decide
def e1211281938910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211281938910 : Closed e1211281938910 ∧ code e1211281938910 = 5609328450014 := by decide
theorem cert_e1211281938910 : check e1211281938910 [[],[]] .chain = true := by decide
def e1211281938934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211281938934 : Closed e1211281938934 ∧ code e1211281938934 = 5609328450038 := by decide
theorem cert_e1211281938934 : check e1211281938934 [[],[]] .chain = true := by decide
def e1211281939510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281939510 : Closed e1211281939510 ∧ code e1211281939510 = 5609328450614 := by decide
theorem cert_e1211281939510 : check e1211281939510 [[],[]] .smaller = true := by decide
def e1211281939514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281939514 : Closed e1211281939514 ∧ code e1211281939514 = 5609328450618 := by decide
theorem cert_e1211281939514 : check e1211281939514 [[],[]] .smaller = true := by decide
def e1211281939654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211281939654 : Closed e1211281939654 ∧ code e1211281939654 = 5609328450758 := by decide
theorem cert_e1211281939654 : check e1211281939654 [[],[]] .smaller = true := by decide
def e1211281939678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281939678 : Closed e1211281939678 ∧ code e1211281939678 = 5609328450782 := by decide
theorem cert_e1211281939678 : check e1211281939678 [[],[]] .chain = true := by decide
def e1211281939706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281939706 : Closed e1211281939706 ∧ code e1211281939706 = 5609328450810 := by decide
theorem cert_e1211281939706 : check e1211281939706 [[],[]] .chain = true := by decide
def e1211281940278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281940278 : Closed e1211281940278 ∧ code e1211281940278 = 5609328451382 := by decide
theorem cert_e1211281940278 : check e1211281940278 [[],[]] .chain = true := by decide
def e1211281940282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281940282 : Closed e1211281940282 ∧ code e1211281940282 = 5609328451386 := by decide
theorem cert_e1211281940282 : check e1211281940282 [[],[]] .chain = true := by decide
def e1211281949662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211281949662 : Closed e1211281949662 ∧ code e1211281949662 = 5609328460766 := by decide
theorem cert_e1211281949662 : check e1211281949662 [[],[]] .chain = true := by decide
def e1211281949678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211281949678 : Closed e1211281949678 ∧ code e1211281949678 = 5609328460782 := by decide
theorem cert_e1211281949678 : check e1211281949678 [[],[]] .chain = true := by decide
def e1211281951598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211281951598 : Closed e1211281951598 ∧ code e1211281951598 = 5609328462702 := by decide
theorem cert_e1211281951598 : check e1211281951598 [[],[]] .chain = true := by decide
def e1211281951606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211281951606 : Closed e1211281951606 ∧ code e1211281951606 = 5609328462710 := by decide
theorem cert_e1211281951606 : check e1211281951606 [[],[]] .chain = true := by decide
def e1211281951662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211281951662 : Closed e1211281951662 ∧ code e1211281951662 = 5609328462766 := by decide
theorem cert_e1211281951662 : check e1211281951662 [[],[]] .chain = true := by decide
def e1211281951674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211281951674 : Closed e1211281951674 ∧ code e1211281951674 = 5609328462778 := by decide
theorem cert_e1211281951674 : check e1211281951674 [[],[]] .chain = true := by decide
def e1211281951702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211281951702 : Closed e1211281951702 ∧ code e1211281951702 = 5609328462806 := by decide
theorem cert_e1211281951702 : check e1211281951702 [[],[]] .chain = true := by decide
def e1211281951706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211281951706 : Closed e1211281951706 ∧ code e1211281951706 = 5609328462810 := by decide
theorem cert_e1211281951706 : check e1211281951706 [[],[]] .chain = true := by decide
def e1211281951982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211281951982 : Closed e1211281951982 ∧ code e1211281951982 = 5609328463086 := by decide
theorem cert_e1211281951982 : check e1211281951982 [[],[]] .chain = true := by decide
def e1211281951990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211281951990 : Closed e1211281951990 ∧ code e1211281951990 = 5609328463094 := by decide
theorem cert_e1211281951990 : check e1211281951990 [[],[]] .chain = true := by decide
def e1211281952366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211281952366 : Closed e1211281952366 ∧ code e1211281952366 = 5609328463470 := by decide
theorem cert_e1211281952366 : check e1211281952366 [[],[]] .chain = true := by decide
def e1211281952378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211281952378 : Closed e1211281952378 ∧ code e1211281952378 = 5609328463482 := by decide
theorem cert_e1211281952378 : check e1211281952378 [[],[]] .chain = true := by decide
def e1211281952566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281952566 : Closed e1211281952566 ∧ code e1211281952566 = 5609328463670 := by decide
theorem cert_e1211281952566 : check e1211281952566 [[],[]] .chain = true := by decide
def e1211281952570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281952570 : Closed e1211281952570 ∧ code e1211281952570 = 5609328463674 := by decide
theorem cert_e1211281952570 : check e1211281952570 [[],[]] .chain = true := by decide
def e1211282844526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211282844526 : Closed e1211282844526 ∧ code e1211282844526 = 5609329355630 := by decide
theorem cert_e1211282844526 : check e1211282844526 [[],[]] .chain = true := by decide
def e1211282844534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211282844534 : Closed e1211282844534 ∧ code e1211282844534 = 5609329355638 := by decide
theorem cert_e1211282844534 : check e1211282844534 [[],[]] .chain = true := by decide
def e1211282844598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211282844598 : Closed e1211282844598 ∧ code e1211282844598 = 5609329355702 := by decide
theorem cert_e1211282844598 : check e1211282844598 [[],[]] .chain = true := by decide
def e1211282845038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211282845038 : Closed e1211282845038 ∧ code e1211282845038 = 5609329356142 := by decide
theorem cert_e1211282845038 : check e1211282845038 [[],[]] .chain = true := by decide
def e1211282845046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211282845046 : Closed e1211282845046 ∧ code e1211282845046 = 5609329356150 := by decide
theorem cert_e1211282845046 : check e1211282845046 [[],[]] .chain = true := by decide
def e1211282845102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211282845102 : Closed e1211282845102 ∧ code e1211282845102 = 5609329356206 := by decide
theorem cert_e1211282845102 : check e1211282845102 [[],[]] .chain = true := by decide
def e1211282845114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211282845114 : Closed e1211282845114 ∧ code e1211282845114 = 5609329356218 := by decide
theorem cert_e1211282845114 : check e1211282845114 [[],[]] .chain = true := by decide
def e1211282845142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211282845142 : Closed e1211282845142 ∧ code e1211282845142 = 5609329356246 := by decide
theorem cert_e1211282845142 : check e1211282845142 [[],[]] .chain = true := by decide
def e1211282845146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211282845146 : Closed e1211282845146 ∧ code e1211282845146 = 5609329356250 := by decide
theorem cert_e1211282845146 : check e1211282845146 [[],[]] .chain = true := by decide
def e1211282845366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211282845366 : Closed e1211282845366 ∧ code e1211282845366 = 5609329356470 := by decide
theorem cert_e1211282845366 : check e1211282845366 [[],[]] .chain = true := by decide
def e1211282845398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211282845398 : Closed e1211282845398 ∧ code e1211282845398 = 5609329356502 := by decide
theorem cert_e1211282845398 : check e1211282845398 [[],[]] .chain = true := by decide
def e1211282845402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211282845402 : Closed e1211282845402 ∧ code e1211282845402 = 5609329356506 := by decide
theorem cert_e1211282845402 : check e1211282845402 [[],[]] .chain = true := by decide
def e1211282847086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211282847086 : Closed e1211282847086 ∧ code e1211282847086 = 5609329358190 := by decide
theorem cert_e1211282847086 : check e1211282847086 [[],[]] .chain = true := by decide
def e1211282847094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211282847094 : Closed e1211282847094 ∧ code e1211282847094 = 5609329358198 := by decide
theorem cert_e1211282847094 : check e1211282847094 [[],[]] .chain = true := by decide
def e1211282847150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211282847150 : Closed e1211282847150 ∧ code e1211282847150 = 5609329358254 := by decide
theorem cert_e1211282847150 : check e1211282847150 [[],[]] .chain = true := by decide
def e1211282847162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211282847162 : Closed e1211282847162 ∧ code e1211282847162 = 5609329358266 := by decide
theorem cert_e1211282847162 : check e1211282847162 [[],[]] .chain = true := by decide
def e1211282847190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211282847190 : Closed e1211282847190 ∧ code e1211282847190 = 5609329358294 := by decide
theorem cert_e1211282847190 : check e1211282847190 [[],[]] .chain = true := by decide
def e1211282847194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211282847194 : Closed e1211282847194 ∧ code e1211282847194 = 5609329358298 := by decide
theorem cert_e1211282847194 : check e1211282847194 [[],[]] .chain = true := by decide
def e1211282847406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211282847406 : Closed e1211282847406 ∧ code e1211282847406 = 5609329358510 := by decide
theorem cert_e1211282847406 : check e1211282847406 [[],[]] .chain = true := by decide
def e1211282847418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211282847418 : Closed e1211282847418 ∧ code e1211282847418 = 5609329358522 := by decide
theorem cert_e1211282847418 : check e1211282847418 [[],[]] .chain = true := by decide
def e1211282847466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211282847466 : Closed e1211282847466 ∧ code e1211282847466 = 5609329358570 := by decide
theorem cert_e1211282847466 : check e1211282847466 [[],[]] .chain = true := by decide
def e1211282847574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211282847574 : Closed e1211282847574 ∧ code e1211282847574 = 5609329358678 := by decide
theorem cert_e1211282847574 : check e1211282847574 [[],[]] .chain = true := by decide
def e1211282847578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211282847578 : Closed e1211282847578 ∧ code e1211282847578 = 5609329358682 := by decide
theorem cert_e1211282847578 : check e1211282847578 [[],[]] .chain = true := by decide
def e1211282847594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211282847594 : Closed e1211282847594 ∧ code e1211282847594 = 5609329358698 := by decide
theorem cert_e1211282847594 : check e1211282847594 [[],[]] .chain = true := by decide
def e1211282848438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211282848438 : Closed e1211282848438 ∧ code e1211282848438 = 5609329359542 := by decide
theorem cert_e1211282848438 : check e1211282848438 [[],[]] .chain = true := by decide
def e1211282848470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211282848470 : Closed e1211282848470 ∧ code e1211282848470 = 5609329359574 := by decide
theorem cert_e1211282848470 : check e1211282848470 [[],[]] .chain = true := by decide
def e1211282848474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211282848474 : Closed e1211282848474 ∧ code e1211282848474 = 5609329359578 := by decide
theorem cert_e1211282848474 : check e1211282848474 [[],[]] .chain = true := by decide
def e1211282848598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211282848598 : Closed e1211282848598 ∧ code e1211282848598 = 5609329359702 := by decide
theorem cert_e1211282848598 : check e1211282848598 [[],[]] .chain = true := by decide
def e1211282848602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211282848602 : Closed e1211282848602 ∧ code e1211282848602 = 5609329359706 := by decide
theorem cert_e1211282848602 : check e1211282848602 [[],[]] .chain = true := by decide
def e1211282848618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211282848618 : Closed e1211282848618 ∧ code e1211282848618 = 5609329359722 := by decide
theorem cert_e1211282848618 : check e1211282848618 [[],[]] .chain = true := by decide
def e1211282850670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e1211282850670 : Closed e1211282850670 ∧ code e1211282850670 = 5609329361774 := by decide
theorem cert_e1211282850670 : check e1211282850670 [[],[]] .chain = true := by decide
def e1211282850678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e1211282850678 : Closed e1211282850678 ∧ code e1211282850678 = 5609329361782 := by decide
theorem cert_e1211282850678 : check e1211282850678 [[],[]] .chain = true := by decide
def e1211282852078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211282852078 : Closed e1211282852078 ∧ code e1211282852078 = 5609329363182 := by decide
theorem cert_e1211282852078 : check e1211282852078 [[],[]] .chain = true := by decide
def e1211282852086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211282852086 : Closed e1211282852086 ∧ code e1211282852086 = 5609329363190 := by decide
theorem cert_e1211282852086 : check e1211282852086 [[],[]] .chain = true := by decide
def e1211282852638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211282852638 : Closed e1211282852638 ∧ code e1211282852638 = 5609329363742 := by decide
theorem cert_e1211282852638 : check e1211282852638 [[],[]] .chain = true := by decide
def e1211282852750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211282852750 : Closed e1211282852750 ∧ code e1211282852750 = 5609329363854 := by decide
theorem cert_e1211282852750 : check e1211282852750 [[],[]] .chain = true := by decide
def e1211282853422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211282853422 : Closed e1211282853422 ∧ code e1211282853422 = 5609329364526 := by decide
theorem cert_e1211282853422 : check e1211282853422 [[],[]] .chain = true := by decide
def e1211282853602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211282853602 : Closed e1211282853602 ∧ code e1211282853602 = 5609329364706 := by decide
theorem cert_e1211282853602 : check e1211282853602 [[],[]] .chain = true := by decide
def e1211282853614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e1211282853614 : Closed e1211282853614 ∧ code e1211282853614 = 5609329364718 := by decide
theorem cert_e1211282853614 : check e1211282853614 [[],[]] .sourceHead = true := by decide
def e1211282853654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211282853654 : Closed e1211282853654 ∧ code e1211282853654 = 5609329364758 := by decide
theorem cert_e1211282853654 : check e1211282853654 [[],[]] .chain = true := by decide
def e1211282853730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211282853730 : Closed e1211282853730 ∧ code e1211282853730 = 5609329364834 := by decide
theorem cert_e1211282853730 : check e1211282853730 [[],[]] .chain = true := by decide
def e1211282853742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e1211282853742 : Closed e1211282853742 ∧ code e1211282853742 = 5609329364846 := by decide
theorem cert_e1211282853742 : check e1211282853742 [[],[]] .sourceHead = true := by decide
def e1211282853750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e1211282853750 : Closed e1211282853750 ∧ code e1211282853750 = 5609329364854 := by decide
theorem cert_e1211282853750 : check e1211282853750 [[],[]] .sourceHead = true := by decide
def e1211282856814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211282856814 : Closed e1211282856814 ∧ code e1211282856814 = 5609329367918 := by decide
theorem cert_e1211282856814 : check e1211282856814 [[],[]] .chain = true := by decide
end Blc.Floor42
