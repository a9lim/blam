import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209572059034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209572059034 : Closed e1209572059034 ∧ code e1209572059034 = 5607618570138 := by decide
theorem cert_e1209572059034 : check e1209572059034 [[],[]] .sourceHead = true := by decide
def e1209572061422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1209572061422 : Closed e1209572061422 ∧ code e1209572061422 = 5607618572526 := by decide
theorem cert_e1209572061422 : check e1209572061422 [[],[]] .sourceHead = true := by decide
def e1209572061430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1209572061430 : Closed e1209572061430 ∧ code e1209572061430 = 5607618572534 := by decide
theorem cert_e1209572061430 : check e1209572061430 [[],[]] .sourceHead = true := by decide
def e1209572061910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1209572061910 : Closed e1209572061910 ∧ code e1209572061910 = 5607618573014 := by decide
theorem cert_e1209572061910 : check e1209572061910 [[],[]] .sourceHead = true := by decide
def e1209572061914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1209572061914 : Closed e1209572061914 ∧ code e1209572061914 = 5607618573018 := by decide
theorem cert_e1209572061914 : check e1209572061914 [[],[]] .sourceHead = true := by decide
def e1209572061930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1209572061930 : Closed e1209572061930 ∧ code e1209572061930 = 5607618573034 := by decide
theorem cert_e1209572061930 : check e1209572061930 [[],[]] .sourceHead = true := by decide
def e1209572061982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209572061982 : Closed e1209572061982 ∧ code e1209572061982 = 5607618573086 := by decide
theorem cert_e1209572061982 : check e1209572061982 [[],[]] .sourceHead = true := by decide
def e1209572062006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209572062006 : Closed e1209572062006 ∧ code e1209572062006 = 5607618573110 := by decide
theorem cert_e1209572062006 : check e1209572062006 [[],[]] .sourceHead = true := by decide
def e1209572062010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209572062010 : Closed e1209572062010 ∧ code e1209572062010 = 5607618573114 := by decide
theorem cert_e1209572062010 : check e1209572062010 [[],[]] .sourceHead = true := by decide
def e1209572062106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209572062106 : Closed e1209572062106 ∧ code e1209572062106 = 5607618573210 := by decide
theorem cert_e1209572062106 : check e1209572062106 [[],[]] .sourceHead = true := by decide
def e1209572062150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209572062150 : Closed e1209572062150 ∧ code e1209572062150 = 5607618573254 := by decide
theorem cert_e1209572062150 : check e1209572062150 [[],[]] .sourceHead = true := by decide
def e1209572136670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1209572136670 : Closed e1209572136670 ∧ code e1209572136670 = 5607618647774 := by decide
theorem cert_e1209572136670 : check e1209572136670 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572136694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1209572136694 : Closed e1209572136694 ∧ code e1209572136694 = 5607618647798 := by decide
private def t_e1209572136694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e1209572136694 : ¬ IsSelfInterpreter e1209572136694 :=
  wSource (t := t_e1209572136694) (replay_sound (ps := []) (t := e1209572136694) (by decide)) (by decide)
def e1209572136798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1209572136798 : Closed e1209572136798 ∧ code e1209572136798 = 5607618647902 := by decide
theorem cert_e1209572136798 : check e1209572136798 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572136814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1209572136814 : Closed e1209572136814 ∧ code e1209572136814 = 5607618647918 := by decide
theorem cert_e1209572136814 : check e1209572136814 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572136822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1209572136822 : Closed e1209572136822 ∧ code e1209572136822 = 5607618647926 := by decide
theorem cert_e1209572136822 : check e1209572136822 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572136826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1209572136826 : Closed e1209572136826 ∧ code e1209572136826 = 5607618647930 := by decide
theorem cert_e1209572136826 : check e1209572136826 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572136886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1209572136886 : Closed e1209572136886 ∧ code e1209572136886 = 5607618647990 := by decide
theorem cert_e1209572136886 : check e1209572136886 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572136918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1209572136918 : Closed e1209572136918 ∧ code e1209572136918 = 5607618648022 := by decide
private def t_e1209572136918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e1209572136918 : ¬ IsSelfInterpreter e1209572136918 :=
  wSource (t := t_e1209572136918) (replay_sound (ps := []) (t := e1209572136918) (by decide)) (by decide)
def e1209572136922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1209572136922 : Closed e1209572136922 ∧ code e1209572136922 = 5607618648026 := by decide
theorem cert_e1209572136922 : check e1209572136922 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572137438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209572137438 : Closed e1209572137438 ∧ code e1209572137438 = 5607618648542 := by decide
theorem cert_e1209572137438 : check e1209572137438 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572137462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209572137462 : Closed e1209572137462 ∧ code e1209572137462 = 5607618648566 := by decide
theorem cert_e1209572137462 : check e1209572137462 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572138206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209572138206 : Closed e1209572138206 ∧ code e1209572138206 = 5607618649310 := by decide
theorem cert_e1209572138206 : check e1209572138206 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572138222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209572138222 : Closed e1209572138222 ∧ code e1209572138222 = 5607618649326 := by decide
theorem cert_e1209572138222 : check e1209572138222 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572138230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209572138230 : Closed e1209572138230 ∧ code e1209572138230 = 5607618649334 := by decide
theorem cert_e1209572138230 : check e1209572138230 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572138234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209572138234 : Closed e1209572138234 ∧ code e1209572138234 = 5607618649338 := by decide
theorem cert_e1209572138234 : check e1209572138234 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572138614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209572138614 : Closed e1209572138614 ∧ code e1209572138614 = 5607618649718 := by decide
theorem cert_e1209572138614 : check e1209572138614 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572138806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209572138806 : Closed e1209572138806 ∧ code e1209572138806 = 5607618649910 := by decide
theorem cert_e1209572138806 : check e1209572138806 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572138810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209572138810 : Closed e1209572138810 ∧ code e1209572138810 = 5607618649914 := by decide
theorem cert_e1209572138810 : check e1209572138810 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572153014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1209572153014 : Closed e1209572153014 ∧ code e1209572153014 = 5607618664118 := by decide
theorem cert_e1209572153014 : check e1209572153014 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1209572153046 : Closed e1209572153046 ∧ code e1209572153046 = 5607618664150 := by decide
theorem cert_e1209572153046 : check e1209572153046 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1209572153050 : Closed e1209572153050 ∧ code e1209572153050 = 5607618664154 := by decide
theorem cert_e1209572153050 : check e1209572153050 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1209572153174 : Closed e1209572153174 ∧ code e1209572153174 = 5607618664278 := by decide
theorem cert_e1209572153174 : check e1209572153174 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1209572153178 : Closed e1209572153178 ∧ code e1209572153178 = 5607618664282 := by decide
theorem cert_e1209572153178 : check e1209572153178 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1209572153194 : Closed e1209572153194 ∧ code e1209572153194 = 5607618664298 := by decide
theorem cert_e1209572153194 : check e1209572153194 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209572153582 : Closed e1209572153582 ∧ code e1209572153582 = 5607618664686 := by decide
theorem cert_e1209572153582 : check e1209572153582 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572153590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209572153590 : Closed e1209572153590 ∧ code e1209572153590 = 5607618664694 := by decide
theorem cert_e1209572153590 : check e1209572153590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572153782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1209572153782 : Closed e1209572153782 ∧ code e1209572153782 = 5607618664886 := by decide
theorem cert_e1209572153782 : check e1209572153782 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1209572153814 : Closed e1209572153814 ∧ code e1209572153814 = 5607618664918 := by decide
theorem cert_e1209572153814 : check e1209572153814 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1209572153818 : Closed e1209572153818 ∧ code e1209572153818 = 5607618664922 := by decide
theorem cert_e1209572153818 : check e1209572153818 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572153974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209572153974 : Closed e1209572153974 ∧ code e1209572153974 = 5607618665078 := by decide
theorem cert_e1209572153974 : check e1209572153974 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209572154142 : Closed e1209572154142 ∧ code e1209572154142 = 5607618665246 := by decide
theorem cert_e1209572154142 : check e1209572154142 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209572154166 : Closed e1209572154166 ∧ code e1209572154166 = 5607618665270 := by decide
theorem cert_e1209572154166 : check e1209572154166 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209572154170 : Closed e1209572154170 ∧ code e1209572154170 = 5607618665274 := by decide
theorem cert_e1209572154170 : check e1209572154170 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209572154254 : Closed e1209572154254 ∧ code e1209572154254 = 5607618665358 := by decide
theorem cert_e1209572154254 : check e1209572154254 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209572154478 : Closed e1209572154478 ∧ code e1209572154478 = 5607618665582 := by decide
theorem cert_e1209572154478 : check e1209572154478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209572154490 : Closed e1209572154490 ∧ code e1209572154490 = 5607618665594 := by decide
theorem cert_e1209572154490 : check e1209572154490 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1209572154582 : Closed e1209572154582 ∧ code e1209572154582 = 5607618665686 := by decide
theorem cert_e1209572154582 : check e1209572154582 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1209572154586 : Closed e1209572154586 ∧ code e1209572154586 = 5607618665690 := by decide
theorem cert_e1209572154586 : check e1209572154586 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1209572154602 : Closed e1209572154602 ∧ code e1209572154602 = 5607618665706 := by decide
theorem cert_e1209572154602 : check e1209572154602 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209572154654 : Closed e1209572154654 ∧ code e1209572154654 = 5607618665758 := by decide
theorem cert_e1209572154654 : check e1209572154654 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209572154678 : Closed e1209572154678 ∧ code e1209572154678 = 5607618665782 := by decide
theorem cert_e1209572154678 : check e1209572154678 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209572154682 : Closed e1209572154682 ∧ code e1209572154682 = 5607618665786 := by decide
theorem cert_e1209572154682 : check e1209572154682 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209572154778 : Closed e1209572154778 ∧ code e1209572154778 = 5607618665882 := by decide
theorem cert_e1209572154778 : check e1209572154778 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572154822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209572154822 : Closed e1209572154822 ∧ code e1209572154822 = 5607618665926 := by decide
theorem cert_e1209572154822 : check e1209572154822 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209572154934 : Closed e1209572154934 ∧ code e1209572154934 = 5607618666038 := by decide
theorem cert_e1209572154934 : check e1209572154934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572154938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209572154938 : Closed e1209572154938 ∧ code e1209572154938 = 5607618666042 := by decide
theorem cert_e1209572154938 : check e1209572154938 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572155022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209572155022 : Closed e1209572155022 ∧ code e1209572155022 = 5607618666126 := by decide
theorem cert_e1209572155022 : check e1209572155022 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572155078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209572155078 : Closed e1209572155078 ∧ code e1209572155078 = 5607618666182 := by decide
theorem cert_e1209572155078 : check e1209572155078 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572155886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1209572155886 : Closed e1209572155886 ∧ code e1209572155886 = 5607618666990 := by decide
theorem cert_e1209572155886 : check e1209572155886 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572156854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1209572156854 : Closed e1209572156854 ∧ code e1209572156854 = 5607618667958 := by decide
theorem cert_e1209572156854 : check e1209572156854 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572156886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1209572156886 : Closed e1209572156886 ∧ code e1209572156886 = 5607618667990 := by decide
theorem cert_e1209572156886 : check e1209572156886 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572156890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1209572156890 : Closed e1209572156890 ∧ code e1209572156890 = 5607618667994 := by decide
theorem cert_e1209572156890 : check e1209572156890 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572157046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209572157046 : Closed e1209572157046 ∧ code e1209572157046 = 5607618668150 := by decide
theorem cert_e1209572157046 : check e1209572157046 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572157214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209572157214 : Closed e1209572157214 ∧ code e1209572157214 = 5607618668318 := by decide
theorem cert_e1209572157214 : check e1209572157214 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572157238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209572157238 : Closed e1209572157238 ∧ code e1209572157238 = 5607618668342 := by decide
theorem cert_e1209572157238 : check e1209572157238 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572157242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209572157242 : Closed e1209572157242 ∧ code e1209572157242 = 5607618668346 := by decide
theorem cert_e1209572157242 : check e1209572157242 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572157326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209572157326 : Closed e1209572157326 ∧ code e1209572157326 = 5607618668430 := by decide
theorem cert_e1209572157326 : check e1209572157326 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572159726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1209572159726 : Closed e1209572159726 ∧ code e1209572159726 = 5607618670830 := by decide
theorem cert_e1209572159726 : check e1209572159726 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572159734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1209572159734 : Closed e1209572159734 ∧ code e1209572159734 = 5607618670838 := by decide
theorem cert_e1209572159734 : check e1209572159734 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1209572160214 : Closed e1209572160214 ∧ code e1209572160214 = 5607618671318 := by decide
theorem cert_e1209572160214 : check e1209572160214 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1209572160218 : Closed e1209572160218 ∧ code e1209572160218 = 5607618671322 := by decide
theorem cert_e1209572160218 : check e1209572160218 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1209572160234 : Closed e1209572160234 ∧ code e1209572160234 = 5607618671338 := by decide
theorem cert_e1209572160234 : check e1209572160234 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209572160286 : Closed e1209572160286 ∧ code e1209572160286 = 5607618671390 := by decide
theorem cert_e1209572160286 : check e1209572160286 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572160310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209572160310 : Closed e1209572160310 ∧ code e1209572160310 = 5607618671414 := by decide
theorem cert_e1209572160310 : check e1209572160310 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209572160314 : Closed e1209572160314 ∧ code e1209572160314 = 5607618671418 := by decide
theorem cert_e1209572160314 : check e1209572160314 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209572160410 : Closed e1209572160410 ∧ code e1209572160410 = 5607618671514 := by decide
theorem cert_e1209572160410 : check e1209572160410 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1209572160454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209572160454 : Closed e1209572160454 ∧ code e1209572160454 = 5607618671558 := by decide
theorem cert_e1209572160454 : check e1209572160454 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572161934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209572161934 : Closed e1209572161934 ∧ code e1209572161934 = 5607618673038 := by decide
theorem cert_e1209572161934 : check e1209572161934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209572161990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209572161990 : Closed e1209572161990 ∧ code e1209572161990 = 5607618673094 := by decide
theorem cert_e1209572161990 : check e1209572161990 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209575955318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1209575955318 : Closed e1209575955318 ∧ code e1209575955318 = 5607622466422 := by decide
theorem cert_e1209575955318 : check e1209575955318 [[],[]] .sourceHead = true := by decide
def e1209575955382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1209575955382 : Closed e1209575955382 ∧ code e1209575955382 = 5607622466486 := by decide
theorem cert_e1209575955382 : check e1209575955382 [[],[]] .sourceHead = true := by decide
def e1209575955830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1209575955830 : Closed e1209575955830 ∧ code e1209575955830 = 5607622466934 := by decide
theorem cert_e1209575955830 : check e1209575955830 [[],[]] .sourceHead = true := by decide
def e1209575955926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1209575955926 : Closed e1209575955926 ∧ code e1209575955926 = 5607622467030 := by decide
theorem cert_e1209575955926 : check e1209575955926 [[],[]] .sourceHead = true := by decide
def e1209575956150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1209575956150 : Closed e1209575956150 ∧ code e1209575956150 = 5607622467254 := by decide
theorem cert_e1209575956150 : check e1209575956150 [[],[]] .sourceHead = true := by decide
def e1209575956182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1209575956182 : Closed e1209575956182 ∧ code e1209575956182 = 5607622467286 := by decide
theorem cert_e1209575956182 : check e1209575956182 [[],[]] .sourceHead = true := by decide
def e1209575958390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1209575958390 : Closed e1209575958390 ∧ code e1209575958390 = 5607622469494 := by decide
theorem cert_e1209575958390 : check e1209575958390 [[],[]] .sourceHead = true := by decide
def e1209575958454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1209575958454 : Closed e1209575958454 ∧ code e1209575958454 = 5607622469558 := by decide
theorem cert_e1209575958454 : check e1209575958454 [[],[]] .sourceHead = true := by decide
def e1209575961462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1209575961462 : Closed e1209575961462 ∧ code e1209575961462 = 5607622472566 := by decide
theorem cert_e1209575961462 : check e1209575961462 [[],[]] .sourceHead = true := by decide
def e1209575961558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1209575961558 : Closed e1209575961558 ∧ code e1209575961558 = 5607622472662 := by decide
theorem cert_e1209575961558 : check e1209575961558 [[],[]] .sourceHead = true := by decide
def e1209575963062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1209575963062 : Closed e1209575963062 ∧ code e1209575963062 = 5607622474166 := by decide
theorem cert_e1209575963062 : check e1209575963062 [[],[]] .sourceHead = true := by decide
def e1209575963094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1209575963094 : Closed e1209575963094 ∧ code e1209575963094 = 5607622474198 := by decide
theorem cert_e1209575963094 : check e1209575963094 [[],[]] .sourceHead = true := by decide
def e1209576131438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209576131438 : Closed e1209576131438 ∧ code e1209576131438 = 5607622642542 := by decide
theorem cert_e1209576131438 : check e1209576131438 [[],[]] .sourceHead = true := by decide
def e1209576131446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209576131446 : Closed e1209576131446 ∧ code e1209576131446 = 5607622642550 := by decide
theorem cert_e1209576131446 : check e1209576131446 [[],[]] .sourceHead = true := by decide
def e1209576131502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209576131502 : Closed e1209576131502 ∧ code e1209576131502 = 5607622642606 := by decide
theorem cert_e1209576131502 : check e1209576131502 [[],[]] .sourceHead = true := by decide
def e1209576131514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209576131514 : Closed e1209576131514 ∧ code e1209576131514 = 5607622642618 := by decide
theorem cert_e1209576131514 : check e1209576131514 [[],[]] .sourceHead = true := by decide
def e1209576131542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209576131542 : Closed e1209576131542 ∧ code e1209576131542 = 5607622642646 := by decide
theorem cert_e1209576131542 : check e1209576131542 [[],[]] .sourceHead = true := by decide
def e1209576131546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209576131546 : Closed e1209576131546 ∧ code e1209576131546 = 5607622642650 := by decide
theorem cert_e1209576131546 : check e1209576131546 [[],[]] .sourceHead = true := by decide
def e1209576131822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209576131822 : Closed e1209576131822 ∧ code e1209576131822 = 5607622642926 := by decide
theorem cert_e1209576131822 : check e1209576131822 [[],[]] .sourceHead = true := by decide
def e1209576131830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209576131830 : Closed e1209576131830 ∧ code e1209576131830 = 5607622642934 := by decide
theorem cert_e1209576131830 : check e1209576131830 [[],[]] .sourceHead = true := by decide
def e1209576132206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209576132206 : Closed e1209576132206 ∧ code e1209576132206 = 5607622643310 := by decide
theorem cert_e1209576132206 : check e1209576132206 [[],[]] .sourceHead = true := by decide
def e1209576132218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209576132218 : Closed e1209576132218 ∧ code e1209576132218 = 5607622643322 := by decide
theorem cert_e1209576132218 : check e1209576132218 [[],[]] .sourceHead = true := by decide
def e1209576132406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209576132406 : Closed e1209576132406 ∧ code e1209576132406 = 5607622643510 := by decide
theorem cert_e1209576132406 : check e1209576132406 [[],[]] .sourceHead = true := by decide
def e1209576132410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209576132410 : Closed e1209576132410 ∧ code e1209576132410 = 5607622643514 := by decide
theorem cert_e1209576132410 : check e1209576132410 [[],[]] .sourceHead = true := by decide
def e1209576205754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1209576205754 : Closed e1209576205754 ∧ code e1209576205754 = 5607622716858 := by decide
theorem cert_e1209576205754 : check e1209576205754 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1209576205786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1209576205786 : Closed e1209576205786 ∧ code e1209576205786 = 5607622716890 := by decide
private def t_e1209576205786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem cert_e1209576205786 : ¬ IsSelfInterpreter e1209576205786 :=
  wSource (t := t_e1209576205786) (replay_sound (ps := []) (t := e1209576205786) (by decide)) (by decide)
def e1209576206010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1209576206010 : Closed e1209576206010 ∧ code e1209576206010 = 5607622717114 := by decide
theorem cert_e1209576206010 : check e1209576206010 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1209576206058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1209576206058 : Closed e1209576206058 ∧ code e1209576206058 = 5607622717162 := by decide
theorem cert_e1209576206058 : check e1209576206058 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1209576206170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1209576206170 : Closed e1209576206170 ∧ code e1209576206170 = 5607622717274 := by decide
private def t_e1209576206170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem cert_e1209576206170 : ¬ IsSelfInterpreter e1209576206170 :=
  wSource (t := t_e1209576206170) (replay_sound (ps := []) (t := e1209576206170) (by decide)) (by decide)
def e1209576206186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1209576206186 : Closed e1209576206186 ∧ code e1209576206186 = 5607622717290 := by decide
theorem cert_e1209576206186 : check e1209576206186 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1209576207290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1209576207290 : Closed e1209576207290 ∧ code e1209576207290 = 5607622718394 := by decide
theorem cert_e1209576207290 : check e1209576207290 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1209576207322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1209576207322 : Closed e1209576207322 ∧ code e1209576207322 = 5607622718426 := by decide
theorem cert_e1209576207322 : check e1209576207322 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1209576208826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1209576208826 : Closed e1209576208826 ∧ code e1209576208826 = 5607622719930 := by decide
theorem cert_e1209576208826 : check e1209576208826 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1209576208874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1209576208874 : Closed e1209576208874 ∧ code e1209576208874 = 5607622719978 := by decide
theorem cert_e1209576208874 : check e1209576208874 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1209576209626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1209576209626 : Closed e1209576209626 ∧ code e1209576209626 = 5607622720730 := by decide
def e1209576209642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1209576209642 : Closed e1209576209642 ∧ code e1209576209642 = 5607622720746 := by decide
def e1209576262510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209576262510 : Closed e1209576262510 ∧ code e1209576262510 = 5607622773614 := by decide
theorem cert_e1209576262510 : check e1209576262510 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209576262518 : Closed e1209576262518 ∧ code e1209576262518 = 5607622773622 := by decide
theorem cert_e1209576262518 : check e1209576262518 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209576262574 : Closed e1209576262574 ∧ code e1209576262574 = 5607622773678 := by decide
theorem cert_e1209576262574 : check e1209576262574 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209576262586 : Closed e1209576262586 ∧ code e1209576262586 = 5607622773690 := by decide
theorem cert_e1209576262586 : check e1209576262586 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209576262614 : Closed e1209576262614 ∧ code e1209576262614 = 5607622773718 := by decide
theorem cert_e1209576262614 : check e1209576262614 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209576262618 : Closed e1209576262618 ∧ code e1209576262618 = 5607622773722 := by decide
theorem cert_e1209576262618 : check e1209576262618 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209576262894 : Closed e1209576262894 ∧ code e1209576262894 = 5607622773998 := by decide
theorem cert_e1209576262894 : check e1209576262894 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576262902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209576262902 : Closed e1209576262902 ∧ code e1209576262902 = 5607622774006 := by decide
theorem cert_e1209576262902 : check e1209576262902 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576263278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209576263278 : Closed e1209576263278 ∧ code e1209576263278 = 5607622774382 := by decide
theorem cert_e1209576263278 : check e1209576263278 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576263290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209576263290 : Closed e1209576263290 ∧ code e1209576263290 = 5607622774394 := by decide
theorem cert_e1209576263290 : check e1209576263290 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576263478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209576263478 : Closed e1209576263478 ∧ code e1209576263478 = 5607622774582 := by decide
theorem cert_e1209576263478 : check e1209576263478 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576263482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209576263482 : Closed e1209576263482 ∧ code e1209576263482 = 5607622774586 := by decide
theorem cert_e1209576263482 : check e1209576263482 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1209576462046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1209576462046 : Closed e1209576462046 ∧ code e1209576462046 = 5607622973150 := by decide
theorem cert_e1209576462046 : check e1209576462046 [[],[]] .smaller = true := by decide
def e1209576462070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1209576462070 : Closed e1209576462070 ∧ code e1209576462070 = 5607622973174 := by decide
theorem cert_e1209576462070 : check e1209576462070 [[],[]] .smaller = true := by decide
def e1209576462174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1209576462174 : Closed e1209576462174 ∧ code e1209576462174 = 5607622973278 := by decide
theorem cert_e1209576462174 : check e1209576462174 [[],[]] .smaller = true := by decide
def e1209576462202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1209576462202 : Closed e1209576462202 ∧ code e1209576462202 = 5607622973306 := by decide
theorem cert_e1209576462202 : check e1209576462202 [[],[]] .smaller = true := by decide
def e1209576462294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1209576462294 : Closed e1209576462294 ∧ code e1209576462294 = 5607622973398 := by decide
theorem cert_e1209576462294 : check e1209576462294 [[],[]] .smaller = true := by decide
def e1209576462298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1209576462298 : Closed e1209576462298 ∧ code e1209576462298 = 5607622973402 := by decide
theorem cert_e1209576462298 : check e1209576462298 [[],[]] .smaller = true := by decide
def e1209576462814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1209576462814 : Closed e1209576462814 ∧ code e1209576462814 = 5607622973918 := by decide
theorem cert_e1209576462814 : check e1209576462814 [[],[]] .smaller = true := by decide
def e1209576462838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1209576462838 : Closed e1209576462838 ∧ code e1209576462838 = 5607622973942 := by decide
theorem cert_e1209576462838 : check e1209576462838 [[],[]] .smaller = true := by decide
def e1209576463582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1209576463582 : Closed e1209576463582 ∧ code e1209576463582 = 5607622974686 := by decide
theorem cert_e1209576463582 : check e1209576463582 [[],[]] .smaller = true := by decide
def e1209576463610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1209576463610 : Closed e1209576463610 ∧ code e1209576463610 = 5607622974714 := by decide
theorem cert_e1209576463610 : check e1209576463610 [[],[]] .smaller = true := by decide
def e1209576464182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209576464182 : Closed e1209576464182 ∧ code e1209576464182 = 5607622975286 := by decide
theorem cert_e1209576464182 : check e1209576464182 [[],[]] .smaller = true := by decide
def e1209576464186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209576464186 : Closed e1209576464186 ∧ code e1209576464186 = 5607622975290 := by decide
theorem cert_e1209576464186 : check e1209576464186 [[],[]] .smaller = true := by decide
def e1209576478958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1209576478958 : Closed e1209576478958 ∧ code e1209576478958 = 5607622990062 := by decide
theorem cert_e1209576478958 : check e1209576478958 [[],[]] .smaller = true := by decide
def e1209576478966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1209576478966 : Closed e1209576478966 ∧ code e1209576478966 = 5607622990070 := by decide
theorem cert_e1209576478966 : check e1209576478966 [[],[]] .smaller = true := by decide
def e1209576479518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1209576479518 : Closed e1209576479518 ∧ code e1209576479518 = 5607622990622 := by decide
theorem cert_e1209576479518 : check e1209576479518 [[],[]] .smaller = true := by decide
def e1209576479630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1209576479630 : Closed e1209576479630 ∧ code e1209576479630 = 5607622990734 := by decide
theorem cert_e1209576479630 : check e1209576479630 [[],[]] .smaller = true := by decide
def e1209576479854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1209576479854 : Closed e1209576479854 ∧ code e1209576479854 = 5607622990958 := by decide
theorem cert_e1209576479854 : check e1209576479854 [[],[]] .smaller = true := by decide
def e1209576479866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1209576479866 : Closed e1209576479866 ∧ code e1209576479866 = 5607622990970 := by decide
theorem cert_e1209576479866 : check e1209576479866 [[],[]] .smaller = true := by decide
def e1209576480030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1209576480030 : Closed e1209576480030 ∧ code e1209576480030 = 5607622991134 := by decide
theorem cert_e1209576480030 : check e1209576480030 [[],[]] .smaller = true := by decide
def e1209576480198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1209576480198 : Closed e1209576480198 ∧ code e1209576480198 = 5607622991302 := by decide
theorem cert_e1209576480198 : check e1209576480198 [[],[]] .smaller = true := by decide
def e1209576480222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1209576480222 : Closed e1209576480222 ∧ code e1209576480222 = 5607622991326 := by decide
theorem cert_e1209576480222 : check e1209576480222 [[],[]] .sourceHead = true := by decide
def e1209576480238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1209576480238 : Closed e1209576480238 ∧ code e1209576480238 = 5607622991342 := by decide
theorem cert_e1209576480238 : check e1209576480238 [[],[]] .sourceHead = true := by decide
def e1209576480310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1209576480310 : Closed e1209576480310 ∧ code e1209576480310 = 5607622991414 := by decide
theorem cert_e1209576480310 : check e1209576480310 [[],[]] .smaller = true := by decide
def e1209576480314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1209576480314 : Closed e1209576480314 ∧ code e1209576480314 = 5607622991418 := by decide
theorem cert_e1209576480314 : check e1209576480314 [[],[]] .smaller = true := by decide
def e1209576480398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1209576480398 : Closed e1209576480398 ∧ code e1209576480398 = 5607622991502 := by decide
theorem cert_e1209576480398 : check e1209576480398 [[],[]] .smaller = true := by decide
def e1209576480454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1209576480454 : Closed e1209576480454 ∧ code e1209576480454 = 5607622991558 := by decide
theorem cert_e1209576480454 : check e1209576480454 [[],[]] .smaller = true := by decide
def e1209576480478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1209576480478 : Closed e1209576480478 ∧ code e1209576480478 = 5607622991582 := by decide
theorem cert_e1209576480478 : check e1209576480478 [[],[]] .sourceHead = true := by decide
def e1209576480502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1209576480502 : Closed e1209576480502 ∧ code e1209576480502 = 5607622991606 := by decide
theorem cert_e1209576480502 : check e1209576480502 [[],[]] .sourceHead = true := by decide
def e1209576480622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1209576480622 : Closed e1209576480622 ∧ code e1209576480622 = 5607622991726 := by decide
theorem cert_e1209576480622 : check e1209576480622 [[],[]] .sourceHead = true := by decide
def e1209576480630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1209576480630 : Closed e1209576480630 ∧ code e1209576480630 = 5607622991734 := by decide
theorem cert_e1209576480630 : check e1209576480630 [[],[]] .sourceHead = true := by decide
def e1209576482590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1209576482590 : Closed e1209576482590 ∧ code e1209576482590 = 5607622993694 := by decide
theorem cert_e1209576482590 : check e1209576482590 [[],[]] .smaller = true := by decide
def e1209576482702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1209576482702 : Closed e1209576482702 ∧ code e1209576482702 = 5607622993806 := by decide
theorem cert_e1209576482702 : check e1209576482702 [[],[]] .smaller = true := by decide
end Blc.Floor42
