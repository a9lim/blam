import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204679454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211204679454 : Closed e1211204679454 ∧ code e1211204679454 = 5609251190558 := by decide
theorem cert_e1211204679454 : check e1211204679454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204679478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204679478 : Closed e1211204679478 ∧ code e1211204679478 = 5609251190582 := by decide
theorem cert_e1211204679478 : check e1211204679478 [[],[]] .chain = true := by decide
def e1211204679482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204679482 : Closed e1211204679482 ∧ code e1211204679482 = 5609251190586 := by decide
theorem cert_e1211204679482 : check e1211204679482 [[],[]] .chain = true := by decide
def e1211204679726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211204679726 : Closed e1211204679726 ∧ code e1211204679726 = 5609251190830 := by decide
theorem cert_e1211204679726 : check e1211204679726 [[],[]] .chain = true := by decide
def e1211204679918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211204679918 : Closed e1211204679918 ∧ code e1211204679918 = 5609251191022 := by decide
theorem cert_e1211204679918 : check e1211204679918 [[],[]] .chain = true := by decide
def e1211204679926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211204679926 : Closed e1211204679926 ∧ code e1211204679926 = 5609251191030 := by decide
theorem cert_e1211204679926 : check e1211204679926 [[],[]] .chain = true := by decide
def e1211204680110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211204680110 : Closed e1211204680110 ∧ code e1211204680110 = 5609251191214 := by decide
theorem cert_e1211204680110 : check e1211204680110 [[],[]] .chain = true := by decide
def e1211204680122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211204680122 : Closed e1211204680122 ∧ code e1211204680122 = 5609251191226 := by decide
theorem cert_e1211204680122 : check e1211204680122 [[],[]] .chain = true := by decide
def e1211204680170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211204680170 : Closed e1211204680170 ∧ code e1211204680170 = 5609251191274 := by decide
theorem cert_e1211204680170 : check e1211204680170 [[],[]] .chain = true := by decide
def e1211204680302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204680302 : Closed e1211204680302 ∧ code e1211204680302 = 5609251191406 := by decide
theorem cert_e1211204680302 : check e1211204680302 [[],[]] .chain = true := by decide
def e1211204680314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204680314 : Closed e1211204680314 ∧ code e1211204680314 = 5609251191418 := by decide
theorem cert_e1211204680314 : check e1211204680314 [[],[]] .chain = true := by decide
def e1211204680478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211204680478 : Closed e1211204680478 ∧ code e1211204680478 = 5609251191582 := by decide
theorem cert_e1211204680478 : check e1211204680478 [[],[]] .chain = true := by decide
def e1211204680578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204680578 : Closed e1211204680578 ∧ code e1211204680578 = 5609251191682 := by decide
theorem cert_e1211204680578 : check e1211204680578 [[],[]] .chain = true := by decide
def e1211204680590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211204680590 : Closed e1211204680590 ∧ code e1211204680590 = 5609251191694 := by decide
theorem cert_e1211204680590 : check e1211204680590 [[],[]] .chain = true := by decide
def e1211204680602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204680602 : Closed e1211204680602 ∧ code e1211204680602 = 5609251191706 := by decide
theorem cert_e1211204680602 : check e1211204680602 [[],[]] .chain = true := by decide
def e1211204680726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211204680726 : Closed e1211204680726 ∧ code e1211204680726 = 5609251191830 := by decide
theorem cert_e1211204680726 : check e1211204680726 [[],[]] .chain = true := by decide
def e1211204680730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211204680730 : Closed e1211204680730 ∧ code e1211204680730 = 5609251191834 := by decide
theorem cert_e1211204680730 : check e1211204680730 [[],[]] .chain = true := by decide
def e1211204680774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211204680774 : Closed e1211204680774 ∧ code e1211204680774 = 5609251191878 := by decide
theorem cert_e1211204680774 : check e1211204680774 [[],[]] .chain = true := by decide
def e1211204680802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211204680802 : Closed e1211204680802 ∧ code e1211204680802 = 5609251191906 := by decide
theorem cert_e1211204680802 : check e1211204680802 [[],[]] .chain = true := by decide
def e1211204680814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211204680814 : Closed e1211204680814 ∧ code e1211204680814 = 5609251191918 := by decide
theorem cert_e1211204680814 : check e1211204680814 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204680822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211204680822 : Closed e1211204680822 ∧ code e1211204680822 = 5609251191926 := by decide
theorem cert_e1211204680822 : check e1211204680822 [[],[]] .chain = true := by decide
def e1211204680826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211204680826 : Closed e1211204680826 ∧ code e1211204680826 = 5609251191930 := by decide
theorem cert_e1211204680826 : check e1211204680826 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204680918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211204680918 : Closed e1211204680918 ∧ code e1211204680918 = 5609251192022 := by decide
theorem cert_e1211204680918 : check e1211204680918 [[],[]] .chain = true := by decide
def e1211204680922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211204680922 : Closed e1211204680922 ∧ code e1211204680922 = 5609251192026 := by decide
theorem cert_e1211204680922 : check e1211204680922 [[],[]] .chain = true := by decide
def e1211204680938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211204680938 : Closed e1211204680938 ∧ code e1211204680938 = 5609251192042 := by decide
theorem cert_e1211204680938 : check e1211204680938 [[],[]] .chain = true := by decide
def e1211204680966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204680966 : Closed e1211204680966 ∧ code e1211204680966 = 5609251192070 := by decide
theorem cert_e1211204680966 : check e1211204680966 [[],[]] .chain = true := by decide
def e1211204680990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211204680990 : Closed e1211204680990 ∧ code e1211204680990 = 5609251192094 := by decide
theorem cert_e1211204680990 : check e1211204680990 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204681014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204681014 : Closed e1211204681014 ∧ code e1211204681014 = 5609251192118 := by decide
theorem cert_e1211204681014 : check e1211204681014 [[],[]] .chain = true := by decide
def e1211204681018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204681018 : Closed e1211204681018 ∧ code e1211204681018 = 5609251192122 := by decide
theorem cert_e1211204681018 : check e1211204681018 [[],[]] .chain = true := by decide
def e1211204681090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204681090 : Closed e1211204681090 ∧ code e1211204681090 = 5609251192194 := by decide
theorem cert_e1211204681090 : check e1211204681090 [[],[]] .chain = true := by decide
def e1211204681102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211204681102 : Closed e1211204681102 ∧ code e1211204681102 = 5609251192206 := by decide
theorem cert_e1211204681102 : check e1211204681102 [[],[]] .chain = true := by decide
def e1211204681114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204681114 : Closed e1211204681114 ∧ code e1211204681114 = 5609251192218 := by decide
theorem cert_e1211204681114 : check e1211204681114 [[],[]] .chain = true := by decide
def e1211204681158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211204681158 : Closed e1211204681158 ∧ code e1211204681158 = 5609251192262 := by decide
theorem cert_e1211204681158 : check e1211204681158 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204681854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211204681854 : Closed e1211204681854 ∧ code e1211204681854 = 5609251192958 := by decide
theorem cert_e1211204681854 : check e1211204681854 [[],[]] .chain = true := by decide
def e1211204682718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211204682718 : Closed e1211204682718 ∧ code e1211204682718 = 5609251193822 := by decide
theorem cert_e1211204682718 : check e1211204682718 [[],[]] .chain = true := by decide
def e1211204682722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211204682722 : Closed e1211204682722 ∧ code e1211204682722 = 5609251193826 := by decide
theorem cert_e1211204682722 : check e1211204682722 [[],[]] .chain = true := by decide
def e1211204682734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211204682734 : Closed e1211204682734 ∧ code e1211204682734 = 5609251193838 := by decide
theorem cert_e1211204682734 : check e1211204682734 [[],[]] .chain = true := by decide
def e1211204684654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211204684654 : Closed e1211204684654 ∧ code e1211204684654 = 5609251195758 := by decide
theorem cert_e1211204684654 : check e1211204684654 [[],[]] .chain = true := by decide
def e1211204684662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211204684662 : Closed e1211204684662 ∧ code e1211204684662 = 5609251195766 := by decide
theorem cert_e1211204684662 : check e1211204684662 [[],[]] .chain = true := by decide
def e1211204684718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211204684718 : Closed e1211204684718 ∧ code e1211204684718 = 5609251195822 := by decide
theorem cert_e1211204684718 : check e1211204684718 [[],[]] .chain = true := by decide
def e1211204684730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211204684730 : Closed e1211204684730 ∧ code e1211204684730 = 5609251195834 := by decide
theorem cert_e1211204684730 : check e1211204684730 [[],[]] .chain = true := by decide
def e1211204684758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211204684758 : Closed e1211204684758 ∧ code e1211204684758 = 5609251195862 := by decide
theorem cert_e1211204684758 : check e1211204684758 [[],[]] .chain = true := by decide
def e1211204684762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211204684762 : Closed e1211204684762 ∧ code e1211204684762 = 5609251195866 := by decide
theorem cert_e1211204684762 : check e1211204684762 [[],[]] .chain = true := by decide
def e1211204685038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204685038 : Closed e1211204685038 ∧ code e1211204685038 = 5609251196142 := by decide
theorem cert_e1211204685038 : check e1211204685038 [[],[]] .chain = true := by decide
def e1211204685046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204685046 : Closed e1211204685046 ∧ code e1211204685046 = 5609251196150 := by decide
theorem cert_e1211204685046 : check e1211204685046 [[],[]] .chain = true := by decide
def e1211204685422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204685422 : Closed e1211204685422 ∧ code e1211204685422 = 5609251196526 := by decide
theorem cert_e1211204685422 : check e1211204685422 [[],[]] .chain = true := by decide
def e1211204685434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204685434 : Closed e1211204685434 ∧ code e1211204685434 = 5609251196538 := by decide
theorem cert_e1211204685434 : check e1211204685434 [[],[]] .chain = true := by decide
def e1211204685574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204685574 : Closed e1211204685574 ∧ code e1211204685574 = 5609251196678 := by decide
theorem cert_e1211204685574 : check e1211204685574 [[],[]] .chain = true := by decide
def e1211204685598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211204685598 : Closed e1211204685598 ∧ code e1211204685598 = 5609251196702 := by decide
theorem cert_e1211204685598 : check e1211204685598 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204685622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204685622 : Closed e1211204685622 ∧ code e1211204685622 = 5609251196726 := by decide
theorem cert_e1211204685622 : check e1211204685622 [[],[]] .chain = true := by decide
def e1211204685626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204685626 : Closed e1211204685626 ∧ code e1211204685626 = 5609251196730 := by decide
theorem cert_e1211204685626 : check e1211204685626 [[],[]] .chain = true := by decide
def e1211204690398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211204690398 : Closed e1211204690398 ∧ code e1211204690398 = 5609251201502 := by decide
theorem cert_e1211204690398 : check e1211204690398 [[],[]] .chain = true := by decide
def e1211204690422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211204690422 : Closed e1211204690422 ∧ code e1211204690422 = 5609251201526 := by decide
theorem cert_e1211204690422 : check e1211204690422 [[],[]] .chain = true := by decide
def e1211204691374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211204691374 : Closed e1211204691374 ∧ code e1211204691374 = 5609251202478 := by decide
theorem cert_e1211204691374 : check e1211204691374 [[],[]] .chain = true := by decide
def e1211204691386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211204691386 : Closed e1211204691386 ∧ code e1211204691386 = 5609251202490 := by decide
theorem cert_e1211204691386 : check e1211204691386 [[],[]] .chain = true := by decide
def e1211204691434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211204691434 : Closed e1211204691434 ∧ code e1211204691434 = 5609251202538 := by decide
theorem cert_e1211204691434 : check e1211204691434 [[],[]] .chain = true := by decide
def e1211204691566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204691566 : Closed e1211204691566 ∧ code e1211204691566 = 5609251202670 := by decide
theorem cert_e1211204691566 : check e1211204691566 [[],[]] .chain = true := by decide
def e1211204691578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204691578 : Closed e1211204691578 ∧ code e1211204691578 = 5609251202682 := by decide
theorem cert_e1211204691578 : check e1211204691578 [[],[]] .chain = true := by decide
def e1211204691742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211204691742 : Closed e1211204691742 ∧ code e1211204691742 = 5609251202846 := by decide
theorem cert_e1211204691742 : check e1211204691742 [[],[]] .chain = true := by decide
def e1211204691842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211204691842 : Closed e1211204691842 ∧ code e1211204691842 = 5609251202946 := by decide
theorem cert_e1211204691842 : check e1211204691842 [[],[]] .chain = true := by decide
def e1211204691854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211204691854 : Closed e1211204691854 ∧ code e1211204691854 = 5609251202958 := by decide
theorem cert_e1211204691854 : check e1211204691854 [[],[]] .chain = true := by decide
def e1211204691866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211204691866 : Closed e1211204691866 ∧ code e1211204691866 = 5609251202970 := by decide
theorem cert_e1211204691866 : check e1211204691866 [[],[]] .chain = true := by decide
def e1211204694046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211204694046 : Closed e1211204694046 ∧ code e1211204694046 = 5609251205150 := by decide
theorem cert_e1211204694046 : check e1211204694046 [[],[]] .chain = true := by decide
def e1211204694214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211204694214 : Closed e1211204694214 ∧ code e1211204694214 = 5609251205318 := by decide
theorem cert_e1211204694214 : check e1211204694214 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204694238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211204694238 : Closed e1211204694238 ∧ code e1211204694238 = 5609251205342 := by decide
theorem cert_e1211204694238 : check e1211204694238 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204694242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211204694242 : Closed e1211204694242 ∧ code e1211204694242 = 5609251205346 := by decide
theorem cert_e1211204694242 : check e1211204694242 [[],[]] .chain = true := by decide
def e1211204694254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204694254 : Closed e1211204694254 ∧ code e1211204694254 = 5609251205358 := by decide
theorem cert_e1211204694254 : check e1211204694254 [[],[]] .chain = true := by decide
def e1211204694262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204694262 : Closed e1211204694262 ∧ code e1211204694262 = 5609251205366 := by decide
theorem cert_e1211204694262 : check e1211204694262 [[],[]] .chain = true := by decide
def e1211204694266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211204694266 : Closed e1211204694266 ∧ code e1211204694266 = 5609251205370 := by decide
theorem cert_e1211204694266 : check e1211204694266 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204694742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211204694742 : Closed e1211204694742 ∧ code e1211204694742 = 5609251205846 := by decide
theorem cert_e1211204694742 : check e1211204694742 [[],[]] .chain = true := by decide
def e1211204694746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211204694746 : Closed e1211204694746 ∧ code e1211204694746 = 5609251205850 := by decide
theorem cert_e1211204694746 : check e1211204694746 [[],[]] .chain = true := by decide
def e1211204694762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211204694762 : Closed e1211204694762 ∧ code e1211204694762 = 5609251205866 := by decide
theorem cert_e1211204694762 : check e1211204694762 [[],[]] .chain = true := by decide
def e1211204694790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204694790 : Closed e1211204694790 ∧ code e1211204694790 = 5609251205894 := by decide
theorem cert_e1211204694790 : check e1211204694790 [[],[]] .chain = true := by decide
def e1211204694814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211204694814 : Closed e1211204694814 ∧ code e1211204694814 = 5609251205918 := by decide
theorem cert_e1211204694814 : check e1211204694814 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204694838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204694838 : Closed e1211204694838 ∧ code e1211204694838 = 5609251205942 := by decide
theorem cert_e1211204694838 : check e1211204694838 [[],[]] .chain = true := by decide
def e1211204694842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204694842 : Closed e1211204694842 ∧ code e1211204694842 = 5609251205946 := by decide
theorem cert_e1211204694842 : check e1211204694842 [[],[]] .chain = true := by decide
def e1211204694914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211204694914 : Closed e1211204694914 ∧ code e1211204694914 = 5609251206018 := by decide
theorem cert_e1211204694914 : check e1211204694914 [[],[]] .chain = true := by decide
def e1211204694926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211204694926 : Closed e1211204694926 ∧ code e1211204694926 = 5609251206030 := by decide
theorem cert_e1211204694926 : check e1211204694926 [[],[]] .chain = true := by decide
def e1211204694938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211204694938 : Closed e1211204694938 ∧ code e1211204694938 = 5609251206042 := by decide
theorem cert_e1211204694938 : check e1211204694938 [[],[]] .chain = true := by decide
def e1211204694982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211204694982 : Closed e1211204694982 ∧ code e1211204694982 = 5609251206086 := by decide
theorem cert_e1211204694982 : check e1211204694982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204765662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e1211204765662 : Closed e1211204765662 ∧ code e1211204765662 = 5609251276766 := by decide
theorem cert_e1211204765662 : check e1211204765662 [[],[]] .chain = true := by decide
def e1211204769502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211204769502 : Closed e1211204769502 ∧ code e1211204769502 = 5609251280606 := by decide
theorem cert_e1211204769502 : check e1211204769502 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204769518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1211204769518 : Closed e1211204769518 ∧ code e1211204769518 = 5609251280622 := by decide
theorem cert_e1211204769518 : check e1211204769518 [[],[]] .chain = true := by decide
def e1211204769526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211204769526 : Closed e1211204769526 ∧ code e1211204769526 = 5609251280630 := by decide
theorem cert_e1211204769526 : check e1211204769526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204769630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211204769630 : Closed e1211204769630 ∧ code e1211204769630 = 5609251280734 := by decide
theorem cert_e1211204769630 : check e1211204769630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204769646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211204769646 : Closed e1211204769646 ∧ code e1211204769646 = 5609251280750 := by decide
theorem cert_e1211204769646 : check e1211204769646 [[],[]] .chain = true := by decide
def e1211204769654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211204769654 : Closed e1211204769654 ∧ code e1211204769654 = 5609251280758 := by decide
theorem cert_e1211204769654 : check e1211204769654 [[],[]] .chain = true := by decide
def e1211204769658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211204769658 : Closed e1211204769658 ∧ code e1211204769658 = 5609251280762 := by decide
theorem cert_e1211204769658 : check e1211204769658 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1211204769710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1211204769710 : Closed e1211204769710 ∧ code e1211204769710 = 5609251280814 := by decide
theorem cert_e1211204769710 : check e1211204769710 [[],[]] .chain = true := by decide
def e1211204769718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211204769718 : Closed e1211204769718 ∧ code e1211204769718 = 5609251280822 := by decide
theorem cert_e1211204769718 : check e1211204769718 [[],[]] .chain = true := by decide
def e1211204769722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1211204769722 : Closed e1211204769722 ∧ code e1211204769722 = 5609251280826 := by decide
theorem cert_e1211204769722 : check e1211204769722 [[],[]] .chain = true := by decide
def e1211204769750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211204769750 : Closed e1211204769750 ∧ code e1211204769750 = 5609251280854 := by decide
theorem cert_e1211204769750 : check e1211204769750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1211204769754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211204769754 : Closed e1211204769754 ∧ code e1211204769754 = 5609251280858 := by decide
theorem cert_e1211204769754 : check e1211204769754 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211204770270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211204770270 : Closed e1211204770270 ∧ code e1211204770270 = 5609251281374 := by decide
theorem cert_e1211204770270 : check e1211204770270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e1211204770286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211204770286 : Closed e1211204770286 ∧ code e1211204770286 = 5609251281390 := by decide
theorem cert_e1211204770286 : check e1211204770286 [[],[]] .chain = true := by decide
def e1211204770294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211204770294 : Closed e1211204770294 ∧ code e1211204770294 = 5609251281398 := by decide
theorem cert_e1211204770294 : check e1211204770294 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e1211204771038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211204771038 : Closed e1211204771038 ∧ code e1211204771038 = 5609251282142 := by decide
theorem cert_e1211204771038 : check e1211204771038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204771054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204771054 : Closed e1211204771054 ∧ code e1211204771054 = 5609251282158 := by decide
theorem cert_e1211204771054 : check e1211204771054 [[],[]] .chain = true := by decide
def e1211204771062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204771062 : Closed e1211204771062 ∧ code e1211204771062 = 5609251282166 := by decide
theorem cert_e1211204771062 : check e1211204771062 [[],[]] .chain = true := by decide
def e1211204771066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211204771066 : Closed e1211204771066 ∧ code e1211204771066 = 5609251282170 := by decide
theorem cert_e1211204771066 : check e1211204771066 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left]] .identityHead = true := by decide
def e1211204771354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211204771354 : Closed e1211204771354 ∧ code e1211204771354 = 5609251282458 := by decide
theorem cert_e1211204771354 : checkPay e1211204771354 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1211204771390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e1211204771390 : Closed e1211204771390 ∧ code e1211204771390 = 5609251282494 := by decide
theorem cert_e1211204771390 : checkPay e1211204771390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1211204771438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204771438 : Closed e1211204771438 ∧ code e1211204771438 = 5609251282542 := by decide
theorem cert_e1211204771438 : check e1211204771438 [[],[]] .chain = true := by decide
def e1211204771446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211204771446 : Closed e1211204771446 ∧ code e1211204771446 = 5609251282550 := by decide
theorem cert_e1211204771446 : check e1211204771446 [[],[]] .chain = true := by decide
def e1211204771450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204771450 : Closed e1211204771450 ∧ code e1211204771450 = 5609251282554 := by decide
theorem cert_e1211204771450 : check e1211204771450 [[],[]] .chain = true := by decide
def e1211204771614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e1211204771614 : Closed e1211204771614 ∧ code e1211204771614 = 5609251282718 := by decide
theorem cert_e1211204771614 : check e1211204771614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1211204771638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204771638 : Closed e1211204771638 ∧ code e1211204771638 = 5609251282742 := by decide
theorem cert_e1211204771638 : check e1211204771638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1211204771642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204771642 : Closed e1211204771642 ∧ code e1211204771642 = 5609251282746 := by decide
theorem cert_e1211204771642 : check e1211204771642 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1211204785846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211204785846 : Closed e1211204785846 ∧ code e1211204785846 = 5609251296950 := by decide
theorem cert_e1211204785846 : check e1211204785846 [[],[]] .chain = true := by decide
def e1211204785878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211204785878 : Closed e1211204785878 ∧ code e1211204785878 = 5609251296982 := by decide
theorem cert_e1211204785878 : check e1211204785878 [[],[]] .chain = true := by decide
def e1211204785882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211204785882 : Closed e1211204785882 ∧ code e1211204785882 = 5609251296986 := by decide
theorem cert_e1211204785882 : check e1211204785882 [[],[]] .chain = true := by decide
def e1211204786006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211204786006 : Closed e1211204786006 ∧ code e1211204786006 = 5609251297110 := by decide
theorem cert_e1211204786006 : check e1211204786006 [[],[]] .chain = true := by decide
def e1211204786010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211204786010 : Closed e1211204786010 ∧ code e1211204786010 = 5609251297114 := by decide
theorem cert_e1211204786010 : check e1211204786010 [[],[]] .chain = true := by decide
def e1211204786026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211204786026 : Closed e1211204786026 ∧ code e1211204786026 = 5609251297130 := by decide
theorem cert_e1211204786026 : check e1211204786026 [[],[]] .chain = true := by decide
def e1211204786230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211204786230 : Closed e1211204786230 ∧ code e1211204786230 = 5609251297334 := by decide
theorem cert_e1211204786230 : check e1211204786230 [[],[]] .chain = true := by decide
def e1211204786318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211204786318 : Closed e1211204786318 ∧ code e1211204786318 = 5609251297422 := by decide
theorem cert_e1211204786318 : check e1211204786318 [[],[]] .chain = true := by decide
def e1211204786402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211204786402 : Closed e1211204786402 ∧ code e1211204786402 = 5609251297506 := by decide
theorem cert_e1211204786402 : check e1211204786402 [[],[]] .chain = true := by decide
def e1211204786414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211204786414 : Closed e1211204786414 ∧ code e1211204786414 = 5609251297518 := by decide
theorem cert_e1211204786414 : check e1211204786414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204786422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211204786422 : Closed e1211204786422 ∧ code e1211204786422 = 5609251297526 := by decide
theorem cert_e1211204786422 : check e1211204786422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211204786614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211204786614 : Closed e1211204786614 ∧ code e1211204786614 = 5609251297718 := by decide
theorem cert_e1211204786614 : check e1211204786614 [[],[]] .chain = true := by decide
def e1211204786646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211204786646 : Closed e1211204786646 ∧ code e1211204786646 = 5609251297750 := by decide
theorem cert_e1211204786646 : check e1211204786646 [[],[]] .chain = true := by decide
def e1211204786650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211204786650 : Closed e1211204786650 ∧ code e1211204786650 = 5609251297754 := by decide
theorem cert_e1211204786650 : check e1211204786650 [[],[]] .chain = true := by decide
def e1211204786806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204786806 : Closed e1211204786806 ∧ code e1211204786806 = 5609251297910 := by decide
theorem cert_e1211204786806 : check e1211204786806 [[],[]] .chain = true := by decide
def e1211204786950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204786950 : Closed e1211204786950 ∧ code e1211204786950 = 5609251298054 := by decide
theorem cert_e1211204786950 : check e1211204786950 [[],[]] .chain = true := by decide
def e1211204786974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211204786974 : Closed e1211204786974 ∧ code e1211204786974 = 5609251298078 := by decide
theorem cert_e1211204786974 : check e1211204786974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211204786998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204786998 : Closed e1211204786998 ∧ code e1211204786998 = 5609251298102 := by decide
theorem cert_e1211204786998 : check e1211204786998 [[],[]] .chain = true := by decide
def e1211204787002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204787002 : Closed e1211204787002 ∧ code e1211204787002 = 5609251298106 := by decide
theorem cert_e1211204787002 : check e1211204787002 [[],[]] .chain = true := by decide
def e1211204787086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211204787086 : Closed e1211204787086 ∧ code e1211204787086 = 5609251298190 := by decide
theorem cert_e1211204787086 : check e1211204787086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204787222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211204787222 : Closed e1211204787222 ∧ code e1211204787222 = 5609251298326 := by decide
theorem cert_e1211204787222 : check e1211204787222 [[],[]] .chain = true := by decide
def e1211204787226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211204787226 : Closed e1211204787226 ∧ code e1211204787226 = 5609251298330 := by decide
theorem cert_e1211204787226 : check e1211204787226 [[],[]] .chain = true := by decide
def e1211204787270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211204787270 : Closed e1211204787270 ∧ code e1211204787270 = 5609251298374 := by decide
theorem cert_e1211204787270 : check e1211204787270 [[],[]] .chain = true := by decide
def e1211204787298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211204787298 : Closed e1211204787298 ∧ code e1211204787298 = 5609251298402 := by decide
theorem cert_e1211204787298 : check e1211204787298 [[],[]] .chain = true := by decide
def e1211204787310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211204787310 : Closed e1211204787310 ∧ code e1211204787310 = 5609251298414 := by decide
theorem cert_e1211204787310 : check e1211204787310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211204787318 : Closed e1211204787318 ∧ code e1211204787318 = 5609251298422 := by decide
theorem cert_e1211204787318 : check e1211204787318 [[],[]] .chain = true := by decide
def e1211204787322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211204787322 : Closed e1211204787322 ∧ code e1211204787322 = 5609251298426 := by decide
theorem cert_e1211204787322 : check e1211204787322 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211204787414 : Closed e1211204787414 ∧ code e1211204787414 = 5609251298518 := by decide
theorem cert_e1211204787414 : check e1211204787414 [[],[]] .chain = true := by decide
def e1211204787418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211204787418 : Closed e1211204787418 ∧ code e1211204787418 = 5609251298522 := by decide
theorem cert_e1211204787418 : check e1211204787418 [[],[]] .chain = true := by decide
def e1211204787434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211204787434 : Closed e1211204787434 ∧ code e1211204787434 = 5609251298538 := by decide
theorem cert_e1211204787434 : check e1211204787434 [[],[]] .chain = true := by decide
def e1211204787462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204787462 : Closed e1211204787462 ∧ code e1211204787462 = 5609251298566 := by decide
theorem cert_e1211204787462 : check e1211204787462 [[],[]] .chain = true := by decide
def e1211204787486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211204787486 : Closed e1211204787486 ∧ code e1211204787486 = 5609251298590 := by decide
theorem cert_e1211204787486 : check e1211204787486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204787510 : Closed e1211204787510 ∧ code e1211204787510 = 5609251298614 := by decide
theorem cert_e1211204787510 : check e1211204787510 [[],[]] .chain = true := by decide
def e1211204787514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204787514 : Closed e1211204787514 ∧ code e1211204787514 = 5609251298618 := by decide
theorem cert_e1211204787514 : check e1211204787514 [[],[]] .chain = true := by decide
def e1211204787586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204787586 : Closed e1211204787586 ∧ code e1211204787586 = 5609251298690 := by decide
theorem cert_e1211204787586 : check e1211204787586 [[],[]] .chain = true := by decide
def e1211204787598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211204787598 : Closed e1211204787598 ∧ code e1211204787598 = 5609251298702 := by decide
theorem cert_e1211204787598 : check e1211204787598 [[],[]] .chain = true := by decide
def e1211204787610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204787610 : Closed e1211204787610 ∧ code e1211204787610 = 5609251298714 := by decide
theorem cert_e1211204787610 : check e1211204787610 [[],[]] .chain = true := by decide
def e1211204787654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211204787654 : Closed e1211204787654 ∧ code e1211204787654 = 5609251298758 := by decide
theorem cert_e1211204787654 : check e1211204787654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211204787766 : Closed e1211204787766 ∧ code e1211204787766 = 5609251298870 := by decide
theorem cert_e1211204787766 : check e1211204787766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211204787770 : Closed e1211204787770 ∧ code e1211204787770 = 5609251298874 := by decide
theorem cert_e1211204787770 : check e1211204787770 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211204787854 : Closed e1211204787854 ∧ code e1211204787854 = 5609251298958 := by decide
theorem cert_e1211204787854 : check e1211204787854 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204787910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211204787910 : Closed e1211204787910 ∧ code e1211204787910 = 5609251299014 := by decide
theorem cert_e1211204787910 : check e1211204787910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211204788286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211204788286 : Closed e1211204788286 ∧ code e1211204788286 = 5609251299390 := by decide
theorem cert_e1211204788286 : check e1211204788286 [[],[]] .chain = true := by decide
def e1211204788706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211204788706 : Closed e1211204788706 ∧ code e1211204788706 = 5609251299810 := by decide
theorem cert_e1211204788706 : check e1211204788706 [[],[]] .chain = true := by decide
def e1211204788718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211204788718 : Closed e1211204788718 ∧ code e1211204788718 = 5609251299822 := by decide
theorem cert_e1211204788718 : check e1211204788718 [[],[]] .chain = true := by decide
def e1211204789686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211204789686 : Closed e1211204789686 ∧ code e1211204789686 = 5609251300790 := by decide
theorem cert_e1211204789686 : check e1211204789686 [[],[]] .chain = true := by decide
def e1211204789718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211204789718 : Closed e1211204789718 ∧ code e1211204789718 = 5609251300822 := by decide
theorem cert_e1211204789718 : check e1211204789718 [[],[]] .chain = true := by decide
def e1211204789722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211204789722 : Closed e1211204789722 ∧ code e1211204789722 = 5609251300826 := by decide
theorem cert_e1211204789722 : check e1211204789722 [[],[]] .chain = true := by decide
def e1211204789878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211204789878 : Closed e1211204789878 ∧ code e1211204789878 = 5609251300982 := by decide
theorem cert_e1211204789878 : check e1211204789878 [[],[]] .chain = true := by decide
def e1211204790022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204790022 : Closed e1211204790022 ∧ code e1211204790022 = 5609251301126 := by decide
theorem cert_e1211204790022 : check e1211204790022 [[],[]] .chain = true := by decide
def e1211204790046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211204790046 : Closed e1211204790046 ∧ code e1211204790046 = 5609251301150 := by decide
theorem cert_e1211204790046 : check e1211204790046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211204790070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204790070 : Closed e1211204790070 ∧ code e1211204790070 = 5609251301174 := by decide
theorem cert_e1211204790070 : check e1211204790070 [[],[]] .chain = true := by decide
end Blc.Floor42
