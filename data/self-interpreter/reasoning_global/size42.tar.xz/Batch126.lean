import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209570545094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1209570545094 : Closed e1209570545094 ∧ code e1209570545094 = 5607617056198 := by decide
theorem cert_e1209570545094 : check e1209570545094 [[],[]] .smaller = true := by decide
def e1209570545434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1209570545434 : Closed e1209570545434 ∧ code e1209570545434 = 5607617056538 := by decide
theorem cert_e1209570545434 : check e1209570545434 [[],[]] .smaller = true := by decide
def e1209570545478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1209570545478 : Closed e1209570545478 ∧ code e1209570545478 = 5607617056582 := by decide
theorem cert_e1209570545478 : check e1209570545478 [[],[]] .smaller = true := by decide
def e1209570546462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209570546462 : Closed e1209570546462 ∧ code e1209570546462 = 5607617057566 := by decide
theorem cert_e1209570546462 : check e1209570546462 [[],[]] .smaller = true := by decide
def e1209570546630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209570546630 : Closed e1209570546630 ∧ code e1209570546630 = 5607617057734 := by decide
theorem cert_e1209570546630 : check e1209570546630 [[],[]] .smaller = true := by decide
def e1209570548934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1209570548934 : Closed e1209570548934 ∧ code e1209570548934 = 5607617060038 := by decide
theorem cert_e1209570548934 : check e1209570548934 [[],[]] .smaller = true := by decide
def e1209570550582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1209570550582 : Closed e1209570550582 ∧ code e1209570550582 = 5607617061686 := by decide
theorem cert_e1209570550582 : check e1209570550582 [[],[]] .smaller = true := by decide
def e1209570550586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1209570550586 : Closed e1209570550586 ∧ code e1209570550586 = 5607617061690 := by decide
theorem cert_e1209570550586 : check e1209570550586 [[],[]] .smaller = true := by decide
def e1209570550682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1209570550682 : Closed e1209570550682 ∧ code e1209570550682 = 5607617061786 := by decide
theorem cert_e1209570550682 : check e1209570550682 [[],[]] .smaller = true := by decide
def e1209570551350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1209570551350 : Closed e1209570551350 ∧ code e1209570551350 = 5607617062454 := by decide
theorem cert_e1209570551350 : check e1209570551350 [[],[]] .smaller = true := by decide
def e1209570551354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1209570551354 : Closed e1209570551354 ∧ code e1209570551354 = 5607617062458 := by decide
theorem cert_e1209570551354 : check e1209570551354 [[],[]] .smaller = true := by decide
def e1209570551438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1209570551438 : Closed e1209570551438 ∧ code e1209570551438 = 5607617062542 := by decide
theorem cert_e1209570551438 : check e1209570551438 [[],[]] .smaller = true := by decide
def e1209570551494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1209570551494 : Closed e1209570551494 ∧ code e1209570551494 = 5607617062598 := by decide
theorem cert_e1209570551494 : check e1209570551494 [[],[]] .smaller = true := by decide
def e1209570551578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1209570551578 : Closed e1209570551578 ∧ code e1209570551578 = 5607617062682 := by decide
theorem cert_e1209570551578 : check e1209570551578 [[],[]] .smaller = true := by decide
def e1209570551622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1209570551622 : Closed e1209570551622 ∧ code e1209570551622 = 5607617062726 := by decide
theorem cert_e1209570551622 : check e1209570551622 [[],[]] .smaller = true := by decide
def e1209570552206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209570552206 : Closed e1209570552206 ∧ code e1209570552206 = 5607617063310 := by decide
theorem cert_e1209570552206 : check e1209570552206 [[],[]] .smaller = true := by decide
def e1209570552262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209570552262 : Closed e1209570552262 ∧ code e1209570552262 = 5607617063366 := by decide
theorem cert_e1209570552262 : check e1209570552262 [[],[]] .smaller = true := by decide
def e1209570553030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1209570553030 : Closed e1209570553030 ∧ code e1209570553030 = 5607617064134 := by decide
theorem cert_e1209570553030 : check e1209570553030 [[],[]] .smaller = true := by decide
def e1209570563806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1209570563806 : Closed e1209570563806 ∧ code e1209570563806 = 5607617074910 := by decide
theorem cert_e1209570563806 : check e1209570563806 [[],[]] .smaller = true := by decide
def e1209570563830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1209570563830 : Closed e1209570563830 ∧ code e1209570563830 = 5607617074934 := by decide
theorem cert_e1209570563830 : check e1209570563830 [[],[]] .smaller = true := by decide
def e1209570563934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1209570563934 : Closed e1209570563934 ∧ code e1209570563934 = 5607617075038 := by decide
theorem cert_e1209570563934 : check e1209570563934 [[],[]] .smaller = true := by decide
def e1209570563962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1209570563962 : Closed e1209570563962 ∧ code e1209570563962 = 5607617075066 := by decide
theorem cert_e1209570563962 : check e1209570563962 [[],[]] .smaller = true := by decide
def e1209570564054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1209570564054 : Closed e1209570564054 ∧ code e1209570564054 = 5607617075158 := by decide
theorem cert_e1209570564054 : check e1209570564054 [[],[]] .smaller = true := by decide
def e1209570564058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1209570564058 : Closed e1209570564058 ∧ code e1209570564058 = 5607617075162 := by decide
theorem cert_e1209570564058 : check e1209570564058 [[],[]] .smaller = true := by decide
def e1209570564574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1209570564574 : Closed e1209570564574 ∧ code e1209570564574 = 5607617075678 := by decide
theorem cert_e1209570564574 : check e1209570564574 [[],[]] .smaller = true := by decide
def e1209570564598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1209570564598 : Closed e1209570564598 ∧ code e1209570564598 = 5607617075702 := by decide
theorem cert_e1209570564598 : check e1209570564598 [[],[]] .smaller = true := by decide
def e1209570565342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1209570565342 : Closed e1209570565342 ∧ code e1209570565342 = 5607617076446 := by decide
theorem cert_e1209570565342 : check e1209570565342 [[],[]] .smaller = true := by decide
def e1209570565370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1209570565370 : Closed e1209570565370 ∧ code e1209570565370 = 5607617076474 := by decide
theorem cert_e1209570565370 : check e1209570565370 [[],[]] .smaller = true := by decide
def e1209570565942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570565942 : Closed e1209570565942 ∧ code e1209570565942 = 5607617077046 := by decide
theorem cert_e1209570565942 : check e1209570565942 [[],[]] .smaller = true := by decide
def e1209570565946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570565946 : Closed e1209570565946 ∧ code e1209570565946 = 5607617077050 := by decide
theorem cert_e1209570565946 : check e1209570565946 [[],[]] .smaller = true := by decide
def e1209570580718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1209570580718 : Closed e1209570580718 ∧ code e1209570580718 = 5607617091822 := by decide
theorem cert_e1209570580718 : check e1209570580718 [[],[]] .smaller = true := by decide
def e1209570580726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1209570580726 : Closed e1209570580726 ∧ code e1209570580726 = 5607617091830 := by decide
theorem cert_e1209570580726 : check e1209570580726 [[],[]] .smaller = true := by decide
def e1209570581278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1209570581278 : Closed e1209570581278 ∧ code e1209570581278 = 5607617092382 := by decide
theorem cert_e1209570581278 : check e1209570581278 [[],[]] .smaller = true := by decide
def e1209570581390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1209570581390 : Closed e1209570581390 ∧ code e1209570581390 = 5607617092494 := by decide
theorem cert_e1209570581390 : check e1209570581390 [[],[]] .smaller = true := by decide
def e1209570581614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1209570581614 : Closed e1209570581614 ∧ code e1209570581614 = 5607617092718 := by decide
theorem cert_e1209570581614 : check e1209570581614 [[],[]] .smaller = true := by decide
def e1209570581626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1209570581626 : Closed e1209570581626 ∧ code e1209570581626 = 5607617092730 := by decide
theorem cert_e1209570581626 : check e1209570581626 [[],[]] .smaller = true := by decide
def e1209570581790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1209570581790 : Closed e1209570581790 ∧ code e1209570581790 = 5607617092894 := by decide
theorem cert_e1209570581790 : check e1209570581790 [[],[]] .smaller = true := by decide
def e1209570581958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1209570581958 : Closed e1209570581958 ∧ code e1209570581958 = 5607617093062 := by decide
theorem cert_e1209570581958 : check e1209570581958 [[],[]] .smaller = true := by decide
def e1209570582070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1209570582070 : Closed e1209570582070 ∧ code e1209570582070 = 5607617093174 := by decide
theorem cert_e1209570582070 : check e1209570582070 [[],[]] .smaller = true := by decide
def e1209570582074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1209570582074 : Closed e1209570582074 ∧ code e1209570582074 = 5607617093178 := by decide
theorem cert_e1209570582074 : check e1209570582074 [[],[]] .smaller = true := by decide
def e1209570582158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1209570582158 : Closed e1209570582158 ∧ code e1209570582158 = 5607617093262 := by decide
theorem cert_e1209570582158 : check e1209570582158 [[],[]] .smaller = true := by decide
def e1209570582214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1209570582214 : Closed e1209570582214 ∧ code e1209570582214 = 5607617093318 := by decide
theorem cert_e1209570582214 : check e1209570582214 [[],[]] .smaller = true := by decide
def e1209570584350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1209570584350 : Closed e1209570584350 ∧ code e1209570584350 = 5607617095454 := by decide
theorem cert_e1209570584350 : check e1209570584350 [[],[]] .smaller = true := by decide
def e1209570584462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1209570584462 : Closed e1209570584462 ∧ code e1209570584462 = 5607617095566 := by decide
theorem cert_e1209570584462 : check e1209570584462 [[],[]] .smaller = true := by decide
def e1209570587422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1209570587422 : Closed e1209570587422 ∧ code e1209570587422 = 5607617098526 := by decide
theorem cert_e1209570587422 : check e1209570587422 [[],[]] .smaller = true := by decide
def e1209570587590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1209570587590 : Closed e1209570587590 ∧ code e1209570587590 = 5607617098694 := by decide
theorem cert_e1209570587590 : check e1209570587590 [[],[]] .smaller = true := by decide
def e1209570589070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1209570589070 : Closed e1209570589070 ∧ code e1209570589070 = 5607617100174 := by decide
theorem cert_e1209570589070 : check e1209570589070 [[],[]] .smaller = true := by decide
def e1209570589126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1209570589126 : Closed e1209570589126 ∧ code e1209570589126 = 5607617100230 := by decide
theorem cert_e1209570589126 : check e1209570589126 [[],[]] .smaller = true := by decide
def e1209570626414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1209570626414 : Closed e1209570626414 ∧ code e1209570626414 = 5607617137518 := by decide
theorem cert_e1209570626414 : check e1209570626414 [[],[]] .smaller = true := by decide
def e1209570626422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1209570626422 : Closed e1209570626422 ∧ code e1209570626422 = 5607617137526 := by decide
theorem cert_e1209570626422 : check e1209570626422 [[],[]] .smaller = true := by decide
def e1209570626478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1209570626478 : Closed e1209570626478 ∧ code e1209570626478 = 5607617137582 := by decide
theorem cert_e1209570626478 : check e1209570626478 [[],[]] .smaller = true := by decide
def e1209570626490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1209570626490 : Closed e1209570626490 ∧ code e1209570626490 = 5607617137594 := by decide
theorem cert_e1209570626490 : check e1209570626490 [[],[]] .smaller = true := by decide
def e1209570626518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1209570626518 : Closed e1209570626518 ∧ code e1209570626518 = 5607617137622 := by decide
theorem cert_e1209570626518 : check e1209570626518 [[],[]] .smaller = true := by decide
def e1209570626522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1209570626522 : Closed e1209570626522 ∧ code e1209570626522 = 5607617137626 := by decide
theorem cert_e1209570626522 : check e1209570626522 [[],[]] .smaller = true := by decide
def e1209570626798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1209570626798 : Closed e1209570626798 ∧ code e1209570626798 = 5607617137902 := by decide
theorem cert_e1209570626798 : check e1209570626798 [[],[]] .smaller = true := by decide
def e1209570626806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1209570626806 : Closed e1209570626806 ∧ code e1209570626806 = 5607617137910 := by decide
theorem cert_e1209570626806 : check e1209570626806 [[],[]] .smaller = true := by decide
def e1209570627182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1209570627182 : Closed e1209570627182 ∧ code e1209570627182 = 5607617138286 := by decide
theorem cert_e1209570627182 : check e1209570627182 [[],[]] .smaller = true := by decide
def e1209570627194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1209570627194 : Closed e1209570627194 ∧ code e1209570627194 = 5607617138298 := by decide
theorem cert_e1209570627194 : check e1209570627194 [[],[]] .smaller = true := by decide
def e1209570627382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570627382 : Closed e1209570627382 ∧ code e1209570627382 = 5607617138486 := by decide
theorem cert_e1209570627382 : check e1209570627382 [[],[]] .smaller = true := by decide
def e1209570627386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570627386 : Closed e1209570627386 ∧ code e1209570627386 = 5607617138490 := by decide
theorem cert_e1209570627386 : check e1209570627386 [[],[]] .smaller = true := by decide
def e1209570634862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1209570634862 : Closed e1209570634862 ∧ code e1209570634862 = 5607617145966 := by decide
theorem cert_e1209570634862 : check e1209570634862 [[],[]] .smaller = true := by decide
def e1209570634874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1209570634874 : Closed e1209570634874 ∧ code e1209570634874 = 5607617145978 := by decide
theorem cert_e1209570634874 : check e1209570634874 [[],[]] .smaller = true := by decide
def e1209570635038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1209570635038 : Closed e1209570635038 ∧ code e1209570635038 = 5607617146142 := by decide
theorem cert_e1209570635038 : check e1209570635038 [[],[]] .smaller = true := by decide
def e1209570635206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1209570635206 : Closed e1209570635206 ∧ code e1209570635206 = 5607617146310 := by decide
theorem cert_e1209570635206 : check e1209570635206 [[],[]] .smaller = true := by decide
def e1209570635546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1209570635546 : Closed e1209570635546 ∧ code e1209570635546 = 5607617146650 := by decide
theorem cert_e1209570635546 : check e1209570635546 [[],[]] .smaller = true := by decide
def e1209570635590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1209570635590 : Closed e1209570635590 ∧ code e1209570635590 = 5607617146694 := by decide
theorem cert_e1209570635590 : check e1209570635590 [[],[]] .smaller = true := by decide
def e1209570636574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1209570636574 : Closed e1209570636574 ∧ code e1209570636574 = 5607617147678 := by decide
theorem cert_e1209570636574 : check e1209570636574 [[],[]] .smaller = true := by decide
def e1209570636742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1209570636742 : Closed e1209570636742 ∧ code e1209570636742 = 5607617147846 := by decide
theorem cert_e1209570636742 : check e1209570636742 [[],[]] .smaller = true := by decide
def e1209570639046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1209570639046 : Closed e1209570639046 ∧ code e1209570639046 = 5607617150150 := by decide
theorem cert_e1209570639046 : check e1209570639046 [[],[]] .smaller = true := by decide
def e1209570661942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1209570661942 : Closed e1209570661942 ∧ code e1209570661942 = 5607617173046 := by decide
theorem cert_e1209570661942 : check e1209570661942 [[],[]] .smaller = true := by decide
def e1209570661946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1209570661946 : Closed e1209570661946 ∧ code e1209570661946 = 5607617173050 := by decide
theorem cert_e1209570661946 : check e1209570661946 [[],[]] .smaller = true := by decide
def e1209570662030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1209570662030 : Closed e1209570662030 ∧ code e1209570662030 = 5607617173134 := by decide
theorem cert_e1209570662030 : check e1209570662030 [[],[]] .smaller = true := by decide
def e1209570662086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1209570662086 : Closed e1209570662086 ∧ code e1209570662086 = 5607617173190 := by decide
theorem cert_e1209570662086 : check e1209570662086 [[],[]] .smaller = true := by decide
def e1209570662170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1209570662170 : Closed e1209570662170 ∧ code e1209570662170 = 5607617173274 := by decide
theorem cert_e1209570662170 : check e1209570662170 [[],[]] .smaller = true := by decide
def e1209570662214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1209570662214 : Closed e1209570662214 ∧ code e1209570662214 = 5607617173318 := by decide
theorem cert_e1209570662214 : check e1209570662214 [[],[]] .smaller = true := by decide
def e1209570662798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1209570662798 : Closed e1209570662798 ∧ code e1209570662798 = 5607617173902 := by decide
theorem cert_e1209570662798 : check e1209570662798 [[],[]] .smaller = true := by decide
def e1209570662854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1209570662854 : Closed e1209570662854 ∧ code e1209570662854 = 5607617173958 := by decide
theorem cert_e1209570662854 : check e1209570662854 [[],[]] .smaller = true := by decide
def e1209570663622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1209570663622 : Closed e1209570663622 ∧ code e1209570663622 = 5607617174726 := by decide
theorem cert_e1209570663622 : check e1209570663622 [[],[]] .smaller = true := by decide
def e1209571568494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1209571568494 : Closed e1209571568494 ∧ code e1209571568494 = 5607618079598 := by decide
theorem cert_e1209571568494 : check e1209571568494 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571568502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1209571568502 : Closed e1209571568502 ∧ code e1209571568502 = 5607618079606 := by decide
theorem cert_e1209571568502 : check e1209571568502 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571568566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1209571568566 : Closed e1209571568566 ∧ code e1209571568566 = 5607618079670 := by decide
theorem cert_e1209571568566 : check e1209571568566 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571569006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209571569006 : Closed e1209571569006 ∧ code e1209571569006 = 5607618080110 := by decide
theorem cert_e1209571569006 : check e1209571569006 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209571569014 : Closed e1209571569014 ∧ code e1209571569014 = 5607618080118 := by decide
theorem cert_e1209571569014 : check e1209571569014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209571569070 : Closed e1209571569070 ∧ code e1209571569070 = 5607618080174 := by decide
theorem cert_e1209571569070 : check e1209571569070 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209571569082 : Closed e1209571569082 ∧ code e1209571569082 = 5607618080186 := by decide
theorem cert_e1209571569082 : check e1209571569082 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209571569110 : Closed e1209571569110 ∧ code e1209571569110 = 5607618080214 := by decide
theorem cert_e1209571569110 : check e1209571569110 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209571569114 : Closed e1209571569114 ∧ code e1209571569114 = 5607618080218 := by decide
theorem cert_e1209571569114 : check e1209571569114 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1209571569334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1209571569334 : Closed e1209571569334 ∧ code e1209571569334 = 5607618080438 := by decide
theorem cert_e1209571569334 : check e1209571569334 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571569366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1209571569366 : Closed e1209571569366 ∧ code e1209571569366 = 5607618080470 := by decide
theorem cert_e1209571569366 : check e1209571569366 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571569370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1209571569370 : Closed e1209571569370 ∧ code e1209571569370 = 5607618080474 := by decide
theorem cert_e1209571569370 : checkPay e1209571569370 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e1209571571054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209571571054 : Closed e1209571571054 ∧ code e1209571571054 = 5607618082158 := by decide
theorem cert_e1209571571054 : check e1209571571054 [[],[]] .sourceHead = true := by decide
def e1209571571062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209571571062 : Closed e1209571571062 ∧ code e1209571571062 = 5607618082166 := by decide
theorem cert_e1209571571062 : check e1209571571062 [[],[]] .sourceHead = true := by decide
def e1209571571118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209571571118 : Closed e1209571571118 ∧ code e1209571571118 = 5607618082222 := by decide
theorem cert_e1209571571118 : check e1209571571118 [[],[]] .sourceHead = true := by decide
def e1209571571130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209571571130 : Closed e1209571571130 ∧ code e1209571571130 = 5607618082234 := by decide
theorem cert_e1209571571130 : check e1209571571130 [[],[]] .sourceHead = true := by decide
def e1209571571158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209571571158 : Closed e1209571571158 ∧ code e1209571571158 = 5607618082262 := by decide
theorem cert_e1209571571158 : check e1209571571158 [[],[]] .sourceHead = true := by decide
def e1209571571162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209571571162 : Closed e1209571571162 ∧ code e1209571571162 = 5607618082266 := by decide
theorem cert_e1209571571162 : check e1209571571162 [[],[]] .sourceHead = true := by decide
def e1209571571374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1209571571374 : Closed e1209571571374 ∧ code e1209571571374 = 5607618082478 := by decide
theorem cert_e1209571571374 : check e1209571571374 [[],[]] .sourceHead = true := by decide
def e1209571571386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1209571571386 : Closed e1209571571386 ∧ code e1209571571386 = 5607618082490 := by decide
theorem cert_e1209571571386 : check e1209571571386 [[],[]] .sourceHead = true := by decide
def e1209571571434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1209571571434 : Closed e1209571571434 ∧ code e1209571571434 = 5607618082538 := by decide
theorem cert_e1209571571434 : check e1209571571434 [[],[]] .sourceHead = true := by decide
def e1209571571542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1209571571542 : Closed e1209571571542 ∧ code e1209571571542 = 5607618082646 := by decide
theorem cert_e1209571571542 : check e1209571571542 [[],[]] .sourceHead = true := by decide
def e1209571571546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1209571571546 : Closed e1209571571546 ∧ code e1209571571546 = 5607618082650 := by decide
theorem cert_e1209571571546 : check e1209571571546 [[],[]] .sourceHead = true := by decide
def e1209571571562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1209571571562 : Closed e1209571571562 ∧ code e1209571571562 = 5607618082666 := by decide
theorem cert_e1209571571562 : check e1209571571562 [[],[]] .sourceHead = true := by decide
def e1209571572406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1209571572406 : Closed e1209571572406 ∧ code e1209571572406 = 5607618083510 := by decide
theorem cert_e1209571572406 : check e1209571572406 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571572438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1209571572438 : Closed e1209571572438 ∧ code e1209571572438 = 5607618083542 := by decide
theorem cert_e1209571572438 : check e1209571572438 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571572442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1209571572442 : Closed e1209571572442 ∧ code e1209571572442 = 5607618083546 := by decide
theorem cert_e1209571572442 : check e1209571572442 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571572566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1209571572566 : Closed e1209571572566 ∧ code e1209571572566 = 5607618083670 := by decide
theorem cert_e1209571572566 : check e1209571572566 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571572570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1209571572570 : Closed e1209571572570 ∧ code e1209571572570 = 5607618083674 := by decide
theorem cert_e1209571572570 : check e1209571572570 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571572586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1209571572586 : Closed e1209571572586 ∧ code e1209571572586 = 5607618083690 := by decide
theorem cert_e1209571572586 : check e1209571572586 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209571577582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e1209571577582 : Closed e1209571577582 ∧ code e1209571577582 = 5607618088686 := by decide
theorem cert_e1209571577582 : check e1209571577582 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571577710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e1209571577710 : Closed e1209571577710 ∧ code e1209571577710 = 5607618088814 := by decide
theorem cert_e1209571577710 : check e1209571577710 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571577718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e1209571577718 : Closed e1209571577718 ∧ code e1209571577718 = 5607618088822 := by decide
theorem cert_e1209571577718 : check e1209571577718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571580782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1209571580782 : Closed e1209571580782 ∧ code e1209571580782 = 5607618091886 := by decide
theorem cert_e1209571580782 : check e1209571580782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571580790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1209571580790 : Closed e1209571580790 ∧ code e1209571580790 = 5607618091894 := by decide
theorem cert_e1209571580790 : check e1209571580790 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571580854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1209571580854 : Closed e1209571580854 ∧ code e1209571580854 = 5607618091958 := by decide
theorem cert_e1209571580854 : check e1209571580854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571581294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1209571581294 : Closed e1209571581294 ∧ code e1209571581294 = 5607618092398 := by decide
theorem cert_e1209571581294 : check e1209571581294 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1209571581302 : Closed e1209571581302 ∧ code e1209571581302 = 5607618092406 := by decide
theorem cert_e1209571581302 : check e1209571581302 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1209571581358 : Closed e1209571581358 ∧ code e1209571581358 = 5607618092462 := by decide
theorem cert_e1209571581358 : check e1209571581358 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1209571581370 : Closed e1209571581370 ∧ code e1209571581370 = 5607618092474 := by decide
theorem cert_e1209571581370 : check e1209571581370 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1209571581398 : Closed e1209571581398 ∧ code e1209571581398 = 5607618092502 := by decide
theorem cert_e1209571581398 : check e1209571581398 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1209571581402 : Closed e1209571581402 ∧ code e1209571581402 = 5607618092506 := by decide
theorem cert_e1209571581402 : check e1209571581402 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571581622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1209571581622 : Closed e1209571581622 ∧ code e1209571581622 = 5607618092726 := by decide
theorem cert_e1209571581622 : checkPay e1209571581622 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571581654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1209571581654 : Closed e1209571581654 ∧ code e1209571581654 = 5607618092758 := by decide
theorem cert_e1209571581654 : check e1209571581654 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571581658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1209571581658 : Closed e1209571581658 ∧ code e1209571581658 = 5607618092762 := by decide
theorem cert_e1209571581658 : check e1209571581658 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571583854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1209571583854 : Closed e1209571583854 ∧ code e1209571583854 = 5607618094958 := by decide
theorem cert_e1209571583854 : check e1209571583854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571583862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1209571583862 : Closed e1209571583862 ∧ code e1209571583862 = 5607618094966 := by decide
theorem cert_e1209571583862 : checkPay e1209571583862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571583926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1209571583926 : Closed e1209571583926 ∧ code e1209571583926 = 5607618095030 := by decide
theorem cert_e1209571583926 : checkPay e1209571583926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571585262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571585262 : Closed e1209571585262 ∧ code e1209571585262 = 5607618096366 := by decide
theorem cert_e1209571585262 : check e1209571585262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571585270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571585270 : Closed e1209571585270 ∧ code e1209571585270 = 5607618096374 := by decide
theorem cert_e1209571585270 : check e1209571585270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209571585654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571585654 : Closed e1209571585654 ∧ code e1209571585654 = 5607618096758 := by decide
theorem cert_e1209571585654 : check e1209571585654 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571586542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1209571586542 : Closed e1209571586542 ∧ code e1209571586542 = 5607618097646 := by decide
theorem cert_e1209571586542 : check e1209571586542 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571586926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209571586926 : Closed e1209571586926 ∧ code e1209571586926 = 5607618098030 := by decide
theorem cert_e1209571586926 : check e1209571586926 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571586934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209571586934 : Closed e1209571586934 ∧ code e1209571586934 = 5607618098038 := by decide
theorem cert_e1209571586934 : check e1209571586934 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571586990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209571586990 : Closed e1209571586990 ∧ code e1209571586990 = 5607618098094 := by decide
theorem cert_e1209571586990 : check e1209571586990 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209571587002 : Closed e1209571587002 ∧ code e1209571587002 = 5607618098106 := by decide
theorem cert_e1209571587002 : check e1209571587002 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209571587030 : Closed e1209571587030 ∧ code e1209571587030 = 5607618098134 := by decide
theorem cert_e1209571587030 : check e1209571587030 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209571587034 : Closed e1209571587034 ∧ code e1209571587034 = 5607618098138 := by decide
theorem cert_e1209571587034 : check e1209571587034 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571587310 : Closed e1209571587310 ∧ code e1209571587310 = 5607618098414 := by decide
theorem cert_e1209571587310 : check e1209571587310 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571587318 : Closed e1209571587318 ∧ code e1209571587318 = 5607618098422 := by decide
theorem cert_e1209571587318 : check e1209571587318 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571587694 : Closed e1209571587694 ∧ code e1209571587694 = 5607618098798 := by decide
theorem cert_e1209571587694 : check e1209571587694 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571587706 : Closed e1209571587706 ∧ code e1209571587706 = 5607618098810 := by decide
theorem cert_e1209571587706 : check e1209571587706 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1209571587870 : Closed e1209571587870 ∧ code e1209571587870 = 5607618098974 := by decide
theorem cert_e1209571587870 : check e1209571587870 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571587894 : Closed e1209571587894 ∧ code e1209571587894 = 5607618098998 := by decide
theorem cert_e1209571587894 : check e1209571587894 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571587898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571587898 : Closed e1209571587898 ∧ code e1209571587898 = 5607618099002 := by decide
theorem cert_e1209571587898 : check e1209571587898 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571588334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1209571588334 : Closed e1209571588334 ∧ code e1209571588334 = 5607618099438 := by decide
theorem cert_e1209571588334 : checkPay e1209571588334 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e1209571588342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1209571588342 : Closed e1209571588342 ∧ code e1209571588342 = 5607618099446 := by decide
theorem cert_e1209571588342 : check e1209571588342 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1209571588534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1209571588534 : Closed e1209571588534 ∧ code e1209571588534 = 5607618099638 := by decide
theorem cert_e1209571588534 : check e1209571588534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571588566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1209571588566 : Closed e1209571588566 ∧ code e1209571588566 = 5607618099670 := by decide
theorem cert_e1209571588566 : check e1209571588566 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571588570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1209571588570 : Closed e1209571588570 ∧ code e1209571588570 = 5607618099674 := by decide
theorem cert_e1209571588570 : check e1209571588570 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571588726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571588726 : Closed e1209571588726 ∧ code e1209571588726 = 5607618099830 := by decide
theorem cert_e1209571588726 : check e1209571588726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571588894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1209571588894 : Closed e1209571588894 ∧ code e1209571588894 = 5607618099998 := by decide
theorem cert_e1209571588894 : check e1209571588894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under]] .identityHead = true := by decide
def e1209571588918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571588918 : Closed e1209571588918 ∧ code e1209571588918 = 5607618100022 := by decide
theorem cert_e1209571588918 : check e1209571588918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571588922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571588922 : Closed e1209571588922 ∧ code e1209571588922 = 5607618100026 := by decide
theorem cert_e1209571588922 : check e1209571588922 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571589006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1209571589006 : Closed e1209571589006 ∧ code e1209571589006 = 5607618100110 := by decide
theorem cert_e1209571589006 : check e1209571589006 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571591918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1209571591918 : Closed e1209571591918 ∧ code e1209571591918 = 5607618103022 := by decide
theorem cert_e1209571591918 : check e1209571591918 [[],[]] .sourceHead = true := by decide
def e1209571592110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e1209571592110 : Closed e1209571592110 ∧ code e1209571592110 = 5607618103214 := by decide
theorem cert_e1209571592110 : check e1209571592110 [[],[]] .sourceHead = true := by decide
def e1209571592122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e1209571592122 : Closed e1209571592122 ∧ code e1209571592122 = 5607618103226 := by decide
theorem cert_e1209571592122 : check e1209571592122 [[],[]] .sourceHead = true := by decide
def e1209571593582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1209571593582 : Closed e1209571593582 ∧ code e1209571593582 = 5607618104686 := by decide
theorem cert_e1209571593582 : check e1209571593582 [[],[]] .sourceHead = true := by decide
def e1209571593590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1209571593590 : Closed e1209571593590 ∧ code e1209571593590 = 5607618104694 := by decide
theorem cert_e1209571593590 : check e1209571593590 [[],[]] .sourceHead = true := by decide
def e1209571593646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1209571593646 : Closed e1209571593646 ∧ code e1209571593646 = 5607618104750 := by decide
theorem cert_e1209571593646 : check e1209571593646 [[],[]] .sourceHead = true := by decide
def e1209571593658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1209571593658 : Closed e1209571593658 ∧ code e1209571593658 = 5607618104762 := by decide
theorem cert_e1209571593658 : check e1209571593658 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
