import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186925466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186925466 : Closed e1211186925466 ∧ code e1211186925466 = 5609233436570 := by decide
theorem cert_e1211186925466 : check e1211186925466 [[],[]] .three = true := by decide
def e1211186931082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186931082 : Closed e1211186931082 ∧ code e1211186931082 = 5609233442186 := by decide
theorem cert_e1211186931082 : check e1211186931082 [[],[]] .three = true := by decide
def e1211186931106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186931106 : Closed e1211186931106 ∧ code e1211186931106 = 5609233442210 := by decide
theorem cert_e1211186931106 : check e1211186931106 [[],[]] .three = true := by decide
def e1211186931118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211186931118 : Closed e1211186931118 ∧ code e1211186931118 = 5609233442222 := by decide
theorem cert_e1211186931118 : check e1211186931118 [[],[]] .three = true := by decide
def e1211186931126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211186931126 : Closed e1211186931126 ∧ code e1211186931126 = 5609233442230 := by decide
theorem cert_e1211186931126 : check e1211186931126 [[],[]] .three = true := by decide
def e1211186931130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211186931130 : Closed e1211186931130 ∧ code e1211186931130 = 5609233442234 := by decide
theorem cert_e1211186931130 : check e1211186931130 [[],[]] .three = true := by decide
def e1211186931158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211186931158 : Closed e1211186931158 ∧ code e1211186931158 = 5609233442262 := by decide
theorem cert_e1211186931158 : check e1211186931158 [[],[]] .three = true := by decide
def e1211186931162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211186931162 : Closed e1211186931162 ∧ code e1211186931162 = 5609233442266 := by decide
theorem cert_e1211186931162 : check e1211186931162 [[],[]] .three = true := by decide
def e1211186931178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211186931178 : Closed e1211186931178 ∧ code e1211186931178 = 5609233442282 := by decide
theorem cert_e1211186931178 : check e1211186931178 [[],[]] .three = true := by decide
def e1211186931214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186931214 : Closed e1211186931214 ∧ code e1211186931214 = 5609233442318 := by decide
theorem cert_e1211186931214 : check e1211186931214 [[],[]] .three = true := by decide
def e1211186931226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186931226 : Closed e1211186931226 ∧ code e1211186931226 = 5609233442330 := by decide
theorem cert_e1211186931226 : check e1211186931226 [[],[]] .three = true := by decide
def e1211186931262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1211186931262 : Closed e1211186931262 ∧ code e1211186931262 = 5609233442366 := by decide
theorem cert_e1211186931262 : check e1211186931262 [[],[]] .three = true := by decide
def e1211186931298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186931298 : Closed e1211186931298 ∧ code e1211186931298 = 5609233442402 := by decide
theorem cert_e1211186931298 : check e1211186931298 [[],[]] .three = true := by decide
def e1211186931310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186931310 : Closed e1211186931310 ∧ code e1211186931310 = 5609233442414 := by decide
theorem cert_e1211186931310 : check e1211186931310 [[],[]] .three = true := by decide
def e1211186931318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186931318 : Closed e1211186931318 ∧ code e1211186931318 = 5609233442422 := by decide
theorem cert_e1211186931318 : check e1211186931318 [[],[]] .three = true := by decide
def e1211186931322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186931322 : Closed e1211186931322 ∧ code e1211186931322 = 5609233442426 := by decide
theorem cert_e1211186931322 : check e1211186931322 [[],[]] .three = true := by decide
def e1211186931486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211186931486 : Closed e1211186931486 ∧ code e1211186931486 = 5609233442590 := by decide
theorem cert_e1211186931486 : check e1211186931486 [[],[]] .three = true := by decide
def e1211186931510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186931510 : Closed e1211186931510 ∧ code e1211186931510 = 5609233442614 := by decide
theorem cert_e1211186931510 : check e1211186931510 [[],[]] .three = true := by decide
def e1211186931514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186931514 : Closed e1211186931514 ∧ code e1211186931514 = 5609233442618 := by decide
theorem cert_e1211186931514 : check e1211186931514 [[],[]] .three = true := by decide
def e1211186931598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211186931598 : Closed e1211186931598 ∧ code e1211186931598 = 5609233442702 := by decide
theorem cert_e1211186931598 : check e1211186931598 [[],[]] .three = true := by decide
def e1211186931610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186931610 : Closed e1211186931610 ∧ code e1211186931610 = 5609233442714 := by decide
theorem cert_e1211186931610 : check e1211186931610 [[],[]] .three = true := by decide
def e1211186931654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1211186931654 : Closed e1211186931654 ∧ code e1211186931654 = 5609233442758 := by decide
theorem cert_e1211186931654 : check e1211186931654 [[],[]] .three = true := by decide
def e1211186941558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186941558 : Closed e1211186941558 ∧ code e1211186941558 = 5609233452662 := by decide
theorem cert_e1211186941558 : check e1211186941558 [[],[]] .smaller = true := by decide
def e1211186941750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186941750 : Closed e1211186941750 ∧ code e1211186941750 = 5609233452854 := by decide
theorem cert_e1211186941750 : check e1211186941750 [[],[]] .smaller = true := by decide
def e1211186941754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186941754 : Closed e1211186941754 ∧ code e1211186941754 = 5609233452858 := by decide
theorem cert_e1211186941754 : check e1211186941754 [[],[]] .smaller = true := by decide
def e1211186943670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e1211186943670 : Closed e1211186943670 ∧ code e1211186943670 = 5609233454774 := by decide
theorem cert_e1211186943670 : check e1211186943670 [[],[]] .smaller = true := by decide
def e1211186943674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e1211186943674 : Closed e1211186943674 ∧ code e1211186943674 = 5609233454778 := by decide
theorem cert_e1211186943674 : check e1211186943674 [[],[]] .smaller = true := by decide
def e1211186943702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186943702 : Closed e1211186943702 ∧ code e1211186943702 = 5609233454806 := by decide
theorem cert_e1211186943702 : check e1211186943702 [[],[]] .smaller = true := by decide
def e1211186943722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186943722 : Closed e1211186943722 ∧ code e1211186943722 = 5609233454826 := by decide
theorem cert_e1211186943722 : check e1211186943722 [[],[]] .smaller = true := by decide
def e1211186943830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186943830 : Closed e1211186943830 ∧ code e1211186943830 = 5609233454934 := by decide
theorem cert_e1211186943830 : check e1211186943830 [[],[]] .smaller = true := by decide
def e1211186943914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186943914 : Closed e1211186943914 ∧ code e1211186943914 = 5609233455018 := by decide
theorem cert_e1211186943914 : check e1211186943914 [[],[]] .smaller = true := by decide
def e1211186944438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e1211186944438 : Closed e1211186944438 ∧ code e1211186944438 = 5609233455542 := by decide
theorem cert_e1211186944438 : check e1211186944438 [[],[]] .smaller = true := by decide
def e1211186944442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e1211186944442 : Closed e1211186944442 ∧ code e1211186944442 = 5609233455546 := by decide
theorem cert_e1211186944442 : check e1211186944442 [[],[]] .smaller = true := by decide
def e1211186944470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e1211186944470 : Closed e1211186944470 ∧ code e1211186944470 = 5609233455574 := by decide
theorem cert_e1211186944470 : check e1211186944470 [[],[]] .smaller = true := by decide
def e1211186944490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e1211186944490 : Closed e1211186944490 ∧ code e1211186944490 = 5609233455594 := by decide
theorem cert_e1211186944490 : check e1211186944490 [[],[]] .smaller = true := by decide
def e1211186944822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186944822 : Closed e1211186944822 ∧ code e1211186944822 = 5609233455926 := by decide
theorem cert_e1211186944822 : check e1211186944822 [[],[]] .smaller = true := by decide
def e1211186944826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186944826 : Closed e1211186944826 ∧ code e1211186944826 = 5609233455930 := by decide
theorem cert_e1211186944826 : check e1211186944826 [[],[]] .smaller = true := by decide
def e1211186944922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186944922 : Closed e1211186944922 ∧ code e1211186944922 = 5609233456026 := by decide
theorem cert_e1211186944922 : check e1211186944922 [[],[]] .smaller = true := by decide
def e1211186945142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211186945142 : Closed e1211186945142 ∧ code e1211186945142 = 5609233456246 := by decide
theorem cert_e1211186945142 : check e1211186945142 [[],[]] .smaller = true := by decide
def e1211186945146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186945146 : Closed e1211186945146 ∧ code e1211186945146 = 5609233456250 := by decide
theorem cert_e1211186945146 : check e1211186945146 [[],[]] .smaller = true := by decide
def e1211186945238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e1211186945238 : Closed e1211186945238 ∧ code e1211186945238 = 5609233456342 := by decide
theorem cert_e1211186945238 : check e1211186945238 [[],[]] .smaller = true := by decide
def e1211186945334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186945334 : Closed e1211186945334 ∧ code e1211186945334 = 5609233456438 := by decide
theorem cert_e1211186945334 : check e1211186945334 [[],[]] .smaller = true := by decide
def e1211186945338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186945338 : Closed e1211186945338 ∧ code e1211186945338 = 5609233456442 := by decide
theorem cert_e1211186945338 : check e1211186945338 [[],[]] .smaller = true := by decide
def e1211186945422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211186945422 : Closed e1211186945422 ∧ code e1211186945422 = 5609233456526 := by decide
theorem cert_e1211186945422 : check e1211186945422 [[],[]] .smaller = true := by decide
def e1211186945478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186945478 : Closed e1211186945478 ∧ code e1211186945478 = 5609233456582 := by decide
theorem cert_e1211186945478 : check e1211186945478 [[],[]] .smaller = true := by decide
def e1211186945594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186945594 : Closed e1211186945594 ∧ code e1211186945594 = 5609233456698 := by decide
theorem cert_e1211186945594 : check e1211186945594 [[],[]] .smaller = true := by decide
def e1211186945642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e1211186945642 : Closed e1211186945642 ∧ code e1211186945642 = 5609233456746 := by decide
theorem cert_e1211186945642 : check e1211186945642 [[],[]] .smaller = true := by decide
def e1211186945690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186945690 : Closed e1211186945690 ∧ code e1211186945690 = 5609233456794 := by decide
theorem cert_e1211186945690 : check e1211186945690 [[],[]] .smaller = true := by decide
def e1211186945734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186945734 : Closed e1211186945734 ∧ code e1211186945734 = 5609233456838 := by decide
theorem cert_e1211186945734 : check e1211186945734 [[],[]] .smaller = true := by decide
def e1211186947510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211186947510 : Closed e1211186947510 ∧ code e1211186947510 = 5609233458614 := by decide
theorem cert_e1211186947510 : check e1211186947510 [[],[]] .smaller = true := by decide
def e1211186947542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211186947542 : Closed e1211186947542 ∧ code e1211186947542 = 5609233458646 := by decide
theorem cert_e1211186947542 : check e1211186947542 [[],[]] .smaller = true := by decide
def e1211186947546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211186947546 : Closed e1211186947546 ∧ code e1211186947546 = 5609233458650 := by decide
theorem cert_e1211186947546 : check e1211186947546 [[],[]] .smaller = true := by decide
def e1211186947702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186947702 : Closed e1211186947702 ∧ code e1211186947702 = 5609233458806 := by decide
theorem cert_e1211186947702 : check e1211186947702 [[],[]] .smaller = true := by decide
def e1211186947894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186947894 : Closed e1211186947894 ∧ code e1211186947894 = 5609233458998 := by decide
theorem cert_e1211186947894 : check e1211186947894 [[],[]] .smaller = true := by decide
def e1211186947898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186947898 : Closed e1211186947898 ∧ code e1211186947898 = 5609233459002 := by decide
theorem cert_e1211186947898 : check e1211186947898 [[],[]] .smaller = true := by decide
def e1211186950382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186950382 : Closed e1211186950382 ∧ code e1211186950382 = 5609233461486 := by decide
theorem cert_e1211186950382 : check e1211186950382 [[],[]] .smaller = true := by decide
def e1211186950390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186950390 : Closed e1211186950390 ∧ code e1211186950390 = 5609233461494 := by decide
theorem cert_e1211186950390 : check e1211186950390 [[],[]] .smaller = true := by decide
def e1211186950870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211186950870 : Closed e1211186950870 ∧ code e1211186950870 = 5609233461974 := by decide
theorem cert_e1211186950870 : check e1211186950870 [[],[]] .smaller = true := by decide
def e1211186950874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211186950874 : Closed e1211186950874 ∧ code e1211186950874 = 5609233461978 := by decide
theorem cert_e1211186950874 : check e1211186950874 [[],[]] .smaller = true := by decide
def e1211186950890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211186950890 : Closed e1211186950890 ∧ code e1211186950890 = 5609233461994 := by decide
theorem cert_e1211186950890 : check e1211186950890 [[],[]] .smaller = true := by decide
def e1211186950966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186950966 : Closed e1211186950966 ∧ code e1211186950966 = 5609233462070 := by decide
theorem cert_e1211186950966 : check e1211186950966 [[],[]] .smaller = true := by decide
def e1211186950970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186950970 : Closed e1211186950970 ∧ code e1211186950970 = 5609233462074 := by decide
theorem cert_e1211186950970 : check e1211186950970 [[],[]] .smaller = true := by decide
def e1211186951054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211186951054 : Closed e1211186951054 ∧ code e1211186951054 = 5609233462158 := by decide
theorem cert_e1211186951054 : check e1211186951054 [[],[]] .smaller = true := by decide
def e1211186951066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186951066 : Closed e1211186951066 ∧ code e1211186951066 = 5609233462170 := by decide
theorem cert_e1211186951066 : check e1211186951066 [[],[]] .smaller = true := by decide
def e1211186951134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186951134 : Closed e1211186951134 ∧ code e1211186951134 = 5609233462238 := by decide
theorem cert_e1211186951134 : check e1211186951134 [[],[]] .three = true := by decide
def e1211186951150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186951150 : Closed e1211186951150 ∧ code e1211186951150 = 5609233462254 := by decide
theorem cert_e1211186951150 : check e1211186951150 [[],[]] .three = true := by decide
def e1211186952310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186952310 : Closed e1211186952310 ∧ code e1211186952310 = 5609233463414 := by decide
theorem cert_e1211186952310 : check e1211186952310 [[],[]] .smaller = true := by decide
def e1211186952554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211186952554 : Closed e1211186952554 ∧ code e1211186952554 = 5609233463658 := by decide
theorem cert_e1211186952554 : check e1211186952554 [[],[]] .smaller = true := by decide
def e1211186952590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186952590 : Closed e1211186952590 ∧ code e1211186952590 = 5609233463694 := by decide
theorem cert_e1211186952590 : check e1211186952590 [[],[]] .smaller = true := by decide
def e1211186952602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186952602 : Closed e1211186952602 ∧ code e1211186952602 = 5609233463706 := by decide
theorem cert_e1211186952602 : check e1211186952602 [[],[]] .smaller = true := by decide
def e1211186952646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186952646 : Closed e1211186952646 ∧ code e1211186952646 = 5609233463750 := by decide
theorem cert_e1211186952646 : check e1211186952646 [[],[]] .smaller = true := by decide
def e1211186952670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186952670 : Closed e1211186952670 ∧ code e1211186952670 = 5609233463774 := by decide
theorem cert_e1211186952670 : check e1211186952670 [[],[]] .three = true := by decide
def e1211186952694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186952694 : Closed e1211186952694 ∧ code e1211186952694 = 5609233463798 := by decide
theorem cert_e1211186952694 : check e1211186952694 [[],[]] .three = true := by decide
def e1211186953438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186953438 : Closed e1211186953438 ∧ code e1211186953438 = 5609233464542 := by decide
theorem cert_e1211186953438 : check e1211186953438 [[],[]] .three = true := by decide
def e1211186953466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186953466 : Closed e1211186953466 ∧ code e1211186953466 = 5609233464570 := by decide
theorem cert_e1211186953466 : check e1211186953466 [[],[]] .three = true := by decide
def e1211186953838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186953838 : Closed e1211186953838 ∧ code e1211186953838 = 5609233464942 := by decide
theorem cert_e1211186953838 : check e1211186953838 [[],[]] .three = true := by decide
def e1211186953846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186953846 : Closed e1211186953846 ∧ code e1211186953846 = 5609233464950 := by decide
theorem cert_e1211186953846 : check e1211186953846 [[],[]] .three = true := by decide
def e1211186953850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186953850 : Closed e1211186953850 ∧ code e1211186953850 = 5609233464954 := by decide
theorem cert_e1211186953850 : check e1211186953850 [[],[]] .three = true := by decide
def e1211186960566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 1)))))))
theorem wire_e1211186960566 : Closed e1211186960566 ∧ code e1211186960566 = 5609233471670 := by decide
theorem cert_e1211186960566 : check e1211186960566 [[],[]] .smaller = true := by decide
def e1211186960598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e1211186960598 : Closed e1211186960598 ∧ code e1211186960598 = 5609233471702 := by decide
theorem cert_e1211186960598 : check e1211186960598 [[],[]] .smaller = true := by decide
def e1211186960602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e1211186960602 : Closed e1211186960602 ∧ code e1211186960602 = 5609233471706 := by decide
theorem cert_e1211186960602 : check e1211186960602 [[],[]] .smaller = true := by decide
def e1211186960618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e1211186960618 : Closed e1211186960618 ∧ code e1211186960618 = 5609233471722 := by decide
theorem cert_e1211186960618 : check e1211186960618 [[],[]] .smaller = true := by decide
def e1211186960950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186960950 : Closed e1211186960950 ∧ code e1211186960950 = 5609233472054 := by decide
theorem cert_e1211186960950 : check e1211186960950 [[],[]] .smaller = true := by decide
def e1211186960954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186960954 : Closed e1211186960954 ∧ code e1211186960954 = 5609233472058 := by decide
theorem cert_e1211186960954 : check e1211186960954 [[],[]] .smaller = true := by decide
def e1211186961038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186961038 : Closed e1211186961038 ∧ code e1211186961038 = 5609233472142 := by decide
theorem cert_e1211186961038 : check e1211186961038 [[],[]] .smaller = true := by decide
def e1211186961094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186961094 : Closed e1211186961094 ∧ code e1211186961094 = 5609233472198 := by decide
theorem cert_e1211186961094 : check e1211186961094 [[],[]] .smaller = true := by decide
def e1211186961118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e1211186961118 : Closed e1211186961118 ∧ code e1211186961118 = 5609233472222 := by decide
theorem cert_e1211186961118 : check e1211186961118 [[],[]] .three = true := by decide
def e1211186961142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e1211186961142 : Closed e1211186961142 ∧ code e1211186961142 = 5609233472246 := by decide
theorem cert_e1211186961142 : check e1211186961142 [[],[]] .three = true := by decide
def e1211186961174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186961174 : Closed e1211186961174 ∧ code e1211186961174 = 5609233472278 := by decide
theorem cert_e1211186961174 : check e1211186961174 [[],[]] .smaller = true := by decide
def e1211186961178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186961178 : Closed e1211186961178 ∧ code e1211186961178 = 5609233472282 := by decide
theorem cert_e1211186961178 : check e1211186961178 [[],[]] .smaller = true := by decide
def e1211186961222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186961222 : Closed e1211186961222 ∧ code e1211186961222 = 5609233472326 := by decide
theorem cert_e1211186961222 : check e1211186961222 [[],[]] .smaller = true := by decide
def e1211186961246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e1211186961246 : Closed e1211186961246 ∧ code e1211186961246 = 5609233472350 := by decide
theorem cert_e1211186961246 : check e1211186961246 [[],[]] .three = true := by decide
def e1211186961250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186961250 : Closed e1211186961250 ∧ code e1211186961250 = 5609233472354 := by decide
theorem cert_e1211186961250 : check e1211186961250 [[],[]] .smaller = true := by decide
def e1211186961262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e1211186961262 : Closed e1211186961262 ∧ code e1211186961262 = 5609233472366 := by decide
theorem cert_e1211186961262 : check e1211186961262 [[],[]] .smaller = true := by decide
def e1211186961270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e1211186961270 : Closed e1211186961270 ∧ code e1211186961270 = 5609233472374 := by decide
theorem cert_e1211186961270 : check e1211186961270 [[],[]] .smaller = true := by decide
def e1211186961274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e1211186961274 : Closed e1211186961274 ∧ code e1211186961274 = 5609233472378 := by decide
theorem cert_e1211186961274 : check e1211186961274 [[],[]] .three = true := by decide
def e1211186961334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e1211186961334 : Closed e1211186961334 ∧ code e1211186961334 = 5609233472438 := by decide
theorem cert_e1211186961334 : check e1211186961334 [[],[]] .smaller = true := by decide
def e1211186961366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e1211186961366 : Closed e1211186961366 ∧ code e1211186961366 = 5609233472470 := by decide
theorem cert_e1211186961366 : check e1211186961366 [[],[]] .three = true := by decide
def e1211186961370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e1211186961370 : Closed e1211186961370 ∧ code e1211186961370 = 5609233472474 := by decide
theorem cert_e1211186961370 : check e1211186961370 [[],[]] .three = true := by decide
def e1211186961494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e1211186961494 : Closed e1211186961494 ∧ code e1211186961494 = 5609233472598 := by decide
theorem cert_e1211186961494 : check e1211186961494 [[],[]] .smaller = true := by decide
def e1211186961498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e1211186961498 : Closed e1211186961498 ∧ code e1211186961498 = 5609233472602 := by decide
theorem cert_e1211186961498 : check e1211186961498 [[],[]] .smaller = true := by decide
def e1211186961514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e1211186961514 : Closed e1211186961514 ∧ code e1211186961514 = 5609233472618 := by decide
theorem cert_e1211186961514 : check e1211186961514 [[],[]] .smaller = true := by decide
def e1211186961686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186961686 : Closed e1211186961686 ∧ code e1211186961686 = 5609233472790 := by decide
theorem cert_e1211186961686 : check e1211186961686 [[],[]] .smaller = true := by decide
def e1211186961690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186961690 : Closed e1211186961690 ∧ code e1211186961690 = 5609233472794 := by decide
theorem cert_e1211186961690 : check e1211186961690 [[],[]] .smaller = true := by decide
def e1211186961734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186961734 : Closed e1211186961734 ∧ code e1211186961734 = 5609233472838 := by decide
theorem cert_e1211186961734 : check e1211186961734 [[],[]] .smaller = true := by decide
def e1211186961758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e1211186961758 : Closed e1211186961758 ∧ code e1211186961758 = 5609233472862 := by decide
theorem cert_e1211186961758 : check e1211186961758 [[],[]] .three = true := by decide
def e1211186961762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186961762 : Closed e1211186961762 ∧ code e1211186961762 = 5609233472866 := by decide
theorem cert_e1211186961762 : check e1211186961762 [[],[]] .smaller = true := by decide
def e1211186961774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211186961774 : Closed e1211186961774 ∧ code e1211186961774 = 5609233472878 := by decide
theorem cert_e1211186961774 : check e1211186961774 [[],[]] .smaller = true := by decide
def e1211186961782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211186961782 : Closed e1211186961782 ∧ code e1211186961782 = 5609233472886 := by decide
theorem cert_e1211186961782 : check e1211186961782 [[],[]] .smaller = true := by decide
def e1211186961786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e1211186961786 : Closed e1211186961786 ∧ code e1211186961786 = 5609233472890 := by decide
theorem cert_e1211186961786 : check e1211186961786 [[],[]] .three = true := by decide
def e1211186961802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186961802 : Closed e1211186961802 ∧ code e1211186961802 = 5609233472906 := by decide
theorem cert_e1211186961802 : check e1211186961802 [[],[]] .smaller = true := by decide
def e1211186961826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186961826 : Closed e1211186961826 ∧ code e1211186961826 = 5609233472930 := by decide
theorem cert_e1211186961826 : check e1211186961826 [[],[]] .smaller = true := by decide
def e1211186961838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211186961838 : Closed e1211186961838 ∧ code e1211186961838 = 5609233472942 := by decide
theorem cert_e1211186961838 : check e1211186961838 [[],[]] .smaller = true := by decide
def e1211186961850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211186961850 : Closed e1211186961850 ∧ code e1211186961850 = 5609233472954 := by decide
theorem cert_e1211186961850 : check e1211186961850 [[],[]] .smaller = true := by decide
def e1211186961878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211186961878 : Closed e1211186961878 ∧ code e1211186961878 = 5609233472982 := by decide
theorem cert_e1211186961878 : check e1211186961878 [[],[]] .smaller = true := by decide
def e1211186961882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211186961882 : Closed e1211186961882 ∧ code e1211186961882 = 5609233472986 := by decide
theorem cert_e1211186961882 : check e1211186961882 [[],[]] .smaller = true := by decide
def e1211186961898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e1211186961898 : Closed e1211186961898 ∧ code e1211186961898 = 5609233473002 := by decide
theorem cert_e1211186961898 : check e1211186961898 [[],[]] .three = true := by decide
def e1211186962102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211186962102 : Closed e1211186962102 ∧ code e1211186962102 = 5609233473206 := by decide
theorem cert_e1211186962102 : check e1211186962102 [[],[]] .smaller = true := by decide
def e1211186962134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211186962134 : Closed e1211186962134 ∧ code e1211186962134 = 5609233473238 := by decide
theorem cert_e1211186962134 : check e1211186962134 [[],[]] .smaller = true := by decide
def e1211186962138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211186962138 : Closed e1211186962138 ∧ code e1211186962138 = 5609233473242 := by decide
theorem cert_e1211186962138 : check e1211186962138 [[],[]] .smaller = true := by decide
def e1211186962262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211186962262 : Closed e1211186962262 ∧ code e1211186962262 = 5609233473366 := by decide
theorem cert_e1211186962262 : check e1211186962262 [[],[]] .three = true := by decide
def e1211186962266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211186962266 : Closed e1211186962266 ∧ code e1211186962266 = 5609233473370 := by decide
theorem cert_e1211186962266 : check e1211186962266 [[],[]] .three = true := by decide
def e1211186962282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211186962282 : Closed e1211186962282 ∧ code e1211186962282 = 5609233473386 := by decide
theorem cert_e1211186962282 : check e1211186962282 [[],[]] .three = true := by decide
def e1211186962678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211186962678 : Closed e1211186962678 ∧ code e1211186962678 = 5609233473782 := by decide
theorem cert_e1211186962678 : check e1211186962678 [[],[]] .smaller = true := by decide
def e1211186962870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e1211186962870 : Closed e1211186962870 ∧ code e1211186962870 = 5609233473974 := by decide
theorem cert_e1211186962870 : check e1211186962870 [[],[]] .smaller = true := by decide
def e1211186962874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e1211186962874 : Closed e1211186962874 ∧ code e1211186962874 = 5609233473978 := by decide
theorem cert_e1211186962874 : check e1211186962874 [[],[]] .smaller = true := by decide
def e1211186962902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e1211186962902 : Closed e1211186962902 ∧ code e1211186962902 = 5609233474006 := by decide
theorem cert_e1211186962902 : check e1211186962902 [[],[]] .smaller = true := by decide
def e1211186962922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e1211186962922 : Closed e1211186962922 ∧ code e1211186962922 = 5609233474026 := by decide
theorem cert_e1211186962922 : check e1211186962922 [[],[]] .smaller = true := by decide
def e1211186963062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186963062 : Closed e1211186963062 ∧ code e1211186963062 = 5609233474166 := by decide
theorem cert_e1211186963062 : check e1211186963062 [[],[]] .smaller = true := by decide
def e1211186963254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186963254 : Closed e1211186963254 ∧ code e1211186963254 = 5609233474358 := by decide
theorem cert_e1211186963254 : check e1211186963254 [[],[]] .smaller = true := by decide
def e1211186963258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186963258 : Closed e1211186963258 ∧ code e1211186963258 = 5609233474362 := by decide
theorem cert_e1211186963258 : check e1211186963258 [[],[]] .smaller = true := by decide
def e1211186963342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211186963342 : Closed e1211186963342 ∧ code e1211186963342 = 5609233474446 := by decide
theorem cert_e1211186963342 : check e1211186963342 [[],[]] .smaller = true := by decide
def e1211186963354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186963354 : Closed e1211186963354 ∧ code e1211186963354 = 5609233474458 := by decide
theorem cert_e1211186963354 : check e1211186963354 [[],[]] .smaller = true := by decide
def e1211186963422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e1211186963422 : Closed e1211186963422 ∧ code e1211186963422 = 5609233474526 := by decide
theorem cert_e1211186963422 : check e1211186963422 [[],[]] .three = true := by decide
def e1211186963438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e1211186963438 : Closed e1211186963438 ∧ code e1211186963438 = 5609233474542 := by decide
theorem cert_e1211186963438 : check e1211186963438 [[],[]] .three = true := by decide
def e1211186964022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211186964022 : Closed e1211186964022 ∧ code e1211186964022 = 5609233475126 := by decide
theorem cert_e1211186964022 : check e1211186964022 [[],[]] .smaller = true := by decide
def e1211186964026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186964026 : Closed e1211186964026 ∧ code e1211186964026 = 5609233475130 := by decide
theorem cert_e1211186964026 : check e1211186964026 [[],[]] .smaller = true := by decide
def e1211186964110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211186964110 : Closed e1211186964110 ∧ code e1211186964110 = 5609233475214 := by decide
theorem cert_e1211186964110 : check e1211186964110 [[],[]] .smaller = true := by decide
def e1211186964166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186964166 : Closed e1211186964166 ∧ code e1211186964166 = 5609233475270 := by decide
theorem cert_e1211186964166 : check e1211186964166 [[],[]] .smaller = true := by decide
def e1211186964190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e1211186964190 : Closed e1211186964190 ∧ code e1211186964190 = 5609233475294 := by decide
theorem cert_e1211186964190 : check e1211186964190 [[],[]] .three = true := by decide
def e1211186964214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211186964214 : Closed e1211186964214 ∧ code e1211186964214 = 5609233475318 := by decide
theorem cert_e1211186964214 : check e1211186964214 [[],[]] .three = true := by decide
def e1211186964246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186964246 : Closed e1211186964246 ∧ code e1211186964246 = 5609233475350 := by decide
theorem cert_e1211186964246 : check e1211186964246 [[],[]] .smaller = true := by decide
def e1211186964250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186964250 : Closed e1211186964250 ∧ code e1211186964250 = 5609233475354 := by decide
theorem cert_e1211186964250 : check e1211186964250 [[],[]] .smaller = true := by decide
def e1211186964294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186964294 : Closed e1211186964294 ∧ code e1211186964294 = 5609233475398 := by decide
theorem cert_e1211186964294 : check e1211186964294 [[],[]] .smaller = true := by decide
def e1211186964318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e1211186964318 : Closed e1211186964318 ∧ code e1211186964318 = 5609233475422 := by decide
theorem cert_e1211186964318 : check e1211186964318 [[],[]] .three = true := by decide
def e1211186964322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186964322 : Closed e1211186964322 ∧ code e1211186964322 = 5609233475426 := by decide
theorem cert_e1211186964322 : check e1211186964322 [[],[]] .smaller = true := by decide
def e1211186964334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211186964334 : Closed e1211186964334 ∧ code e1211186964334 = 5609233475438 := by decide
theorem cert_e1211186964334 : check e1211186964334 [[],[]] .smaller = true := by decide
def e1211186964342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211186964342 : Closed e1211186964342 ∧ code e1211186964342 = 5609233475446 := by decide
theorem cert_e1211186964342 : check e1211186964342 [[],[]] .smaller = true := by decide
def e1211186964346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1211186964346 : Closed e1211186964346 ∧ code e1211186964346 = 5609233475450 := by decide
theorem cert_e1211186964346 : check e1211186964346 [[],[]] .three = true := by decide
def e1211186964406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211186964406 : Closed e1211186964406 ∧ code e1211186964406 = 5609233475510 := by decide
theorem cert_e1211186964406 : check e1211186964406 [[],[]] .smaller = true := by decide
def e1211186964438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211186964438 : Closed e1211186964438 ∧ code e1211186964438 = 5609233475542 := by decide
theorem cert_e1211186964438 : check e1211186964438 [[],[]] .three = true := by decide
def e1211186964442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1211186964442 : Closed e1211186964442 ∧ code e1211186964442 = 5609233475546 := by decide
theorem cert_e1211186964442 : check e1211186964442 [[],[]] .three = true := by decide
def e1211186964590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186964590 : Closed e1211186964590 ∧ code e1211186964590 = 5609233475694 := by decide
theorem cert_e1211186964590 : check e1211186964590 [[],[]] .smaller = true := by decide
def e1211186964602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186964602 : Closed e1211186964602 ∧ code e1211186964602 = 5609233475706 := by decide
theorem cert_e1211186964602 : check e1211186964602 [[],[]] .smaller = true := by decide
def e1211186964878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186964878 : Closed e1211186964878 ∧ code e1211186964878 = 5609233475982 := by decide
theorem cert_e1211186964878 : check e1211186964878 [[],[]] .smaller = true := by decide
def e1211186964934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186964934 : Closed e1211186964934 ∧ code e1211186964934 = 5609233476038 := by decide
theorem cert_e1211186964934 : check e1211186964934 [[],[]] .smaller = true := by decide
def e1211186964958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186964958 : Closed e1211186964958 ∧ code e1211186964958 = 5609233476062 := by decide
theorem cert_e1211186964958 : check e1211186964958 [[],[]] .three = true := by decide
def e1211186964982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186964982 : Closed e1211186964982 ∧ code e1211186964982 = 5609233476086 := by decide
theorem cert_e1211186964982 : check e1211186964982 [[],[]] .three = true := by decide
def e1211186965534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186965534 : Closed e1211186965534 ∧ code e1211186965534 = 5609233476638 := by decide
theorem cert_e1211186965534 : check e1211186965534 [[],[]] .smaller = true := by decide
def e1211186965558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186965558 : Closed e1211186965558 ∧ code e1211186965558 = 5609233476662 := by decide
theorem cert_e1211186965558 : check e1211186965558 [[],[]] .smaller = true := by decide
end Blc.Floor42
