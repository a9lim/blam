import Batch132
import ExtraBase
namespace Blc.Floor42.Extra132
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1209595423982 : Term := (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1209595423982 : ¬ IsSelfInterpreter e1209595423982 := by
  intro he
  have hp := replay_sound (t := e1209595423982) (u := t_e1209595423982) (ps := [[],[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595423982) (by decide) (by decide) hj
#print axioms ex_e1209595423982
private def t_e1209595423990 : Term := (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1)))))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1))))))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1))))))))))) (.var 1)))))))
theorem ex_e1209595423990 : ¬ IsSelfInterpreter e1209595423990 := by
  intro he
  have hp := replay_sound (t := e1209595423990) (u := t_e1209595423990) (ps := [[],[],[.left],[.left,.right,.under,.under,.right],[.left],[.left,.right,.under,.under,.right],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595423990) (by decide) (by decide) hj
#print axioms ex_e1209595423990
private def t_e1209595424374 : Term := (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))))))
theorem ex_e1209595424374 : ¬ IsSelfInterpreter e1209595424374 := by
  intro he
  have hp := replay_sound (t := e1209595424374) (u := t_e1209595424374) (ps := [[],[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595424374) (by decide) (by decide) hj
#print axioms ex_e1209595424374
private def t_e1209595426030 : Term := (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1209595426030 : ¬ IsSelfInterpreter e1209595426030 := by
  intro he
  have hp := replay_sound (t := e1209595426030) (u := t_e1209595426030) (ps := [[],[],[.left],[.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595426030) (by decide) (by decide) hj
#print axioms ex_e1209595426030
private def t_e1209595426038 : Term := (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))) (.var 1)))))))
theorem ex_e1209595426038 : ¬ IsSelfInterpreter e1209595426038 := by
  intro he
  have hp := replay_sound (t := e1209595426038) (u := t_e1209595426038) (ps := [[],[],[.left],[.left,.right,.under,.under,.right],[.left],[.left,.right,.under,.under,.right],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595426038) (by decide) (by decide) hj
#print axioms ex_e1209595426038
private def t_e1209595427446 : Term := (.app (.app (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.var 0)) (.app (.var 1) (.var 1))))) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem ex_e1209595427446 : ¬ IsSelfInterpreter e1209595427446 := by
  intro he
  have hp := replay_sound (t := e1209595427446) (u := t_e1209595427446) (ps := [[],[],[.left],[.left,.right,.under,.under,.left],[.left],[.left,.right,.under,.under,.left],[.left],[]]) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209595427446) (by decide) (by decide) hj
#print axioms ex_e1209595427446
end Blc.Floor42.Extra132
