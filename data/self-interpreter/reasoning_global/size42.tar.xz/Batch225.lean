import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210977082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210977082 : Closed e1211210977082 ∧ code e1211210977082 = 5609257488186 := by decide
theorem cert_e1211210977082 : check e1211210977082 [[],[]] .chain = true := by decide
def e1211210981854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211210981854 : Closed e1211210981854 ∧ code e1211210981854 = 5609257492958 := by decide
theorem cert_e1211210981854 : check e1211210981854 [[],[]] .chain = true := by decide
def e1211210981878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211210981878 : Closed e1211210981878 ∧ code e1211210981878 = 5609257492982 := by decide
theorem cert_e1211210981878 : check e1211210981878 [[],[]] .chain = true := by decide
def e1211210982830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211210982830 : Closed e1211210982830 ∧ code e1211210982830 = 5609257493934 := by decide
theorem cert_e1211210982830 : check e1211210982830 [[],[]] .chain = true := by decide
def e1211210982842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211210982842 : Closed e1211210982842 ∧ code e1211210982842 = 5609257493946 := by decide
theorem cert_e1211210982842 : check e1211210982842 [[],[]] .chain = true := by decide
def e1211210982890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211210982890 : Closed e1211210982890 ∧ code e1211210982890 = 5609257493994 := by decide
theorem cert_e1211210982890 : check e1211210982890 [[],[]] .chain = true := by decide
def e1211210983022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210983022 : Closed e1211210983022 ∧ code e1211210983022 = 5609257494126 := by decide
theorem cert_e1211210983022 : check e1211210983022 [[],[]] .chain = true := by decide
def e1211210983034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210983034 : Closed e1211210983034 ∧ code e1211210983034 = 5609257494138 := by decide
theorem cert_e1211210983034 : check e1211210983034 [[],[]] .chain = true := by decide
def e1211210983198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211210983198 : Closed e1211210983198 ∧ code e1211210983198 = 5609257494302 := by decide
theorem cert_e1211210983198 : check e1211210983198 [[],[]] .chain = true := by decide
def e1211210983298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211210983298 : Closed e1211210983298 ∧ code e1211210983298 = 5609257494402 := by decide
theorem cert_e1211210983298 : check e1211210983298 [[],[]] .chain = true := by decide
def e1211210983310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211210983310 : Closed e1211210983310 ∧ code e1211210983310 = 5609257494414 := by decide
theorem cert_e1211210983310 : check e1211210983310 [[],[]] .chain = true := by decide
def e1211210983322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210983322 : Closed e1211210983322 ∧ code e1211210983322 = 5609257494426 := by decide
theorem cert_e1211210983322 : check e1211210983322 [[],[]] .chain = true := by decide
def e1211210985502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211210985502 : Closed e1211210985502 ∧ code e1211210985502 = 5609257496606 := by decide
theorem cert_e1211210985502 : check e1211210985502 [[],[]] .chain = true := by decide
def e1211210985670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211210985670 : Closed e1211210985670 ∧ code e1211210985670 = 5609257496774 := by decide
theorem cert_e1211210985670 : check e1211210985670 [[],[]] .sourceHead = true := by decide
def e1211210985694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210985694 : Closed e1211210985694 ∧ code e1211210985694 = 5609257496798 := by decide
theorem cert_e1211210985694 : check e1211210985694 [[],[]] .sourceHead = true := by decide
def e1211210985698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211210985698 : Closed e1211210985698 ∧ code e1211210985698 = 5609257496802 := by decide
theorem cert_e1211210985698 : check e1211210985698 [[],[]] .chain = true := by decide
def e1211210985710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211210985710 : Closed e1211210985710 ∧ code e1211210985710 = 5609257496814 := by decide
theorem cert_e1211210985710 : check e1211210985710 [[],[]] .chain = true := by decide
def e1211210985718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211210985718 : Closed e1211210985718 ∧ code e1211210985718 = 5609257496822 := by decide
theorem cert_e1211210985718 : check e1211210985718 [[],[]] .chain = true := by decide
def e1211210985722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210985722 : Closed e1211210985722 ∧ code e1211210985722 = 5609257496826 := by decide
theorem cert_e1211210985722 : check e1211210985722 [[],[]] .sourceHead = true := by decide
def e1211210986198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211210986198 : Closed e1211210986198 ∧ code e1211210986198 = 5609257497302 := by decide
theorem cert_e1211210986198 : check e1211210986198 [[],[]] .chain = true := by decide
def e1211210986202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211210986202 : Closed e1211210986202 ∧ code e1211210986202 = 5609257497306 := by decide
theorem cert_e1211210986202 : check e1211210986202 [[],[]] .chain = true := by decide
def e1211210986218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211210986218 : Closed e1211210986218 ∧ code e1211210986218 = 5609257497322 := by decide
theorem cert_e1211210986218 : check e1211210986218 [[],[]] .chain = true := by decide
def e1211210986246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211210986246 : Closed e1211210986246 ∧ code e1211210986246 = 5609257497350 := by decide
theorem cert_e1211210986246 : check e1211210986246 [[],[]] .chain = true := by decide
def e1211210986270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211210986270 : Closed e1211210986270 ∧ code e1211210986270 = 5609257497374 := by decide
theorem cert_e1211210986270 : check e1211210986270 [[],[]] .sourceHead = true := by decide
def e1211210986294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210986294 : Closed e1211210986294 ∧ code e1211210986294 = 5609257497398 := by decide
theorem cert_e1211210986294 : check e1211210986294 [[],[]] .chain = true := by decide
def e1211210986298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210986298 : Closed e1211210986298 ∧ code e1211210986298 = 5609257497402 := by decide
theorem cert_e1211210986298 : check e1211210986298 [[],[]] .chain = true := by decide
def e1211210986370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211210986370 : Closed e1211210986370 ∧ code e1211210986370 = 5609257497474 := by decide
theorem cert_e1211210986370 : check e1211210986370 [[],[]] .chain = true := by decide
def e1211210986382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211210986382 : Closed e1211210986382 ∧ code e1211210986382 = 5609257497486 := by decide
theorem cert_e1211210986382 : check e1211210986382 [[],[]] .chain = true := by decide
def e1211210986394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210986394 : Closed e1211210986394 ∧ code e1211210986394 = 5609257497498 := by decide
theorem cert_e1211210986394 : check e1211210986394 [[],[]] .chain = true := by decide
def e1211210986438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211210986438 : Closed e1211210986438 ∧ code e1211210986438 = 5609257497542 := by decide
theorem cert_e1211210986438 : check e1211210986438 [[],[]] .sourceHead = true := by decide
def e1211211057086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211211057086 : Closed e1211211057086 ∧ code e1211211057086 = 5609257568190 := by decide
theorem cert_e1211211057086 : check e1211211057086 [[],[]] .chain = true := by decide
def e1211211057134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211211057134 : Closed e1211211057134 ∧ code e1211211057134 = 5609257568238 := by decide
theorem cert_e1211211057134 : check e1211211057134 [[],[]] .chain = true := by decide
def e1211211060958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211211060958 : Closed e1211211060958 ∧ code e1211211060958 = 5609257572062 := by decide
theorem cert_e1211211060958 : check e1211211060958 [[],[]] .chain = true := by decide
def e1211211060982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211211060982 : Closed e1211211060982 ∧ code e1211211060982 = 5609257572086 := by decide
theorem cert_e1211211060982 : check e1211211060982 [[],[]] .chain = true := by decide
def e1211211061086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211211061086 : Closed e1211211061086 ∧ code e1211211061086 = 5609257572190 := by decide
theorem cert_e1211211061086 : check e1211211061086 [[],[]] .chain = true := by decide
def e1211211061114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211211061114 : Closed e1211211061114 ∧ code e1211211061114 = 5609257572218 := by decide
theorem cert_e1211211061114 : check e1211211061114 [[],[]] .chain = true := by decide
def e1211211061206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211211061206 : Closed e1211211061206 ∧ code e1211211061206 = 5609257572310 := by decide
theorem cert_e1211211061206 : check e1211211061206 [[],[]] .chain = true := by decide
def e1211211061210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211211061210 : Closed e1211211061210 ∧ code e1211211061210 = 5609257572314 := by decide
theorem cert_e1211211061210 : check e1211211061210 [[],[]] .chain = true := by decide
def e1211211061726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211211061726 : Closed e1211211061726 ∧ code e1211211061726 = 5609257572830 := by decide
theorem cert_e1211211061726 : check e1211211061726 [[],[]] .chain = true := by decide
def e1211211061750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211211061750 : Closed e1211211061750 ∧ code e1211211061750 = 5609257572854 := by decide
theorem cert_e1211211061750 : check e1211211061750 [[],[]] .chain = true := by decide
def e1211211062494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211211062494 : Closed e1211211062494 ∧ code e1211211062494 = 5609257573598 := by decide
theorem cert_e1211211062494 : check e1211211062494 [[],[]] .chain = true := by decide
def e1211211062522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211211062522 : Closed e1211211062522 ∧ code e1211211062522 = 5609257573626 := by decide
theorem cert_e1211211062522 : check e1211211062522 [[],[]] .chain = true := by decide
def e1211211063094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211211063094 : Closed e1211211063094 ∧ code e1211211063094 = 5609257574198 := by decide
theorem cert_e1211211063094 : check e1211211063094 [[],[]] .chain = true := by decide
def e1211211063098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211211063098 : Closed e1211211063098 ∧ code e1211211063098 = 5609257574202 := by decide
theorem cert_e1211211063098 : check e1211211063098 [[],[]] .chain = true := by decide
def e1211211077294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211211077294 : Closed e1211211077294 ∧ code e1211211077294 = 5609257588398 := by decide
theorem cert_e1211211077294 : check e1211211077294 [[],[]] .chain = true := by decide
def e1211211077306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211211077306 : Closed e1211211077306 ∧ code e1211211077306 = 5609257588410 := by decide
theorem cert_e1211211077306 : check e1211211077306 [[],[]] .chain = true := by decide
def e1211211077354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211211077354 : Closed e1211211077354 ∧ code e1211211077354 = 5609257588458 := by decide
theorem cert_e1211211077354 : check e1211211077354 [[],[]] .chain = true := by decide
def e1211211077546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211211077546 : Closed e1211211077546 ∧ code e1211211077546 = 5609257588650 := by decide
theorem cert_e1211211077546 : check e1211211077546 [[],[]] .chain = true := by decide
def e1211211077678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211211077678 : Closed e1211211077678 ∧ code e1211211077678 = 5609257588782 := by decide
theorem cert_e1211211077678 : check e1211211077678 [[],[]] .chain = true := by decide
def e1211211077870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211211077870 : Closed e1211211077870 ∧ code e1211211077870 = 5609257588974 := by decide
theorem cert_e1211211077870 : check e1211211077870 [[],[]] .chain = true := by decide
def e1211211077878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211211077878 : Closed e1211211077878 ∧ code e1211211077878 = 5609257588982 := by decide
theorem cert_e1211211077878 : check e1211211077878 [[],[]] .chain = true := by decide
def e1211211078062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211211078062 : Closed e1211211078062 ∧ code e1211211078062 = 5609257589166 := by decide
theorem cert_e1211211078062 : check e1211211078062 [[],[]] .chain = true := by decide
def e1211211078074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211211078074 : Closed e1211211078074 ∧ code e1211211078074 = 5609257589178 := by decide
theorem cert_e1211211078074 : check e1211211078074 [[],[]] .chain = true := by decide
def e1211211078122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211211078122 : Closed e1211211078122 ∧ code e1211211078122 = 5609257589226 := by decide
theorem cert_e1211211078122 : check e1211211078122 [[],[]] .chain = true := by decide
def e1211211078254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211211078254 : Closed e1211211078254 ∧ code e1211211078254 = 5609257589358 := by decide
theorem cert_e1211211078254 : check e1211211078254 [[],[]] .chain = true := by decide
def e1211211078266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211211078266 : Closed e1211211078266 ∧ code e1211211078266 = 5609257589370 := by decide
theorem cert_e1211211078266 : check e1211211078266 [[],[]] .chain = true := by decide
def e1211211078430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211211078430 : Closed e1211211078430 ∧ code e1211211078430 = 5609257589534 := by decide
theorem cert_e1211211078430 : check e1211211078430 [[],[]] .chain = true := by decide
def e1211211078530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211211078530 : Closed e1211211078530 ∧ code e1211211078530 = 5609257589634 := by decide
theorem cert_e1211211078530 : check e1211211078530 [[],[]] .chain = true := by decide
def e1211211078542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211211078542 : Closed e1211211078542 ∧ code e1211211078542 = 5609257589646 := by decide
theorem cert_e1211211078542 : check e1211211078542 [[],[]] .chain = true := by decide
def e1211211078554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211211078554 : Closed e1211211078554 ∧ code e1211211078554 = 5609257589658 := by decide
theorem cert_e1211211078554 : check e1211211078554 [[],[]] .chain = true := by decide
def e1211211078766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211211078766 : Closed e1211211078766 ∧ code e1211211078766 = 5609257589870 := by decide
theorem cert_e1211211078766 : check e1211211078766 [[],[]] .chain = true := by decide
def e1211211078778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211211078778 : Closed e1211211078778 ∧ code e1211211078778 = 5609257589882 := by decide
theorem cert_e1211211078778 : check e1211211078778 [[],[]] .chain = true := by decide
def e1211211078942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211211078942 : Closed e1211211078942 ∧ code e1211211078942 = 5609257590046 := by decide
theorem cert_e1211211078942 : check e1211211078942 [[],[]] .chain = true := by decide
def e1211211079110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211211079110 : Closed e1211211079110 ∧ code e1211211079110 = 5609257590214 := by decide
theorem cert_e1211211079110 : check e1211211079110 [[],[]] .chain = true := by decide
def e1211211079178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211211079178 : Closed e1211211079178 ∧ code e1211211079178 = 5609257590282 := by decide
theorem cert_e1211211079178 : check e1211211079178 [[],[]] .chain = true := by decide
def e1211211079222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211211079222 : Closed e1211211079222 ∧ code e1211211079222 = 5609257590326 := by decide
theorem cert_e1211211079222 : check e1211211079222 [[],[]] .chain = true := by decide
def e1211211079226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211211079226 : Closed e1211211079226 ∧ code e1211211079226 = 5609257590330 := by decide
theorem cert_e1211211079226 : check e1211211079226 [[],[]] .chain = true := by decide
def e1211211079274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211211079274 : Closed e1211211079274 ∧ code e1211211079274 = 5609257590378 := by decide
theorem cert_e1211211079274 : check e1211211079274 [[],[]] .chain = true := by decide
def e1211211079298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211211079298 : Closed e1211211079298 ∧ code e1211211079298 = 5609257590402 := by decide
theorem cert_e1211211079298 : check e1211211079298 [[],[]] .chain = true := by decide
def e1211211079310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211211079310 : Closed e1211211079310 ∧ code e1211211079310 = 5609257590414 := by decide
theorem cert_e1211211079310 : check e1211211079310 [[],[]] .chain = true := by decide
def e1211211079322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211211079322 : Closed e1211211079322 ∧ code e1211211079322 = 5609257590426 := by decide
theorem cert_e1211211079322 : check e1211211079322 [[],[]] .chain = true := by decide
def e1211211079366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211211079366 : Closed e1211211079366 ∧ code e1211211079366 = 5609257590470 := by decide
theorem cert_e1211211079366 : check e1211211079366 [[],[]] .chain = true := by decide
def e1211211080158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211211080158 : Closed e1211211080158 ∧ code e1211211080158 = 5609257591262 := by decide
theorem cert_e1211211080158 : check e1211211080158 [[],[]] .chain = true := by decide
def e1211211080182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211211080182 : Closed e1211211080182 ∧ code e1211211080182 = 5609257591286 := by decide
theorem cert_e1211211080182 : check e1211211080182 [[],[]] .chain = true := by decide
def e1211211081134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211211081134 : Closed e1211211081134 ∧ code e1211211081134 = 5609257592238 := by decide
theorem cert_e1211211081134 : check e1211211081134 [[],[]] .chain = true := by decide
def e1211211081146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211211081146 : Closed e1211211081146 ∧ code e1211211081146 = 5609257592250 := by decide
theorem cert_e1211211081146 : check e1211211081146 [[],[]] .chain = true := by decide
def e1211211081194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211211081194 : Closed e1211211081194 ∧ code e1211211081194 = 5609257592298 := by decide
theorem cert_e1211211081194 : check e1211211081194 [[],[]] .chain = true := by decide
def e1211211081326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211211081326 : Closed e1211211081326 ∧ code e1211211081326 = 5609257592430 := by decide
theorem cert_e1211211081326 : check e1211211081326 [[],[]] .chain = true := by decide
def e1211211081338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211211081338 : Closed e1211211081338 ∧ code e1211211081338 = 5609257592442 := by decide
theorem cert_e1211211081338 : check e1211211081338 [[],[]] .chain = true := by decide
def e1211211081502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211211081502 : Closed e1211211081502 ∧ code e1211211081502 = 5609257592606 := by decide
theorem cert_e1211211081502 : check e1211211081502 [[],[]] .chain = true := by decide
def e1211211081602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211211081602 : Closed e1211211081602 ∧ code e1211211081602 = 5609257592706 := by decide
theorem cert_e1211211081602 : check e1211211081602 [[],[]] .chain = true := by decide
def e1211211081614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211211081614 : Closed e1211211081614 ∧ code e1211211081614 = 5609257592718 := by decide
theorem cert_e1211211081614 : check e1211211081614 [[],[]] .chain = true := by decide
def e1211211081626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211211081626 : Closed e1211211081626 ∧ code e1211211081626 = 5609257592730 := by decide
theorem cert_e1211211081626 : check e1211211081626 [[],[]] .chain = true := by decide
def e1211211084574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211211084574 : Closed e1211211084574 ∧ code e1211211084574 = 5609257595678 := by decide
theorem cert_e1211211084574 : check e1211211084574 [[],[]] .chain = true := by decide
def e1211211084742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211211084742 : Closed e1211211084742 ∧ code e1211211084742 = 5609257595846 := by decide
theorem cert_e1211211084742 : check e1211211084742 [[],[]] .chain = true := by decide
def e1211211085942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211211085942 : Closed e1211211085942 ∧ code e1211211085942 = 5609257597046 := by decide
theorem cert_e1211211085942 : check e1211211085942 [[],[]] .chain = true := by decide
def e1211211086186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211211086186 : Closed e1211211086186 ∧ code e1211211086186 = 5609257597290 := by decide
theorem cert_e1211211086186 : check e1211211086186 [[],[]] .chain = true := by decide
def e1211211086210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211211086210 : Closed e1211211086210 ∧ code e1211211086210 = 5609257597314 := by decide
theorem cert_e1211211086210 : check e1211211086210 [[],[]] .chain = true := by decide
def e1211211086222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211211086222 : Closed e1211211086222 ∧ code e1211211086222 = 5609257597326 := by decide
theorem cert_e1211211086222 : check e1211211086222 [[],[]] .chain = true := by decide
def e1211211086234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211211086234 : Closed e1211211086234 ∧ code e1211211086234 = 5609257597338 := by decide
theorem cert_e1211211086234 : check e1211211086234 [[],[]] .chain = true := by decide
def e1211211086278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211211086278 : Closed e1211211086278 ∧ code e1211211086278 = 5609257597382 := by decide
theorem cert_e1211211086278 : check e1211211086278 [[],[]] .chain = true := by decide
def e1211211121630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211211121630 : Closed e1211211121630 ∧ code e1211211121630 = 5609257632734 := by decide
theorem cert_e1211211121630 : check e1211211121630 [[],[]] .chain = true := by decide
def e1211211121646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211211121646 : Closed e1211211121646 ∧ code e1211211121646 = 5609257632750 := by decide
theorem cert_e1211211121646 : check e1211211121646 [[],[]] .chain = true := by decide
def e1211211123566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211211123566 : Closed e1211211123566 ∧ code e1211211123566 = 5609257634670 := by decide
theorem cert_e1211211123566 : check e1211211123566 [[],[]] .chain = true := by decide
def e1211211123574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211211123574 : Closed e1211211123574 ∧ code e1211211123574 = 5609257634678 := by decide
theorem cert_e1211211123574 : check e1211211123574 [[],[]] .chain = true := by decide
def e1211211123630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211211123630 : Closed e1211211123630 ∧ code e1211211123630 = 5609257634734 := by decide
theorem cert_e1211211123630 : check e1211211123630 [[],[]] .chain = true := by decide
def e1211211123638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e1211211123638 : Closed e1211211123638 ∧ code e1211211123638 = 5609257634742 := by decide
theorem cert_e1211211123638 : check e1211211123638 [[],[]] .chain = true := by decide
def e1211211123642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211211123642 : Closed e1211211123642 ∧ code e1211211123642 = 5609257634746 := by decide
theorem cert_e1211211123642 : check e1211211123642 [[],[]] .chain = true := by decide
def e1211211123670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211211123670 : Closed e1211211123670 ∧ code e1211211123670 = 5609257634774 := by decide
theorem cert_e1211211123670 : check e1211211123670 [[],[]] .chain = true := by decide
def e1211211123674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211211123674 : Closed e1211211123674 ∧ code e1211211123674 = 5609257634778 := by decide
theorem cert_e1211211123674 : check e1211211123674 [[],[]] .chain = true := by decide
def e1211211123950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211211123950 : Closed e1211211123950 ∧ code e1211211123950 = 5609257635054 := by decide
theorem cert_e1211211123950 : check e1211211123950 [[],[]] .chain = true := by decide
def e1211211123958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211211123958 : Closed e1211211123958 ∧ code e1211211123958 = 5609257635062 := by decide
theorem cert_e1211211123958 : check e1211211123958 [[],[]] .chain = true := by decide
def e1211211124250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211211124250 : Closed e1211211124250 ∧ code e1211211124250 = 5609257635354 := by decide
theorem cert_e1211211124250 : check e1211211124250 [[],[]] .sourceHead = true := by decide
def e1211211124286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211211124286 : Closed e1211211124286 ∧ code e1211211124286 = 5609257635390 := by decide
theorem cert_e1211211124286 : check e1211211124286 [[],[]] .sourceHead = true := by decide
def e1211211124334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211211124334 : Closed e1211211124334 ∧ code e1211211124334 = 5609257635438 := by decide
theorem cert_e1211211124334 : check e1211211124334 [[],[]] .chain = true := by decide
def e1211211124342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211211124342 : Closed e1211211124342 ∧ code e1211211124342 = 5609257635446 := by decide
theorem cert_e1211211124342 : check e1211211124342 [[],[]] .chain = true := by decide
def e1211211124346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211211124346 : Closed e1211211124346 ∧ code e1211211124346 = 5609257635450 := by decide
theorem cert_e1211211124346 : check e1211211124346 [[],[]] .chain = true := by decide
def e1211211124534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211211124534 : Closed e1211211124534 ∧ code e1211211124534 = 5609257635638 := by decide
theorem cert_e1211211124534 : check e1211211124534 [[],[]] .chain = true := by decide
def e1211211124538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211211124538 : Closed e1211211124538 ∧ code e1211211124538 = 5609257635642 := by decide
theorem cert_e1211211124538 : check e1211211124538 [[],[]] .chain = true := by decide
def e1211211124622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211211124622 : Closed e1211211124622 ∧ code e1211211124622 = 5609257635726 := by decide
theorem cert_e1211211124622 : check e1211211124622 [[],[]] .sourceHead = true := by decide
def e1211211131734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211211131734 : Closed e1211211131734 ∧ code e1211211131734 = 5609257642838 := by decide
theorem cert_e1211211131734 : check e1211211131734 [[],[]] .chain = true := by decide
def e1211211131738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211211131738 : Closed e1211211131738 ∧ code e1211211131738 = 5609257642842 := by decide
theorem cert_e1211211131738 : check e1211211131738 [[],[]] .chain = true := by decide
def e1211211131754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211211131754 : Closed e1211211131754 ∧ code e1211211131754 = 5609257642858 := by decide
theorem cert_e1211211131754 : check e1211211131754 [[],[]] .chain = true := by decide
def e1211211131818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211211131818 : Closed e1211211131818 ∧ code e1211211131818 = 5609257642922 := by decide
theorem cert_e1211211131818 : check e1211211131818 [[],[]] .chain = true := by decide
def e1211211131926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211211131926 : Closed e1211211131926 ∧ code e1211211131926 = 5609257643030 := by decide
theorem cert_e1211211131926 : check e1211211131926 [[],[]] .chain = true := by decide
def e1211211131930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211211131930 : Closed e1211211131930 ∧ code e1211211131930 = 5609257643034 := by decide
theorem cert_e1211211131930 : check e1211211131930 [[],[]] .chain = true := by decide
def e1211211131974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211211131974 : Closed e1211211131974 ∧ code e1211211131974 = 5609257643078 := by decide
theorem cert_e1211211131974 : check e1211211131974 [[],[]] .chain = true := by decide
def e1211211132002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211211132002 : Closed e1211211132002 ∧ code e1211211132002 = 5609257643106 := by decide
theorem cert_e1211211132002 : check e1211211132002 [[],[]] .chain = true := by decide
def e1211211132014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211211132014 : Closed e1211211132014 ∧ code e1211211132014 = 5609257643118 := by decide
theorem cert_e1211211132014 : check e1211211132014 [[],[]] .sourceHead = true := by decide
def e1211211132022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211211132022 : Closed e1211211132022 ∧ code e1211211132022 = 5609257643126 := by decide
theorem cert_e1211211132022 : check e1211211132022 [[],[]] .chain = true := by decide
def e1211211132026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211211132026 : Closed e1211211132026 ∧ code e1211211132026 = 5609257643130 := by decide
theorem cert_e1211211132026 : check e1211211132026 [[],[]] .sourceHead = true := by decide
def e1211211132118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211211132118 : Closed e1211211132118 ∧ code e1211211132118 = 5609257643222 := by decide
theorem cert_e1211211132118 : check e1211211132118 [[],[]] .chain = true := by decide
def e1211211132122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211211132122 : Closed e1211211132122 ∧ code e1211211132122 = 5609257643226 := by decide
theorem cert_e1211211132122 : check e1211211132122 [[],[]] .chain = true := by decide
def e1211211132138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211211132138 : Closed e1211211132138 ∧ code e1211211132138 = 5609257643242 := by decide
theorem cert_e1211211132138 : check e1211211132138 [[],[]] .chain = true := by decide
def e1211211132166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211211132166 : Closed e1211211132166 ∧ code e1211211132166 = 5609257643270 := by decide
theorem cert_e1211211132166 : check e1211211132166 [[],[]] .chain = true := by decide
def e1211211132190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211211132190 : Closed e1211211132190 ∧ code e1211211132190 = 5609257643294 := by decide
theorem cert_e1211211132190 : check e1211211132190 [[],[]] .sourceHead = true := by decide
def e1211211132214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211211132214 : Closed e1211211132214 ∧ code e1211211132214 = 5609257643318 := by decide
theorem cert_e1211211132214 : check e1211211132214 [[],[]] .chain = true := by decide
def e1211211132218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211211132218 : Closed e1211211132218 ∧ code e1211211132218 = 5609257643322 := by decide
theorem cert_e1211211132218 : check e1211211132218 [[],[]] .chain = true := by decide
def e1211211132290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211211132290 : Closed e1211211132290 ∧ code e1211211132290 = 5609257643394 := by decide
theorem cert_e1211211132290 : check e1211211132290 [[],[]] .chain = true := by decide
def e1211211132302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211211132302 : Closed e1211211132302 ∧ code e1211211132302 = 5609257643406 := by decide
theorem cert_e1211211132302 : check e1211211132302 [[],[]] .chain = true := by decide
def e1211211132314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211211132314 : Closed e1211211132314 ∧ code e1211211132314 = 5609257643418 := by decide
theorem cert_e1211211132314 : check e1211211132314 [[],[]] .chain = true := by decide
def e1211211132358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211211132358 : Closed e1211211132358 ∧ code e1211211132358 = 5609257643462 := by decide
theorem cert_e1211211132358 : check e1211211132358 [[],[]] .sourceHead = true := by decide
def e1211211132426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211211132426 : Closed e1211211132426 ∧ code e1211211132426 = 5609257643530 := by decide
theorem cert_e1211211132426 : check e1211211132426 [[],[]] .chain = true := by decide
def e1211211132470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211211132470 : Closed e1211211132470 ∧ code e1211211132470 = 5609257643574 := by decide
theorem cert_e1211211132470 : check e1211211132470 [[],[]] .chain = true := by decide
def e1211211132474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211211132474 : Closed e1211211132474 ∧ code e1211211132474 = 5609257643578 := by decide
theorem cert_e1211211132474 : check e1211211132474 [[],[]] .chain = true := by decide
def e1211211132522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211211132522 : Closed e1211211132522 ∧ code e1211211132522 = 5609257643626 := by decide
theorem cert_e1211211132522 : check e1211211132522 [[],[]] .chain = true := by decide
def e1211211132546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211211132546 : Closed e1211211132546 ∧ code e1211211132546 = 5609257643650 := by decide
theorem cert_e1211211132546 : check e1211211132546 [[],[]] .chain = true := by decide
def e1211211132558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211211132558 : Closed e1211211132558 ∧ code e1211211132558 = 5609257643662 := by decide
theorem cert_e1211211132558 : check e1211211132558 [[],[]] .chain = true := by decide
def e1211211132570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211211132570 : Closed e1211211132570 ∧ code e1211211132570 = 5609257643674 := by decide
theorem cert_e1211211132570 : check e1211211132570 [[],[]] .chain = true := by decide
def e1211211132614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211211132614 : Closed e1211211132614 ∧ code e1211211132614 = 5609257643718 := by decide
theorem cert_e1211211132614 : check e1211211132614 [[],[]] .chain = true := by decide
def e1211211132698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211211132698 : Closed e1211211132698 ∧ code e1211211132698 = 5609257643802 := by decide
theorem cert_e1211211132698 : check e1211211132698 [[],[]] .sourceHead = true := by decide
def e1211211132742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211211132742 : Closed e1211211132742 ∧ code e1211211132742 = 5609257643846 := by decide
theorem cert_e1211211132742 : check e1211211132742 [[],[]] .sourceHead = true := by decide
def e1211211132958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211211132958 : Closed e1211211132958 ∧ code e1211211132958 = 5609257644062 := by decide
theorem cert_e1211211132958 : check e1211211132958 [[],[]] .chain = true := by decide
def e1211211133126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211211133126 : Closed e1211211133126 ∧ code e1211211133126 = 5609257644230 := by decide
theorem cert_e1211211133126 : check e1211211133126 [[],[]] .sourceHead = true := by decide
def e1211211133150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211211133150 : Closed e1211211133150 ∧ code e1211211133150 = 5609257644254 := by decide
theorem cert_e1211211133150 : check e1211211133150 [[],[]] .sourceHead = true := by decide
def e1211211133154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211211133154 : Closed e1211211133154 ∧ code e1211211133154 = 5609257644258 := by decide
theorem cert_e1211211133154 : check e1211211133154 [[],[]] .chain = true := by decide
def e1211211133166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211211133166 : Closed e1211211133166 ∧ code e1211211133166 = 5609257644270 := by decide
theorem cert_e1211211133166 : check e1211211133166 [[],[]] .chain = true := by decide
def e1211211133174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211211133174 : Closed e1211211133174 ∧ code e1211211133174 = 5609257644278 := by decide
theorem cert_e1211211133174 : check e1211211133174 [[],[]] .chain = true := by decide
def e1211211133178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211211133178 : Closed e1211211133178 ∧ code e1211211133178 = 5609257644282 := by decide
theorem cert_e1211211133178 : check e1211211133178 [[],[]] .sourceHead = true := by decide
def e1211211133654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211211133654 : Closed e1211211133654 ∧ code e1211211133654 = 5609257644758 := by decide
theorem cert_e1211211133654 : check e1211211133654 [[],[]] .chain = true := by decide
def e1211211133658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211211133658 : Closed e1211211133658 ∧ code e1211211133658 = 5609257644762 := by decide
theorem cert_e1211211133658 : check e1211211133658 [[],[]] .chain = true := by decide
def e1211211133674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211211133674 : Closed e1211211133674 ∧ code e1211211133674 = 5609257644778 := by decide
theorem cert_e1211211133674 : check e1211211133674 [[],[]] .chain = true := by decide
def e1211211133702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211211133702 : Closed e1211211133702 ∧ code e1211211133702 = 5609257644806 := by decide
theorem cert_e1211211133702 : check e1211211133702 [[],[]] .chain = true := by decide
def e1211211133726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211211133726 : Closed e1211211133726 ∧ code e1211211133726 = 5609257644830 := by decide
theorem cert_e1211211133726 : check e1211211133726 [[],[]] .sourceHead = true := by decide
def e1211211133750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211211133750 : Closed e1211211133750 ∧ code e1211211133750 = 5609257644854 := by decide
theorem cert_e1211211133750 : check e1211211133750 [[],[]] .chain = true := by decide
def e1211211133754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211211133754 : Closed e1211211133754 ∧ code e1211211133754 = 5609257644858 := by decide
theorem cert_e1211211133754 : check e1211211133754 [[],[]] .chain = true := by decide
def e1211211133826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211211133826 : Closed e1211211133826 ∧ code e1211211133826 = 5609257644930 := by decide
theorem cert_e1211211133826 : check e1211211133826 [[],[]] .chain = true := by decide
def e1211211133838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211211133838 : Closed e1211211133838 ∧ code e1211211133838 = 5609257644942 := by decide
theorem cert_e1211211133838 : check e1211211133838 [[],[]] .chain = true := by decide
def e1211211133850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211211133850 : Closed e1211211133850 ∧ code e1211211133850 = 5609257644954 := by decide
theorem cert_e1211211133850 : check e1211211133850 [[],[]] .chain = true := by decide
def e1211211133894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211211133894 : Closed e1211211133894 ∧ code e1211211133894 = 5609257644998 := by decide
theorem cert_e1211211133894 : check e1211211133894 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
