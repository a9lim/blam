import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1105542450374 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105542450374 : Closed e1105542450374 ∧ code e1105542450374 = 5503588961478 := by decide
theorem cert_e1105542450374 : check e1105542450374 [[]] .width = true := by decide
def e1105544011802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105544011802 : Closed e1105544011802 ∧ code e1105544011802 = 5503590522906 := by decide
theorem cert_e1105544011802 : check e1105544011802 [[]] .width = true := by decide
def e1105544011894 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105544011894 : Closed e1105544011894 ∧ code e1105544011894 = 5503590522998 := by decide
theorem cert_e1105544011894 : check e1105544011894 [[]] .width = true := by decide
def e1105544012138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105544012138 : Closed e1105544012138 ∧ code e1105544012138 = 5503590523242 := by decide
theorem cert_e1105544012138 : check e1105544012138 [[]] .width = true := by decide
def e1105544012186 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105544012186 : Closed e1105544012186 ∧ code e1105544012186 = 5503590523290 := by decide
theorem cert_e1105544012186 : check e1105544012186 [[]] .width = true := by decide
def e1105546641606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105546641606 : Closed e1105546641606 ∧ code e1105546641606 = 5503593152710 := by decide
theorem cert_e1105546641606 : check e1105546641606 [[]] .width = true := by decide
def e1105546642134 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105546642134 : Closed e1105546642134 ∧ code e1105546642134 = 5503593153238 := by decide
theorem cert_e1105546642134 : check e1105546642134 [[]] .width = true := by decide
def e1105546642138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105546642138 : Closed e1105546642138 ∧ code e1105546642138 = 5503593153242 := by decide
theorem cert_e1105546642138 : check e1105546642138 [[]] .width = true := by decide
def e1105546642154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105546642154 : Closed e1105546642154 ∧ code e1105546642154 = 5503593153258 := by decide
theorem cert_e1105546642154 : check e1105546642154 [[]] .width = true := by decide
def e1105546642230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105546642230 : Closed e1105546642230 ∧ code e1105546642230 = 5503593153334 := by decide
theorem cert_e1105546642230 : check e1105546642230 [[]] .width = true := by decide
def e1105546642234 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105546642234 : Closed e1105546642234 ∧ code e1105546642234 = 5503593153338 := by decide
theorem cert_e1105546642234 : check e1105546642234 [[]] .width = true := by decide
def e1105546642318 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105546642318 : Closed e1105546642318 ∧ code e1105546642318 = 5503593153422 := by decide
theorem cert_e1105546642318 : check e1105546642318 [[]] .width = true := by decide
def e1105546642330 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105546642330 : Closed e1105546642330 ∧ code e1105546642330 = 5503593153434 := by decide
theorem cert_e1105546642330 : check e1105546642330 [[]] .width = true := by decide
def e1105546644250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105546644250 : Closed e1105546644250 ∧ code e1105546644250 = 5503593155354 := by decide
theorem cert_e1105546644250 : check e1105546644250 [[]] .width = true := by decide
def e1105546644294 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105546644294 : Closed e1105546644294 ∧ code e1105546644294 = 5503593155398 := by decide
theorem cert_e1105546644294 : check e1105546644294 [[]] .width = true := by decide
def e1105546644534 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105546644534 : Closed e1105546644534 ∧ code e1105546644534 = 5503593155638 := by decide
theorem cert_e1105546644534 : check e1105546644534 [[]] .width = true := by decide
def e1105546644538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105546644538 : Closed e1105546644538 ∧ code e1105546644538 = 5503593155642 := by decide
theorem cert_e1105546644538 : check e1105546644538 [[]] .width = true := by decide
def e1105546644678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105546644678 : Closed e1105546644678 ∧ code e1105546644678 = 5503593155782 := by decide
theorem cert_e1105546644678 : check e1105546644678 [[]] .width = true := by decide
def e1105546764314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105546764314 : Closed e1105546764314 ∧ code e1105546764314 = 5503593275418 := by decide
theorem cert_e1105546764314 : check e1105546764314 [[]] .width = true := by decide
def e1105546764406 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105546764406 : Closed e1105546764406 ∧ code e1105546764406 = 5503593275510 := by decide
theorem cert_e1105546764406 : check e1105546764406 [[]] .width = true := by decide
def e1105546764650 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105546764650 : Closed e1105546764650 ∧ code e1105546764650 = 5503593275754 := by decide
theorem cert_e1105546764650 : check e1105546764650 [[]] .width = true := by decide
def e1105546764698 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105546764698 : Closed e1105546764698 ∧ code e1105546764698 = 5503593275802 := by decide
theorem cert_e1105546764698 : check e1105546764698 [[]] .width = true := by decide
def e1105546903750 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105546903750 : Closed e1105546903750 ∧ code e1105546903750 = 5503593414854 := by decide
theorem cert_e1105546903750 : check e1105546903750 [[]] .width = true := by decide
def e1105546904278 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105546904278 : Closed e1105546904278 ∧ code e1105546904278 = 5503593415382 := by decide
theorem cert_e1105546904278 : check e1105546904278 [[]] .width = true := by decide
def e1105546904282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105546904282 : Closed e1105546904282 ∧ code e1105546904282 = 5503593415386 := by decide
theorem cert_e1105546904282 : check e1105546904282 [[]] .width = true := by decide
def e1105546904298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105546904298 : Closed e1105546904298 ∧ code e1105546904298 = 5503593415402 := by decide
theorem cert_e1105546904298 : check e1105546904298 [[]] .width = true := by decide
def e1105546904374 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105546904374 : Closed e1105546904374 ∧ code e1105546904374 = 5503593415478 := by decide
theorem cert_e1105546904374 : check e1105546904374 [[]] .width = true := by decide
def e1105546904378 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105546904378 : Closed e1105546904378 ∧ code e1105546904378 = 5503593415482 := by decide
theorem cert_e1105546904378 : check e1105546904378 [[]] .width = true := by decide
def e1105546904462 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105546904462 : Closed e1105546904462 ∧ code e1105546904462 = 5503593415566 := by decide
theorem cert_e1105546904462 : check e1105546904462 [[]] .width = true := by decide
def e1105546904474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105546904474 : Closed e1105546904474 ∧ code e1105546904474 = 5503593415578 := by decide
theorem cert_e1105546904474 : check e1105546904474 [[]] .width = true := by decide
def e1105546906394 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105546906394 : Closed e1105546906394 ∧ code e1105546906394 = 5503593417498 := by decide
theorem cert_e1105546906394 : check e1105546906394 [[]] .width = true := by decide
def e1105546906438 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105546906438 : Closed e1105546906438 ∧ code e1105546906438 = 5503593417542 := by decide
theorem cert_e1105546906438 : check e1105546906438 [[]] .width = true := by decide
def e1105546906678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105546906678 : Closed e1105546906678 ∧ code e1105546906678 = 5503593417782 := by decide
theorem cert_e1105546906678 : check e1105546906678 [[]] .width = true := by decide
def e1105546906682 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105546906682 : Closed e1105546906682 ∧ code e1105546906682 = 5503593417786 := by decide
theorem cert_e1105546906682 : check e1105546906682 [[]] .width = true := by decide
def e1105546906822 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105546906822 : Closed e1105546906822 ∧ code e1105546906822 = 5503593417926 := by decide
theorem cert_e1105546906822 : check e1105546906822 [[]] .width = true := by decide
def e1105634721990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105634721990 : Closed e1105634721990 ∧ code e1105634721990 = 5503681233094 := by decide
theorem cert_e1105634721990 : check e1105634721990 [[]] .width = true := by decide
def e1105634722518 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105634722518 : Closed e1105634722518 ∧ code e1105634722518 = 5503681233622 := by decide
theorem cert_e1105634722518 : check e1105634722518 [[]] .width = true := by decide
def e1105634722522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105634722522 : Closed e1105634722522 ∧ code e1105634722522 = 5503681233626 := by decide
theorem cert_e1105634722522 : check e1105634722522 [[]] .width = true := by decide
def e1105634722538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105634722538 : Closed e1105634722538 ∧ code e1105634722538 = 5503681233642 := by decide
theorem cert_e1105634722538 : check e1105634722538 [[]] .width = true := by decide
def e1105634722614 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105634722614 : Closed e1105634722614 ∧ code e1105634722614 = 5503681233718 := by decide
theorem cert_e1105634722614 : check e1105634722614 [[]] .width = true := by decide
def e1105634722618 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105634722618 : Closed e1105634722618 ∧ code e1105634722618 = 5503681233722 := by decide
theorem cert_e1105634722618 : check e1105634722618 [[]] .width = true := by decide
def e1105634722702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105634722702 : Closed e1105634722702 ∧ code e1105634722702 = 5503681233806 := by decide
theorem cert_e1105634722702 : check e1105634722702 [[]] .width = true := by decide
def e1105634722714 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105634722714 : Closed e1105634722714 ∧ code e1105634722714 = 5503681233818 := by decide
theorem cert_e1105634722714 : check e1105634722714 [[]] .width = true := by decide
def e1105634724634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105634724634 : Closed e1105634724634 ∧ code e1105634724634 = 5503681235738 := by decide
theorem cert_e1105634724634 : check e1105634724634 [[]] .width = true := by decide
def e1105634724678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105634724678 : Closed e1105634724678 ∧ code e1105634724678 = 5503681235782 := by decide
theorem cert_e1105634724678 : check e1105634724678 [[]] .width = true := by decide
def e1105634724918 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105634724918 : Closed e1105634724918 ∧ code e1105634724918 = 5503681236022 := by decide
theorem cert_e1105634724918 : check e1105634724918 [[]] .width = true := by decide
def e1105634724922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105634724922 : Closed e1105634724922 ∧ code e1105634724922 = 5503681236026 := by decide
theorem cert_e1105634724922 : check e1105634724922 [[]] .width = true := by decide
def e1105634725062 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105634725062 : Closed e1105634725062 ∧ code e1105634725062 = 5503681236166 := by decide
theorem cert_e1105634725062 : check e1105634725062 [[]] .width = true := by decide
def e1105659887814 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105659887814 : Closed e1105659887814 ∧ code e1105659887814 = 5503706398918 := by decide
theorem cert_e1105659887814 : check e1105659887814 [[]] .width = true := by decide
def e1105659888342 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105659888342 : Closed e1105659888342 ∧ code e1105659888342 = 5503706399446 := by decide
theorem cert_e1105659888342 : check e1105659888342 [[]] .width = true := by decide
def e1105659888346 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105659888346 : Closed e1105659888346 ∧ code e1105659888346 = 5503706399450 := by decide
theorem cert_e1105659888346 : check e1105659888346 [[]] .width = true := by decide
def e1105659888362 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105659888362 : Closed e1105659888362 ∧ code e1105659888362 = 5503706399466 := by decide
theorem cert_e1105659888362 : check e1105659888362 [[]] .width = true := by decide
def e1105659888438 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105659888438 : Closed e1105659888438 ∧ code e1105659888438 = 5503706399542 := by decide
theorem cert_e1105659888438 : check e1105659888438 [[]] .width = true := by decide
def e1105659888442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105659888442 : Closed e1105659888442 ∧ code e1105659888442 = 5503706399546 := by decide
theorem cert_e1105659888442 : check e1105659888442 [[]] .width = true := by decide
def e1105659888526 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105659888526 : Closed e1105659888526 ∧ code e1105659888526 = 5503706399630 := by decide
theorem cert_e1105659888526 : check e1105659888526 [[]] .width = true := by decide
def e1105659888538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105659888538 : Closed e1105659888538 ∧ code e1105659888538 = 5503706399642 := by decide
theorem cert_e1105659888538 : check e1105659888538 [[]] .width = true := by decide
def e1105659890458 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105659890458 : Closed e1105659890458 ∧ code e1105659890458 = 5503706401562 := by decide
theorem cert_e1105659890458 : check e1105659890458 [[]] .width = true := by decide
def e1105659890502 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105659890502 : Closed e1105659890502 ∧ code e1105659890502 = 5503706401606 := by decide
theorem cert_e1105659890502 : check e1105659890502 [[]] .width = true := by decide
def e1105659890742 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105659890742 : Closed e1105659890742 ∧ code e1105659890742 = 5503706401846 := by decide
theorem cert_e1105659890742 : check e1105659890742 [[]] .width = true := by decide
def e1105659890746 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105659890746 : Closed e1105659890746 ∧ code e1105659890746 = 5503706401850 := by decide
theorem cert_e1105659890746 : check e1105659890746 [[]] .width = true := by decide
def e1105659890886 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105659890886 : Closed e1105659890886 ∧ code e1105659890886 = 5503706401990 := by decide
theorem cert_e1105659890886 : check e1105659890886 [[]] .width = true := by decide
def e1105660010522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105660010522 : Closed e1105660010522 ∧ code e1105660010522 = 5503706521626 := by decide
theorem cert_e1105660010522 : check e1105660010522 [[]] .width = true := by decide
def e1105660010614 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105660010614 : Closed e1105660010614 ∧ code e1105660010614 = 5503706521718 := by decide
theorem cert_e1105660010614 : check e1105660010614 [[]] .width = true := by decide
def e1105660010858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105660010858 : Closed e1105660010858 ∧ code e1105660010858 = 5503706521962 := by decide
theorem cert_e1105660010858 : check e1105660010858 [[]] .width = true := by decide
def e1105660010906 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105660010906 : Closed e1105660010906 ∧ code e1105660010906 = 5503706522010 := by decide
theorem cert_e1105660010906 : check e1105660010906 [[]] .width = true := by decide
def e1105660149958 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105660149958 : Closed e1105660149958 ∧ code e1105660149958 = 5503706661062 := by decide
theorem cert_e1105660149958 : check e1105660149958 [[]] .width = true := by decide
def e1105660150486 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105660150486 : Closed e1105660150486 ∧ code e1105660150486 = 5503706661590 := by decide
theorem cert_e1105660150486 : check e1105660150486 [[]] .width = true := by decide
def e1105660150490 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105660150490 : Closed e1105660150490 ∧ code e1105660150490 = 5503706661594 := by decide
theorem cert_e1105660150490 : check e1105660150490 [[]] .width = true := by decide
def e1105660150506 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105660150506 : Closed e1105660150506 ∧ code e1105660150506 = 5503706661610 := by decide
theorem cert_e1105660150506 : check e1105660150506 [[]] .width = true := by decide
def e1105660150582 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105660150582 : Closed e1105660150582 ∧ code e1105660150582 = 5503706661686 := by decide
theorem cert_e1105660150582 : check e1105660150582 [[]] .width = true := by decide
def e1105660150586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105660150586 : Closed e1105660150586 ∧ code e1105660150586 = 5503706661690 := by decide
theorem cert_e1105660150586 : check e1105660150586 [[]] .width = true := by decide
def e1105660150670 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105660150670 : Closed e1105660150670 ∧ code e1105660150670 = 5503706661774 := by decide
theorem cert_e1105660150670 : check e1105660150670 [[]] .width = true := by decide
def e1105660150682 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105660150682 : Closed e1105660150682 ∧ code e1105660150682 = 5503706661786 := by decide
theorem cert_e1105660150682 : check e1105660150682 [[]] .width = true := by decide
def e1105660152602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105660152602 : Closed e1105660152602 ∧ code e1105660152602 = 5503706663706 := by decide
theorem cert_e1105660152602 : check e1105660152602 [[]] .width = true := by decide
def e1105660152646 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105660152646 : Closed e1105660152646 ∧ code e1105660152646 = 5503706663750 := by decide
theorem cert_e1105660152646 : check e1105660152646 [[]] .width = true := by decide
def e1105660152886 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105660152886 : Closed e1105660152886 ∧ code e1105660152886 = 5503706663990 := by decide
theorem cert_e1105660152886 : check e1105660152886 [[]] .width = true := by decide
def e1105660152890 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105660152890 : Closed e1105660152890 ∧ code e1105660152890 = 5503706663994 := by decide
theorem cert_e1105660152890 : check e1105660152890 [[]] .width = true := by decide
def e1105660153030 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105660153030 : Closed e1105660153030 ∧ code e1105660153030 = 5503706664134 := by decide
theorem cert_e1105660153030 : check e1105660153030 [[]] .width = true := by decide
def e1105712832538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105712832538 : Closed e1105712832538 ∧ code e1105712832538 = 5503759343642 := by decide
theorem cert_e1105712832538 : check e1105712832538 [[]] .width = true := by decide
def e1105712832630 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105712832630 : Closed e1105712832630 ∧ code e1105712832630 = 5503759343734 := by decide
theorem cert_e1105712832630 : check e1105712832630 [[]] .width = true := by decide
def e1105712832874 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105712832874 : Closed e1105712832874 ∧ code e1105712832874 = 5503759343978 := by decide
theorem cert_e1105712832874 : check e1105712832874 [[]] .width = true := by decide
def e1105712832922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105712832922 : Closed e1105712832922 ∧ code e1105712832922 = 5503759344026 := by decide
theorem cert_e1105712832922 : check e1105712832922 [[]] .width = true := by decide
def e1105743773894 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105743773894 : Closed e1105743773894 ∧ code e1105743773894 = 5503790284998 := by decide
theorem cert_e1105743773894 : check e1105743773894 [[]] .width = true := by decide
def e1105743774422 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105743774422 : Closed e1105743774422 ∧ code e1105743774422 = 5503790285526 := by decide
theorem cert_e1105743774422 : check e1105743774422 [[]] .width = true := by decide
def e1105743774426 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105743774426 : Closed e1105743774426 ∧ code e1105743774426 = 5503790285530 := by decide
theorem cert_e1105743774426 : check e1105743774426 [[]] .width = true := by decide
def e1105743774442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105743774442 : Closed e1105743774442 ∧ code e1105743774442 = 5503790285546 := by decide
theorem cert_e1105743774442 : check e1105743774442 [[]] .width = true := by decide
def e1105743774518 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105743774518 : Closed e1105743774518 ∧ code e1105743774518 = 5503790285622 := by decide
theorem cert_e1105743774518 : check e1105743774518 [[]] .width = true := by decide
def e1105743774522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105743774522 : Closed e1105743774522 ∧ code e1105743774522 = 5503790285626 := by decide
theorem cert_e1105743774522 : check e1105743774522 [[]] .width = true := by decide
def e1105743774606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105743774606 : Closed e1105743774606 ∧ code e1105743774606 = 5503790285710 := by decide
theorem cert_e1105743774606 : check e1105743774606 [[]] .width = true := by decide
def e1105743774618 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105743774618 : Closed e1105743774618 ∧ code e1105743774618 = 5503790285722 := by decide
theorem cert_e1105743774618 : check e1105743774618 [[]] .width = true := by decide
def e1105743776538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105743776538 : Closed e1105743776538 ∧ code e1105743776538 = 5503790287642 := by decide
theorem cert_e1105743776538 : check e1105743776538 [[]] .width = true := by decide
def e1105743776582 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105743776582 : Closed e1105743776582 ∧ code e1105743776582 = 5503790287686 := by decide
theorem cert_e1105743776582 : check e1105743776582 [[]] .width = true := by decide
def e1105743776822 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105743776822 : Closed e1105743776822 ∧ code e1105743776822 = 5503790287926 := by decide
theorem cert_e1105743776822 : check e1105743776822 [[]] .width = true := by decide
def e1105743776826 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105743776826 : Closed e1105743776826 ∧ code e1105743776826 = 5503790287930 := by decide
theorem cert_e1105743776826 : check e1105743776826 [[]] .width = true := by decide
def e1105743776966 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105743776966 : Closed e1105743776966 ∧ code e1105743776966 = 5503790288070 := by decide
theorem cert_e1105743776966 : check e1105743776966 [[]] .width = true := by decide
def e1105749008410 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105749008410 : Closed e1105749008410 ∧ code e1105749008410 = 5503795519514 := by decide
theorem cert_e1105749008410 : check e1105749008410 [[]] .width = true := by decide
def e1105749008502 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105749008502 : Closed e1105749008502 ∧ code e1105749008502 = 5503795519606 := by decide
theorem cert_e1105749008502 : check e1105749008502 [[]] .width = true := by decide
def e1105749008746 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105749008746 : Closed e1105749008746 ∧ code e1105749008746 = 5503795519850 := by decide
theorem cert_e1105749008746 : check e1105749008746 [[]] .width = true := by decide
def e1105749008794 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105749008794 : Closed e1105749008794 ∧ code e1105749008794 = 5503795519898 := by decide
theorem cert_e1105749008794 : check e1105749008794 [[]] .width = true := by decide
def e1105750065350 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105750065350 : Closed e1105750065350 ∧ code e1105750065350 = 5503796576454 := by decide
theorem cert_e1105750065350 : check e1105750065350 [[]] .width = true := by decide
def e1105750065878 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105750065878 : Closed e1105750065878 ∧ code e1105750065878 = 5503796576982 := by decide
theorem cert_e1105750065878 : check e1105750065878 [[]] .width = true := by decide
def e1105750065882 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105750065882 : Closed e1105750065882 ∧ code e1105750065882 = 5503796576986 := by decide
theorem cert_e1105750065882 : check e1105750065882 [[]] .width = true := by decide
def e1105750065898 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105750065898 : Closed e1105750065898 ∧ code e1105750065898 = 5503796577002 := by decide
theorem cert_e1105750065898 : check e1105750065898 [[]] .width = true := by decide
def e1105750065974 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105750065974 : Closed e1105750065974 ∧ code e1105750065974 = 5503796577078 := by decide
theorem cert_e1105750065974 : check e1105750065974 [[]] .width = true := by decide
def e1105750065978 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105750065978 : Closed e1105750065978 ∧ code e1105750065978 = 5503796577082 := by decide
theorem cert_e1105750065978 : check e1105750065978 [[]] .width = true := by decide
def e1105750066062 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105750066062 : Closed e1105750066062 ∧ code e1105750066062 = 5503796577166 := by decide
theorem cert_e1105750066062 : check e1105750066062 [[]] .width = true := by decide
def e1105750066074 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105750066074 : Closed e1105750066074 ∧ code e1105750066074 = 5503796577178 := by decide
theorem cert_e1105750066074 : check e1105750066074 [[]] .width = true := by decide
def e1105750067994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105750067994 : Closed e1105750067994 ∧ code e1105750067994 = 5503796579098 := by decide
theorem cert_e1105750067994 : check e1105750067994 [[]] .width = true := by decide
def e1105750068038 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105750068038 : Closed e1105750068038 ∧ code e1105750068038 = 5503796579142 := by decide
theorem cert_e1105750068038 : check e1105750068038 [[]] .width = true := by decide
def e1105750068278 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105750068278 : Closed e1105750068278 ∧ code e1105750068278 = 5503796579382 := by decide
theorem cert_e1105750068278 : check e1105750068278 [[]] .width = true := by decide
def e1105750068282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105750068282 : Closed e1105750068282 ∧ code e1105750068282 = 5503796579386 := by decide
theorem cert_e1105750068282 : check e1105750068282 [[]] .width = true := by decide
def e1105750068422 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105750068422 : Closed e1105750068422 ∧ code e1105750068422 = 5503796579526 := by decide
theorem cert_e1105750068422 : check e1105750068422 [[]] .width = true := by decide
def e1105750417434 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105750417434 : Closed e1105750417434 ∧ code e1105750417434 = 5503796928538 := by decide
theorem cert_e1105750417434 : check e1105750417434 [[]] .width = true := by decide
def e1105750417526 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105750417526 : Closed e1105750417526 ∧ code e1105750417526 = 5503796928630 := by decide
theorem cert_e1105750417526 : check e1105750417526 [[]] .width = true := by decide
def e1105750417770 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105750417770 : Closed e1105750417770 ∧ code e1105750417770 = 5503796928874 := by decide
theorem cert_e1105750417770 : check e1105750417770 [[]] .width = true := by decide
def e1105750417818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105750417818 : Closed e1105750417818 ∧ code e1105750417818 = 5503796928922 := by decide
theorem cert_e1105750417818 : check e1105750417818 [[]] .width = true := by decide
def e1105750458566 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105750458566 : Closed e1105750458566 ∧ code e1105750458566 = 5503796969670 := by decide
theorem cert_e1105750458566 : check e1105750458566 [[]] .width = true := by decide
def e1105750459094 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105750459094 : Closed e1105750459094 ∧ code e1105750459094 = 5503796970198 := by decide
theorem cert_e1105750459094 : check e1105750459094 [[]] .width = true := by decide
def e1105750459098 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105750459098 : Closed e1105750459098 ∧ code e1105750459098 = 5503796970202 := by decide
theorem cert_e1105750459098 : check e1105750459098 [[]] .width = true := by decide
def e1105750459114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105750459114 : Closed e1105750459114 ∧ code e1105750459114 = 5503796970218 := by decide
theorem cert_e1105750459114 : check e1105750459114 [[]] .width = true := by decide
def e1105750459190 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105750459190 : Closed e1105750459190 ∧ code e1105750459190 = 5503796970294 := by decide
theorem cert_e1105750459190 : check e1105750459190 [[]] .width = true := by decide
def e1105750459194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105750459194 : Closed e1105750459194 ∧ code e1105750459194 = 5503796970298 := by decide
theorem cert_e1105750459194 : check e1105750459194 [[]] .width = true := by decide
def e1105750459278 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105750459278 : Closed e1105750459278 ∧ code e1105750459278 = 5503796970382 := by decide
theorem cert_e1105750459278 : check e1105750459278 [[]] .width = true := by decide
def e1105750459290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105750459290 : Closed e1105750459290 ∧ code e1105750459290 = 5503796970394 := by decide
theorem cert_e1105750459290 : check e1105750459290 [[]] .width = true := by decide
def e1105750461210 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105750461210 : Closed e1105750461210 ∧ code e1105750461210 = 5503796972314 := by decide
theorem cert_e1105750461210 : check e1105750461210 [[]] .width = true := by decide
def e1105750461254 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105750461254 : Closed e1105750461254 ∧ code e1105750461254 = 5503796972358 := by decide
theorem cert_e1105750461254 : check e1105750461254 [[]] .width = true := by decide
def e1105750461494 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105750461494 : Closed e1105750461494 ∧ code e1105750461494 = 5503796972598 := by decide
theorem cert_e1105750461494 : check e1105750461494 [[]] .width = true := by decide
def e1105750461498 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105750461498 : Closed e1105750461498 ∧ code e1105750461498 = 5503796972602 := by decide
theorem cert_e1105750461498 : check e1105750461498 [[]] .width = true := by decide
def e1105750461638 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105750461638 : Closed e1105750461638 ∧ code e1105750461638 = 5503796972742 := by decide
theorem cert_e1105750461638 : check e1105750461638 [[]] .width = true := by decide
def e1105768939718 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105768939718 : Closed e1105768939718 ∧ code e1105768939718 = 5503815450822 := by decide
theorem cert_e1105768939718 : check e1105768939718 [[]] .width = true := by decide
def e1105768940246 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105768940246 : Closed e1105768940246 ∧ code e1105768940246 = 5503815451350 := by decide
theorem cert_e1105768940246 : check e1105768940246 [[]] .width = true := by decide
def e1105768940250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105768940250 : Closed e1105768940250 ∧ code e1105768940250 = 5503815451354 := by decide
theorem cert_e1105768940250 : check e1105768940250 [[]] .width = true := by decide
def e1105768940266 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105768940266 : Closed e1105768940266 ∧ code e1105768940266 = 5503815451370 := by decide
theorem cert_e1105768940266 : check e1105768940266 [[]] .width = true := by decide
def e1105768940342 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105768940342 : Closed e1105768940342 ∧ code e1105768940342 = 5503815451446 := by decide
theorem cert_e1105768940342 : check e1105768940342 [[]] .width = true := by decide
def e1105768940346 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105768940346 : Closed e1105768940346 ∧ code e1105768940346 = 5503815451450 := by decide
theorem cert_e1105768940346 : check e1105768940346 [[]] .width = true := by decide
def e1105768940430 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105768940430 : Closed e1105768940430 ∧ code e1105768940430 = 5503815451534 := by decide
theorem cert_e1105768940430 : check e1105768940430 [[]] .width = true := by decide
def e1105768940442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105768940442 : Closed e1105768940442 ∧ code e1105768940442 = 5503815451546 := by decide
theorem cert_e1105768940442 : check e1105768940442 [[]] .width = true := by decide
def e1105768942362 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105768942362 : Closed e1105768942362 ∧ code e1105768942362 = 5503815453466 := by decide
theorem cert_e1105768942362 : check e1105768942362 [[]] .width = true := by decide
def e1105768942406 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105768942406 : Closed e1105768942406 ∧ code e1105768942406 = 5503815453510 := by decide
theorem cert_e1105768942406 : check e1105768942406 [[]] .width = true := by decide
def e1105768942646 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105768942646 : Closed e1105768942646 ∧ code e1105768942646 = 5503815453750 := by decide
theorem cert_e1105768942646 : check e1105768942646 [[]] .width = true := by decide
def e1105768942650 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105768942650 : Closed e1105768942650 ∧ code e1105768942650 = 5503815453754 := by decide
theorem cert_e1105768942650 : check e1105768942650 [[]] .width = true := by decide
def e1105768942790 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105768942790 : Closed e1105768942790 ∧ code e1105768942790 = 5503815453894 := by decide
theorem cert_e1105768942790 : check e1105768942790 [[]] .width = true := by decide
def e1105806688454 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105806688454 : Closed e1105806688454 ∧ code e1105806688454 = 5503853199558 := by decide
theorem cert_e1105806688454 : check e1105806688454 [[]] .width = true := by decide
def e1105806688982 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105806688982 : Closed e1105806688982 ∧ code e1105806688982 = 5503853200086 := by decide
theorem cert_e1105806688982 : check e1105806688982 [[]] .width = true := by decide
def e1105806688986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105806688986 : Closed e1105806688986 ∧ code e1105806688986 = 5503853200090 := by decide
theorem cert_e1105806688986 : check e1105806688986 [[]] .width = true := by decide
def e1105806689002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105806689002 : Closed e1105806689002 ∧ code e1105806689002 = 5503853200106 := by decide
theorem cert_e1105806689002 : check e1105806689002 [[]] .width = true := by decide
def e1105806689078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105806689078 : Closed e1105806689078 ∧ code e1105806689078 = 5503853200182 := by decide
theorem cert_e1105806689078 : check e1105806689078 [[]] .width = true := by decide
def e1105806689082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105806689082 : Closed e1105806689082 ∧ code e1105806689082 = 5503853200186 := by decide
theorem cert_e1105806689082 : check e1105806689082 [[]] .width = true := by decide
def e1105806689166 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105806689166 : Closed e1105806689166 ∧ code e1105806689166 = 5503853200270 := by decide
theorem cert_e1105806689166 : check e1105806689166 [[]] .width = true := by decide
def e1105806689178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105806689178 : Closed e1105806689178 ∧ code e1105806689178 = 5503853200282 := by decide
theorem cert_e1105806689178 : check e1105806689178 [[]] .width = true := by decide
def e1105806691098 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105806691098 : Closed e1105806691098 ∧ code e1105806691098 = 5503853202202 := by decide
theorem cert_e1105806691098 : check e1105806691098 [[]] .width = true := by decide
def e1105806691142 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105806691142 : Closed e1105806691142 ∧ code e1105806691142 = 5503853202246 := by decide
theorem cert_e1105806691142 : check e1105806691142 [[]] .width = true := by decide
def e1105806691382 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105806691382 : Closed e1105806691382 ∧ code e1105806691382 = 5503853202486 := by decide
theorem cert_e1105806691382 : check e1105806691382 [[]] .width = true := by decide
def e1105806691386 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105806691386 : Closed e1105806691386 ∧ code e1105806691386 = 5503853202490 := by decide
theorem cert_e1105806691386 : check e1105806691386 [[]] .width = true := by decide
def e1105806691526 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105806691526 : Closed e1105806691526 ∧ code e1105806691526 = 5503853202630 := by decide
theorem cert_e1105806691526 : check e1105806691526 [[]] .width = true := by decide
def e1105807040538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105807040538 : Closed e1105807040538 ∧ code e1105807040538 = 5503853551642 := by decide
theorem cert_e1105807040538 : check e1105807040538 [[]] .width = true := by decide
def e1105807040630 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105807040630 : Closed e1105807040630 ∧ code e1105807040630 = 5503853551734 := by decide
theorem cert_e1105807040630 : check e1105807040630 [[]] .width = true := by decide
def e1105807040874 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105807040874 : Closed e1105807040874 ∧ code e1105807040874 = 5503853551978 := by decide
theorem cert_e1105807040874 : check e1105807040874 [[]] .width = true := by decide
def e1105807040922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105807040922 : Closed e1105807040922 ∧ code e1105807040922 = 5503853552026 := by decide
theorem cert_e1105807040922 : check e1105807040922 [[]] .width = true := by decide
def e1105807081670 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105807081670 : Closed e1105807081670 ∧ code e1105807081670 = 5503853592774 := by decide
theorem cert_e1105807081670 : check e1105807081670 [[]] .width = true := by decide
end Blc.Floor42
