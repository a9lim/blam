import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812781946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e1205812781946 : Closed e1205812781946 ∧ code e1205812781946 = 5603859293050 := by decide
theorem cert_e1205812781946 : check e1205812781946 [[],[]] .three = true := by decide
def e1205812781998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1205812781998 : Closed e1205812781998 ∧ code e1205812781998 = 5603859293102 := by decide
theorem cert_e1205812781998 : check e1205812781998 [[],[]] .smaller = true := by decide
def e1205812782010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1205812782010 : Closed e1205812782010 ∧ code e1205812782010 = 5603859293114 := by decide
theorem cert_e1205812782010 : check e1205812782010 [[],[]] .smaller = true := by decide
def e1205812782038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1205812782038 : Closed e1205812782038 ∧ code e1205812782038 = 5603859293142 := by decide
theorem cert_e1205812782038 : check e1205812782038 [[],[]] .smaller = true := by decide
def e1205812782042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1205812782042 : Closed e1205812782042 ∧ code e1205812782042 = 5603859293146 := by decide
theorem cert_e1205812782042 : check e1205812782042 [[],[]] .smaller = true := by decide
def e1205812782058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e1205812782058 : Closed e1205812782058 ∧ code e1205812782058 = 5603859293162 := by decide
theorem cert_e1205812782058 : check e1205812782058 [[],[]] .three = true := by decide
def e1205812782766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205812782766 : Closed e1205812782766 ∧ code e1205812782766 = 5603859293870 := by decide
theorem cert_e1205812782766 : check e1205812782766 [[],[]] .smaller = true := by decide
def e1205812782778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205812782778 : Closed e1205812782778 ∧ code e1205812782778 = 5603859293882 := by decide
theorem cert_e1205812782778 : check e1205812782778 [[],[]] .smaller = true := by decide
def e1205812782826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1205812782826 : Closed e1205812782826 ∧ code e1205812782826 = 5603859293930 := by decide
theorem cert_e1205812782826 : check e1205812782826 [[],[]] .smaller = true := by decide
def e1205812783018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1205812783018 : Closed e1205812783018 ∧ code e1205812783018 = 5603859294122 := by decide
theorem cert_e1205812783018 : check e1205812783018 [[],[]] .smaller = true := by decide
def e1205812783326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1205812783326 : Closed e1205812783326 ∧ code e1205812783326 = 5603859294430 := by decide
theorem cert_e1205812783326 : check e1205812783326 [[],[]] .three = true := by decide
def e1205812783342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1205812783342 : Closed e1205812783342 ∧ code e1205812783342 = 5603859294446 := by decide
theorem cert_e1205812783342 : check e1205812783342 [[],[]] .smaller = true := by decide
def e1205812783350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1205812783350 : Closed e1205812783350 ∧ code e1205812783350 = 5603859294454 := by decide
theorem cert_e1205812783350 : check e1205812783350 [[],[]] .smaller = true := by decide
def e1205812783354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1205812783354 : Closed e1205812783354 ∧ code e1205812783354 = 5603859294458 := by decide
theorem cert_e1205812783354 : check e1205812783354 [[],[]] .three = true := by decide
def e1205812783534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1205812783534 : Closed e1205812783534 ∧ code e1205812783534 = 5603859294638 := by decide
theorem cert_e1205812783534 : check e1205812783534 [[],[]] .smaller = true := by decide
def e1205812783546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1205812783546 : Closed e1205812783546 ∧ code e1205812783546 = 5603859294650 := by decide
theorem cert_e1205812783546 : check e1205812783546 [[],[]] .smaller = true := by decide
def e1205812783594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1205812783594 : Closed e1205812783594 ∧ code e1205812783594 = 5603859294698 := by decide
theorem cert_e1205812783594 : check e1205812783594 [[],[]] .smaller = true := by decide
def e1205812783678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1205812783678 : Closed e1205812783678 ∧ code e1205812783678 = 5603859294782 := by decide
theorem cert_e1205812783678 : check e1205812783678 [[],[]] .three = true := by decide
def e1205812783726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812783726 : Closed e1205812783726 ∧ code e1205812783726 = 5603859294830 := by decide
theorem cert_e1205812783726 : check e1205812783726 [[],[]] .smaller = true := by decide
def e1205812783738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812783738 : Closed e1205812783738 ∧ code e1205812783738 = 5603859294842 := by decide
theorem cert_e1205812783738 : check e1205812783738 [[],[]] .smaller = true := by decide
def e1205812783902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1205812783902 : Closed e1205812783902 ∧ code e1205812783902 = 5603859295006 := by decide
theorem cert_e1205812783902 : check e1205812783902 [[],[]] .smaller = true := by decide
def e1205812784014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1205812784014 : Closed e1205812784014 ∧ code e1205812784014 = 5603859295118 := by decide
theorem cert_e1205812784014 : check e1205812784014 [[],[]] .smaller = true := by decide
def e1205812784026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812784026 : Closed e1205812784026 ∧ code e1205812784026 = 5603859295130 := by decide
theorem cert_e1205812784026 : check e1205812784026 [[],[]] .smaller = true := by decide
def e1205812784070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1205812784070 : Closed e1205812784070 ∧ code e1205812784070 = 5603859295174 := by decide
theorem cert_e1205812784070 : check e1205812784070 [[],[]] .three = true := by decide
def e1205812784094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e1205812784094 : Closed e1205812784094 ∧ code e1205812784094 = 5603859295198 := by decide
theorem cert_e1205812784094 : check e1205812784094 [[],[]] .three = true := by decide
def e1205812784238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1205812784238 : Closed e1205812784238 ∧ code e1205812784238 = 5603859295342 := by decide
theorem cert_e1205812784238 : check e1205812784238 [[],[]] .smaller = true := by decide
def e1205812784250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1205812784250 : Closed e1205812784250 ∧ code e1205812784250 = 5603859295354 := by decide
theorem cert_e1205812784250 : check e1205812784250 [[],[]] .smaller = true := by decide
def e1205812784414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1205812784414 : Closed e1205812784414 ∧ code e1205812784414 = 5603859295518 := by decide
theorem cert_e1205812784414 : check e1205812784414 [[],[]] .smaller = true := by decide
def e1205812784582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1205812784582 : Closed e1205812784582 ∧ code e1205812784582 = 5603859295686 := by decide
theorem cert_e1205812784582 : check e1205812784582 [[],[]] .smaller = true := by decide
def e1205812784606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e1205812784606 : Closed e1205812784606 ∧ code e1205812784606 = 5603859295710 := by decide
theorem cert_e1205812784606 : check e1205812784606 [[],[]] .three = true := by decide
def e1205812784622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e1205812784622 : Closed e1205812784622 ∧ code e1205812784622 = 5603859295726 := by decide
theorem cert_e1205812784622 : check e1205812784622 [[],[]] .three = true := by decide
def e1205812784694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1205812784694 : Closed e1205812784694 ∧ code e1205812784694 = 5603859295798 := by decide
theorem cert_e1205812784694 : check e1205812784694 [[],[]] .smaller = true := by decide
def e1205812784698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1205812784698 : Closed e1205812784698 ∧ code e1205812784698 = 5603859295802 := by decide
theorem cert_e1205812784698 : check e1205812784698 [[],[]] .smaller = true := by decide
def e1205812784746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1205812784746 : Closed e1205812784746 ∧ code e1205812784746 = 5603859295850 := by decide
theorem cert_e1205812784746 : check e1205812784746 [[],[]] .smaller = true := by decide
def e1205812784782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1205812784782 : Closed e1205812784782 ∧ code e1205812784782 = 5603859295886 := by decide
theorem cert_e1205812784782 : check e1205812784782 [[],[]] .smaller = true := by decide
def e1205812784794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812784794 : Closed e1205812784794 ∧ code e1205812784794 = 5603859295898 := by decide
theorem cert_e1205812784794 : check e1205812784794 [[],[]] .smaller = true := by decide
def e1205812784838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1205812784838 : Closed e1205812784838 ∧ code e1205812784838 = 5603859295942 := by decide
theorem cert_e1205812784838 : check e1205812784838 [[],[]] .smaller = true := by decide
def e1205812784862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e1205812784862 : Closed e1205812784862 ∧ code e1205812784862 = 5603859295966 := by decide
theorem cert_e1205812784862 : check e1205812784862 [[],[]] .three = true := by decide
def e1205812784886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e1205812784886 : Closed e1205812784886 ∧ code e1205812784886 = 5603859295990 := by decide
theorem cert_e1205812784886 : check e1205812784886 [[],[]] .three = true := by decide
def e1205812784922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1205812784922 : Closed e1205812784922 ∧ code e1205812784922 = 5603859296026 := by decide
theorem cert_e1205812784922 : check e1205812784922 [[],[]] .three = true := by decide
def e1205812784966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1205812784966 : Closed e1205812784966 ∧ code e1205812784966 = 5603859296070 := by decide
theorem cert_e1205812784966 : check e1205812784966 [[],[]] .three = true := by decide
def e1205812784990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e1205812784990 : Closed e1205812784990 ∧ code e1205812784990 = 5603859296094 := by decide
theorem cert_e1205812784990 : check e1205812784990 [[],[]] .three = true := by decide
def e1205812785006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e1205812785006 : Closed e1205812785006 ∧ code e1205812785006 = 5603859296110 := by decide
theorem cert_e1205812785006 : check e1205812785006 [[],[]] .three = true := by decide
def e1205812785014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e1205812785014 : Closed e1205812785014 ∧ code e1205812785014 = 5603859296118 := by decide
theorem cert_e1205812785014 : check e1205812785014 [[],[]] .three = true := by decide
def e1205812785018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e1205812785018 : Closed e1205812785018 ∧ code e1205812785018 = 5603859296122 := by decide
theorem cert_e1205812785018 : check e1205812785018 [[],[]] .three = true := by decide
def e1205812785590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1205812785590 : Closed e1205812785590 ∧ code e1205812785590 = 5603859296694 := by decide
theorem cert_e1205812785590 : check e1205812785590 [[],[]] .smaller = true := by decide
def e1205812785622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1205812785622 : Closed e1205812785622 ∧ code e1205812785622 = 5603859296726 := by decide
theorem cert_e1205812785622 : check e1205812785622 [[],[]] .smaller = true := by decide
def e1205812785626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1205812785626 : Closed e1205812785626 ∧ code e1205812785626 = 5603859296730 := by decide
theorem cert_e1205812785626 : check e1205812785626 [[],[]] .smaller = true := by decide
def e1205812786006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205812786006 : Closed e1205812786006 ∧ code e1205812786006 = 5603859297110 := by decide
theorem cert_e1205812786006 : check e1205812786006 [[],[]] .smaller = true := by decide
def e1205812786010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205812786010 : Closed e1205812786010 ∧ code e1205812786010 = 5603859297114 := by decide
theorem cert_e1205812786010 : check e1205812786010 [[],[]] .smaller = true := by decide
def e1205812786026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1205812786026 : Closed e1205812786026 ∧ code e1205812786026 = 5603859297130 := by decide
theorem cert_e1205812786026 : check e1205812786026 [[],[]] .smaller = true := by decide
def e1205812786090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1205812786090 : Closed e1205812786090 ∧ code e1205812786090 = 5603859297194 := by decide
theorem cert_e1205812786090 : check e1205812786090 [[],[]] .smaller = true := by decide
def e1205812786294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1205812786294 : Closed e1205812786294 ∧ code e1205812786294 = 5603859297398 := by decide
theorem cert_e1205812786294 : check e1205812786294 [[],[]] .smaller = true := by decide
def e1205812786390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1205812786390 : Closed e1205812786390 ∧ code e1205812786390 = 5603859297494 := by decide
theorem cert_e1205812786390 : check e1205812786390 [[],[]] .smaller = true := by decide
def e1205812786394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1205812786394 : Closed e1205812786394 ∧ code e1205812786394 = 5603859297498 := by decide
theorem cert_e1205812786394 : check e1205812786394 [[],[]] .smaller = true := by decide
def e1205812786410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1205812786410 : Closed e1205812786410 ∧ code e1205812786410 = 5603859297514 := by decide
theorem cert_e1205812786410 : check e1205812786410 [[],[]] .smaller = true := by decide
def e1205812786486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812786486 : Closed e1205812786486 ∧ code e1205812786486 = 5603859297590 := by decide
theorem cert_e1205812786486 : check e1205812786486 [[],[]] .smaller = true := by decide
def e1205812786490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812786490 : Closed e1205812786490 ∧ code e1205812786490 = 5603859297594 := by decide
theorem cert_e1205812786490 : check e1205812786490 [[],[]] .smaller = true := by decide
def e1205812786574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1205812786574 : Closed e1205812786574 ∧ code e1205812786574 = 5603859297678 := by decide
theorem cert_e1205812786574 : check e1205812786574 [[],[]] .smaller = true := by decide
def e1205812786586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812786586 : Closed e1205812786586 ∧ code e1205812786586 = 5603859297690 := by decide
theorem cert_e1205812786586 : check e1205812786586 [[],[]] .smaller = true := by decide
def e1205812786654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e1205812786654 : Closed e1205812786654 ∧ code e1205812786654 = 5603859297758 := by decide
theorem cert_e1205812786654 : check e1205812786654 [[],[]] .three = true := by decide
def e1205812786670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e1205812786670 : Closed e1205812786670 ∧ code e1205812786670 = 5603859297774 := by decide
theorem cert_e1205812786670 : check e1205812786670 [[],[]] .three = true := by decide
def e1205812786742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1205812786742 : Closed e1205812786742 ∧ code e1205812786742 = 5603859297846 := by decide
theorem cert_e1205812786742 : check e1205812786742 [[],[]] .smaller = true := by decide
def e1205812786746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1205812786746 : Closed e1205812786746 ∧ code e1205812786746 = 5603859297850 := by decide
theorem cert_e1205812786746 : check e1205812786746 [[],[]] .smaller = true := by decide
def e1205812786794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1205812786794 : Closed e1205812786794 ∧ code e1205812786794 = 5603859297898 := by decide
theorem cert_e1205812786794 : check e1205812786794 [[],[]] .smaller = true := by decide
def e1205812786830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1205812786830 : Closed e1205812786830 ∧ code e1205812786830 = 5603859297934 := by decide
theorem cert_e1205812786830 : check e1205812786830 [[],[]] .smaller = true := by decide
def e1205812786842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812786842 : Closed e1205812786842 ∧ code e1205812786842 = 5603859297946 := by decide
theorem cert_e1205812786842 : check e1205812786842 [[],[]] .smaller = true := by decide
def e1205812786886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1205812786886 : Closed e1205812786886 ∧ code e1205812786886 = 5603859297990 := by decide
theorem cert_e1205812786886 : check e1205812786886 [[],[]] .smaller = true := by decide
def e1205812786910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e1205812786910 : Closed e1205812786910 ∧ code e1205812786910 = 5603859298014 := by decide
theorem cert_e1205812786910 : check e1205812786910 [[],[]] .three = true := by decide
def e1205812786934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e1205812786934 : Closed e1205812786934 ∧ code e1205812786934 = 5603859298038 := by decide
theorem cert_e1205812786934 : check e1205812786934 [[],[]] .three = true := by decide
def e1205812787038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e1205812787038 : Closed e1205812787038 ∧ code e1205812787038 = 5603859298142 := by decide
theorem cert_e1205812787038 : check e1205812787038 [[],[]] .three = true := by decide
def e1205812787066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e1205812787066 : Closed e1205812787066 ∧ code e1205812787066 = 5603859298170 := by decide
theorem cert_e1205812787066 : check e1205812787066 [[],[]] .three = true := by decide
def e1205812787118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e1205812787118 : Closed e1205812787118 ∧ code e1205812787118 = 5603859298222 := by decide
theorem cert_e1205812787118 : check e1205812787118 [[],[]] .three = true := by decide
def e1205812787126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e1205812787126 : Closed e1205812787126 ∧ code e1205812787126 = 5603859298230 := by decide
theorem cert_e1205812787126 : check e1205812787126 [[],[]] .three = true := by decide
def e1205812787130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e1205812787130 : Closed e1205812787130 ∧ code e1205812787130 = 5603859298234 := by decide
theorem cert_e1205812787130 : check e1205812787130 [[],[]] .three = true := by decide
def e1205812787414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1205812787414 : Closed e1205812787414 ∧ code e1205812787414 = 5603859298518 := by decide
theorem cert_e1205812787414 : check e1205812787414 [[],[]] .three = true := by decide
def e1205812787418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1205812787418 : Closed e1205812787418 ∧ code e1205812787418 = 5603859298522 := by decide
theorem cert_e1205812787418 : check e1205812787418 [[],[]] .three = true := by decide
def e1205812787434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1205812787434 : Closed e1205812787434 ∧ code e1205812787434 = 5603859298538 := by decide
theorem cert_e1205812787434 : check e1205812787434 [[],[]] .three = true := by decide
def e1205812787766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1205812787766 : Closed e1205812787766 ∧ code e1205812787766 = 5603859298870 := by decide
theorem cert_e1205812787766 : check e1205812787766 [[],[]] .three = true := by decide
def e1205812787770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1205812787770 : Closed e1205812787770 ∧ code e1205812787770 = 5603859298874 := by decide
theorem cert_e1205812787770 : check e1205812787770 [[],[]] .three = true := by decide
def e1205812787854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1205812787854 : Closed e1205812787854 ∧ code e1205812787854 = 5603859298958 := by decide
theorem cert_e1205812787854 : check e1205812787854 [[],[]] .three = true := by decide
def e1205812787910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1205812787910 : Closed e1205812787910 ∧ code e1205812787910 = 5603859299014 := by decide
theorem cert_e1205812787910 : check e1205812787910 [[],[]] .three = true := by decide
def e1205812787934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1205812787934 : Closed e1205812787934 ∧ code e1205812787934 = 5603859299038 := by decide
theorem cert_e1205812787934 : check e1205812787934 [[],[]] .three = true := by decide
def e1205812787950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1205812787950 : Closed e1205812787950 ∧ code e1205812787950 = 5603859299054 := by decide
theorem cert_e1205812787950 : check e1205812787950 [[],[]] .three = true := by decide
def e1205812787958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1205812787958 : Closed e1205812787958 ∧ code e1205812787958 = 5603859299062 := by decide
theorem cert_e1205812787958 : check e1205812787958 [[],[]] .three = true := by decide
def e1205812787994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1205812787994 : Closed e1205812787994 ∧ code e1205812787994 = 5603859299098 := by decide
theorem cert_e1205812787994 : check e1205812787994 [[],[]] .three = true := by decide
def e1205812788038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1205812788038 : Closed e1205812788038 ∧ code e1205812788038 = 5603859299142 := by decide
theorem cert_e1205812788038 : check e1205812788038 [[],[]] .three = true := by decide
def e1205812788062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1205812788062 : Closed e1205812788062 ∧ code e1205812788062 = 5603859299166 := by decide
theorem cert_e1205812788062 : check e1205812788062 [[],[]] .three = true := by decide
def e1205812788078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1205812788078 : Closed e1205812788078 ∧ code e1205812788078 = 5603859299182 := by decide
theorem cert_e1205812788078 : check e1205812788078 [[],[]] .three = true := by decide
def e1205812788086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1205812788086 : Closed e1205812788086 ∧ code e1205812788086 = 5603859299190 := by decide
theorem cert_e1205812788086 : check e1205812788086 [[],[]] .three = true := by decide
def e1205812788090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1205812788090 : Closed e1205812788090 ∧ code e1205812788090 = 5603859299194 := by decide
theorem cert_e1205812788090 : check e1205812788090 [[],[]] .three = true := by decide
def e1205812788142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1205812788142 : Closed e1205812788142 ∧ code e1205812788142 = 5603859299246 := by decide
theorem cert_e1205812788142 : check e1205812788142 [[],[]] .three = true := by decide
def e1205812788150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1205812788150 : Closed e1205812788150 ∧ code e1205812788150 = 5603859299254 := by decide
theorem cert_e1205812788150 : check e1205812788150 [[],[]] .three = true := by decide
def e1205812788154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1205812788154 : Closed e1205812788154 ∧ code e1205812788154 = 5603859299258 := by decide
theorem cert_e1205812788154 : check e1205812788154 [[],[]] .three = true := by decide
def e1205812788182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1205812788182 : Closed e1205812788182 ∧ code e1205812788182 = 5603859299286 := by decide
theorem cert_e1205812788182 : check e1205812788182 [[],[]] .three = true := by decide
def e1205812788186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1205812788186 : Closed e1205812788186 ∧ code e1205812788186 = 5603859299290 := by decide
theorem cert_e1205812788186 : check e1205812788186 [[],[]] .three = true := by decide
def e1205812793070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1205812793070 : Closed e1205812793070 ∧ code e1205812793070 = 5603859304174 := by decide
theorem cert_e1205812793070 : check e1205812793070 [[],[]] .smaller = true := by decide
def e1205812793078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1205812793078 : Closed e1205812793078 ∧ code e1205812793078 = 5603859304182 := by decide
theorem cert_e1205812793078 : check e1205812793078 [[],[]] .smaller = true := by decide
def e1205812793198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1205812793198 : Closed e1205812793198 ∧ code e1205812793198 = 5603859304302 := by decide
theorem cert_e1205812793198 : check e1205812793198 [[],[]] .smaller = true := by decide
def e1205812793210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1205812793210 : Closed e1205812793210 ∧ code e1205812793210 = 5603859304314 := by decide
theorem cert_e1205812793210 : check e1205812793210 [[],[]] .smaller = true := by decide
def e1205812793270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1205812793270 : Closed e1205812793270 ∧ code e1205812793270 = 5603859304374 := by decide
theorem cert_e1205812793270 : check e1205812793270 [[],[]] .smaller = true := by decide
def e1205812793274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1205812793274 : Closed e1205812793274 ∧ code e1205812793274 = 5603859304378 := by decide
theorem cert_e1205812793274 : check e1205812793274 [[],[]] .smaller = true := by decide
def e1205812795870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e1205812795870 : Closed e1205812795870 ∧ code e1205812795870 = 5603859306974 := by decide
theorem cert_e1205812795870 : check e1205812795870 [[],[]] .three = true := by decide
def e1205812795894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e1205812795894 : Closed e1205812795894 ∧ code e1205812795894 = 5603859306998 := by decide
theorem cert_e1205812795894 : check e1205812795894 [[],[]] .three = true := by decide
def e1205812796638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e1205812796638 : Closed e1205812796638 ∧ code e1205812796638 = 5603859307742 := by decide
theorem cert_e1205812796638 : check e1205812796638 [[],[]] .three = true := by decide
def e1205812796654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812796654 : Closed e1205812796654 ∧ code e1205812796654 = 5603859307758 := by decide
theorem cert_e1205812796654 : check e1205812796654 [[],[]] .smaller = true := by decide
def e1205812796662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812796662 : Closed e1205812796662 ∧ code e1205812796662 = 5603859307766 := by decide
theorem cert_e1205812796662 : check e1205812796662 [[],[]] .smaller = true := by decide
def e1205812796666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e1205812796666 : Closed e1205812796666 ∧ code e1205812796666 = 5603859307770 := by decide
theorem cert_e1205812796666 : check e1205812796666 [[],[]] .three = true := by decide
def e1205812797046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1205812797046 : Closed e1205812797046 ∧ code e1205812797046 = 5603859308150 := by decide
theorem cert_e1205812797046 : check e1205812797046 [[],[]] .smaller = true := by decide
def e1205812797238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812797238 : Closed e1205812797238 ∧ code e1205812797238 = 5603859308342 := by decide
theorem cert_e1205812797238 : check e1205812797238 [[],[]] .three = true := by decide
def e1205812797242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812797242 : Closed e1205812797242 ∧ code e1205812797242 = 5603859308346 := by decide
theorem cert_e1205812797242 : check e1205812797242 [[],[]] .three = true := by decide
def e1205812800878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1205812800878 : Closed e1205812800878 ∧ code e1205812800878 = 5603859311982 := by decide
theorem cert_e1205812800878 : check e1205812800878 [[],[]] .smaller = true := by decide
def e1205812800886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1205812800886 : Closed e1205812800886 ∧ code e1205812800886 = 5603859311990 := by decide
theorem cert_e1205812800886 : check e1205812800886 [[],[]] .smaller = true := by decide
def e1205812800942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1205812800942 : Closed e1205812800942 ∧ code e1205812800942 = 5603859312046 := by decide
theorem cert_e1205812800942 : check e1205812800942 [[],[]] .smaller = true := by decide
def e1205812800954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1205812800954 : Closed e1205812800954 ∧ code e1205812800954 = 5603859312058 := by decide
theorem cert_e1205812800954 : check e1205812800954 [[],[]] .smaller = true := by decide
def e1205812800982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1205812800982 : Closed e1205812800982 ∧ code e1205812800982 = 5603859312086 := by decide
theorem cert_e1205812800982 : check e1205812800982 [[],[]] .smaller = true := by decide
def e1205812800986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1205812800986 : Closed e1205812800986 ∧ code e1205812800986 = 5603859312090 := by decide
theorem cert_e1205812800986 : check e1205812800986 [[],[]] .smaller = true := by decide
def e1205812801198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1205812801198 : Closed e1205812801198 ∧ code e1205812801198 = 5603859312302 := by decide
theorem cert_e1205812801198 : check e1205812801198 [[],[]] .smaller = true := by decide
def e1205812801210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1205812801210 : Closed e1205812801210 ∧ code e1205812801210 = 5603859312314 := by decide
theorem cert_e1205812801210 : check e1205812801210 [[],[]] .smaller = true := by decide
def e1205812801258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1205812801258 : Closed e1205812801258 ∧ code e1205812801258 = 5603859312362 := by decide
theorem cert_e1205812801258 : check e1205812801258 [[],[]] .smaller = true := by decide
def e1205812801366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1205812801366 : Closed e1205812801366 ∧ code e1205812801366 = 5603859312470 := by decide
theorem cert_e1205812801366 : check e1205812801366 [[],[]] .smaller = true := by decide
def e1205812801370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1205812801370 : Closed e1205812801370 ∧ code e1205812801370 = 5603859312474 := by decide
theorem cert_e1205812801370 : check e1205812801370 [[],[]] .smaller = true := by decide
def e1205812801386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1205812801386 : Closed e1205812801386 ∧ code e1205812801386 = 5603859312490 := by decide
theorem cert_e1205812801386 : check e1205812801386 [[],[]] .smaller = true := by decide
def e1205812802014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1205812802014 : Closed e1205812802014 ∧ code e1205812802014 = 5603859313118 := by decide
theorem cert_e1205812802014 : check e1205812802014 [[],[]] .three = true := by decide
def e1205812802038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1205812802038 : Closed e1205812802038 ∧ code e1205812802038 = 5603859313142 := by decide
theorem cert_e1205812802038 : check e1205812802038 [[],[]] .three = true := by decide
def e1205812802414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1205812802414 : Closed e1205812802414 ∧ code e1205812802414 = 5603859313518 := by decide
theorem cert_e1205812802414 : check e1205812802414 [[],[]] .smaller = true := by decide
def e1205812802422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1205812802422 : Closed e1205812802422 ∧ code e1205812802422 = 5603859313526 := by decide
theorem cert_e1205812802422 : check e1205812802422 [[],[]] .smaller = true := by decide
def e1205812802478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1205812802478 : Closed e1205812802478 ∧ code e1205812802478 = 5603859313582 := by decide
theorem cert_e1205812802478 : check e1205812802478 [[],[]] .smaller = true := by decide
def e1205812802490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1205812802490 : Closed e1205812802490 ∧ code e1205812802490 = 5603859313594 := by decide
theorem cert_e1205812802490 : check e1205812802490 [[],[]] .smaller = true := by decide
def e1205812802518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1205812802518 : Closed e1205812802518 ∧ code e1205812802518 = 5603859313622 := by decide
theorem cert_e1205812802518 : check e1205812802518 [[],[]] .smaller = true := by decide
def e1205812802522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1205812802522 : Closed e1205812802522 ∧ code e1205812802522 = 5603859313626 := by decide
theorem cert_e1205812802522 : check e1205812802522 [[],[]] .smaller = true := by decide
def e1205812802798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205812802798 : Closed e1205812802798 ∧ code e1205812802798 = 5603859313902 := by decide
theorem cert_e1205812802798 : check e1205812802798 [[],[]] .smaller = true := by decide
def e1205812802806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205812802806 : Closed e1205812802806 ∧ code e1205812802806 = 5603859313910 := by decide
theorem cert_e1205812802806 : check e1205812802806 [[],[]] .smaller = true := by decide
def e1205812803134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e1205812803134 : Closed e1205812803134 ∧ code e1205812803134 = 5603859314238 := by decide
theorem cert_e1205812803134 : check e1205812803134 [[],[]] .three = true := by decide
def e1205812803182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812803182 : Closed e1205812803182 ∧ code e1205812803182 = 5603859314286 := by decide
theorem cert_e1205812803182 : check e1205812803182 [[],[]] .smaller = true := by decide
def e1205812803194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812803194 : Closed e1205812803194 ∧ code e1205812803194 = 5603859314298 := by decide
theorem cert_e1205812803194 : check e1205812803194 [[],[]] .smaller = true := by decide
def e1205812803382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812803382 : Closed e1205812803382 ∧ code e1205812803382 = 5603859314486 := by decide
theorem cert_e1205812803382 : check e1205812803382 [[],[]] .smaller = true := by decide
def e1205812803386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812803386 : Closed e1205812803386 ∧ code e1205812803386 = 5603859314490 := by decide
theorem cert_e1205812803386 : check e1205812803386 [[],[]] .smaller = true := by decide
def e1205812803470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e1205812803470 : Closed e1205812803470 ∧ code e1205812803470 = 5603859314574 := by decide
theorem cert_e1205812803470 : check e1205812803470 [[],[]] .three = true := by decide
def e1205812803806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e1205812803806 : Closed e1205812803806 ∧ code e1205812803806 = 5603859314910 := by decide
theorem cert_e1205812803806 : check e1205812803806 [[],[]] .three = true := by decide
def e1205812803822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205812803822 : Closed e1205812803822 ∧ code e1205812803822 = 5603859314926 := by decide
theorem cert_e1205812803822 : check e1205812803822 [[],[]] .smaller = true := by decide
def e1205812803830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1205812803830 : Closed e1205812803830 ∧ code e1205812803830 = 5603859314934 := by decide
theorem cert_e1205812803830 : check e1205812803830 [[],[]] .smaller = true := by decide
def e1205812803834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205812803834 : Closed e1205812803834 ∧ code e1205812803834 = 5603859314938 := by decide
theorem cert_e1205812803834 : check e1205812803834 [[],[]] .three = true := by decide
def e1205812804014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1205812804014 : Closed e1205812804014 ∧ code e1205812804014 = 5603859315118 := by decide
theorem cert_e1205812804014 : check e1205812804014 [[],[]] .smaller = true := by decide
def e1205812804026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1205812804026 : Closed e1205812804026 ∧ code e1205812804026 = 5603859315130 := by decide
theorem cert_e1205812804026 : check e1205812804026 [[],[]] .smaller = true := by decide
def e1205812804074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1205812804074 : Closed e1205812804074 ∧ code e1205812804074 = 5603859315178 := by decide
theorem cert_e1205812804074 : check e1205812804074 [[],[]] .smaller = true := by decide
def e1205812804158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e1205812804158 : Closed e1205812804158 ∧ code e1205812804158 = 5603859315262 := by decide
theorem cert_e1205812804158 : check e1205812804158 [[],[]] .three = true := by decide
def e1205812804206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205812804206 : Closed e1205812804206 ∧ code e1205812804206 = 5603859315310 := by decide
theorem cert_e1205812804206 : check e1205812804206 [[],[]] .smaller = true := by decide
def e1205812804218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205812804218 : Closed e1205812804218 ∧ code e1205812804218 = 5603859315322 := by decide
theorem cert_e1205812804218 : check e1205812804218 [[],[]] .smaller = true := by decide
def e1205812804382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205812804382 : Closed e1205812804382 ∧ code e1205812804382 = 5603859315486 := by decide
theorem cert_e1205812804382 : check e1205812804382 [[],[]] .smaller = true := by decide
def e1205812804494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1205812804494 : Closed e1205812804494 ∧ code e1205812804494 = 5603859315598 := by decide
theorem cert_e1205812804494 : check e1205812804494 [[],[]] .smaller = true := by decide
def e1205812804506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205812804506 : Closed e1205812804506 ∧ code e1205812804506 = 5603859315610 := by decide
theorem cert_e1205812804506 : check e1205812804506 [[],[]] .smaller = true := by decide
def e1205812804550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205812804550 : Closed e1205812804550 ∧ code e1205812804550 = 5603859315654 := by decide
theorem cert_e1205812804550 : check e1205812804550 [[],[]] .three = true := by decide
def e1205812804574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e1205812804574 : Closed e1205812804574 ∧ code e1205812804574 = 5603859315678 := by decide
theorem cert_e1205812804574 : check e1205812804574 [[],[]] .three = true := by decide
def e1205812804726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205812804726 : Closed e1205812804726 ∧ code e1205812804726 = 5603859315830 := by decide
theorem cert_e1205812804726 : check e1205812804726 [[],[]] .smaller = true := by decide
def e1205812804822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1205812804822 : Closed e1205812804822 ∧ code e1205812804822 = 5603859315926 := by decide
theorem cert_e1205812804822 : check e1205812804822 [[],[]] .smaller = true := by decide
def e1205812804826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1205812804826 : Closed e1205812804826 ∧ code e1205812804826 = 5603859315930 := by decide
theorem cert_e1205812804826 : check e1205812804826 [[],[]] .smaller = true := by decide
def e1205812804842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1205812804842 : Closed e1205812804842 ∧ code e1205812804842 = 5603859315946 := by decide
theorem cert_e1205812804842 : check e1205812804842 [[],[]] .smaller = true := by decide
def e1205812804918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205812804918 : Closed e1205812804918 ∧ code e1205812804918 = 5603859316022 := by decide
theorem cert_e1205812804918 : check e1205812804918 [[],[]] .smaller = true := by decide
def e1205812804922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205812804922 : Closed e1205812804922 ∧ code e1205812804922 = 5603859316026 := by decide
theorem cert_e1205812804922 : check e1205812804922 [[],[]] .smaller = true := by decide
end Blc.Floor42
