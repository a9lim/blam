import Batch114
import ExtraBase
namespace Blc.Floor42.Extra114
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1205824326618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1205824326618 : ¬ IsSelfInterpreter e1205824326618 := by
  intro he
  have hp := replay_sound (t := e1205824326618) (u := t_e1205824326618) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1205824326618
private def t_e1205824326902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1205824326902 : ¬ IsSelfInterpreter e1205824326902 := by
  intro he
  have hp := replay_sound (t := e1205824326902) (u := t_e1205824326902) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1205824326902
end Blc.Floor42.Extra114
