import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211590828510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211590828510 : Closed e1211590828510 ∧ code e1211590828510 = 5609637339614 := by decide
private def t_e1211590828510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem cert_e1211590828510 : ¬ IsSelfInterpreter e1211590828510 :=
  wSource (t := t_e1211590828510) (replay_sound (ps := []) (t := e1211590828510) (by decide)) (by decide)
def e1211590828534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211590828534 : Closed e1211590828534 ∧ code e1211590828534 = 5609637339638 := by decide
private def t_e1211590828534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem cert_e1211590828534 : ¬ IsSelfInterpreter e1211590828534 :=
  wSource (t := t_e1211590828534) (replay_sound (ps := []) (t := e1211590828534) (by decide)) (by decide)
def e1211590829486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211590829486 : Closed e1211590829486 ∧ code e1211590829486 = 5609637340590 := by decide
private def t_e1211590829486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem cert_e1211590829486 : ¬ IsSelfInterpreter e1211590829486 :=
  wSource (t := t_e1211590829486) (replay_sound (ps := []) (t := e1211590829486) (by decide)) (by decide)
def e1211590829498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211590829498 : Closed e1211590829498 ∧ code e1211590829498 = 5609637340602 := by decide
private def t_e1211590829498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem cert_e1211590829498 : ¬ IsSelfInterpreter e1211590829498 :=
  wSource (t := t_e1211590829498) (replay_sound (ps := []) (t := e1211590829498) (by decide)) (by decide)
def e1211590829546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211590829546 : Closed e1211590829546 ∧ code e1211590829546 = 5609637340650 := by decide
private def t_e1211590829546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem cert_e1211590829546 : ¬ IsSelfInterpreter e1211590829546 :=
  wSource (t := t_e1211590829546) (replay_sound (ps := []) (t := e1211590829546) (by decide)) (by decide)
def e1211590829678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211590829678 : Closed e1211590829678 ∧ code e1211590829678 = 5609637340782 := by decide
private def t_e1211590829678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211590829678 : ¬ IsSelfInterpreter e1211590829678 :=
  wSource (t := t_e1211590829678) (replay_sound (ps := []) (t := e1211590829678) (by decide)) (by decide)
def e1211590829690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211590829690 : Closed e1211590829690 ∧ code e1211590829690 = 5609637340794 := by decide
private def t_e1211590829690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211590829690 : ¬ IsSelfInterpreter e1211590829690 :=
  wSource (t := t_e1211590829690) (replay_sound (ps := []) (t := e1211590829690) (by decide)) (by decide)
def e1211590829978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211590829978 : Closed e1211590829978 ∧ code e1211590829978 = 5609637341082 := by decide
private def t_e1211590829978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem cert_e1211590829978 : ¬ IsSelfInterpreter e1211590829978 :=
  wSource (t := t_e1211590829978) (replay_sound (ps := []) (t := e1211590829978) (by decide)) (by decide)
def e1211590832366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211590832366 : Closed e1211590832366 ∧ code e1211590832366 = 5609637343470 := by decide
private def t_e1211590832366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem cert_e1211590832366 : ¬ IsSelfInterpreter e1211590832366 :=
  wSource (t := t_e1211590832366) (replay_sound (ps := []) (t := e1211590832366) (by decide)) (by decide)
def e1211590832374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211590832374 : Closed e1211590832374 ∧ code e1211590832374 = 5609637343478 := by decide
private def t_e1211590832374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem cert_e1211590832374 : ¬ IsSelfInterpreter e1211590832374 :=
  wSource (t := t_e1211590832374) (replay_sound (ps := []) (t := e1211590832374) (by decide)) (by decide)
def e1211590832854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211590832854 : Closed e1211590832854 ∧ code e1211590832854 = 5609637343958 := by decide
private def t_e1211590832854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem cert_e1211590832854 : ¬ IsSelfInterpreter e1211590832854 :=
  wSource (t := t_e1211590832854) (replay_sound (ps := []) (t := e1211590832854) (by decide)) (by decide)
def e1211590832858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211590832858 : Closed e1211590832858 ∧ code e1211590832858 = 5609637343962 := by decide
private def t_e1211590832858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem cert_e1211590832858 : ¬ IsSelfInterpreter e1211590832858 :=
  wSource (t := t_e1211590832858) (replay_sound (ps := []) (t := e1211590832858) (by decide)) (by decide)
def e1211590832874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211590832874 : Closed e1211590832874 ∧ code e1211590832874 = 5609637343978 := by decide
private def t_e1211590832874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem cert_e1211590832874 : ¬ IsSelfInterpreter e1211590832874 :=
  wSource (t := t_e1211590832874) (replay_sound (ps := []) (t := e1211590832874) (by decide)) (by decide)
def e1211590832950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211590832950 : Closed e1211590832950 ∧ code e1211590832950 = 5609637344054 := by decide
private def t_e1211590832950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211590832950 : ¬ IsSelfInterpreter e1211590832950 :=
  wSource (t := t_e1211590832950) (replay_sound (ps := []) (t := e1211590832950) (by decide)) (by decide)
def e1211590832954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211590832954 : Closed e1211590832954 ∧ code e1211590832954 = 5609637344058 := by decide
private def t_e1211590832954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211590832954 : ¬ IsSelfInterpreter e1211590832954 :=
  wSource (t := t_e1211590832954) (replay_sound (ps := []) (t := e1211590832954) (by decide)) (by decide)
def e1211590833050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211590833050 : Closed e1211590833050 ∧ code e1211590833050 = 5609637344154 := by decide
private def t_e1211590833050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem cert_e1211590833050 : ¬ IsSelfInterpreter e1211590833050 :=
  wSource (t := t_e1211590833050) (replay_sound (ps := []) (t := e1211590833050) (by decide)) (by decide)
def e1211590970222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211590970222 : Closed e1211590970222 ∧ code e1211590970222 = 5609637481326 := by decide
private def t_e1211590970222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211590970222 : ¬ IsSelfInterpreter e1211590970222 :=
  wSource (t := t_e1211590970222) (replay_sound (ps := []) (t := e1211590970222) (by decide)) (by decide)
def e1211590970230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211590970230 : Closed e1211590970230 ∧ code e1211590970230 = 5609637481334 := by decide
private def t_e1211590970230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211590970230 : ¬ IsSelfInterpreter e1211590970230 :=
  wSource (t := t_e1211590970230) (replay_sound (ps := []) (t := e1211590970230) (by decide)) (by decide)
def e1211590970286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211590970286 : Closed e1211590970286 ∧ code e1211590970286 = 5609637481390 := by decide
private def t_e1211590970286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211590970286 : ¬ IsSelfInterpreter e1211590970286 :=
  wSource (t := t_e1211590970286) (replay_sound (ps := []) (t := e1211590970286) (by decide)) (by decide)
def e1211590970298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211590970298 : Closed e1211590970298 ∧ code e1211590970298 = 5609637481402 := by decide
private def t_e1211590970298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211590970298 : ¬ IsSelfInterpreter e1211590970298 :=
  wSource (t := t_e1211590970298) (replay_sound (ps := []) (t := e1211590970298) (by decide)) (by decide)
def e1211590970326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211590970326 : Closed e1211590970326 ∧ code e1211590970326 = 5609637481430 := by decide
private def t_e1211590970326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211590970326 : ¬ IsSelfInterpreter e1211590970326 :=
  wSource (t := t_e1211590970326) (replay_sound (ps := []) (t := e1211590970326) (by decide)) (by decide)
def e1211590970330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211590970330 : Closed e1211590970330 ∧ code e1211590970330 = 5609637481434 := by decide
private def t_e1211590970330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211590970330 : ¬ IsSelfInterpreter e1211590970330 :=
  wSource (t := t_e1211590970330) (replay_sound (ps := []) (t := e1211590970330) (by decide)) (by decide)
def e1211590970606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211590970606 : Closed e1211590970606 ∧ code e1211590970606 = 5609637481710 := by decide
private def t_e1211590970606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211590970606 : ¬ IsSelfInterpreter e1211590970606 :=
  wSource (t := t_e1211590970606) (replay_sound (ps := []) (t := e1211590970606) (by decide)) (by decide)
def e1211590970614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211590970614 : Closed e1211590970614 ∧ code e1211590970614 = 5609637481718 := by decide
private def t_e1211590970614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211590970614 : ¬ IsSelfInterpreter e1211590970614 :=
  wSource (t := t_e1211590970614) (replay_sound (ps := []) (t := e1211590970614) (by decide)) (by decide)
def e1211590970990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211590970990 : Closed e1211590970990 ∧ code e1211590970990 = 5609637482094 := by decide
private def t_e1211590970990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211590970990 : ¬ IsSelfInterpreter e1211590970990 :=
  wSource (t := t_e1211590970990) (replay_sound (ps := []) (t := e1211590970990) (by decide)) (by decide)
def e1211590971002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211590971002 : Closed e1211590971002 ∧ code e1211590971002 = 5609637482106 := by decide
private def t_e1211590971002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211590971002 : ¬ IsSelfInterpreter e1211590971002 :=
  wSource (t := t_e1211590971002) (replay_sound (ps := []) (t := e1211590971002) (by decide)) (by decide)
def e1211590971190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211590971190 : Closed e1211590971190 ∧ code e1211590971190 = 5609637482294 := by decide
private def t_e1211590971190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211590971190 : ¬ IsSelfInterpreter e1211590971190 :=
  wSource (t := t_e1211590971190) (replay_sound (ps := []) (t := e1211590971190) (by decide)) (by decide)
def e1211590971194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211590971194 : Closed e1211590971194 ∧ code e1211590971194 = 5609637482298 := by decide
private def t_e1211590971194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211590971194 : ¬ IsSelfInterpreter e1211590971194 :=
  wSource (t := t_e1211590971194) (replay_sound (ps := []) (t := e1211590971194) (by decide)) (by decide)
def e1211608602334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211608602334 : Closed e1211608602334 ∧ code e1211608602334 = 5609655113438 := by decide
theorem cert_e1211608602334 : check e1211608602334 [[],[],[],[.left]] .chain = true := by decide
def e1211608602358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211608602358 : Closed e1211608602358 ∧ code e1211608602358 = 5609655113462 := by decide
theorem cert_e1211608602358 : check e1211608602358 [[],[],[],[.left]] .chain = true := by decide
def e1211608602462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211608602462 : Closed e1211608602462 ∧ code e1211608602462 = 5609655113566 := by decide
theorem cert_e1211608602462 : check e1211608602462 [[],[],[],[.left]] .chain = true := by decide
def e1211608602490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211608602490 : Closed e1211608602490 ∧ code e1211608602490 = 5609655113594 := by decide
theorem cert_e1211608602490 : check e1211608602490 [[],[],[],[.left]] .chain = true := by decide
def e1211608602582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211608602582 : Closed e1211608602582 ∧ code e1211608602582 = 5609655113686 := by decide
theorem cert_e1211608602582 : check e1211608602582 [[],[],[],[.left]] .chain = true := by decide
def e1211608602586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211608602586 : Closed e1211608602586 ∧ code e1211608602586 = 5609655113690 := by decide
theorem cert_e1211608602586 : check e1211608602586 [[],[],[],[.left]] .chain = true := by decide
def e1211608603102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211608603102 : Closed e1211608603102 ∧ code e1211608603102 = 5609655114206 := by decide
theorem cert_e1211608603102 : check e1211608603102 [[],[],[],[.left]] .chain = true := by decide
def e1211608603126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211608603126 : Closed e1211608603126 ∧ code e1211608603126 = 5609655114230 := by decide
theorem cert_e1211608603126 : check e1211608603126 [[],[],[],[.left]] .chain = true := by decide
def e1211608603870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211608603870 : Closed e1211608603870 ∧ code e1211608603870 = 5609655114974 := by decide
theorem cert_e1211608603870 : check e1211608603870 [[],[],[],[.left]] .chain = true := by decide
def e1211608603898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211608603898 : Closed e1211608603898 ∧ code e1211608603898 = 5609655115002 := by decide
theorem cert_e1211608603898 : check e1211608603898 [[],[],[],[.left]] .chain = true := by decide
def e1211608604470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211608604470 : Closed e1211608604470 ∧ code e1211608604470 = 5609655115574 := by decide
theorem cert_e1211608604470 : check e1211608604470 [[],[],[],[.left]] .chain = true := by decide
def e1211608604474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211608604474 : Closed e1211608604474 ∧ code e1211608604474 = 5609655115578 := by decide
theorem cert_e1211608604474 : check e1211608604474 [[],[],[],[.left]] .chain = true := by decide
def e1211608619246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211608619246 : Closed e1211608619246 ∧ code e1211608619246 = 5609655130350 := by decide
theorem cert_e1211608619246 : check e1211608619246 [[],[],[],[.left]] .chain = true := by decide
def e1211608619254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211608619254 : Closed e1211608619254 ∧ code e1211608619254 = 5609655130358 := by decide
theorem cert_e1211608619254 : check e1211608619254 [[],[],[],[.left]] .chain = true := by decide
def e1211608619806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211608619806 : Closed e1211608619806 ∧ code e1211608619806 = 5609655130910 := by decide
theorem cert_e1211608619806 : check e1211608619806 [[],[],[],[.left]] .chain = true := by decide
def e1211608619918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211608619918 : Closed e1211608619918 ∧ code e1211608619918 = 5609655131022 := by decide
theorem cert_e1211608619918 : check e1211608619918 [[],[],[],[.left]] .chain = true := by decide
def e1211608620142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211608620142 : Closed e1211608620142 ∧ code e1211608620142 = 5609655131246 := by decide
theorem cert_e1211608620142 : check e1211608620142 [[],[],[],[.left]] .chain = true := by decide
def e1211608620154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211608620154 : Closed e1211608620154 ∧ code e1211608620154 = 5609655131258 := by decide
theorem cert_e1211608620154 : check e1211608620154 [[],[],[],[.left]] .chain = true := by decide
def e1211608620318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211608620318 : Closed e1211608620318 ∧ code e1211608620318 = 5609655131422 := by decide
theorem cert_e1211608620318 : check e1211608620318 [[],[],[],[.left]] .chain = true := by decide
def e1211608620486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211608620486 : Closed e1211608620486 ∧ code e1211608620486 = 5609655131590 := by decide
theorem cert_e1211608620486 : check e1211608620486 [[],[],[],[.left]] .chain = true := by decide
def e1211608620510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211608620510 : Closed e1211608620510 ∧ code e1211608620510 = 5609655131614 := by decide
theorem cert_e1211608620510 : check e1211608620510 [[],[],[],[.left],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211608620526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211608620526 : Closed e1211608620526 ∧ code e1211608620526 = 5609655131630 := by decide
def e1211608620598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211608620598 : Closed e1211608620598 ∧ code e1211608620598 = 5609655131702 := by decide
theorem cert_e1211608620598 : check e1211608620598 [[],[],[],[.left]] .chain = true := by decide
def e1211608620602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211608620602 : Closed e1211608620602 ∧ code e1211608620602 = 5609655131706 := by decide
theorem cert_e1211608620602 : check e1211608620602 [[],[],[],[.left]] .chain = true := by decide
def e1211608620686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211608620686 : Closed e1211608620686 ∧ code e1211608620686 = 5609655131790 := by decide
theorem cert_e1211608620686 : check e1211608620686 [[],[],[],[.left]] .chain = true := by decide
def e1211608620742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211608620742 : Closed e1211608620742 ∧ code e1211608620742 = 5609655131846 := by decide
theorem cert_e1211608620742 : check e1211608620742 [[],[],[],[.left]] .chain = true := by decide
def e1211608620766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211608620766 : Closed e1211608620766 ∧ code e1211608620766 = 5609655131870 := by decide
theorem cert_e1211608620766 : check e1211608620766 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211608620790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211608620790 : Closed e1211608620790 ∧ code e1211608620790 = 5609655131894 := by decide
private def t_e1211608620790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem cert_e1211608620790 : ¬ IsSelfInterpreter e1211608620790 :=
  wSource (t := t_e1211608620790) (replay_sound (ps := []) (t := e1211608620790) (by decide)) (by decide)
def e1211608620910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211608620910 : Closed e1211608620910 ∧ code e1211608620910 = 5609655132014 := by decide
def e1211608620918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211608620918 : Closed e1211608620918 ∧ code e1211608620918 = 5609655132022 := by decide
private def t_e1211608620918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem cert_e1211608620918 : ¬ IsSelfInterpreter e1211608620918 :=
  wSource (t := t_e1211608620918) (replay_sound (ps := []) (t := e1211608620918) (by decide)) (by decide)
def e1211608622878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211608622878 : Closed e1211608622878 ∧ code e1211608622878 = 5609655133982 := by decide
theorem cert_e1211608622878 : check e1211608622878 [[],[],[],[.left]] .chain = true := by decide
def e1211608622990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211608622990 : Closed e1211608622990 ∧ code e1211608622990 = 5609655134094 := by decide
theorem cert_e1211608622990 : check e1211608622990 [[],[],[],[.left]] .chain = true := by decide
def e1211608625950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211608625950 : Closed e1211608625950 ∧ code e1211608625950 = 5609655137054 := by decide
theorem cert_e1211608625950 : check e1211608625950 [[],[],[],[.left]] .chain = true := by decide
def e1211608626118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211608626118 : Closed e1211608626118 ∧ code e1211608626118 = 5609655137222 := by decide
theorem cert_e1211608626118 : check e1211608626118 [[],[],[],[.left]] .chain = true := by decide
def e1211608626142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211608626142 : Closed e1211608626142 ∧ code e1211608626142 = 5609655137246 := by decide
theorem cert_e1211608626142 : check e1211608626142 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e1211608626158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211608626158 : Closed e1211608626158 ∧ code e1211608626158 = 5609655137262 := by decide
theorem cert_e1211608626158 : check e1211608626158 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e1211608627598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211608627598 : Closed e1211608627598 ∧ code e1211608627598 = 5609655138702 := by decide
theorem cert_e1211608627598 : check e1211608627598 [[],[],[],[.left]] .chain = true := by decide
def e1211608627654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211608627654 : Closed e1211608627654 ∧ code e1211608627654 = 5609655138758 := by decide
theorem cert_e1211608627654 : check e1211608627654 [[],[],[],[.left]] .chain = true := by decide
def e1211608627678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211608627678 : Closed e1211608627678 ∧ code e1211608627678 = 5609655138782 := by decide
theorem cert_e1211608627678 : check e1211608627678 [[],[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1211608627702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211608627702 : Closed e1211608627702 ∧ code e1211608627702 = 5609655138806 := by decide
theorem cert_e1211608627702 : check e1211608627702 [[],[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1211608628462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211608628462 : Closed e1211608628462 ∧ code e1211608628462 = 5609655139566 := by decide
def e1211608628470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211608628470 : Closed e1211608628470 ∧ code e1211608628470 = 5609655139574 := by decide
def e1211608685422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211608685422 : Closed e1211608685422 ∧ code e1211608685422 = 5609655196526 := by decide
def e1211608685430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211608685430 : Closed e1211608685430 ∧ code e1211608685430 = 5609655196534 := by decide
def e1211608685494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211608685494 : Closed e1211608685494 ∧ code e1211608685494 = 5609655196598 := by decide
def e1211608685934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211608685934 : Closed e1211608685934 ∧ code e1211608685934 = 5609655197038 := by decide
def e1211608685942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211608685942 : Closed e1211608685942 ∧ code e1211608685942 = 5609655197046 := by decide
def e1211608685998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211608685998 : Closed e1211608685998 ∧ code e1211608685998 = 5609655197102 := by decide
private def t_e1211608685998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem cert_e1211608685998 : ¬ IsSelfInterpreter e1211608685998 :=
  wSource (t := t_e1211608685998) (replay_sound (ps := []) (t := e1211608685998) (by decide)) (by decide)
def e1211608686010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211608686010 : Closed e1211608686010 ∧ code e1211608686010 = 5609655197114 := by decide
private def t_e1211608686010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem cert_e1211608686010 : ¬ IsSelfInterpreter e1211608686010 :=
  wSource (t := t_e1211608686010) (replay_sound (ps := []) (t := e1211608686010) (by decide)) (by decide)
def e1211608686038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211608686038 : Closed e1211608686038 ∧ code e1211608686038 = 5609655197142 := by decide
private def t_e1211608686038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e1211608686038 : ¬ IsSelfInterpreter e1211608686038 :=
  wSource (t := t_e1211608686038) (replay_sound (ps := []) (t := e1211608686038) (by decide)) (by decide)
def e1211608686042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211608686042 : Closed e1211608686042 ∧ code e1211608686042 = 5609655197146 := by decide
private def t_e1211608686042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e1211608686042 : ¬ IsSelfInterpreter e1211608686042 :=
  wSource (t := t_e1211608686042) (replay_sound (ps := []) (t := e1211608686042) (by decide)) (by decide)
def e1211608686262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211608686262 : Closed e1211608686262 ∧ code e1211608686262 = 5609655197366 := by decide
def e1211608686294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211608686294 : Closed e1211608686294 ∧ code e1211608686294 = 5609655197398 := by decide
private def t_e1211608686294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem cert_e1211608686294 : ¬ IsSelfInterpreter e1211608686294 :=
  wSource (t := t_e1211608686294) (replay_sound (ps := []) (t := e1211608686294) (by decide)) (by decide)
def e1211608686298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211608686298 : Closed e1211608686298 ∧ code e1211608686298 = 5609655197402 := by decide
private def t_e1211608686298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem cert_e1211608686298 : ¬ IsSelfInterpreter e1211608686298 :=
  wSource (t := t_e1211608686298) (replay_sound (ps := []) (t := e1211608686298) (by decide)) (by decide)
def e1211608688494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211608688494 : Closed e1211608688494 ∧ code e1211608688494 = 5609655199598 := by decide
def e1211608688502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211608688502 : Closed e1211608688502 ∧ code e1211608688502 = 5609655199606 := by decide
def e1211608688566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211608688566 : Closed e1211608688566 ∧ code e1211608688566 = 5609655199670 := by decide
def e1211608689902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211608689902 : Closed e1211608689902 ∧ code e1211608689902 = 5609655201006 := by decide
def e1211608689910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211608689910 : Closed e1211608689910 ∧ code e1211608689910 = 5609655201014 := by decide
def e1211608690294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211608690294 : Closed e1211608690294 ∧ code e1211608690294 = 5609655201398 := by decide
def e1211608691566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211608691566 : Closed e1211608691566 ∧ code e1211608691566 = 5609655202670 := by decide
def e1211608691574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211608691574 : Closed e1211608691574 ∧ code e1211608691574 = 5609655202678 := by decide
def e1211608691630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211608691630 : Closed e1211608691630 ∧ code e1211608691630 = 5609655202734 := by decide
def e1211608691642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211608691642 : Closed e1211608691642 ∧ code e1211608691642 = 5609655202746 := by decide
private def t_e1211608691642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem cert_e1211608691642 : ¬ IsSelfInterpreter e1211608691642 :=
  wSource (t := t_e1211608691642) (replay_sound (ps := []) (t := e1211608691642) (by decide)) (by decide)
def e1211608691670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211608691670 : Closed e1211608691670 ∧ code e1211608691670 = 5609655202774 := by decide
def e1211608691674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211608691674 : Closed e1211608691674 ∧ code e1211608691674 = 5609655202778 := by decide
private def t_e1211608691674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem cert_e1211608691674 : ¬ IsSelfInterpreter e1211608691674 :=
  wSource (t := t_e1211608691674) (replay_sound (ps := []) (t := e1211608691674) (by decide)) (by decide)
def e1211608691950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211608691950 : Closed e1211608691950 ∧ code e1211608691950 = 5609655203054 := by decide
def e1211608691958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211608691958 : Closed e1211608691958 ∧ code e1211608691958 = 5609655203062 := by decide
def e1211608692334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211608692334 : Closed e1211608692334 ∧ code e1211608692334 = 5609655203438 := by decide
private def t_e1211608692334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211608692334 : ¬ IsSelfInterpreter e1211608692334 :=
  wSource (t := t_e1211608692334) (replay_sound (ps := []) (t := e1211608692334) (by decide)) (by decide)
def e1211608692346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211608692346 : Closed e1211608692346 ∧ code e1211608692346 = 5609655203450 := by decide
private def t_e1211608692346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211608692346 : ¬ IsSelfInterpreter e1211608692346 :=
  wSource (t := t_e1211608692346) (replay_sound (ps := []) (t := e1211608692346) (by decide)) (by decide)
def e1211608692534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211608692534 : Closed e1211608692534 ∧ code e1211608692534 = 5609655203638 := by decide
private def t_e1211608692534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211608692534 : ¬ IsSelfInterpreter e1211608692534 :=
  wSource (t := t_e1211608692534) (replay_sound (ps := []) (t := e1211608692534) (by decide)) (by decide)
def e1211608692538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211608692538 : Closed e1211608692538 ∧ code e1211608692538 = 5609655203642 := by decide
private def t_e1211608692538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211608692538 : ¬ IsSelfInterpreter e1211608692538 :=
  wSource (t := t_e1211608692538) (replay_sound (ps := []) (t := e1211608692538) (by decide)) (by decide)
def e1211608693174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211608693174 : Closed e1211608693174 ∧ code e1211608693174 = 5609655204278 := by decide
def e1211608693206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211608693206 : Closed e1211608693206 ∧ code e1211608693206 = 5609655204310 := by decide
def e1211608693210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211608693210 : Closed e1211608693210 ∧ code e1211608693210 = 5609655204314 := by decide
private def t_e1211608693210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem cert_e1211608693210 : ¬ IsSelfInterpreter e1211608693210 :=
  wSource (t := t_e1211608693210) (replay_sound (ps := []) (t := e1211608693210) (by decide)) (by decide)
def e1211608693366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211608693366 : Closed e1211608693366 ∧ code e1211608693366 = 5609655204470 := by decide
def e1211608693558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211608693558 : Closed e1211608693558 ∧ code e1211608693558 = 5609655204662 := by decide
private def t_e1211608693558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211608693558 : ¬ IsSelfInterpreter e1211608693558 :=
  wSource (t := t_e1211608693558) (replay_sound (ps := []) (t := e1211608693558) (by decide)) (by decide)
def e1211608693562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211608693562 : Closed e1211608693562 ∧ code e1211608693562 = 5609655204666 := by decide
private def t_e1211608693562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211608693562 : ¬ IsSelfInterpreter e1211608693562 :=
  wSource (t := t_e1211608693562) (replay_sound (ps := []) (t := e1211608693562) (by decide)) (by decide)
def e1211608700782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211608700782 : Closed e1211608700782 ∧ code e1211608700782 = 5609655211886 := by decide
def e1211608700790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211608700790 : Closed e1211608700790 ∧ code e1211608700790 = 5609655211894 := by decide
def e1211608700854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211608700854 : Closed e1211608700854 ∧ code e1211608700854 = 5609655211958 := by decide
def e1211608702190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211608702190 : Closed e1211608702190 ∧ code e1211608702190 = 5609655213294 := by decide
def e1211608702198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211608702198 : Closed e1211608702198 ∧ code e1211608702198 = 5609655213302 := by decide
def e1211608702582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211608702582 : Closed e1211608702582 ∧ code e1211608702582 = 5609655213686 := by decide
def e1211608714094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211608714094 : Closed e1211608714094 ∧ code e1211608714094 = 5609655225198 := by decide
def e1211608714102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211608714102 : Closed e1211608714102 ∧ code e1211608714102 = 5609655225206 := by decide
def e1211608714158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211608714158 : Closed e1211608714158 ∧ code e1211608714158 = 5609655225262 := by decide
def e1211608714170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211608714170 : Closed e1211608714170 ∧ code e1211608714170 = 5609655225274 := by decide
private def t_e1211608714170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211608714170 : ¬ IsSelfInterpreter e1211608714170 :=
  wSource (t := t_e1211608714170) (replay_sound (ps := []) (t := e1211608714170) (by decide)) (by decide)
def e1211608714198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211608714198 : Closed e1211608714198 ∧ code e1211608714198 = 5609655225302 := by decide
def e1211608714202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211608714202 : Closed e1211608714202 ∧ code e1211608714202 = 5609655225306 := by decide
private def t_e1211608714202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211608714202 : ¬ IsSelfInterpreter e1211608714202 :=
  wSource (t := t_e1211608714202) (replay_sound (ps := []) (t := e1211608714202) (by decide)) (by decide)
def e1211608714478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211608714478 : Closed e1211608714478 ∧ code e1211608714478 = 5609655225582 := by decide
def e1211608714486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211608714486 : Closed e1211608714486 ∧ code e1211608714486 = 5609655225590 := by decide
def e1211608714862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211608714862 : Closed e1211608714862 ∧ code e1211608714862 = 5609655225966 := by decide
def e1211608714874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211608714874 : Closed e1211608714874 ∧ code e1211608714874 = 5609655225978 := by decide
def e1211608715062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211608715062 : Closed e1211608715062 ∧ code e1211608715062 = 5609655226166 := by decide
def e1211608715066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211608715066 : Closed e1211608715066 ∧ code e1211608715066 = 5609655226170 := by decide
def e1211608720822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211608720822 : Closed e1211608720822 ∧ code e1211608720822 = 5609655231926 := by decide
def e1211608720854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211608720854 : Closed e1211608720854 ∧ code e1211608720854 = 5609655231958 := by decide
def e1211608720858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211608720858 : Closed e1211608720858 ∧ code e1211608720858 = 5609655231962 := by decide
private def t_e1211608720858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem cert_e1211608720858 : ¬ IsSelfInterpreter e1211608720858 :=
  wSource (t := t_e1211608720858) (replay_sound (ps := []) (t := e1211608720858) (by decide)) (by decide)
def e1211608721014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211608721014 : Closed e1211608721014 ∧ code e1211608721014 = 5609655232118 := by decide
def e1211608721206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211608721206 : Closed e1211608721206 ∧ code e1211608721206 = 5609655232310 := by decide
def e1211608721210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211608721210 : Closed e1211608721210 ∧ code e1211608721210 = 5609655232314 := by decide
def e1211609058158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211609058158 : Closed e1211609058158 ∧ code e1211609058158 = 5609655569262 := by decide
private def t_e1211609058158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211609058158 : ¬ IsSelfInterpreter e1211609058158 :=
  wSource (t := t_e1211609058158) (replay_sound (ps := []) (t := e1211609058158) (by decide)) (by decide)
def e1211609058166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211609058166 : Closed e1211609058166 ∧ code e1211609058166 = 5609655569270 := by decide
private def t_e1211609058166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211609058166 : ¬ IsSelfInterpreter e1211609058166 :=
  wSource (t := t_e1211609058166) (replay_sound (ps := []) (t := e1211609058166) (by decide)) (by decide)
def e1211609058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211609058222 : Closed e1211609058222 ∧ code e1211609058222 = 5609655569326 := by decide
private def t_e1211609058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211609058222 : ¬ IsSelfInterpreter e1211609058222 :=
  wSource (t := t_e1211609058222) (replay_sound (ps := []) (t := e1211609058222) (by decide)) (by decide)
def e1211609058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211609058234 : Closed e1211609058234 ∧ code e1211609058234 = 5609655569338 := by decide
private def t_e1211609058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211609058234 : ¬ IsSelfInterpreter e1211609058234 :=
  wSource (t := t_e1211609058234) (replay_sound (ps := []) (t := e1211609058234) (by decide)) (by decide)
def e1211609058262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211609058262 : Closed e1211609058262 ∧ code e1211609058262 = 5609655569366 := by decide
private def t_e1211609058262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211609058262 : ¬ IsSelfInterpreter e1211609058262 :=
  wSource (t := t_e1211609058262) (replay_sound (ps := []) (t := e1211609058262) (by decide)) (by decide)
def e1211609058266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211609058266 : Closed e1211609058266 ∧ code e1211609058266 = 5609655569370 := by decide
private def t_e1211609058266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211609058266 : ¬ IsSelfInterpreter e1211609058266 :=
  wSource (t := t_e1211609058266) (replay_sound (ps := []) (t := e1211609058266) (by decide)) (by decide)
def e1211609058542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211609058542 : Closed e1211609058542 ∧ code e1211609058542 = 5609655569646 := by decide
private def t_e1211609058542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211609058542 : ¬ IsSelfInterpreter e1211609058542 :=
  wSource (t := t_e1211609058542) (replay_sound (ps := []) (t := e1211609058542) (by decide)) (by decide)
def e1211609058550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211609058550 : Closed e1211609058550 ∧ code e1211609058550 = 5609655569654 := by decide
private def t_e1211609058550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211609058550 : ¬ IsSelfInterpreter e1211609058550 :=
  wSource (t := t_e1211609058550) (replay_sound (ps := []) (t := e1211609058550) (by decide)) (by decide)
def e1211609058926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211609058926 : Closed e1211609058926 ∧ code e1211609058926 = 5609655570030 := by decide
private def t_e1211609058926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211609058926 : ¬ IsSelfInterpreter e1211609058926 :=
  wSource (t := t_e1211609058926) (replay_sound (ps := []) (t := e1211609058926) (by decide)) (by decide)
def e1211609058938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211609058938 : Closed e1211609058938 ∧ code e1211609058938 = 5609655570042 := by decide
private def t_e1211609058938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211609058938 : ¬ IsSelfInterpreter e1211609058938 :=
  wSource (t := t_e1211609058938) (replay_sound (ps := []) (t := e1211609058938) (by decide)) (by decide)
def e1211609059126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211609059126 : Closed e1211609059126 ∧ code e1211609059126 = 5609655570230 := by decide
private def t_e1211609059126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211609059126 : ¬ IsSelfInterpreter e1211609059126 :=
  wSource (t := t_e1211609059126) (replay_sound (ps := []) (t := e1211609059126) (by decide)) (by decide)
def e1211609059130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211609059130 : Closed e1211609059130 ∧ code e1211609059130 = 5609655570234 := by decide
private def t_e1211609059130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211609059130 : ¬ IsSelfInterpreter e1211609059130 :=
  wSource (t := t_e1211609059130) (replay_sound (ps := []) (t := e1211609059130) (by decide)) (by decide)
def e1212358331246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1212358331246 : Closed e1212358331246 ∧ code e1212358331246 = 5610404842350 := by decide
theorem cert_e1212358331246 : check e1212358331246 [[],[.left]] .chain = true := by decide
def e1212358331254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1212358331254 : Closed e1212358331254 ∧ code e1212358331254 = 5610404842358 := by decide
theorem cert_e1212358331254 : check e1212358331254 [[],[.left]] .chain = true := by decide
def e1212358331310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1212358331310 : Closed e1212358331310 ∧ code e1212358331310 = 5610404842414 := by decide
theorem cert_e1212358331310 : check e1212358331310 [[],[.left]] .chain = true := by decide
def e1212358331322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1212358331322 : Closed e1212358331322 ∧ code e1212358331322 = 5610404842426 := by decide
theorem cert_e1212358331322 : check e1212358331322 [[],[.left]] .chain = true := by decide
def e1212358331350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1212358331350 : Closed e1212358331350 ∧ code e1212358331350 = 5610404842454 := by decide
theorem cert_e1212358331350 : check e1212358331350 [[],[.left]] .chain = true := by decide
def e1212358331354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1212358331354 : Closed e1212358331354 ∧ code e1212358331354 = 5610404842458 := by decide
theorem cert_e1212358331354 : check e1212358331354 [[],[.left]] .chain = true := by decide
def e1212358331630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1212358331630 : Closed e1212358331630 ∧ code e1212358331630 = 5610404842734 := by decide
theorem cert_e1212358331630 : check e1212358331630 [[],[.left]] .chain = true := by decide
def e1212358331638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1212358331638 : Closed e1212358331638 ∧ code e1212358331638 = 5610404842742 := by decide
theorem cert_e1212358331638 : check e1212358331638 [[],[.left]] .chain = true := by decide
def e1212358332014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1212358332014 : Closed e1212358332014 ∧ code e1212358332014 = 5610404843118 := by decide
theorem cert_e1212358332014 : check e1212358332014 [[],[.left]] .chain = true := by decide
def e1212358332026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1212358332026 : Closed e1212358332026 ∧ code e1212358332026 = 5610404843130 := by decide
theorem cert_e1212358332026 : check e1212358332026 [[],[.left]] .chain = true := by decide
def e1212358332214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1212358332214 : Closed e1212358332214 ∧ code e1212358332214 = 5610404843318 := by decide
theorem cert_e1212358332214 : check e1212358332214 [[],[.left]] .chain = true := by decide
def e1212358332218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1212358332218 : Closed e1212358332218 ∧ code e1212358332218 = 5610404843322 := by decide
theorem cert_e1212358332218 : check e1212358332218 [[],[.left]] .chain = true := by decide
def e1212363577054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1212363577054 : Closed e1212363577054 ∧ code e1212363577054 = 5610410088158 := by decide
theorem cert_e1212363577054 : check e1212363577054 [[],[.left]] .chain = true := by decide
def e1212363577078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1212363577078 : Closed e1212363577078 ∧ code e1212363577078 = 5610410088182 := by decide
theorem cert_e1212363577078 : check e1212363577078 [[],[.left]] .chain = true := by decide
def e1212363577182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1212363577182 : Closed e1212363577182 ∧ code e1212363577182 = 5610410088286 := by decide
theorem cert_e1212363577182 : check e1212363577182 [[],[.left]] .chain = true := by decide
def e1212363577210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1212363577210 : Closed e1212363577210 ∧ code e1212363577210 = 5610410088314 := by decide
theorem cert_e1212363577210 : check e1212363577210 [[],[.left]] .chain = true := by decide
def e1212363577302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1212363577302 : Closed e1212363577302 ∧ code e1212363577302 = 5610410088406 := by decide
theorem cert_e1212363577302 : check e1212363577302 [[],[.left]] .chain = true := by decide
def e1212363577306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1212363577306 : Closed e1212363577306 ∧ code e1212363577306 = 5610410088410 := by decide
theorem cert_e1212363577306 : check e1212363577306 [[],[.left]] .chain = true := by decide
end Blc.Floor42
