import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202842700654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1202842700654 : Closed e1202842700654 ∧ code e1202842700654 = 5600889211758 := by decide
theorem cert_e1202842700654 : check e1202842700654 [[],[]] .chain = true := by decide
def e1202842700662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1202842700662 : Closed e1202842700662 ∧ code e1202842700662 = 5600889211766 := by decide
theorem cert_e1202842700662 : check e1202842700662 [[],[]] .chain = true := by decide
def e1202842700718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1202842700718 : Closed e1202842700718 ∧ code e1202842700718 = 5600889211822 := by decide
theorem cert_e1202842700718 : check e1202842700718 [[],[]] .chain = true := by decide
def e1202842700730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1202842700730 : Closed e1202842700730 ∧ code e1202842700730 = 5600889211834 := by decide
theorem cert_e1202842700730 : check e1202842700730 [[],[]] .chain = true := by decide
def e1202842700758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1202842700758 : Closed e1202842700758 ∧ code e1202842700758 = 5600889211862 := by decide
theorem cert_e1202842700758 : check e1202842700758 [[],[]] .chain = true := by decide
def e1202842700762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1202842700762 : Closed e1202842700762 ∧ code e1202842700762 = 5600889211866 := by decide
theorem cert_e1202842700762 : check e1202842700762 [[],[]] .chain = true := by decide
def e1202842701038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1202842701038 : Closed e1202842701038 ∧ code e1202842701038 = 5600889212142 := by decide
theorem cert_e1202842701038 : check e1202842701038 [[],[]] .chain = true := by decide
def e1202842701046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1202842701046 : Closed e1202842701046 ∧ code e1202842701046 = 5600889212150 := by decide
theorem cert_e1202842701046 : check e1202842701046 [[],[]] .chain = true := by decide
def e1202842701422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1202842701422 : Closed e1202842701422 ∧ code e1202842701422 = 5600889212526 := by decide
theorem cert_e1202842701422 : check e1202842701422 [[],[]] .chain = true := by decide
def e1202842701434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1202842701434 : Closed e1202842701434 ∧ code e1202842701434 = 5600889212538 := by decide
theorem cert_e1202842701434 : check e1202842701434 [[],[]] .chain = true := by decide
def e1202842701622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1202842701622 : Closed e1202842701622 ∧ code e1202842701622 = 5600889212726 := by decide
theorem cert_e1202842701622 : check e1202842701622 [[],[]] .chain = true := by decide
def e1202842701626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1202842701626 : Closed e1202842701626 ∧ code e1202842701626 = 5600889212730 := by decide
theorem cert_e1202842701626 : check e1202842701626 [[],[]] .chain = true := by decide
def e1202843290478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1202843290478 : Closed e1202843290478 ∧ code e1202843290478 = 5600889801582 := by decide
theorem cert_e1202843290478 : check e1202843290478 [[],[],[]] .smaller = true := by decide
def e1202843290486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1202843290486 : Closed e1202843290486 ∧ code e1202843290486 = 5600889801590 := by decide
theorem cert_e1202843290486 : check e1202843290486 [[],[],[]] .smaller = true := by decide
def e1202843290542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1202843290542 : Closed e1202843290542 ∧ code e1202843290542 = 5600889801646 := by decide
theorem cert_e1202843290542 : check e1202843290542 [[],[],[]] .smaller = true := by decide
def e1202843290554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1202843290554 : Closed e1202843290554 ∧ code e1202843290554 = 5600889801658 := by decide
theorem cert_e1202843290554 : check e1202843290554 [[],[],[]] .smaller = true := by decide
def e1202843290582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1202843290582 : Closed e1202843290582 ∧ code e1202843290582 = 5600889801686 := by decide
theorem cert_e1202843290582 : check e1202843290582 [[],[],[]] .smaller = true := by decide
def e1202843290586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1202843290586 : Closed e1202843290586 ∧ code e1202843290586 = 5600889801690 := by decide
theorem cert_e1202843290586 : check e1202843290586 [[],[],[]] .smaller = true := by decide
def e1202843290862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1202843290862 : Closed e1202843290862 ∧ code e1202843290862 = 5600889801966 := by decide
theorem cert_e1202843290862 : check e1202843290862 [[],[],[]] .smaller = true := by decide
def e1202843290870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1202843290870 : Closed e1202843290870 ∧ code e1202843290870 = 5600889801974 := by decide
theorem cert_e1202843290870 : check e1202843290870 [[],[],[]] .smaller = true := by decide
def e1202843291246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1202843291246 : Closed e1202843291246 ∧ code e1202843291246 = 5600889802350 := by decide
theorem cert_e1202843291246 : check e1202843291246 [[],[],[]] .smaller = true := by decide
def e1202843291258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1202843291258 : Closed e1202843291258 ∧ code e1202843291258 = 5600889802362 := by decide
theorem cert_e1202843291258 : check e1202843291258 [[],[],[]] .smaller = true := by decide
def e1202843291446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1202843291446 : Closed e1202843291446 ∧ code e1202843291446 = 5600889802550 := by decide
theorem cert_e1202843291446 : check e1202843291446 [[],[],[]] .smaller = true := by decide
def e1202843291450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1202843291450 : Closed e1202843291450 ∧ code e1202843291450 = 5600889802554 := by decide
theorem cert_e1202843291450 : check e1202843291450 [[],[],[]] .smaller = true := by decide
def e1202952302790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202952302790 : Closed e1202952302790 ∧ code e1202952302790 = 5600998813894 := by decide
theorem cert_e1202952302790 : check e1202952302790 [[]] .width = true := by decide
def e1202952319174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202952319174 : Closed e1202952319174 ∧ code e1202952319174 = 5600998830278 := by decide
theorem cert_e1202952319174 : check e1202952319174 [[]] .width = true := by decide
def e1202952452122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202952452122 : Closed e1202952452122 ∧ code e1202952452122 = 5600998963226 := by decide
theorem cert_e1202952452122 : check e1202952452122 [[]] .width = true := by decide
def e1202952460314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202952460314 : Closed e1202952460314 ∧ code e1202952460314 = 5600998971418 := by decide
theorem cert_e1202952460314 : check e1202952460314 [[]] .width = true := by decide
def e1202952517658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202952517658 : Closed e1202952517658 ∧ code e1202952517658 = 5600999028762 := by decide
theorem cert_e1202952517658 : check e1202952517658 [[]] .width = true := by decide
def e1202952529946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202952529946 : Closed e1202952529946 ∧ code e1202952529946 = 5600999041050 := by decide
theorem cert_e1202952529946 : check e1202952529946 [[]] .width = true := by decide
def e1202952531482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202952531482 : Closed e1202952531482 ∧ code e1202952531482 = 5600999042586 := by decide
theorem cert_e1202952531482 : check e1202952531482 [[]] .width = true := by decide
def e1202952564250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202952564250 : Closed e1202952564250 ∧ code e1202952564250 = 5600999075354 := by decide
theorem cert_e1202952564250 : check e1202952564250 [[]] .width = true := by decide
def e1202952566298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202952566298 : Closed e1202952566298 ∧ code e1202952566298 = 5600999077402 := by decide
theorem cert_e1202952566298 : check e1202952566298 [[]] .width = true := by decide
def e1202953893914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202953893914 : Closed e1202953893914 ∧ code e1202953893914 = 5601000405018 := by decide
theorem cert_e1202953893914 : check e1202953893914 [[]] .width = true := by decide
def e1202954551494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202954551494 : Closed e1202954551494 ∧ code e1202954551494 = 5601001062598 := by decide
theorem cert_e1202954551494 : check e1202954551494 [[]] .width = true := by decide
def e1202954582042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202954582042 : Closed e1202954582042 ∧ code e1202954582042 = 5601001093146 := by decide
theorem cert_e1202954582042 : check e1202954582042 [[]] .width = true := by decide
def e1202954617030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202954617030 : Closed e1202954617030 ∧ code e1202954617030 = 5601001128134 := by decide
theorem cert_e1202954617030 : check e1202954617030 [[]] .width = true := by decide
def e1202954793158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202954793158 : Closed e1202954793158 ∧ code e1202954793158 = 5601001304262 := by decide
theorem cert_e1202954793158 : check e1202954793158 [[]] .width = true := by decide
def e1202954811418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202954811418 : Closed e1202954811418 ∧ code e1202954811418 = 5601001322522 := by decide
theorem cert_e1202954811418 : check e1202954811418 [[]] .width = true := by decide
def e1202954825242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202954825242 : Closed e1202954825242 ∧ code e1202954825242 = 5601001336346 := by decide
theorem cert_e1202954825242 : check e1202954825242 [[]] .width = true := by decide
def e1202955075782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202955075782 : Closed e1202955075782 ∧ code e1202955075782 = 5601001586886 := by decide
theorem cert_e1202955075782 : check e1202955075782 [[]] .width = true := by decide
def e1202955149338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202955149338 : Closed e1202955149338 ∧ code e1202955149338 = 5601001660442 := by decide
theorem cert_e1202955149338 : check e1202955149338 [[]] .width = true := by decide
def e1202955149430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202955149430 : Closed e1202955149430 ∧ code e1202955149430 = 5601001660534 := by decide
theorem cert_e1202955149430 : check e1202955149430 [[]] .width = true := by decide
def e1202955149674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202955149674 : Closed e1202955149674 ∧ code e1202955149674 = 5601001660778 := by decide
theorem cert_e1202955149674 : check e1202955149674 [[]] .width = true := by decide
def e1202955149722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202955149722 : Closed e1202955149722 ∧ code e1202955149722 = 5601001660826 := by decide
theorem cert_e1202955149722 : check e1202955149722 [[]] .width = true := by decide
def e1202955161798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955161798 : Closed e1202955161798 ∧ code e1202955161798 = 5601001672902 := by decide
theorem cert_e1202955161798 : check e1202955161798 [[]] .width = true := by decide
def e1202955163674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202955163674 : Closed e1202955163674 ∧ code e1202955163674 = 5601001674778 := by decide
theorem cert_e1202955163674 : check e1202955163674 [[]] .width = true := by decide
def e1202955165210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202955165210 : Closed e1202955165210 ∧ code e1202955165210 = 5601001676314 := by decide
theorem cert_e1202955165210 : check e1202955165210 [[]] .width = true := by decide
def e1202955174086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202955174086 : Closed e1202955174086 ∧ code e1202955174086 = 5601001685190 := by decide
theorem cert_e1202955174086 : check e1202955174086 [[]] .width = true := by decide
def e1202955182106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202955182106 : Closed e1202955182106 ∧ code e1202955182106 = 5601001693210 := by decide
theorem cert_e1202955182106 : check e1202955182106 [[]] .width = true := by decide
def e1202955182198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202955182198 : Closed e1202955182198 ∧ code e1202955182198 = 5601001693302 := by decide
theorem cert_e1202955182198 : check e1202955182198 [[]] .width = true := by decide
def e1202955182442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202955182442 : Closed e1202955182442 ∧ code e1202955182442 = 5601001693546 := by decide
theorem cert_e1202955182442 : check e1202955182442 [[]] .width = true := by decide
def e1202955182490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202955182490 : Closed e1202955182490 ∧ code e1202955182490 = 5601001693594 := by decide
theorem cert_e1202955182490 : check e1202955182490 [[]] .width = true := by decide
def e1202955186374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955186374 : Closed e1202955186374 ∧ code e1202955186374 = 5601001697478 := by decide
theorem cert_e1202955186374 : check e1202955186374 [[]] .width = true := by decide
def e1202955268294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955268294 : Closed e1202955268294 ∧ code e1202955268294 = 5601001779398 := by decide
theorem cert_e1202955268294 : check e1202955268294 [[]] .width = true := by decide
def e1202955278362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202955278362 : Closed e1202955278362 ∧ code e1202955278362 = 5601001789466 := by decide
theorem cert_e1202955278362 : check e1202955278362 [[]] .width = true := by decide
def e1202955282458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202955282458 : Closed e1202955282458 ∧ code e1202955282458 = 5601001793562 := by decide
theorem cert_e1202955282458 : check e1202955282458 [[]] .width = true := by decide
def e1202955283994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202955283994 : Closed e1202955283994 ∧ code e1202955283994 = 5601001795098 := by decide
theorem cert_e1202955283994 : check e1202955283994 [[]] .width = true := by decide
def e1202955286042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202955286042 : Closed e1202955286042 ∧ code e1202955286042 = 5601001797146 := by decide
theorem cert_e1202955286042 : check e1202955286042 [[]] .width = true := by decide
def e1202955368474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202955368474 : Closed e1202955368474 ∧ code e1202955368474 = 5601001879578 := by decide
theorem cert_e1202955368474 : check e1202955368474 [[]] .width = true := by decide
def e1202955403462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202955403462 : Closed e1202955403462 ∧ code e1202955403462 = 5601001914566 := by decide
theorem cert_e1202955403462 : check e1202955403462 [[]] .width = true := by decide
def e1202955423942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955423942 : Closed e1202955423942 ∧ code e1202955423942 = 5601001935046 := by decide
theorem cert_e1202955423942 : check e1202955423942 [[]] .width = true := by decide
def e1202955425818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202955425818 : Closed e1202955425818 ∧ code e1202955425818 = 5601001936922 := by decide
theorem cert_e1202955425818 : check e1202955425818 [[]] .width = true := by decide
def e1202955427354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202955427354 : Closed e1202955427354 ∧ code e1202955427354 = 5601001938458 := by decide
theorem cert_e1202955427354 : check e1202955427354 [[]] .width = true := by decide
def e1202955436230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202955436230 : Closed e1202955436230 ∧ code e1202955436230 = 5601001947334 := by decide
theorem cert_e1202955436230 : check e1202955436230 [[]] .width = true := by decide
def e1202955444250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202955444250 : Closed e1202955444250 ∧ code e1202955444250 = 5601001955354 := by decide
theorem cert_e1202955444250 : check e1202955444250 [[]] .width = true := by decide
def e1202955444342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202955444342 : Closed e1202955444342 ∧ code e1202955444342 = 5601001955446 := by decide
theorem cert_e1202955444342 : check e1202955444342 [[]] .width = true := by decide
def e1202955444586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202955444586 : Closed e1202955444586 ∧ code e1202955444586 = 5601001955690 := by decide
theorem cert_e1202955444586 : check e1202955444586 [[]] .width = true := by decide
def e1202955444634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202955444634 : Closed e1202955444634 ∧ code e1202955444634 = 5601001955738 := by decide
theorem cert_e1202955444634 : check e1202955444634 [[]] .width = true := by decide
def e1202955448518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955448518 : Closed e1202955448518 ∧ code e1202955448518 = 5601001959622 := by decide
theorem cert_e1202955448518 : check e1202955448518 [[]] .width = true := by decide
def e1202955456026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202955456026 : Closed e1202955456026 ∧ code e1202955456026 = 5601001967130 := by decide
theorem cert_e1202955456026 : check e1202955456026 [[]] .width = true := by decide
def e1202955464902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202955464902 : Closed e1202955464902 ∧ code e1202955464902 = 5601001976006 := by decide
theorem cert_e1202955464902 : check e1202955464902 [[]] .width = true := by decide
def e1202956103878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202956103878 : Closed e1202956103878 ∧ code e1202956103878 = 5601002614982 := by decide
theorem cert_e1202956103878 : check e1202956103878 [[]] .width = true := by decide
def e1202956128454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202956128454 : Closed e1202956128454 ∧ code e1202956128454 = 5601002639558 := by decide
theorem cert_e1202956128454 : check e1202956128454 [[]] .width = true := by decide
def e1202956187674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202956187674 : Closed e1202956187674 ∧ code e1202956187674 = 5601002698778 := by decide
theorem cert_e1202956187674 : check e1202956187674 [[]] .width = true := by decide
def e1202956199962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202956199962 : Closed e1202956199962 ∧ code e1202956199962 = 5601002711066 := by decide
theorem cert_e1202956199962 : check e1202956199962 [[]] .width = true := by decide
def e1202956201498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202956201498 : Closed e1202956201498 ∧ code e1202956201498 = 5601002712602 := by decide
theorem cert_e1202956201498 : check e1202956201498 [[]] .width = true := by decide
def e1202956250650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202956250650 : Closed e1202956250650 ∧ code e1202956250650 = 5601002761754 := by decide
theorem cert_e1202956250650 : check e1202956250650 [[]] .width = true := by decide
def e1202956253722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202956253722 : Closed e1202956253722 ∧ code e1202956253722 = 5601002764826 := by decide
theorem cert_e1202956253722 : check e1202956253722 [[]] .width = true := by decide
def e1202956890310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202956890310 : Closed e1202956890310 ∧ code e1202956890310 = 5601003401414 := by decide
theorem cert_e1202956890310 : check e1202956890310 [[]] .width = true := by decide
def e1202956908570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202956908570 : Closed e1202956908570 ∧ code e1202956908570 = 5601003419674 := by decide
theorem cert_e1202956908570 : check e1202956908570 [[]] .width = true := by decide
def e1202956922394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202956922394 : Closed e1202956922394 ∧ code e1202956922394 = 5601003433498 := by decide
theorem cert_e1202956922394 : check e1202956922394 [[]] .width = true := by decide
def e1202957172934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202957172934 : Closed e1202957172934 ∧ code e1202957172934 = 5601003684038 := by decide
theorem cert_e1202957172934 : check e1202957172934 [[]] .width = true := by decide
def e1202957246490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957246490 : Closed e1202957246490 ∧ code e1202957246490 = 5601003757594 := by decide
theorem cert_e1202957246490 : check e1202957246490 [[]] .width = true := by decide
def e1202957246582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957246582 : Closed e1202957246582 ∧ code e1202957246582 = 5601003757686 := by decide
theorem cert_e1202957246582 : check e1202957246582 [[]] .width = true := by decide
def e1202957246826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957246826 : Closed e1202957246826 ∧ code e1202957246826 = 5601003757930 := by decide
theorem cert_e1202957246826 : check e1202957246826 [[]] .width = true := by decide
def e1202957246874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957246874 : Closed e1202957246874 ∧ code e1202957246874 = 5601003757978 := by decide
theorem cert_e1202957246874 : check e1202957246874 [[]] .width = true := by decide
def e1202957258950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957258950 : Closed e1202957258950 ∧ code e1202957258950 = 5601003770054 := by decide
theorem cert_e1202957258950 : check e1202957258950 [[]] .width = true := by decide
def e1202957260826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202957260826 : Closed e1202957260826 ∧ code e1202957260826 = 5601003771930 := by decide
theorem cert_e1202957260826 : check e1202957260826 [[]] .width = true := by decide
def e1202957262362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202957262362 : Closed e1202957262362 ∧ code e1202957262362 = 5601003773466 := by decide
theorem cert_e1202957262362 : check e1202957262362 [[]] .width = true := by decide
def e1202957271238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202957271238 : Closed e1202957271238 ∧ code e1202957271238 = 5601003782342 := by decide
theorem cert_e1202957271238 : check e1202957271238 [[]] .width = true := by decide
def e1202957279258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957279258 : Closed e1202957279258 ∧ code e1202957279258 = 5601003790362 := by decide
theorem cert_e1202957279258 : check e1202957279258 [[]] .width = true := by decide
def e1202957279350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957279350 : Closed e1202957279350 ∧ code e1202957279350 = 5601003790454 := by decide
theorem cert_e1202957279350 : check e1202957279350 [[]] .width = true := by decide
def e1202957279594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957279594 : Closed e1202957279594 ∧ code e1202957279594 = 5601003790698 := by decide
theorem cert_e1202957279594 : check e1202957279594 [[]] .width = true := by decide
def e1202957279642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957279642 : Closed e1202957279642 ∧ code e1202957279642 = 5601003790746 := by decide
theorem cert_e1202957279642 : check e1202957279642 [[]] .width = true := by decide
def e1202957283526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957283526 : Closed e1202957283526 ∧ code e1202957283526 = 5601003794630 := by decide
theorem cert_e1202957283526 : check e1202957283526 [[]] .width = true := by decide
def e1202957508634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957508634 : Closed e1202957508634 ∧ code e1202957508634 = 5601004019738 := by decide
theorem cert_e1202957508634 : check e1202957508634 [[]] .width = true := by decide
def e1202957508726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957508726 : Closed e1202957508726 ∧ code e1202957508726 = 5601004019830 := by decide
private def t_e1202957508726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202957508726 : ¬ IsSelfInterpreter e1202957508726 :=
  wSource (t := t_e1202957508726) (replay_sound (ps := []) (t := e1202957508726) (by decide)) (by decide)
def e1202957508970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957508970 : Closed e1202957508970 ∧ code e1202957508970 = 5601004020074 := by decide
private def t_e1202957508970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202957508970 : ¬ IsSelfInterpreter e1202957508970 :=
  wSource (t := t_e1202957508970) (replay_sound (ps := []) (t := e1202957508970) (by decide)) (by decide)
def e1202957509018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957509018 : Closed e1202957509018 ∧ code e1202957509018 = 5601004020122 := by decide
private def t_e1202957509018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202957509018 : ¬ IsSelfInterpreter e1202957509018 :=
  wSource (t := t_e1202957509018) (replay_sound (ps := []) (t := e1202957509018) (by decide)) (by decide)
def e1202957557786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957557786 : Closed e1202957557786 ∧ code e1202957557786 = 5601004068890 := by decide
theorem cert_e1202957557786 : check e1202957557786 [[]] .width = true := by decide
def e1202957557878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957557878 : Closed e1202957557878 ∧ code e1202957557878 = 5601004068982 := by decide
private def t_e1202957557878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202957557878 : ¬ IsSelfInterpreter e1202957557878 :=
  wSource (t := t_e1202957557878) (replay_sound (ps := []) (t := e1202957557878) (by decide)) (by decide)
def e1202957558122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957558122 : Closed e1202957558122 ∧ code e1202957558122 = 5601004069226 := by decide
private def t_e1202957558122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202957558122 : ¬ IsSelfInterpreter e1202957558122 :=
  wSource (t := t_e1202957558122) (replay_sound (ps := []) (t := e1202957558122) (by decide)) (by decide)
def e1202957558170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957558170 : Closed e1202957558170 ∧ code e1202957558170 = 5601004069274 := by decide
private def t_e1202957558170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202957558170 : ¬ IsSelfInterpreter e1202957558170 :=
  wSource (t := t_e1202957558170) (replay_sound (ps := []) (t := e1202957558170) (by decide)) (by decide)
def e1202957603014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957603014 : Closed e1202957603014 ∧ code e1202957603014 = 5601004114118 := by decide
theorem cert_e1202957603014 : check e1202957603014 [[]] .width = true := by decide
def e1202957608986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202957608986 : Closed e1202957608986 ∧ code e1202957608986 = 5601004120090 := by decide
theorem cert_e1202957608986 : check e1202957608986 [[]] .width = true := by decide
def e1202957610522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202957610522 : Closed e1202957610522 ∧ code e1202957610522 = 5601004121626 := by decide
private def t_e1202957610522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202957610522 : ¬ IsSelfInterpreter e1202957610522 :=
  wSource (t := t_e1202957610522) (replay_sound (ps := []) (t := e1202957610522) (by decide)) (by decide)
def e1202957613594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202957613594 : Closed e1202957613594 ∧ code e1202957613594 = 5601004124698 := by decide
private def t_e1202957613594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202957613594 : ¬ IsSelfInterpreter e1202957613594 :=
  wSource (t := t_e1202957613594) (replay_sound (ps := []) (t := e1202957613594) (by decide)) (by decide)
def e1202957652166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957652166 : Closed e1202957652166 ∧ code e1202957652166 = 5601004163270 := by decide
theorem cert_e1202957652166 : check e1202957652166 [[]] .width = true := by decide
def e1202957654042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202957654042 : Closed e1202957654042 ∧ code e1202957654042 = 5601004165146 := by decide
theorem cert_e1202957654042 : check e1202957654042 [[]] .width = true := by decide
def e1202957655578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202957655578 : Closed e1202957655578 ∧ code e1202957655578 = 5601004166682 := by decide
private def t_e1202957655578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202957655578 : ¬ IsSelfInterpreter e1202957655578 :=
  wSource (t := t_e1202957655578) (replay_sound (ps := []) (t := e1202957655578) (by decide)) (by decide)
def e1202957664454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202957664454 : Closed e1202957664454 ∧ code e1202957664454 = 5601004175558 := by decide
theorem cert_e1202957664454 : check e1202957664454 [[]] .width = true := by decide
def e1202957672474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957672474 : Closed e1202957672474 ∧ code e1202957672474 = 5601004183578 := by decide
theorem cert_e1202957672474 : check e1202957672474 [[]] .width = true := by decide
def e1202957672566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957672566 : Closed e1202957672566 ∧ code e1202957672566 = 5601004183670 := by decide
private def t_e1202957672566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202957672566 : ¬ IsSelfInterpreter e1202957672566 :=
  wSource (t := t_e1202957672566) (replay_sound (ps := []) (t := e1202957672566) (by decide)) (by decide)
def e1202957672810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957672810 : Closed e1202957672810 ∧ code e1202957672810 = 5601004183914 := by decide
private def t_e1202957672810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202957672810 : ¬ IsSelfInterpreter e1202957672810 :=
  wSource (t := t_e1202957672810) (replay_sound (ps := []) (t := e1202957672810) (by decide)) (by decide)
def e1202957672858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957672858 : Closed e1202957672858 ∧ code e1202957672858 = 5601004183962 := by decide
private def t_e1202957672858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202957672858 : ¬ IsSelfInterpreter e1202957672858 :=
  wSource (t := t_e1202957672858) (replay_sound (ps := []) (t := e1202957672858) (by decide)) (by decide)
def e1202957676742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957676742 : Closed e1202957676742 ∧ code e1202957676742 = 5601004187846 := by decide
theorem cert_e1202957676742 : check e1202957676742 [[]] .width = true := by decide
def e1202957688858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202957688858 : Closed e1202957688858 ∧ code e1202957688858 = 5601004199962 := by decide
theorem cert_e1202957688858 : check e1202957688858 [[]] .width = true := by decide
def e1202957688950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202957688950 : Closed e1202957688950 ∧ code e1202957688950 = 5601004200054 := by decide
private def t_e1202957688950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202957688950 : ¬ IsSelfInterpreter e1202957688950 :=
  wSource (t := t_e1202957688950) (replay_sound (ps := []) (t := e1202957688950) (by decide)) (by decide)
def e1202957689194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202957689194 : Closed e1202957689194 ∧ code e1202957689194 = 5601004200298 := by decide
private def t_e1202957689194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202957689194 : ¬ IsSelfInterpreter e1202957689194 :=
  wSource (t := t_e1202957689194) (replay_sound (ps := []) (t := e1202957689194) (by decide)) (by decide)
def e1202957689242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202957689242 : Closed e1202957689242 ∧ code e1202957689242 = 5601004200346 := by decide
private def t_e1202957689242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202957689242 : ¬ IsSelfInterpreter e1202957689242 :=
  wSource (t := t_e1202957689242) (replay_sound (ps := []) (t := e1202957689242) (by decide)) (by decide)
def e1202957698586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202957698586 : Closed e1202957698586 ∧ code e1202957698586 = 5601004209690 := by decide
private def t_e1202957698586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202957698586 : ¬ IsSelfInterpreter e1202957698586 :=
  wSource (t := t_e1202957698586) (replay_sound (ps := []) (t := e1202957698586) (by decide)) (by decide)
def e1202957701318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202957701318 : Closed e1202957701318 ∧ code e1202957701318 = 5601004212422 := by decide
theorem cert_e1202957701318 : check e1202957701318 [[]] .width = true := by decide
def e1202958020806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958020806 : Closed e1202958020806 ∧ code e1202958020806 = 5601004531910 := by decide
theorem cert_e1202958020806 : check e1202958020806 [[]] .width = true := by decide
def e1202958028998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958028998 : Closed e1202958028998 ∧ code e1202958028998 = 5601004540102 := by decide
theorem cert_e1202958028998 : check e1202958028998 [[]] .width = true := by decide
def e1202958063642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958063642 : Closed e1202958063642 ∧ code e1202958063642 = 5601004574746 := by decide
theorem cert_e1202958063642 : check e1202958063642 [[]] .width = true := by decide
def e1202958067738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958067738 : Closed e1202958067738 ∧ code e1202958067738 = 5601004578842 := by decide
theorem cert_e1202958067738 : check e1202958067738 [[]] .width = true := by decide
def e1202958069274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958069274 : Closed e1202958069274 ∧ code e1202958069274 = 5601004580378 := by decide
theorem cert_e1202958069274 : check e1202958069274 [[]] .width = true := by decide
def e1202958071322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958071322 : Closed e1202958071322 ∧ code e1202958071322 = 5601004582426 := by decide
theorem cert_e1202958071322 : check e1202958071322 [[]] .width = true := by decide
def e1202958084122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958084122 : Closed e1202958084122 ∧ code e1202958084122 = 5601004595226 := by decide
theorem cert_e1202958084122 : check e1202958084122 [[]] .width = true := by decide
def e1202958085658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958085658 : Closed e1202958085658 ∧ code e1202958085658 = 5601004596762 := by decide
theorem cert_e1202958085658 : check e1202958085658 [[]] .width = true := by decide
def e1202958088730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958088730 : Closed e1202958088730 ∧ code e1202958088730 = 5601004599834 := by decide
theorem cert_e1202958088730 : check e1202958088730 [[]] .width = true := by decide
def e1202958095898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958095898 : Closed e1202958095898 ∧ code e1202958095898 = 5601004607002 := by decide
theorem cert_e1202958095898 : check e1202958095898 [[]] .width = true := by decide
def e1202958096922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958096922 : Closed e1202958096922 ∧ code e1202958096922 = 5601004608026 := by decide
theorem cert_e1202958096922 : check e1202958096922 [[]] .width = true := by decide
def e1202958414022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958414022 : Closed e1202958414022 ∧ code e1202958414022 = 5601004925126 := by decide
theorem cert_e1202958414022 : check e1202958414022 [[]] .width = true := by decide
def e1202958424090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958424090 : Closed e1202958424090 ∧ code e1202958424090 = 5601004935194 := by decide
theorem cert_e1202958424090 : check e1202958424090 [[]] .width = true := by decide
def e1202958428186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958428186 : Closed e1202958428186 ∧ code e1202958428186 = 5601004939290 := by decide
theorem cert_e1202958428186 : check e1202958428186 [[]] .width = true := by decide
def e1202958429722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958429722 : Closed e1202958429722 ∧ code e1202958429722 = 5601004940826 := by decide
theorem cert_e1202958429722 : check e1202958429722 [[]] .width = true := by decide
def e1202958431770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958431770 : Closed e1202958431770 ∧ code e1202958431770 = 5601004942874 := by decide
theorem cert_e1202958431770 : check e1202958431770 [[]] .width = true := by decide
def e1202958514202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958514202 : Closed e1202958514202 ∧ code e1202958514202 = 5601005025306 := by decide
theorem cert_e1202958514202 : check e1202958514202 [[]] .width = true := by decide
def e1202958549190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202958549190 : Closed e1202958549190 ∧ code e1202958549190 = 5601005060294 := by decide
theorem cert_e1202958549190 : check e1202958549190 [[]] .width = true := by decide
def e1202958569670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958569670 : Closed e1202958569670 ∧ code e1202958569670 = 5601005080774 := by decide
theorem cert_e1202958569670 : check e1202958569670 [[]] .width = true := by decide
def e1202958571546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958571546 : Closed e1202958571546 ∧ code e1202958571546 = 5601005082650 := by decide
theorem cert_e1202958571546 : check e1202958571546 [[]] .width = true := by decide
def e1202958573082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958573082 : Closed e1202958573082 ∧ code e1202958573082 = 5601005084186 := by decide
theorem cert_e1202958573082 : check e1202958573082 [[]] .width = true := by decide
def e1202958581958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202958581958 : Closed e1202958581958 ∧ code e1202958581958 = 5601005093062 := by decide
theorem cert_e1202958581958 : check e1202958581958 [[]] .width = true := by decide
def e1202958589978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202958589978 : Closed e1202958589978 ∧ code e1202958589978 = 5601005101082 := by decide
theorem cert_e1202958589978 : check e1202958589978 [[]] .width = true := by decide
def e1202958590070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202958590070 : Closed e1202958590070 ∧ code e1202958590070 = 5601005101174 := by decide
theorem cert_e1202958590070 : check e1202958590070 [[]] .width = true := by decide
def e1202958590314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202958590314 : Closed e1202958590314 ∧ code e1202958590314 = 5601005101418 := by decide
theorem cert_e1202958590314 : check e1202958590314 [[]] .width = true := by decide
def e1202958590362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202958590362 : Closed e1202958590362 ∧ code e1202958590362 = 5601005101466 := by decide
theorem cert_e1202958590362 : check e1202958590362 [[]] .width = true := by decide
def e1202958594246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958594246 : Closed e1202958594246 ∧ code e1202958594246 = 5601005105350 := by decide
theorem cert_e1202958594246 : check e1202958594246 [[]] .width = true := by decide
def e1202958601754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958601754 : Closed e1202958601754 ∧ code e1202958601754 = 5601005112858 := by decide
theorem cert_e1202958601754 : check e1202958601754 [[]] .width = true := by decide
def e1202958610630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958610630 : Closed e1202958610630 ∧ code e1202958610630 = 5601005121734 := by decide
theorem cert_e1202958610630 : check e1202958610630 [[]] .width = true := by decide
def e1202958651590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958651590 : Closed e1202958651590 ∧ code e1202958651590 = 5601005162694 := by decide
theorem cert_e1202958651590 : check e1202958651590 [[]] .width = true := by decide
def e1202958657562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958657562 : Closed e1202958657562 ∧ code e1202958657562 = 5601005168666 := by decide
theorem cert_e1202958657562 : check e1202958657562 [[]] .width = true := by decide
def e1202958659098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958659098 : Closed e1202958659098 ∧ code e1202958659098 = 5601005170202 := by decide
private def t_e1202958659098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958659098 : ¬ IsSelfInterpreter e1202958659098 :=
  wSource (t := t_e1202958659098) (replay_sound (ps := []) (t := e1202958659098) (by decide)) (by decide)
def e1202958662170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958662170 : Closed e1202958662170 ∧ code e1202958662170 = 5601005173274 := by decide
private def t_e1202958662170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958662170 : ¬ IsSelfInterpreter e1202958662170 :=
  wSource (t := t_e1202958662170) (replay_sound (ps := []) (t := e1202958662170) (by decide)) (by decide)
def e1202958700742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202958700742 : Closed e1202958700742 ∧ code e1202958700742 = 5601005211846 := by decide
theorem cert_e1202958700742 : check e1202958700742 [[]] .width = true := by decide
def e1202958702618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202958702618 : Closed e1202958702618 ∧ code e1202958702618 = 5601005213722 := by decide
theorem cert_e1202958702618 : check e1202958702618 [[]] .width = true := by decide
def e1202958704154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202958704154 : Closed e1202958704154 ∧ code e1202958704154 = 5601005215258 := by decide
private def t_e1202958704154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202958704154 : ¬ IsSelfInterpreter e1202958704154 :=
  wSource (t := t_e1202958704154) (replay_sound (ps := []) (t := e1202958704154) (by decide)) (by decide)
def e1202958713030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202958713030 : Closed e1202958713030 ∧ code e1202958713030 = 5601005224134 := by decide
theorem cert_e1202958713030 : check e1202958713030 [[]] .width = true := by decide
end Blc.Floor42
