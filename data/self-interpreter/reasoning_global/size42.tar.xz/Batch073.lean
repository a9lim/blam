import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196283080474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1196283080474 : Closed e1196283080474 ∧ code e1196283080474 = 5594329591578 := by decide
theorem cert_e1196283080474 : check e1196283080474 [[],[.left]] .chain = true := by decide
def e1196283080518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1196283080518 : Closed e1196283080518 ∧ code e1196283080518 = 5594329591622 := by decide
theorem cert_e1196283080518 : check e1196283080518 [[],[.left]] .chain = true := by decide
def e1196283081502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196283081502 : Closed e1196283081502 ∧ code e1196283081502 = 5594329592606 := by decide
theorem cert_e1196283081502 : check e1196283081502 [[],[.left]] .chain = true := by decide
def e1196283081670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196283081670 : Closed e1196283081670 ∧ code e1196283081670 = 5594329592774 := by decide
theorem cert_e1196283081670 : check e1196283081670 [[],[.left]] .chain = true := by decide
def e1196283083974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1196283083974 : Closed e1196283083974 ∧ code e1196283083974 = 5594329595078 := by decide
theorem cert_e1196283083974 : check e1196283083974 [[],[.left]] .chain = true := by decide
def e1196283106870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196283106870 : Closed e1196283106870 ∧ code e1196283106870 = 5594329617974 := by decide
theorem cert_e1196283106870 : check e1196283106870 [[],[.left]] .chain = true := by decide
def e1196283106874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196283106874 : Closed e1196283106874 ∧ code e1196283106874 = 5594329617978 := by decide
theorem cert_e1196283106874 : check e1196283106874 [[],[.left]] .chain = true := by decide
def e1196283106958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196283106958 : Closed e1196283106958 ∧ code e1196283106958 = 5594329618062 := by decide
theorem cert_e1196283106958 : check e1196283106958 [[],[.left]] .chain = true := by decide
def e1196283107014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196283107014 : Closed e1196283107014 ∧ code e1196283107014 = 5594329618118 := by decide
theorem cert_e1196283107014 : check e1196283107014 [[],[.left]] .chain = true := by decide
def e1196283107098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1196283107098 : Closed e1196283107098 ∧ code e1196283107098 = 5594329618202 := by decide
theorem cert_e1196283107098 : check e1196283107098 [[],[.left]] .chain = true := by decide
def e1196283107142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1196283107142 : Closed e1196283107142 ∧ code e1196283107142 = 5594329618246 := by decide
theorem cert_e1196283107142 : check e1196283107142 [[],[.left]] .chain = true := by decide
def e1196283107726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196283107726 : Closed e1196283107726 ∧ code e1196283107726 = 5594329618830 := by decide
theorem cert_e1196283107726 : check e1196283107726 [[],[.left]] .chain = true := by decide
def e1196283107782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196283107782 : Closed e1196283107782 ∧ code e1196283107782 = 5594329618886 := by decide
theorem cert_e1196283107782 : check e1196283107782 [[],[.left]] .chain = true := by decide
def e1196283108550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1196283108550 : Closed e1196283108550 ∧ code e1196283108550 = 5594329619654 := by decide
theorem cert_e1196283108550 : check e1196283108550 [[],[.left]] .chain = true := by decide
def e1196284205294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196284205294 : Closed e1196284205294 ∧ code e1196284205294 = 5594330716398 := by decide
theorem cert_e1196284205294 : check e1196284205294 [[],[.left]] .chain = true := by decide
def e1196284205302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196284205302 : Closed e1196284205302 ∧ code e1196284205302 = 5594330716406 := by decide
theorem cert_e1196284205302 : check e1196284205302 [[],[.left]] .chain = true := by decide
def e1196284205854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196284205854 : Closed e1196284205854 ∧ code e1196284205854 = 5594330716958 := by decide
theorem cert_e1196284205854 : check e1196284205854 [[],[.left]] .chain = true := by decide
def e1196284205966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196284205966 : Closed e1196284205966 ∧ code e1196284205966 = 5594330717070 := by decide
theorem cert_e1196284205966 : check e1196284205966 [[],[.left]] .chain = true := by decide
def e1196284206190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196284206190 : Closed e1196284206190 ∧ code e1196284206190 = 5594330717294 := by decide
theorem cert_e1196284206190 : check e1196284206190 [[],[.left]] .chain = true := by decide
def e1196284206202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196284206202 : Closed e1196284206202 ∧ code e1196284206202 = 5594330717306 := by decide
theorem cert_e1196284206202 : check e1196284206202 [[],[.left]] .chain = true := by decide
def e1196284206366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196284206366 : Closed e1196284206366 ∧ code e1196284206366 = 5594330717470 := by decide
theorem cert_e1196284206366 : check e1196284206366 [[],[.left]] .chain = true := by decide
def e1196284206534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196284206534 : Closed e1196284206534 ∧ code e1196284206534 = 5594330717638 := by decide
theorem cert_e1196284206534 : check e1196284206534 [[],[.left]] .chain = true := by decide
def e1196284206646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196284206646 : Closed e1196284206646 ∧ code e1196284206646 = 5594330717750 := by decide
theorem cert_e1196284206646 : check e1196284206646 [[],[.left]] .chain = true := by decide
def e1196284206650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196284206650 : Closed e1196284206650 ∧ code e1196284206650 = 5594330717754 := by decide
theorem cert_e1196284206650 : check e1196284206650 [[],[.left]] .chain = true := by decide
def e1196284206734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196284206734 : Closed e1196284206734 ∧ code e1196284206734 = 5594330717838 := by decide
theorem cert_e1196284206734 : check e1196284206734 [[],[.left]] .chain = true := by decide
def e1196284206790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196284206790 : Closed e1196284206790 ∧ code e1196284206790 = 5594330717894 := by decide
theorem cert_e1196284206790 : check e1196284206790 [[],[.left]] .chain = true := by decide
def e1196284208926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196284208926 : Closed e1196284208926 ∧ code e1196284208926 = 5594330720030 := by decide
theorem cert_e1196284208926 : check e1196284208926 [[],[.left]] .chain = true := by decide
def e1196284209038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196284209038 : Closed e1196284209038 ∧ code e1196284209038 = 5594330720142 := by decide
theorem cert_e1196284209038 : check e1196284209038 [[],[.left]] .chain = true := by decide
def e1196284211998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196284211998 : Closed e1196284211998 ∧ code e1196284211998 = 5594330723102 := by decide
theorem cert_e1196284211998 : check e1196284211998 [[],[.left]] .chain = true := by decide
def e1196284212166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196284212166 : Closed e1196284212166 ∧ code e1196284212166 = 5594330723270 := by decide
theorem cert_e1196284212166 : check e1196284212166 [[],[.left]] .chain = true := by decide
def e1196284213646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196284213646 : Closed e1196284213646 ∧ code e1196284213646 = 5594330724750 := by decide
theorem cert_e1196284213646 : check e1196284213646 [[],[.left]] .chain = true := by decide
def e1196284213702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196284213702 : Closed e1196284213702 ∧ code e1196284213702 = 5594330724806 := by decide
theorem cert_e1196284213702 : check e1196284213702 [[],[.left]] .chain = true := by decide
def e1196288906974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1196288906974 : Closed e1196288906974 ∧ code e1196288906974 = 5594335418078 := by decide
theorem cert_e1196288906974 : check e1196288906974 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288906998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1196288906998 : Closed e1196288906998 ∧ code e1196288906998 = 5594335418102 := by decide
theorem cert_e1196288906998 : check e1196288906998 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1196288907102 : Closed e1196288907102 ∧ code e1196288907102 = 5594335418206 := by decide
theorem cert_e1196288907102 : check e1196288907102 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1196288907130 : Closed e1196288907130 ∧ code e1196288907130 = 5594335418234 := by decide
theorem cert_e1196288907130 : check e1196288907130 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1196288907222 : Closed e1196288907222 ∧ code e1196288907222 = 5594335418326 := by decide
theorem cert_e1196288907222 : check e1196288907222 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1196288907226 : Closed e1196288907226 ∧ code e1196288907226 = 5594335418330 := by decide
theorem cert_e1196288907226 : check e1196288907226 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196288907742 : Closed e1196288907742 ∧ code e1196288907742 = 5594335418846 := by decide
theorem cert_e1196288907742 : check e1196288907742 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288907766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196288907766 : Closed e1196288907766 ∧ code e1196288907766 = 5594335418870 := by decide
theorem cert_e1196288907766 : check e1196288907766 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288908510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196288908510 : Closed e1196288908510 ∧ code e1196288908510 = 5594335419614 := by decide
theorem cert_e1196288908510 : check e1196288908510 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288908538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196288908538 : Closed e1196288908538 ∧ code e1196288908538 = 5594335419642 := by decide
theorem cert_e1196288908538 : check e1196288908538 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288909110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196288909110 : Closed e1196288909110 ∧ code e1196288909110 = 5594335420214 := by decide
theorem cert_e1196288909110 : check e1196288909110 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288909114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196288909114 : Closed e1196288909114 ∧ code e1196288909114 = 5594335420218 := by decide
theorem cert_e1196288909114 : check e1196288909114 [[],[.left],[.left],[.left]] .chain = true := by decide
def e1196288923886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196288923886 : Closed e1196288923886 ∧ code e1196288923886 = 5594335434990 := by decide
theorem cert_e1196288923886 : check e1196288923886 [[],[.left],[.left],[.left],[],[.left],[]] .chain = true := by decide
def e1196288923894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196288923894 : Closed e1196288923894 ∧ code e1196288923894 = 5594335434998 := by decide
theorem cert_e1196288923894 : check e1196288923894 [[],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1196288924446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196288924446 : Closed e1196288924446 ∧ code e1196288924446 = 5594335435550 := by decide
theorem cert_e1196288924446 : check e1196288924446 [[],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1196288924558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196288924558 : Closed e1196288924558 ∧ code e1196288924558 = 5594335435662 := by decide
theorem cert_e1196288924558 : check e1196288924558 [[],[.left],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e1196288924782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196288924782 : Closed e1196288924782 ∧ code e1196288924782 = 5594335435886 := by decide
theorem cert_e1196288924782 : check e1196288924782 [[],[.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e1196288924794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196288924794 : Closed e1196288924794 ∧ code e1196288924794 = 5594335435898 := by decide
theorem cert_e1196288924794 : check e1196288924794 [[],[.left],[.left],[.left],[],[.left],[],[.left]] .smaller = true := by decide
def e1196288924958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196288924958 : Closed e1196288924958 ∧ code e1196288924958 = 5594335436062 := by decide
theorem cert_e1196288924958 : check e1196288924958 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e1196288925126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196288925126 : Closed e1196288925126 ∧ code e1196288925126 = 5594335436230 := by decide
private def t_e1196288925126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e1196288925126 : ¬ IsSelfInterpreter e1196288925126 :=
  wSource (t := t_e1196288925126) (replay_sound (ps := []) (t := e1196288925126) (by decide)) (by decide)
def e1196288925238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196288925238 : Closed e1196288925238 ∧ code e1196288925238 = 5594335436342 := by decide
theorem cert_e1196288925238 : check e1196288925238 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1196288925242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196288925242 : Closed e1196288925242 ∧ code e1196288925242 = 5594335436346 := by decide
theorem cert_e1196288925242 : check e1196288925242 [[],[.left],[.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e1196288925326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196288925326 : Closed e1196288925326 ∧ code e1196288925326 = 5594335436430 := by decide
theorem cert_e1196288925326 : check e1196288925326 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1196288925382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196288925382 : Closed e1196288925382 ∧ code e1196288925382 = 5594335436486 := by decide
private def t_e1196288925382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1196288925382 : ¬ IsSelfInterpreter e1196288925382 :=
  wSource (t := t_e1196288925382) (replay_sound (ps := []) (t := e1196288925382) (by decide)) (by decide)
def e1196288927518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196288927518 : Closed e1196288927518 ∧ code e1196288927518 = 5594335438622 := by decide
theorem cert_e1196288927518 : check e1196288927518 [[],[.left],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e1196288927630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196288927630 : Closed e1196288927630 ∧ code e1196288927630 = 5594335438734 := by decide
theorem cert_e1196288927630 : check e1196288927630 [[],[.left],[.left],[.left],[],[],[],[]] .chain = true := by decide
def e1196288930590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196288930590 : Closed e1196288930590 ∧ code e1196288930590 = 5594335441694 := by decide
theorem cert_e1196288930590 : check e1196288930590 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .smaller = true := by decide
def e1196288930758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196288930758 : Closed e1196288930758 ∧ code e1196288930758 = 5594335441862 := by decide
theorem cert_e1196288930758 : check e1196288930758 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e1196288932238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196288932238 : Closed e1196288932238 ∧ code e1196288932238 = 5594335443342 := by decide
theorem cert_e1196288932238 : check e1196288932238 [[],[.left],[.left],[.left],[],[],[.left],[]] .chain = true := by decide
def e1196288932294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196288932294 : Closed e1196288932294 ∧ code e1196288932294 = 5594335443398 := by decide
theorem cert_e1196288932294 : check e1196288932294 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e1196349762926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196349762926 : Closed e1196349762926 ∧ code e1196349762926 = 5594396274030 := by decide
theorem cert_e1196349762926 : check e1196349762926 [[],[.left],[]] .chain = true := by decide
def e1196349762934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196349762934 : Closed e1196349762934 ∧ code e1196349762934 = 5594396274038 := by decide
theorem cert_e1196349762934 : check e1196349762934 [[],[.left],[]] .chain = true := by decide
def e1196349762990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196349762990 : Closed e1196349762990 ∧ code e1196349762990 = 5594396274094 := by decide
theorem cert_e1196349762990 : check e1196349762990 [[],[.left],[]] .chain = true := by decide
def e1196349763002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196349763002 : Closed e1196349763002 ∧ code e1196349763002 = 5594396274106 := by decide
theorem cert_e1196349763002 : check e1196349763002 [[],[.left],[]] .chain = true := by decide
def e1196349763030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196349763030 : Closed e1196349763030 ∧ code e1196349763030 = 5594396274134 := by decide
theorem cert_e1196349763030 : check e1196349763030 [[],[.left],[]] .chain = true := by decide
def e1196349763034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196349763034 : Closed e1196349763034 ∧ code e1196349763034 = 5594396274138 := by decide
theorem cert_e1196349763034 : check e1196349763034 [[],[.left],[]] .chain = true := by decide
def e1196349763246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1196349763246 : Closed e1196349763246 ∧ code e1196349763246 = 5594396274350 := by decide
theorem cert_e1196349763246 : check e1196349763246 [[],[.left],[]] .chain = true := by decide
def e1196349763258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1196349763258 : Closed e1196349763258 ∧ code e1196349763258 = 5594396274362 := by decide
theorem cert_e1196349763258 : check e1196349763258 [[],[.left],[]] .chain = true := by decide
def e1196349763306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1196349763306 : Closed e1196349763306 ∧ code e1196349763306 = 5594396274410 := by decide
theorem cert_e1196349763306 : check e1196349763306 [[],[.left],[]] .chain = true := by decide
def e1196349763414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1196349763414 : Closed e1196349763414 ∧ code e1196349763414 = 5594396274518 := by decide
theorem cert_e1196349763414 : check e1196349763414 [[],[.left],[]] .chain = true := by decide
def e1196349763418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1196349763418 : Closed e1196349763418 ∧ code e1196349763418 = 5594396274522 := by decide
theorem cert_e1196349763418 : check e1196349763418 [[],[.left],[]] .chain = true := by decide
def e1196349763434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1196349763434 : Closed e1196349763434 ∧ code e1196349763434 = 5594396274538 := by decide
theorem cert_e1196349763434 : check e1196349763434 [[],[.left],[]] .chain = true := by decide
def e1196349764462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196349764462 : Closed e1196349764462 ∧ code e1196349764462 = 5594396275566 := by decide
theorem cert_e1196349764462 : check e1196349764462 [[],[.left],[]] .chain = true := by decide
def e1196349764470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196349764470 : Closed e1196349764470 ∧ code e1196349764470 = 5594396275574 := by decide
theorem cert_e1196349764470 : check e1196349764470 [[],[.left],[]] .chain = true := by decide
def e1196349764526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196349764526 : Closed e1196349764526 ∧ code e1196349764526 = 5594396275630 := by decide
theorem cert_e1196349764526 : check e1196349764526 [[],[.left],[]] .chain = true := by decide
def e1196349764538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196349764538 : Closed e1196349764538 ∧ code e1196349764538 = 5594396275642 := by decide
theorem cert_e1196349764538 : check e1196349764538 [[],[.left],[]] .chain = true := by decide
def e1196349764566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196349764566 : Closed e1196349764566 ∧ code e1196349764566 = 5594396275670 := by decide
theorem cert_e1196349764566 : check e1196349764566 [[],[.left],[]] .chain = true := by decide
def e1196349764570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196349764570 : Closed e1196349764570 ∧ code e1196349764570 = 5594396275674 := by decide
theorem cert_e1196349764570 : check e1196349764570 [[],[.left],[]] .chain = true := by decide
def e1196349764846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196349764846 : Closed e1196349764846 ∧ code e1196349764846 = 5594396275950 := by decide
theorem cert_e1196349764846 : check e1196349764846 [[],[.left],[]] .chain = true := by decide
def e1196349764854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196349764854 : Closed e1196349764854 ∧ code e1196349764854 = 5594396275958 := by decide
theorem cert_e1196349764854 : check e1196349764854 [[],[.left],[]] .chain = true := by decide
def e1196349765230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196349765230 : Closed e1196349765230 ∧ code e1196349765230 = 5594396276334 := by decide
theorem cert_e1196349765230 : check e1196349765230 [[],[.left],[]] .chain = true := by decide
def e1196349765242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196349765242 : Closed e1196349765242 ∧ code e1196349765242 = 5594396276346 := by decide
theorem cert_e1196349765242 : check e1196349765242 [[],[.left],[]] .chain = true := by decide
def e1196349765430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196349765430 : Closed e1196349765430 ∧ code e1196349765430 = 5594396276534 := by decide
theorem cert_e1196349765430 : check e1196349765430 [[],[.left],[]] .chain = true := by decide
def e1196349765434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196349765434 : Closed e1196349765434 ∧ code e1196349765434 = 5594396276538 := by decide
theorem cert_e1196349765434 : check e1196349765434 [[],[.left],[]] .chain = true := by decide
def e1196349766062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1196349766062 : Closed e1196349766062 ∧ code e1196349766062 = 5594396277166 := by decide
theorem cert_e1196349766062 : check e1196349766062 [[],[.left],[]] .chain = true := by decide
def e1196349766074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1196349766074 : Closed e1196349766074 ∧ code e1196349766074 = 5594396277178 := by decide
theorem cert_e1196349766074 : check e1196349766074 [[],[.left],[]] .chain = true := by decide
def e1196349766122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1196349766122 : Closed e1196349766122 ∧ code e1196349766122 = 5594396277226 := by decide
theorem cert_e1196349766122 : check e1196349766122 [[],[.left],[]] .chain = true := by decide
def e1196349766254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196349766254 : Closed e1196349766254 ∧ code e1196349766254 = 5594396277358 := by decide
theorem cert_e1196349766254 : check e1196349766254 [[],[.left],[]] .chain = true := by decide
def e1196349766266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196349766266 : Closed e1196349766266 ∧ code e1196349766266 = 5594396277370 := by decide
theorem cert_e1196349766266 : check e1196349766266 [[],[.left],[]] .chain = true := by decide
def e1196349766554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196349766554 : Closed e1196349766554 ∧ code e1196349766554 = 5594396277658 := by decide
theorem cert_e1196349766554 : check e1196349766554 [[],[.left],[]] .chain = true := by decide
def e1196349766870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1196349766870 : Closed e1196349766870 ∧ code e1196349766870 = 5594396277974 := by decide
theorem cert_e1196349766870 : check e1196349766870 [[],[.left],[]] .chain = true := by decide
def e1196349766874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1196349766874 : Closed e1196349766874 ∧ code e1196349766874 = 5594396277978 := by decide
theorem cert_e1196349766874 : check e1196349766874 [[],[.left],[]] .chain = true := by decide
def e1196349766890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1196349766890 : Closed e1196349766890 ∧ code e1196349766890 = 5594396277994 := by decide
theorem cert_e1196349766890 : check e1196349766890 [[],[.left],[]] .chain = true := by decide
def e1196349766966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196349766966 : Closed e1196349766966 ∧ code e1196349766966 = 5594396278070 := by decide
theorem cert_e1196349766966 : check e1196349766966 [[],[.left],[]] .chain = true := by decide
def e1196349766970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196349766970 : Closed e1196349766970 ∧ code e1196349766970 = 5594396278074 := by decide
theorem cert_e1196349766970 : check e1196349766970 [[],[.left],[]] .chain = true := by decide
def e1196349767066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196349767066 : Closed e1196349767066 ∧ code e1196349767066 = 5594396278170 := by decide
theorem cert_e1196349767066 : check e1196349767066 [[],[.left],[]] .chain = true := by decide
def e1196349770606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196349770606 : Closed e1196349770606 ∧ code e1196349770606 = 5594396281710 := by decide
theorem cert_e1196349770606 : check e1196349770606 [[],[.left],[]] .chain = true := by decide
def e1196349770614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196349770614 : Closed e1196349770614 ∧ code e1196349770614 = 5594396281718 := by decide
theorem cert_e1196349770614 : check e1196349770614 [[],[.left],[]] .chain = true := by decide
def e1196349770670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196349770670 : Closed e1196349770670 ∧ code e1196349770670 = 5594396281774 := by decide
theorem cert_e1196349770670 : check e1196349770670 [[],[.left],[]] .chain = true := by decide
def e1196349770682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196349770682 : Closed e1196349770682 ∧ code e1196349770682 = 5594396281786 := by decide
theorem cert_e1196349770682 : check e1196349770682 [[],[.left],[]] .chain = true := by decide
def e1196349770710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196349770710 : Closed e1196349770710 ∧ code e1196349770710 = 5594396281814 := by decide
theorem cert_e1196349770710 : check e1196349770710 [[],[.left],[]] .chain = true := by decide
def e1196349770714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196349770714 : Closed e1196349770714 ∧ code e1196349770714 = 5594396281818 := by decide
theorem cert_e1196349770714 : check e1196349770714 [[],[.left],[]] .chain = true := by decide
def e1196349770990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196349770990 : Closed e1196349770990 ∧ code e1196349770990 = 5594396282094 := by decide
theorem cert_e1196349770990 : check e1196349770990 [[],[.left],[]] .chain = true := by decide
def e1196349770998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196349770998 : Closed e1196349770998 ∧ code e1196349770998 = 5594396282102 := by decide
theorem cert_e1196349770998 : check e1196349770998 [[],[.left],[]] .chain = true := by decide
def e1196349771374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196349771374 : Closed e1196349771374 ∧ code e1196349771374 = 5594396282478 := by decide
theorem cert_e1196349771374 : check e1196349771374 [[],[.left],[]] .chain = true := by decide
def e1196349771386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196349771386 : Closed e1196349771386 ∧ code e1196349771386 = 5594396282490 := by decide
theorem cert_e1196349771386 : check e1196349771386 [[],[.left],[]] .chain = true := by decide
def e1196349771574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196349771574 : Closed e1196349771574 ∧ code e1196349771574 = 5594396282678 := by decide
theorem cert_e1196349771574 : check e1196349771574 [[],[.left],[]] .chain = true := by decide
def e1196349771578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196349771578 : Closed e1196349771578 ∧ code e1196349771578 = 5594396282682 := by decide
theorem cert_e1196349771578 : check e1196349771578 [[],[.left],[]] .chain = true := by decide
def e1196349777326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1196349777326 : Closed e1196349777326 ∧ code e1196349777326 = 5594396288430 := by decide
theorem cert_e1196349777326 : check e1196349777326 [[],[.left],[]] .chain = true := by decide
def e1196349777338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1196349777338 : Closed e1196349777338 ∧ code e1196349777338 = 5594396288442 := by decide
theorem cert_e1196349777338 : check e1196349777338 [[],[.left],[]] .chain = true := by decide
def e1196349777386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1196349777386 : Closed e1196349777386 ∧ code e1196349777386 = 5594396288490 := by decide
theorem cert_e1196349777386 : check e1196349777386 [[],[.left],[]] .chain = true := by decide
def e1196349777518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196349777518 : Closed e1196349777518 ∧ code e1196349777518 = 5594396288622 := by decide
theorem cert_e1196349777518 : check e1196349777518 [[],[.left],[]] .chain = true := by decide
def e1196349777530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196349777530 : Closed e1196349777530 ∧ code e1196349777530 = 5594396288634 := by decide
theorem cert_e1196349777530 : check e1196349777530 [[],[.left],[]] .chain = true := by decide
def e1196349777818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196349777818 : Closed e1196349777818 ∧ code e1196349777818 = 5594396288922 := by decide
theorem cert_e1196349777818 : check e1196349777818 [[],[.left],[]] .chain = true := by decide
def e1196349780694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1196349780694 : Closed e1196349780694 ∧ code e1196349780694 = 5594396291798 := by decide
theorem cert_e1196349780694 : check e1196349780694 [[],[.left],[]] .chain = true := by decide
def e1196349780698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1196349780698 : Closed e1196349780698 ∧ code e1196349780698 = 5594396291802 := by decide
theorem cert_e1196349780698 : check e1196349780698 [[],[.left],[]] .chain = true := by decide
def e1196349780714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1196349780714 : Closed e1196349780714 ∧ code e1196349780714 = 5594396291818 := by decide
theorem cert_e1196349780714 : check e1196349780714 [[],[.left],[]] .chain = true := by decide
def e1196349780790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196349780790 : Closed e1196349780790 ∧ code e1196349780790 = 5594396291894 := by decide
theorem cert_e1196349780790 : check e1196349780790 [[],[.left],[]] .chain = true := by decide
def e1196349780794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196349780794 : Closed e1196349780794 ∧ code e1196349780794 = 5594396291898 := by decide
theorem cert_e1196349780794 : check e1196349780794 [[],[.left],[]] .chain = true := by decide
def e1196349780890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196349780890 : Closed e1196349780890 ∧ code e1196349780890 = 5594396291994 := by decide
theorem cert_e1196349780890 : check e1196349780890 [[],[.left],[]] .chain = true := by decide
def e1196349896430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1196349896430 : Closed e1196349896430 ∧ code e1196349896430 = 5594396407534 := by decide
theorem cert_e1196349896430 : check e1196349896430 [[],[.left],[]] .sourceHead = true := by decide
def e1196349896558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1196349896558 : Closed e1196349896558 ∧ code e1196349896558 = 5594396407662 := by decide
theorem cert_e1196349896558 : check e1196349896558 [[],[.left],[]] .sourceHead = true := by decide
def e1196349896566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1196349896566 : Closed e1196349896566 ∧ code e1196349896566 = 5594396407670 := by decide
theorem cert_e1196349896566 : check e1196349896566 [[],[.left],[]] .sourceHead = true := by decide
def e1196349897454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1196349897454 : Closed e1196349897454 ∧ code e1196349897454 = 5594396408558 := by decide
theorem cert_e1196349897454 : check e1196349897454 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e1196349897646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1196349897646 : Closed e1196349897646 ∧ code e1196349897646 = 5594396408750 := by decide
theorem cert_e1196349897646 : check e1196349897646 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1196349897658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1196349897658 : Closed e1196349897658 ∧ code e1196349897658 = 5594396408762 := by decide
theorem cert_e1196349897658 : check e1196349897658 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196349898094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196349898094 : Closed e1196349898094 ∧ code e1196349898094 = 5594396409198 := by decide
theorem cert_e1196349898094 : check e1196349898094 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196349898102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196349898102 : Closed e1196349898102 ∧ code e1196349898102 = 5594396409206 := by decide
theorem cert_e1196349898102 : check e1196349898102 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196349898158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196349898158 : Closed e1196349898158 ∧ code e1196349898158 = 5594396409262 := by decide
theorem cert_e1196349898158 : check e1196349898158 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349898170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196349898170 : Closed e1196349898170 ∧ code e1196349898170 = 5594396409274 := by decide
theorem cert_e1196349898170 : check e1196349898170 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349898198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196349898198 : Closed e1196349898198 ∧ code e1196349898198 = 5594396409302 := by decide
private def t_e1196349898198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e1196349898198 : ¬ IsSelfInterpreter e1196349898198 :=
  wSource (t := t_e1196349898198) (replay_sound (ps := []) (t := e1196349898198) (by decide)) (by decide)
def e1196349898202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196349898202 : Closed e1196349898202 ∧ code e1196349898202 = 5594396409306 := by decide
private def t_e1196349898202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e1196349898202 : ¬ IsSelfInterpreter e1196349898202 :=
  wSource (t := t_e1196349898202) (replay_sound (ps := []) (t := e1196349898202) (by decide)) (by decide)
def e1196349902574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1196349902574 : Closed e1196349902574 ∧ code e1196349902574 = 5594396413678 := by decide
theorem cert_e1196349902574 : check e1196349902574 [[],[.left],[]] .sourceHead = true := by decide
def e1196349902702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1196349902702 : Closed e1196349902702 ∧ code e1196349902702 = 5594396413806 := by decide
theorem cert_e1196349902702 : check e1196349902702 [[],[.left],[]] .sourceHead = true := by decide
def e1196349902710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1196349902710 : Closed e1196349902710 ∧ code e1196349902710 = 5594396413814 := by decide
theorem cert_e1196349902710 : check e1196349902710 [[],[.left],[]] .sourceHead = true := by decide
def e1196349905390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1196349905390 : Closed e1196349905390 ∧ code e1196349905390 = 5594396416494 := by decide
theorem cert_e1196349905390 : check e1196349905390 [[],[.left],[]] .sourceHead = true := by decide
def e1196349906158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196349906158 : Closed e1196349906158 ∧ code e1196349906158 = 5594396417262 := by decide
theorem cert_e1196349906158 : check e1196349906158 [[],[.left],[]] .sourceHead = true := by decide
def e1196349906166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196349906166 : Closed e1196349906166 ∧ code e1196349906166 = 5594396417270 := by decide
theorem cert_e1196349906166 : check e1196349906166 [[],[.left],[]] .sourceHead = true := by decide
def e1196349908718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1196349908718 : Closed e1196349908718 ∧ code e1196349908718 = 5594396419822 := by decide
theorem cert_e1196349908718 : check e1196349908718 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1196349908910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1196349908910 : Closed e1196349908910 ∧ code e1196349908910 = 5594396420014 := by decide
theorem cert_e1196349908910 : check e1196349908910 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1196349908922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1196349908922 : Closed e1196349908922 ∧ code e1196349908922 = 5594396420026 := by decide
theorem cert_e1196349908922 : check e1196349908922 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1196349909486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1196349909486 : Closed e1196349909486 ∧ code e1196349909486 = 5594396420590 := by decide
theorem cert_e1196349909486 : check e1196349909486 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1196349910638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196349910638 : Closed e1196349910638 ∧ code e1196349910638 = 5594396421742 := by decide
theorem cert_e1196349910638 : check e1196349910638 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1196349910650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196349910650 : Closed e1196349910650 ∧ code e1196349910650 = 5594396421754 := by decide
theorem cert_e1196349910650 : check e1196349910650 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e1196349911918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196349911918 : Closed e1196349911918 ∧ code e1196349911918 = 5594396423022 := by decide
theorem cert_e1196349911918 : check e1196349911918 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196349911926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196349911926 : Closed e1196349911926 ∧ code e1196349911926 = 5594396423030 := by decide
theorem cert_e1196349911926 : check e1196349911926 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196349911982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196349911982 : Closed e1196349911982 ∧ code e1196349911982 = 5594396423086 := by decide
theorem cert_e1196349911982 : check e1196349911982 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349911994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196349911994 : Closed e1196349911994 ∧ code e1196349911994 = 5594396423098 := by decide
theorem cert_e1196349911994 : check e1196349911994 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349912022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196349912022 : Closed e1196349912022 ∧ code e1196349912022 = 5594396423126 := by decide
theorem cert_e1196349912022 : checkPay e1196349912022 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196349912026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196349912026 : Closed e1196349912026 ∧ code e1196349912026 = 5594396423130 := by decide
theorem cert_e1196349912026 : check e1196349912026 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1196349912302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196349912302 : Closed e1196349912302 ∧ code e1196349912302 = 5594396423406 := by decide
theorem cert_e1196349912302 : checkPay e1196349912302 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196349912310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196349912310 : Closed e1196349912310 ∧ code e1196349912310 = 5594396423414 := by decide
theorem cert_e1196349912310 : checkPay e1196349912310 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196349912686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196349912686 : Closed e1196349912686 ∧ code e1196349912686 = 5594396423790 := by decide
theorem cert_e1196349912686 : check e1196349912686 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349912698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196349912698 : Closed e1196349912698 ∧ code e1196349912698 = 5594396423802 := by decide
theorem cert_e1196349912698 : check e1196349912698 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196349912886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196349912886 : Closed e1196349912886 ∧ code e1196349912886 = 5594396423990 := by decide
private def t_e1196349912886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e1196349912886 : ¬ IsSelfInterpreter e1196349912886 :=
  wSource (t := t_e1196349912886) (replay_sound (ps := []) (t := e1196349912886) (by decide)) (by decide)
def e1196349912890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196349912890 : Closed e1196349912890 ∧ code e1196349912890 = 5594396423994 := by decide
private def t_e1196349912890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e1196349912890 : ¬ IsSelfInterpreter e1196349912890 :=
  wSource (t := t_e1196349912890) (replay_sound (ps := []) (t := e1196349912890) (by decide)) (by decide)
def e1196349918062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196349918062 : Closed e1196349918062 ∧ code e1196349918062 = 5594396429166 := by decide
theorem cert_e1196349918062 : check e1196349918062 [[],[.left],[]] .chain = true := by decide
def e1196349918070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196349918070 : Closed e1196349918070 ∧ code e1196349918070 = 5594396429174 := by decide
theorem cert_e1196349918070 : check e1196349918070 [[],[.left],[]] .chain = true := by decide
end Blc.Floor42
