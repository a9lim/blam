import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209234812526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209234812526 : Closed e1209234812526 ∧ code e1209234812526 = 5607281323630 := by decide
theorem cert_e1209234812526 : checkPay e1209234812526 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209234812538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209234812538 : Closed e1209234812538 ∧ code e1209234812538 = 5607281323642 := by decide
theorem cert_e1209234812538 : checkPay e1209234812538 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right]] = true := by decide
def e1209234813806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209234813806 : Closed e1209234813806 ∧ code e1209234813806 = 5607281324910 := by decide
theorem cert_e1209234813806 : check e1209234813806 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234813814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209234813814 : Closed e1209234813814 ∧ code e1209234813814 = 5607281324918 := by decide
theorem cert_e1209234813814 : check e1209234813814 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234813870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209234813870 : Closed e1209234813870 ∧ code e1209234813870 = 5607281324974 := by decide
theorem cert_e1209234813870 : check e1209234813870 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234813882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209234813882 : Closed e1209234813882 ∧ code e1209234813882 = 5607281324986 := by decide
theorem cert_e1209234813882 : check e1209234813882 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1209234813910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209234813910 : Closed e1209234813910 ∧ code e1209234813910 = 5607281325014 := by decide
theorem cert_e1209234813910 : check e1209234813910 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234813914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209234813914 : Closed e1209234813914 ∧ code e1209234813914 = 5607281325018 := by decide
theorem cert_e1209234813914 : check e1209234813914 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1209234814190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209234814190 : Closed e1209234814190 ∧ code e1209234814190 = 5607281325294 := by decide
theorem cert_e1209234814190 : check e1209234814190 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234814198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209234814198 : Closed e1209234814198 ∧ code e1209234814198 = 5607281325302 := by decide
theorem cert_e1209234814198 : check e1209234814198 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234814574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209234814574 : Closed e1209234814574 ∧ code e1209234814574 = 5607281325678 := by decide
theorem cert_e1209234814574 : check e1209234814574 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234814586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209234814586 : Closed e1209234814586 ∧ code e1209234814586 = 5607281325690 := by decide
theorem cert_e1209234814586 : check e1209234814586 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234814774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209234814774 : Closed e1209234814774 ∧ code e1209234814774 = 5607281325878 := by decide
theorem cert_e1209234814774 : check e1209234814774 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234814778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209234814778 : Closed e1209234814778 ∧ code e1209234814778 = 5607281325882 := by decide
theorem cert_e1209234814778 : check e1209234814778 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234819950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209234819950 : Closed e1209234819950 ∧ code e1209234819950 = 5607281331054 := by decide
theorem cert_e1209234819950 : check e1209234819950 [[],[]] .smaller = true := by decide
def e1209234819958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209234819958 : Closed e1209234819958 ∧ code e1209234819958 = 5607281331062 := by decide
theorem cert_e1209234819958 : check e1209234819958 [[],[]] .smaller = true := by decide
def e1209234820014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209234820014 : Closed e1209234820014 ∧ code e1209234820014 = 5607281331118 := by decide
theorem cert_e1209234820014 : check e1209234820014 [[],[]] .smaller = true := by decide
def e1209234820026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209234820026 : Closed e1209234820026 ∧ code e1209234820026 = 5607281331130 := by decide
theorem cert_e1209234820026 : check e1209234820026 [[],[]] .smaller = true := by decide
def e1209234820054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209234820054 : Closed e1209234820054 ∧ code e1209234820054 = 5607281331158 := by decide
theorem cert_e1209234820054 : check e1209234820054 [[],[]] .smaller = true := by decide
def e1209234820058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209234820058 : Closed e1209234820058 ∧ code e1209234820058 = 5607281331162 := by decide
theorem cert_e1209234820058 : check e1209234820058 [[],[]] .smaller = true := by decide
def e1209234820334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209234820334 : Closed e1209234820334 ∧ code e1209234820334 = 5607281331438 := by decide
theorem cert_e1209234820334 : check e1209234820334 [[],[]] .smaller = true := by decide
def e1209234820342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209234820342 : Closed e1209234820342 ∧ code e1209234820342 = 5607281331446 := by decide
theorem cert_e1209234820342 : check e1209234820342 [[],[]] .smaller = true := by decide
def e1209234820718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209234820718 : Closed e1209234820718 ∧ code e1209234820718 = 5607281331822 := by decide
theorem cert_e1209234820718 : check e1209234820718 [[],[]] .smaller = true := by decide
def e1209234820730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209234820730 : Closed e1209234820730 ∧ code e1209234820730 = 5607281331834 := by decide
theorem cert_e1209234820730 : check e1209234820730 [[],[]] .smaller = true := by decide
def e1209234820918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209234820918 : Closed e1209234820918 ∧ code e1209234820918 = 5607281332022 := by decide
theorem cert_e1209234820918 : check e1209234820918 [[],[]] .smaller = true := by decide
def e1209234820922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209234820922 : Closed e1209234820922 ∧ code e1209234820922 = 5607281332026 := by decide
theorem cert_e1209234820922 : check e1209234820922 [[],[]] .smaller = true := by decide
def e1209234829038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1209234829038 : Closed e1209234829038 ∧ code e1209234829038 = 5607281340142 := by decide
theorem cert_e1209234829038 : check e1209234829038 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209234829166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1209234829166 : Closed e1209234829166 ∧ code e1209234829166 = 5607281340270 := by decide
theorem cert_e1209234829166 : check e1209234829166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209234829174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1209234829174 : Closed e1209234829174 ∧ code e1209234829174 = 5607281340278 := by decide
theorem cert_e1209234829174 : check e1209234829174 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209234831854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1209234831854 : Closed e1209234831854 ∧ code e1209234831854 = 5607281342958 := by decide
theorem cert_e1209234831854 : check e1209234831854 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209234832622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1209234832622 : Closed e1209234832622 ∧ code e1209234832622 = 5607281343726 := by decide
theorem cert_e1209234832622 : check e1209234832622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209234832630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1209234832630 : Closed e1209234832630 ∧ code e1209234832630 = 5607281343734 := by decide
theorem cert_e1209234832630 : check e1209234832630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1209234855662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1209234855662 : Closed e1209234855662 ∧ code e1209234855662 = 5607281366766 := by decide
theorem cert_e1209234855662 : check e1209234855662 [[],[]] .sourceHead = true := by decide
def e1209234855854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1209234855854 : Closed e1209234855854 ∧ code e1209234855854 = 5607281366958 := by decide
theorem cert_e1209234855854 : check e1209234855854 [[],[]] .sourceHead = true := by decide
def e1209234855866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1209234855866 : Closed e1209234855866 ∧ code e1209234855866 = 5607281366970 := by decide
theorem cert_e1209234855866 : check e1209234855866 [[],[]] .sourceHead = true := by decide
def e1209234856430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1209234856430 : Closed e1209234856430 ∧ code e1209234856430 = 5607281367534 := by decide
theorem cert_e1209234856430 : check e1209234856430 [[],[]] .sourceHead = true := by decide
def e1209234857582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1209234857582 : Closed e1209234857582 ∧ code e1209234857582 = 5607281368686 := by decide
theorem cert_e1209234857582 : check e1209234857582 [[],[]] .sourceHead = true := by decide
def e1209234857594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1209234857594 : Closed e1209234857594 ∧ code e1209234857594 = 5607281368698 := by decide
theorem cert_e1209234857594 : check e1209234857594 [[],[]] .sourceHead = true := by decide
def e1209234869102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209234869102 : Closed e1209234869102 ∧ code e1209234869102 = 5607281380206 := by decide
theorem cert_e1209234869102 : check e1209234869102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209234869110 : Closed e1209234869110 ∧ code e1209234869110 = 5607281380214 := by decide
theorem cert_e1209234869110 : check e1209234869110 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209234869166 : Closed e1209234869166 ∧ code e1209234869166 = 5607281380270 := by decide
theorem cert_e1209234869166 : check e1209234869166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209234869178 : Closed e1209234869178 ∧ code e1209234869178 = 5607281380282 := by decide
theorem cert_e1209234869178 : check e1209234869178 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209234869206 : Closed e1209234869206 ∧ code e1209234869206 = 5607281380310 := by decide
theorem cert_e1209234869206 : check e1209234869206 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209234869210 : Closed e1209234869210 ∧ code e1209234869210 = 5607281380314 := by decide
theorem cert_e1209234869210 : check e1209234869210 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209234869486 : Closed e1209234869486 ∧ code e1209234869486 = 5607281380590 := by decide
theorem cert_e1209234869486 : check e1209234869486 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209234869494 : Closed e1209234869494 ∧ code e1209234869494 = 5607281380598 := by decide
theorem cert_e1209234869494 : check e1209234869494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209234869870 : Closed e1209234869870 ∧ code e1209234869870 = 5607281380974 := by decide
theorem cert_e1209234869870 : check e1209234869870 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234869882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209234869882 : Closed e1209234869882 ∧ code e1209234869882 = 5607281380986 := by decide
theorem cert_e1209234869882 : check e1209234869882 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234870070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209234870070 : Closed e1209234870070 ∧ code e1209234870070 = 5607281381174 := by decide
theorem cert_e1209234870070 : check e1209234870070 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234870074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209234870074 : Closed e1209234870074 ∧ code e1209234870074 = 5607281381178 := by decide
theorem cert_e1209234870074 : check e1209234870074 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209235409774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209235409774 : Closed e1209235409774 ∧ code e1209235409774 = 5607281920878 := by decide
theorem cert_e1209235409774 : check e1209235409774 [[],[]] .smaller = true := by decide
def e1209235409782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209235409782 : Closed e1209235409782 ∧ code e1209235409782 = 5607281920886 := by decide
theorem cert_e1209235409782 : check e1209235409782 [[],[]] .smaller = true := by decide
def e1209235409838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209235409838 : Closed e1209235409838 ∧ code e1209235409838 = 5607281920942 := by decide
theorem cert_e1209235409838 : check e1209235409838 [[],[]] .smaller = true := by decide
def e1209235409850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209235409850 : Closed e1209235409850 ∧ code e1209235409850 = 5607281920954 := by decide
theorem cert_e1209235409850 : check e1209235409850 [[],[]] .smaller = true := by decide
def e1209235409878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209235409878 : Closed e1209235409878 ∧ code e1209235409878 = 5607281920982 := by decide
theorem cert_e1209235409878 : check e1209235409878 [[],[]] .smaller = true := by decide
def e1209235409882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209235409882 : Closed e1209235409882 ∧ code e1209235409882 = 5607281920986 := by decide
theorem cert_e1209235409882 : check e1209235409882 [[],[]] .smaller = true := by decide
def e1209235410158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209235410158 : Closed e1209235410158 ∧ code e1209235410158 = 5607281921262 := by decide
theorem cert_e1209235410158 : check e1209235410158 [[],[]] .smaller = true := by decide
def e1209235410166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209235410166 : Closed e1209235410166 ∧ code e1209235410166 = 5607281921270 := by decide
theorem cert_e1209235410166 : check e1209235410166 [[],[]] .smaller = true := by decide
def e1209235410542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209235410542 : Closed e1209235410542 ∧ code e1209235410542 = 5607281921646 := by decide
theorem cert_e1209235410542 : check e1209235410542 [[],[]] .smaller = true := by decide
def e1209235410554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209235410554 : Closed e1209235410554 ∧ code e1209235410554 = 5607281921658 := by decide
theorem cert_e1209235410554 : check e1209235410554 [[],[]] .smaller = true := by decide
def e1209235410742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209235410742 : Closed e1209235410742 ∧ code e1209235410742 = 5607281921846 := by decide
theorem cert_e1209235410742 : check e1209235410742 [[],[]] .smaller = true := by decide
def e1209235410746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209235410746 : Closed e1209235410746 ∧ code e1209235410746 = 5607281921850 := by decide
theorem cert_e1209235410746 : check e1209235410746 [[],[]] .smaller = true := by decide
def e1209469590382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1209469590382 : Closed e1209469590382 ∧ code e1209469590382 = 5607516101486 := by decide
theorem cert_e1209469590382 : check e1209469590382 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209469590390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1209469590390 : Closed e1209469590390 ∧ code e1209469590390 = 5607516101494 := by decide
theorem cert_e1209469590390 : check e1209469590390 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209469590454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1209469590454 : Closed e1209469590454 ∧ code e1209469590454 = 5607516101558 := by decide
theorem cert_e1209469590454 : check e1209469590454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209469590894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209469590894 : Closed e1209469590894 ∧ code e1209469590894 = 5607516101998 := by decide
theorem cert_e1209469590894 : check e1209469590894 [[],[]] .sourceHead = true := by decide
def e1209469590902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209469590902 : Closed e1209469590902 ∧ code e1209469590902 = 5607516102006 := by decide
theorem cert_e1209469590902 : check e1209469590902 [[],[]] .sourceHead = true := by decide
def e1209469590958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209469590958 : Closed e1209469590958 ∧ code e1209469590958 = 5607516102062 := by decide
theorem cert_e1209469590958 : check e1209469590958 [[],[]] .sourceHead = true := by decide
def e1209469590970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209469590970 : Closed e1209469590970 ∧ code e1209469590970 = 5607516102074 := by decide
theorem cert_e1209469590970 : check e1209469590970 [[],[]] .sourceHead = true := by decide
def e1209469590998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209469590998 : Closed e1209469590998 ∧ code e1209469590998 = 5607516102102 := by decide
theorem cert_e1209469590998 : check e1209469590998 [[],[]] .sourceHead = true := by decide
def e1209469591002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209469591002 : Closed e1209469591002 ∧ code e1209469591002 = 5607516102106 := by decide
theorem cert_e1209469591002 : check e1209469591002 [[],[]] .sourceHead = true := by decide
def e1209469591222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1209469591222 : Closed e1209469591222 ∧ code e1209469591222 = 5607516102326 := by decide
theorem cert_e1209469591222 : check e1209469591222 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209469591254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1209469591254 : Closed e1209469591254 ∧ code e1209469591254 = 5607516102358 := by decide
theorem cert_e1209469591254 : check e1209469591254 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209469591258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1209469591258 : Closed e1209469591258 ∧ code e1209469591258 = 5607516102362 := by decide
theorem cert_e1209469591258 : check e1209469591258 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1209469593454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1209469593454 : Closed e1209469593454 ∧ code e1209469593454 = 5607516104558 := by decide
theorem cert_e1209469593454 : check e1209469593454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209469593462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1209469593462 : Closed e1209469593462 ∧ code e1209469593462 = 5607516104566 := by decide
theorem cert_e1209469593462 : check e1209469593462 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209469593526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1209469593526 : Closed e1209469593526 ∧ code e1209469593526 = 5607516104630 := by decide
theorem cert_e1209469593526 : check e1209469593526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209469594862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209469594862 : Closed e1209469594862 ∧ code e1209469594862 = 5607516105966 := by decide
theorem cert_e1209469594862 : check e1209469594862 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209469594870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209469594870 : Closed e1209469594870 ∧ code e1209469594870 = 5607516105974 := by decide
theorem cert_e1209469594870 : check e1209469594870 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209469595254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209469595254 : Closed e1209469595254 ∧ code e1209469595254 = 5607516106358 := by decide
theorem cert_e1209469595254 : check e1209469595254 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209469596526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209469596526 : Closed e1209469596526 ∧ code e1209469596526 = 5607516107630 := by decide
theorem cert_e1209469596526 : checkPay e1209469596526 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209469596534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209469596534 : Closed e1209469596534 ∧ code e1209469596534 = 5607516107638 := by decide
theorem cert_e1209469596534 : checkPay e1209469596534 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e1209469596590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209469596590 : Closed e1209469596590 ∧ code e1209469596590 = 5607516107694 := by decide
theorem cert_e1209469596590 : checkPay e1209469596590 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209469596602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209469596602 : Closed e1209469596602 ∧ code e1209469596602 = 5607516107706 := by decide
theorem cert_e1209469596602 : checkPay e1209469596602 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e1209469596630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209469596630 : Closed e1209469596630 ∧ code e1209469596630 = 5607516107734 := by decide
theorem cert_e1209469596630 : checkPay e1209469596630 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right],[.under,.left,.left,.left,.right,.under,.under,.left,.right]] = true := by decide
def e1209469596634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209469596634 : Closed e1209469596634 ∧ code e1209469596634 = 5607516107738 := by decide
theorem cert_e1209469596634 : checkPay e1209469596634 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1209469596910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209469596910 : Closed e1209469596910 ∧ code e1209469596910 = 5607516108014 := by decide
theorem cert_e1209469596910 : checkPay e1209469596910 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209469596918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209469596918 : Closed e1209469596918 ∧ code e1209469596918 = 5607516108022 := by decide
theorem cert_e1209469596918 : checkPay e1209469596918 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209469597294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209469597294 : Closed e1209469597294 ∧ code e1209469597294 = 5607516108398 := by decide
theorem cert_e1209469597294 : checkPay e1209469597294 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209469597306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209469597306 : Closed e1209469597306 ∧ code e1209469597306 = 5607516108410 := by decide
theorem cert_e1209469597306 : checkPay e1209469597306 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209469597494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209469597494 : Closed e1209469597494 ∧ code e1209469597494 = 5607516108598 := by decide
theorem cert_e1209469597494 : checkPay e1209469597494 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1209469597498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209469597498 : Closed e1209469597498 ∧ code e1209469597498 = 5607516108602 := by decide
theorem cert_e1209469597498 : checkPay e1209469597498 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1209469598134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1209469598134 : Closed e1209469598134 ∧ code e1209469598134 = 5607516109238 := by decide
theorem cert_e1209469598134 : check e1209469598134 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469598166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1209469598166 : Closed e1209469598166 ∧ code e1209469598166 = 5607516109270 := by decide
theorem cert_e1209469598166 : check e1209469598166 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469598170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1209469598170 : Closed e1209469598170 ∧ code e1209469598170 = 5607516109274 := by decide
theorem cert_e1209469598170 : check e1209469598170 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469598326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209469598326 : Closed e1209469598326 ∧ code e1209469598326 = 5607516109430 := by decide
theorem cert_e1209469598326 : check e1209469598326 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469598518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209469598518 : Closed e1209469598518 ∧ code e1209469598518 = 5607516109622 := by decide
theorem cert_e1209469598518 : check e1209469598518 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469598522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209469598522 : Closed e1209469598522 ∧ code e1209469598522 = 5607516109626 := by decide
theorem cert_e1209469598522 : check e1209469598522 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1209469605742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1209469605742 : Closed e1209469605742 ∧ code e1209469605742 = 5607516116846 := by decide
theorem cert_e1209469605742 : check e1209469605742 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209469605750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1209469605750 : Closed e1209469605750 ∧ code e1209469605750 = 5607516116854 := by decide
theorem cert_e1209469605750 : check e1209469605750 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209469605814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1209469605814 : Closed e1209469605814 ∧ code e1209469605814 = 5607516116918 := by decide
theorem cert_e1209469605814 : check e1209469605814 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209469607150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1209469607150 : Closed e1209469607150 ∧ code e1209469607150 = 5607516118254 := by decide
theorem cert_e1209469607150 : check e1209469607150 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209469607158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1209469607158 : Closed e1209469607158 ∧ code e1209469607158 = 5607516118262 := by decide
theorem cert_e1209469607158 : check e1209469607158 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1209469607542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1209469607542 : Closed e1209469607542 ∧ code e1209469607542 = 5607516118646 := by decide
theorem cert_e1209469607542 : check e1209469607542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209469619054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209469619054 : Closed e1209469619054 ∧ code e1209469619054 = 5607516130158 := by decide
theorem cert_e1209469619054 : check e1209469619054 [[],[]] .sourceHead = true := by decide
def e1209469619062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209469619062 : Closed e1209469619062 ∧ code e1209469619062 = 5607516130166 := by decide
theorem cert_e1209469619062 : check e1209469619062 [[],[]] .sourceHead = true := by decide
def e1209469619118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209469619118 : Closed e1209469619118 ∧ code e1209469619118 = 5607516130222 := by decide
theorem cert_e1209469619118 : check e1209469619118 [[],[]] .sourceHead = true := by decide
def e1209469619130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209469619130 : Closed e1209469619130 ∧ code e1209469619130 = 5607516130234 := by decide
theorem cert_e1209469619130 : check e1209469619130 [[],[]] .sourceHead = true := by decide
def e1209469619158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209469619158 : Closed e1209469619158 ∧ code e1209469619158 = 5607516130262 := by decide
theorem cert_e1209469619158 : check e1209469619158 [[],[]] .sourceHead = true := by decide
def e1209469619162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209469619162 : Closed e1209469619162 ∧ code e1209469619162 = 5607516130266 := by decide
theorem cert_e1209469619162 : check e1209469619162 [[],[]] .sourceHead = true := by decide
def e1209469619438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209469619438 : Closed e1209469619438 ∧ code e1209469619438 = 5607516130542 := by decide
theorem cert_e1209469619438 : check e1209469619438 [[],[]] .sourceHead = true := by decide
def e1209469619446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209469619446 : Closed e1209469619446 ∧ code e1209469619446 = 5607516130550 := by decide
theorem cert_e1209469619446 : check e1209469619446 [[],[]] .sourceHead = true := by decide
def e1209469619822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209469619822 : Closed e1209469619822 ∧ code e1209469619822 = 5607516130926 := by decide
theorem cert_e1209469619822 : check e1209469619822 [[],[]] .sourceHead = true := by decide
def e1209469619834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209469619834 : Closed e1209469619834 ∧ code e1209469619834 = 5607516130938 := by decide
theorem cert_e1209469619834 : check e1209469619834 [[],[]] .sourceHead = true := by decide
def e1209469620022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209469620022 : Closed e1209469620022 ∧ code e1209469620022 = 5607516131126 := by decide
theorem cert_e1209469620022 : check e1209469620022 [[],[]] .sourceHead = true := by decide
def e1209469620026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209469620026 : Closed e1209469620026 ∧ code e1209469620026 = 5607516131130 := by decide
theorem cert_e1209469620026 : check e1209469620026 [[],[]] .sourceHead = true := by decide
def e1209469625782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1209469625782 : Closed e1209469625782 ∧ code e1209469625782 = 5607516136886 := by decide
theorem cert_e1209469625782 : check e1209469625782 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469625814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1209469625814 : Closed e1209469625814 ∧ code e1209469625814 = 5607516136918 := by decide
theorem cert_e1209469625814 : check e1209469625814 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469625818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1209469625818 : Closed e1209469625818 ∧ code e1209469625818 = 5607516136922 := by decide
theorem cert_e1209469625818 : check e1209469625818 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469625974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1209469625974 : Closed e1209469625974 ∧ code e1209469625974 = 5607516137078 := by decide
theorem cert_e1209469625974 : check e1209469625974 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469626166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1209469626166 : Closed e1209469626166 ∧ code e1209469626166 = 5607516137270 := by decide
theorem cert_e1209469626166 : check e1209469626166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469626170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1209469626170 : Closed e1209469626170 ∧ code e1209469626170 = 5607516137274 := by decide
theorem cert_e1209469626170 : check e1209469626170 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209469963118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209469963118 : Closed e1209469963118 ∧ code e1209469963118 = 5607516474222 := by decide
theorem cert_e1209469963118 : check e1209469963118 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209469963126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209469963126 : Closed e1209469963126 ∧ code e1209469963126 = 5607516474230 := by decide
private def t_e1209469963126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1209469963126 : ¬ IsSelfInterpreter e1209469963126 :=
  wSource (t := t_e1209469963126) (replay_sound (ps := []) (t := e1209469963126) (by decide)) (by decide)
def e1209469963182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209469963182 : Closed e1209469963182 ∧ code e1209469963182 = 5607516474286 := by decide
theorem cert_e1209469963182 : check e1209469963182 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1209469963194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209469963194 : Closed e1209469963194 ∧ code e1209469963194 = 5607516474298 := by decide
theorem cert_e1209469963194 : check e1209469963194 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1209469963222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209469963222 : Closed e1209469963222 ∧ code e1209469963222 = 5607516474326 := by decide
private def t_e1209469963222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1209469963222 : ¬ IsSelfInterpreter e1209469963222 :=
  wSource (t := t_e1209469963222) (replay_sound (ps := []) (t := e1209469963222) (by decide)) (by decide)
def e1209469963226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209469963226 : Closed e1209469963226 ∧ code e1209469963226 = 5607516474330 := by decide
def e1209469963502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209469963502 : Closed e1209469963502 ∧ code e1209469963502 = 5607516474606 := by decide
theorem cert_e1209469963502 : check e1209469963502 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209469963510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209469963510 : Closed e1209469963510 ∧ code e1209469963510 = 5607516474614 := by decide
def e1209469963886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209469963886 : Closed e1209469963886 ∧ code e1209469963886 = 5607516474990 := by decide
theorem cert_e1209469963886 : check e1209469963886 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209469963898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209469963898 : Closed e1209469963898 ∧ code e1209469963898 = 5607516475002 := by decide
theorem cert_e1209469963898 : check e1209469963898 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1209469964086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209469964086 : Closed e1209469964086 ∧ code e1209469964086 = 5607516475190 := by decide
theorem cert_e1209469964086 : check e1209469964086 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209469964090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209469964090 : Closed e1209469964090 ∧ code e1209469964090 = 5607516475194 := by decide
theorem cert_e1209469964090 : check e1209469964090 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1209570253534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1209570253534 : Closed e1209570253534 ∧ code e1209570253534 = 5607616764638 := by decide
theorem cert_e1209570253534 : check e1209570253534 [[],[]] .smaller = true := by decide
def e1209570253558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1209570253558 : Closed e1209570253558 ∧ code e1209570253558 = 5607616764662 := by decide
theorem cert_e1209570253558 : check e1209570253558 [[],[]] .smaller = true := by decide
def e1209570253662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1209570253662 : Closed e1209570253662 ∧ code e1209570253662 = 5607616764766 := by decide
theorem cert_e1209570253662 : check e1209570253662 [[],[]] .smaller = true := by decide
def e1209570253678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1209570253678 : Closed e1209570253678 ∧ code e1209570253678 = 5607616764782 := by decide
theorem cert_e1209570253678 : check e1209570253678 [[],[]] .smaller = true := by decide
def e1209570253686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1209570253686 : Closed e1209570253686 ∧ code e1209570253686 = 5607616764790 := by decide
theorem cert_e1209570253686 : check e1209570253686 [[],[]] .smaller = true := by decide
def e1209570253690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1209570253690 : Closed e1209570253690 ∧ code e1209570253690 = 5607616764794 := by decide
theorem cert_e1209570253690 : check e1209570253690 [[],[]] .smaller = true := by decide
def e1209570253750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1209570253750 : Closed e1209570253750 ∧ code e1209570253750 = 5607616764854 := by decide
theorem cert_e1209570253750 : check e1209570253750 [[],[]] .smaller = true := by decide
def e1209570253782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1209570253782 : Closed e1209570253782 ∧ code e1209570253782 = 5607616764886 := by decide
theorem cert_e1209570253782 : check e1209570253782 [[],[]] .smaller = true := by decide
def e1209570253786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1209570253786 : Closed e1209570253786 ∧ code e1209570253786 = 5607616764890 := by decide
theorem cert_e1209570253786 : check e1209570253786 [[],[]] .smaller = true := by decide
def e1209570254174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1209570254174 : Closed e1209570254174 ∧ code e1209570254174 = 5607616765278 := by decide
theorem cert_e1209570254174 : check e1209570254174 [[],[]] .smaller = true := by decide
def e1209570254190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1209570254190 : Closed e1209570254190 ∧ code e1209570254190 = 5607616765294 := by decide
theorem cert_e1209570254190 : check e1209570254190 [[],[]] .smaller = true := by decide
def e1209570254198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1209570254198 : Closed e1209570254198 ∧ code e1209570254198 = 5607616765302 := by decide
theorem cert_e1209570254198 : check e1209570254198 [[],[]] .smaller = true := by decide
def e1209570254202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1209570254202 : Closed e1209570254202 ∧ code e1209570254202 = 5607616765306 := by decide
theorem cert_e1209570254202 : check e1209570254202 [[],[]] .smaller = true := by decide
def e1209570254254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1209570254254 : Closed e1209570254254 ∧ code e1209570254254 = 5607616765358 := by decide
theorem cert_e1209570254254 : check e1209570254254 [[],[]] .smaller = true := by decide
def e1209570254266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1209570254266 : Closed e1209570254266 ∧ code e1209570254266 = 5607616765370 := by decide
theorem cert_e1209570254266 : check e1209570254266 [[],[]] .smaller = true := by decide
def e1209570254294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1209570254294 : Closed e1209570254294 ∧ code e1209570254294 = 5607616765398 := by decide
theorem cert_e1209570254294 : check e1209570254294 [[],[]] .smaller = true := by decide
def e1209570254298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1209570254298 : Closed e1209570254298 ∧ code e1209570254298 = 5607616765402 := by decide
theorem cert_e1209570254298 : check e1209570254298 [[],[]] .smaller = true := by decide
def e1209570254314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1209570254314 : Closed e1209570254314 ∧ code e1209570254314 = 5607616765418 := by decide
theorem cert_e1209570254314 : check e1209570254314 [[],[]] .smaller = true := by decide
def e1209570254518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1209570254518 : Closed e1209570254518 ∧ code e1209570254518 = 5607616765622 := by decide
theorem cert_e1209570254518 : check e1209570254518 [[],[]] .smaller = true := by decide
def e1209570254550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1209570254550 : Closed e1209570254550 ∧ code e1209570254550 = 5607616765654 := by decide
theorem cert_e1209570254550 : check e1209570254550 [[],[]] .smaller = true := by decide
def e1209570254554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1209570254554 : Closed e1209570254554 ∧ code e1209570254554 = 5607616765658 := by decide
theorem cert_e1209570254554 : check e1209570254554 [[],[]] .smaller = true := by decide
def e1209570254678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1209570254678 : Closed e1209570254678 ∧ code e1209570254678 = 5607616765782 := by decide
theorem cert_e1209570254678 : check e1209570254678 [[],[]] .smaller = true := by decide
def e1209570254682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1209570254682 : Closed e1209570254682 ∧ code e1209570254682 = 5607616765786 := by decide
theorem cert_e1209570254682 : check e1209570254682 [[],[]] .smaller = true := by decide
def e1209570254698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1209570254698 : Closed e1209570254698 ∧ code e1209570254698 = 5607616765802 := by decide
theorem cert_e1209570254698 : check e1209570254698 [[],[]] .smaller = true := by decide
def e1209570256606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1209570256606 : Closed e1209570256606 ∧ code e1209570256606 = 5607616767710 := by decide
theorem cert_e1209570256606 : check e1209570256606 [[],[]] .smaller = true := by decide
def e1209570256630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1209570256630 : Closed e1209570256630 ∧ code e1209570256630 = 5607616767734 := by decide
theorem cert_e1209570256630 : check e1209570256630 [[],[]] .smaller = true := by decide
end Blc.Floor42
