import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211298426746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211298426746 : Closed e1211298426746 ∧ code e1211298426746 = 5609344937850 := by decide
theorem cert_e1211298426746 : check e1211298426746 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211298426798 : Closed e1211298426798 ∧ code e1211298426798 = 5609344937902 := by decide
theorem cert_e1211298426798 : check e1211298426798 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211298426806 : Closed e1211298426806 ∧ code e1211298426806 = 5609344937910 := by decide
theorem cert_e1211298426806 : check e1211298426806 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211298426810 : Closed e1211298426810 ∧ code e1211298426810 = 5609344937914 := by decide
theorem cert_e1211298426810 : check e1211298426810 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298427870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211298427870 : Closed e1211298427870 ∧ code e1211298427870 = 5609344938974 := by decide
theorem cert_e1211298427870 : check e1211298427870 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298427886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211298427886 : Closed e1211298427886 ∧ code e1211298427886 = 5609344938990 := by decide
theorem cert_e1211298427886 : check e1211298427886 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298429406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211298429406 : Closed e1211298429406 ∧ code e1211298429406 = 5609344940510 := by decide
theorem cert_e1211298429406 : check e1211298429406 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298429422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211298429422 : Closed e1211298429422 ∧ code e1211298429422 = 5609344940526 := by decide
theorem cert_e1211298429422 : check e1211298429422 [[],[]] .chain = true := by decide
def e1211298429430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211298429430 : Closed e1211298429430 ∧ code e1211298429430 = 5609344940534 := by decide
theorem cert_e1211298429430 : check e1211298429430 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298430174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211298430174 : Closed e1211298430174 ∧ code e1211298430174 = 5609344941278 := by decide
theorem cert_e1211298430174 : check e1211298430174 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298430190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211298430190 : Closed e1211298430190 ∧ code e1211298430190 = 5609344941294 := by decide
theorem cert_e1211298430190 : check e1211298430190 [[],[]] .chain = true := by decide
def e1211298430198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211298430198 : Closed e1211298430198 ∧ code e1211298430198 = 5609344941302 := by decide
theorem cert_e1211298430198 : check e1211298430198 [[],[]] .chain = true := by decide
def e1211298430202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211298430202 : Closed e1211298430202 ∧ code e1211298430202 = 5609344941306 := by decide
theorem cert_e1211298430202 : check e1211298430202 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298430574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298430574 : Closed e1211298430574 ∧ code e1211298430574 = 5609344941678 := by decide
theorem cert_e1211298430574 : check e1211298430574 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298430582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211298430582 : Closed e1211298430582 ∧ code e1211298430582 = 5609344941686 := by decide
theorem cert_e1211298430582 : check e1211298430582 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298430586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298430586 : Closed e1211298430586 ∧ code e1211298430586 = 5609344941690 := by decide
theorem cert_e1211298430586 : check e1211298430586 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211298453214 : Closed e1211298453214 ∧ code e1211298453214 = 5609344964318 := by decide
theorem cert_e1211298453214 : check e1211298453214 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211298453230 : Closed e1211298453230 ∧ code e1211298453230 = 5609344964334 := by decide
theorem cert_e1211298453230 : check e1211298453230 [[],[]] .chain = true := by decide
def e1211298453238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211298453238 : Closed e1211298453238 ∧ code e1211298453238 = 5609344964342 := by decide
theorem cert_e1211298453238 : check e1211298453238 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211298453342 : Closed e1211298453342 ∧ code e1211298453342 = 5609344964446 := by decide
theorem cert_e1211298453342 : check e1211298453342 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211298453370 : Closed e1211298453370 ∧ code e1211298453370 = 5609344964474 := by decide
private def t_e1211298453370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e1211298453370 : ¬ IsSelfInterpreter e1211298453370 :=
  wSource (t := t_e1211298453370) (replay_sound (ps := []) (t := e1211298453370) (by decide)) (by decide)
def e1211298453422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211298453422 : Closed e1211298453422 ∧ code e1211298453422 = 5609344964526 := by decide
theorem cert_e1211298453422 : check e1211298453422 [[],[]] .chain = true := by decide
def e1211298453434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211298453434 : Closed e1211298453434 ∧ code e1211298453434 = 5609344964538 := by decide
theorem cert_e1211298453434 : check e1211298453434 [[],[]] .chain = true := by decide
def e1211298453462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211298453462 : Closed e1211298453462 ∧ code e1211298453462 = 5609344964566 := by decide
theorem cert_e1211298453462 : check e1211298453462 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211298453466 : Closed e1211298453466 ∧ code e1211298453466 = 5609344964570 := by decide
private def t_e1211298453466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e1211298453466 : ¬ IsSelfInterpreter e1211298453466 :=
  wSource (t := t_e1211298453466) (replay_sound (ps := []) (t := e1211298453466) (by decide)) (by decide)
def e1211298453982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211298453982 : Closed e1211298453982 ∧ code e1211298453982 = 5609344965086 := by decide
theorem cert_e1211298453982 : check e1211298453982 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298453998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211298453998 : Closed e1211298453998 ∧ code e1211298453998 = 5609344965102 := by decide
theorem cert_e1211298453998 : check e1211298453998 [[],[]] .chain = true := by decide
def e1211298454006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211298454006 : Closed e1211298454006 ∧ code e1211298454006 = 5609344965110 := by decide
theorem cert_e1211298454006 : check e1211298454006 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298454750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211298454750 : Closed e1211298454750 ∧ code e1211298454750 = 5609344965854 := by decide
theorem cert_e1211298454750 : check e1211298454750 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298454778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211298454778 : Closed e1211298454778 ∧ code e1211298454778 = 5609344965882 := by decide
theorem cert_e1211298454778 : check e1211298454778 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298455102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211298455102 : Closed e1211298455102 ∧ code e1211298455102 = 5609344966206 := by decide
theorem cert_e1211298455102 : check e1211298455102 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298455150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298455150 : Closed e1211298455150 ∧ code e1211298455150 = 5609344966254 := by decide
theorem cert_e1211298455150 : check e1211298455150 [[],[]] .chain = true := by decide
def e1211298455162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298455162 : Closed e1211298455162 ∧ code e1211298455162 = 5609344966266 := by decide
theorem cert_e1211298455162 : check e1211298455162 [[],[]] .chain = true := by decide
def e1211298455326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211298455326 : Closed e1211298455326 ∧ code e1211298455326 = 5609344966430 := by decide
theorem cert_e1211298455326 : check e1211298455326 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298455350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211298455350 : Closed e1211298455350 ∧ code e1211298455350 = 5609344966454 := by decide
theorem cert_e1211298455350 : check e1211298455350 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298455354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211298455354 : Closed e1211298455354 ∧ code e1211298455354 = 5609344966458 := by decide
theorem cert_e1211298455354 : check e1211298455354 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298464702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e1211298464702 : Closed e1211298464702 ∧ code e1211298464702 = 5609344975806 := by decide
theorem cert_e1211298464702 : check e1211298464702 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298464758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e1211298464758 : Closed e1211298464758 ∧ code e1211298464758 = 5609344975862 := by decide
theorem cert_e1211298464758 : check e1211298464758 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298466654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211298466654 : Closed e1211298466654 ∧ code e1211298466654 = 5609344977758 := by decide
theorem cert_e1211298466654 : check e1211298466654 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298466670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211298466670 : Closed e1211298466670 ∧ code e1211298466670 = 5609344977774 := by decide
theorem cert_e1211298466670 : check e1211298466670 [[],[]] .chain = true := by decide
def e1211298466678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211298466678 : Closed e1211298466678 ∧ code e1211298466678 = 5609344977782 := by decide
theorem cert_e1211298466678 : check e1211298466678 [[],[]] .chain = true := by decide
def e1211298466682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211298466682 : Closed e1211298466682 ∧ code e1211298466682 = 5609344977786 := by decide
theorem cert_e1211298466682 : check e1211298466682 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298466734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211298466734 : Closed e1211298466734 ∧ code e1211298466734 = 5609344977838 := by decide
theorem cert_e1211298466734 : check e1211298466734 [[],[]] .chain = true := by decide
def e1211298466746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211298466746 : Closed e1211298466746 ∧ code e1211298466746 = 5609344977850 := by decide
theorem cert_e1211298466746 : check e1211298466746 [[],[]] .chain = true := by decide
def e1211298466774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211298466774 : Closed e1211298466774 ∧ code e1211298466774 = 5609344977878 := by decide
theorem cert_e1211298466774 : check e1211298466774 [[],[]] .chain = true := by decide
def e1211298466778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211298466778 : Closed e1211298466778 ∧ code e1211298466778 = 5609344977882 := by decide
theorem cert_e1211298466778 : check e1211298466778 [[],[]] .chain = true := by decide
def e1211298466794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211298466794 : Closed e1211298466794 ∧ code e1211298466794 = 5609344977898 := by decide
theorem cert_e1211298466794 : check e1211298466794 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298467038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211298467038 : Closed e1211298467038 ∧ code e1211298467038 = 5609344978142 := by decide
theorem cert_e1211298467038 : check e1211298467038 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298467054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211298467054 : Closed e1211298467054 ∧ code e1211298467054 = 5609344978158 := by decide
theorem cert_e1211298467054 : check e1211298467054 [[],[]] .chain = true := by decide
def e1211298467062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211298467062 : Closed e1211298467062 ∧ code e1211298467062 = 5609344978166 := by decide
theorem cert_e1211298467062 : check e1211298467062 [[],[]] .chain = true := by decide
def e1211298467066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211298467066 : Closed e1211298467066 ∧ code e1211298467066 = 5609344978170 := by decide
theorem cert_e1211298467066 : check e1211298467066 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298467390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211298467390 : Closed e1211298467390 ∧ code e1211298467390 = 5609344978494 := by decide
theorem cert_e1211298467390 : check e1211298467390 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298467438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298467438 : Closed e1211298467438 ∧ code e1211298467438 = 5609344978542 := by decide
theorem cert_e1211298467438 : check e1211298467438 [[],[]] .chain = true := by decide
def e1211298467450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298467450 : Closed e1211298467450 ∧ code e1211298467450 = 5609344978554 := by decide
theorem cert_e1211298467450 : check e1211298467450 [[],[]] .chain = true := by decide
def e1211298467638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211298467638 : Closed e1211298467638 ∧ code e1211298467638 = 5609344978742 := by decide
theorem cert_e1211298467638 : check e1211298467638 [[],[]] .chain = true := by decide
def e1211298467642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211298467642 : Closed e1211298467642 ∧ code e1211298467642 = 5609344978746 := by decide
theorem cert_e1211298467642 : check e1211298467642 [[],[]] .chain = true := by decide
def e1211298467726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211298467726 : Closed e1211298467726 ∧ code e1211298467726 = 5609344978830 := by decide
theorem cert_e1211298467726 : check e1211298467726 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298467738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211298467738 : Closed e1211298467738 ∧ code e1211298467738 = 5609344978842 := by decide
theorem cert_e1211298467738 : check e1211298467738 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298472414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211298472414 : Closed e1211298472414 ∧ code e1211298472414 = 5609344983518 := by decide
theorem cert_e1211298472414 : check e1211298472414 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298472438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211298472438 : Closed e1211298472438 ∧ code e1211298472438 = 5609344983542 := by decide
theorem cert_e1211298472438 : check e1211298472438 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211298473390 : Closed e1211298473390 ∧ code e1211298473390 = 5609344984494 := by decide
theorem cert_e1211298473390 : check e1211298473390 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211298473398 : Closed e1211298473398 ∧ code e1211298473398 = 5609344984502 := by decide
theorem cert_e1211298473398 : check e1211298473398 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211298473402 : Closed e1211298473402 ∧ code e1211298473402 = 5609344984506 := by decide
theorem cert_e1211298473402 : check e1211298473402 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211298473430 : Closed e1211298473430 ∧ code e1211298473430 = 5609344984534 := by decide
theorem cert_e1211298473430 : check e1211298473430 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211298473434 : Closed e1211298473434 ∧ code e1211298473434 = 5609344984538 := by decide
private def t_e1211298473434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem cert_e1211298473434 : ¬ IsSelfInterpreter e1211298473434 :=
  wSource (t := t_e1211298473434) (replay_sound (ps := []) (t := e1211298473434) (by decide)) (by decide)
def e1211298473450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211298473450 : Closed e1211298473450 ∧ code e1211298473450 = 5609344984554 := by decide
theorem cert_e1211298473450 : check e1211298473450 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298473582 : Closed e1211298473582 ∧ code e1211298473582 = 5609344984686 := by decide
theorem cert_e1211298473582 : check e1211298473582 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211298473590 : Closed e1211298473590 ∧ code e1211298473590 = 5609344984694 := by decide
theorem cert_e1211298473590 : check e1211298473590 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298473594 : Closed e1211298473594 ∧ code e1211298473594 = 5609344984698 := by decide
theorem cert_e1211298473594 : check e1211298473594 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211298473758 : Closed e1211298473758 ∧ code e1211298473758 = 5609344984862 := by decide
theorem cert_e1211298473758 : check e1211298473758 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211298473782 : Closed e1211298473782 ∧ code e1211298473782 = 5609344984886 := by decide
theorem cert_e1211298473782 : check e1211298473782 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211298473786 : Closed e1211298473786 ∧ code e1211298473786 = 5609344984890 := by decide
theorem cert_e1211298473786 : check e1211298473786 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211298473870 : Closed e1211298473870 ∧ code e1211298473870 = 5609344984974 := by decide
theorem cert_e1211298473870 : check e1211298473870 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298473882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211298473882 : Closed e1211298473882 ∧ code e1211298473882 = 5609344984986 := by decide
theorem cert_e1211298473882 : check e1211298473882 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298919790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211298919790 : Closed e1211298919790 ∧ code e1211298919790 = 5609345430894 := by decide
private def t_e1211298919790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e1211298919790 : ¬ IsSelfInterpreter e1211298919790 :=
  wSource (t := t_e1211298919790) (replay_sound (ps := []) (t := e1211298919790) (by decide)) (by decide)
def e1211298919798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211298919798 : Closed e1211298919798 ∧ code e1211298919798 = 5609345430902 := by decide
private def t_e1211298919798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e1211298919798 : ¬ IsSelfInterpreter e1211298919798 :=
  wSource (t := t_e1211298919798) (replay_sound (ps := []) (t := e1211298919798) (by decide)) (by decide)
def e1211298919854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211298919854 : Closed e1211298919854 ∧ code e1211298919854 = 5609345430958 := by decide
private def t_e1211298919854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e1211298919854 : ¬ IsSelfInterpreter e1211298919854 :=
  wSource (t := t_e1211298919854) (replay_sound (ps := []) (t := e1211298919854) (by decide)) (by decide)
def e1211298919866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211298919866 : Closed e1211298919866 ∧ code e1211298919866 = 5609345430970 := by decide
private def t_e1211298919866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e1211298919866 : ¬ IsSelfInterpreter e1211298919866 :=
  wSource (t := t_e1211298919866) (replay_sound (ps := []) (t := e1211298919866) (by decide)) (by decide)
def e1211298919894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211298919894 : Closed e1211298919894 ∧ code e1211298919894 = 5609345430998 := by decide
private def t_e1211298919894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1211298919894 : ¬ IsSelfInterpreter e1211298919894 :=
  wSource (t := t_e1211298919894) (replay_sound (ps := []) (t := e1211298919894) (by decide)) (by decide)
def e1211298919898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211298919898 : Closed e1211298919898 ∧ code e1211298919898 = 5609345431002 := by decide
private def t_e1211298919898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1211298919898 : ¬ IsSelfInterpreter e1211298919898 :=
  wSource (t := t_e1211298919898) (replay_sound (ps := []) (t := e1211298919898) (by decide)) (by decide)
def e1211298920110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211298920110 : Closed e1211298920110 ∧ code e1211298920110 = 5609345431214 := by decide
theorem cert_e1211298920110 : check e1211298920110 [[],[],[.under],[.under,.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298920122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211298920122 : Closed e1211298920122 ∧ code e1211298920122 = 5609345431226 := by decide
theorem cert_e1211298920122 : check e1211298920122 [[],[],[.under],[.under,.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298920170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211298920170 : Closed e1211298920170 ∧ code e1211298920170 = 5609345431274 := by decide
theorem cert_e1211298920170 : check e1211298920170 [[],[],[.under],[.under,.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298920278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211298920278 : Closed e1211298920278 ∧ code e1211298920278 = 5609345431382 := by decide
private def t_e1211298920278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1211298920278 : ¬ IsSelfInterpreter e1211298920278 :=
  wSource (t := t_e1211298920278) (replay_sound (ps := []) (t := e1211298920278) (by decide)) (by decide)
def e1211298920282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211298920282 : Closed e1211298920282 ∧ code e1211298920282 = 5609345431386 := by decide
private def t_e1211298920282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1211298920282 : ¬ IsSelfInterpreter e1211298920282 :=
  wSource (t := t_e1211298920282) (replay_sound (ps := []) (t := e1211298920282) (by decide)) (by decide)
def e1211298920298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211298920298 : Closed e1211298920298 ∧ code e1211298920298 = 5609345431402 := by decide
private def t_e1211298920298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e1211298920298 : ¬ IsSelfInterpreter e1211298920298 :=
  wSource (t := t_e1211298920298) (replay_sound (ps := []) (t := e1211298920298) (by decide)) (by decide)
def e1211298921134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211298921134 : Closed e1211298921134 ∧ code e1211298921134 = 5609345432238 := by decide
theorem cert_e1211298921134 : check e1211298921134 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298921146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211298921146 : Closed e1211298921146 ∧ code e1211298921146 = 5609345432250 := by decide
theorem cert_e1211298921146 : check e1211298921146 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298921194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211298921194 : Closed e1211298921194 ∧ code e1211298921194 = 5609345432298 := by decide
theorem cert_e1211298921194 : check e1211298921194 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298921386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211298921386 : Closed e1211298921386 ∧ code e1211298921386 = 5609345432490 := by decide
theorem cert_e1211298921386 : check e1211298921386 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298921814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211298921814 : Closed e1211298921814 ∧ code e1211298921814 = 5609345432918 := by decide
private def t_e1211298921814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1211298921814 : ¬ IsSelfInterpreter e1211298921814 :=
  wSource (t := t_e1211298921814) (replay_sound (ps := []) (t := e1211298921814) (by decide)) (by decide)
def e1211298921818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211298921818 : Closed e1211298921818 ∧ code e1211298921818 = 5609345432922 := by decide
private def t_e1211298921818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1211298921818 : ¬ IsSelfInterpreter e1211298921818 :=
  wSource (t := t_e1211298921818) (replay_sound (ps := []) (t := e1211298921818) (by decide)) (by decide)
def e1211298921834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211298921834 : Closed e1211298921834 ∧ code e1211298921834 = 5609345432938 := by decide
private def t_e1211298921834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e1211298921834 : ¬ IsSelfInterpreter e1211298921834 :=
  wSource (t := t_e1211298921834) (replay_sound (ps := []) (t := e1211298921834) (by decide)) (by decide)
def e1211298921898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211298921898 : Closed e1211298921898 ∧ code e1211298921898 = 5609345433002 := by decide
theorem cert_e1211298921898 : check e1211298921898 [[],[],[.under],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298922862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211298922862 : Closed e1211298922862 ∧ code e1211298922862 = 5609345433966 := by decide
theorem cert_e1211298922862 : check e1211298922862 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211298922870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211298922870 : Closed e1211298922870 ∧ code e1211298922870 = 5609345433974 := by decide
theorem cert_e1211298922870 : checkPay e1211298922870 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211298924398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211298924398 : Closed e1211298924398 ∧ code e1211298924398 = 5609345435502 := by decide
theorem cert_e1211298924398 : check e1211298924398 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298924406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211298924406 : Closed e1211298924406 ∧ code e1211298924406 = 5609345435510 := by decide
theorem cert_e1211298924406 : check e1211298924406 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298924470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211298924470 : Closed e1211298924470 ∧ code e1211298924470 = 5609345435574 := by decide
theorem cert_e1211298924470 : check e1211298924470 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211298925934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211298925934 : Closed e1211298925934 ∧ code e1211298925934 = 5609345437038 := by decide
private def t_e1211298925934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem cert_e1211298925934 : ¬ IsSelfInterpreter e1211298925934 :=
  wSource (t := t_e1211298925934) (replay_sound (ps := []) (t := e1211298925934) (by decide)) (by decide)
def e1211298925942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211298925942 : Closed e1211298925942 ∧ code e1211298925942 = 5609345437046 := by decide
private def t_e1211298925942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem cert_e1211298925942 : ¬ IsSelfInterpreter e1211298925942 :=
  wSource (t := t_e1211298925942) (replay_sound (ps := []) (t := e1211298925942) (by decide)) (by decide)
def e1211298925998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211298925998 : Closed e1211298925998 ∧ code e1211298925998 = 5609345437102 := by decide
theorem cert_e1211298925998 : check e1211298925998 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298926010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211298926010 : Closed e1211298926010 ∧ code e1211298926010 = 5609345437114 := by decide
theorem cert_e1211298926010 : check e1211298926010 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298926038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211298926038 : Closed e1211298926038 ∧ code e1211298926038 = 5609345437142 := by decide
private def t_e1211298926038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem cert_e1211298926038 : ¬ IsSelfInterpreter e1211298926038 :=
  wSource (t := t_e1211298926038) (replay_sound (ps := []) (t := e1211298926038) (by decide)) (by decide)
def e1211298926042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211298926042 : Closed e1211298926042 ∧ code e1211298926042 = 5609345437146 := by decide
private def t_e1211298926042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem cert_e1211298926042 : ¬ IsSelfInterpreter e1211298926042 :=
  wSource (t := t_e1211298926042) (replay_sound (ps := []) (t := e1211298926042) (by decide)) (by decide)
def e1211298926254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211298926254 : Closed e1211298926254 ∧ code e1211298926254 = 5609345437358 := by decide
theorem cert_e1211298926254 : check e1211298926254 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298926266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211298926266 : Closed e1211298926266 ∧ code e1211298926266 = 5609345437370 := by decide
theorem cert_e1211298926266 : check e1211298926266 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298926314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211298926314 : Closed e1211298926314 ∧ code e1211298926314 = 5609345437418 := by decide
theorem cert_e1211298926314 : check e1211298926314 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298926422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211298926422 : Closed e1211298926422 ∧ code e1211298926422 = 5609345437526 := by decide
private def t_e1211298926422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem cert_e1211298926422 : ¬ IsSelfInterpreter e1211298926422 :=
  wSource (t := t_e1211298926422) (replay_sound (ps := []) (t := e1211298926422) (by decide)) (by decide)
def e1211298926426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211298926426 : Closed e1211298926426 ∧ code e1211298926426 = 5609345437530 := by decide
private def t_e1211298926426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem cert_e1211298926426 : ¬ IsSelfInterpreter e1211298926426 :=
  wSource (t := t_e1211298926426) (replay_sound (ps := []) (t := e1211298926426) (by decide)) (by decide)
def e1211298926442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211298926442 : Closed e1211298926442 ∧ code e1211298926442 = 5609345437546 := by decide
theorem cert_e1211298926442 : check e1211298926442 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298927470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211298927470 : Closed e1211298927470 ∧ code e1211298927470 = 5609345438574 := by decide
private def t_e1211298927470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem cert_e1211298927470 : ¬ IsSelfInterpreter e1211298927470 :=
  wSource (t := t_e1211298927470) (replay_sound (ps := []) (t := e1211298927470) (by decide)) (by decide)
def e1211298927478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211298927478 : Closed e1211298927478 ∧ code e1211298927478 = 5609345438582 := by decide
private def t_e1211298927478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e1211298927478 : ¬ IsSelfInterpreter e1211298927478 :=
  wSource (t := t_e1211298927478) (replay_sound (ps := []) (t := e1211298927478) (by decide)) (by decide)
def e1211298927534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211298927534 : Closed e1211298927534 ∧ code e1211298927534 = 5609345438638 := by decide
private def t_e1211298927534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem cert_e1211298927534 : ¬ IsSelfInterpreter e1211298927534 :=
  wSource (t := t_e1211298927534) (replay_sound (ps := []) (t := e1211298927534) (by decide)) (by decide)
def e1211298927546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211298927546 : Closed e1211298927546 ∧ code e1211298927546 = 5609345438650 := by decide
private def t_e1211298927546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e1211298927546 : ¬ IsSelfInterpreter e1211298927546 :=
  wSource (t := t_e1211298927546) (replay_sound (ps := []) (t := e1211298927546) (by decide)) (by decide)
def e1211298927574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211298927574 : Closed e1211298927574 ∧ code e1211298927574 = 5609345438678 := by decide
private def t_e1211298927574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e1211298927574 : ¬ IsSelfInterpreter e1211298927574 :=
  wSource (t := t_e1211298927574) (replay_sound (ps := []) (t := e1211298927574) (by decide)) (by decide)
def e1211298927578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211298927578 : Closed e1211298927578 ∧ code e1211298927578 = 5609345438682 := by decide
private def t_e1211298927578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e1211298927578 : ¬ IsSelfInterpreter e1211298927578 :=
  wSource (t := t_e1211298927578) (replay_sound (ps := []) (t := e1211298927578) (by decide)) (by decide)
def e1211298927854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211298927854 : Closed e1211298927854 ∧ code e1211298927854 = 5609345438958 := by decide
private def t_e1211298927854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e1211298927854 : ¬ IsSelfInterpreter e1211298927854 :=
  wSource (t := t_e1211298927854) (replay_sound (ps := []) (t := e1211298927854) (by decide)) (by decide)
def e1211298927862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211298927862 : Closed e1211298927862 ∧ code e1211298927862 = 5609345438966 := by decide
private def t_e1211298927862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e1211298927862 : ¬ IsSelfInterpreter e1211298927862 :=
  wSource (t := t_e1211298927862) (replay_sound (ps := []) (t := e1211298927862) (by decide)) (by decide)
def e1211298928238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298928238 : Closed e1211298928238 ∧ code e1211298928238 = 5609345439342 := by decide
private def t_e1211298928238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e1211298928238 : ¬ IsSelfInterpreter e1211298928238 :=
  wSource (t := t_e1211298928238) (replay_sound (ps := []) (t := e1211298928238) (by decide)) (by decide)
def e1211298928250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298928250 : Closed e1211298928250 ∧ code e1211298928250 = 5609345439354 := by decide
private def t_e1211298928250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e1211298928250 : ¬ IsSelfInterpreter e1211298928250 :=
  wSource (t := t_e1211298928250) (replay_sound (ps := []) (t := e1211298928250) (by decide)) (by decide)
def e1211298928438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298928438 : Closed e1211298928438 ∧ code e1211298928438 = 5609345439542 := by decide
private def t_e1211298928438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298928438 : ¬ IsSelfInterpreter e1211298928438 :=
  wSource (t := t_e1211298928438) (replay_sound (ps := []) (t := e1211298928438) (by decide)) (by decide)
def e1211298928442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298928442 : Closed e1211298928442 ∧ code e1211298928442 = 5609345439546 := by decide
private def t_e1211298928442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298928442 : ¬ IsSelfInterpreter e1211298928442 :=
  wSource (t := t_e1211298928442) (replay_sound (ps := []) (t := e1211298928442) (by decide)) (by decide)
def e1211298928686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211298928686 : Closed e1211298928686 ∧ code e1211298928686 = 5609345439790 := by decide
theorem cert_e1211298928686 : check e1211298928686 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298928878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211298928878 : Closed e1211298928878 ∧ code e1211298928878 = 5609345439982 := by decide
theorem cert_e1211298928878 : check e1211298928878 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298928886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211298928886 : Closed e1211298928886 ∧ code e1211298928886 = 5609345439990 := by decide
theorem cert_e1211298928886 : check e1211298928886 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211298929070 : Closed e1211298929070 ∧ code e1211298929070 = 5609345440174 := by decide
theorem cert_e1211298929070 : check e1211298929070 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211298929082 : Closed e1211298929082 ∧ code e1211298929082 = 5609345440186 := by decide
theorem cert_e1211298929082 : check e1211298929082 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211298929130 : Closed e1211298929130 ∧ code e1211298929130 = 5609345440234 := by decide
theorem cert_e1211298929130 : check e1211298929130 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298929262 : Closed e1211298929262 ∧ code e1211298929262 = 5609345440366 := by decide
theorem cert_e1211298929262 : check e1211298929262 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298929274 : Closed e1211298929274 ∧ code e1211298929274 = 5609345440378 := by decide
theorem cert_e1211298929274 : check e1211298929274 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211298929438 : Closed e1211298929438 ∧ code e1211298929438 = 5609345440542 := by decide
theorem cert_e1211298929438 : check e1211298929438 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298929538 : Closed e1211298929538 ∧ code e1211298929538 = 5609345440642 := by decide
theorem cert_e1211298929538 : check e1211298929538 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211298929550 : Closed e1211298929550 ∧ code e1211298929550 = 5609345440654 := by decide
theorem cert_e1211298929550 : check e1211298929550 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298929562 : Closed e1211298929562 ∧ code e1211298929562 = 5609345440666 := by decide
theorem cert_e1211298929562 : check e1211298929562 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298929686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211298929686 : Closed e1211298929686 ∧ code e1211298929686 = 5609345440790 := by decide
private def t_e1211298929686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem cert_e1211298929686 : ¬ IsSelfInterpreter e1211298929686 :=
  wSource (t := t_e1211298929686) (replay_sound (ps := []) (t := e1211298929686) (by decide)) (by decide)
def e1211298929782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211298929782 : Closed e1211298929782 ∧ code e1211298929782 = 5609345440886 := by decide
private def t_e1211298929782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem cert_e1211298929782 : ¬ IsSelfInterpreter e1211298929782 :=
  wSource (t := t_e1211298929782) (replay_sound (ps := []) (t := e1211298929782) (by decide)) (by decide)
def e1211298929878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211298929878 : Closed e1211298929878 ∧ code e1211298929878 = 5609345440982 := by decide
private def t_e1211298929878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1211298929878 : ¬ IsSelfInterpreter e1211298929878 :=
  wSource (t := t_e1211298929878) (replay_sound (ps := []) (t := e1211298929878) (by decide)) (by decide)
def e1211298929882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211298929882 : Closed e1211298929882 ∧ code e1211298929882 = 5609345440986 := by decide
private def t_e1211298929882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e1211298929882 : ¬ IsSelfInterpreter e1211298929882 :=
  wSource (t := t_e1211298929882) (replay_sound (ps := []) (t := e1211298929882) (by decide)) (by decide)
def e1211298929898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211298929898 : Closed e1211298929898 ∧ code e1211298929898 = 5609345441002 := by decide
private def t_e1211298929898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e1211298929898 : ¬ IsSelfInterpreter e1211298929898 :=
  wSource (t := t_e1211298929898) (replay_sound (ps := []) (t := e1211298929898) (by decide)) (by decide)
def e1211298929974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298929974 : Closed e1211298929974 ∧ code e1211298929974 = 5609345441078 := by decide
private def t_e1211298929974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298929974 : ¬ IsSelfInterpreter e1211298929974 :=
  wSource (t := t_e1211298929974) (replay_sound (ps := []) (t := e1211298929974) (by decide)) (by decide)
def e1211298929978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298929978 : Closed e1211298929978 ∧ code e1211298929978 = 5609345441082 := by decide
private def t_e1211298929978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298929978 : ¬ IsSelfInterpreter e1211298929978 :=
  wSource (t := t_e1211298929978) (replay_sound (ps := []) (t := e1211298929978) (by decide)) (by decide)
def e1211298930050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298930050 : Closed e1211298930050 ∧ code e1211298930050 = 5609345441154 := by decide
private def t_e1211298930050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem cert_e1211298930050 : ¬ IsSelfInterpreter e1211298930050 :=
  wSource (t := t_e1211298930050) (replay_sound (ps := []) (t := e1211298930050) (by decide)) (by decide)
def e1211298930062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211298930062 : Closed e1211298930062 ∧ code e1211298930062 = 5609345441166 := by decide
private def t_e1211298930062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem cert_e1211298930062 : ¬ IsSelfInterpreter e1211298930062 :=
  wSource (t := t_e1211298930062) (replay_sound (ps := []) (t := e1211298930062) (by decide)) (by decide)
def e1211298930074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298930074 : Closed e1211298930074 ∧ code e1211298930074 = 5609345441178 := by decide
private def t_e1211298930074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e1211298930074 : ¬ IsSelfInterpreter e1211298930074 :=
  wSource (t := t_e1211298930074) (replay_sound (ps := []) (t := e1211298930074) (by decide)) (by decide)
def e1211298930862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e1211298930862 : Closed e1211298930862 ∧ code e1211298930862 = 5609345441966 := by decide
theorem cert_e1211298930862 : check e1211298930862 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298930874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e1211298930874 : Closed e1211298930874 ∧ code e1211298930874 = 5609345441978 := by decide
theorem cert_e1211298930874 : check e1211298930874 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211298931566 : Closed e1211298931566 ∧ code e1211298931566 = 5609345442670 := by decide
theorem cert_e1211298931566 : check e1211298931566 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211298931574 : Closed e1211298931574 ∧ code e1211298931574 = 5609345442678 := by decide
theorem cert_e1211298931574 : check e1211298931574 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211298931630 : Closed e1211298931630 ∧ code e1211298931630 = 5609345442734 := by decide
theorem cert_e1211298931630 : check e1211298931630 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211298931642 : Closed e1211298931642 ∧ code e1211298931642 = 5609345442746 := by decide
theorem cert_e1211298931642 : check e1211298931642 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211298931670 : Closed e1211298931670 ∧ code e1211298931670 = 5609345442774 := by decide
theorem cert_e1211298931670 : check e1211298931670 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298931674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211298931674 : Closed e1211298931674 ∧ code e1211298931674 = 5609345442778 := by decide
theorem cert_e1211298931674 : check e1211298931674 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211298932398 : Closed e1211298932398 ∧ code e1211298932398 = 5609345443502 := by decide
theorem cert_e1211298932398 : check e1211298932398 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211298932410 : Closed e1211298932410 ∧ code e1211298932410 = 5609345443514 := by decide
theorem cert_e1211298932410 : check e1211298932410 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211298932458 : Closed e1211298932458 ∧ code e1211298932458 = 5609345443562 := by decide
theorem cert_e1211298932458 : check e1211298932458 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211298932650 : Closed e1211298932650 ∧ code e1211298932650 = 5609345443754 := by decide
theorem cert_e1211298932650 : check e1211298932650 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211298932782 : Closed e1211298932782 ∧ code e1211298932782 = 5609345443886 := by decide
theorem cert_e1211298932782 : check e1211298932782 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211298932974 : Closed e1211298932974 ∧ code e1211298932974 = 5609345444078 := by decide
theorem cert_e1211298932974 : check e1211298932974 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298932982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211298932982 : Closed e1211298932982 ∧ code e1211298932982 = 5609345444086 := by decide
theorem cert_e1211298932982 : check e1211298932982 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
end Blc.Floor42
