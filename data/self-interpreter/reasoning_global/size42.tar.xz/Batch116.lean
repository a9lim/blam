import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205824851566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205824851566 : Closed e1205824851566 ∧ code e1205824851566 = 5603871362670 := by decide
theorem cert_e1205824851566 : check e1205824851566 [[],[]] .smaller = true := by decide
def e1205824851578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205824851578 : Closed e1205824851578 ∧ code e1205824851578 = 5603871362682 := by decide
theorem cert_e1205824851578 : check e1205824851578 [[],[]] .smaller = true := by decide
def e1205824851766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205824851766 : Closed e1205824851766 ∧ code e1205824851766 = 5603871362870 := by decide
theorem cert_e1205824851766 : check e1205824851766 [[],[]] .smaller = true := by decide
def e1205824851770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205824851770 : Closed e1205824851770 ∧ code e1205824851770 = 5603871362874 := by decide
theorem cert_e1205824851770 : check e1205824851770 [[],[]] .smaller = true := by decide
def e1205824859694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205824859694 : Closed e1205824859694 ∧ code e1205824859694 = 5603871370798 := by decide
theorem cert_e1205824859694 : check e1205824859694 [[],[]] .chain = true := by decide
def e1205824859874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205824859874 : Closed e1205824859874 ∧ code e1205824859874 = 5603871370978 := by decide
theorem cert_e1205824859874 : check e1205824859874 [[],[]] .chain = true := by decide
def e1205824859886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1205824859886 : Closed e1205824859886 ∧ code e1205824859886 = 5603871370990 := by decide
theorem cert_e1205824859886 : check e1205824859886 [[],[]] .sourceHead = true := by decide
def e1205824859926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205824859926 : Closed e1205824859926 ∧ code e1205824859926 = 5603871371030 := by decide
theorem cert_e1205824859926 : check e1205824859926 [[],[]] .chain = true := by decide
def e1205824860002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205824860002 : Closed e1205824860002 ∧ code e1205824860002 = 5603871371106 := by decide
theorem cert_e1205824860002 : check e1205824860002 [[],[]] .chain = true := by decide
def e1205824860014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1205824860014 : Closed e1205824860014 ∧ code e1205824860014 = 5603871371118 := by decide
theorem cert_e1205824860014 : check e1205824860014 [[],[]] .sourceHead = true := by decide
def e1205824860022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1205824860022 : Closed e1205824860022 ∧ code e1205824860022 = 5603871371126 := by decide
theorem cert_e1205824860022 : check e1205824860022 [[],[]] .sourceHead = true := by decide
def e1205824862270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e1205824862270 : Closed e1205824862270 ∧ code e1205824862270 = 5603871373374 := by decide
theorem cert_e1205824862270 : check e1205824862270 [[],[]] .chain = true := by decide
def e1205824862690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205824862690 : Closed e1205824862690 ∧ code e1205824862690 = 5603871373794 := by decide
theorem cert_e1205824862690 : check e1205824862690 [[],[]] .chain = true := by decide
def e1205824862702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205824862702 : Closed e1205824862702 ∧ code e1205824862702 = 5603871373806 := by decide
theorem cert_e1205824862702 : check e1205824862702 [[],[]] .sourceHead = true := by decide
def e1205824863262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e1205824863262 : Closed e1205824863262 ∧ code e1205824863262 = 5603871374366 := by decide
theorem cert_e1205824863262 : check e1205824863262 [[],[]] .chain = true := by decide
def e1205824863458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205824863458 : Closed e1205824863458 ∧ code e1205824863458 = 5603871374562 := by decide
theorem cert_e1205824863458 : check e1205824863458 [[],[]] .chain = true := by decide
def e1205824863470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205824863470 : Closed e1205824863470 ∧ code e1205824863470 = 5603871374574 := by decide
theorem cert_e1205824863470 : check e1205824863470 [[],[]] .sourceHead = true := by decide
def e1205824863478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205824863478 : Closed e1205824863478 ∧ code e1205824863478 = 5603871374582 := by decide
theorem cert_e1205824863478 : check e1205824863478 [[],[]] .sourceHead = true := by decide
def e1205824886318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205824886318 : Closed e1205824886318 ∧ code e1205824886318 = 5603871397422 := by decide
theorem cert_e1205824886318 : check e1205824886318 [[],[]] .chain = true := by decide
def e1205824886498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205824886498 : Closed e1205824886498 ∧ code e1205824886498 = 5603871397602 := by decide
theorem cert_e1205824886498 : check e1205824886498 [[],[]] .chain = true := by decide
def e1205824886510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1205824886510 : Closed e1205824886510 ∧ code e1205824886510 = 5603871397614 := by decide
theorem cert_e1205824886510 : check e1205824886510 [[],[]] .sourceHead = true := by decide
def e1205824886666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205824886666 : Closed e1205824886666 ∧ code e1205824886666 = 5603871397770 := by decide
theorem cert_e1205824886666 : check e1205824886666 [[],[]] .chain = true := by decide
def e1205824886690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205824886690 : Closed e1205824886690 ∧ code e1205824886690 = 5603871397794 := by decide
theorem cert_e1205824886690 : check e1205824886690 [[],[]] .chain = true := by decide
def e1205824886702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1205824886702 : Closed e1205824886702 ∧ code e1205824886702 = 5603871397806 := by decide
theorem cert_e1205824886702 : check e1205824886702 [[],[]] .sourceHead = true := by decide
def e1205824886714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1205824886714 : Closed e1205824886714 ∧ code e1205824886714 = 5603871397818 := by decide
theorem cert_e1205824886714 : check e1205824886714 [[],[]] .sourceHead = true := by decide
def e1205824886846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e1205824886846 : Closed e1205824886846 ∧ code e1205824886846 = 5603871397950 := by decide
theorem cert_e1205824886846 : check e1205824886846 [[],[]] .chain = true := by decide
def e1205824887266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205824887266 : Closed e1205824887266 ∧ code e1205824887266 = 5603871398370 := by decide
theorem cert_e1205824887266 : check e1205824887266 [[],[]] .chain = true := by decide
def e1205824887278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205824887278 : Closed e1205824887278 ∧ code e1205824887278 = 5603871398382 := by decide
theorem cert_e1205824887278 : check e1205824887278 [[],[]] .sourceHead = true := by decide
def e1205824888334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e1205824888334 : Closed e1205824888334 ∧ code e1205824888334 = 5603871399438 := by decide
theorem cert_e1205824888334 : check e1205824888334 [[],[]] .chain = true := by decide
def e1205824888418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205824888418 : Closed e1205824888418 ∧ code e1205824888418 = 5603871399522 := by decide
theorem cert_e1205824888418 : check e1205824888418 [[],[]] .chain = true := by decide
def e1205824888430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205824888430 : Closed e1205824888430 ∧ code e1205824888430 = 5603871399534 := by decide
theorem cert_e1205824888430 : check e1205824888430 [[],[]] .sourceHead = true := by decide
def e1205824888442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205824888442 : Closed e1205824888442 ∧ code e1205824888442 = 5603871399546 := by decide
theorem cert_e1205824888442 : check e1205824888442 [[],[]] .sourceHead = true := by decide
def e1205824899862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205824899862 : Closed e1205824899862 ∧ code e1205824899862 = 5603871410966 := by decide
theorem cert_e1205824899862 : check e1205824899862 [[],[]] .chain = true := by decide
def e1205824899938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205824899938 : Closed e1205824899938 ∧ code e1205824899938 = 5603871411042 := by decide
theorem cert_e1205824899938 : check e1205824899938 [[],[]] .chain = true := by decide
def e1205824899950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205824899950 : Closed e1205824899950 ∧ code e1205824899950 = 5603871411054 := by decide
theorem cert_e1205824899950 : check e1205824899950 [[],[]] .sourceHead = true := by decide
def e1205824899958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205824899958 : Closed e1205824899958 ∧ code e1205824899958 = 5603871411062 := by decide
theorem cert_e1205824899958 : check e1205824899958 [[],[]] .sourceHead = true := by decide
def e1205824899978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205824899978 : Closed e1205824899978 ∧ code e1205824899978 = 5603871411082 := by decide
theorem cert_e1205824899978 : check e1205824899978 [[],[]] .chain = true := by decide
def e1205824900002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205824900002 : Closed e1205824900002 ∧ code e1205824900002 = 5603871411106 := by decide
theorem cert_e1205824900002 : check e1205824900002 [[],[]] .chain = true := by decide
def e1205824900014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205824900014 : Closed e1205824900014 ∧ code e1205824900014 = 5603871411118 := by decide
theorem cert_e1205824900014 : check e1205824900014 [[],[]] .sourceHead = true := by decide
def e1205824900026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205824900026 : Closed e1205824900026 ∧ code e1205824900026 = 5603871411130 := by decide
theorem cert_e1205824900026 : check e1205824900026 [[],[]] .sourceHead = true := by decide
def e1205824900054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205824900054 : Closed e1205824900054 ∧ code e1205824900054 = 5603871411158 := by decide
theorem cert_e1205824900054 : check e1205824900054 [[],[]] .sourceHead = true := by decide
def e1205824900058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205824900058 : Closed e1205824900058 ∧ code e1205824900058 = 5603871411162 := by decide
theorem cert_e1205824900058 : check e1205824900058 [[],[]] .sourceHead = true := by decide
def e1205824900126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1205824900126 : Closed e1205824900126 ∧ code e1205824900126 = 5603871411230 := by decide
theorem cert_e1205824900126 : check e1205824900126 [[],[]] .chain = true := by decide
def e1205824900322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205824900322 : Closed e1205824900322 ∧ code e1205824900322 = 5603871411426 := by decide
theorem cert_e1205824900322 : check e1205824900322 [[],[]] .chain = true := by decide
def e1205824900334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205824900334 : Closed e1205824900334 ∧ code e1205824900334 = 5603871411438 := by decide
theorem cert_e1205824900334 : check e1205824900334 [[],[]] .sourceHead = true := by decide
def e1205824900342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205824900342 : Closed e1205824900342 ∧ code e1205824900342 = 5603871411446 := by decide
theorem cert_e1205824900342 : check e1205824900342 [[],[]] .sourceHead = true := by decide
def e1205824900622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1205824900622 : Closed e1205824900622 ∧ code e1205824900622 = 5603871411726 := by decide
theorem cert_e1205824900622 : check e1205824900622 [[],[]] .chain = true := by decide
def e1205824900706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205824900706 : Closed e1205824900706 ∧ code e1205824900706 = 5603871411810 := by decide
theorem cert_e1205824900706 : check e1205824900706 [[],[]] .chain = true := by decide
def e1205824900718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205824900718 : Closed e1205824900718 ∧ code e1205824900718 = 5603871411822 := by decide
theorem cert_e1205824900718 : check e1205824900718 [[],[]] .sourceHead = true := by decide
def e1205824900730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205824900730 : Closed e1205824900730 ∧ code e1205824900730 = 5603871411834 := by decide
theorem cert_e1205824900730 : check e1205824900730 [[],[]] .sourceHead = true := by decide
def e1205824900918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205824900918 : Closed e1205824900918 ∧ code e1205824900918 = 5603871412022 := by decide
theorem cert_e1205824900918 : check e1205824900918 [[],[]] .sourceHead = true := by decide
def e1205824900922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205824900922 : Closed e1205824900922 ∧ code e1205824900922 = 5603871412026 := by decide
theorem cert_e1205824900922 : check e1205824900922 [[],[]] .sourceHead = true := by decide
def e1205825440622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205825440622 : Closed e1205825440622 ∧ code e1205825440622 = 5603871951726 := by decide
theorem cert_e1205825440622 : check e1205825440622 [[],[]] .smaller = true := by decide
def e1205825440630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205825440630 : Closed e1205825440630 ∧ code e1205825440630 = 5603871951734 := by decide
theorem cert_e1205825440630 : check e1205825440630 [[],[]] .smaller = true := by decide
def e1205825440686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205825440686 : Closed e1205825440686 ∧ code e1205825440686 = 5603871951790 := by decide
theorem cert_e1205825440686 : check e1205825440686 [[],[]] .smaller = true := by decide
def e1205825440698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205825440698 : Closed e1205825440698 ∧ code e1205825440698 = 5603871951802 := by decide
theorem cert_e1205825440698 : check e1205825440698 [[],[]] .smaller = true := by decide
def e1205825440726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205825440726 : Closed e1205825440726 ∧ code e1205825440726 = 5603871951830 := by decide
theorem cert_e1205825440726 : check e1205825440726 [[],[]] .smaller = true := by decide
def e1205825440730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205825440730 : Closed e1205825440730 ∧ code e1205825440730 = 5603871951834 := by decide
theorem cert_e1205825440730 : check e1205825440730 [[],[]] .smaller = true := by decide
def e1205825441006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205825441006 : Closed e1205825441006 ∧ code e1205825441006 = 5603871952110 := by decide
theorem cert_e1205825441006 : check e1205825441006 [[],[]] .smaller = true := by decide
def e1205825441014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205825441014 : Closed e1205825441014 ∧ code e1205825441014 = 5603871952118 := by decide
theorem cert_e1205825441014 : check e1205825441014 [[],[]] .smaller = true := by decide
def e1205825441390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205825441390 : Closed e1205825441390 ∧ code e1205825441390 = 5603871952494 := by decide
theorem cert_e1205825441390 : check e1205825441390 [[],[]] .smaller = true := by decide
def e1205825441402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205825441402 : Closed e1205825441402 ∧ code e1205825441402 = 5603871952506 := by decide
theorem cert_e1205825441402 : check e1205825441402 [[],[]] .smaller = true := by decide
def e1205825441590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205825441590 : Closed e1205825441590 ∧ code e1205825441590 = 5603871952694 := by decide
theorem cert_e1205825441590 : check e1205825441590 [[],[]] .smaller = true := by decide
def e1205825441594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205825441594 : Closed e1205825441594 ∧ code e1205825441594 = 5603871952698 := by decide
theorem cert_e1205825441594 : check e1205825441594 [[],[]] .smaller = true := by decide
def e1205826772446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1205826772446 : Closed e1205826772446 ∧ code e1205826772446 = 5603873283550 := by decide
theorem cert_e1205826772446 : check e1205826772446 [[],[],[.under]] .smaller = true := by decide
def e1205826772462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1205826772462 : Closed e1205826772462 ∧ code e1205826772462 = 5603873283566 := by decide
theorem cert_e1205826772462 : check e1205826772462 [[],[],[.under]] .smaller = true := by decide
def e1205826772702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1205826772702 : Closed e1205826772702 ∧ code e1205826772702 = 5603873283806 := by decide
theorem cert_e1205826772702 : check e1205826772702 [[],[],[.under]] .smaller = true := by decide
def e1205826772726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1205826772726 : Closed e1205826772726 ∧ code e1205826772726 = 5603873283830 := by decide
theorem cert_e1205826772726 : check e1205826772726 [[],[],[.under]] .smaller = true := by decide
def e1205826772846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1205826772846 : Closed e1205826772846 ∧ code e1205826772846 = 5603873283950 := by decide
theorem cert_e1205826772846 : check e1205826772846 [[],[],[.under]] .smaller = true := by decide
def e1205826772854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1205826772854 : Closed e1205826772854 ∧ code e1205826772854 = 5603873283958 := by decide
theorem cert_e1205826772854 : check e1205826772854 [[],[],[.under]] .smaller = true := by decide
def e1205826778078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205826778078 : Closed e1205826778078 ∧ code e1205826778078 = 5603873289182 := by decide
theorem cert_e1205826778078 : check e1205826778078 [[],[],[.under]] .smaller = true := by decide
def e1205826778094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205826778094 : Closed e1205826778094 ∧ code e1205826778094 = 5603873289198 := by decide
theorem cert_e1205826778094 : check e1205826778094 [[],[],[.under]] .smaller = true := by decide
def e1205826779614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205826779614 : Closed e1205826779614 ∧ code e1205826779614 = 5603873290718 := by decide
theorem cert_e1205826779614 : check e1205826779614 [[],[],[.under]] .smaller = true := by decide
def e1205826779638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205826779638 : Closed e1205826779638 ∧ code e1205826779638 = 5603873290742 := by decide
theorem cert_e1205826779638 : check e1205826779638 [[],[],[.under]] .smaller = true := by decide
def e1205826780398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205826780398 : Closed e1205826780398 ∧ code e1205826780398 = 5603873291502 := by decide
theorem cert_e1205826780398 : check e1205826780398 [[],[],[.under]] .smaller = true := by decide
def e1205826780406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205826780406 : Closed e1205826780406 ∧ code e1205826780406 = 5603873291510 := by decide
theorem cert_e1205826780406 : check e1205826780406 [[],[],[.under]] .smaller = true := by decide
def e1205826837358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1205826837358 : Closed e1205826837358 ∧ code e1205826837358 = 5603873348462 := by decide
theorem cert_e1205826837358 : check e1205826837358 [[],[],[.under]] .smaller = true := by decide
def e1205826837366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1205826837366 : Closed e1205826837366 ∧ code e1205826837366 = 5603873348470 := by decide
theorem cert_e1205826837366 : check e1205826837366 [[],[],[.under]] .smaller = true := by decide
def e1205826837430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1205826837430 : Closed e1205826837430 ∧ code e1205826837430 = 5603873348534 := by decide
theorem cert_e1205826837430 : check e1205826837430 [[],[],[.under]] .smaller = true := by decide
def e1205826837870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205826837870 : Closed e1205826837870 ∧ code e1205826837870 = 5603873348974 := by decide
theorem cert_e1205826837870 : check e1205826837870 [[],[],[.under]] .smaller = true := by decide
def e1205826837878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205826837878 : Closed e1205826837878 ∧ code e1205826837878 = 5603873348982 := by decide
theorem cert_e1205826837878 : check e1205826837878 [[],[],[.under]] .smaller = true := by decide
def e1205826837934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205826837934 : Closed e1205826837934 ∧ code e1205826837934 = 5603873349038 := by decide
theorem cert_e1205826837934 : check e1205826837934 [[],[],[.under]] .smaller = true := by decide
def e1205826837946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205826837946 : Closed e1205826837946 ∧ code e1205826837946 = 5603873349050 := by decide
theorem cert_e1205826837946 : check e1205826837946 [[],[],[.under]] .smaller = true := by decide
def e1205826837974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205826837974 : Closed e1205826837974 ∧ code e1205826837974 = 5603873349078 := by decide
theorem cert_e1205826837974 : check e1205826837974 [[],[],[.under]] .smaller = true := by decide
def e1205826837978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205826837978 : Closed e1205826837978 ∧ code e1205826837978 = 5603873349082 := by decide
theorem cert_e1205826837978 : check e1205826837978 [[],[],[.under]] .smaller = true := by decide
def e1205826838198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1205826838198 : Closed e1205826838198 ∧ code e1205826838198 = 5603873349302 := by decide
theorem cert_e1205826838198 : check e1205826838198 [[],[],[.under]] .smaller = true := by decide
def e1205826838230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1205826838230 : Closed e1205826838230 ∧ code e1205826838230 = 5603873349334 := by decide
theorem cert_e1205826838230 : check e1205826838230 [[],[],[.under]] .smaller = true := by decide
def e1205826838234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1205826838234 : Closed e1205826838234 ∧ code e1205826838234 = 5603873349338 := by decide
theorem cert_e1205826838234 : check e1205826838234 [[],[],[.under]] .smaller = true := by decide
def e1205826840430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1205826840430 : Closed e1205826840430 ∧ code e1205826840430 = 5603873351534 := by decide
theorem cert_e1205826840430 : check e1205826840430 [[],[],[.under]] .smaller = true := by decide
def e1205826840438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1205826840438 : Closed e1205826840438 ∧ code e1205826840438 = 5603873351542 := by decide
theorem cert_e1205826840438 : check e1205826840438 [[],[],[.under]] .smaller = true := by decide
def e1205826840502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1205826840502 : Closed e1205826840502 ∧ code e1205826840502 = 5603873351606 := by decide
theorem cert_e1205826840502 : check e1205826840502 [[],[],[.under]] .smaller = true := by decide
def e1205826841838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205826841838 : Closed e1205826841838 ∧ code e1205826841838 = 5603873352942 := by decide
theorem cert_e1205826841838 : check e1205826841838 [[],[],[.under]] .smaller = true := by decide
def e1205826841846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205826841846 : Closed e1205826841846 ∧ code e1205826841846 = 5603873352950 := by decide
theorem cert_e1205826841846 : check e1205826841846 [[],[],[.under]] .smaller = true := by decide
def e1205826842230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205826842230 : Closed e1205826842230 ∧ code e1205826842230 = 5603873353334 := by decide
theorem cert_e1205826842230 : check e1205826842230 [[],[],[.under]] .smaller = true := by decide
def e1205826843502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205826843502 : Closed e1205826843502 ∧ code e1205826843502 = 5603873354606 := by decide
theorem cert_e1205826843502 : check e1205826843502 [[],[],[.under]] .smaller = true := by decide
def e1205826843510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205826843510 : Closed e1205826843510 ∧ code e1205826843510 = 5603873354614 := by decide
theorem cert_e1205826843510 : check e1205826843510 [[],[],[.under]] .smaller = true := by decide
def e1205826843566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205826843566 : Closed e1205826843566 ∧ code e1205826843566 = 5603873354670 := by decide
theorem cert_e1205826843566 : check e1205826843566 [[],[],[.under]] .smaller = true := by decide
def e1205826843578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205826843578 : Closed e1205826843578 ∧ code e1205826843578 = 5603873354682 := by decide
theorem cert_e1205826843578 : check e1205826843578 [[],[],[.under]] .smaller = true := by decide
def e1205826843606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205826843606 : Closed e1205826843606 ∧ code e1205826843606 = 5603873354710 := by decide
theorem cert_e1205826843606 : check e1205826843606 [[],[],[.under]] .smaller = true := by decide
def e1205826843610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205826843610 : Closed e1205826843610 ∧ code e1205826843610 = 5603873354714 := by decide
theorem cert_e1205826843610 : check e1205826843610 [[],[],[.under]] .smaller = true := by decide
def e1205826843886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205826843886 : Closed e1205826843886 ∧ code e1205826843886 = 5603873354990 := by decide
theorem cert_e1205826843886 : check e1205826843886 [[],[],[.under]] .smaller = true := by decide
def e1205826843894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205826843894 : Closed e1205826843894 ∧ code e1205826843894 = 5603873354998 := by decide
theorem cert_e1205826843894 : check e1205826843894 [[],[],[.under]] .smaller = true := by decide
def e1205826844270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205826844270 : Closed e1205826844270 ∧ code e1205826844270 = 5603873355374 := by decide
theorem cert_e1205826844270 : check e1205826844270 [[],[],[.under]] .smaller = true := by decide
def e1205826844282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205826844282 : Closed e1205826844282 ∧ code e1205826844282 = 5603873355386 := by decide
theorem cert_e1205826844282 : check e1205826844282 [[],[],[.under]] .smaller = true := by decide
def e1205826844470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205826844470 : Closed e1205826844470 ∧ code e1205826844470 = 5603873355574 := by decide
theorem cert_e1205826844470 : check e1205826844470 [[],[],[.under]] .smaller = true := by decide
def e1205826844474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205826844474 : Closed e1205826844474 ∧ code e1205826844474 = 5603873355578 := by decide
theorem cert_e1205826844474 : check e1205826844474 [[],[],[.under]] .smaller = true := by decide
def e1205826845110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1205826845110 : Closed e1205826845110 ∧ code e1205826845110 = 5603873356214 := by decide
theorem cert_e1205826845110 : check e1205826845110 [[],[],[.under]] .smaller = true := by decide
def e1205826845142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1205826845142 : Closed e1205826845142 ∧ code e1205826845142 = 5603873356246 := by decide
theorem cert_e1205826845142 : check e1205826845142 [[],[],[.under]] .smaller = true := by decide
def e1205826845146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1205826845146 : Closed e1205826845146 ∧ code e1205826845146 = 5603873356250 := by decide
theorem cert_e1205826845146 : check e1205826845146 [[],[],[.under]] .smaller = true := by decide
def e1205826845302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205826845302 : Closed e1205826845302 ∧ code e1205826845302 = 5603873356406 := by decide
theorem cert_e1205826845302 : check e1205826845302 [[],[],[.under]] .smaller = true := by decide
def e1205826845494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205826845494 : Closed e1205826845494 ∧ code e1205826845494 = 5603873356598 := by decide
theorem cert_e1205826845494 : check e1205826845494 [[],[],[.under]] .smaller = true := by decide
def e1205826845498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205826845498 : Closed e1205826845498 ∧ code e1205826845498 = 5603873356602 := by decide
theorem cert_e1205826845498 : check e1205826845498 [[],[],[.under]] .smaller = true := by decide
def e1205826852718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1205826852718 : Closed e1205826852718 ∧ code e1205826852718 = 5603873363822 := by decide
theorem cert_e1205826852718 : check e1205826852718 [[],[],[.under]] .smaller = true := by decide
def e1205826852726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1205826852726 : Closed e1205826852726 ∧ code e1205826852726 = 5603873363830 := by decide
theorem cert_e1205826852726 : check e1205826852726 [[],[],[.under]] .smaller = true := by decide
def e1205826852790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1205826852790 : Closed e1205826852790 ∧ code e1205826852790 = 5603873363894 := by decide
theorem cert_e1205826852790 : check e1205826852790 [[],[],[.under]] .smaller = true := by decide
def e1205826854126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205826854126 : Closed e1205826854126 ∧ code e1205826854126 = 5603873365230 := by decide
theorem cert_e1205826854126 : check e1205826854126 [[],[],[.under]] .smaller = true := by decide
def e1205826854134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205826854134 : Closed e1205826854134 ∧ code e1205826854134 = 5603873365238 := by decide
theorem cert_e1205826854134 : check e1205826854134 [[],[],[.under]] .smaller = true := by decide
def e1205826854518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205826854518 : Closed e1205826854518 ∧ code e1205826854518 = 5603873365622 := by decide
theorem cert_e1205826854518 : check e1205826854518 [[],[],[.under]] .smaller = true := by decide
def e1205826866030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205826866030 : Closed e1205826866030 ∧ code e1205826866030 = 5603873377134 := by decide
theorem cert_e1205826866030 : check e1205826866030 [[],[],[.under]] .smaller = true := by decide
def e1205826866038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205826866038 : Closed e1205826866038 ∧ code e1205826866038 = 5603873377142 := by decide
theorem cert_e1205826866038 : check e1205826866038 [[],[],[.under]] .smaller = true := by decide
def e1205826866094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205826866094 : Closed e1205826866094 ∧ code e1205826866094 = 5603873377198 := by decide
theorem cert_e1205826866094 : check e1205826866094 [[],[],[.under]] .smaller = true := by decide
def e1205826866106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205826866106 : Closed e1205826866106 ∧ code e1205826866106 = 5603873377210 := by decide
theorem cert_e1205826866106 : check e1205826866106 [[],[],[.under]] .smaller = true := by decide
def e1205826866134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205826866134 : Closed e1205826866134 ∧ code e1205826866134 = 5603873377238 := by decide
theorem cert_e1205826866134 : check e1205826866134 [[],[],[.under]] .smaller = true := by decide
def e1205826866138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205826866138 : Closed e1205826866138 ∧ code e1205826866138 = 5603873377242 := by decide
theorem cert_e1205826866138 : check e1205826866138 [[],[],[.under]] .smaller = true := by decide
def e1205826866414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205826866414 : Closed e1205826866414 ∧ code e1205826866414 = 5603873377518 := by decide
theorem cert_e1205826866414 : check e1205826866414 [[],[],[.under]] .smaller = true := by decide
def e1205826866422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205826866422 : Closed e1205826866422 ∧ code e1205826866422 = 5603873377526 := by decide
theorem cert_e1205826866422 : check e1205826866422 [[],[],[.under]] .smaller = true := by decide
def e1205826866798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205826866798 : Closed e1205826866798 ∧ code e1205826866798 = 5603873377902 := by decide
theorem cert_e1205826866798 : check e1205826866798 [[],[],[.under]] .smaller = true := by decide
def e1205826866810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205826866810 : Closed e1205826866810 ∧ code e1205826866810 = 5603873377914 := by decide
theorem cert_e1205826866810 : check e1205826866810 [[],[],[.under]] .smaller = true := by decide
def e1205826866998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205826866998 : Closed e1205826866998 ∧ code e1205826866998 = 5603873378102 := by decide
theorem cert_e1205826866998 : check e1205826866998 [[],[],[.under]] .smaller = true := by decide
def e1205826867002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205826867002 : Closed e1205826867002 ∧ code e1205826867002 = 5603873378106 := by decide
theorem cert_e1205826867002 : check e1205826867002 [[],[],[.under]] .smaller = true := by decide
def e1205826872758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1205826872758 : Closed e1205826872758 ∧ code e1205826872758 = 5603873383862 := by decide
theorem cert_e1205826872758 : check e1205826872758 [[],[],[.under]] .smaller = true := by decide
def e1205826872790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1205826872790 : Closed e1205826872790 ∧ code e1205826872790 = 5603873383894 := by decide
theorem cert_e1205826872790 : check e1205826872790 [[],[],[.under]] .smaller = true := by decide
def e1205826872794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1205826872794 : Closed e1205826872794 ∧ code e1205826872794 = 5603873383898 := by decide
theorem cert_e1205826872794 : check e1205826872794 [[],[],[.under]] .smaller = true := by decide
def e1205826872950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205826872950 : Closed e1205826872950 ∧ code e1205826872950 = 5603873384054 := by decide
theorem cert_e1205826872950 : check e1205826872950 [[],[],[.under]] .smaller = true := by decide
def e1205826873142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205826873142 : Closed e1205826873142 ∧ code e1205826873142 = 5603873384246 := by decide
theorem cert_e1205826873142 : check e1205826873142 [[],[],[.under]] .smaller = true := by decide
def e1205826873146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205826873146 : Closed e1205826873146 ∧ code e1205826873146 = 5603873384250 := by decide
theorem cert_e1205826873146 : check e1205826873146 [[],[],[.under]] .smaller = true := by decide
def e1205827210094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205827210094 : Closed e1205827210094 ∧ code e1205827210094 = 5603873721198 := by decide
theorem cert_e1205827210094 : check e1205827210094 [[],[],[.under]] .smaller = true := by decide
def e1205827210102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205827210102 : Closed e1205827210102 ∧ code e1205827210102 = 5603873721206 := by decide
theorem cert_e1205827210102 : check e1205827210102 [[],[],[.under]] .smaller = true := by decide
def e1205827210158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205827210158 : Closed e1205827210158 ∧ code e1205827210158 = 5603873721262 := by decide
theorem cert_e1205827210158 : check e1205827210158 [[],[],[.under]] .smaller = true := by decide
def e1205827210170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205827210170 : Closed e1205827210170 ∧ code e1205827210170 = 5603873721274 := by decide
theorem cert_e1205827210170 : check e1205827210170 [[],[],[.under]] .smaller = true := by decide
def e1205827210198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205827210198 : Closed e1205827210198 ∧ code e1205827210198 = 5603873721302 := by decide
theorem cert_e1205827210198 : check e1205827210198 [[],[],[.under]] .smaller = true := by decide
def e1205827210202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205827210202 : Closed e1205827210202 ∧ code e1205827210202 = 5603873721306 := by decide
theorem cert_e1205827210202 : check e1205827210202 [[],[],[.under]] .smaller = true := by decide
def e1205827210478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205827210478 : Closed e1205827210478 ∧ code e1205827210478 = 5603873721582 := by decide
theorem cert_e1205827210478 : check e1205827210478 [[],[],[.under]] .smaller = true := by decide
def e1205827210486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205827210486 : Closed e1205827210486 ∧ code e1205827210486 = 5603873721590 := by decide
theorem cert_e1205827210486 : check e1205827210486 [[],[],[.under]] .smaller = true := by decide
def e1205827210862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205827210862 : Closed e1205827210862 ∧ code e1205827210862 = 5603873721966 := by decide
theorem cert_e1205827210862 : check e1205827210862 [[],[],[.under]] .smaller = true := by decide
def e1205827210874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205827210874 : Closed e1205827210874 ∧ code e1205827210874 = 5603873721978 := by decide
theorem cert_e1205827210874 : check e1205827210874 [[],[],[.under]] .smaller = true := by decide
def e1205827211062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205827211062 : Closed e1205827211062 ∧ code e1205827211062 = 5603873722166 := by decide
theorem cert_e1205827211062 : check e1205827211062 [[],[],[.under]] .smaller = true := by decide
def e1205827211066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205827211066 : Closed e1205827211066 ∧ code e1205827211066 = 5603873722170 := by decide
theorem cert_e1205827211066 : check e1205827211066 [[],[],[.under]] .smaller = true := by decide
def e1205849033582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205849033582 : Closed e1205849033582 ∧ code e1205849033582 = 5603895544686 := by decide
theorem cert_e1205849033582 : check e1205849033582 [[],[],[],[]] .sourceHead = true := by decide
def e1205849033590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205849033590 : Closed e1205849033590 ∧ code e1205849033590 = 5603895544694 := by decide
theorem cert_e1205849033590 : check e1205849033590 [[],[],[],[]] .sourceHead = true := by decide
def e1205849033646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205849033646 : Closed e1205849033646 ∧ code e1205849033646 = 5603895544750 := by decide
theorem cert_e1205849033646 : check e1205849033646 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1205849033658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205849033658 : Closed e1205849033658 ∧ code e1205849033658 = 5603895544762 := by decide
theorem cert_e1205849033658 : check e1205849033658 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e1205849033686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205849033686 : Closed e1205849033686 ∧ code e1205849033686 = 5603895544790 := by decide
theorem cert_e1205849033686 : check e1205849033686 [[],[],[],[],[.under,.left],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1205849033690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205849033690 : Closed e1205849033690 ∧ code e1205849033690 = 5603895544794 := by decide
theorem cert_e1205849033690 : check e1205849033690 [[],[],[],[],[.under,.left]] .smaller = true := by decide
def e1205849033966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205849033966 : Closed e1205849033966 ∧ code e1205849033966 = 5603895545070 := by decide
theorem cert_e1205849033966 : check e1205849033966 [[],[],[],[]] .sourceHead = true := by decide
def e1205849033974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205849033974 : Closed e1205849033974 ∧ code e1205849033974 = 5603895545078 := by decide
theorem cert_e1205849033974 : check e1205849033974 [[],[],[],[]] .sourceHead = true := by decide
def e1205849034350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205849034350 : Closed e1205849034350 ∧ code e1205849034350 = 5603895545454 := by decide
theorem cert_e1205849034350 : checkPay e1205849034350 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under],[.under,.under],[.under,.under,.under]] = true := by decide
def e1205849034362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205849034362 : Closed e1205849034362 ∧ code e1205849034362 = 5603895545466 := by decide
theorem cert_e1205849034362 : check e1205849034362 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1205849034550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205849034550 : Closed e1205849034550 ∧ code e1205849034550 = 5603895545654 := by decide
theorem cert_e1205849034550 : check e1205849034550 [[],[],[],[],[.under]] .smaller = true := by decide
def e1205849034554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205849034554 : Closed e1205849034554 ∧ code e1205849034554 = 5603895545658 := by decide
theorem cert_e1205849034554 : check e1205849034554 [[],[],[],[],[.under]] .smaller = true := by decide
end Blc.Floor42
