import Tables
import Batch080
namespace Blc.Floor42.Grades080
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196691361590 : ¬ IsSelfInterpreter e1196691361590 := cutM0_2 (by decide)
#print axioms ex_e1196691361590
theorem ex_e1196691360622 : ¬ IsSelfInterpreter e1196691360622 := cutM2_0 (by decide)
#print axioms ex_e1196691360622
theorem ex_e1196691360686 : ¬ IsSelfInterpreter e1196691360686 := cutM2_0 (by decide)
#print axioms ex_e1196691360686
theorem ex_e1196691361594 : ¬ IsSelfInterpreter e1196691361594 := cutM2_0 (by decide)
#print axioms ex_e1196691361594
theorem ex_e1196691053430 : ¬ IsSelfInterpreter e1196691053430 := cutM3_0 (by decide)
#print axioms ex_e1196691053430
theorem ex_e1196691053494 : ¬ IsSelfInterpreter e1196691053494 := cutM3_0 (by decide)
#print axioms ex_e1196691053494
theorem ex_e1196691053942 : ¬ IsSelfInterpreter e1196691053942 := cutM3_0 (by decide)
#print axioms ex_e1196691053942
theorem ex_e1196691054262 : ¬ IsSelfInterpreter e1196691054262 := cutM3_0 (by decide)
#print axioms ex_e1196691054262
theorem ex_e1196691059574 : ¬ IsSelfInterpreter e1196691059574 := cutM3_0 (by decide)
#print axioms ex_e1196691059574
theorem ex_e1196691059670 : ¬ IsSelfInterpreter e1196691059670 := cutM3_0 (by decide)
#print axioms ex_e1196691059670
theorem ex_e1196691061174 : ¬ IsSelfInterpreter e1196691061174 := cutM3_0 (by decide)
#print axioms ex_e1196691061174
theorem ex_e1196691061206 : ¬ IsSelfInterpreter e1196691061206 := cutM3_0 (by decide)
#print axioms ex_e1196691061206
theorem ex_e1196691230518 : ¬ IsSelfInterpreter e1196691230518 := cutM3_0 (by decide)
#print axioms ex_e1196691230518
theorem ex_e1196691230522 : ¬ IsSelfInterpreter e1196691230522 := cutM3_0 (by decide)
#print axioms ex_e1196691230522
end Blc.Floor42.Grades080
