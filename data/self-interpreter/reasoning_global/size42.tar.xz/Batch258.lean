import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211583901578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211583901578 : Closed e1211583901578 ∧ code e1211583901578 = 5609630412682 := by decide
theorem cert_e1211583901578 : check e1211583901578 [[],[],[],[]] .chain = true := by decide
def e1211583901602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211583901602 : Closed e1211583901602 ∧ code e1211583901602 = 5609630412706 := by decide
theorem cert_e1211583901602 : check e1211583901602 [[],[],[],[]] .chain = true := by decide
def e1211583901614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211583901614 : Closed e1211583901614 ∧ code e1211583901614 = 5609630412718 := by decide
theorem cert_e1211583901614 : check e1211583901614 [[],[],[],[]] .sourceHead = true := by decide
def e1211583901626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211583901626 : Closed e1211583901626 ∧ code e1211583901626 = 5609630412730 := by decide
theorem cert_e1211583901626 : check e1211583901626 [[],[],[],[]] .sourceHead = true := by decide
def e1211583901822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211583901822 : Closed e1211583901822 ∧ code e1211583901822 = 5609630412926 := by decide
theorem cert_e1211583901822 : check e1211583901822 [[],[],[],[]] .chain = true := by decide
def e1211583902494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211583902494 : Closed e1211583902494 ∧ code e1211583902494 = 5609630413598 := by decide
theorem cert_e1211583902494 : check e1211583902494 [[],[],[],[]] .chain = true := by decide
def e1211583902662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211583902662 : Closed e1211583902662 ∧ code e1211583902662 = 5609630413766 := by decide
theorem cert_e1211583902662 : check e1211583902662 [[],[],[],[]] .chain = true := by decide
def e1211583902686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211583902686 : Closed e1211583902686 ∧ code e1211583902686 = 5609630413790 := by decide
theorem cert_e1211583902686 : check e1211583902686 [[],[],[],[]] .sourceHead = true := by decide
def e1211583902690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211583902690 : Closed e1211583902690 ∧ code e1211583902690 = 5609630413794 := by decide
theorem cert_e1211583902690 : check e1211583902690 [[],[],[],[]] .chain = true := by decide
def e1211583902702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211583902702 : Closed e1211583902702 ∧ code e1211583902702 = 5609630413806 := by decide
theorem cert_e1211583902702 : check e1211583902702 [[],[],[],[]] .sourceHead = true := by decide
def e1211583904966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211583904966 : Closed e1211583904966 ∧ code e1211583904966 = 5609630416070 := by decide
theorem cert_e1211583904966 : check e1211583904966 [[],[],[],[]] .chain = true := by decide
def e1211583904990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211583904990 : Closed e1211583904990 ∧ code e1211583904990 = 5609630416094 := by decide
theorem cert_e1211583904990 : check e1211583904990 [[],[],[],[]] .sourceHead = true := by decide
def e1211583905018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211583905018 : Closed e1211583905018 ∧ code e1211583905018 = 5609630416122 := by decide
theorem cert_e1211583905018 : check e1211583905018 [[],[],[],[]] .sourceHead = true := by decide
def e1211583905294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211583905294 : Closed e1211583905294 ∧ code e1211583905294 = 5609630416398 := by decide
theorem cert_e1211583905294 : check e1211583905294 [[],[],[],[]] .chain = true := by decide
def e1211583905378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211583905378 : Closed e1211583905378 ∧ code e1211583905378 = 5609630416482 := by decide
theorem cert_e1211583905378 : check e1211583905378 [[],[],[],[]] .chain = true := by decide
def e1211583905390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211583905390 : Closed e1211583905390 ∧ code e1211583905390 = 5609630416494 := by decide
theorem cert_e1211583905390 : check e1211583905390 [[],[],[],[]] .sourceHead = true := by decide
def e1211583905402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211583905402 : Closed e1211583905402 ∧ code e1211583905402 = 5609630416506 := by decide
theorem cert_e1211583905402 : check e1211583905402 [[],[],[],[]] .sourceHead = true := by decide
def e1211583924158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211583924158 : Closed e1211583924158 ∧ code e1211583924158 = 5609630435262 := by decide
theorem cert_e1211583924158 : check e1211583924158 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583924206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211583924206 : Closed e1211583924206 ∧ code e1211583924206 = 5609630435310 := by decide
theorem cert_e1211583924206 : check e1211583924206 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583927862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211583927862 : Closed e1211583927862 ∧ code e1211583927862 = 5609630438966 := by decide
theorem cert_e1211583927862 : check e1211583927862 [[],[],[],[]] .chain = true := by decide
def e1211583927866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211583927866 : Closed e1211583927866 ∧ code e1211583927866 = 5609630438970 := by decide
theorem cert_e1211583927866 : check e1211583927866 [[],[],[],[]] .chain = true := by decide
def e1211583927950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211583927950 : Closed e1211583927950 ∧ code e1211583927950 = 5609630439054 := by decide
theorem cert_e1211583927950 : check e1211583927950 [[],[],[],[]] .chain = true := by decide
def e1211583928006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211583928006 : Closed e1211583928006 ∧ code e1211583928006 = 5609630439110 := by decide
theorem cert_e1211583928006 : check e1211583928006 [[],[],[],[]] .chain = true := by decide
def e1211583928030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211583928030 : Closed e1211583928030 ∧ code e1211583928030 = 5609630439134 := by decide
theorem cert_e1211583928030 : check e1211583928030 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211583928054 : Closed e1211583928054 ∧ code e1211583928054 = 5609630439158 := by decide
theorem cert_e1211583928054 : check e1211583928054 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211583928090 : Closed e1211583928090 ∧ code e1211583928090 = 5609630439194 := by decide
theorem cert_e1211583928090 : check e1211583928090 [[],[],[],[]] .chain = true := by decide
def e1211583928134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211583928134 : Closed e1211583928134 ∧ code e1211583928134 = 5609630439238 := by decide
theorem cert_e1211583928134 : check e1211583928134 [[],[],[],[]] .chain = true := by decide
def e1211583928158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211583928158 : Closed e1211583928158 ∧ code e1211583928158 = 5609630439262 := by decide
theorem cert_e1211583928158 : check e1211583928158 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211583928186 : Closed e1211583928186 ∧ code e1211583928186 = 5609630439290 := by decide
theorem cert_e1211583928186 : check e1211583928186 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211583928278 : Closed e1211583928278 ∧ code e1211583928278 = 5609630439382 := by decide
theorem cert_e1211583928278 : check e1211583928278 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211583928282 : Closed e1211583928282 ∧ code e1211583928282 = 5609630439386 := by decide
theorem cert_e1211583928282 : check e1211583928282 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211583928718 : Closed e1211583928718 ∧ code e1211583928718 = 5609630439822 := by decide
theorem cert_e1211583928718 : check e1211583928718 [[],[],[],[]] .chain = true := by decide
def e1211583928774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211583928774 : Closed e1211583928774 ∧ code e1211583928774 = 5609630439878 := by decide
theorem cert_e1211583928774 : check e1211583928774 [[],[],[],[]] .chain = true := by decide
def e1211583928798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211583928798 : Closed e1211583928798 ∧ code e1211583928798 = 5609630439902 := by decide
theorem cert_e1211583928798 : check e1211583928798 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583928822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211583928822 : Closed e1211583928822 ∧ code e1211583928822 = 5609630439926 := by decide
theorem cert_e1211583928822 : check e1211583928822 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583929542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211583929542 : Closed e1211583929542 ∧ code e1211583929542 = 5609630440646 := by decide
theorem cert_e1211583929542 : check e1211583929542 [[],[],[],[]] .chain = true := by decide
def e1211583929566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211583929566 : Closed e1211583929566 ∧ code e1211583929566 = 5609630440670 := by decide
theorem cert_e1211583929566 : check e1211583929566 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583929594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211583929594 : Closed e1211583929594 ∧ code e1211583929594 = 5609630440698 := by decide
theorem cert_e1211583929594 : check e1211583929594 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583930166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583930166 : Closed e1211583930166 ∧ code e1211583930166 = 5609630441270 := by decide
theorem cert_e1211583930166 : check e1211583930166 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583930170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583930170 : Closed e1211583930170 ∧ code e1211583930170 = 5609630441274 := by decide
theorem cert_e1211583930170 : check e1211583930170 [[],[],[],[],[.under,.under]] .three = true := by decide
def e1211583939550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211583939550 : Closed e1211583939550 ∧ code e1211583939550 = 5609630450654 := by decide
theorem cert_e1211583939550 : check e1211583939550 [[],[],[],[],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211583939566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211583939566 : Closed e1211583939566 ∧ code e1211583939566 = 5609630450670 := by decide
theorem cert_e1211583939566 : check e1211583939566 [[],[],[],[],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211583941398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211583941398 : Closed e1211583941398 ∧ code e1211583941398 = 5609630452502 := by decide
theorem cert_e1211583941398 : check e1211583941398 [[],[],[],[]] .chain = true := by decide
def e1211583941474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211583941474 : Closed e1211583941474 ∧ code e1211583941474 = 5609630452578 := by decide
theorem cert_e1211583941474 : check e1211583941474 [[],[],[],[]] .chain = true := by decide
def e1211583941486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211583941486 : Closed e1211583941486 ∧ code e1211583941486 = 5609630452590 := by decide
theorem cert_e1211583941486 : check e1211583941486 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211583941494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211583941494 : Closed e1211583941494 ∧ code e1211583941494 = 5609630452598 := by decide
theorem cert_e1211583941494 : check e1211583941494 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under]] .identityHead = true := by decide
def e1211583941514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211583941514 : Closed e1211583941514 ∧ code e1211583941514 = 5609630452618 := by decide
theorem cert_e1211583941514 : check e1211583941514 [[],[],[],[]] .chain = true := by decide
def e1211583941538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211583941538 : Closed e1211583941538 ∧ code e1211583941538 = 5609630452642 := by decide
theorem cert_e1211583941538 : check e1211583941538 [[],[],[],[]] .chain = true := by decide
def e1211583941550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211583941550 : Closed e1211583941550 ∧ code e1211583941550 = 5609630452654 := by decide
theorem cert_e1211583941550 : check e1211583941550 [[],[],[],[],[.under,.under]] .sourceHead = true := by decide
def e1211583941562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211583941562 : Closed e1211583941562 ∧ code e1211583941562 = 5609630452666 := by decide
theorem cert_e1211583941562 : check e1211583941562 [[],[],[],[],[.under,.under]] .sourceHead = true := by decide
def e1211583941590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211583941590 : Closed e1211583941590 ∧ code e1211583941590 = 5609630452694 := by decide
theorem cert_e1211583941590 : check e1211583941590 [[],[],[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211583941594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211583941594 : Closed e1211583941594 ∧ code e1211583941594 = 5609630452698 := by decide
theorem cert_e1211583941594 : check e1211583941594 [[],[],[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211583941662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211583941662 : Closed e1211583941662 ∧ code e1211583941662 = 5609630452766 := by decide
theorem cert_e1211583941662 : check e1211583941662 [[],[],[],[]] .chain = true := by decide
def e1211583941858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211583941858 : Closed e1211583941858 ∧ code e1211583941858 = 5609630452962 := by decide
theorem cert_e1211583941858 : check e1211583941858 [[],[],[],[]] .chain = true := by decide
def e1211583941870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211583941870 : Closed e1211583941870 ∧ code e1211583941870 = 5609630452974 := by decide
theorem cert_e1211583941870 : check e1211583941870 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1211583941878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211583941878 : Closed e1211583941878 ∧ code e1211583941878 = 5609630452982 := by decide
theorem cert_e1211583941878 : check e1211583941878 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under]] .identityHead = true := by decide
def e1211583942158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211583942158 : Closed e1211583942158 ∧ code e1211583942158 = 5609630453262 := by decide
theorem cert_e1211583942158 : check e1211583942158 [[],[],[],[]] .chain = true := by decide
def e1211583942242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211583942242 : Closed e1211583942242 ∧ code e1211583942242 = 5609630453346 := by decide
theorem cert_e1211583942242 : check e1211583942242 [[],[],[],[]] .chain = true := by decide
def e1211583942254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211583942254 : Closed e1211583942254 ∧ code e1211583942254 = 5609630453358 := by decide
theorem cert_e1211583942254 : checkPay e1211583942254 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under],[.under,.under,.under],[.under,.under,.under,.left,.right,.right],[.under,.under,.under,.right,.under,.under,.under,.left,.right,.right]] = true := by decide
def e1211583942266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211583942266 : Closed e1211583942266 ∧ code e1211583942266 = 5609630453370 := by decide
theorem cert_e1211583942266 : checkPay e1211583942266 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.under,.under],[.under,.under,.under,.under,.left,.right,.left,.right],[.under,.under,.under,.under,.right,.under,.under,.under,.left,.right,.left,.right]] = true := by decide
def e1211583942454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583942454 : Closed e1211583942454 ∧ code e1211583942454 = 5609630453558 := by decide
theorem cert_e1211583942454 : check e1211583942454 [[],[],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583942458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583942458 : Closed e1211583942458 ∧ code e1211583942458 = 5609630453562 := by decide
theorem cert_e1211583942458 : check e1211583942458 [[],[],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211584834414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211584834414 : Closed e1211584834414 ∧ code e1211584834414 = 5609631345518 := by decide
theorem cert_e1211584834414 : check e1211584834414 [[],[],[],[]] .sourceHead = true := by decide
def e1211584834422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211584834422 : Closed e1211584834422 ∧ code e1211584834422 = 5609631345526 := by decide
theorem cert_e1211584834422 : check e1211584834422 [[],[],[],[]] .sourceHead = true := by decide
def e1211584834486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211584834486 : Closed e1211584834486 ∧ code e1211584834486 = 5609631345590 := by decide
theorem cert_e1211584834486 : check e1211584834486 [[],[],[],[]] .sourceHead = true := by decide
def e1211584834926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211584834926 : Closed e1211584834926 ∧ code e1211584834926 = 5609631346030 := by decide
theorem cert_e1211584834926 : check e1211584834926 [[],[],[],[]] .sourceHead = true := by decide
def e1211584834934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211584834934 : Closed e1211584834934 ∧ code e1211584834934 = 5609631346038 := by decide
theorem cert_e1211584834934 : check e1211584834934 [[],[],[],[]] .sourceHead = true := by decide
def e1211584834990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211584834990 : Closed e1211584834990 ∧ code e1211584834990 = 5609631346094 := by decide
theorem cert_e1211584834990 : check e1211584834990 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211584835002 : Closed e1211584835002 ∧ code e1211584835002 = 5609631346106 := by decide
theorem cert_e1211584835002 : check e1211584835002 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211584835030 : Closed e1211584835030 ∧ code e1211584835030 = 5609631346134 := by decide
theorem cert_e1211584835030 : check e1211584835030 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211584835034 : Closed e1211584835034 ∧ code e1211584835034 = 5609631346138 := by decide
theorem cert_e1211584835034 : check e1211584835034 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211584835254 : Closed e1211584835254 ∧ code e1211584835254 = 5609631346358 := by decide
theorem cert_e1211584835254 : check e1211584835254 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211584835286 : Closed e1211584835286 ∧ code e1211584835286 = 5609631346390 := by decide
theorem cert_e1211584835286 : check e1211584835286 [[],[],[],[]] .sourceHead = true := by decide
def e1211584835290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211584835290 : Closed e1211584835290 ∧ code e1211584835290 = 5609631346394 := by decide
theorem cert_e1211584835290 : check e1211584835290 [[],[],[],[]] .sourceHead = true := by decide
def e1211584836974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211584836974 : Closed e1211584836974 ∧ code e1211584836974 = 5609631348078 := by decide
theorem cert_e1211584836974 : check e1211584836974 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584836982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211584836982 : Closed e1211584836982 ∧ code e1211584836982 = 5609631348086 := by decide
theorem cert_e1211584836982 : check e1211584836982 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584837038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211584837038 : Closed e1211584837038 ∧ code e1211584837038 = 5609631348142 := by decide
theorem cert_e1211584837038 : check e1211584837038 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584837050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211584837050 : Closed e1211584837050 ∧ code e1211584837050 = 5609631348154 := by decide
theorem cert_e1211584837050 : check e1211584837050 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584837078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211584837078 : Closed e1211584837078 ∧ code e1211584837078 = 5609631348182 := by decide
theorem cert_e1211584837078 : check e1211584837078 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584837082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211584837082 : Closed e1211584837082 ∧ code e1211584837082 = 5609631348186 := by decide
theorem cert_e1211584837082 : check e1211584837082 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584837294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211584837294 : Closed e1211584837294 ∧ code e1211584837294 = 5609631348398 := by decide
private def t_e1211584837294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem cert_e1211584837294 : ¬ IsSelfInterpreter e1211584837294 :=
  wSource (t := t_e1211584837294) (replay_sound (ps := []) (t := e1211584837294) (by decide)) (by decide)
def e1211584837306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211584837306 : Closed e1211584837306 ∧ code e1211584837306 = 5609631348410 := by decide
private def t_e1211584837306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem cert_e1211584837306 : ¬ IsSelfInterpreter e1211584837306 :=
  wSource (t := t_e1211584837306) (replay_sound (ps := []) (t := e1211584837306) (by decide)) (by decide)
def e1211584837354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211584837354 : Closed e1211584837354 ∧ code e1211584837354 = 5609631348458 := by decide
private def t_e1211584837354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e1211584837354 : ¬ IsSelfInterpreter e1211584837354 :=
  wSource (t := t_e1211584837354) (replay_sound (ps := []) (t := e1211584837354) (by decide)) (by decide)
def e1211584837462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211584837462 : Closed e1211584837462 ∧ code e1211584837462 = 5609631348566 := by decide
private def t_e1211584837462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1211584837462 : ¬ IsSelfInterpreter e1211584837462 :=
  wSource (t := t_e1211584837462) (replay_sound (ps := []) (t := e1211584837462) (by decide)) (by decide)
def e1211584837466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211584837466 : Closed e1211584837466 ∧ code e1211584837466 = 5609631348570 := by decide
private def t_e1211584837466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1211584837466 : ¬ IsSelfInterpreter e1211584837466 :=
  wSource (t := t_e1211584837466) (replay_sound (ps := []) (t := e1211584837466) (by decide)) (by decide)
def e1211584837482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211584837482 : Closed e1211584837482 ∧ code e1211584837482 = 5609631348586 := by decide
private def t_e1211584837482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e1211584837482 : ¬ IsSelfInterpreter e1211584837482 :=
  wSource (t := t_e1211584837482) (replay_sound (ps := []) (t := e1211584837482) (by decide)) (by decide)
def e1211584838326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211584838326 : Closed e1211584838326 ∧ code e1211584838326 = 5609631349430 := by decide
theorem cert_e1211584838326 : check e1211584838326 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584838358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211584838358 : Closed e1211584838358 ∧ code e1211584838358 = 5609631349462 := by decide
theorem cert_e1211584838358 : check e1211584838358 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584838362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211584838362 : Closed e1211584838362 ∧ code e1211584838362 = 5609631349466 := by decide
theorem cert_e1211584838362 : check e1211584838362 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584838486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211584838486 : Closed e1211584838486 ∧ code e1211584838486 = 5609631349590 := by decide
private def t_e1211584838486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1211584838486 : ¬ IsSelfInterpreter e1211584838486 :=
  wSource (t := t_e1211584838486) (replay_sound (ps := []) (t := e1211584838486) (by decide)) (by decide)
def e1211584838490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211584838490 : Closed e1211584838490 ∧ code e1211584838490 = 5609631349594 := by decide
private def t_e1211584838490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1211584838490 : ¬ IsSelfInterpreter e1211584838490 :=
  wSource (t := t_e1211584838490) (replay_sound (ps := []) (t := e1211584838490) (by decide)) (by decide)
def e1211584838506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211584838506 : Closed e1211584838506 ∧ code e1211584838506 = 5609631349610 := by decide
private def t_e1211584838506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e1211584838506 : ¬ IsSelfInterpreter e1211584838506 :=
  wSource (t := t_e1211584838506) (replay_sound (ps := []) (t := e1211584838506) (by decide)) (by decide)
def e1211584840558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e1211584840558 : Closed e1211584840558 ∧ code e1211584840558 = 5609631351662 := by decide
theorem cert_e1211584840558 : check e1211584840558 [[],[],[],[]] .sourceHead = true := by decide
def e1211584840566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e1211584840566 : Closed e1211584840566 ∧ code e1211584840566 = 5609631351670 := by decide
theorem cert_e1211584840566 : check e1211584840566 [[],[],[],[]] .sourceHead = true := by decide
def e1211584841966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211584841966 : Closed e1211584841966 ∧ code e1211584841966 = 5609631353070 := by decide
theorem cert_e1211584841966 : check e1211584841966 [[],[],[],[]] .sourceHead = true := by decide
def e1211584841974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211584841974 : Closed e1211584841974 ∧ code e1211584841974 = 5609631353078 := by decide
theorem cert_e1211584841974 : check e1211584841974 [[],[],[],[]] .sourceHead = true := by decide
def e1211584842526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211584842526 : Closed e1211584842526 ∧ code e1211584842526 = 5609631353630 := by decide
theorem cert_e1211584842526 : check e1211584842526 [[],[],[],[]] .sourceHead = true := by decide
def e1211584842638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211584842638 : Closed e1211584842638 ∧ code e1211584842638 = 5609631353742 := by decide
theorem cert_e1211584842638 : check e1211584842638 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211584843310 : Closed e1211584843310 ∧ code e1211584843310 = 5609631354414 := by decide
theorem cert_e1211584843310 : check e1211584843310 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211584843490 : Closed e1211584843490 ∧ code e1211584843490 = 5609631354594 := by decide
theorem cert_e1211584843490 : check e1211584843490 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e1211584843502 : Closed e1211584843502 ∧ code e1211584843502 = 5609631354606 := by decide
theorem cert_e1211584843502 : check e1211584843502 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211584843542 : Closed e1211584843542 ∧ code e1211584843542 = 5609631354646 := by decide
theorem cert_e1211584843542 : check e1211584843542 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211584843618 : Closed e1211584843618 ∧ code e1211584843618 = 5609631354722 := by decide
theorem cert_e1211584843618 : check e1211584843618 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e1211584843630 : Closed e1211584843630 ∧ code e1211584843630 = 5609631354734 := by decide
theorem cert_e1211584843630 : check e1211584843630 [[],[],[],[]] .sourceHead = true := by decide
def e1211584843638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e1211584843638 : Closed e1211584843638 ∧ code e1211584843638 = 5609631354742 := by decide
theorem cert_e1211584843638 : check e1211584843638 [[],[],[],[]] .sourceHead = true := by decide
def e1211584846702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211584846702 : Closed e1211584846702 ∧ code e1211584846702 = 5609631357806 := by decide
theorem cert_e1211584846702 : check e1211584846702 [[],[],[],[]] .sourceHead = true := by decide
def e1211584846710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211584846710 : Closed e1211584846710 ∧ code e1211584846710 = 5609631357814 := by decide
theorem cert_e1211584846710 : check e1211584846710 [[],[],[],[]] .sourceHead = true := by decide
def e1211584846774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211584846774 : Closed e1211584846774 ∧ code e1211584846774 = 5609631357878 := by decide
theorem cert_e1211584846774 : check e1211584846774 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211584847214 : Closed e1211584847214 ∧ code e1211584847214 = 5609631358318 := by decide
theorem cert_e1211584847214 : check e1211584847214 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211584847222 : Closed e1211584847222 ∧ code e1211584847222 = 5609631358326 := by decide
theorem cert_e1211584847222 : check e1211584847222 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211584847278 : Closed e1211584847278 ∧ code e1211584847278 = 5609631358382 := by decide
theorem cert_e1211584847278 : check e1211584847278 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211584847290 : Closed e1211584847290 ∧ code e1211584847290 = 5609631358394 := by decide
theorem cert_e1211584847290 : check e1211584847290 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211584847318 : Closed e1211584847318 ∧ code e1211584847318 = 5609631358422 := by decide
theorem cert_e1211584847318 : check e1211584847318 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211584847322 : Closed e1211584847322 ∧ code e1211584847322 = 5609631358426 := by decide
theorem cert_e1211584847322 : check e1211584847322 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211584847542 : Closed e1211584847542 ∧ code e1211584847542 = 5609631358646 := by decide
theorem cert_e1211584847542 : check e1211584847542 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211584847574 : Closed e1211584847574 ∧ code e1211584847574 = 5609631358678 := by decide
theorem cert_e1211584847574 : check e1211584847574 [[],[],[],[]] .sourceHead = true := by decide
def e1211584847578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211584847578 : Closed e1211584847578 ∧ code e1211584847578 = 5609631358682 := by decide
theorem cert_e1211584847578 : check e1211584847578 [[],[],[],[]] .sourceHead = true := by decide
def e1211584849774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211584849774 : Closed e1211584849774 ∧ code e1211584849774 = 5609631360878 := by decide
theorem cert_e1211584849774 : check e1211584849774 [[],[],[],[]] .sourceHead = true := by decide
def e1211584849782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211584849782 : Closed e1211584849782 ∧ code e1211584849782 = 5609631360886 := by decide
theorem cert_e1211584849782 : check e1211584849782 [[],[],[],[]] .sourceHead = true := by decide
def e1211584849846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211584849846 : Closed e1211584849846 ∧ code e1211584849846 = 5609631360950 := by decide
theorem cert_e1211584849846 : check e1211584849846 [[],[],[],[]] .sourceHead = true := by decide
def e1211584851182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584851182 : Closed e1211584851182 ∧ code e1211584851182 = 5609631362286 := by decide
theorem cert_e1211584851182 : check e1211584851182 [[],[],[],[]] .sourceHead = true := by decide
def e1211584851190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584851190 : Closed e1211584851190 ∧ code e1211584851190 = 5609631362294 := by decide
theorem cert_e1211584851190 : check e1211584851190 [[],[],[],[]] .sourceHead = true := by decide
def e1211584851574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584851574 : Closed e1211584851574 ∧ code e1211584851574 = 5609631362678 := by decide
theorem cert_e1211584851574 : check e1211584851574 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211584852078 : Closed e1211584852078 ∧ code e1211584852078 = 5609631363182 := by decide
theorem cert_e1211584852078 : check e1211584852078 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211584852254 : Closed e1211584852254 ∧ code e1211584852254 = 5609631363358 := by decide
theorem cert_e1211584852254 : check e1211584852254 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211584852450 : Closed e1211584852450 ∧ code e1211584852450 = 5609631363554 := by decide
theorem cert_e1211584852450 : check e1211584852450 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211584852462 : Closed e1211584852462 ∧ code e1211584852462 = 5609631363566 := by decide
theorem cert_e1211584852462 : check e1211584852462 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211584852846 : Closed e1211584852846 ∧ code e1211584852846 = 5609631363950 := by decide
theorem cert_e1211584852846 : check e1211584852846 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211584852854 : Closed e1211584852854 ∧ code e1211584852854 = 5609631363958 := by decide
theorem cert_e1211584852854 : check e1211584852854 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211584852910 : Closed e1211584852910 ∧ code e1211584852910 = 5609631364014 := by decide
theorem cert_e1211584852910 : check e1211584852910 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211584852922 : Closed e1211584852922 ∧ code e1211584852922 = 5609631364026 := by decide
theorem cert_e1211584852922 : check e1211584852922 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211584852950 : Closed e1211584852950 ∧ code e1211584852950 = 5609631364054 := by decide
theorem cert_e1211584852950 : check e1211584852950 [[],[],[],[]] .sourceHead = true := by decide
def e1211584852954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211584852954 : Closed e1211584852954 ∧ code e1211584852954 = 5609631364058 := by decide
theorem cert_e1211584852954 : check e1211584852954 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584853230 : Closed e1211584853230 ∧ code e1211584853230 = 5609631364334 := by decide
theorem cert_e1211584853230 : check e1211584853230 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584853238 : Closed e1211584853238 ∧ code e1211584853238 = 5609631364342 := by decide
theorem cert_e1211584853238 : check e1211584853238 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584853614 : Closed e1211584853614 ∧ code e1211584853614 = 5609631364718 := by decide
theorem cert_e1211584853614 : check e1211584853614 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584853626 : Closed e1211584853626 ∧ code e1211584853626 = 5609631364730 := by decide
theorem cert_e1211584853626 : check e1211584853626 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584853766 : Closed e1211584853766 ∧ code e1211584853766 = 5609631364870 := by decide
theorem cert_e1211584853766 : check e1211584853766 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211584853790 : Closed e1211584853790 ∧ code e1211584853790 = 5609631364894 := by decide
theorem cert_e1211584853790 : check e1211584853790 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584853814 : Closed e1211584853814 ∧ code e1211584853814 = 5609631364918 := by decide
theorem cert_e1211584853814 : check e1211584853814 [[],[],[],[]] .sourceHead = true := by decide
def e1211584853818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584853818 : Closed e1211584853818 ∧ code e1211584853818 = 5609631364922 := by decide
theorem cert_e1211584853818 : check e1211584853818 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211584854070 : Closed e1211584854070 ∧ code e1211584854070 = 5609631365174 := by decide
theorem cert_e1211584854070 : check e1211584854070 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211584854158 : Closed e1211584854158 ∧ code e1211584854158 = 5609631365262 := by decide
theorem cert_e1211584854158 : check e1211584854158 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211584854242 : Closed e1211584854242 ∧ code e1211584854242 = 5609631365346 := by decide
theorem cert_e1211584854242 : check e1211584854242 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211584854254 : Closed e1211584854254 ∧ code e1211584854254 = 5609631365358 := by decide
theorem cert_e1211584854254 : check e1211584854254 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211584854262 : Closed e1211584854262 ∧ code e1211584854262 = 5609631365366 := by decide
theorem cert_e1211584854262 : check e1211584854262 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211584854454 : Closed e1211584854454 ∧ code e1211584854454 = 5609631365558 := by decide
theorem cert_e1211584854454 : check e1211584854454 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211584854486 : Closed e1211584854486 ∧ code e1211584854486 = 5609631365590 := by decide
theorem cert_e1211584854486 : check e1211584854486 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211584854490 : Closed e1211584854490 ∧ code e1211584854490 = 5609631365594 := by decide
theorem cert_e1211584854490 : check e1211584854490 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584854646 : Closed e1211584854646 ∧ code e1211584854646 = 5609631365750 := by decide
theorem cert_e1211584854646 : check e1211584854646 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584854790 : Closed e1211584854790 ∧ code e1211584854790 = 5609631365894 := by decide
theorem cert_e1211584854790 : check e1211584854790 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211584854814 : Closed e1211584854814 ∧ code e1211584854814 = 5609631365918 := by decide
theorem cert_e1211584854814 : check e1211584854814 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584854838 : Closed e1211584854838 ∧ code e1211584854838 = 5609631365942 := by decide
theorem cert_e1211584854838 : check e1211584854838 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584854842 : Closed e1211584854842 ∧ code e1211584854842 = 5609631365946 := by decide
theorem cert_e1211584854842 : check e1211584854842 [[],[],[],[]] .sourceHead = true := by decide
def e1211584854926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211584854926 : Closed e1211584854926 ∧ code e1211584854926 = 5609631366030 := by decide
theorem cert_e1211584854926 : check e1211584854926 [[],[],[],[]] .sourceHead = true := by decide
def e1211584856494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211584856494 : Closed e1211584856494 ∧ code e1211584856494 = 5609631367598 := by decide
theorem cert_e1211584856494 : check e1211584856494 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e1211584856506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211584856506 : Closed e1211584856506 ∧ code e1211584856506 = 5609631367610 := by decide
theorem cert_e1211584856506 : check e1211584856506 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1211584857198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211584857198 : Closed e1211584857198 ∧ code e1211584857198 = 5609631368302 := by decide
theorem cert_e1211584857198 : check e1211584857198 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e1211584857210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211584857210 : Closed e1211584857210 ∧ code e1211584857210 = 5609631368314 := by decide
theorem cert_e1211584857210 : check e1211584857210 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211584857374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211584857374 : Closed e1211584857374 ∧ code e1211584857374 = 5609631368478 := by decide
theorem cert_e1211584857374 : check e1211584857374 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
end Blc.Floor42
