import R1130567043958V0
import R1130567043958K0
import R1130567043958st0
import R1130567043958st12
import R1130567043958hs0
import R1130567043958hs12
import CodeBridge
import Batch054
namespace Certgen.R1130567043958
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 21,.app 2 20,.app 3 10,.lam 4,.lam 5,.app 6 7,.var 1,.app 8 9,.var 1,.var 1,.lam 11,.app 12 13,.var 0,.lam 14,.lam 15,.app 16 19,.app 17 18,.var 0,.var 2,.var 1,.opaque,.lam 22,.app 23 28,.app 24 25,.var 0,.lam 26,.lam 27,.var 1,.lam 29,.app 30 35,.app 31 32,.var 0,.lam 33,.lam 34,.var 1,.lam 36,.app 37 42,.app 38 39,.var 0,.lam 40,.lam 41,.var 0,.lam 43,.app 44 49,.app 45 46,.var 0,.lam 47,.lam 48,.var 1,.opaque]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 431 then (if i < 220 then (if i < 100 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else (if i < 160 then (if i < 120 then (st100[i-100]?.getD entry) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry))) else (if i < 180 then (st160[i-160]?.getD entry) else (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry))))) else (if i < 320 then (if i < 260 then (if i < 240 then (st220[i-220]?.getD entry) else (st240[i-240]?.getD entry)) else (if i < 280 then (st260[i-260]?.getD entry) else (if i < 300 then (st280[i-280]?.getD entry) else (st300[i-300]?.getD entry)))) else (if i < 380 then (if i < 340 then (st320[i-320]?.getD entry) else (if i < 360 then (st340[i-340]?.getD entry) else (st360[i-360]?.getD entry))) else (if i < 400 then (st380[i-380]?.getD entry) else (if i < 420 then (st400[i-400]?.getD entry) else (st420[i-420]?.getD entry)))))) else entry
def hs (i : Nat) : List Nat := (if i < 220 then (if i < 100 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])))) else (if i < 160 then (if i < 120 then (hs100[i-100]?.getD []) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))) else (if i < 180 then (hs160[i-160]?.getD []) else (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD []))))) else (if i < 320 then (if i < 260 then (if i < 240 then (hs220[i-220]?.getD []) else (hs240[i-240]?.getD [])) else (if i < 280 then (hs260[i-260]?.getD []) else (if i < 300 then (hs280[i-280]?.getD []) else (hs300[i-300]?.getD [])))) else (if i < 380 then (if i < 340 then (hs320[i-320]?.getD []) else (if i < 360 then (hs340[i-340]?.getD []) else (hs360[i-360]?.getD []))) else (if i < 400 then (hs380[i-380]?.getD []) else (if i < 420 then (hs400[i-400]?.getD []) else (hs420[i-420]?.getD []))))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R1130567043958
