import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211282962042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282962042 : Closed e1211282962042 ∧ code e1211282962042 = 5609329473146 := by decide
theorem cert_e1211282962042 : check e1211282962042 [[],[]] .chain = true := by decide
def e1211282962182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282962182 : Closed e1211282962182 ∧ code e1211282962182 = 5609329473286 := by decide
theorem cert_e1211282962182 : check e1211282962182 [[],[]] .chain = true := by decide
def e1211282962206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211282962206 : Closed e1211282962206 ∧ code e1211282962206 = 5609329473310 := by decide
theorem cert_e1211282962206 : check e1211282962206 [[],[]] .sourceHead = true := by decide
def e1211282962230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282962230 : Closed e1211282962230 ∧ code e1211282962230 = 5609329473334 := by decide
theorem cert_e1211282962230 : check e1211282962230 [[],[]] .chain = true := by decide
def e1211282962234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282962234 : Closed e1211282962234 ∧ code e1211282962234 = 5609329473338 := by decide
theorem cert_e1211282962234 : check e1211282962234 [[],[]] .chain = true := by decide
def e1211282962862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211282962862 : Closed e1211282962862 ∧ code e1211282962862 = 5609329473966 := by decide
theorem cert_e1211282962862 : check e1211282962862 [[],[]] .chain = true := by decide
def e1211282962874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211282962874 : Closed e1211282962874 ∧ code e1211282962874 = 5609329473978 := by decide
theorem cert_e1211282962874 : check e1211282962874 [[],[]] .chain = true := by decide
def e1211282962922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211282962922 : Closed e1211282962922 ∧ code e1211282962922 = 5609329474026 := by decide
theorem cert_e1211282962922 : check e1211282962922 [[],[]] .chain = true := by decide
def e1211282963054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282963054 : Closed e1211282963054 ∧ code e1211282963054 = 5609329474158 := by decide
theorem cert_e1211282963054 : check e1211282963054 [[],[]] .chain = true := by decide
def e1211282963066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282963066 : Closed e1211282963066 ∧ code e1211282963066 = 5609329474170 := by decide
theorem cert_e1211282963066 : check e1211282963066 [[],[]] .chain = true := by decide
def e1211282963354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282963354 : Closed e1211282963354 ∧ code e1211282963354 = 5609329474458 := by decide
theorem cert_e1211282963354 : check e1211282963354 [[],[]] .chain = true := by decide
def e1211282963482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211282963482 : Closed e1211282963482 ∧ code e1211282963482 = 5609329474586 := by decide
theorem cert_e1211282963482 : check e1211282963482 [[],[]] .chain = true := by decide
def e1211282963526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211282963526 : Closed e1211282963526 ∧ code e1211282963526 = 5609329474630 := by decide
theorem cert_e1211282963526 : check e1211282963526 [[],[]] .chain = true := by decide
def e1211282963554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211282963554 : Closed e1211282963554 ∧ code e1211282963554 = 5609329474658 := by decide
theorem cert_e1211282963554 : check e1211282963554 [[],[]] .chain = true := by decide
def e1211282963566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211282963566 : Closed e1211282963566 ∧ code e1211282963566 = 5609329474670 := by decide
theorem cert_e1211282963566 : check e1211282963566 [[],[]] .sourceHead = true := by decide
def e1211282963578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211282963578 : Closed e1211282963578 ∧ code e1211282963578 = 5609329474682 := by decide
theorem cert_e1211282963578 : check e1211282963578 [[],[]] .sourceHead = true := by decide
def e1211282963670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211282963670 : Closed e1211282963670 ∧ code e1211282963670 = 5609329474774 := by decide
theorem cert_e1211282963670 : check e1211282963670 [[],[]] .chain = true := by decide
def e1211282963674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211282963674 : Closed e1211282963674 ∧ code e1211282963674 = 5609329474778 := by decide
theorem cert_e1211282963674 : check e1211282963674 [[],[]] .chain = true := by decide
def e1211282963690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211282963690 : Closed e1211282963690 ∧ code e1211282963690 = 5609329474794 := by decide
theorem cert_e1211282963690 : check e1211282963690 [[],[]] .chain = true := by decide
def e1211282963718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282963718 : Closed e1211282963718 ∧ code e1211282963718 = 5609329474822 := by decide
theorem cert_e1211282963718 : check e1211282963718 [[],[]] .chain = true := by decide
def e1211282963742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211282963742 : Closed e1211282963742 ∧ code e1211282963742 = 5609329474846 := by decide
theorem cert_e1211282963742 : check e1211282963742 [[],[]] .sourceHead = true := by decide
def e1211282963766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282963766 : Closed e1211282963766 ∧ code e1211282963766 = 5609329474870 := by decide
theorem cert_e1211282963766 : check e1211282963766 [[],[]] .chain = true := by decide
def e1211282963770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282963770 : Closed e1211282963770 ∧ code e1211282963770 = 5609329474874 := by decide
theorem cert_e1211282963770 : check e1211282963770 [[],[]] .chain = true := by decide
def e1211282963866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282963866 : Closed e1211282963866 ∧ code e1211282963866 = 5609329474970 := by decide
theorem cert_e1211282963866 : check e1211282963866 [[],[]] .chain = true := by decide
def e1211282963910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211282963910 : Closed e1211282963910 ∧ code e1211282963910 = 5609329475014 := by decide
theorem cert_e1211282963910 : check e1211282963910 [[],[]] .sourceHead = true := by decide
def e1211282964606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211282964606 : Closed e1211282964606 ∧ code e1211282964606 = 5609329475710 := by decide
theorem cert_e1211282964606 : check e1211282964606 [[],[]] .chain = true := by decide
def e1211282965470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211282965470 : Closed e1211282965470 ∧ code e1211282965470 = 5609329476574 := by decide
theorem cert_e1211282965470 : check e1211282965470 [[],[]] .chain = true := by decide
def e1211282965474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211282965474 : Closed e1211282965474 ∧ code e1211282965474 = 5609329476578 := by decide
theorem cert_e1211282965474 : check e1211282965474 [[],[]] .chain = true := by decide
def e1211282965486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211282965486 : Closed e1211282965486 ∧ code e1211282965486 = 5609329476590 := by decide
theorem cert_e1211282965486 : check e1211282965486 [[],[]] .chain = true := by decide
def e1211282967406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211282967406 : Closed e1211282967406 ∧ code e1211282967406 = 5609329478510 := by decide
theorem cert_e1211282967406 : check e1211282967406 [[],[]] .chain = true := by decide
def e1211282967414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211282967414 : Closed e1211282967414 ∧ code e1211282967414 = 5609329478518 := by decide
theorem cert_e1211282967414 : check e1211282967414 [[],[]] .chain = true := by decide
def e1211282967470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211282967470 : Closed e1211282967470 ∧ code e1211282967470 = 5609329478574 := by decide
theorem cert_e1211282967470 : check e1211282967470 [[],[]] .chain = true := by decide
def e1211282967482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211282967482 : Closed e1211282967482 ∧ code e1211282967482 = 5609329478586 := by decide
theorem cert_e1211282967482 : check e1211282967482 [[],[]] .chain = true := by decide
def e1211282967510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211282967510 : Closed e1211282967510 ∧ code e1211282967510 = 5609329478614 := by decide
theorem cert_e1211282967510 : check e1211282967510 [[],[]] .chain = true := by decide
def e1211282967514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211282967514 : Closed e1211282967514 ∧ code e1211282967514 = 5609329478618 := by decide
theorem cert_e1211282967514 : check e1211282967514 [[],[]] .chain = true := by decide
def e1211282967790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211282967790 : Closed e1211282967790 ∧ code e1211282967790 = 5609329478894 := by decide
theorem cert_e1211282967790 : check e1211282967790 [[],[]] .chain = true := by decide
def e1211282967798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211282967798 : Closed e1211282967798 ∧ code e1211282967798 = 5609329478902 := by decide
theorem cert_e1211282967798 : check e1211282967798 [[],[]] .chain = true := by decide
def e1211282968174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211282968174 : Closed e1211282968174 ∧ code e1211282968174 = 5609329479278 := by decide
theorem cert_e1211282968174 : check e1211282968174 [[],[]] .chain = true := by decide
def e1211282968186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211282968186 : Closed e1211282968186 ∧ code e1211282968186 = 5609329479290 := by decide
theorem cert_e1211282968186 : check e1211282968186 [[],[]] .chain = true := by decide
def e1211282968326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282968326 : Closed e1211282968326 ∧ code e1211282968326 = 5609329479430 := by decide
theorem cert_e1211282968326 : check e1211282968326 [[],[]] .chain = true := by decide
def e1211282968350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211282968350 : Closed e1211282968350 ∧ code e1211282968350 = 5609329479454 := by decide
theorem cert_e1211282968350 : check e1211282968350 [[],[]] .sourceHead = true := by decide
def e1211282968374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282968374 : Closed e1211282968374 ∧ code e1211282968374 = 5609329479478 := by decide
theorem cert_e1211282968374 : check e1211282968374 [[],[]] .chain = true := by decide
def e1211282968378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282968378 : Closed e1211282968378 ∧ code e1211282968378 = 5609329479482 := by decide
theorem cert_e1211282968378 : check e1211282968378 [[],[]] .chain = true := by decide
def e1211282973150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211282973150 : Closed e1211282973150 ∧ code e1211282973150 = 5609329484254 := by decide
theorem cert_e1211282973150 : check e1211282973150 [[],[]] .chain = true := by decide
def e1211282973174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211282973174 : Closed e1211282973174 ∧ code e1211282973174 = 5609329484278 := by decide
theorem cert_e1211282973174 : check e1211282973174 [[],[]] .chain = true := by decide
def e1211282974126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211282974126 : Closed e1211282974126 ∧ code e1211282974126 = 5609329485230 := by decide
theorem cert_e1211282974126 : check e1211282974126 [[],[]] .chain = true := by decide
def e1211282974138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211282974138 : Closed e1211282974138 ∧ code e1211282974138 = 5609329485242 := by decide
theorem cert_e1211282974138 : check e1211282974138 [[],[]] .chain = true := by decide
def e1211282974186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211282974186 : Closed e1211282974186 ∧ code e1211282974186 = 5609329485290 := by decide
theorem cert_e1211282974186 : check e1211282974186 [[],[]] .chain = true := by decide
def e1211282974318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211282974318 : Closed e1211282974318 ∧ code e1211282974318 = 5609329485422 := by decide
theorem cert_e1211282974318 : check e1211282974318 [[],[]] .chain = true := by decide
def e1211282974330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211282974330 : Closed e1211282974330 ∧ code e1211282974330 = 5609329485434 := by decide
theorem cert_e1211282974330 : check e1211282974330 [[],[]] .chain = true := by decide
def e1211282974618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211282974618 : Closed e1211282974618 ∧ code e1211282974618 = 5609329485722 := by decide
theorem cert_e1211282974618 : check e1211282974618 [[],[]] .chain = true := by decide
def e1211282976798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211282976798 : Closed e1211282976798 ∧ code e1211282976798 = 5609329487902 := by decide
theorem cert_e1211282976798 : check e1211282976798 [[],[]] .chain = true := by decide
def e1211282976994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211282976994 : Closed e1211282976994 ∧ code e1211282976994 = 5609329488098 := by decide
theorem cert_e1211282976994 : check e1211282976994 [[],[]] .chain = true := by decide
def e1211282977006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211282977006 : Closed e1211282977006 ∧ code e1211282977006 = 5609329488110 := by decide
theorem cert_e1211282977006 : check e1211282977006 [[],[]] .chain = true := by decide
def e1211282977014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211282977014 : Closed e1211282977014 ∧ code e1211282977014 = 5609329488118 := by decide
theorem cert_e1211282977014 : check e1211282977014 [[],[]] .chain = true := by decide
def e1211282977494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211282977494 : Closed e1211282977494 ∧ code e1211282977494 = 5609329488598 := by decide
theorem cert_e1211282977494 : check e1211282977494 [[],[]] .chain = true := by decide
def e1211282977498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211282977498 : Closed e1211282977498 ∧ code e1211282977498 = 5609329488602 := by decide
theorem cert_e1211282977498 : check e1211282977498 [[],[]] .chain = true := by decide
def e1211282977514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211282977514 : Closed e1211282977514 ∧ code e1211282977514 = 5609329488618 := by decide
theorem cert_e1211282977514 : check e1211282977514 [[],[]] .chain = true := by decide
def e1211282977542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282977542 : Closed e1211282977542 ∧ code e1211282977542 = 5609329488646 := by decide
theorem cert_e1211282977542 : check e1211282977542 [[],[]] .chain = true := by decide
def e1211282977566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211282977566 : Closed e1211282977566 ∧ code e1211282977566 = 5609329488670 := by decide
theorem cert_e1211282977566 : check e1211282977566 [[],[]] .sourceHead = true := by decide
def e1211282977590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282977590 : Closed e1211282977590 ∧ code e1211282977590 = 5609329488694 := by decide
theorem cert_e1211282977590 : check e1211282977590 [[],[]] .chain = true := by decide
def e1211282977594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282977594 : Closed e1211282977594 ∧ code e1211282977594 = 5609329488698 := by decide
theorem cert_e1211282977594 : check e1211282977594 [[],[]] .chain = true := by decide
def e1211282977690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211282977690 : Closed e1211282977690 ∧ code e1211282977690 = 5609329488794 := by decide
theorem cert_e1211282977690 : check e1211282977690 [[],[]] .chain = true := by decide
def e1211282977734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211282977734 : Closed e1211282977734 ∧ code e1211282977734 = 5609329488838 := by decide
theorem cert_e1211282977734 : check e1211282977734 [[],[]] .sourceHead = true := by decide
def e1211282981110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211282981110 : Closed e1211282981110 ∧ code e1211282981110 = 5609329492214 := by decide
theorem cert_e1211282981110 : check e1211282981110 [[],[]] .chain = true := by decide
def e1211282981114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211282981114 : Closed e1211282981114 ∧ code e1211282981114 = 5609329492218 := by decide
theorem cert_e1211282981114 : check e1211282981114 [[],[]] .chain = true := by decide
def e1211282981686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282981686 : Closed e1211282981686 ∧ code e1211282981686 = 5609329492790 := by decide
theorem cert_e1211282981686 : check e1211282981686 [[],[]] .chain = true := by decide
def e1211282981690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282981690 : Closed e1211282981690 ∧ code e1211282981690 = 5609329492794 := by decide
theorem cert_e1211282981690 : check e1211282981690 [[],[]] .chain = true := by decide
def e1211282981774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211282981774 : Closed e1211282981774 ∧ code e1211282981774 = 5609329492878 := by decide
theorem cert_e1211282981774 : check e1211282981774 [[],[]] .chain = true := by decide
def e1211282981830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211282981830 : Closed e1211282981830 ∧ code e1211282981830 = 5609329492934 := by decide
theorem cert_e1211282981830 : check e1211282981830 [[],[]] .chain = true := by decide
def e1211282982678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211282982678 : Closed e1211282982678 ∧ code e1211282982678 = 5609329493782 := by decide
theorem cert_e1211282982678 : check e1211282982678 [[],[]] .chain = true := by decide
def e1211282982774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211282982774 : Closed e1211282982774 ∧ code e1211282982774 = 5609329493878 := by decide
theorem cert_e1211282982774 : check e1211282982774 [[],[]] .chain = true := by decide
def e1211282982794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211282982794 : Closed e1211282982794 ∧ code e1211282982794 = 5609329493898 := by decide
theorem cert_e1211282982794 : check e1211282982794 [[],[]] .chain = true := by decide
def e1211282982838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211282982838 : Closed e1211282982838 ∧ code e1211282982838 = 5609329493942 := by decide
theorem cert_e1211282982838 : check e1211282982838 [[],[]] .chain = true := by decide
def e1211282982842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e1211282982842 : Closed e1211282982842 ∧ code e1211282982842 = 5609329493946 := by decide
theorem cert_e1211282982842 : check e1211282982842 [[],[]] .chain = true := by decide
def e1211282983310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211282983310 : Closed e1211282983310 ∧ code e1211282983310 = 5609329494414 := by decide
theorem cert_e1211282983310 : check e1211282983310 [[],[]] .chain = true := by decide
def e1211282983366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211282983366 : Closed e1211282983366 ∧ code e1211282983366 = 5609329494470 := by decide
theorem cert_e1211282983366 : check e1211282983366 [[],[]] .chain = true := by decide
def e1211282983966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211282983966 : Closed e1211282983966 ∧ code e1211282983966 = 5609329495070 := by decide
theorem cert_e1211282983966 : check e1211282983966 [[],[]] .chain = true := by decide
def e1211282984162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211282984162 : Closed e1211282984162 ∧ code e1211282984162 = 5609329495266 := by decide
theorem cert_e1211282984162 : check e1211282984162 [[],[]] .chain = true := by decide
def e1211282984174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282984174 : Closed e1211282984174 ∧ code e1211282984174 = 5609329495278 := by decide
theorem cert_e1211282984174 : check e1211282984174 [[],[]] .sourceHead = true := by decide
def e1211282984182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282984182 : Closed e1211282984182 ∧ code e1211282984182 = 5609329495286 := by decide
theorem cert_e1211282984182 : check e1211282984182 [[],[]] .sourceHead = true := by decide
def e1211282984462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211282984462 : Closed e1211282984462 ∧ code e1211282984462 = 5609329495566 := by decide
theorem cert_e1211282984462 : check e1211282984462 [[],[]] .chain = true := by decide
def e1211282984546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211282984546 : Closed e1211282984546 ∧ code e1211282984546 = 5609329495650 := by decide
theorem cert_e1211282984546 : check e1211282984546 [[],[]] .chain = true := by decide
def e1211282984558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282984558 : Closed e1211282984558 ∧ code e1211282984558 = 5609329495662 := by decide
theorem cert_e1211282984558 : check e1211282984558 [[],[]] .sourceHead = true := by decide
def e1211282984570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282984570 : Closed e1211282984570 ∧ code e1211282984570 = 5609329495674 := by decide
theorem cert_e1211282984570 : check e1211282984570 [[],[]] .sourceHead = true := by decide
def e1211282984758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282984758 : Closed e1211282984758 ∧ code e1211282984758 = 5609329495862 := by decide
theorem cert_e1211282984758 : check e1211282984758 [[],[]] .sourceHead = true := by decide
def e1211282984762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282984762 : Closed e1211282984762 ∧ code e1211282984762 = 5609329495866 := by decide
theorem cert_e1211282984762 : check e1211282984762 [[],[]] .sourceHead = true := by decide
def e1211282986678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211282986678 : Closed e1211282986678 ∧ code e1211282986678 = 5609329497782 := by decide
theorem cert_e1211282986678 : check e1211282986678 [[],[]] .chain = true := by decide
def e1211282986710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211282986710 : Closed e1211282986710 ∧ code e1211282986710 = 5609329497814 := by decide
theorem cert_e1211282986710 : check e1211282986710 [[],[]] .chain = true := by decide
def e1211282986714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211282986714 : Closed e1211282986714 ∧ code e1211282986714 = 5609329497818 := by decide
theorem cert_e1211282986714 : check e1211282986714 [[],[]] .chain = true := by decide
def e1211282986838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211282986838 : Closed e1211282986838 ∧ code e1211282986838 = 5609329497942 := by decide
theorem cert_e1211282986838 : check e1211282986838 [[],[]] .chain = true := by decide
def e1211282986842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211282986842 : Closed e1211282986842 ∧ code e1211282986842 = 5609329497946 := by decide
theorem cert_e1211282986842 : check e1211282986842 [[],[]] .chain = true := by decide
def e1211282986858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211282986858 : Closed e1211282986858 ∧ code e1211282986858 = 5609329497962 := by decide
theorem cert_e1211282986858 : check e1211282986858 [[],[]] .chain = true := by decide
def e1211282987062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211282987062 : Closed e1211282987062 ∧ code e1211282987062 = 5609329498166 := by decide
theorem cert_e1211282987062 : check e1211282987062 [[],[]] .chain = true := by decide
def e1211282987150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211282987150 : Closed e1211282987150 ∧ code e1211282987150 = 5609329498254 := by decide
theorem cert_e1211282987150 : check e1211282987150 [[],[]] .chain = true := by decide
def e1211282987234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211282987234 : Closed e1211282987234 ∧ code e1211282987234 = 5609329498338 := by decide
theorem cert_e1211282987234 : check e1211282987234 [[],[]] .chain = true := by decide
def e1211282987246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211282987246 : Closed e1211282987246 ∧ code e1211282987246 = 5609329498350 := by decide
theorem cert_e1211282987246 : check e1211282987246 [[],[]] .sourceHead = true := by decide
def e1211282987254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211282987254 : Closed e1211282987254 ∧ code e1211282987254 = 5609329498358 := by decide
theorem cert_e1211282987254 : check e1211282987254 [[],[]] .sourceHead = true := by decide
def e1211282987446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211282987446 : Closed e1211282987446 ∧ code e1211282987446 = 5609329498550 := by decide
theorem cert_e1211282987446 : check e1211282987446 [[],[]] .chain = true := by decide
def e1211282987478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211282987478 : Closed e1211282987478 ∧ code e1211282987478 = 5609329498582 := by decide
theorem cert_e1211282987478 : check e1211282987478 [[],[]] .chain = true := by decide
def e1211282987482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211282987482 : Closed e1211282987482 ∧ code e1211282987482 = 5609329498586 := by decide
theorem cert_e1211282987482 : check e1211282987482 [[],[]] .chain = true := by decide
def e1211282987638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282987638 : Closed e1211282987638 ∧ code e1211282987638 = 5609329498742 := by decide
theorem cert_e1211282987638 : check e1211282987638 [[],[]] .chain = true := by decide
def e1211282987782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282987782 : Closed e1211282987782 ∧ code e1211282987782 = 5609329498886 := by decide
theorem cert_e1211282987782 : check e1211282987782 [[],[]] .chain = true := by decide
def e1211282987806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211282987806 : Closed e1211282987806 ∧ code e1211282987806 = 5609329498910 := by decide
theorem cert_e1211282987806 : check e1211282987806 [[],[]] .sourceHead = true := by decide
def e1211282987830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282987830 : Closed e1211282987830 ∧ code e1211282987830 = 5609329498934 := by decide
theorem cert_e1211282987830 : check e1211282987830 [[],[]] .chain = true := by decide
def e1211282987834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282987834 : Closed e1211282987834 ∧ code e1211282987834 = 5609329498938 := by decide
theorem cert_e1211282987834 : check e1211282987834 [[],[]] .chain = true := by decide
def e1211282987918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211282987918 : Closed e1211282987918 ∧ code e1211282987918 = 5609329499022 := by decide
theorem cert_e1211282987918 : check e1211282987918 [[],[]] .sourceHead = true := by decide
def e1211282988058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211282988058 : Closed e1211282988058 ∧ code e1211282988058 = 5609329499162 := by decide
theorem cert_e1211282988058 : check e1211282988058 [[],[]] .chain = true := by decide
def e1211282988102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211282988102 : Closed e1211282988102 ∧ code e1211282988102 = 5609329499206 := by decide
theorem cert_e1211282988102 : check e1211282988102 [[],[]] .chain = true := by decide
def e1211282988130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211282988130 : Closed e1211282988130 ∧ code e1211282988130 = 5609329499234 := by decide
theorem cert_e1211282988130 : check e1211282988130 [[],[]] .chain = true := by decide
def e1211282988142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211282988142 : Closed e1211282988142 ∧ code e1211282988142 = 5609329499246 := by decide
theorem cert_e1211282988142 : check e1211282988142 [[],[]] .sourceHead = true := by decide
def e1211282988154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211282988154 : Closed e1211282988154 ∧ code e1211282988154 = 5609329499258 := by decide
theorem cert_e1211282988154 : check e1211282988154 [[],[]] .sourceHead = true := by decide
def e1211282988246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211282988246 : Closed e1211282988246 ∧ code e1211282988246 = 5609329499350 := by decide
theorem cert_e1211282988246 : check e1211282988246 [[],[]] .chain = true := by decide
def e1211282988250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211282988250 : Closed e1211282988250 ∧ code e1211282988250 = 5609329499354 := by decide
theorem cert_e1211282988250 : check e1211282988250 [[],[]] .chain = true := by decide
def e1211282988266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211282988266 : Closed e1211282988266 ∧ code e1211282988266 = 5609329499370 := by decide
theorem cert_e1211282988266 : check e1211282988266 [[],[]] .chain = true := by decide
def e1211282988294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282988294 : Closed e1211282988294 ∧ code e1211282988294 = 5609329499398 := by decide
theorem cert_e1211282988294 : check e1211282988294 [[],[]] .chain = true := by decide
def e1211282988318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211282988318 : Closed e1211282988318 ∧ code e1211282988318 = 5609329499422 := by decide
theorem cert_e1211282988318 : check e1211282988318 [[],[]] .sourceHead = true := by decide
def e1211282988342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282988342 : Closed e1211282988342 ∧ code e1211282988342 = 5609329499446 := by decide
theorem cert_e1211282988342 : check e1211282988342 [[],[]] .chain = true := by decide
def e1211282988346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282988346 : Closed e1211282988346 ∧ code e1211282988346 = 5609329499450 := by decide
theorem cert_e1211282988346 : check e1211282988346 [[],[]] .chain = true := by decide
def e1211282988442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282988442 : Closed e1211282988442 ∧ code e1211282988442 = 5609329499546 := by decide
theorem cert_e1211282988442 : check e1211282988442 [[],[]] .chain = true := by decide
def e1211282988486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211282988486 : Closed e1211282988486 ∧ code e1211282988486 = 5609329499590 := by decide
theorem cert_e1211282988486 : check e1211282988486 [[],[]] .sourceHead = true := by decide
def e1211282988598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211282988598 : Closed e1211282988598 ∧ code e1211282988598 = 5609329499702 := by decide
theorem cert_e1211282988598 : check e1211282988598 [[],[]] .sourceHead = true := by decide
def e1211282988602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211282988602 : Closed e1211282988602 ∧ code e1211282988602 = 5609329499706 := by decide
theorem cert_e1211282988602 : check e1211282988602 [[],[]] .sourceHead = true := by decide
def e1211282988686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211282988686 : Closed e1211282988686 ∧ code e1211282988686 = 5609329499790 := by decide
theorem cert_e1211282988686 : check e1211282988686 [[],[]] .sourceHead = true := by decide
def e1211282988742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211282988742 : Closed e1211282988742 ∧ code e1211282988742 = 5609329499846 := by decide
theorem cert_e1211282988742 : check e1211282988742 [[],[]] .sourceHead = true := by decide
def e1211282989118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211282989118 : Closed e1211282989118 ∧ code e1211282989118 = 5609329500222 := by decide
theorem cert_e1211282989118 : check e1211282989118 [[],[]] .chain = true := by decide
def e1211282989538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211282989538 : Closed e1211282989538 ∧ code e1211282989538 = 5609329500642 := by decide
theorem cert_e1211282989538 : check e1211282989538 [[],[]] .chain = true := by decide
def e1211282989550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211282989550 : Closed e1211282989550 ∧ code e1211282989550 = 5609329500654 := by decide
theorem cert_e1211282989550 : check e1211282989550 [[],[]] .chain = true := by decide
def e1211282990518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211282990518 : Closed e1211282990518 ∧ code e1211282990518 = 5609329501622 := by decide
theorem cert_e1211282990518 : check e1211282990518 [[],[]] .chain = true := by decide
def e1211282990550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211282990550 : Closed e1211282990550 ∧ code e1211282990550 = 5609329501654 := by decide
theorem cert_e1211282990550 : check e1211282990550 [[],[]] .chain = true := by decide
def e1211282990554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211282990554 : Closed e1211282990554 ∧ code e1211282990554 = 5609329501658 := by decide
theorem cert_e1211282990554 : check e1211282990554 [[],[]] .chain = true := by decide
def e1211282990710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211282990710 : Closed e1211282990710 ∧ code e1211282990710 = 5609329501814 := by decide
theorem cert_e1211282990710 : check e1211282990710 [[],[]] .chain = true := by decide
def e1211282990854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282990854 : Closed e1211282990854 ∧ code e1211282990854 = 5609329501958 := by decide
theorem cert_e1211282990854 : check e1211282990854 [[],[]] .chain = true := by decide
def e1211282990878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211282990878 : Closed e1211282990878 ∧ code e1211282990878 = 5609329501982 := by decide
theorem cert_e1211282990878 : check e1211282990878 [[],[]] .sourceHead = true := by decide
def e1211282990902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282990902 : Closed e1211282990902 ∧ code e1211282990902 = 5609329502006 := by decide
theorem cert_e1211282990902 : check e1211282990902 [[],[]] .chain = true := by decide
def e1211282990906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282990906 : Closed e1211282990906 ∧ code e1211282990906 = 5609329502010 := by decide
theorem cert_e1211282990906 : check e1211282990906 [[],[]] .chain = true := by decide
def e1211282990990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211282990990 : Closed e1211282990990 ∧ code e1211282990990 = 5609329502094 := by decide
theorem cert_e1211282990990 : check e1211282990990 [[],[]] .sourceHead = true := by decide
def e1211282993182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211282993182 : Closed e1211282993182 ∧ code e1211282993182 = 5609329504286 := by decide
theorem cert_e1211282993182 : check e1211282993182 [[],[]] .chain = true := by decide
def e1211282993378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211282993378 : Closed e1211282993378 ∧ code e1211282993378 = 5609329504482 := by decide
theorem cert_e1211282993378 : check e1211282993378 [[],[]] .chain = true := by decide
def e1211282993390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211282993390 : Closed e1211282993390 ∧ code e1211282993390 = 5609329504494 := by decide
theorem cert_e1211282993390 : check e1211282993390 [[],[]] .chain = true := by decide
def e1211282993398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211282993398 : Closed e1211282993398 ∧ code e1211282993398 = 5609329504502 := by decide
theorem cert_e1211282993398 : check e1211282993398 [[],[]] .chain = true := by decide
def e1211282993878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211282993878 : Closed e1211282993878 ∧ code e1211282993878 = 5609329504982 := by decide
theorem cert_e1211282993878 : check e1211282993878 [[],[]] .chain = true := by decide
def e1211282993882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211282993882 : Closed e1211282993882 ∧ code e1211282993882 = 5609329504986 := by decide
theorem cert_e1211282993882 : check e1211282993882 [[],[]] .chain = true := by decide
def e1211282993898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211282993898 : Closed e1211282993898 ∧ code e1211282993898 = 5609329505002 := by decide
theorem cert_e1211282993898 : check e1211282993898 [[],[]] .chain = true := by decide
def e1211282993926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282993926 : Closed e1211282993926 ∧ code e1211282993926 = 5609329505030 := by decide
theorem cert_e1211282993926 : check e1211282993926 [[],[]] .chain = true := by decide
def e1211282993950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211282993950 : Closed e1211282993950 ∧ code e1211282993950 = 5609329505054 := by decide
theorem cert_e1211282993950 : check e1211282993950 [[],[]] .sourceHead = true := by decide
def e1211282993974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282993974 : Closed e1211282993974 ∧ code e1211282993974 = 5609329505078 := by decide
theorem cert_e1211282993974 : check e1211282993974 [[],[]] .chain = true := by decide
def e1211282993978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282993978 : Closed e1211282993978 ∧ code e1211282993978 = 5609329505082 := by decide
theorem cert_e1211282993978 : check e1211282993978 [[],[]] .chain = true := by decide
def e1211282994074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211282994074 : Closed e1211282994074 ∧ code e1211282994074 = 5609329505178 := by decide
theorem cert_e1211282994074 : check e1211282994074 [[],[]] .chain = true := by decide
def e1211282994118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211282994118 : Closed e1211282994118 ∧ code e1211282994118 = 5609329505222 := by decide
theorem cert_e1211282994118 : check e1211282994118 [[],[]] .sourceHead = true := by decide
def e1211282995598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211282995598 : Closed e1211282995598 ∧ code e1211282995598 = 5609329506702 := by decide
theorem cert_e1211282995598 : check e1211282995598 [[],[]] .sourceHead = true := by decide
def e1211282995654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211282995654 : Closed e1211282995654 ∧ code e1211282995654 = 5609329506758 := by decide
theorem cert_e1211282995654 : check e1211282995654 [[],[]] .sourceHead = true := by decide
def e1211283019486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211283019486 : Closed e1211283019486 ∧ code e1211283019486 = 5609329530590 := by decide
theorem cert_e1211283019486 : check e1211283019486 [[],[]] .smaller = true := by decide
def e1211283019510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211283019510 : Closed e1211283019510 ∧ code e1211283019510 = 5609329530614 := by decide
theorem cert_e1211283019510 : check e1211283019510 [[],[]] .smaller = true := by decide
def e1211283019614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211283019614 : Closed e1211283019614 ∧ code e1211283019614 = 5609329530718 := by decide
theorem cert_e1211283019614 : check e1211283019614 [[],[]] .smaller = true := by decide
def e1211283019642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211283019642 : Closed e1211283019642 ∧ code e1211283019642 = 5609329530746 := by decide
theorem cert_e1211283019642 : check e1211283019642 [[],[]] .smaller = true := by decide
def e1211283019734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211283019734 : Closed e1211283019734 ∧ code e1211283019734 = 5609329530838 := by decide
theorem cert_e1211283019734 : check e1211283019734 [[],[]] .smaller = true := by decide
def e1211283019738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211283019738 : Closed e1211283019738 ∧ code e1211283019738 = 5609329530842 := by decide
theorem cert_e1211283019738 : check e1211283019738 [[],[]] .smaller = true := by decide
def e1211283020254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211283020254 : Closed e1211283020254 ∧ code e1211283020254 = 5609329531358 := by decide
theorem cert_e1211283020254 : check e1211283020254 [[],[]] .smaller = true := by decide
def e1211283020278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211283020278 : Closed e1211283020278 ∧ code e1211283020278 = 5609329531382 := by decide
theorem cert_e1211283020278 : check e1211283020278 [[],[]] .smaller = true := by decide
end Blc.Floor42
