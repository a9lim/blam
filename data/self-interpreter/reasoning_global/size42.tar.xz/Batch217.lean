import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207612166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207612166 : Closed e1211207612166 ∧ code e1211207612166 = 5609254123270 := by decide
theorem cert_e1211207612166 : check e1211207612166 [[],[]] .chain = true := by decide
def e1211207612190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211207612190 : Closed e1211207612190 ∧ code e1211207612190 = 5609254123294 := by decide
theorem cert_e1211207612190 : check e1211207612190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207612214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207612214 : Closed e1211207612214 ∧ code e1211207612214 = 5609254123318 := by decide
theorem cert_e1211207612214 : check e1211207612214 [[],[]] .chain = true := by decide
def e1211207612218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207612218 : Closed e1211207612218 ∧ code e1211207612218 = 5609254123322 := by decide
theorem cert_e1211207612218 : check e1211207612218 [[],[]] .chain = true := by decide
def e1211207612470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211207612470 : Closed e1211207612470 ∧ code e1211207612470 = 5609254123574 := by decide
theorem cert_e1211207612470 : check e1211207612470 [[],[]] .chain = true := by decide
def e1211207612558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211207612558 : Closed e1211207612558 ∧ code e1211207612558 = 5609254123662 := by decide
theorem cert_e1211207612558 : check e1211207612558 [[],[]] .chain = true := by decide
def e1211207612642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211207612642 : Closed e1211207612642 ∧ code e1211207612642 = 5609254123746 := by decide
theorem cert_e1211207612642 : check e1211207612642 [[],[]] .chain = true := by decide
def e1211207612654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211207612654 : Closed e1211207612654 ∧ code e1211207612654 = 5609254123758 := by decide
theorem cert_e1211207612654 : checkPay e1211207612654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e1211207612662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211207612662 : Closed e1211207612662 ∧ code e1211207612662 = 5609254123766 := by decide
theorem cert_e1211207612662 : check e1211207612662 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207612854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211207612854 : Closed e1211207612854 ∧ code e1211207612854 = 5609254123958 := by decide
theorem cert_e1211207612854 : check e1211207612854 [[],[]] .chain = true := by decide
def e1211207612886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211207612886 : Closed e1211207612886 ∧ code e1211207612886 = 5609254123990 := by decide
theorem cert_e1211207612886 : check e1211207612886 [[],[]] .chain = true := by decide
def e1211207612890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211207612890 : Closed e1211207612890 ∧ code e1211207612890 = 5609254123994 := by decide
theorem cert_e1211207612890 : check e1211207612890 [[],[]] .chain = true := by decide
def e1211207613046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207613046 : Closed e1211207613046 ∧ code e1211207613046 = 5609254124150 := by decide
theorem cert_e1211207613046 : check e1211207613046 [[],[]] .chain = true := by decide
def e1211207613190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207613190 : Closed e1211207613190 ∧ code e1211207613190 = 5609254124294 := by decide
theorem cert_e1211207613190 : check e1211207613190 [[],[]] .chain = true := by decide
def e1211207613214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211207613214 : Closed e1211207613214 ∧ code e1211207613214 = 5609254124318 := by decide
theorem cert_e1211207613214 : check e1211207613214 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211207613238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207613238 : Closed e1211207613238 ∧ code e1211207613238 = 5609254124342 := by decide
theorem cert_e1211207613238 : check e1211207613238 [[],[]] .chain = true := by decide
def e1211207613242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207613242 : Closed e1211207613242 ∧ code e1211207613242 = 5609254124346 := by decide
theorem cert_e1211207613242 : check e1211207613242 [[],[]] .chain = true := by decide
def e1211207613326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211207613326 : Closed e1211207613326 ∧ code e1211207613326 = 5609254124430 := by decide
theorem cert_e1211207613326 : check e1211207613326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211207620462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211207620462 : Closed e1211207620462 ∧ code e1211207620462 = 5609254131566 := by decide
theorem cert_e1211207620462 : check e1211207620462 [[],[]] .chain = true := by decide
def e1211207620470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211207620470 : Closed e1211207620470 ∧ code e1211207620470 = 5609254131574 := by decide
theorem cert_e1211207620470 : check e1211207620470 [[],[]] .chain = true := by decide
def e1211207620534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211207620534 : Closed e1211207620534 ∧ code e1211207620534 = 5609254131638 := by decide
theorem cert_e1211207620534 : check e1211207620534 [[],[]] .chain = true := by decide
def e1211207621870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207621870 : Closed e1211207621870 ∧ code e1211207621870 = 5609254132974 := by decide
theorem cert_e1211207621870 : check e1211207621870 [[],[]] .chain = true := by decide
def e1211207621878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207621878 : Closed e1211207621878 ∧ code e1211207621878 = 5609254132982 := by decide
theorem cert_e1211207621878 : check e1211207621878 [[],[]] .chain = true := by decide
def e1211207622262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211207622262 : Closed e1211207622262 ∧ code e1211207622262 = 5609254133366 := by decide
theorem cert_e1211207622262 : check e1211207622262 [[],[]] .chain = true := by decide
def e1211207630974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211207630974 : Closed e1211207630974 ∧ code e1211207630974 = 5609254142078 := by decide
theorem cert_e1211207630974 : check e1211207630974 [[],[]] .chain = true := by decide
def e1211207631838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211207631838 : Closed e1211207631838 ∧ code e1211207631838 = 5609254142942 := by decide
theorem cert_e1211207631838 : check e1211207631838 [[],[]] .chain = true := by decide
def e1211207631842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211207631842 : Closed e1211207631842 ∧ code e1211207631842 = 5609254142946 := by decide
theorem cert_e1211207631842 : check e1211207631842 [[],[]] .chain = true := by decide
def e1211207631854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211207631854 : Closed e1211207631854 ∧ code e1211207631854 = 5609254142958 := by decide
theorem cert_e1211207631854 : check e1211207631854 [[],[]] .chain = true := by decide
def e1211207633774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211207633774 : Closed e1211207633774 ∧ code e1211207633774 = 5609254144878 := by decide
theorem cert_e1211207633774 : check e1211207633774 [[],[]] .chain = true := by decide
def e1211207633782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211207633782 : Closed e1211207633782 ∧ code e1211207633782 = 5609254144886 := by decide
theorem cert_e1211207633782 : check e1211207633782 [[],[]] .chain = true := by decide
def e1211207633838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211207633838 : Closed e1211207633838 ∧ code e1211207633838 = 5609254144942 := by decide
theorem cert_e1211207633838 : check e1211207633838 [[],[]] .chain = true := by decide
def e1211207633850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211207633850 : Closed e1211207633850 ∧ code e1211207633850 = 5609254144954 := by decide
theorem cert_e1211207633850 : check e1211207633850 [[],[]] .chain = true := by decide
def e1211207633878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211207633878 : Closed e1211207633878 ∧ code e1211207633878 = 5609254144982 := by decide
theorem cert_e1211207633878 : check e1211207633878 [[],[]] .chain = true := by decide
def e1211207633882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211207633882 : Closed e1211207633882 ∧ code e1211207633882 = 5609254144986 := by decide
theorem cert_e1211207633882 : check e1211207633882 [[],[]] .chain = true := by decide
def e1211207634158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207634158 : Closed e1211207634158 ∧ code e1211207634158 = 5609254145262 := by decide
theorem cert_e1211207634158 : check e1211207634158 [[],[]] .chain = true := by decide
def e1211207634166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207634166 : Closed e1211207634166 ∧ code e1211207634166 = 5609254145270 := by decide
theorem cert_e1211207634166 : check e1211207634166 [[],[]] .chain = true := by decide
def e1211207634542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207634542 : Closed e1211207634542 ∧ code e1211207634542 = 5609254145646 := by decide
theorem cert_e1211207634542 : check e1211207634542 [[],[]] .chain = true := by decide
def e1211207634554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207634554 : Closed e1211207634554 ∧ code e1211207634554 = 5609254145658 := by decide
theorem cert_e1211207634554 : check e1211207634554 [[],[]] .chain = true := by decide
def e1211207634694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207634694 : Closed e1211207634694 ∧ code e1211207634694 = 5609254145798 := by decide
theorem cert_e1211207634694 : check e1211207634694 [[],[]] .chain = true := by decide
def e1211207634718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211207634718 : Closed e1211207634718 ∧ code e1211207634718 = 5609254145822 := by decide
theorem cert_e1211207634718 : check e1211207634718 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207634742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207634742 : Closed e1211207634742 ∧ code e1211207634742 = 5609254145846 := by decide
theorem cert_e1211207634742 : check e1211207634742 [[],[]] .chain = true := by decide
def e1211207634746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207634746 : Closed e1211207634746 ∧ code e1211207634746 = 5609254145850 := by decide
theorem cert_e1211207634746 : check e1211207634746 [[],[]] .chain = true := by decide
def e1211207639102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211207639102 : Closed e1211207639102 ∧ code e1211207639102 = 5609254150206 := by decide
theorem cert_e1211207639102 : check e1211207639102 [[],[]] .chain = true := by decide
def e1211207639522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211207639522 : Closed e1211207639522 ∧ code e1211207639522 = 5609254150626 := by decide
theorem cert_e1211207639522 : check e1211207639522 [[],[]] .chain = true := by decide
def e1211207639534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211207639534 : Closed e1211207639534 ∧ code e1211207639534 = 5609254150638 := by decide
theorem cert_e1211207639534 : check e1211207639534 [[],[]] .chain = true := by decide
def e1211207640502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211207640502 : Closed e1211207640502 ∧ code e1211207640502 = 5609254151606 := by decide
theorem cert_e1211207640502 : check e1211207640502 [[],[]] .chain = true := by decide
def e1211207640534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211207640534 : Closed e1211207640534 ∧ code e1211207640534 = 5609254151638 := by decide
theorem cert_e1211207640534 : check e1211207640534 [[],[]] .chain = true := by decide
def e1211207640538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211207640538 : Closed e1211207640538 ∧ code e1211207640538 = 5609254151642 := by decide
theorem cert_e1211207640538 : check e1211207640538 [[],[]] .chain = true := by decide
def e1211207640694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211207640694 : Closed e1211207640694 ∧ code e1211207640694 = 5609254151798 := by decide
theorem cert_e1211207640694 : check e1211207640694 [[],[]] .chain = true := by decide
def e1211207640838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207640838 : Closed e1211207640838 ∧ code e1211207640838 = 5609254151942 := by decide
theorem cert_e1211207640838 : check e1211207640838 [[],[]] .chain = true := by decide
def e1211207640862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211207640862 : Closed e1211207640862 ∧ code e1211207640862 = 5609254151966 := by decide
theorem cert_e1211207640862 : check e1211207640862 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207640886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207640886 : Closed e1211207640886 ∧ code e1211207640886 = 5609254151990 := by decide
theorem cert_e1211207640886 : check e1211207640886 [[],[]] .chain = true := by decide
def e1211207640890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207640890 : Closed e1211207640890 ∧ code e1211207640890 = 5609254151994 := by decide
theorem cert_e1211207640890 : check e1211207640890 [[],[]] .chain = true := by decide
def e1211207640974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211207640974 : Closed e1211207640974 ∧ code e1211207640974 = 5609254152078 := by decide
theorem cert_e1211207640974 : check e1211207640974 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207781230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211207781230 : Closed e1211207781230 ∧ code e1211207781230 = 5609254292334 := by decide
theorem cert_e1211207781230 : check e1211207781230 [[],[]] .smaller = true := by decide
def e1211207781238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211207781238 : Closed e1211207781238 ∧ code e1211207781238 = 5609254292342 := by decide
theorem cert_e1211207781238 : check e1211207781238 [[],[]] .smaller = true := by decide
def e1211207781294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211207781294 : Closed e1211207781294 ∧ code e1211207781294 = 5609254292398 := by decide
theorem cert_e1211207781294 : check e1211207781294 [[],[]] .smaller = true := by decide
def e1211207781306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211207781306 : Closed e1211207781306 ∧ code e1211207781306 = 5609254292410 := by decide
theorem cert_e1211207781306 : check e1211207781306 [[],[]] .smaller = true := by decide
def e1211207781334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211207781334 : Closed e1211207781334 ∧ code e1211207781334 = 5609254292438 := by decide
theorem cert_e1211207781334 : check e1211207781334 [[],[]] .smaller = true := by decide
def e1211207781338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211207781338 : Closed e1211207781338 ∧ code e1211207781338 = 5609254292442 := by decide
theorem cert_e1211207781338 : check e1211207781338 [[],[]] .smaller = true := by decide
def e1211207781614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211207781614 : Closed e1211207781614 ∧ code e1211207781614 = 5609254292718 := by decide
theorem cert_e1211207781614 : check e1211207781614 [[],[]] .smaller = true := by decide
def e1211207781622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211207781622 : Closed e1211207781622 ∧ code e1211207781622 = 5609254292726 := by decide
theorem cert_e1211207781622 : check e1211207781622 [[],[]] .smaller = true := by decide
def e1211207781998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211207781998 : Closed e1211207781998 ∧ code e1211207781998 = 5609254293102 := by decide
theorem cert_e1211207781998 : check e1211207781998 [[],[]] .smaller = true := by decide
def e1211207782010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211207782010 : Closed e1211207782010 ∧ code e1211207782010 = 5609254293114 := by decide
theorem cert_e1211207782010 : check e1211207782010 [[],[]] .smaller = true := by decide
def e1211207782198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211207782198 : Closed e1211207782198 ∧ code e1211207782198 = 5609254293302 := by decide
theorem cert_e1211207782198 : check e1211207782198 [[],[]] .smaller = true := by decide
def e1211207782202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211207782202 : Closed e1211207782202 ∧ code e1211207782202 = 5609254293306 := by decide
theorem cert_e1211207782202 : check e1211207782202 [[],[]] .smaller = true := by decide
def e1211207782334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211207782334 : Closed e1211207782334 ∧ code e1211207782334 = 5609254293438 := by decide
theorem cert_e1211207782334 : check e1211207782334 [[],[]] .chain = true := by decide
def e1211207782366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211207782366 : Closed e1211207782366 ∧ code e1211207782366 = 5609254293470 := by decide
theorem cert_e1211207782366 : check e1211207782366 [[],[]] .chain = true := by decide
def e1211207790046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211207790046 : Closed e1211207790046 ∧ code e1211207790046 = 5609254301150 := by decide
theorem cert_e1211207790046 : check e1211207790046 [[],[]] .chain = true := by decide
def e1211207790062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211207790062 : Closed e1211207790062 ∧ code e1211207790062 = 5609254301166 := by decide
theorem cert_e1211207790062 : check e1211207790062 [[],[]] .chain = true := by decide
def e1211207790302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211207790302 : Closed e1211207790302 ∧ code e1211207790302 = 5609254301406 := by decide
theorem cert_e1211207790302 : check e1211207790302 [[],[]] .chain = true := by decide
def e1211207790326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211207790326 : Closed e1211207790326 ∧ code e1211207790326 = 5609254301430 := by decide
theorem cert_e1211207790326 : check e1211207790326 [[],[]] .chain = true := by decide
def e1211207790430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211207790430 : Closed e1211207790430 ∧ code e1211207790430 = 5609254301534 := by decide
theorem cert_e1211207790430 : check e1211207790430 [[],[]] .chain = true := by decide
def e1211207790458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211207790458 : Closed e1211207790458 ∧ code e1211207790458 = 5609254301562 := by decide
theorem cert_e1211207790458 : check e1211207790458 [[],[]] .chain = true := by decide
def e1211207790510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211207790510 : Closed e1211207790510 ∧ code e1211207790510 = 5609254301614 := by decide
theorem cert_e1211207790510 : check e1211207790510 [[],[]] .chain = true := by decide
def e1211207790518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211207790518 : Closed e1211207790518 ∧ code e1211207790518 = 5609254301622 := by decide
theorem cert_e1211207790518 : check e1211207790518 [[],[]] .chain = true := by decide
def e1211207790522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211207790522 : Closed e1211207790522 ∧ code e1211207790522 = 5609254301626 := by decide
theorem cert_e1211207790522 : check e1211207790522 [[],[]] .chain = true := by decide
def e1211207791582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211207791582 : Closed e1211207791582 ∧ code e1211207791582 = 5609254302686 := by decide
theorem cert_e1211207791582 : check e1211207791582 [[],[]] .chain = true := by decide
def e1211207791598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211207791598 : Closed e1211207791598 ∧ code e1211207791598 = 5609254302702 := by decide
theorem cert_e1211207791598 : check e1211207791598 [[],[]] .chain = true := by decide
def e1211207793118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211207793118 : Closed e1211207793118 ∧ code e1211207793118 = 5609254304222 := by decide
theorem cert_e1211207793118 : check e1211207793118 [[],[]] .chain = true := by decide
def e1211207793142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211207793142 : Closed e1211207793142 ∧ code e1211207793142 = 5609254304246 := by decide
theorem cert_e1211207793142 : check e1211207793142 [[],[]] .chain = true := by decide
def e1211207793886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211207793886 : Closed e1211207793886 ∧ code e1211207793886 = 5609254304990 := by decide
theorem cert_e1211207793886 : check e1211207793886 [[],[]] .chain = true := by decide
def e1211207793914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211207793914 : Closed e1211207793914 ∧ code e1211207793914 = 5609254305018 := by decide
theorem cert_e1211207793914 : check e1211207793914 [[],[]] .chain = true := by decide
def e1211207794202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211207794202 : Closed e1211207794202 ∧ code e1211207794202 = 5609254305306 := by decide
theorem cert_e1211207794202 : check e1211207794202 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207794238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e1211207794238 : Closed e1211207794238 ∧ code e1211207794238 = 5609254305342 := by decide
theorem cert_e1211207794238 : check e1211207794238 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207794286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207794286 : Closed e1211207794286 ∧ code e1211207794286 = 5609254305390 := by decide
theorem cert_e1211207794286 : check e1211207794286 [[],[]] .chain = true := by decide
def e1211207794294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211207794294 : Closed e1211207794294 ∧ code e1211207794294 = 5609254305398 := by decide
theorem cert_e1211207794294 : check e1211207794294 [[],[]] .chain = true := by decide
def e1211207794298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207794298 : Closed e1211207794298 ∧ code e1211207794298 = 5609254305402 := by decide
theorem cert_e1211207794298 : check e1211207794298 [[],[]] .chain = true := by decide
def e1211207822702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211207822702 : Closed e1211207822702 ∧ code e1211207822702 = 5609254333806 := by decide
theorem cert_e1211207822702 : check e1211207822702 [[],[]] .chain = true := by decide
def e1211207822710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211207822710 : Closed e1211207822710 ∧ code e1211207822710 = 5609254333814 := by decide
theorem cert_e1211207822710 : check e1211207822710 [[],[]] .chain = true := by decide
def e1211207822766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211207822766 : Closed e1211207822766 ∧ code e1211207822766 = 5609254333870 := by decide
theorem cert_e1211207822766 : check e1211207822766 [[],[]] .chain = true := by decide
def e1211207822778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211207822778 : Closed e1211207822778 ∧ code e1211207822778 = 5609254333882 := by decide
theorem cert_e1211207822778 : check e1211207822778 [[],[]] .chain = true := by decide
def e1211207822806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211207822806 : Closed e1211207822806 ∧ code e1211207822806 = 5609254333910 := by decide
theorem cert_e1211207822806 : check e1211207822806 [[],[]] .chain = true := by decide
def e1211207822810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211207822810 : Closed e1211207822810 ∧ code e1211207822810 = 5609254333914 := by decide
theorem cert_e1211207822810 : check e1211207822810 [[],[]] .chain = true := by decide
def e1211207823022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211207823022 : Closed e1211207823022 ∧ code e1211207823022 = 5609254334126 := by decide
theorem cert_e1211207823022 : check e1211207823022 [[],[]] .chain = true := by decide
def e1211207823034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211207823034 : Closed e1211207823034 ∧ code e1211207823034 = 5609254334138 := by decide
theorem cert_e1211207823034 : check e1211207823034 [[],[]] .chain = true := by decide
def e1211207823082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211207823082 : Closed e1211207823082 ∧ code e1211207823082 = 5609254334186 := by decide
theorem cert_e1211207823082 : check e1211207823082 [[],[]] .chain = true := by decide
def e1211207823190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211207823190 : Closed e1211207823190 ∧ code e1211207823190 = 5609254334294 := by decide
theorem cert_e1211207823190 : check e1211207823190 [[],[]] .chain = true := by decide
def e1211207823194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211207823194 : Closed e1211207823194 ∧ code e1211207823194 = 5609254334298 := by decide
theorem cert_e1211207823194 : check e1211207823194 [[],[]] .chain = true := by decide
def e1211207823210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211207823210 : Closed e1211207823210 ∧ code e1211207823210 = 5609254334314 := by decide
theorem cert_e1211207823210 : check e1211207823210 [[],[]] .chain = true := by decide
def e1211207823470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211207823470 : Closed e1211207823470 ∧ code e1211207823470 = 5609254334574 := by decide
theorem cert_e1211207823470 : check e1211207823470 [[],[]] .chain = true := by decide
def e1211207823646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211207823646 : Closed e1211207823646 ∧ code e1211207823646 = 5609254334750 := by decide
theorem cert_e1211207823646 : check e1211207823646 [[],[]] .chain = true := by decide
def e1211207823842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211207823842 : Closed e1211207823842 ∧ code e1211207823842 = 5609254334946 := by decide
theorem cert_e1211207823842 : check e1211207823842 [[],[]] .chain = true := by decide
def e1211207823854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211207823854 : Closed e1211207823854 ∧ code e1211207823854 = 5609254334958 := by decide
theorem cert_e1211207823854 : check e1211207823854 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207824238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211207824238 : Closed e1211207824238 ∧ code e1211207824238 = 5609254335342 := by decide
theorem cert_e1211207824238 : check e1211207824238 [[],[]] .chain = true := by decide
def e1211207824246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211207824246 : Closed e1211207824246 ∧ code e1211207824246 = 5609254335350 := by decide
theorem cert_e1211207824246 : check e1211207824246 [[],[]] .chain = true := by decide
def e1211207824302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211207824302 : Closed e1211207824302 ∧ code e1211207824302 = 5609254335406 := by decide
theorem cert_e1211207824302 : check e1211207824302 [[],[]] .chain = true := by decide
def e1211207824314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211207824314 : Closed e1211207824314 ∧ code e1211207824314 = 5609254335418 := by decide
theorem cert_e1211207824314 : check e1211207824314 [[],[]] .chain = true := by decide
def e1211207824342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211207824342 : Closed e1211207824342 ∧ code e1211207824342 = 5609254335446 := by decide
theorem cert_e1211207824342 : check e1211207824342 [[],[]] .chain = true := by decide
def e1211207824346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211207824346 : Closed e1211207824346 ∧ code e1211207824346 = 5609254335450 := by decide
theorem cert_e1211207824346 : check e1211207824346 [[],[]] .chain = true := by decide
def e1211207824622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207824622 : Closed e1211207824622 ∧ code e1211207824622 = 5609254335726 := by decide
theorem cert_e1211207824622 : check e1211207824622 [[],[]] .chain = true := by decide
def e1211207824630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207824630 : Closed e1211207824630 ∧ code e1211207824630 = 5609254335734 := by decide
theorem cert_e1211207824630 : check e1211207824630 [[],[]] .chain = true := by decide
def e1211207825006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207825006 : Closed e1211207825006 ∧ code e1211207825006 = 5609254336110 := by decide
theorem cert_e1211207825006 : check e1211207825006 [[],[]] .chain = true := by decide
def e1211207825018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207825018 : Closed e1211207825018 ∧ code e1211207825018 = 5609254336122 := by decide
theorem cert_e1211207825018 : check e1211207825018 [[],[]] .chain = true := by decide
def e1211207825158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207825158 : Closed e1211207825158 ∧ code e1211207825158 = 5609254336262 := by decide
theorem cert_e1211207825158 : check e1211207825158 [[],[]] .chain = true := by decide
def e1211207825182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211207825182 : Closed e1211207825182 ∧ code e1211207825182 = 5609254336286 := by decide
theorem cert_e1211207825182 : check e1211207825182 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207825206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207825206 : Closed e1211207825206 ∧ code e1211207825206 = 5609254336310 := by decide
theorem cert_e1211207825206 : check e1211207825206 [[],[]] .chain = true := by decide
def e1211207825210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207825210 : Closed e1211207825210 ∧ code e1211207825210 = 5609254336314 := by decide
theorem cert_e1211207825210 : check e1211207825210 [[],[]] .chain = true := by decide
def e1211207825454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211207825454 : Closed e1211207825454 ∧ code e1211207825454 = 5609254336558 := by decide
theorem cert_e1211207825454 : check e1211207825454 [[],[]] .chain = true := by decide
def e1211207825646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211207825646 : Closed e1211207825646 ∧ code e1211207825646 = 5609254336750 := by decide
theorem cert_e1211207825646 : check e1211207825646 [[],[]] .chain = true := by decide
def e1211207825654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211207825654 : Closed e1211207825654 ∧ code e1211207825654 = 5609254336758 := by decide
theorem cert_e1211207825654 : check e1211207825654 [[],[]] .chain = true := by decide
def e1211207825838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211207825838 : Closed e1211207825838 ∧ code e1211207825838 = 5609254336942 := by decide
theorem cert_e1211207825838 : check e1211207825838 [[],[]] .chain = true := by decide
def e1211207825850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211207825850 : Closed e1211207825850 ∧ code e1211207825850 = 5609254336954 := by decide
theorem cert_e1211207825850 : check e1211207825850 [[],[]] .chain = true := by decide
def e1211207825898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211207825898 : Closed e1211207825898 ∧ code e1211207825898 = 5609254337002 := by decide
theorem cert_e1211207825898 : check e1211207825898 [[],[]] .chain = true := by decide
def e1211207826030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207826030 : Closed e1211207826030 ∧ code e1211207826030 = 5609254337134 := by decide
theorem cert_e1211207826030 : check e1211207826030 [[],[]] .chain = true := by decide
def e1211207826042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207826042 : Closed e1211207826042 ∧ code e1211207826042 = 5609254337146 := by decide
theorem cert_e1211207826042 : check e1211207826042 [[],[]] .chain = true := by decide
def e1211207826206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211207826206 : Closed e1211207826206 ∧ code e1211207826206 = 5609254337310 := by decide
theorem cert_e1211207826206 : check e1211207826206 [[],[]] .chain = true := by decide
def e1211207826306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207826306 : Closed e1211207826306 ∧ code e1211207826306 = 5609254337410 := by decide
theorem cert_e1211207826306 : check e1211207826306 [[],[]] .chain = true := by decide
def e1211207826318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211207826318 : Closed e1211207826318 ∧ code e1211207826318 = 5609254337422 := by decide
theorem cert_e1211207826318 : check e1211207826318 [[],[]] .chain = true := by decide
def e1211207826330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207826330 : Closed e1211207826330 ∧ code e1211207826330 = 5609254337434 := by decide
theorem cert_e1211207826330 : check e1211207826330 [[],[]] .chain = true := by decide
def e1211207826454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211207826454 : Closed e1211207826454 ∧ code e1211207826454 = 5609254337558 := by decide
theorem cert_e1211207826454 : check e1211207826454 [[],[]] .chain = true := by decide
def e1211207826458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211207826458 : Closed e1211207826458 ∧ code e1211207826458 = 5609254337562 := by decide
theorem cert_e1211207826458 : check e1211207826458 [[],[]] .chain = true := by decide
def e1211207826502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211207826502 : Closed e1211207826502 ∧ code e1211207826502 = 5609254337606 := by decide
theorem cert_e1211207826502 : check e1211207826502 [[],[]] .chain = true := by decide
def e1211207826530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211207826530 : Closed e1211207826530 ∧ code e1211207826530 = 5609254337634 := by decide
theorem cert_e1211207826530 : check e1211207826530 [[],[]] .chain = true := by decide
def e1211207826542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211207826542 : Closed e1211207826542 ∧ code e1211207826542 = 5609254337646 := by decide
theorem cert_e1211207826542 : check e1211207826542 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207826550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211207826550 : Closed e1211207826550 ∧ code e1211207826550 = 5609254337654 := by decide
theorem cert_e1211207826550 : check e1211207826550 [[],[]] .chain = true := by decide
def e1211207826554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211207826554 : Closed e1211207826554 ∧ code e1211207826554 = 5609254337658 := by decide
theorem cert_e1211207826554 : check e1211207826554 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207826646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211207826646 : Closed e1211207826646 ∧ code e1211207826646 = 5609254337750 := by decide
theorem cert_e1211207826646 : check e1211207826646 [[],[]] .chain = true := by decide
def e1211207826650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211207826650 : Closed e1211207826650 ∧ code e1211207826650 = 5609254337754 := by decide
theorem cert_e1211207826650 : check e1211207826650 [[],[]] .chain = true := by decide
def e1211207826666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211207826666 : Closed e1211207826666 ∧ code e1211207826666 = 5609254337770 := by decide
theorem cert_e1211207826666 : check e1211207826666 [[],[]] .chain = true := by decide
def e1211207826694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207826694 : Closed e1211207826694 ∧ code e1211207826694 = 5609254337798 := by decide
theorem cert_e1211207826694 : check e1211207826694 [[],[]] .chain = true := by decide
def e1211207826718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211207826718 : Closed e1211207826718 ∧ code e1211207826718 = 5609254337822 := by decide
theorem cert_e1211207826718 : check e1211207826718 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207826742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207826742 : Closed e1211207826742 ∧ code e1211207826742 = 5609254337846 := by decide
theorem cert_e1211207826742 : check e1211207826742 [[],[]] .chain = true := by decide
def e1211207826746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207826746 : Closed e1211207826746 ∧ code e1211207826746 = 5609254337850 := by decide
theorem cert_e1211207826746 : check e1211207826746 [[],[]] .chain = true := by decide
def e1211207826818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207826818 : Closed e1211207826818 ∧ code e1211207826818 = 5609254337922 := by decide
theorem cert_e1211207826818 : check e1211207826818 [[],[]] .chain = true := by decide
def e1211207826830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211207826830 : Closed e1211207826830 ∧ code e1211207826830 = 5609254337934 := by decide
theorem cert_e1211207826830 : check e1211207826830 [[],[]] .chain = true := by decide
def e1211207826842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207826842 : Closed e1211207826842 ∧ code e1211207826842 = 5609254337946 := by decide
theorem cert_e1211207826842 : check e1211207826842 [[],[]] .chain = true := by decide
def e1211207826886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211207826886 : Closed e1211207826886 ∧ code e1211207826886 = 5609254337990 := by decide
theorem cert_e1211207826886 : check e1211207826886 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207827582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211207827582 : Closed e1211207827582 ∧ code e1211207827582 = 5609254338686 := by decide
theorem cert_e1211207827582 : check e1211207827582 [[],[]] .chain = true := by decide
def e1211207828446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211207828446 : Closed e1211207828446 ∧ code e1211207828446 = 5609254339550 := by decide
theorem cert_e1211207828446 : check e1211207828446 [[],[]] .chain = true := by decide
def e1211207828450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211207828450 : Closed e1211207828450 ∧ code e1211207828450 = 5609254339554 := by decide
theorem cert_e1211207828450 : check e1211207828450 [[],[]] .chain = true := by decide
def e1211207828462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211207828462 : Closed e1211207828462 ∧ code e1211207828462 = 5609254339566 := by decide
theorem cert_e1211207828462 : check e1211207828462 [[],[]] .chain = true := by decide
def e1211207830382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211207830382 : Closed e1211207830382 ∧ code e1211207830382 = 5609254341486 := by decide
theorem cert_e1211207830382 : check e1211207830382 [[],[]] .chain = true := by decide
def e1211207830390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211207830390 : Closed e1211207830390 ∧ code e1211207830390 = 5609254341494 := by decide
theorem cert_e1211207830390 : check e1211207830390 [[],[]] .chain = true := by decide
def e1211207830446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211207830446 : Closed e1211207830446 ∧ code e1211207830446 = 5609254341550 := by decide
theorem cert_e1211207830446 : check e1211207830446 [[],[]] .chain = true := by decide
def e1211207830458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211207830458 : Closed e1211207830458 ∧ code e1211207830458 = 5609254341562 := by decide
theorem cert_e1211207830458 : check e1211207830458 [[],[]] .chain = true := by decide
def e1211207830486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211207830486 : Closed e1211207830486 ∧ code e1211207830486 = 5609254341590 := by decide
theorem cert_e1211207830486 : check e1211207830486 [[],[]] .chain = true := by decide
def e1211207830490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211207830490 : Closed e1211207830490 ∧ code e1211207830490 = 5609254341594 := by decide
theorem cert_e1211207830490 : check e1211207830490 [[],[]] .chain = true := by decide
def e1211207830766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207830766 : Closed e1211207830766 ∧ code e1211207830766 = 5609254341870 := by decide
theorem cert_e1211207830766 : check e1211207830766 [[],[]] .chain = true := by decide
def e1211207830774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207830774 : Closed e1211207830774 ∧ code e1211207830774 = 5609254341878 := by decide
theorem cert_e1211207830774 : check e1211207830774 [[],[]] .chain = true := by decide
end Blc.Floor42
