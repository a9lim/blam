import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196686925526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1196686925526 : Closed e1196686925526 ∧ code e1196686925526 = 5594733436630 := by decide
theorem cert_e1196686925526 : check e1196686925526 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1196686925530 : Closed e1196686925530 ∧ code e1196686925530 = 5594733436634 := by decide
theorem cert_e1196686925530 : check e1196686925530 [[],[.left],[]] .sourceHead = true := by decide
def e1196686927726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1196686927726 : Closed e1196686927726 ∧ code e1196686927726 = 5594733438830 := by decide
theorem cert_e1196686927726 : check e1196686927726 [[],[.left],[]] .sourceHead = true := by decide
def e1196686927734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1196686927734 : Closed e1196686927734 ∧ code e1196686927734 = 5594733438838 := by decide
theorem cert_e1196686927734 : check e1196686927734 [[],[.left],[]] .sourceHead = true := by decide
def e1196686927798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1196686927798 : Closed e1196686927798 ∧ code e1196686927798 = 5594733438902 := by decide
theorem cert_e1196686927798 : check e1196686927798 [[],[.left],[]] .sourceHead = true := by decide
def e1196686929134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196686929134 : Closed e1196686929134 ∧ code e1196686929134 = 5594733440238 := by decide
theorem cert_e1196686929134 : check e1196686929134 [[],[.left],[]] .sourceHead = true := by decide
def e1196686929142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196686929142 : Closed e1196686929142 ∧ code e1196686929142 = 5594733440246 := by decide
theorem cert_e1196686929142 : check e1196686929142 [[],[.left],[]] .sourceHead = true := by decide
def e1196686929526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196686929526 : Closed e1196686929526 ∧ code e1196686929526 = 5594733440630 := by decide
theorem cert_e1196686929526 : check e1196686929526 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1196686930414 : Closed e1196686930414 ∧ code e1196686930414 = 5594733441518 := by decide
theorem cert_e1196686930414 : check e1196686930414 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196686930798 : Closed e1196686930798 ∧ code e1196686930798 = 5594733441902 := by decide
theorem cert_e1196686930798 : check e1196686930798 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196686930806 : Closed e1196686930806 ∧ code e1196686930806 = 5594733441910 := by decide
theorem cert_e1196686930806 : check e1196686930806 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196686930862 : Closed e1196686930862 ∧ code e1196686930862 = 5594733441966 := by decide
theorem cert_e1196686930862 : check e1196686930862 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196686930874 : Closed e1196686930874 ∧ code e1196686930874 = 5594733441978 := by decide
theorem cert_e1196686930874 : check e1196686930874 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196686930902 : Closed e1196686930902 ∧ code e1196686930902 = 5594733442006 := by decide
theorem cert_e1196686930902 : check e1196686930902 [[],[.left],[]] .sourceHead = true := by decide
def e1196686930906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196686930906 : Closed e1196686930906 ∧ code e1196686930906 = 5594733442010 := by decide
theorem cert_e1196686930906 : check e1196686930906 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196686931182 : Closed e1196686931182 ∧ code e1196686931182 = 5594733442286 := by decide
theorem cert_e1196686931182 : check e1196686931182 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196686931190 : Closed e1196686931190 ∧ code e1196686931190 = 5594733442294 := by decide
theorem cert_e1196686931190 : check e1196686931190 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196686931566 : Closed e1196686931566 ∧ code e1196686931566 = 5594733442670 := by decide
theorem cert_e1196686931566 : check e1196686931566 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196686931578 : Closed e1196686931578 ∧ code e1196686931578 = 5594733442682 := by decide
theorem cert_e1196686931578 : check e1196686931578 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1196686931742 : Closed e1196686931742 ∧ code e1196686931742 = 5594733442846 := by decide
theorem cert_e1196686931742 : check e1196686931742 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686931766 : Closed e1196686931766 ∧ code e1196686931766 = 5594733442870 := by decide
theorem cert_e1196686931766 : check e1196686931766 [[],[.left],[]] .sourceHead = true := by decide
def e1196686931770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686931770 : Closed e1196686931770 ∧ code e1196686931770 = 5594733442874 := by decide
theorem cert_e1196686931770 : check e1196686931770 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196686932206 : Closed e1196686932206 ∧ code e1196686932206 = 5594733443310 := by decide
theorem cert_e1196686932206 : check e1196686932206 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196686932214 : Closed e1196686932214 ∧ code e1196686932214 = 5594733443318 := by decide
theorem cert_e1196686932214 : check e1196686932214 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1196686932406 : Closed e1196686932406 ∧ code e1196686932406 = 5594733443510 := by decide
theorem cert_e1196686932406 : check e1196686932406 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1196686932438 : Closed e1196686932438 ∧ code e1196686932438 = 5594733443542 := by decide
theorem cert_e1196686932438 : check e1196686932438 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1196686932442 : Closed e1196686932442 ∧ code e1196686932442 = 5594733443546 := by decide
theorem cert_e1196686932442 : check e1196686932442 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196686932598 : Closed e1196686932598 ∧ code e1196686932598 = 5594733443702 := by decide
theorem cert_e1196686932598 : check e1196686932598 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196686932766 : Closed e1196686932766 ∧ code e1196686932766 = 5594733443870 := by decide
theorem cert_e1196686932766 : check e1196686932766 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686932790 : Closed e1196686932790 ∧ code e1196686932790 = 5594733443894 := by decide
theorem cert_e1196686932790 : check e1196686932790 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686932794 : Closed e1196686932794 ∧ code e1196686932794 = 5594733443898 := by decide
theorem cert_e1196686932794 : check e1196686932794 [[],[.left],[]] .sourceHead = true := by decide
def e1196686932878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196686932878 : Closed e1196686932878 ∧ code e1196686932878 = 5594733443982 := by decide
theorem cert_e1196686932878 : check e1196686932878 [[],[.left],[]] .sourceHead = true := by decide
def e1196686940014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1196686940014 : Closed e1196686940014 ∧ code e1196686940014 = 5594733451118 := by decide
theorem cert_e1196686940014 : check e1196686940014 [[],[.left],[]] .sourceHead = true := by decide
def e1196686940022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1196686940022 : Closed e1196686940022 ∧ code e1196686940022 = 5594733451126 := by decide
theorem cert_e1196686940022 : check e1196686940022 [[],[.left],[]] .sourceHead = true := by decide
def e1196686940086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1196686940086 : Closed e1196686940086 ∧ code e1196686940086 = 5594733451190 := by decide
theorem cert_e1196686940086 : check e1196686940086 [[],[.left],[]] .sourceHead = true := by decide
def e1196686941422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196686941422 : Closed e1196686941422 ∧ code e1196686941422 = 5594733452526 := by decide
theorem cert_e1196686941422 : check e1196686941422 [[],[.left],[]] .sourceHead = true := by decide
def e1196686941430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196686941430 : Closed e1196686941430 ∧ code e1196686941430 = 5594733452534 := by decide
theorem cert_e1196686941430 : check e1196686941430 [[],[.left],[]] .sourceHead = true := by decide
def e1196686941814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196686941814 : Closed e1196686941814 ∧ code e1196686941814 = 5594733452918 := by decide
theorem cert_e1196686941814 : check e1196686941814 [[],[.left],[]] .sourceHead = true := by decide
def e1196686951390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1196686951390 : Closed e1196686951390 ∧ code e1196686951390 = 5594733462494 := by decide
theorem cert_e1196686951390 : check e1196686951390 [[],[.left],[]] .sourceHead = true := by decide
def e1196686951406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1196686951406 : Closed e1196686951406 ∧ code e1196686951406 = 5594733462510 := by decide
theorem cert_e1196686951406 : check e1196686951406 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196686953326 : Closed e1196686953326 ∧ code e1196686953326 = 5594733464430 := by decide
theorem cert_e1196686953326 : check e1196686953326 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196686953334 : Closed e1196686953334 ∧ code e1196686953334 = 5594733464438 := by decide
theorem cert_e1196686953334 : check e1196686953334 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196686953390 : Closed e1196686953390 ∧ code e1196686953390 = 5594733464494 := by decide
theorem cert_e1196686953390 : check e1196686953390 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196686953402 : Closed e1196686953402 ∧ code e1196686953402 = 5594733464506 := by decide
theorem cert_e1196686953402 : check e1196686953402 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196686953430 : Closed e1196686953430 ∧ code e1196686953430 = 5594733464534 := by decide
theorem cert_e1196686953430 : check e1196686953430 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196686953434 : Closed e1196686953434 ∧ code e1196686953434 = 5594733464538 := by decide
theorem cert_e1196686953434 : check e1196686953434 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196686953710 : Closed e1196686953710 ∧ code e1196686953710 = 5594733464814 := by decide
theorem cert_e1196686953710 : check e1196686953710 [[],[.left],[]] .sourceHead = true := by decide
def e1196686953718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196686953718 : Closed e1196686953718 ∧ code e1196686953718 = 5594733464822 := by decide
theorem cert_e1196686953718 : check e1196686953718 [[],[.left],[]] .sourceHead = true := by decide
def e1196686954094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196686954094 : Closed e1196686954094 ∧ code e1196686954094 = 5594733465198 := by decide
theorem cert_e1196686954094 : check e1196686954094 [[],[.left],[]] .sourceHead = true := by decide
def e1196686954106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196686954106 : Closed e1196686954106 ∧ code e1196686954106 = 5594733465210 := by decide
theorem cert_e1196686954106 : check e1196686954106 [[],[.left],[]] .sourceHead = true := by decide
def e1196686954270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1196686954270 : Closed e1196686954270 ∧ code e1196686954270 = 5594733465374 := by decide
theorem cert_e1196686954270 : check e1196686954270 [[],[.left],[]] .sourceHead = true := by decide
def e1196686954294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196686954294 : Closed e1196686954294 ∧ code e1196686954294 = 5594733465398 := by decide
theorem cert_e1196686954294 : check e1196686954294 [[],[.left],[]] .sourceHead = true := by decide
def e1196686954298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196686954298 : Closed e1196686954298 ∧ code e1196686954298 = 5594733465402 := by decide
theorem cert_e1196686954298 : check e1196686954298 [[],[.left],[]] .sourceHead = true := by decide
def e1196686959086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1196686959086 : Closed e1196686959086 ∧ code e1196686959086 = 5594733470190 := by decide
theorem cert_e1196686959086 : check e1196686959086 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1196686960054 : Closed e1196686960054 ∧ code e1196686960054 = 5594733471158 := by decide
theorem cert_e1196686960054 : check e1196686960054 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1196686960086 : Closed e1196686960086 ∧ code e1196686960086 = 5594733471190 := by decide
theorem cert_e1196686960086 : check e1196686960086 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1196686960090 : Closed e1196686960090 ∧ code e1196686960090 = 5594733471194 := by decide
theorem cert_e1196686960090 : check e1196686960090 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196686960246 : Closed e1196686960246 ∧ code e1196686960246 = 5594733471350 := by decide
theorem cert_e1196686960246 : check e1196686960246 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196686960414 : Closed e1196686960414 ∧ code e1196686960414 = 5594733471518 := by decide
theorem cert_e1196686960414 : check e1196686960414 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196686960438 : Closed e1196686960438 ∧ code e1196686960438 = 5594733471542 := by decide
theorem cert_e1196686960438 : check e1196686960438 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196686960442 : Closed e1196686960442 ∧ code e1196686960442 = 5594733471546 := by decide
theorem cert_e1196686960442 : check e1196686960442 [[],[.left],[]] .sourceHead = true := by decide
def e1196686960526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196686960526 : Closed e1196686960526 ∧ code e1196686960526 = 5594733471630 := by decide
theorem cert_e1196686960526 : check e1196686960526 [[],[.left],[]] .sourceHead = true := by decide
def e1196687109598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1196687109598 : Closed e1196687109598 ∧ code e1196687109598 = 5594733620702 := by decide
theorem cert_e1196687109598 : check e1196687109598 [[],[.left],[],[.under]] .three = true := by decide
def e1196687109614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1196687109614 : Closed e1196687109614 ∧ code e1196687109614 = 5594733620718 := by decide
theorem cert_e1196687109614 : check e1196687109614 [[],[.left],[],[.under]] .three = true := by decide
def e1196687109854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1196687109854 : Closed e1196687109854 ∧ code e1196687109854 = 5594733620958 := by decide
theorem cert_e1196687109854 : check e1196687109854 [[],[.left],[],[.under]] .three = true := by decide
def e1196687109878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1196687109878 : Closed e1196687109878 ∧ code e1196687109878 = 5594733620982 := by decide
theorem cert_e1196687109878 : check e1196687109878 [[],[.left],[],[.under]] .three = true := by decide
def e1196687109982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1196687109982 : Closed e1196687109982 ∧ code e1196687109982 = 5594733621086 := by decide
theorem cert_e1196687109982 : check e1196687109982 [[],[.left],[],[.under]] .three = true := by decide
def e1196687110010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1196687110010 : Closed e1196687110010 ∧ code e1196687110010 = 5594733621114 := by decide
theorem cert_e1196687110010 : check e1196687110010 [[],[.left],[],[.under]] .three = true := by decide
def e1196687110062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1196687110062 : Closed e1196687110062 ∧ code e1196687110062 = 5594733621166 := by decide
theorem cert_e1196687110062 : check e1196687110062 [[],[.left],[],[.under]] .three = true := by decide
def e1196687110070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1196687110070 : Closed e1196687110070 ∧ code e1196687110070 = 5594733621174 := by decide
theorem cert_e1196687110070 : check e1196687110070 [[],[.left],[],[.under]] .three = true := by decide
def e1196687110074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1196687110074 : Closed e1196687110074 ∧ code e1196687110074 = 5594733621178 := by decide
theorem cert_e1196687110074 : check e1196687110074 [[],[.left],[],[.under]] .three = true := by decide
def e1196687111134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1196687111134 : Closed e1196687111134 ∧ code e1196687111134 = 5594733622238 := by decide
theorem cert_e1196687111134 : check e1196687111134 [[],[.left],[],[.under]] .three = true := by decide
def e1196687111150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1196687111150 : Closed e1196687111150 ∧ code e1196687111150 = 5594733622254 := by decide
theorem cert_e1196687111150 : check e1196687111150 [[],[.left],[],[.under]] .three = true := by decide
def e1196687112670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196687112670 : Closed e1196687112670 ∧ code e1196687112670 = 5594733623774 := by decide
theorem cert_e1196687112670 : check e1196687112670 [[],[.left],[],[.under]] .three = true := by decide
def e1196687112694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196687112694 : Closed e1196687112694 ∧ code e1196687112694 = 5594733623798 := by decide
theorem cert_e1196687112694 : check e1196687112694 [[],[.left],[],[.under]] .three = true := by decide
def e1196687113438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196687113438 : Closed e1196687113438 ∧ code e1196687113438 = 5594733624542 := by decide
theorem cert_e1196687113438 : check e1196687113438 [[],[.left],[],[.under]] .three = true := by decide
def e1196687113466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196687113466 : Closed e1196687113466 ∧ code e1196687113466 = 5594733624570 := by decide
theorem cert_e1196687113466 : check e1196687113466 [[],[.left],[],[.under]] .three = true := by decide
def e1196687113838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196687113838 : Closed e1196687113838 ∧ code e1196687113838 = 5594733624942 := by decide
theorem cert_e1196687113838 : check e1196687113838 [[],[.left],[],[.under]] .three = true := by decide
def e1196687113846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196687113846 : Closed e1196687113846 ∧ code e1196687113846 = 5594733624950 := by decide
theorem cert_e1196687113846 : check e1196687113846 [[],[.left],[],[.under]] .three = true := by decide
def e1196687113850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196687113850 : Closed e1196687113850 ∧ code e1196687113850 = 5594733624954 := by decide
theorem cert_e1196687113850 : check e1196687113850 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196687142254 : Closed e1196687142254 ∧ code e1196687142254 = 5594733653358 := by decide
theorem cert_e1196687142254 : check e1196687142254 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196687142262 : Closed e1196687142262 ∧ code e1196687142262 = 5594733653366 := by decide
theorem cert_e1196687142262 : check e1196687142262 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196687142318 : Closed e1196687142318 ∧ code e1196687142318 = 5594733653422 := by decide
theorem cert_e1196687142318 : check e1196687142318 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196687142330 : Closed e1196687142330 ∧ code e1196687142330 = 5594733653434 := by decide
theorem cert_e1196687142330 : check e1196687142330 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196687142358 : Closed e1196687142358 ∧ code e1196687142358 = 5594733653462 := by decide
theorem cert_e1196687142358 : check e1196687142358 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196687142362 : Closed e1196687142362 ∧ code e1196687142362 = 5594733653466 := by decide
theorem cert_e1196687142362 : check e1196687142362 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1196687142574 : Closed e1196687142574 ∧ code e1196687142574 = 5594733653678 := by decide
theorem cert_e1196687142574 : check e1196687142574 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1196687142586 : Closed e1196687142586 ∧ code e1196687142586 = 5594733653690 := by decide
theorem cert_e1196687142586 : check e1196687142586 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1196687142634 : Closed e1196687142634 ∧ code e1196687142634 = 5594733653738 := by decide
theorem cert_e1196687142634 : check e1196687142634 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1196687142742 : Closed e1196687142742 ∧ code e1196687142742 = 5594733653846 := by decide
theorem cert_e1196687142742 : check e1196687142742 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1196687142746 : Closed e1196687142746 ∧ code e1196687142746 = 5594733653850 := by decide
theorem cert_e1196687142746 : check e1196687142746 [[],[.left],[],[.under]] .three = true := by decide
def e1196687142762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1196687142762 : Closed e1196687142762 ∧ code e1196687142762 = 5594733653866 := by decide
theorem cert_e1196687142762 : check e1196687142762 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1196687143406 : Closed e1196687143406 ∧ code e1196687143406 = 5594733654510 := by decide
theorem cert_e1196687143406 : check e1196687143406 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196687143790 : Closed e1196687143790 ∧ code e1196687143790 = 5594733654894 := by decide
theorem cert_e1196687143790 : check e1196687143790 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196687143798 : Closed e1196687143798 ∧ code e1196687143798 = 5594733654902 := by decide
theorem cert_e1196687143798 : check e1196687143798 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196687143854 : Closed e1196687143854 ∧ code e1196687143854 = 5594733654958 := by decide
theorem cert_e1196687143854 : check e1196687143854 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196687143866 : Closed e1196687143866 ∧ code e1196687143866 = 5594733654970 := by decide
theorem cert_e1196687143866 : check e1196687143866 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196687143894 : Closed e1196687143894 ∧ code e1196687143894 = 5594733654998 := by decide
theorem cert_e1196687143894 : check e1196687143894 [[],[.left],[],[.under]] .three = true := by decide
def e1196687143898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196687143898 : Closed e1196687143898 ∧ code e1196687143898 = 5594733655002 := by decide
theorem cert_e1196687143898 : check e1196687143898 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196687144174 : Closed e1196687144174 ∧ code e1196687144174 = 5594733655278 := by decide
theorem cert_e1196687144174 : check e1196687144174 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196687144182 : Closed e1196687144182 ∧ code e1196687144182 = 5594733655286 := by decide
theorem cert_e1196687144182 : check e1196687144182 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196687144558 : Closed e1196687144558 ∧ code e1196687144558 = 5594733655662 := by decide
theorem cert_e1196687144558 : check e1196687144558 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196687144570 : Closed e1196687144570 ∧ code e1196687144570 = 5594733655674 := by decide
theorem cert_e1196687144570 : check e1196687144570 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1196687144734 : Closed e1196687144734 ∧ code e1196687144734 = 5594733655838 := by decide
theorem cert_e1196687144734 : check e1196687144734 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196687144758 : Closed e1196687144758 ∧ code e1196687144758 = 5594733655862 := by decide
theorem cert_e1196687144758 : check e1196687144758 [[],[.left],[],[.under]] .three = true := by decide
def e1196687144762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196687144762 : Closed e1196687144762 ∧ code e1196687144762 = 5594733655866 := by decide
theorem cert_e1196687144762 : check e1196687144762 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1196687145390 : Closed e1196687145390 ∧ code e1196687145390 = 5594733656494 := by decide
theorem cert_e1196687145390 : check e1196687145390 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1196687145402 : Closed e1196687145402 ∧ code e1196687145402 = 5594733656506 := by decide
theorem cert_e1196687145402 : check e1196687145402 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1196687145450 : Closed e1196687145450 ∧ code e1196687145450 = 5594733656554 := by decide
theorem cert_e1196687145450 : check e1196687145450 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196687145582 : Closed e1196687145582 ∧ code e1196687145582 = 5594733656686 := by decide
theorem cert_e1196687145582 : check e1196687145582 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196687145594 : Closed e1196687145594 ∧ code e1196687145594 = 5594733656698 := by decide
theorem cert_e1196687145594 : check e1196687145594 [[],[.left],[],[.under]] .three = true := by decide
def e1196687145882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196687145882 : Closed e1196687145882 ∧ code e1196687145882 = 5594733656986 := by decide
theorem cert_e1196687145882 : check e1196687145882 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196687146094 : Closed e1196687146094 ∧ code e1196687146094 = 5594733657198 := by decide
theorem cert_e1196687146094 : check e1196687146094 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196687146106 : Closed e1196687146106 ∧ code e1196687146106 = 5594733657210 := by decide
theorem cert_e1196687146106 : check e1196687146106 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1196687146198 : Closed e1196687146198 ∧ code e1196687146198 = 5594733657302 := by decide
theorem cert_e1196687146198 : check e1196687146198 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1196687146202 : Closed e1196687146202 ∧ code e1196687146202 = 5594733657306 := by decide
theorem cert_e1196687146202 : check e1196687146202 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1196687146218 : Closed e1196687146218 ∧ code e1196687146218 = 5594733657322 := by decide
theorem cert_e1196687146218 : check e1196687146218 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196687146270 : Closed e1196687146270 ∧ code e1196687146270 = 5594733657374 := by decide
theorem cert_e1196687146270 : check e1196687146270 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196687146294 : Closed e1196687146294 ∧ code e1196687146294 = 5594733657398 := by decide
theorem cert_e1196687146294 : check e1196687146294 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196687146298 : Closed e1196687146298 ∧ code e1196687146298 = 5594733657402 := by decide
theorem cert_e1196687146298 : check e1196687146298 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196687146394 : Closed e1196687146394 ∧ code e1196687146394 = 5594733657498 := by decide
theorem cert_e1196687146394 : check e1196687146394 [[],[.left],[],[.under]] .three = true := by decide
def e1196687146438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196687146438 : Closed e1196687146438 ∧ code e1196687146438 = 5594733657542 := by decide
theorem cert_e1196687146438 : check e1196687146438 [[],[.left],[],[.under]] .three = true := by decide
def e1196687147998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1196687147998 : Closed e1196687147998 ∧ code e1196687147998 = 5594733659102 := by decide
theorem cert_e1196687147998 : check e1196687147998 [[],[.left],[],[.under]] .three = true := by decide
def e1196687148014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1196687148014 : Closed e1196687148014 ∧ code e1196687148014 = 5594733659118 := by decide
theorem cert_e1196687148014 : check e1196687148014 [[],[.left],[],[.under]] .three = true := by decide
def e1196687149934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196687149934 : Closed e1196687149934 ∧ code e1196687149934 = 5594733661038 := by decide
theorem cert_e1196687149934 : check e1196687149934 [[],[.left],[],[.under]] .three = true := by decide
def e1196687149942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196687149942 : Closed e1196687149942 ∧ code e1196687149942 = 5594733661046 := by decide
theorem cert_e1196687149942 : check e1196687149942 [[],[.left],[],[.under]] .three = true := by decide
def e1196687149998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196687149998 : Closed e1196687149998 ∧ code e1196687149998 = 5594733661102 := by decide
theorem cert_e1196687149998 : check e1196687149998 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196687150010 : Closed e1196687150010 ∧ code e1196687150010 = 5594733661114 := by decide
theorem cert_e1196687150010 : check e1196687150010 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196687150038 : Closed e1196687150038 ∧ code e1196687150038 = 5594733661142 := by decide
theorem cert_e1196687150038 : check e1196687150038 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196687150042 : Closed e1196687150042 ∧ code e1196687150042 = 5594733661146 := by decide
theorem cert_e1196687150042 : check e1196687150042 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196687150318 : Closed e1196687150318 ∧ code e1196687150318 = 5594733661422 := by decide
theorem cert_e1196687150318 : check e1196687150318 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196687150326 : Closed e1196687150326 ∧ code e1196687150326 = 5594733661430 := by decide
theorem cert_e1196687150326 : check e1196687150326 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196687150702 : Closed e1196687150702 ∧ code e1196687150702 = 5594733661806 := by decide
theorem cert_e1196687150702 : check e1196687150702 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196687150714 : Closed e1196687150714 ∧ code e1196687150714 = 5594733661818 := by decide
theorem cert_e1196687150714 : check e1196687150714 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1196687150878 : Closed e1196687150878 ∧ code e1196687150878 = 5594733661982 := by decide
theorem cert_e1196687150878 : check e1196687150878 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196687150902 : Closed e1196687150902 ∧ code e1196687150902 = 5594733662006 := by decide
theorem cert_e1196687150902 : check e1196687150902 [[],[.left],[],[.under]] .three = true := by decide
def e1196687150906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196687150906 : Closed e1196687150906 ∧ code e1196687150906 = 5594733662010 := by decide
theorem cert_e1196687150906 : check e1196687150906 [[],[.left],[],[.under]] .three = true := by decide
def e1196687155678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1196687155678 : Closed e1196687155678 ∧ code e1196687155678 = 5594733666782 := by decide
theorem cert_e1196687155678 : check e1196687155678 [[],[.left],[],[.under]] .three = true := by decide
def e1196687155702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1196687155702 : Closed e1196687155702 ∧ code e1196687155702 = 5594733666806 := by decide
theorem cert_e1196687155702 : check e1196687155702 [[],[.left],[],[.under]] .three = true := by decide
def e1196687156654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1196687156654 : Closed e1196687156654 ∧ code e1196687156654 = 5594733667758 := by decide
theorem cert_e1196687156654 : check e1196687156654 [[],[.left],[],[.under]] .three = true := by decide
def e1196687156666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1196687156666 : Closed e1196687156666 ∧ code e1196687156666 = 5594733667770 := by decide
theorem cert_e1196687156666 : check e1196687156666 [[],[.left],[],[.under]] .three = true := by decide
def e1196687156714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1196687156714 : Closed e1196687156714 ∧ code e1196687156714 = 5594733667818 := by decide
theorem cert_e1196687156714 : check e1196687156714 [[],[.left],[],[.under]] .three = true := by decide
def e1196687156846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196687156846 : Closed e1196687156846 ∧ code e1196687156846 = 5594733667950 := by decide
theorem cert_e1196687156846 : check e1196687156846 [[],[.left],[],[.under]] .three = true := by decide
def e1196687156858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196687156858 : Closed e1196687156858 ∧ code e1196687156858 = 5594733667962 := by decide
theorem cert_e1196687156858 : check e1196687156858 [[],[.left],[],[.under]] .three = true := by decide
def e1196687157146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196687157146 : Closed e1196687157146 ∧ code e1196687157146 = 5594733668250 := by decide
theorem cert_e1196687157146 : check e1196687157146 [[],[.left],[],[.under]] .three = true := by decide
def e1196687159534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1196687159534 : Closed e1196687159534 ∧ code e1196687159534 = 5594733670638 := by decide
theorem cert_e1196687159534 : check e1196687159534 [[],[.left],[],[.under]] .three = true := by decide
def e1196687159542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1196687159542 : Closed e1196687159542 ∧ code e1196687159542 = 5594733670646 := by decide
theorem cert_e1196687159542 : check e1196687159542 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1196687160022 : Closed e1196687160022 ∧ code e1196687160022 = 5594733671126 := by decide
theorem cert_e1196687160022 : check e1196687160022 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1196687160026 : Closed e1196687160026 ∧ code e1196687160026 = 5594733671130 := by decide
theorem cert_e1196687160026 : check e1196687160026 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1196687160042 : Closed e1196687160042 ∧ code e1196687160042 = 5594733671146 := by decide
theorem cert_e1196687160042 : check e1196687160042 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196687160094 : Closed e1196687160094 ∧ code e1196687160094 = 5594733671198 := by decide
theorem cert_e1196687160094 : check e1196687160094 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196687160118 : Closed e1196687160118 ∧ code e1196687160118 = 5594733671222 := by decide
theorem cert_e1196687160118 : check e1196687160118 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196687160122 : Closed e1196687160122 ∧ code e1196687160122 = 5594733671226 := by decide
theorem cert_e1196687160122 : check e1196687160122 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196687160218 : Closed e1196687160218 ∧ code e1196687160218 = 5594733671322 := by decide
theorem cert_e1196687160218 : check e1196687160218 [[],[.left],[],[.under]] .three = true := by decide
def e1196687160262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196687160262 : Closed e1196687160262 ∧ code e1196687160262 = 5594733671366 := by decide
theorem cert_e1196687160262 : check e1196687160262 [[],[.left],[],[.under]] .three = true := by decide
def e1196687234782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1196687234782 : Closed e1196687234782 ∧ code e1196687234782 = 5594733745886 := by decide
theorem cert_e1196687234782 : check e1196687234782 [[],[.left],[],[.under]] .three = true := by decide
def e1196687234806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1196687234806 : Closed e1196687234806 ∧ code e1196687234806 = 5594733745910 := by decide
private def t_e1196687234806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e1196687234806 : ¬ IsSelfInterpreter e1196687234806 :=
  wSource (t := t_e1196687234806) (replay_sound (ps := []) (t := e1196687234806) (by decide)) (by decide)
def e1196687234910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1196687234910 : Closed e1196687234910 ∧ code e1196687234910 = 5594733746014 := by decide
theorem cert_e1196687234910 : check e1196687234910 [[],[.left],[],[.under]] .three = true := by decide
def e1196687234926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1196687234926 : Closed e1196687234926 ∧ code e1196687234926 = 5594733746030 := by decide
theorem cert_e1196687234926 : check e1196687234926 [[],[.left],[],[.under]] .three = true := by decide
def e1196687234934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1196687234934 : Closed e1196687234934 ∧ code e1196687234934 = 5594733746038 := by decide
theorem cert_e1196687234934 : check e1196687234934 [[],[.left],[],[.under]] .three = true := by decide
end Blc.Floor42
