import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e412612648794 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e412612648794 : Closed e412612648794 ∧ code e412612648794 = 4810659159898 := by decide
theorem cert_e412612648794 : check e412612648794 [] .sourceHead = true := by decide
def e412612648810 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e412612648810 : Closed e412612648810 ∧ code e412612648810 = 4810659159914 := by decide
theorem cert_e412612648810 : check e412612648810 [] .sourceHead = true := by decide
def e412612650718 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e412612650718 : Closed e412612650718 ∧ code e412612650718 = 4810659161822 := by decide
theorem cert_e412612650718 : check e412612650718 [] .sourceHead = true := by decide
def e412612650742 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e412612650742 : Closed e412612650742 ∧ code e412612650742 = 4810659161846 := by decide
theorem cert_e412612650742 : check e412612650742 [] .sourceHead = true := by decide
def e412612650846 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e412612650846 : Closed e412612650846 ∧ code e412612650846 = 4810659161950 := by decide
theorem cert_e412612650846 : check e412612650846 [] .sourceHead = true := by decide
def e412612650874 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e412612650874 : Closed e412612650874 ∧ code e412612650874 = 4810659161978 := by decide
theorem cert_e412612650874 : check e412612650874 [] .sourceHead = true := by decide
def e412612650966 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e412612650966 : Closed e412612650966 ∧ code e412612650966 = 4810659162070 := by decide
theorem cert_e412612650966 : check e412612650966 [] .sourceHead = true := by decide
def e412612650970 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e412612650970 : Closed e412612650970 ∧ code e412612650970 = 4810659162074 := by decide
theorem cert_e412612650970 : check e412612650970 [] .sourceHead = true := by decide
def e412612651486 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e412612651486 : Closed e412612651486 ∧ code e412612651486 = 4810659162590 := by decide
theorem cert_e412612651486 : check e412612651486 [] .sourceHead = true := by decide
def e412612651510 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e412612651510 : Closed e412612651510 ∧ code e412612651510 = 4810659162614 := by decide
theorem cert_e412612651510 : check e412612651510 [] .sourceHead = true := by decide
def e412612652254 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e412612652254 : Closed e412612652254 ∧ code e412612652254 = 4810659163358 := by decide
theorem cert_e412612652254 : check e412612652254 [] .sourceHead = true := by decide
def e412612652282 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e412612652282 : Closed e412612652282 ∧ code e412612652282 = 4810659163386 := by decide
theorem cert_e412612652282 : check e412612652282 [] .sourceHead = true := by decide
def e412612652854 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e412612652854 : Closed e412612652854 ∧ code e412612652854 = 4810659163958 := by decide
theorem cert_e412612652854 : check e412612652854 [] .sourceHead = true := by decide
def e412612652858 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e412612652858 : Closed e412612652858 ∧ code e412612652858 = 4810659163962 := by decide
theorem cert_e412612652858 : check e412612652858 [] .sourceHead = true := by decide
def e412612653918 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e412612653918 : Closed e412612653918 ∧ code e412612653918 = 4810659165022 := by decide
theorem cert_e412612653918 : check e412612653918 [] .sourceHead = true := by decide
def e412612653946 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e412612653946 : Closed e412612653946 ∧ code e412612653946 = 4810659165050 := by decide
theorem cert_e412612653946 : check e412612653946 [] .sourceHead = true := by decide
def e412612654058 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e412612654058 : Closed e412612654058 ∧ code e412612654058 = 4810659165162 := by decide
theorem cert_e412612654058 : check e412612654058 [] .sourceHead = true := by decide
def e412612654302 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e412612654302 : Closed e412612654302 ∧ code e412612654302 = 4810659165406 := by decide
theorem cert_e412612654302 : check e412612654302 [] .sourceHead = true := by decide
def e412612654330 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e412612654330 : Closed e412612654330 ∧ code e412612654330 = 4810659165434 := by decide
theorem cert_e412612654330 : check e412612654330 [] .sourceHead = true := by decide
def e412612655002 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e412612655002 : Closed e412612655002 ∧ code e412612655002 = 4810659166106 := by decide
theorem cert_e412612655002 : check e412612655002 [] .sourceHead = true := by decide
def e412612656342 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e412612656342 : Closed e412612656342 ∧ code e412612656342 = 4810659167446 := by decide
theorem cert_e412612656342 : check e412612656342 [] .sourceHead = true := by decide
def e412612656346 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e412612656346 : Closed e412612656346 ∧ code e412612656346 = 4810659167450 := by decide
theorem cert_e412612656346 : check e412612656346 [] .sourceHead = true := by decide
def e412612656362 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e412612656362 : Closed e412612656362 ∧ code e412612656362 = 4810659167466 := by decide
theorem cert_e412612656362 : check e412612656362 [] .sourceHead = true := by decide
def e412612656438 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e412612656438 : Closed e412612656438 ∧ code e412612656438 = 4810659167542 := by decide
theorem cert_e412612656438 : check e412612656438 [] .sourceHead = true := by decide
def e412612656442 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e412612656442 : Closed e412612656442 ∧ code e412612656442 = 4810659167546 := by decide
theorem cert_e412612656442 : check e412612656442 [] .sourceHead = true := by decide
def e412612656538 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e412612656538 : Closed e412612656538 ∧ code e412612656538 = 4810659167642 := by decide
theorem cert_e412612656538 : check e412612656538 [] .sourceHead = true := by decide
def e412612663006 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e412612663006 : Closed e412612663006 ∧ code e412612663006 = 4810659174110 := by decide
theorem cert_e412612663006 : check e412612663006 [] .sourceHead = true := by decide
def e412612663030 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e412612663030 : Closed e412612663030 ∧ code e412612663030 = 4810659174134 := by decide
theorem cert_e412612663030 : check e412612663030 [] .sourceHead = true := by decide
def e412612663134 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e412612663134 : Closed e412612663134 ∧ code e412612663134 = 4810659174238 := by decide
theorem cert_e412612663134 : check e412612663134 [] .sourceHead = true := by decide
def e412612663162 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e412612663162 : Closed e412612663162 ∧ code e412612663162 = 4810659174266 := by decide
theorem cert_e412612663162 : check e412612663162 [] .sourceHead = true := by decide
def e412612663254 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e412612663254 : Closed e412612663254 ∧ code e412612663254 = 4810659174358 := by decide
theorem cert_e412612663254 : check e412612663254 [] .sourceHead = true := by decide
def e412612663258 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e412612663258 : Closed e412612663258 ∧ code e412612663258 = 4810659174362 := by decide
theorem cert_e412612663258 : check e412612663258 [] .sourceHead = true := by decide
def e412612663774 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e412612663774 : Closed e412612663774 ∧ code e412612663774 = 4810659174878 := by decide
theorem cert_e412612663774 : check e412612663774 [] .sourceHead = true := by decide
def e412612663798 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e412612663798 : Closed e412612663798 ∧ code e412612663798 = 4810659174902 := by decide
theorem cert_e412612663798 : check e412612663798 [] .sourceHead = true := by decide
def e412612664542 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e412612664542 : Closed e412612664542 ∧ code e412612664542 = 4810659175646 := by decide
theorem cert_e412612664542 : check e412612664542 [] .sourceHead = true := by decide
def e412612664570 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e412612664570 : Closed e412612664570 ∧ code e412612664570 = 4810659175674 := by decide
theorem cert_e412612664570 : check e412612664570 [] .sourceHead = true := by decide
def e412612665142 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e412612665142 : Closed e412612665142 ∧ code e412612665142 = 4810659176246 := by decide
theorem cert_e412612665142 : check e412612665142 [] .sourceHead = true := by decide
def e412612665146 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e412612665146 : Closed e412612665146 ∧ code e412612665146 = 4810659176250 := by decide
theorem cert_e412612665146 : check e412612665146 [] .sourceHead = true := by decide
def e412612676446 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e412612676446 : Closed e412612676446 ∧ code e412612676446 = 4810659187550 := by decide
theorem cert_e412612676446 : check e412612676446 [] .sourceHead = true := by decide
def e412612676474 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e412612676474 : Closed e412612676474 ∧ code e412612676474 = 4810659187578 := by decide
theorem cert_e412612676474 : check e412612676474 [] .sourceHead = true := by decide
def e412612676586 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e412612676586 : Closed e412612676586 ∧ code e412612676586 = 4810659187690 := by decide
theorem cert_e412612676586 : check e412612676586 [] .sourceHead = true := by decide
def e412612676830 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e412612676830 : Closed e412612676830 ∧ code e412612676830 = 4810659187934 := by decide
theorem cert_e412612676830 : check e412612676830 [] .sourceHead = true := by decide
def e412612676858 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e412612676858 : Closed e412612676858 ∧ code e412612676858 = 4810659187962 := by decide
theorem cert_e412612676858 : check e412612676858 [] .sourceHead = true := by decide
def e412612677530 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e412612677530 : Closed e412612677530 ∧ code e412612677530 = 4810659188634 := by decide
theorem cert_e412612677530 : check e412612677530 [] .sourceHead = true := by decide
def e412612686550 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e412612686550 : Closed e412612686550 ∧ code e412612686550 = 4810659197654 := by decide
theorem cert_e412612686550 : check e412612686550 [] .sourceHead = true := by decide
def e412612686554 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e412612686554 : Closed e412612686554 ∧ code e412612686554 = 4810659197658 := by decide
theorem cert_e412612686554 : check e412612686554 [] .sourceHead = true := by decide
def e412612686570 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e412612686570 : Closed e412612686570 ∧ code e412612686570 = 4810659197674 := by decide
theorem cert_e412612686570 : check e412612686570 [] .sourceHead = true := by decide
def e412612686646 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e412612686646 : Closed e412612686646 ∧ code e412612686646 = 4810659197750 := by decide
theorem cert_e412612686646 : check e412612686646 [] .sourceHead = true := by decide
def e412612686650 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e412612686650 : Closed e412612686650 ∧ code e412612686650 = 4810659197754 := by decide
theorem cert_e412612686650 : check e412612686650 [] .sourceHead = true := by decide
def e412612686746 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e412612686746 : Closed e412612686746 ∧ code e412612686746 = 4810659197850 := by decide
theorem cert_e412612686746 : check e412612686746 [] .sourceHead = true := by decide
def e413481529542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481529542 : Closed e413481529542 ∧ code e413481529542 = 4811528040646 := by decide
theorem cert_e413481529542 : check e413481529542 [] .sourceHead = true := by decide
def e413481545926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481545926 : Closed e413481545926 ∧ code e413481545926 = 4811528057030 := by decide
theorem cert_e413481545926 : check e413481545926 [] .sourceHead = true := by decide
def e413481660614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481660614 : Closed e413481660614 ∧ code e413481660614 = 4811528171718 := by decide
theorem cert_e413481660614 : check e413481660614 [] .sourceHead = true := by decide
def e413481685190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481685190 : Closed e413481685190 ∧ code e413481685190 = 4811528196294 := by decide
theorem cert_e413481685190 : check e413481685190 [] .sourceHead = true := by decide
def e413481742534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481742534 : Closed e413481742534 ∧ code e413481742534 = 4811528253638 := by decide
theorem cert_e413481742534 : check e413481742534 [] .sourceHead = true := by decide
def e413481750726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413481750726 : Closed e413481750726 ∧ code e413481750726 = 4811528261830 := by decide
theorem cert_e413481750726 : check e413481750726 [] .sourceHead = true := by decide
def e413482184902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482184902 : Closed e413482184902 ∧ code e413482184902 = 4811528696006 := by decide
theorem cert_e413482184902 : check e413482184902 [] .sourceHead = true := by decide
def e413482209478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482209478 : Closed e413482209478 ∧ code e413482209478 = 4811528720582 := by decide
theorem cert_e413482209478 : check e413482209478 [] .sourceHead = true := by decide
def e413482307782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482307782 : Closed e413482307782 ∧ code e413482307782 = 4811528818886 := by decide
theorem cert_e413482307782 : check e413482307782 [] .sourceHead = true := by decide
def e413482528966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482528966 : Closed e413482528966 ∧ code e413482528966 = 4811529040070 := by decide
theorem cert_e413482528966 : check e413482528966 [] .sourceHead = true := by decide
def e413482537158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482537158 : Closed e413482537158 ∧ code e413482537158 = 4811529048262 := by decide
theorem cert_e413482537158 : check e413482537158 [] .sourceHead = true := by decide
def e413482569926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413482569926 : Closed e413482569926 ∧ code e413482569926 = 4811529081030 := by decide
theorem cert_e413482569926 : check e413482569926 [] .sourceHead = true := by decide
def e413484675270 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484675270 : Closed e413484675270 ∧ code e413484675270 = 4811531186374 := by decide
theorem cert_e413484675270 : check e413484675270 [] .sourceHead = true := by decide
def e413484691654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484691654 : Closed e413484691654 ∧ code e413484691654 = 4811531202758 := by decide
theorem cert_e413484691654 : check e413484691654 [] .sourceHead = true := by decide
def e413484806342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484806342 : Closed e413484806342 ∧ code e413484806342 = 4811531317446 := by decide
theorem cert_e413484806342 : check e413484806342 [] .sourceHead = true := by decide
def e413484830918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484830918 : Closed e413484830918 ∧ code e413484830918 = 4811531342022 := by decide
theorem cert_e413484830918 : check e413484830918 [] .sourceHead = true := by decide
def e413484888262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484888262 : Closed e413484888262 ∧ code e413484888262 = 4811531399366 := by decide
theorem cert_e413484888262 : check e413484888262 [] .sourceHead = true := by decide
def e413484896454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413484896454 : Closed e413484896454 ∧ code e413484896454 = 4811531407558 := by decide
theorem cert_e413484896454 : check e413484896454 [] .sourceHead = true := by decide
def e413485461702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413485461702 : Closed e413485461702 ∧ code e413485461702 = 4811531972806 := by decide
theorem cert_e413485461702 : check e413485461702 [] .sourceHead = true := by decide
def e413485478086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413485478086 : Closed e413485478086 ∧ code e413485478086 = 4811531989190 := by decide
theorem cert_e413485478086 : check e413485478086 [] .sourceHead = true := by decide
def e413486248134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413486248134 : Closed e413486248134 ∧ code e413486248134 = 4811532759238 := by decide
theorem cert_e413486248134 : check e413486248134 [] .sourceHead = true := by decide
def e413486272710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413486272710 : Closed e413486272710 ∧ code e413486272710 = 4811532783814 := by decide
theorem cert_e413486272710 : check e413486272710 [] .sourceHead = true := by decide
def e413486657734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413486657734 : Closed e413486657734 ∧ code e413486657734 = 4811533168838 := by decide
theorem cert_e413486657734 : check e413486657734 [] .sourceHead = true := by decide
def e413486665926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413486665926 : Closed e413486665926 ∧ code e413486665926 = 4811533177030 := by decide
theorem cert_e413486665926 : check e413486665926 [] .sourceHead = true := by decide
def e413487952070 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413487952070 : Closed e413487952070 ∧ code e413487952070 = 4811534463174 := by decide
theorem cert_e413487952070 : check e413487952070 [] .sourceHead = true := by decide
def e413487976646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413487976646 : Closed e413487976646 ∧ code e413487976646 = 4811534487750 := by decide
theorem cert_e413487976646 : check e413487976646 [] .sourceHead = true := by decide
def e413488074950 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413488074950 : Closed e413488074950 ∧ code e413488074950 = 4811534586054 := by decide
theorem cert_e413488074950 : check e413488074950 [] .sourceHead = true := by decide
def e413488345286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413488345286 : Closed e413488345286 ∧ code e413488345286 = 4811534856390 := by decide
theorem cert_e413488345286 : check e413488345286 [] .sourceHead = true := by decide
def e413488369862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413488369862 : Closed e413488369862 ∧ code e413488369862 = 4811534880966 := by decide
theorem cert_e413488369862 : check e413488369862 [] .sourceHead = true := by decide
def e413488959686 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413488959686 : Closed e413488959686 ∧ code e413488959686 = 4811535470790 := by decide
theorem cert_e413488959686 : check e413488959686 [] .sourceHead = true := by decide
def e413489606854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413489606854 : Closed e413489606854 ∧ code e413489606854 = 4811536117958 := by decide
theorem cert_e413489606854 : check e413489606854 [] .sourceHead = true := by decide
def e413489615046 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413489615046 : Closed e413489615046 ∧ code e413489615046 = 4811536126150 := by decide
theorem cert_e413489615046 : check e413489615046 [] .sourceHead = true := by decide
def e413489647814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413489647814 : Closed e413489647814 ∧ code e413489647814 = 4811536158918 := by decide
theorem cert_e413489647814 : check e413489647814 [] .sourceHead = true := by decide
def e413489803462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413489803462 : Closed e413489803462 ∧ code e413489803462 = 4811536314566 := by decide
theorem cert_e413489803462 : check e413489803462 [] .sourceHead = true := by decide
def e413489811654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413489811654 : Closed e413489811654 ∧ code e413489811654 = 4811536322758 := by decide
theorem cert_e413489811654 : check e413489811654 [] .sourceHead = true := by decide
def e413490008262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413490008262 : Closed e413490008262 ∧ code e413490008262 = 4811536519366 := by decide
theorem cert_e413490008262 : check e413490008262 [] .sourceHead = true := by decide
def e413494455662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e413494455662 : Closed e413494455662 ∧ code e413494455662 = 4811540966766 := by decide
theorem cert_e413494455662 : check e413494455662 [] .sourceHead = true := by decide
def e413494455670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e413494455670 : Closed e413494455670 ∧ code e413494455670 = 4811540966774 := by decide
theorem cert_e413494455670 : check e413494455670 [] .sourceHead = true := by decide
def e413494455726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e413494455726 : Closed e413494455726 ∧ code e413494455726 = 4811540966830 := by decide
theorem cert_e413494455726 : check e413494455726 [] .sourceHead = true := by decide
def e413494455738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e413494455738 : Closed e413494455738 ∧ code e413494455738 = 4811540966842 := by decide
theorem cert_e413494455738 : check e413494455738 [] .sourceHead = true := by decide
def e413494455766 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e413494455766 : Closed e413494455766 ∧ code e413494455766 = 4811540966870 := by decide
theorem cert_e413494455766 : check e413494455766 [] .sourceHead = true := by decide
def e413494455770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e413494455770 : Closed e413494455770 ∧ code e413494455770 = 4811540966874 := by decide
theorem cert_e413494455770 : check e413494455770 [] .sourceHead = true := by decide
def e413494455982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e413494455982 : Closed e413494455982 ∧ code e413494455982 = 4811540967086 := by decide
theorem cert_e413494455982 : check e413494455982 [] .sourceHead = true := by decide
def e413494455994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e413494455994 : Closed e413494455994 ∧ code e413494455994 = 4811540967098 := by decide
theorem cert_e413494455994 : check e413494455994 [] .sourceHead = true := by decide
def e413494456042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e413494456042 : Closed e413494456042 ∧ code e413494456042 = 4811540967146 := by decide
theorem cert_e413494456042 : check e413494456042 [] .sourceHead = true := by decide
def e413494456150 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e413494456150 : Closed e413494456150 ∧ code e413494456150 = 4811540967254 := by decide
theorem cert_e413494456150 : check e413494456150 [] .sourceHead = true := by decide
def e413494456154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e413494456154 : Closed e413494456154 ∧ code e413494456154 = 4811540967258 := by decide
theorem cert_e413494456154 : check e413494456154 [] .sourceHead = true := by decide
def e413494456170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e413494456170 : Closed e413494456170 ∧ code e413494456170 = 4811540967274 := by decide
theorem cert_e413494456170 : check e413494456170 [] .sourceHead = true := by decide
def e413494457198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e413494457198 : Closed e413494457198 ∧ code e413494457198 = 4811540968302 := by decide
theorem cert_e413494457198 : check e413494457198 [] .sourceHead = true := by decide
def e413494457206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e413494457206 : Closed e413494457206 ∧ code e413494457206 = 4811540968310 := by decide
theorem cert_e413494457206 : check e413494457206 [] .sourceHead = true := by decide
def e413494457262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e413494457262 : Closed e413494457262 ∧ code e413494457262 = 4811540968366 := by decide
theorem cert_e413494457262 : check e413494457262 [] .sourceHead = true := by decide
def e413494457274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e413494457274 : Closed e413494457274 ∧ code e413494457274 = 4811540968378 := by decide
theorem cert_e413494457274 : check e413494457274 [] .sourceHead = true := by decide
def e413494457302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e413494457302 : Closed e413494457302 ∧ code e413494457302 = 4811540968406 := by decide
theorem cert_e413494457302 : check e413494457302 [] .sourceHead = true := by decide
def e413494457306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e413494457306 : Closed e413494457306 ∧ code e413494457306 = 4811540968410 := by decide
theorem cert_e413494457306 : check e413494457306 [] .sourceHead = true := by decide
def e413494457582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e413494457582 : Closed e413494457582 ∧ code e413494457582 = 4811540968686 := by decide
theorem cert_e413494457582 : check e413494457582 [] .sourceHead = true := by decide
def e413494457590 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e413494457590 : Closed e413494457590 ∧ code e413494457590 = 4811540968694 := by decide
theorem cert_e413494457590 : check e413494457590 [] .sourceHead = true := by decide
def e413494457966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e413494457966 : Closed e413494457966 ∧ code e413494457966 = 4811540969070 := by decide
theorem cert_e413494457966 : check e413494457966 [] .sourceHead = true := by decide
def e413494457978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e413494457978 : Closed e413494457978 ∧ code e413494457978 = 4811540969082 := by decide
theorem cert_e413494457978 : check e413494457978 [] .sourceHead = true := by decide
def e413494458166 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e413494458166 : Closed e413494458166 ∧ code e413494458166 = 4811540969270 := by decide
theorem cert_e413494458166 : check e413494458166 [] .sourceHead = true := by decide
def e413494458170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e413494458170 : Closed e413494458170 ∧ code e413494458170 = 4811540969274 := by decide
theorem cert_e413494458170 : check e413494458170 [] .sourceHead = true := by decide
def e413494458798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e413494458798 : Closed e413494458798 ∧ code e413494458798 = 4811540969902 := by decide
theorem cert_e413494458798 : check e413494458798 [] .sourceHead = true := by decide
def e413494458810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e413494458810 : Closed e413494458810 ∧ code e413494458810 = 4811540969914 := by decide
theorem cert_e413494458810 : check e413494458810 [] .sourceHead = true := by decide
def e413494458858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e413494458858 : Closed e413494458858 ∧ code e413494458858 = 4811540969962 := by decide
theorem cert_e413494458858 : check e413494458858 [] .sourceHead = true := by decide
def e413494458990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e413494458990 : Closed e413494458990 ∧ code e413494458990 = 4811540970094 := by decide
theorem cert_e413494458990 : check e413494458990 [] .sourceHead = true := by decide
def e413494459002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e413494459002 : Closed e413494459002 ∧ code e413494459002 = 4811540970106 := by decide
theorem cert_e413494459002 : check e413494459002 [] .sourceHead = true := by decide
def e413494459290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e413494459290 : Closed e413494459290 ∧ code e413494459290 = 4811540970394 := by decide
theorem cert_e413494459290 : check e413494459290 [] .sourceHead = true := by decide
def e413494459606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e413494459606 : Closed e413494459606 ∧ code e413494459606 = 4811540970710 := by decide
theorem cert_e413494459606 : check e413494459606 [] .sourceHead = true := by decide
def e413494459610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e413494459610 : Closed e413494459610 ∧ code e413494459610 = 4811540970714 := by decide
theorem cert_e413494459610 : check e413494459610 [] .sourceHead = true := by decide
def e413494459626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e413494459626 : Closed e413494459626 ∧ code e413494459626 = 4811540970730 := by decide
theorem cert_e413494459626 : check e413494459626 [] .sourceHead = true := by decide
def e413494459702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e413494459702 : Closed e413494459702 ∧ code e413494459702 = 4811540970806 := by decide
theorem cert_e413494459702 : check e413494459702 [] .sourceHead = true := by decide
def e413494459706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e413494459706 : Closed e413494459706 ∧ code e413494459706 = 4811540970810 := by decide
theorem cert_e413494459706 : check e413494459706 [] .sourceHead = true := by decide
def e413494459802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e413494459802 : Closed e413494459802 ∧ code e413494459802 = 4811540970906 := by decide
theorem cert_e413494459802 : check e413494459802 [] .sourceHead = true := by decide
def e413494463342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e413494463342 : Closed e413494463342 ∧ code e413494463342 = 4811540974446 := by decide
theorem cert_e413494463342 : check e413494463342 [] .sourceHead = true := by decide
def e413494463350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e413494463350 : Closed e413494463350 ∧ code e413494463350 = 4811540974454 := by decide
theorem cert_e413494463350 : check e413494463350 [] .sourceHead = true := by decide
def e413494463406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e413494463406 : Closed e413494463406 ∧ code e413494463406 = 4811540974510 := by decide
theorem cert_e413494463406 : check e413494463406 [] .sourceHead = true := by decide
def e413494463418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e413494463418 : Closed e413494463418 ∧ code e413494463418 = 4811540974522 := by decide
theorem cert_e413494463418 : check e413494463418 [] .sourceHead = true := by decide
def e413494463446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e413494463446 : Closed e413494463446 ∧ code e413494463446 = 4811540974550 := by decide
theorem cert_e413494463446 : check e413494463446 [] .sourceHead = true := by decide
def e413494463450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e413494463450 : Closed e413494463450 ∧ code e413494463450 = 4811540974554 := by decide
theorem cert_e413494463450 : check e413494463450 [] .sourceHead = true := by decide
def e413494463726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e413494463726 : Closed e413494463726 ∧ code e413494463726 = 4811540974830 := by decide
theorem cert_e413494463726 : check e413494463726 [] .sourceHead = true := by decide
def e413494463734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e413494463734 : Closed e413494463734 ∧ code e413494463734 = 4811540974838 := by decide
theorem cert_e413494463734 : check e413494463734 [] .sourceHead = true := by decide
def e413494464110 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e413494464110 : Closed e413494464110 ∧ code e413494464110 = 4811540975214 := by decide
theorem cert_e413494464110 : check e413494464110 [] .sourceHead = true := by decide
def e413494464122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e413494464122 : Closed e413494464122 ∧ code e413494464122 = 4811540975226 := by decide
theorem cert_e413494464122 : check e413494464122 [] .sourceHead = true := by decide
def e413494464310 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e413494464310 : Closed e413494464310 ∧ code e413494464310 = 4811540975414 := by decide
theorem cert_e413494464310 : check e413494464310 [] .sourceHead = true := by decide
def e413494464314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e413494464314 : Closed e413494464314 ∧ code e413494464314 = 4811540975418 := by decide
theorem cert_e413494464314 : check e413494464314 [] .sourceHead = true := by decide
def e413494470062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e413494470062 : Closed e413494470062 ∧ code e413494470062 = 4811540981166 := by decide
theorem cert_e413494470062 : check e413494470062 [] .sourceHead = true := by decide
def e413494470074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e413494470074 : Closed e413494470074 ∧ code e413494470074 = 4811540981178 := by decide
theorem cert_e413494470074 : check e413494470074 [] .sourceHead = true := by decide
def e413494470122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e413494470122 : Closed e413494470122 ∧ code e413494470122 = 4811540981226 := by decide
theorem cert_e413494470122 : check e413494470122 [] .sourceHead = true := by decide
def e413494470254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e413494470254 : Closed e413494470254 ∧ code e413494470254 = 4811540981358 := by decide
theorem cert_e413494470254 : check e413494470254 [] .sourceHead = true := by decide
def e413494470266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e413494470266 : Closed e413494470266 ∧ code e413494470266 = 4811540981370 := by decide
theorem cert_e413494470266 : check e413494470266 [] .sourceHead = true := by decide
def e413494470554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e413494470554 : Closed e413494470554 ∧ code e413494470554 = 4811540981658 := by decide
theorem cert_e413494470554 : check e413494470554 [] .sourceHead = true := by decide
def e413494473430 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e413494473430 : Closed e413494473430 ∧ code e413494473430 = 4811540984534 := by decide
theorem cert_e413494473430 : check e413494473430 [] .sourceHead = true := by decide
def e413494473434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e413494473434 : Closed e413494473434 ∧ code e413494473434 = 4811540984538 := by decide
theorem cert_e413494473434 : check e413494473434 [] .sourceHead = true := by decide
def e413494473450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e413494473450 : Closed e413494473450 ∧ code e413494473450 = 4811540984554 := by decide
theorem cert_e413494473450 : check e413494473450 [] .sourceHead = true := by decide
def e413494473526 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e413494473526 : Closed e413494473526 ∧ code e413494473526 = 4811540984630 := by decide
theorem cert_e413494473526 : check e413494473526 [] .sourceHead = true := by decide
def e413494473530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e413494473530 : Closed e413494473530 ∧ code e413494473530 = 4811540984634 := by decide
theorem cert_e413494473530 : check e413494473530 [] .sourceHead = true := by decide
def e413494473626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e413494473626 : Closed e413494473626 ∧ code e413494473626 = 4811540984730 := by decide
theorem cert_e413494473626 : check e413494473626 [] .sourceHead = true := by decide
def e413497258182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497258182 : Closed e413497258182 ∧ code e413497258182 = 4811543769286 := by decide
theorem cert_e413497258182 : check e413497258182 [] .sourceHead = true := by decide
def e413497274566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497274566 : Closed e413497274566 ∧ code e413497274566 = 4811543785670 := by decide
theorem cert_e413497274566 : check e413497274566 [] .sourceHead = true := by decide
def e413497389254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497389254 : Closed e413497389254 ∧ code e413497389254 = 4811543900358 := by decide
theorem cert_e413497389254 : check e413497389254 [] .sourceHead = true := by decide
def e413497413830 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497413830 : Closed e413497413830 ∧ code e413497413830 = 4811543924934 := by decide
theorem cert_e413497413830 : check e413497413830 [] .sourceHead = true := by decide
def e413497471174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497471174 : Closed e413497471174 ∧ code e413497471174 = 4811543982278 := by decide
theorem cert_e413497471174 : check e413497471174 [] .sourceHead = true := by decide
def e413497479366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413497479366 : Closed e413497479366 ∧ code e413497479366 = 4811543990470 := by decide
theorem cert_e413497479366 : check e413497479366 [] .sourceHead = true := by decide
def e413498044614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413498044614 : Closed e413498044614 ∧ code e413498044614 = 4811544555718 := by decide
theorem cert_e413498044614 : check e413498044614 [] .sourceHead = true := by decide
def e413498060998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413498060998 : Closed e413498060998 ∧ code e413498060998 = 4811544572102 := by decide
theorem cert_e413498060998 : check e413498060998 [] .sourceHead = true := by decide
def e413498831046 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413498831046 : Closed e413498831046 ∧ code e413498831046 = 4811545342150 := by decide
theorem cert_e413498831046 : check e413498831046 [] .sourceHead = true := by decide
def e413498855622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413498855622 : Closed e413498855622 ∧ code e413498855622 = 4811545366726 := by decide
theorem cert_e413498855622 : check e413498855622 [] .sourceHead = true := by decide
def e413499240646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413499240646 : Closed e413499240646 ∧ code e413499240646 = 4811545751750 := by decide
theorem cert_e413499240646 : check e413499240646 [] .sourceHead = true := by decide
def e413499248838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413499248838 : Closed e413499248838 ∧ code e413499248838 = 4811545759942 := by decide
theorem cert_e413499248838 : check e413499248838 [] .sourceHead = true := by decide
def e413499742942 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e413499742942 : Closed e413499742942 ∧ code e413499742942 = 4811546254046 := by decide
theorem cert_e413499742942 : check e413499742942 [] .sourceHead = true := by decide
def e413499742966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e413499742966 : Closed e413499742966 ∧ code e413499742966 = 4811546254070 := by decide
theorem cert_e413499742966 : check e413499742966 [] .sourceHead = true := by decide
end Blc.Floor42
