import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186529110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186529110 : Closed e1211186529110 ∧ code e1211186529110 = 5609233040214 := by decide
private def t_e1211186529110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)))))))
theorem cert_e1211186529110 : ¬ IsSelfInterpreter e1211186529110 :=
  wSource (t := t_e1211186529110) (replay_sound (ps := []) (t := e1211186529110) (by decide)) (by decide)
def e1211186529114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186529114 : Closed e1211186529114 ∧ code e1211186529114 = 5609233040218 := by decide
private def t_e1211186529114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)))))))
theorem cert_e1211186529114 : ¬ IsSelfInterpreter e1211186529114 :=
  wSource (t := t_e1211186529114) (replay_sound (ps := []) (t := e1211186529114) (by decide)) (by decide)
def e1211186529494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211186529494 : Closed e1211186529494 ∧ code e1211186529494 = 5609233040598 := by decide
theorem cert_e1211186529494 : check e1211186529494 [[],[]] .three = true := by decide
def e1211186529498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211186529498 : Closed e1211186529498 ∧ code e1211186529498 = 5609233040602 := by decide
theorem cert_e1211186529498 : check e1211186529498 [[],[]] .three = true := by decide
def e1211186529514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211186529514 : Closed e1211186529514 ∧ code e1211186529514 = 5609233040618 := by decide
theorem cert_e1211186529514 : check e1211186529514 [[],[]] .three = true := by decide
def e1211186529590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186529590 : Closed e1211186529590 ∧ code e1211186529590 = 5609233040694 := by decide
theorem cert_e1211186529590 : check e1211186529590 [[],[]] .three = true := by decide
def e1211186529594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186529594 : Closed e1211186529594 ∧ code e1211186529594 = 5609233040698 := by decide
theorem cert_e1211186529594 : check e1211186529594 [[],[]] .three = true := by decide
def e1211186529690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186529690 : Closed e1211186529690 ∧ code e1211186529690 = 5609233040794 := by decide
theorem cert_e1211186529690 : check e1211186529690 [[],[]] .three = true := by decide
def e1211186529846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186529846 : Closed e1211186529846 ∧ code e1211186529846 = 5609233040950 := by decide
theorem cert_e1211186529846 : check e1211186529846 [[],[]] .three = true := by decide
def e1211186529850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186529850 : Closed e1211186529850 ∧ code e1211186529850 = 5609233040954 := by decide
theorem cert_e1211186529850 : check e1211186529850 [[],[]] .three = true := by decide
def e1211186529934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186529934 : Closed e1211186529934 ∧ code e1211186529934 = 5609233041038 := by decide
theorem cert_e1211186529934 : check e1211186529934 [[],[]] .three = true := by decide
def e1211186529990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186529990 : Closed e1211186529990 ∧ code e1211186529990 = 5609233041094 := by decide
theorem cert_e1211186529990 : check e1211186529990 [[],[]] .three = true := by decide
def e1211186530014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e1211186530014 : Closed e1211186530014 ∧ code e1211186530014 = 5609233041118 := by decide
theorem cert_e1211186530014 : check e1211186530014 [[],[]] .three = true := by decide
def e1211186530030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211186530030 : Closed e1211186530030 ∧ code e1211186530030 = 5609233041134 := by decide
theorem cert_e1211186530030 : check e1211186530030 [[],[]] .three = true := by decide
def e1211186530038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e1211186530038 : Closed e1211186530038 ∧ code e1211186530038 = 5609233041142 := by decide
theorem cert_e1211186530038 : check e1211186530038 [[],[]] .three = true := by decide
def e1211186530074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186530074 : Closed e1211186530074 ∧ code e1211186530074 = 5609233041178 := by decide
theorem cert_e1211186530074 : check e1211186530074 [[],[]] .three = true := by decide
def e1211186530118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186530118 : Closed e1211186530118 ∧ code e1211186530118 = 5609233041222 := by decide
theorem cert_e1211186530118 : check e1211186530118 [[],[]] .three = true := by decide
def e1211186530142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e1211186530142 : Closed e1211186530142 ∧ code e1211186530142 = 5609233041246 := by decide
theorem cert_e1211186530142 : check e1211186530142 [[],[]] .three = true := by decide
def e1211186530158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211186530158 : Closed e1211186530158 ∧ code e1211186530158 = 5609233041262 := by decide
theorem cert_e1211186530158 : check e1211186530158 [[],[]] .three = true := by decide
def e1211186530166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211186530166 : Closed e1211186530166 ∧ code e1211186530166 = 5609233041270 := by decide
theorem cert_e1211186530166 : check e1211186530166 [[],[]] .three = true := by decide
def e1211186530170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e1211186530170 : Closed e1211186530170 ∧ code e1211186530170 = 5609233041274 := by decide
theorem cert_e1211186530170 : check e1211186530170 [[],[]] .three = true := by decide
def e1211186530222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211186530222 : Closed e1211186530222 ∧ code e1211186530222 = 5609233041326 := by decide
theorem cert_e1211186530222 : check e1211186530222 [[],[]] .three = true := by decide
def e1211186530230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211186530230 : Closed e1211186530230 ∧ code e1211186530230 = 5609233041334 := by decide
theorem cert_e1211186530230 : check e1211186530230 [[],[]] .three = true := by decide
def e1211186530234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211186530234 : Closed e1211186530234 ∧ code e1211186530234 = 5609233041338 := by decide
theorem cert_e1211186530234 : check e1211186530234 [[],[]] .three = true := by decide
def e1211186530262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e1211186530262 : Closed e1211186530262 ∧ code e1211186530262 = 5609233041366 := by decide
theorem cert_e1211186530262 : check e1211186530262 [[],[]] .three = true := by decide
def e1211186530266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e1211186530266 : Closed e1211186530266 ∧ code e1211186530266 = 5609233041370 := by decide
theorem cert_e1211186530266 : check e1211186530266 [[],[]] .three = true := by decide
def e1211186531414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186531414 : Closed e1211186531414 ∧ code e1211186531414 = 5609233042518 := by decide
theorem cert_e1211186531414 : check e1211186531414 [[],[]] .three = true := by decide
def e1211186531418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186531418 : Closed e1211186531418 ∧ code e1211186531418 = 5609233042522 := by decide
theorem cert_e1211186531418 : check e1211186531418 [[],[]] .three = true := by decide
def e1211186531606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186531606 : Closed e1211186531606 ∧ code e1211186531606 = 5609233042710 := by decide
theorem cert_e1211186531606 : check e1211186531606 [[],[]] .three = true := by decide
def e1211186531682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186531682 : Closed e1211186531682 ∧ code e1211186531682 = 5609233042786 := by decide
theorem cert_e1211186531682 : check e1211186531682 [[],[]] .three = true := by decide
def e1211186531694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186531694 : Closed e1211186531694 ∧ code e1211186531694 = 5609233042798 := by decide
theorem cert_e1211186531694 : check e1211186531694 [[],[]] .three = true := by decide
def e1211186531702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186531702 : Closed e1211186531702 ∧ code e1211186531702 = 5609233042806 := by decide
theorem cert_e1211186531702 : check e1211186531702 [[],[]] .three = true := by decide
def e1211186531722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186531722 : Closed e1211186531722 ∧ code e1211186531722 = 5609233042826 := by decide
theorem cert_e1211186531722 : check e1211186531722 [[],[]] .three = true := by decide
def e1211186531746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186531746 : Closed e1211186531746 ∧ code e1211186531746 = 5609233042850 := by decide
theorem cert_e1211186531746 : check e1211186531746 [[],[]] .three = true := by decide
def e1211186531758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186531758 : Closed e1211186531758 ∧ code e1211186531758 = 5609233042862 := by decide
theorem cert_e1211186531758 : check e1211186531758 [[],[]] .three = true := by decide
def e1211186531766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1211186531766 : Closed e1211186531766 ∧ code e1211186531766 = 5609233042870 := by decide
theorem cert_e1211186531766 : check e1211186531766 [[],[]] .three = true := by decide
def e1211186531770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186531770 : Closed e1211186531770 ∧ code e1211186531770 = 5609233042874 := by decide
theorem cert_e1211186531770 : check e1211186531770 [[],[]] .three = true := by decide
def e1211186531798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211186531798 : Closed e1211186531798 ∧ code e1211186531798 = 5609233042902 := by decide
theorem cert_e1211186531798 : check e1211186531798 [[],[]] .three = true := by decide
def e1211186531802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211186531802 : Closed e1211186531802 ∧ code e1211186531802 = 5609233042906 := by decide
theorem cert_e1211186531802 : check e1211186531802 [[],[]] .three = true := by decide
def e1211186531882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186531882 : Closed e1211186531882 ∧ code e1211186531882 = 5609233042986 := by decide
theorem cert_e1211186531882 : check e1211186531882 [[],[]] .three = true := by decide
def e1211186531978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186531978 : Closed e1211186531978 ∧ code e1211186531978 = 5609233043082 := by decide
theorem cert_e1211186531978 : check e1211186531978 [[],[]] .three = true := by decide
def e1211186532002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186532002 : Closed e1211186532002 ∧ code e1211186532002 = 5609233043106 := by decide
theorem cert_e1211186532002 : check e1211186532002 [[],[]] .three = true := by decide
def e1211186532014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211186532014 : Closed e1211186532014 ∧ code e1211186532014 = 5609233043118 := by decide
theorem cert_e1211186532014 : check e1211186532014 [[],[]] .three = true := by decide
def e1211186532022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211186532022 : Closed e1211186532022 ∧ code e1211186532022 = 5609233043126 := by decide
theorem cert_e1211186532022 : check e1211186532022 [[],[]] .three = true := by decide
def e1211186532026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211186532026 : Closed e1211186532026 ∧ code e1211186532026 = 5609233043130 := by decide
theorem cert_e1211186532026 : check e1211186532026 [[],[]] .three = true := by decide
def e1211186532054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211186532054 : Closed e1211186532054 ∧ code e1211186532054 = 5609233043158 := by decide
theorem cert_e1211186532054 : check e1211186532054 [[],[]] .three = true := by decide
def e1211186532058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211186532058 : Closed e1211186532058 ∧ code e1211186532058 = 5609233043162 := by decide
theorem cert_e1211186532058 : check e1211186532058 [[],[]] .three = true := by decide
def e1211186532074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211186532074 : Closed e1211186532074 ∧ code e1211186532074 = 5609233043178 := by decide
theorem cert_e1211186532074 : check e1211186532074 [[],[]] .three = true := by decide
def e1211186532182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186532182 : Closed e1211186532182 ∧ code e1211186532182 = 5609233043286 := by decide
theorem cert_e1211186532182 : check e1211186532182 [[],[]] .three = true := by decide
def e1211186532186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186532186 : Closed e1211186532186 ∧ code e1211186532186 = 5609233043290 := by decide
theorem cert_e1211186532186 : check e1211186532186 [[],[]] .three = true := by decide
def e1211186532202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211186532202 : Closed e1211186532202 ∧ code e1211186532202 = 5609233043306 := by decide
theorem cert_e1211186532202 : check e1211186532202 [[],[]] .three = true := by decide
def e1211186532470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211186532470 : Closed e1211186532470 ∧ code e1211186532470 = 5609233043574 := by decide
theorem cert_e1211186532470 : check e1211186532470 [[],[]] .three = true := by decide
def e1211186532474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186532474 : Closed e1211186532474 ∧ code e1211186532474 = 5609233043578 := by decide
theorem cert_e1211186532474 : check e1211186532474 [[],[]] .three = true := by decide
def e1211186532566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211186532566 : Closed e1211186532566 ∧ code e1211186532566 = 5609233043670 := by decide
theorem cert_e1211186532566 : check e1211186532566 [[],[]] .three = true := by decide
def e1211186532662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186532662 : Closed e1211186532662 ∧ code e1211186532662 = 5609233043766 := by decide
theorem cert_e1211186532662 : check e1211186532662 [[],[]] .three = true := by decide
def e1211186532666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186532666 : Closed e1211186532666 ∧ code e1211186532666 = 5609233043770 := by decide
theorem cert_e1211186532666 : check e1211186532666 [[],[]] .three = true := by decide
def e1211186532750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211186532750 : Closed e1211186532750 ∧ code e1211186532750 = 5609233043854 := by decide
theorem cert_e1211186532750 : check e1211186532750 [[],[]] .three = true := by decide
def e1211186532806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186532806 : Closed e1211186532806 ∧ code e1211186532806 = 5609233043910 := by decide
theorem cert_e1211186532806 : check e1211186532806 [[],[]] .three = true := by decide
def e1211186532830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1211186532830 : Closed e1211186532830 ∧ code e1211186532830 = 5609233043934 := by decide
theorem cert_e1211186532830 : check e1211186532830 [[],[]] .three = true := by decide
def e1211186532846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211186532846 : Closed e1211186532846 ∧ code e1211186532846 = 5609233043950 := by decide
theorem cert_e1211186532846 : check e1211186532846 [[],[]] .three = true := by decide
def e1211186532854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1211186532854 : Closed e1211186532854 ∧ code e1211186532854 = 5609233043958 := by decide
theorem cert_e1211186532854 : check e1211186532854 [[],[]] .three = true := by decide
def e1211186533142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186533142 : Closed e1211186533142 ∧ code e1211186533142 = 5609233044246 := by decide
theorem cert_e1211186533142 : check e1211186533142 [[],[]] .three = true := by decide
def e1211186533218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186533218 : Closed e1211186533218 ∧ code e1211186533218 = 5609233044322 := by decide
theorem cert_e1211186533218 : check e1211186533218 [[],[]] .three = true := by decide
def e1211186533230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186533230 : Closed e1211186533230 ∧ code e1211186533230 = 5609233044334 := by decide
theorem cert_e1211186533230 : check e1211186533230 [[],[]] .three = true := by decide
def e1211186533238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186533238 : Closed e1211186533238 ∧ code e1211186533238 = 5609233044342 := by decide
theorem cert_e1211186533238 : check e1211186533238 [[],[]] .three = true := by decide
def e1211186533258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186533258 : Closed e1211186533258 ∧ code e1211186533258 = 5609233044362 := by decide
theorem cert_e1211186533258 : check e1211186533258 [[],[]] .three = true := by decide
def e1211186533282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186533282 : Closed e1211186533282 ∧ code e1211186533282 = 5609233044386 := by decide
theorem cert_e1211186533282 : check e1211186533282 [[],[]] .three = true := by decide
def e1211186533294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186533294 : Closed e1211186533294 ∧ code e1211186533294 = 5609233044398 := by decide
theorem cert_e1211186533294 : check e1211186533294 [[],[]] .three = true := by decide
def e1211186533302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e1211186533302 : Closed e1211186533302 ∧ code e1211186533302 = 5609233044406 := by decide
theorem cert_e1211186533302 : check e1211186533302 [[],[]] .three = true := by decide
def e1211186533306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186533306 : Closed e1211186533306 ∧ code e1211186533306 = 5609233044410 := by decide
theorem cert_e1211186533306 : check e1211186533306 [[],[]] .three = true := by decide
def e1211186533334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186533334 : Closed e1211186533334 ∧ code e1211186533334 = 5609233044438 := by decide
theorem cert_e1211186533334 : check e1211186533334 [[],[]] .three = true := by decide
def e1211186533338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186533338 : Closed e1211186533338 ∧ code e1211186533338 = 5609233044442 := by decide
theorem cert_e1211186533338 : check e1211186533338 [[],[]] .three = true := by decide
def e1211186533406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186533406 : Closed e1211186533406 ∧ code e1211186533406 = 5609233044510 := by decide
theorem cert_e1211186533406 : check e1211186533406 [[],[]] .three = true := by decide
def e1211186533602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186533602 : Closed e1211186533602 ∧ code e1211186533602 = 5609233044706 := by decide
theorem cert_e1211186533602 : check e1211186533602 [[],[]] .three = true := by decide
def e1211186533614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186533614 : Closed e1211186533614 ∧ code e1211186533614 = 5609233044718 := by decide
theorem cert_e1211186533614 : check e1211186533614 [[],[]] .three = true := by decide
def e1211186533622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186533622 : Closed e1211186533622 ∧ code e1211186533622 = 5609233044726 := by decide
theorem cert_e1211186533622 : check e1211186533622 [[],[]] .three = true := by decide
def e1211186533902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186533902 : Closed e1211186533902 ∧ code e1211186533902 = 5609233045006 := by decide
theorem cert_e1211186533902 : check e1211186533902 [[],[]] .three = true := by decide
def e1211186533914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186533914 : Closed e1211186533914 ∧ code e1211186533914 = 5609233045018 := by decide
theorem cert_e1211186533914 : check e1211186533914 [[],[]] .three = true := by decide
def e1211186533950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1211186533950 : Closed e1211186533950 ∧ code e1211186533950 = 5609233045054 := by decide
theorem cert_e1211186533950 : check e1211186533950 [[],[]] .three = true := by decide
def e1211186533986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186533986 : Closed e1211186533986 ∧ code e1211186533986 = 5609233045090 := by decide
theorem cert_e1211186533986 : check e1211186533986 [[],[]] .three = true := by decide
def e1211186533998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186533998 : Closed e1211186533998 ∧ code e1211186533998 = 5609233045102 := by decide
theorem cert_e1211186533998 : check e1211186533998 [[],[]] .three = true := by decide
def e1211186534006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186534006 : Closed e1211186534006 ∧ code e1211186534006 = 5609233045110 := by decide
theorem cert_e1211186534006 : check e1211186534006 [[],[]] .three = true := by decide
def e1211186534010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186534010 : Closed e1211186534010 ∧ code e1211186534010 = 5609233045114 := by decide
theorem cert_e1211186534010 : check e1211186534010 [[],[]] .three = true := by decide
def e1211186534174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211186534174 : Closed e1211186534174 ∧ code e1211186534174 = 5609233045278 := by decide
theorem cert_e1211186534174 : check e1211186534174 [[],[]] .three = true := by decide
def e1211186534198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186534198 : Closed e1211186534198 ∧ code e1211186534198 = 5609233045302 := by decide
theorem cert_e1211186534198 : check e1211186534198 [[],[]] .three = true := by decide
def e1211186534202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186534202 : Closed e1211186534202 ∧ code e1211186534202 = 5609233045306 := by decide
theorem cert_e1211186534202 : check e1211186534202 [[],[]] .three = true := by decide
def e1211186534286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1211186534286 : Closed e1211186534286 ∧ code e1211186534286 = 5609233045390 := by decide
theorem cert_e1211186534286 : check e1211186534286 [[],[]] .three = true := by decide
def e1211186534458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186534458 : Closed e1211186534458 ∧ code e1211186534458 = 5609233045562 := by decide
theorem cert_e1211186534458 : check e1211186534458 [[],[]] .three = true := by decide
def e1211186534506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211186534506 : Closed e1211186534506 ∧ code e1211186534506 = 5609233045610 := by decide
theorem cert_e1211186534506 : check e1211186534506 [[],[]] .three = true := by decide
def e1211186534554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186534554 : Closed e1211186534554 ∧ code e1211186534554 = 5609233045658 := by decide
theorem cert_e1211186534554 : check e1211186534554 [[],[]] .three = true := by decide
def e1211186534598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186534598 : Closed e1211186534598 ∧ code e1211186534598 = 5609233045702 := by decide
theorem cert_e1211186534598 : check e1211186534598 [[],[]] .three = true := by decide
def e1211186534622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1211186534622 : Closed e1211186534622 ∧ code e1211186534622 = 5609233045726 := by decide
theorem cert_e1211186534622 : check e1211186534622 [[],[]] .three = true := by decide
def e1211186534638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186534638 : Closed e1211186534638 ∧ code e1211186534638 = 5609233045742 := by decide
theorem cert_e1211186534638 : check e1211186534638 [[],[]] .three = true := by decide
def e1211186534646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186534646 : Closed e1211186534646 ∧ code e1211186534646 = 5609233045750 := by decide
theorem cert_e1211186534646 : check e1211186534646 [[],[]] .three = true := by decide
def e1211186534650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1211186534650 : Closed e1211186534650 ∧ code e1211186534650 = 5609233045754 := by decide
theorem cert_e1211186534650 : check e1211186534650 [[],[]] .three = true := by decide
def e1211186534794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186534794 : Closed e1211186534794 ∧ code e1211186534794 = 5609233045898 := by decide
theorem cert_e1211186534794 : check e1211186534794 [[],[]] .three = true := by decide
def e1211186534818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186534818 : Closed e1211186534818 ∧ code e1211186534818 = 5609233045922 := by decide
theorem cert_e1211186534818 : check e1211186534818 [[],[]] .three = true := by decide
def e1211186534830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211186534830 : Closed e1211186534830 ∧ code e1211186534830 = 5609233045934 := by decide
theorem cert_e1211186534830 : check e1211186534830 [[],[]] .three = true := by decide
def e1211186534838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211186534838 : Closed e1211186534838 ∧ code e1211186534838 = 5609233045942 := by decide
theorem cert_e1211186534838 : check e1211186534838 [[],[]] .three = true := by decide
def e1211186534842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211186534842 : Closed e1211186534842 ∧ code e1211186534842 = 5609233045946 := by decide
theorem cert_e1211186534842 : check e1211186534842 [[],[]] .three = true := by decide
def e1211186534870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211186534870 : Closed e1211186534870 ∧ code e1211186534870 = 5609233045974 := by decide
theorem cert_e1211186534870 : check e1211186534870 [[],[]] .three = true := by decide
def e1211186534874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211186534874 : Closed e1211186534874 ∧ code e1211186534874 = 5609233045978 := by decide
theorem cert_e1211186534874 : check e1211186534874 [[],[]] .three = true := by decide
def e1211186534890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211186534890 : Closed e1211186534890 ∧ code e1211186534890 = 5609233045994 := by decide
theorem cert_e1211186534890 : check e1211186534890 [[],[]] .three = true := by decide
def e1211186534926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186534926 : Closed e1211186534926 ∧ code e1211186534926 = 5609233046030 := by decide
theorem cert_e1211186534926 : check e1211186534926 [[],[]] .three = true := by decide
def e1211186534938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186534938 : Closed e1211186534938 ∧ code e1211186534938 = 5609233046042 := by decide
theorem cert_e1211186534938 : check e1211186534938 [[],[]] .three = true := by decide
def e1211186534974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1211186534974 : Closed e1211186534974 ∧ code e1211186534974 = 5609233046078 := by decide
theorem cert_e1211186534974 : check e1211186534974 [[],[]] .three = true := by decide
def e1211186535010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186535010 : Closed e1211186535010 ∧ code e1211186535010 = 5609233046114 := by decide
theorem cert_e1211186535010 : check e1211186535010 [[],[]] .three = true := by decide
def e1211186535022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186535022 : Closed e1211186535022 ∧ code e1211186535022 = 5609233046126 := by decide
theorem cert_e1211186535022 : check e1211186535022 [[],[]] .three = true := by decide
def e1211186535030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186535030 : Closed e1211186535030 ∧ code e1211186535030 = 5609233046134 := by decide
theorem cert_e1211186535030 : check e1211186535030 [[],[]] .three = true := by decide
def e1211186535034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186535034 : Closed e1211186535034 ∧ code e1211186535034 = 5609233046138 := by decide
theorem cert_e1211186535034 : check e1211186535034 [[],[]] .three = true := by decide
def e1211186535198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186535198 : Closed e1211186535198 ∧ code e1211186535198 = 5609233046302 := by decide
theorem cert_e1211186535198 : check e1211186535198 [[],[]] .three = true := by decide
def e1211186535222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186535222 : Closed e1211186535222 ∧ code e1211186535222 = 5609233046326 := by decide
theorem cert_e1211186535222 : check e1211186535222 [[],[]] .three = true := by decide
def e1211186535226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186535226 : Closed e1211186535226 ∧ code e1211186535226 = 5609233046330 := by decide
theorem cert_e1211186535226 : check e1211186535226 [[],[]] .three = true := by decide
def e1211186535310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186535310 : Closed e1211186535310 ∧ code e1211186535310 = 5609233046414 := by decide
theorem cert_e1211186535310 : check e1211186535310 [[],[]] .three = true := by decide
def e1211186535322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186535322 : Closed e1211186535322 ∧ code e1211186535322 = 5609233046426 := by decide
theorem cert_e1211186535322 : check e1211186535322 [[],[]] .three = true := by decide
def e1211186535366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1211186535366 : Closed e1211186535366 ∧ code e1211186535366 = 5609233046470 := by decide
theorem cert_e1211186535366 : check e1211186535366 [[],[]] .three = true := by decide
def e1211186535534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186535534 : Closed e1211186535534 ∧ code e1211186535534 = 5609233046638 := by decide
theorem cert_e1211186535534 : check e1211186535534 [[],[]] .three = true := by decide
def e1211186535542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211186535542 : Closed e1211186535542 ∧ code e1211186535542 = 5609233046646 := by decide
theorem cert_e1211186535542 : check e1211186535542 [[],[]] .three = true := by decide
def e1211186535546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186535546 : Closed e1211186535546 ∧ code e1211186535546 = 5609233046650 := by decide
theorem cert_e1211186535546 : check e1211186535546 [[],[]] .three = true := by decide
def e1211186535638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211186535638 : Closed e1211186535638 ∧ code e1211186535638 = 5609233046742 := by decide
theorem cert_e1211186535638 : check e1211186535638 [[],[]] .three = true := by decide
def e1211186535642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211186535642 : Closed e1211186535642 ∧ code e1211186535642 = 5609233046746 := by decide
theorem cert_e1211186535642 : check e1211186535642 [[],[]] .three = true := by decide
def e1211186535658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211186535658 : Closed e1211186535658 ∧ code e1211186535658 = 5609233046762 := by decide
theorem cert_e1211186535658 : check e1211186535658 [[],[]] .three = true := by decide
def e1211186535710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186535710 : Closed e1211186535710 ∧ code e1211186535710 = 5609233046814 := by decide
theorem cert_e1211186535710 : check e1211186535710 [[],[]] .three = true := by decide
def e1211186535734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186535734 : Closed e1211186535734 ∧ code e1211186535734 = 5609233046838 := by decide
theorem cert_e1211186535734 : check e1211186535734 [[],[]] .three = true := by decide
def e1211186535738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186535738 : Closed e1211186535738 ∧ code e1211186535738 = 5609233046842 := by decide
theorem cert_e1211186535738 : check e1211186535738 [[],[]] .three = true := by decide
def e1211186535822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211186535822 : Closed e1211186535822 ∧ code e1211186535822 = 5609233046926 := by decide
theorem cert_e1211186535822 : check e1211186535822 [[],[]] .three = true := by decide
def e1211186535834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186535834 : Closed e1211186535834 ∧ code e1211186535834 = 5609233046938 := by decide
theorem cert_e1211186535834 : check e1211186535834 [[],[]] .three = true := by decide
def e1211186535878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186535878 : Closed e1211186535878 ∧ code e1211186535878 = 5609233046982 := by decide
theorem cert_e1211186535878 : check e1211186535878 [[],[]] .three = true := by decide
def e1211186535990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186535990 : Closed e1211186535990 ∧ code e1211186535990 = 5609233047094 := by decide
private def t_e1211186535990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e1211186535990 : ¬ IsSelfInterpreter e1211186535990 :=
  wSource (t := t_e1211186535990) (replay_sound (ps := []) (t := e1211186535990) (by decide)) (by decide)
def e1211186535994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186535994 : Closed e1211186535994 ∧ code e1211186535994 = 5609233047098 := by decide
private def t_e1211186535994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e1211186535994 : ¬ IsSelfInterpreter e1211186535994 :=
  wSource (t := t_e1211186535994) (replay_sound (ps := []) (t := e1211186535994) (by decide)) (by decide)
def e1211186536078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186536078 : Closed e1211186536078 ∧ code e1211186536078 = 5609233047182 := by decide
private def t_e1211186536078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e1211186536078 : ¬ IsSelfInterpreter e1211186536078 :=
  wSource (t := t_e1211186536078) (replay_sound (ps := []) (t := e1211186536078) (by decide)) (by decide)
def e1211186536134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186536134 : Closed e1211186536134 ∧ code e1211186536134 = 5609233047238 := by decide
private def t_e1211186536134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1211186536134 : ¬ IsSelfInterpreter e1211186536134 :=
  wSource (t := t_e1211186536134) (replay_sound (ps := []) (t := e1211186536134) (by decide)) (by decide)
def e1211186559454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186559454 : Closed e1211186559454 ∧ code e1211186559454 = 5609233070558 := by decide
theorem cert_e1211186559454 : check e1211186559454 [[],[]] .three = true := by decide
def e1211186559478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186559478 : Closed e1211186559478 ∧ code e1211186559478 = 5609233070582 := by decide
theorem cert_e1211186559478 : check e1211186559478 [[],[]] .three = true := by decide
def e1211186560222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186560222 : Closed e1211186560222 ∧ code e1211186560222 = 5609233071326 := by decide
theorem cert_e1211186560222 : check e1211186560222 [[],[]] .three = true := by decide
def e1211186560238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186560238 : Closed e1211186560238 ∧ code e1211186560238 = 5609233071342 := by decide
theorem cert_e1211186560238 : check e1211186560238 [[],[]] .smaller = true := by decide
def e1211186560246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186560246 : Closed e1211186560246 ∧ code e1211186560246 = 5609233071350 := by decide
theorem cert_e1211186560246 : check e1211186560246 [[],[]] .smaller = true := by decide
def e1211186560250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186560250 : Closed e1211186560250 ∧ code e1211186560250 = 5609233071354 := by decide
theorem cert_e1211186560250 : check e1211186560250 [[],[]] .three = true := by decide
def e1211186560630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186560630 : Closed e1211186560630 ∧ code e1211186560630 = 5609233071734 := by decide
theorem cert_e1211186560630 : check e1211186560630 [[],[]] .smaller = true := by decide
def e1211186560822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186560822 : Closed e1211186560822 ∧ code e1211186560822 = 5609233071926 := by decide
theorem cert_e1211186560822 : check e1211186560822 [[],[]] .three = true := by decide
def e1211186560826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186560826 : Closed e1211186560826 ∧ code e1211186560826 = 5609233071930 := by decide
theorem cert_e1211186560826 : check e1211186560826 [[],[]] .three = true := by decide
def e1211186567918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 2)))))))
theorem wire_e1211186567918 : Closed e1211186567918 ∧ code e1211186567918 = 5609233079022 := by decide
theorem cert_e1211186567918 : check e1211186567918 [[],[]] .smaller = true := by decide
def e1211186567926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 1)))))))
theorem wire_e1211186567926 : Closed e1211186567926 ∧ code e1211186567926 = 5609233079030 := by decide
theorem cert_e1211186567926 : check e1211186567926 [[],[]] .smaller = true := by decide
def e1211186568054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))))
theorem wire_e1211186568054 : Closed e1211186568054 ∧ code e1211186568054 = 5609233079158 := by decide
theorem cert_e1211186568054 : check e1211186568054 [[],[]] .smaller = true := by decide
def e1211186568058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0)))))))
theorem wire_e1211186568058 : Closed e1211186568058 ∧ code e1211186568058 = 5609233079162 := by decide
theorem cert_e1211186568058 : check e1211186568058 [[],[]] .smaller = true := by decide
def e1211186568110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 2)))))))
theorem wire_e1211186568110 : Closed e1211186568110 ∧ code e1211186568110 = 5609233079214 := by decide
theorem cert_e1211186568110 : check e1211186568110 [[],[]] .smaller = true := by decide
def e1211186568118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))))
theorem wire_e1211186568118 : Closed e1211186568118 ∧ code e1211186568118 = 5609233079222 := by decide
theorem cert_e1211186568118 : check e1211186568118 [[],[]] .smaller = true := by decide
def e1211186568150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186568150 : Closed e1211186568150 ∧ code e1211186568150 = 5609233079254 := by decide
theorem cert_e1211186568150 : check e1211186568150 [[],[]] .smaller = true := by decide
def e1211186568154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0)))))))
theorem wire_e1211186568154 : Closed e1211186568154 ∧ code e1211186568154 = 5609233079258 := by decide
theorem cert_e1211186568154 : check e1211186568154 [[],[]] .smaller = true := by decide
def e1211186568566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))))
theorem wire_e1211186568566 : Closed e1211186568566 ∧ code e1211186568566 = 5609233079670 := by decide
theorem cert_e1211186568566 : check e1211186568566 [[],[]] .smaller = true := by decide
def e1211186568570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0)))))))
theorem wire_e1211186568570 : Closed e1211186568570 ∧ code e1211186568570 = 5609233079674 := by decide
theorem cert_e1211186568570 : check e1211186568570 [[],[]] .smaller = true := by decide
def e1211186568662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186568662 : Closed e1211186568662 ∧ code e1211186568662 = 5609233079766 := by decide
theorem cert_e1211186568662 : check e1211186568662 [[],[]] .smaller = true := by decide
def e1211186568682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186568682 : Closed e1211186568682 ∧ code e1211186568682 = 5609233079786 := by decide
theorem cert_e1211186568682 : check e1211186568682 [[],[]] .smaller = true := by decide
def e1211186568878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 2)))))))
theorem wire_e1211186568878 : Closed e1211186568878 ∧ code e1211186568878 = 5609233079982 := by decide
theorem cert_e1211186568878 : check e1211186568878 [[],[]] .smaller = true := by decide
def e1211186568886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e1211186568886 : Closed e1211186568886 ∧ code e1211186568886 = 5609233079990 := by decide
theorem cert_e1211186568886 : check e1211186568886 [[],[]] .smaller = true := by decide
def e1211186568918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186568918 : Closed e1211186568918 ∧ code e1211186568918 = 5609233080022 := by decide
theorem cert_e1211186568918 : check e1211186568918 [[],[]] .smaller = true := by decide
def e1211186569046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e1211186569046 : Closed e1211186569046 ∧ code e1211186569046 = 5609233080150 := by decide
theorem cert_e1211186569046 : check e1211186569046 [[],[]] .smaller = true := by decide
def e1211186569050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e1211186569050 : Closed e1211186569050 ∧ code e1211186569050 = 5609233080154 := by decide
theorem cert_e1211186569050 : check e1211186569050 [[],[]] .smaller = true := by decide
def e1211186569066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186569066 : Closed e1211186569066 ∧ code e1211186569066 = 5609233080170 := by decide
theorem cert_e1211186569066 : check e1211186569066 [[],[]] .smaller = true := by decide
def e1211186570990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 2)))))))
theorem wire_e1211186570990 : Closed e1211186570990 ∧ code e1211186570990 = 5609233082094 := by decide
theorem cert_e1211186570990 : check e1211186570990 [[],[]] .smaller = true := by decide
end Blc.Floor42
