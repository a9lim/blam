import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211187427038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e1211187427038 : Closed e1211187427038 ∧ code e1211187427038 = 5609233938142 := by decide
theorem cert_e1211187427038 : check e1211187427038 [[],[]] .three = true := by decide
def e1211187427042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211187427042 : Closed e1211187427042 ∧ code e1211187427042 = 5609233938146 := by decide
theorem cert_e1211187427042 : check e1211187427042 [[],[]] .smaller = true := by decide
def e1211187427054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1211187427054 : Closed e1211187427054 ∧ code e1211187427054 = 5609233938158 := by decide
theorem cert_e1211187427054 : check e1211187427054 [[],[]] .smaller = true := by decide
def e1211187427062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e1211187427062 : Closed e1211187427062 ∧ code e1211187427062 = 5609233938166 := by decide
theorem cert_e1211187427062 : check e1211187427062 [[],[]] .three = true := by decide
def e1211187427094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211187427094 : Closed e1211187427094 ∧ code e1211187427094 = 5609233938198 := by decide
theorem cert_e1211187427094 : check e1211187427094 [[],[]] .smaller = true := by decide
def e1211187427098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211187427098 : Closed e1211187427098 ∧ code e1211187427098 = 5609233938202 := by decide
theorem cert_e1211187427098 : check e1211187427098 [[],[]] .smaller = true := by decide
def e1211187427142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211187427142 : Closed e1211187427142 ∧ code e1211187427142 = 5609233938246 := by decide
theorem cert_e1211187427142 : check e1211187427142 [[],[]] .smaller = true := by decide
def e1211187427166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211187427166 : Closed e1211187427166 ∧ code e1211187427166 = 5609233938270 := by decide
theorem cert_e1211187427166 : check e1211187427166 [[],[]] .three = true := by decide
def e1211187427170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211187427170 : Closed e1211187427170 ∧ code e1211187427170 = 5609233938274 := by decide
theorem cert_e1211187427170 : check e1211187427170 [[],[]] .smaller = true := by decide
def e1211187427182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1211187427182 : Closed e1211187427182 ∧ code e1211187427182 = 5609233938286 := by decide
theorem cert_e1211187427182 : check e1211187427182 [[],[]] .smaller = true := by decide
def e1211187427190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1211187427190 : Closed e1211187427190 ∧ code e1211187427190 = 5609233938294 := by decide
theorem cert_e1211187427190 : check e1211187427190 [[],[]] .smaller = true := by decide
def e1211187427194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211187427194 : Closed e1211187427194 ∧ code e1211187427194 = 5609233938298 := by decide
theorem cert_e1211187427194 : check e1211187427194 [[],[]] .three = true := by decide
def e1211187427210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211187427210 : Closed e1211187427210 ∧ code e1211187427210 = 5609233938314 := by decide
theorem cert_e1211187427210 : check e1211187427210 [[],[]] .three = true := by decide
def e1211187427234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211187427234 : Closed e1211187427234 ∧ code e1211187427234 = 5609233938338 := by decide
theorem cert_e1211187427234 : check e1211187427234 [[],[]] .three = true := by decide
def e1211187427246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211187427246 : Closed e1211187427246 ∧ code e1211187427246 = 5609233938350 := by decide
theorem cert_e1211187427246 : check e1211187427246 [[],[]] .three = true := by decide
def e1211187427254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e1211187427254 : Closed e1211187427254 ∧ code e1211187427254 = 5609233938358 := by decide
theorem cert_e1211187427254 : check e1211187427254 [[],[]] .three = true := by decide
def e1211187427258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211187427258 : Closed e1211187427258 ∧ code e1211187427258 = 5609233938362 := by decide
theorem cert_e1211187427258 : check e1211187427258 [[],[]] .three = true := by decide
def e1211187427510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e1211187427510 : Closed e1211187427510 ∧ code e1211187427510 = 5609233938614 := by decide
theorem cert_e1211187427510 : check e1211187427510 [[],[]] .smaller = true := by decide
def e1211187427542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211187427542 : Closed e1211187427542 ∧ code e1211187427542 = 5609233938646 := by decide
theorem cert_e1211187427542 : check e1211187427542 [[],[]] .smaller = true := by decide
def e1211187427546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211187427546 : Closed e1211187427546 ∧ code e1211187427546 = 5609233938650 := by decide
theorem cert_e1211187427546 : check e1211187427546 [[],[]] .smaller = true := by decide
def e1211187427562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211187427562 : Closed e1211187427562 ∧ code e1211187427562 = 5609233938666 := by decide
theorem cert_e1211187427562 : check e1211187427562 [[],[]] .smaller = true := by decide
def e1211187427894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211187427894 : Closed e1211187427894 ∧ code e1211187427894 = 5609233938998 := by decide
theorem cert_e1211187427894 : check e1211187427894 [[],[]] .smaller = true := by decide
def e1211187427898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211187427898 : Closed e1211187427898 ∧ code e1211187427898 = 5609233939002 := by decide
theorem cert_e1211187427898 : check e1211187427898 [[],[]] .smaller = true := by decide
def e1211187427982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211187427982 : Closed e1211187427982 ∧ code e1211187427982 = 5609233939086 := by decide
theorem cert_e1211187427982 : check e1211187427982 [[],[]] .smaller = true := by decide
def e1211187428038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211187428038 : Closed e1211187428038 ∧ code e1211187428038 = 5609233939142 := by decide
theorem cert_e1211187428038 : check e1211187428038 [[],[]] .smaller = true := by decide
def e1211187428062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211187428062 : Closed e1211187428062 ∧ code e1211187428062 = 5609233939166 := by decide
theorem cert_e1211187428062 : check e1211187428062 [[],[]] .three = true := by decide
def e1211187428086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211187428086 : Closed e1211187428086 ∧ code e1211187428086 = 5609233939190 := by decide
theorem cert_e1211187428086 : check e1211187428086 [[],[]] .three = true := by decide
def e1211187428118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211187428118 : Closed e1211187428118 ∧ code e1211187428118 = 5609233939222 := by decide
theorem cert_e1211187428118 : check e1211187428118 [[],[]] .smaller = true := by decide
def e1211187428122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211187428122 : Closed e1211187428122 ∧ code e1211187428122 = 5609233939226 := by decide
theorem cert_e1211187428122 : check e1211187428122 [[],[]] .smaller = true := by decide
def e1211187428166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211187428166 : Closed e1211187428166 ∧ code e1211187428166 = 5609233939270 := by decide
theorem cert_e1211187428166 : check e1211187428166 [[],[]] .smaller = true := by decide
def e1211187428190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211187428190 : Closed e1211187428190 ∧ code e1211187428190 = 5609233939294 := by decide
theorem cert_e1211187428190 : check e1211187428190 [[],[]] .three = true := by decide
def e1211187428194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211187428194 : Closed e1211187428194 ∧ code e1211187428194 = 5609233939298 := by decide
theorem cert_e1211187428194 : check e1211187428194 [[],[]] .smaller = true := by decide
def e1211187428206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211187428206 : Closed e1211187428206 ∧ code e1211187428206 = 5609233939310 := by decide
theorem cert_e1211187428206 : check e1211187428206 [[],[]] .smaller = true := by decide
def e1211187428214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211187428214 : Closed e1211187428214 ∧ code e1211187428214 = 5609233939318 := by decide
theorem cert_e1211187428214 : check e1211187428214 [[],[]] .smaller = true := by decide
def e1211187428218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211187428218 : Closed e1211187428218 ∧ code e1211187428218 = 5609233939322 := by decide
theorem cert_e1211187428218 : check e1211187428218 [[],[]] .three = true := by decide
def e1211187428278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211187428278 : Closed e1211187428278 ∧ code e1211187428278 = 5609233939382 := by decide
theorem cert_e1211187428278 : check e1211187428278 [[],[]] .smaller = true := by decide
def e1211187428310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211187428310 : Closed e1211187428310 ∧ code e1211187428310 = 5609233939414 := by decide
theorem cert_e1211187428310 : check e1211187428310 [[],[]] .three = true := by decide
def e1211187428314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211187428314 : Closed e1211187428314 ∧ code e1211187428314 = 5609233939418 := by decide
theorem cert_e1211187428314 : check e1211187428314 [[],[]] .three = true := by decide
def e1211187428438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211187428438 : Closed e1211187428438 ∧ code e1211187428438 = 5609233939542 := by decide
theorem cert_e1211187428438 : check e1211187428438 [[],[]] .three = true := by decide
def e1211187428442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211187428442 : Closed e1211187428442 ∧ code e1211187428442 = 5609233939546 := by decide
theorem cert_e1211187428442 : check e1211187428442 [[],[]] .three = true := by decide
def e1211187428630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211187428630 : Closed e1211187428630 ∧ code e1211187428630 = 5609233939734 := by decide
theorem cert_e1211187428630 : check e1211187428630 [[],[]] .three = true := by decide
def e1211187428706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211187428706 : Closed e1211187428706 ∧ code e1211187428706 = 5609233939810 := by decide
theorem cert_e1211187428706 : check e1211187428706 [[],[]] .three = true := by decide
def e1211187428718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211187428718 : Closed e1211187428718 ∧ code e1211187428718 = 5609233939822 := by decide
theorem cert_e1211187428718 : check e1211187428718 [[],[]] .three = true := by decide
def e1211187428726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211187428726 : Closed e1211187428726 ∧ code e1211187428726 = 5609233939830 := by decide
theorem cert_e1211187428726 : check e1211187428726 [[],[]] .three = true := by decide
def e1211187428746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211187428746 : Closed e1211187428746 ∧ code e1211187428746 = 5609233939850 := by decide
theorem cert_e1211187428746 : check e1211187428746 [[],[]] .three = true := by decide
def e1211187428770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211187428770 : Closed e1211187428770 ∧ code e1211187428770 = 5609233939874 := by decide
theorem cert_e1211187428770 : check e1211187428770 [[],[]] .three = true := by decide
def e1211187428782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211187428782 : Closed e1211187428782 ∧ code e1211187428782 = 5609233939886 := by decide
theorem cert_e1211187428782 : check e1211187428782 [[],[]] .three = true := by decide
def e1211187428790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e1211187428790 : Closed e1211187428790 ∧ code e1211187428790 = 5609233939894 := by decide
theorem cert_e1211187428790 : check e1211187428790 [[],[]] .three = true := by decide
def e1211187428794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211187428794 : Closed e1211187428794 ∧ code e1211187428794 = 5609233939898 := by decide
theorem cert_e1211187428794 : check e1211187428794 [[],[]] .three = true := by decide
def e1211187428822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211187428822 : Closed e1211187428822 ∧ code e1211187428822 = 5609233939926 := by decide
theorem cert_e1211187428822 : check e1211187428822 [[],[]] .three = true := by decide
def e1211187428826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211187428826 : Closed e1211187428826 ∧ code e1211187428826 = 5609233939930 := by decide
theorem cert_e1211187428826 : check e1211187428826 [[],[]] .three = true := by decide
def e1211187430366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3))))))))
theorem wire_e1211187430366 : Closed e1211187430366 ∧ code e1211187430366 = 5609233941470 := by decide
theorem cert_e1211187430366 : check e1211187430366 [[],[]] .three = true := by decide
def e1211187430390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1))))))))
theorem wire_e1211187430390 : Closed e1211187430390 ∧ code e1211187430390 = 5609233941494 := by decide
theorem cert_e1211187430390 : check e1211187430390 [[],[]] .three = true := by decide
def e1211187431150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e1211187431150 : Closed e1211187431150 ∧ code e1211187431150 = 5609233942254 := by decide
theorem cert_e1211187431150 : check e1211187431150 [[],[]] .smaller = true := by decide
def e1211187431158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e1211187431158 : Closed e1211187431158 ∧ code e1211187431158 = 5609233942262 := by decide
theorem cert_e1211187431158 : check e1211187431158 [[],[]] .smaller = true := by decide
def e1211187431342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e1211187431342 : Closed e1211187431342 ∧ code e1211187431342 = 5609233942446 := by decide
theorem cert_e1211187431342 : check e1211187431342 [[],[]] .smaller = true := by decide
def e1211187431382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e1211187431382 : Closed e1211187431382 ∧ code e1211187431382 = 5609233942486 := by decide
theorem cert_e1211187431382 : check e1211187431382 [[],[]] .smaller = true := by decide
def e1211187431902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211187431902 : Closed e1211187431902 ∧ code e1211187431902 = 5609233943006 := by decide
theorem cert_e1211187431902 : check e1211187431902 [[],[]] .three = true := by decide
def e1211187431926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211187431926 : Closed e1211187431926 ∧ code e1211187431926 = 5609233943030 := by decide
theorem cert_e1211187431926 : check e1211187431926 [[],[]] .three = true := by decide
def e1211187432686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187432686 : Closed e1211187432686 ∧ code e1211187432686 = 5609233943790 := by decide
theorem cert_e1211187432686 : check e1211187432686 [[],[]] .smaller = true := by decide
def e1211187432694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187432694 : Closed e1211187432694 ∧ code e1211187432694 = 5609233943798 := by decide
theorem cert_e1211187432694 : check e1211187432694 [[],[]] .smaller = true := by decide
def e1211187433022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4)))))))))
theorem wire_e1211187433022 : Closed e1211187433022 ∧ code e1211187433022 = 5609233944126 := by decide
theorem cert_e1211187433022 : check e1211187433022 [[],[]] .three = true := by decide
def e1211187433070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187433070 : Closed e1211187433070 ∧ code e1211187433070 = 5609233944174 := by decide
theorem cert_e1211187433070 : check e1211187433070 [[],[]] .smaller = true := by decide
def e1211187433082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187433082 : Closed e1211187433082 ∧ code e1211187433082 = 5609233944186 := by decide
theorem cert_e1211187433082 : check e1211187433082 [[],[]] .smaller = true := by decide
def e1211187433270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187433270 : Closed e1211187433270 ∧ code e1211187433270 = 5609233944374 := by decide
theorem cert_e1211187433270 : check e1211187433270 [[],[]] .smaller = true := by decide
def e1211187433274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187433274 : Closed e1211187433274 ∧ code e1211187433274 = 5609233944378 := by decide
theorem cert_e1211187433274 : check e1211187433274 [[],[]] .smaller = true := by decide
def e1211187433358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2)))))))))
theorem wire_e1211187433358 : Closed e1211187433358 ∧ code e1211187433358 = 5609233944462 := by decide
theorem cert_e1211187433358 : check e1211187433358 [[],[]] .three = true := by decide
def e1211187435758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211187435758 : Closed e1211187435758 ∧ code e1211187435758 = 5609233946862 := by decide
theorem cert_e1211187435758 : check e1211187435758 [[],[]] .smaller = true := by decide
def e1211187435766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211187435766 : Closed e1211187435766 ∧ code e1211187435766 = 5609233946870 := by decide
theorem cert_e1211187435766 : check e1211187435766 [[],[]] .smaller = true := by decide
def e1211187436318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211187436318 : Closed e1211187436318 ∧ code e1211187436318 = 5609233947422 := by decide
theorem cert_e1211187436318 : check e1211187436318 [[],[]] .smaller = true := by decide
def e1211187436430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211187436430 : Closed e1211187436430 ∧ code e1211187436430 = 5609233947534 := by decide
theorem cert_e1211187436430 : check e1211187436430 [[],[]] .smaller = true := by decide
def e1211187436638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211187436638 : Closed e1211187436638 ∧ code e1211187436638 = 5609233947742 := by decide
theorem cert_e1211187436638 : check e1211187436638 [[],[]] .three = true := by decide
def e1211187436654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211187436654 : Closed e1211187436654 ∧ code e1211187436654 = 5609233947758 := by decide
theorem cert_e1211187436654 : check e1211187436654 [[],[]] .smaller = true := by decide
def e1211187436666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211187436666 : Closed e1211187436666 ∧ code e1211187436666 = 5609233947770 := by decide
theorem cert_e1211187436666 : check e1211187436666 [[],[]] .smaller = true := by decide
def e1211187436830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211187436830 : Closed e1211187436830 ∧ code e1211187436830 = 5609233947934 := by decide
theorem cert_e1211187436830 : check e1211187436830 [[],[]] .smaller = true := by decide
def e1211187436998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211187436998 : Closed e1211187436998 ∧ code e1211187436998 = 5609233948102 := by decide
theorem cert_e1211187436998 : check e1211187436998 [[],[]] .smaller = true := by decide
def e1211187437022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e1211187437022 : Closed e1211187437022 ∧ code e1211187437022 = 5609233948126 := by decide
theorem cert_e1211187437022 : check e1211187437022 [[],[]] .three = true := by decide
def e1211187437026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211187437026 : Closed e1211187437026 ∧ code e1211187437026 = 5609233948130 := by decide
theorem cert_e1211187437026 : check e1211187437026 [[],[]] .three = true := by decide
def e1211187437038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e1211187437038 : Closed e1211187437038 ∧ code e1211187437038 = 5609233948142 := by decide
theorem cert_e1211187437038 : check e1211187437038 [[],[]] .three = true := by decide
def e1211187437110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211187437110 : Closed e1211187437110 ∧ code e1211187437110 = 5609233948214 := by decide
theorem cert_e1211187437110 : check e1211187437110 [[],[]] .smaller = true := by decide
def e1211187437114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211187437114 : Closed e1211187437114 ∧ code e1211187437114 = 5609233948218 := by decide
theorem cert_e1211187437114 : check e1211187437114 [[],[]] .smaller = true := by decide
def e1211187437198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211187437198 : Closed e1211187437198 ∧ code e1211187437198 = 5609233948302 := by decide
theorem cert_e1211187437198 : check e1211187437198 [[],[]] .smaller = true := by decide
def e1211187437254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211187437254 : Closed e1211187437254 ∧ code e1211187437254 = 5609233948358 := by decide
theorem cert_e1211187437254 : check e1211187437254 [[],[]] .smaller = true := by decide
def e1211187437278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e1211187437278 : Closed e1211187437278 ∧ code e1211187437278 = 5609233948382 := by decide
theorem cert_e1211187437278 : check e1211187437278 [[],[]] .three = true := by decide
def e1211187437302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e1211187437302 : Closed e1211187437302 ∧ code e1211187437302 = 5609233948406 := by decide
theorem cert_e1211187437302 : check e1211187437302 [[],[]] .three = true := by decide
def e1211187437334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211187437334 : Closed e1211187437334 ∧ code e1211187437334 = 5609233948438 := by decide
theorem cert_e1211187437334 : check e1211187437334 [[],[]] .three = true := by decide
def e1211187437410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211187437410 : Closed e1211187437410 ∧ code e1211187437410 = 5609233948514 := by decide
theorem cert_e1211187437410 : check e1211187437410 [[],[]] .three = true := by decide
def e1211187437422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e1211187437422 : Closed e1211187437422 ∧ code e1211187437422 = 5609233948526 := by decide
theorem cert_e1211187437422 : check e1211187437422 [[],[]] .three = true := by decide
def e1211187437430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e1211187437430 : Closed e1211187437430 ∧ code e1211187437430 = 5609233948534 := by decide
theorem cert_e1211187437430 : check e1211187437430 [[],[]] .three = true := by decide
def e1211187439390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211187439390 : Closed e1211187439390 ∧ code e1211187439390 = 5609233950494 := by decide
theorem cert_e1211187439390 : check e1211187439390 [[],[]] .smaller = true := by decide
def e1211187439502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211187439502 : Closed e1211187439502 ∧ code e1211187439502 = 5609233950606 := by decide
theorem cert_e1211187439502 : check e1211187439502 [[],[]] .smaller = true := by decide
def e1211187441790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211187441790 : Closed e1211187441790 ∧ code e1211187441790 = 5609233952894 := by decide
theorem cert_e1211187441790 : check e1211187441790 [[],[]] .three = true := by decide
def e1211187441886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187441886 : Closed e1211187441886 ∧ code e1211187441886 = 5609233952990 := by decide
theorem cert_e1211187441886 : check e1211187441886 [[],[]] .smaller = true := by decide
def e1211187441914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187441914 : Closed e1211187441914 ∧ code e1211187441914 = 5609233953018 := by decide
theorem cert_e1211187441914 : check e1211187441914 [[],[]] .smaller = true := by decide
def e1211187442462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211187442462 : Closed e1211187442462 ∧ code e1211187442462 = 5609233953566 := by decide
theorem cert_e1211187442462 : check e1211187442462 [[],[]] .smaller = true := by decide
def e1211187442630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211187442630 : Closed e1211187442630 ∧ code e1211187442630 = 5609233953734 := by decide
theorem cert_e1211187442630 : check e1211187442630 [[],[]] .smaller = true := by decide
def e1211187442654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211187442654 : Closed e1211187442654 ∧ code e1211187442654 = 5609233953758 := by decide
theorem cert_e1211187442654 : check e1211187442654 [[],[]] .three = true := by decide
def e1211187442658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211187442658 : Closed e1211187442658 ∧ code e1211187442658 = 5609233953762 := by decide
theorem cert_e1211187442658 : check e1211187442658 [[],[]] .three = true := by decide
def e1211187442670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211187442670 : Closed e1211187442670 ∧ code e1211187442670 = 5609233953774 := by decide
theorem cert_e1211187442670 : check e1211187442670 [[],[]] .three = true := by decide
def e1211187443822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211187443822 : Closed e1211187443822 ∧ code e1211187443822 = 5609233954926 := by decide
theorem cert_e1211187443822 : check e1211187443822 [[],[]] .smaller = true := by decide
def e1211187443834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211187443834 : Closed e1211187443834 ∧ code e1211187443834 = 5609233954938 := by decide
theorem cert_e1211187443834 : check e1211187443834 [[],[]] .smaller = true := by decide
def e1211187444110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211187444110 : Closed e1211187444110 ∧ code e1211187444110 = 5609233955214 := by decide
theorem cert_e1211187444110 : check e1211187444110 [[],[]] .smaller = true := by decide
def e1211187444166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211187444166 : Closed e1211187444166 ∧ code e1211187444166 = 5609233955270 := by decide
theorem cert_e1211187444166 : check e1211187444166 [[],[]] .smaller = true := by decide
def e1211187444190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211187444190 : Closed e1211187444190 ∧ code e1211187444190 = 5609233955294 := by decide
theorem cert_e1211187444190 : check e1211187444190 [[],[]] .three = true := by decide
def e1211187444214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211187444214 : Closed e1211187444214 ∧ code e1211187444214 = 5609233955318 := by decide
theorem cert_e1211187444214 : check e1211187444214 [[],[]] .three = true := by decide
def e1211187444766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211187444766 : Closed e1211187444766 ∧ code e1211187444766 = 5609233955870 := by decide
theorem cert_e1211187444766 : check e1211187444766 [[],[]] .three = true := by decide
def e1211187444962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211187444962 : Closed e1211187444962 ∧ code e1211187444962 = 5609233956066 := by decide
theorem cert_e1211187444962 : check e1211187444962 [[],[]] .three = true := by decide
def e1211187444974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187444974 : Closed e1211187444974 ∧ code e1211187444974 = 5609233956078 := by decide
theorem cert_e1211187444974 : check e1211187444974 [[],[]] .three = true := by decide
def e1211187444982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187444982 : Closed e1211187444982 ∧ code e1211187444982 = 5609233956086 := by decide
theorem cert_e1211187444982 : check e1211187444982 [[],[]] .three = true := by decide
def e1211187446238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211187446238 : Closed e1211187446238 ∧ code e1211187446238 = 5609233957342 := by decide
theorem cert_e1211187446238 : check e1211187446238 [[],[]] .three = true := by decide
def e1211187446254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e1211187446254 : Closed e1211187446254 ∧ code e1211187446254 = 5609233957358 := by decide
theorem cert_e1211187446254 : check e1211187446254 [[],[]] .smaller = true := by decide
def e1211187446262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e1211187446262 : Closed e1211187446262 ∧ code e1211187446262 = 5609233957366 := by decide
theorem cert_e1211187446262 : check e1211187446262 [[],[]] .smaller = true := by decide
def e1211187446266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211187446266 : Closed e1211187446266 ∧ code e1211187446266 = 5609233957370 := by decide
theorem cert_e1211187446266 : check e1211187446266 [[],[]] .three = true := by decide
def e1211187446622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e1211187446622 : Closed e1211187446622 ∧ code e1211187446622 = 5609233957726 := by decide
theorem cert_e1211187446622 : check e1211187446622 [[],[]] .three = true := by decide
def e1211187446638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211187446638 : Closed e1211187446638 ∧ code e1211187446638 = 5609233957742 := by decide
theorem cert_e1211187446638 : check e1211187446638 [[],[]] .smaller = true := by decide
def e1211187446650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211187446650 : Closed e1211187446650 ∧ code e1211187446650 = 5609233957754 := by decide
theorem cert_e1211187446650 : check e1211187446650 [[],[]] .smaller = true := by decide
def e1211187446702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211187446702 : Closed e1211187446702 ∧ code e1211187446702 = 5609233957806 := by decide
theorem cert_e1211187446702 : check e1211187446702 [[],[]] .smaller = true := by decide
def e1211187446762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211187446762 : Closed e1211187446762 ∧ code e1211187446762 = 5609233957866 := by decide
theorem cert_e1211187446762 : check e1211187446762 [[],[]] .smaller = true := by decide
def e1211187447006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211187447006 : Closed e1211187447006 ∧ code e1211187447006 = 5609233958110 := by decide
theorem cert_e1211187447006 : check e1211187447006 [[],[]] .three = true := by decide
def e1211187447022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187447022 : Closed e1211187447022 ∧ code e1211187447022 = 5609233958126 := by decide
theorem cert_e1211187447022 : check e1211187447022 [[],[]] .smaller = true := by decide
def e1211187447030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187447030 : Closed e1211187447030 ∧ code e1211187447030 = 5609233958134 := by decide
theorem cert_e1211187447030 : check e1211187447030 [[],[]] .smaller = true := by decide
def e1211187447034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211187447034 : Closed e1211187447034 ∧ code e1211187447034 = 5609233958138 := by decide
theorem cert_e1211187447034 : check e1211187447034 [[],[]] .three = true := by decide
def e1211187447358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211187447358 : Closed e1211187447358 ∧ code e1211187447358 = 5609233958462 := by decide
theorem cert_e1211187447358 : check e1211187447358 [[],[]] .three = true := by decide
def e1211187447406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187447406 : Closed e1211187447406 ∧ code e1211187447406 = 5609233958510 := by decide
theorem cert_e1211187447406 : check e1211187447406 [[],[]] .smaller = true := by decide
def e1211187447418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187447418 : Closed e1211187447418 ∧ code e1211187447418 = 5609233958522 := by decide
theorem cert_e1211187447418 : check e1211187447418 [[],[]] .smaller = true := by decide
def e1211187447582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e1211187447582 : Closed e1211187447582 ∧ code e1211187447582 = 5609233958686 := by decide
theorem cert_e1211187447582 : check e1211187447582 [[],[]] .smaller = true := by decide
def e1211187447694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e1211187447694 : Closed e1211187447694 ∧ code e1211187447694 = 5609233958798 := by decide
theorem cert_e1211187447694 : check e1211187447694 [[],[]] .smaller = true := by decide
def e1211187447706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187447706 : Closed e1211187447706 ∧ code e1211187447706 = 5609233958810 := by decide
theorem cert_e1211187447706 : check e1211187447706 [[],[]] .smaller = true := by decide
def e1211187447750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211187447750 : Closed e1211187447750 ∧ code e1211187447750 = 5609233958854 := by decide
theorem cert_e1211187447750 : check e1211187447750 [[],[]] .three = true := by decide
def e1211187447774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 3))))))))
theorem wire_e1211187447774 : Closed e1211187447774 ∧ code e1211187447774 = 5609233958878 := by decide
theorem cert_e1211187447774 : check e1211187447774 [[],[]] .three = true := by decide
def e1211187448926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211187448926 : Closed e1211187448926 ∧ code e1211187448926 = 5609233960030 := by decide
theorem cert_e1211187448926 : check e1211187448926 [[],[]] .three = true := by decide
def e1211187448942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211187448942 : Closed e1211187448942 ∧ code e1211187448942 = 5609233960046 := by decide
theorem cert_e1211187448942 : check e1211187448942 [[],[]] .smaller = true := by decide
def e1211187448954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211187448954 : Closed e1211187448954 ∧ code e1211187448954 = 5609233960058 := by decide
theorem cert_e1211187448954 : check e1211187448954 [[],[]] .smaller = true := by decide
def e1211187449118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211187449118 : Closed e1211187449118 ∧ code e1211187449118 = 5609233960222 := by decide
theorem cert_e1211187449118 : check e1211187449118 [[],[]] .smaller = true := by decide
def e1211187449286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211187449286 : Closed e1211187449286 ∧ code e1211187449286 = 5609233960390 := by decide
theorem cert_e1211187449286 : check e1211187449286 [[],[]] .smaller = true := by decide
def e1211187449310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211187449310 : Closed e1211187449310 ∧ code e1211187449310 = 5609233960414 := by decide
theorem cert_e1211187449310 : check e1211187449310 [[],[]] .three = true := by decide
def e1211187449314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211187449314 : Closed e1211187449314 ∧ code e1211187449314 = 5609233960418 := by decide
theorem cert_e1211187449314 : check e1211187449314 [[],[]] .three = true := by decide
def e1211187449326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211187449326 : Closed e1211187449326 ∧ code e1211187449326 = 5609233960430 := by decide
theorem cert_e1211187449326 : check e1211187449326 [[],[]] .three = true := by decide
def e1211187449390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211187449390 : Closed e1211187449390 ∧ code e1211187449390 = 5609233960494 := by decide
theorem cert_e1211187449390 : check e1211187449390 [[],[]] .smaller = true := by decide
def e1211187449566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e1211187449566 : Closed e1211187449566 ∧ code e1211187449566 = 5609233960670 := by decide
theorem cert_e1211187449566 : check e1211187449566 [[],[]] .three = true := by decide
def e1211187449570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211187449570 : Closed e1211187449570 ∧ code e1211187449570 = 5609233960674 := by decide
theorem cert_e1211187449570 : check e1211187449570 [[],[]] .smaller = true := by decide
def e1211187449582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1211187449582 : Closed e1211187449582 ∧ code e1211187449582 = 5609233960686 := by decide
theorem cert_e1211187449582 : check e1211187449582 [[],[]] .smaller = true := by decide
def e1211187449590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e1211187449590 : Closed e1211187449590 ∧ code e1211187449590 = 5609233960694 := by decide
theorem cert_e1211187449590 : check e1211187449590 [[],[]] .three = true := by decide
def e1211187449622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211187449622 : Closed e1211187449622 ∧ code e1211187449622 = 5609233960726 := by decide
theorem cert_e1211187449622 : check e1211187449622 [[],[]] .smaller = true := by decide
def e1211187449626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211187449626 : Closed e1211187449626 ∧ code e1211187449626 = 5609233960730 := by decide
theorem cert_e1211187449626 : check e1211187449626 [[],[]] .smaller = true := by decide
def e1211187449670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211187449670 : Closed e1211187449670 ∧ code e1211187449670 = 5609233960774 := by decide
theorem cert_e1211187449670 : check e1211187449670 [[],[]] .smaller = true := by decide
def e1211187449694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211187449694 : Closed e1211187449694 ∧ code e1211187449694 = 5609233960798 := by decide
theorem cert_e1211187449694 : check e1211187449694 [[],[]] .three = true := by decide
def e1211187449698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211187449698 : Closed e1211187449698 ∧ code e1211187449698 = 5609233960802 := by decide
theorem cert_e1211187449698 : check e1211187449698 [[],[]] .smaller = true := by decide
def e1211187449710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1211187449710 : Closed e1211187449710 ∧ code e1211187449710 = 5609233960814 := by decide
theorem cert_e1211187449710 : check e1211187449710 [[],[]] .smaller = true := by decide
def e1211187449718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1211187449718 : Closed e1211187449718 ∧ code e1211187449718 = 5609233960822 := by decide
theorem cert_e1211187449718 : check e1211187449718 [[],[]] .smaller = true := by decide
def e1211187449722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211187449722 : Closed e1211187449722 ∧ code e1211187449722 = 5609233960826 := by decide
theorem cert_e1211187449722 : check e1211187449722 [[],[]] .three = true := by decide
def e1211187449738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211187449738 : Closed e1211187449738 ∧ code e1211187449738 = 5609233960842 := by decide
theorem cert_e1211187449738 : check e1211187449738 [[],[]] .three = true := by decide
def e1211187449762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211187449762 : Closed e1211187449762 ∧ code e1211187449762 = 5609233960866 := by decide
theorem cert_e1211187449762 : check e1211187449762 [[],[]] .three = true := by decide
def e1211187449774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211187449774 : Closed e1211187449774 ∧ code e1211187449774 = 5609233960878 := by decide
theorem cert_e1211187449774 : check e1211187449774 [[],[]] .three = true := by decide
def e1211187449782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e1211187449782 : Closed e1211187449782 ∧ code e1211187449782 = 5609233960886 := by decide
theorem cert_e1211187449782 : check e1211187449782 [[],[]] .three = true := by decide
def e1211187449786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211187449786 : Closed e1211187449786 ∧ code e1211187449786 = 5609233960890 := by decide
theorem cert_e1211187449786 : check e1211187449786 [[],[]] .three = true := by decide
def e1211187449982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211187449982 : Closed e1211187449982 ∧ code e1211187449982 = 5609233961086 := by decide
theorem cert_e1211187449982 : check e1211187449982 [[],[]] .three = true := by decide
def e1211187450078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187450078 : Closed e1211187450078 ∧ code e1211187450078 = 5609233961182 := by decide
theorem cert_e1211187450078 : check e1211187450078 [[],[]] .smaller = true := by decide
def e1211187450106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187450106 : Closed e1211187450106 ∧ code e1211187450106 = 5609233961210 := by decide
theorem cert_e1211187450106 : check e1211187450106 [[],[]] .smaller = true := by decide
def e1211187450654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211187450654 : Closed e1211187450654 ∧ code e1211187450654 = 5609233961758 := by decide
theorem cert_e1211187450654 : check e1211187450654 [[],[]] .smaller = true := by decide
end Blc.Floor42
