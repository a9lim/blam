import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182272314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182272314 : Closed e1211182272314 ∧ code e1211182272314 = 5609228783418 := by decide
theorem cert_e1211182272314 : check e1211182272314 [[],[]] .smaller = true := by decide
def e1211182272398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211182272398 : Closed e1211182272398 ∧ code e1211182272398 = 5609228783502 := by decide
theorem cert_e1211182272398 : check e1211182272398 [[],[]] .smaller = true := by decide
def e1211182272410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182272410 : Closed e1211182272410 ∧ code e1211182272410 = 5609228783514 := by decide
theorem cert_e1211182272410 : check e1211182272410 [[],[]] .smaller = true := by decide
def e1211182272454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.lam (.var 1))))))))))
theorem wire_e1211182272454 : Closed e1211182272454 ∧ code e1211182272454 = 5609228783558 := by decide
theorem cert_e1211182272454 : check e1211182272454 [[],[]] .three = true := by decide
def e1211182277102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182277102 : Closed e1211182277102 ∧ code e1211182277102 = 5609228788206 := by decide
theorem cert_e1211182277102 : check e1211182277102 [[],[]] .smaller = true := by decide
def e1211182278070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211182278070 : Closed e1211182278070 ∧ code e1211182278070 = 5609228789174 := by decide
theorem cert_e1211182278070 : check e1211182278070 [[],[]] .smaller = true := by decide
def e1211182278102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211182278102 : Closed e1211182278102 ∧ code e1211182278102 = 5609228789206 := by decide
theorem cert_e1211182278102 : check e1211182278102 [[],[]] .smaller = true := by decide
def e1211182278106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211182278106 : Closed e1211182278106 ∧ code e1211182278106 = 5609228789210 := by decide
theorem cert_e1211182278106 : check e1211182278106 [[],[]] .smaller = true := by decide
def e1211182278206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211182278206 : Closed e1211182278206 ∧ code e1211182278206 = 5609228789310 := by decide
theorem cert_e1211182278206 : check e1211182278206 [[],[]] .smaller = true := by decide
def e1211182278262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182278262 : Closed e1211182278262 ∧ code e1211182278262 = 5609228789366 := by decide
theorem cert_e1211182278262 : check e1211182278262 [[],[]] .smaller = true := by decide
def e1211182278430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211182278430 : Closed e1211182278430 ∧ code e1211182278430 = 5609228789534 := by decide
theorem cert_e1211182278430 : check e1211182278430 [[],[]] .smaller = true := by decide
def e1211182278454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182278454 : Closed e1211182278454 ∧ code e1211182278454 = 5609228789558 := by decide
theorem cert_e1211182278454 : check e1211182278454 [[],[]] .smaller = true := by decide
def e1211182278458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182278458 : Closed e1211182278458 ∧ code e1211182278458 = 5609228789562 := by decide
theorem cert_e1211182278458 : check e1211182278458 [[],[]] .smaller = true := by decide
def e1211182278542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211182278542 : Closed e1211182278542 ∧ code e1211182278542 = 5609228789646 := by decide
theorem cert_e1211182278542 : check e1211182278542 [[],[]] .smaller = true := by decide
def e1211182278590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 4)))))))))
theorem wire_e1211182278590 : Closed e1211182278590 ∧ code e1211182278590 = 5609228789694 := by decide
theorem cert_e1211182278590 : check e1211182278590 [[],[]] .three = true := by decide
def e1211182278598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211182278598 : Closed e1211182278598 ∧ code e1211182278598 = 5609228789702 := by decide
theorem cert_e1211182278598 : check e1211182278598 [[],[]] .smaller = true := by decide
def e1211182278622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 3)))))))))
theorem wire_e1211182278622 : Closed e1211182278622 ∧ code e1211182278622 = 5609228789726 := by decide
theorem cert_e1211182278622 : check e1211182278622 [[],[]] .smaller = true := by decide
def e1211182278638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 4) (.var 2)))))))))
theorem wire_e1211182278638 : Closed e1211182278638 ∧ code e1211182278638 = 5609228789742 := by decide
theorem cert_e1211182278638 : check e1211182278638 [[],[]] .three = true := by decide
def e1211182280942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182280942 : Closed e1211182280942 ∧ code e1211182280942 = 5609228792046 := by decide
theorem cert_e1211182280942 : check e1211182280942 [[],[]] .smaller = true := by decide
def e1211182280950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182280950 : Closed e1211182280950 ∧ code e1211182280950 = 5609228792054 := by decide
theorem cert_e1211182280950 : check e1211182280950 [[],[]] .smaller = true := by decide
def e1211182281430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211182281430 : Closed e1211182281430 ∧ code e1211182281430 = 5609228792534 := by decide
theorem cert_e1211182281430 : check e1211182281430 [[],[]] .smaller = true := by decide
def e1211182281434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211182281434 : Closed e1211182281434 ∧ code e1211182281434 = 5609228792538 := by decide
theorem cert_e1211182281434 : check e1211182281434 [[],[]] .smaller = true := by decide
def e1211182281450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211182281450 : Closed e1211182281450 ∧ code e1211182281450 = 5609228792554 := by decide
theorem cert_e1211182281450 : check e1211182281450 [[],[]] .smaller = true := by decide
def e1211182281502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211182281502 : Closed e1211182281502 ∧ code e1211182281502 = 5609228792606 := by decide
theorem cert_e1211182281502 : check e1211182281502 [[],[]] .smaller = true := by decide
def e1211182281526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182281526 : Closed e1211182281526 ∧ code e1211182281526 = 5609228792630 := by decide
theorem cert_e1211182281526 : check e1211182281526 [[],[]] .smaller = true := by decide
def e1211182281530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182281530 : Closed e1211182281530 ∧ code e1211182281530 = 5609228792634 := by decide
theorem cert_e1211182281530 : check e1211182281530 [[],[]] .smaller = true := by decide
def e1211182281614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211182281614 : Closed e1211182281614 ∧ code e1211182281614 = 5609228792718 := by decide
theorem cert_e1211182281614 : check e1211182281614 [[],[]] .smaller = true := by decide
def e1211182281626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182281626 : Closed e1211182281626 ∧ code e1211182281626 = 5609228792730 := by decide
theorem cert_e1211182281626 : check e1211182281626 [[],[]] .smaller = true := by decide
def e1211182281670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211182281670 : Closed e1211182281670 ∧ code e1211182281670 = 5609228792774 := by decide
theorem cert_e1211182281670 : check e1211182281670 [[],[]] .smaller = true := by decide
def e1211182281694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211182281694 : Closed e1211182281694 ∧ code e1211182281694 = 5609228792798 := by decide
theorem cert_e1211182281694 : check e1211182281694 [[],[]] .smaller = true := by decide
def e1211182281710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211182281710 : Closed e1211182281710 ∧ code e1211182281710 = 5609228792814 := by decide
theorem cert_e1211182281710 : check e1211182281710 [[],[]] .smaller = true := by decide
def e1211182283150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211182283150 : Closed e1211182283150 ∧ code e1211182283150 = 5609228794254 := by decide
theorem cert_e1211182283150 : check e1211182283150 [[],[]] .three = true := by decide
def e1211182283206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211182283206 : Closed e1211182283206 ∧ code e1211182283206 = 5609228794310 := by decide
theorem cert_e1211182283206 : check e1211182283206 [[],[]] .three = true := by decide
def e1211182283246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182283246 : Closed e1211182283246 ∧ code e1211182283246 = 5609228794350 := by decide
theorem cert_e1211182283246 : check e1211182283246 [[],[]] .three = true := by decide
def e1211182288606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 3))))))))
theorem wire_e1211182288606 : Closed e1211182288606 ∧ code e1211182288606 = 5609228799710 := by decide
theorem cert_e1211182288606 : check e1211182288606 [[],[]] .smaller = true := by decide
def e1211182288622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e1211182288622 : Closed e1211182288622 ∧ code e1211182288622 = 5609228799726 := by decide
theorem cert_e1211182288622 : check e1211182288622 [[],[]] .smaller = true := by decide
def e1211182288630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e1211182288630 : Closed e1211182288630 ∧ code e1211182288630 = 5609228799734 := by decide
theorem cert_e1211182288630 : check e1211182288630 [[],[]] .smaller = true := by decide
def e1211182288634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 0))))))))
theorem wire_e1211182288634 : Closed e1211182288634 ∧ code e1211182288634 = 5609228799738 := by decide
theorem cert_e1211182288634 : check e1211182288634 [[],[]] .smaller = true := by decide
def e1211182288750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e1211182288750 : Closed e1211182288750 ∧ code e1211182288750 = 5609228799854 := by decide
theorem cert_e1211182288750 : check e1211182288750 [[],[]] .smaller = true := by decide
def e1211182288762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e1211182288762 : Closed e1211182288762 ∧ code e1211182288762 = 5609228799866 := by decide
theorem cert_e1211182288762 : check e1211182288762 [[],[]] .smaller = true := by decide
def e1211182288822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e1211182288822 : Closed e1211182288822 ∧ code e1211182288822 = 5609228799926 := by decide
theorem cert_e1211182288822 : check e1211182288822 [[],[]] .smaller = true := by decide
def e1211182288826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e1211182288826 : Closed e1211182288826 ∧ code e1211182288826 = 5609228799930 := by decide
theorem cert_e1211182288826 : check e1211182288826 [[],[]] .smaller = true := by decide
def e1211182288858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 0))))))))
theorem wire_e1211182288858 : Closed e1211182288858 ∧ code e1211182288858 = 5609228799962 := by decide
theorem cert_e1211182288858 : check e1211182288858 [[],[]] .smaller = true := by decide
def e1211182291390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 4)))))))))
theorem wire_e1211182291390 : Closed e1211182291390 ∧ code e1211182291390 = 5609228802494 := by decide
theorem cert_e1211182291390 : check e1211182291390 [[],[]] .three = true := by decide
def e1211182291422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211182291422 : Closed e1211182291422 ∧ code e1211182291422 = 5609228802526 := by decide
theorem cert_e1211182291422 : check e1211182291422 [[],[]] .smaller = true := by decide
def e1211182291438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182291438 : Closed e1211182291438 ∧ code e1211182291438 = 5609228802542 := by decide
theorem cert_e1211182291438 : check e1211182291438 [[],[]] .smaller = true := by decide
def e1211182291446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211182291446 : Closed e1211182291446 ∧ code e1211182291446 = 5609228802550 := by decide
theorem cert_e1211182291446 : check e1211182291446 [[],[]] .smaller = true := by decide
def e1211182291450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 4) (.var 0)))))))))
theorem wire_e1211182291450 : Closed e1211182291450 ∧ code e1211182291450 = 5609228802554 := by decide
theorem cert_e1211182291450 : check e1211182291450 [[],[]] .three = true := by decide
def e1211182292190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182292190 : Closed e1211182292190 ∧ code e1211182292190 = 5609228803294 := by decide
theorem cert_e1211182292190 : check e1211182292190 [[],[]] .smaller = true := by decide
def e1211182292218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182292218 : Closed e1211182292218 ∧ code e1211182292218 = 5609228803322 := by decide
theorem cert_e1211182292218 : check e1211182292218 [[],[]] .smaller = true := by decide
def e1211182292590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182292590 : Closed e1211182292590 ∧ code e1211182292590 = 5609228803694 := by decide
theorem cert_e1211182292590 : check e1211182292590 [[],[]] .smaller = true := by decide
def e1211182292602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182292602 : Closed e1211182292602 ∧ code e1211182292602 = 5609228803706 := by decide
theorem cert_e1211182292602 : check e1211182292602 [[],[]] .smaller = true := by decide
def e1211182292790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182292790 : Closed e1211182292790 ∧ code e1211182292790 = 5609228803894 := by decide
theorem cert_e1211182292790 : check e1211182292790 [[],[]] .smaller = true := by decide
def e1211182292794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182292794 : Closed e1211182292794 ∧ code e1211182292794 = 5609228803898 := by decide
theorem cert_e1211182292794 : check e1211182292794 [[],[]] .smaller = true := by decide
def e1211182292890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 5))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182292890 : Closed e1211182292890 ∧ code e1211182292890 = 5609228803994 := by decide
theorem cert_e1211182292890 : check e1211182292890 [[],[]] .three = true := by decide
def e1211182296414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 3))))))))
theorem wire_e1211182296414 : Closed e1211182296414 ∧ code e1211182296414 = 5609228807518 := by decide
theorem cert_e1211182296414 : check e1211182296414 [[],[]] .smaller = true := by decide
def e1211182296430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e1211182296430 : Closed e1211182296430 ∧ code e1211182296430 = 5609228807534 := by decide
theorem cert_e1211182296430 : check e1211182296430 [[],[]] .smaller = true := by decide
def e1211182296438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e1211182296438 : Closed e1211182296438 ∧ code e1211182296438 = 5609228807542 := by decide
theorem cert_e1211182296438 : check e1211182296438 [[],[]] .smaller = true := by decide
def e1211182296442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0))))))))
theorem wire_e1211182296442 : Closed e1211182296442 ∧ code e1211182296442 = 5609228807546 := by decide
theorem cert_e1211182296442 : check e1211182296442 [[],[]] .smaller = true := by decide
def e1211182296494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e1211182296494 : Closed e1211182296494 ∧ code e1211182296494 = 5609228807598 := by decide
theorem cert_e1211182296494 : check e1211182296494 [[],[]] .smaller = true := by decide
def e1211182296506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e1211182296506 : Closed e1211182296506 ∧ code e1211182296506 = 5609228807610 := by decide
theorem cert_e1211182296506 : check e1211182296506 [[],[]] .smaller = true := by decide
def e1211182296534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e1211182296534 : Closed e1211182296534 ∧ code e1211182296534 = 5609228807638 := by decide
theorem cert_e1211182296534 : check e1211182296534 [[],[]] .smaller = true := by decide
def e1211182296538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e1211182296538 : Closed e1211182296538 ∧ code e1211182296538 = 5609228807642 := by decide
theorem cert_e1211182296538 : check e1211182296538 [[],[]] .smaller = true := by decide
def e1211182296554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0))))))))
theorem wire_e1211182296554 : Closed e1211182296554 ∧ code e1211182296554 = 5609228807658 := by decide
theorem cert_e1211182296554 : check e1211182296554 [[],[]] .smaller = true := by decide
def e1211182296750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e1211182296750 : Closed e1211182296750 ∧ code e1211182296750 = 5609228807854 := by decide
theorem cert_e1211182296750 : check e1211182296750 [[],[]] .smaller = true := by decide
def e1211182296762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e1211182296762 : Closed e1211182296762 ∧ code e1211182296762 = 5609228807866 := by decide
theorem cert_e1211182296762 : check e1211182296762 [[],[]] .smaller = true := by decide
def e1211182296810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e1211182296810 : Closed e1211182296810 ∧ code e1211182296810 = 5609228807914 := by decide
theorem cert_e1211182296810 : check e1211182296810 [[],[]] .smaller = true := by decide
def e1211182296918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e1211182296918 : Closed e1211182296918 ∧ code e1211182296918 = 5609228808022 := by decide
theorem cert_e1211182296918 : check e1211182296918 [[],[]] .smaller = true := by decide
def e1211182296922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e1211182296922 : Closed e1211182296922 ∧ code e1211182296922 = 5609228808026 := by decide
theorem cert_e1211182296922 : check e1211182296922 [[],[]] .smaller = true := by decide
def e1211182296938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e1211182296938 : Closed e1211182296938 ∧ code e1211182296938 = 5609228808042 := by decide
theorem cert_e1211182296938 : check e1211182296938 [[],[]] .smaller = true := by decide
def e1211182297002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e1211182297002 : Closed e1211182297002 ∧ code e1211182297002 = 5609228808106 := by decide
theorem cert_e1211182297002 : check e1211182297002 [[],[]] .smaller = true := by decide
def e1211182297534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 4))))))))
theorem wire_e1211182297534 : Closed e1211182297534 ∧ code e1211182297534 = 5609228808638 := by decide
theorem cert_e1211182297534 : check e1211182297534 [[],[]] .three = true := by decide
def e1211182297566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211182297566 : Closed e1211182297566 ∧ code e1211182297566 = 5609228808670 := by decide
theorem cert_e1211182297566 : check e1211182297566 [[],[]] .smaller = true := by decide
def e1211182297582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))))
theorem wire_e1211182297582 : Closed e1211182297582 ∧ code e1211182297582 = 5609228808686 := by decide
theorem cert_e1211182297582 : check e1211182297582 [[],[]] .smaller = true := by decide
def e1211182297590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 1))))))))
theorem wire_e1211182297590 : Closed e1211182297590 ∧ code e1211182297590 = 5609228808694 := by decide
theorem cert_e1211182297590 : check e1211182297590 [[],[]] .smaller = true := by decide
def e1211182297594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211182297594 : Closed e1211182297594 ∧ code e1211182297594 = 5609228808698 := by decide
theorem cert_e1211182297594 : check e1211182297594 [[],[]] .three = true := by decide
def e1211182297950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e1211182297950 : Closed e1211182297950 ∧ code e1211182297950 = 5609228809054 := by decide
theorem cert_e1211182297950 : check e1211182297950 [[],[]] .smaller = true := by decide
def e1211182297966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211182297966 : Closed e1211182297966 ∧ code e1211182297966 = 5609228809070 := by decide
theorem cert_e1211182297966 : check e1211182297966 [[],[]] .smaller = true := by decide
def e1211182297974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e1211182297974 : Closed e1211182297974 ∧ code e1211182297974 = 5609228809078 := by decide
theorem cert_e1211182297974 : check e1211182297974 [[],[]] .smaller = true := by decide
def e1211182297978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211182297978 : Closed e1211182297978 ∧ code e1211182297978 = 5609228809082 := by decide
theorem cert_e1211182297978 : check e1211182297978 [[],[]] .smaller = true := by decide
def e1211182298030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211182298030 : Closed e1211182298030 ∧ code e1211182298030 = 5609228809134 := by decide
theorem cert_e1211182298030 : check e1211182298030 [[],[]] .smaller = true := by decide
def e1211182298042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e1211182298042 : Closed e1211182298042 ∧ code e1211182298042 = 5609228809146 := by decide
theorem cert_e1211182298042 : check e1211182298042 [[],[]] .smaller = true := by decide
def e1211182298070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e1211182298070 : Closed e1211182298070 ∧ code e1211182298070 = 5609228809174 := by decide
theorem cert_e1211182298070 : check e1211182298070 [[],[]] .smaller = true := by decide
def e1211182298074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e1211182298074 : Closed e1211182298074 ∧ code e1211182298074 = 5609228809178 := by decide
theorem cert_e1211182298074 : check e1211182298074 [[],[]] .smaller = true := by decide
def e1211182298090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211182298090 : Closed e1211182298090 ∧ code e1211182298090 = 5609228809194 := by decide
theorem cert_e1211182298090 : check e1211182298090 [[],[]] .smaller = true := by decide
def e1211182298238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 5)))))))))
theorem wire_e1211182298238 : Closed e1211182298238 ∧ code e1211182298238 = 5609228809342 := by decide
theorem cert_e1211182298238 : check e1211182298238 [[],[]] .three = true := by decide
def e1211182298334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182298334 : Closed e1211182298334 ∧ code e1211182298334 = 5609228809438 := by decide
theorem cert_e1211182298334 : check e1211182298334 [[],[]] .smaller = true := by decide
def e1211182298350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182298350 : Closed e1211182298350 ∧ code e1211182298350 = 5609228809454 := by decide
theorem cert_e1211182298350 : check e1211182298350 [[],[]] .smaller = true := by decide
def e1211182298358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182298358 : Closed e1211182298358 ∧ code e1211182298358 = 5609228809462 := by decide
theorem cert_e1211182298358 : check e1211182298358 [[],[]] .smaller = true := by decide
def e1211182298362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182298362 : Closed e1211182298362 ∧ code e1211182298362 = 5609228809466 := by decide
theorem cert_e1211182298362 : check e1211182298362 [[],[]] .smaller = true := by decide
def e1211182298686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211182298686 : Closed e1211182298686 ∧ code e1211182298686 = 5609228809790 := by decide
theorem cert_e1211182298686 : check e1211182298686 [[],[]] .smaller = true := by decide
def e1211182298734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182298734 : Closed e1211182298734 ∧ code e1211182298734 = 5609228809838 := by decide
theorem cert_e1211182298734 : check e1211182298734 [[],[]] .smaller = true := by decide
def e1211182298746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182298746 : Closed e1211182298746 ∧ code e1211182298746 = 5609228809850 := by decide
theorem cert_e1211182298746 : check e1211182298746 [[],[]] .smaller = true := by decide
def e1211182298910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))))
theorem wire_e1211182298910 : Closed e1211182298910 ∧ code e1211182298910 = 5609228810014 := by decide
theorem cert_e1211182298910 : check e1211182298910 [[],[]] .smaller = true := by decide
def e1211182298934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182298934 : Closed e1211182298934 ∧ code e1211182298934 = 5609228810038 := by decide
theorem cert_e1211182298934 : check e1211182298934 [[],[]] .smaller = true := by decide
def e1211182298938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182298938 : Closed e1211182298938 ∧ code e1211182298938 = 5609228810042 := by decide
theorem cert_e1211182298938 : check e1211182298938 [[],[]] .smaller = true := by decide
def e1211182299022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 2)))))))))
theorem wire_e1211182299022 : Closed e1211182299022 ∧ code e1211182299022 = 5609228810126 := by decide
theorem cert_e1211182299022 : check e1211182299022 [[],[]] .smaller = true := by decide
def e1211182299034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182299034 : Closed e1211182299034 ∧ code e1211182299034 = 5609228810138 := by decide
theorem cert_e1211182299034 : check e1211182299034 [[],[]] .smaller = true := by decide
def e1211182299078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211182299078 : Closed e1211182299078 ∧ code e1211182299078 = 5609228810182 := by decide
theorem cert_e1211182299078 : check e1211182299078 [[],[]] .three = true := by decide
def e1211182299358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e1211182299358 : Closed e1211182299358 ∧ code e1211182299358 = 5609228810462 := by decide
theorem cert_e1211182299358 : check e1211182299358 [[],[]] .smaller = true := by decide
def e1211182299386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e1211182299386 : Closed e1211182299386 ∧ code e1211182299386 = 5609228810490 := by decide
theorem cert_e1211182299386 : check e1211182299386 [[],[]] .smaller = true := by decide
def e1211182299566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e1211182299566 : Closed e1211182299566 ∧ code e1211182299566 = 5609228810670 := by decide
theorem cert_e1211182299566 : check e1211182299566 [[],[]] .smaller = true := by decide
def e1211182299578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e1211182299578 : Closed e1211182299578 ∧ code e1211182299578 = 5609228810682 := by decide
theorem cert_e1211182299578 : check e1211182299578 [[],[]] .smaller = true := by decide
def e1211182299626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e1211182299626 : Closed e1211182299626 ∧ code e1211182299626 = 5609228810730 := by decide
theorem cert_e1211182299626 : check e1211182299626 [[],[]] .smaller = true := by decide
def e1211182299710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e1211182299710 : Closed e1211182299710 ∧ code e1211182299710 = 5609228810814 := by decide
theorem cert_e1211182299710 : check e1211182299710 [[],[]] .smaller = true := by decide
def e1211182299758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182299758 : Closed e1211182299758 ∧ code e1211182299758 = 5609228810862 := by decide
theorem cert_e1211182299758 : check e1211182299758 [[],[]] .smaller = true := by decide
def e1211182299770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182299770 : Closed e1211182299770 ∧ code e1211182299770 = 5609228810874 := by decide
theorem cert_e1211182299770 : check e1211182299770 [[],[]] .smaller = true := by decide
def e1211182300058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182300058 : Closed e1211182300058 ∧ code e1211182300058 = 5609228811162 := by decide
theorem cert_e1211182300058 : check e1211182300058 [[],[]] .smaller = true := by decide
def e1211182300094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 4))))))))
theorem wire_e1211182300094 : Closed e1211182300094 ∧ code e1211182300094 = 5609228811198 := by decide
theorem cert_e1211182300094 : check e1211182300094 [[],[]] .three = true := by decide
def e1211182300102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e1211182300102 : Closed e1211182300102 ∧ code e1211182300102 = 5609228811206 := by decide
theorem cert_e1211182300102 : check e1211182300102 [[],[]] .smaller = true := by decide
def e1211182300142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.var 2))))))))
theorem wire_e1211182300142 : Closed e1211182300142 ∧ code e1211182300142 = 5609228811246 := by decide
theorem cert_e1211182300142 : check e1211182300142 [[],[]] .three = true := by decide
def e1211182300270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211182300270 : Closed e1211182300270 ∧ code e1211182300270 = 5609228811374 := by decide
theorem cert_e1211182300270 : check e1211182300270 [[],[]] .smaller = true := by decide
def e1211182300282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211182300282 : Closed e1211182300282 ∧ code e1211182300282 = 5609228811386 := by decide
theorem cert_e1211182300282 : check e1211182300282 [[],[]] .smaller = true := by decide
def e1211182300374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211182300374 : Closed e1211182300374 ∧ code e1211182300374 = 5609228811478 := by decide
theorem cert_e1211182300374 : check e1211182300374 [[],[]] .smaller = true := by decide
def e1211182300378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211182300378 : Closed e1211182300378 ∧ code e1211182300378 = 5609228811482 := by decide
theorem cert_e1211182300378 : check e1211182300378 [[],[]] .smaller = true := by decide
def e1211182300394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211182300394 : Closed e1211182300394 ∧ code e1211182300394 = 5609228811498 := by decide
theorem cert_e1211182300394 : check e1211182300394 [[],[]] .smaller = true := by decide
def e1211182300446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211182300446 : Closed e1211182300446 ∧ code e1211182300446 = 5609228811550 := by decide
theorem cert_e1211182300446 : check e1211182300446 [[],[]] .smaller = true := by decide
def e1211182300470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182300470 : Closed e1211182300470 ∧ code e1211182300470 = 5609228811574 := by decide
theorem cert_e1211182300470 : check e1211182300470 [[],[]] .smaller = true := by decide
def e1211182300474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182300474 : Closed e1211182300474 ∧ code e1211182300474 = 5609228811578 := by decide
theorem cert_e1211182300474 : check e1211182300474 [[],[]] .smaller = true := by decide
def e1211182300570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182300570 : Closed e1211182300570 ∧ code e1211182300570 = 5609228811674 := by decide
theorem cert_e1211182300570 : check e1211182300570 [[],[]] .smaller = true := by decide
def e1211182300606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 4))))))))
theorem wire_e1211182300606 : Closed e1211182300606 ∧ code e1211182300606 = 5609228811710 := by decide
theorem cert_e1211182300606 : check e1211182300606 [[],[]] .three = true := by decide
def e1211182300614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211182300614 : Closed e1211182300614 ∧ code e1211182300614 = 5609228811718 := by decide
theorem cert_e1211182300614 : check e1211182300614 [[],[]] .smaller = true := by decide
def e1211182300638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 3))))))))
theorem wire_e1211182300638 : Closed e1211182300638 ∧ code e1211182300638 = 5609228811742 := by decide
theorem cert_e1211182300638 : check e1211182300638 [[],[]] .smaller = true := by decide
def e1211182300654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 2))))))))
theorem wire_e1211182300654 : Closed e1211182300654 ∧ code e1211182300654 = 5609228811758 := by decide
theorem cert_e1211182300654 : check e1211182300654 [[],[]] .smaller = true := by decide
def e1211182300662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 4))) (.var 1))))))))
theorem wire_e1211182300662 : Closed e1211182300662 ∧ code e1211182300662 = 5609228811766 := by decide
theorem cert_e1211182300662 : check e1211182300662 [[],[]] .three = true := by decide
def e1211182300726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211182300726 : Closed e1211182300726 ∧ code e1211182300726 = 5609228811830 := by decide
theorem cert_e1211182300726 : check e1211182300726 [[],[]] .smaller = true := by decide
def e1211182300730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211182300730 : Closed e1211182300730 ∧ code e1211182300730 = 5609228811834 := by decide
theorem cert_e1211182300730 : check e1211182300730 [[],[]] .smaller = true := by decide
def e1211182300778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e1211182300778 : Closed e1211182300778 ∧ code e1211182300778 = 5609228811882 := by decide
theorem cert_e1211182300778 : check e1211182300778 [[],[]] .smaller = true := by decide
def e1211182300814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211182300814 : Closed e1211182300814 ∧ code e1211182300814 = 5609228811918 := by decide
theorem cert_e1211182300814 : check e1211182300814 [[],[]] .smaller = true := by decide
def e1211182300826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182300826 : Closed e1211182300826 ∧ code e1211182300826 = 5609228811930 := by decide
theorem cert_e1211182300826 : check e1211182300826 [[],[]] .smaller = true := by decide
def e1211182300870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211182300870 : Closed e1211182300870 ∧ code e1211182300870 = 5609228811974 := by decide
theorem cert_e1211182300870 : check e1211182300870 [[],[]] .smaller = true := by decide
def e1211182300910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 2))))))))
theorem wire_e1211182300910 : Closed e1211182300910 ∧ code e1211182300910 = 5609228812014 := by decide
theorem cert_e1211182300910 : check e1211182300910 [[],[]] .smaller = true := by decide
def e1211182300954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211182300954 : Closed e1211182300954 ∧ code e1211182300954 = 5609228812058 := by decide
theorem cert_e1211182300954 : check e1211182300954 [[],[]] .three = true := by decide
def e1211182300998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211182300998 : Closed e1211182300998 ∧ code e1211182300998 = 5609228812102 := by decide
theorem cert_e1211182300998 : check e1211182300998 [[],[]] .three = true := by decide
def e1211182301038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.var 2))))))))
theorem wire_e1211182301038 : Closed e1211182301038 ∧ code e1211182301038 = 5609228812142 := by decide
theorem cert_e1211182301038 : check e1211182301038 [[],[]] .three = true := by decide
def e1211182301046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 2))) (.var 1))))))))
theorem wire_e1211182301046 : Closed e1211182301046 ∧ code e1211182301046 = 5609228812150 := by decide
theorem cert_e1211182301046 : check e1211182301046 [[],[]] .three = true := by decide
def e1211182302142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e1211182302142 : Closed e1211182302142 ∧ code e1211182302142 = 5609228813246 := by decide
theorem cert_e1211182302142 : check e1211182302142 [[],[]] .smaller = true := by decide
def e1211182302174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182302174 : Closed e1211182302174 ∧ code e1211182302174 = 5609228813278 := by decide
theorem cert_e1211182302174 : check e1211182302174 [[],[]] .smaller = true := by decide
def e1211182302190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182302190 : Closed e1211182302190 ∧ code e1211182302190 = 5609228813294 := by decide
theorem cert_e1211182302190 : check e1211182302190 [[],[]] .smaller = true := by decide
def e1211182302198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e1211182302198 : Closed e1211182302198 ∧ code e1211182302198 = 5609228813302 := by decide
theorem cert_e1211182302198 : check e1211182302198 [[],[]] .smaller = true := by decide
def e1211182304094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211182304094 : Closed e1211182304094 ∧ code e1211182304094 = 5609228815198 := by decide
theorem cert_e1211182304094 : check e1211182304094 [[],[]] .smaller = true := by decide
def e1211182304110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211182304110 : Closed e1211182304110 ∧ code e1211182304110 = 5609228815214 := by decide
theorem cert_e1211182304110 : check e1211182304110 [[],[]] .smaller = true := by decide
def e1211182304118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211182304118 : Closed e1211182304118 ∧ code e1211182304118 = 5609228815222 := by decide
theorem cert_e1211182304118 : check e1211182304118 [[],[]] .smaller = true := by decide
def e1211182304122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211182304122 : Closed e1211182304122 ∧ code e1211182304122 = 5609228815226 := by decide
theorem cert_e1211182304122 : check e1211182304122 [[],[]] .smaller = true := by decide
def e1211182304174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211182304174 : Closed e1211182304174 ∧ code e1211182304174 = 5609228815278 := by decide
theorem cert_e1211182304174 : check e1211182304174 [[],[]] .smaller = true := by decide
def e1211182304186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211182304186 : Closed e1211182304186 ∧ code e1211182304186 = 5609228815290 := by decide
theorem cert_e1211182304186 : check e1211182304186 [[],[]] .smaller = true := by decide
def e1211182304214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211182304214 : Closed e1211182304214 ∧ code e1211182304214 = 5609228815318 := by decide
theorem cert_e1211182304214 : check e1211182304214 [[],[]] .smaller = true := by decide
def e1211182304218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211182304218 : Closed e1211182304218 ∧ code e1211182304218 = 5609228815322 := by decide
theorem cert_e1211182304218 : check e1211182304218 [[],[]] .smaller = true := by decide
def e1211182304234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211182304234 : Closed e1211182304234 ∧ code e1211182304234 = 5609228815338 := by decide
theorem cert_e1211182304234 : check e1211182304234 [[],[]] .smaller = true := by decide
def e1211182304382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 5))))))))))
theorem wire_e1211182304382 : Closed e1211182304382 ∧ code e1211182304382 = 5609228815486 := by decide
theorem cert_e1211182304382 : check e1211182304382 [[],[]] .three = true := by decide
def e1211182304478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182304478 : Closed e1211182304478 ∧ code e1211182304478 = 5609228815582 := by decide
theorem cert_e1211182304478 : check e1211182304478 [[],[]] .smaller = true := by decide
def e1211182304494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182304494 : Closed e1211182304494 ∧ code e1211182304494 = 5609228815598 := by decide
theorem cert_e1211182304494 : check e1211182304494 [[],[]] .smaller = true := by decide
def e1211182304502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182304502 : Closed e1211182304502 ∧ code e1211182304502 = 5609228815606 := by decide
theorem cert_e1211182304502 : check e1211182304502 [[],[]] .smaller = true := by decide
def e1211182304506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182304506 : Closed e1211182304506 ∧ code e1211182304506 = 5609228815610 := by decide
theorem cert_e1211182304506 : check e1211182304506 [[],[]] .smaller = true := by decide
def e1211182304830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211182304830 : Closed e1211182304830 ∧ code e1211182304830 = 5609228815934 := by decide
theorem cert_e1211182304830 : check e1211182304830 [[],[]] .smaller = true := by decide
def e1211182304878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182304878 : Closed e1211182304878 ∧ code e1211182304878 = 5609228815982 := by decide
theorem cert_e1211182304878 : check e1211182304878 [[],[]] .smaller = true := by decide
def e1211182304890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182304890 : Closed e1211182304890 ∧ code e1211182304890 = 5609228815994 := by decide
theorem cert_e1211182304890 : check e1211182304890 [[],[]] .smaller = true := by decide
def e1211182305054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211182305054 : Closed e1211182305054 ∧ code e1211182305054 = 5609228816158 := by decide
theorem cert_e1211182305054 : check e1211182305054 [[],[]] .smaller = true := by decide
def e1211182305078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182305078 : Closed e1211182305078 ∧ code e1211182305078 = 5609228816182 := by decide
theorem cert_e1211182305078 : check e1211182305078 [[],[]] .smaller = true := by decide
def e1211182305082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182305082 : Closed e1211182305082 ∧ code e1211182305082 = 5609228816186 := by decide
theorem cert_e1211182305082 : check e1211182305082 [[],[]] .smaller = true := by decide
end Blc.Floor42
