import Tables
import Batch132
namespace Blc.Floor42.Grades132
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1209595420014 : ¬ IsSelfInterpreter e1209595420014 := cutM0_2 (by decide)
#print axioms ex_e1209595420014
theorem ex_e1209595420022 : ¬ IsSelfInterpreter e1209595420022 := cutM0_2 (by decide)
#print axioms ex_e1209595420022
theorem ex_e1209595425646 : ¬ IsSelfInterpreter e1209595425646 := cutM0_2 (by decide)
#print axioms ex_e1209595425646
theorem ex_e1209595425654 : ¬ IsSelfInterpreter e1209595425654 := cutM0_2 (by decide)
#print axioms ex_e1209595425654
theorem ex_e1209595425710 : ¬ IsSelfInterpreter e1209595425710 := cutM0_2 (by decide)
#print axioms ex_e1209595425710
theorem ex_e1209595425750 : ¬ IsSelfInterpreter e1209595425750 := cutM0_2 (by decide)
#print axioms ex_e1209595425750
theorem ex_e1209595427286 : ¬ IsSelfInterpreter e1209595427286 := cutM0_2 (by decide)
#print axioms ex_e1209595427286
theorem ex_e1209595448238 : ¬ IsSelfInterpreter e1209595448238 := cutM0_2 (by decide)
#print axioms ex_e1209595448238
theorem ex_e1209595448942 : ¬ IsSelfInterpreter e1209595448942 := cutM0_2 (by decide)
#print axioms ex_e1209595448942
theorem ex_e1209595448954 : ¬ IsSelfInterpreter e1209595448954 := cutM0_2 (by decide)
#print axioms ex_e1209595448954
theorem ex_e1209595449146 : ¬ IsSelfInterpreter e1209595449146 := cutM0_2 (by decide)
#print axioms ex_e1209595449146
theorem ex_e1209595454934 : ¬ IsSelfInterpreter e1209595454934 := cutM0_2 (by decide)
#print axioms ex_e1209595454934
theorem ex_e1209595455286 : ¬ IsSelfInterpreter e1209595455286 := cutM0_2 (by decide)
#print axioms ex_e1209595455286
theorem ex_e1209595455290 : ¬ IsSelfInterpreter e1209595455290 := cutM0_2 (by decide)
#print axioms ex_e1209595455290
theorem ex_e1209595448174 : ¬ IsSelfInterpreter e1209595448174 := cutM1_2 (by decide)
#print axioms ex_e1209595448174
theorem ex_e1209595448182 : ¬ IsSelfInterpreter e1209595448182 := cutM1_2 (by decide)
#print axioms ex_e1209595448182
theorem ex_e1209595448278 : ¬ IsSelfInterpreter e1209595448278 := cutM1_2 (by decide)
#print axioms ex_e1209595448278
theorem ex_e1209595448558 : ¬ IsSelfInterpreter e1209595448558 := cutM1_2 (by decide)
#print axioms ex_e1209595448558
theorem ex_e1209595448566 : ¬ IsSelfInterpreter e1209595448566 := cutM1_2 (by decide)
#print axioms ex_e1209595448566
theorem ex_e1209595449142 : ¬ IsSelfInterpreter e1209595449142 := cutM1_2 (by decide)
#print axioms ex_e1209595449142
theorem ex_e1209595419502 : ¬ IsSelfInterpreter e1209595419502 := cutM3_1 (by decide)
#print axioms ex_e1209595419502
theorem ex_e1209595419510 : ¬ IsSelfInterpreter e1209595419510 := cutM3_1 (by decide)
#print axioms ex_e1209595419510
theorem ex_e1209595419574 : ¬ IsSelfInterpreter e1209595419574 := cutM3_1 (by decide)
#print axioms ex_e1209595419574
theorem ex_e1209595420342 : ¬ IsSelfInterpreter e1209595420342 := cutM3_1 (by decide)
#print axioms ex_e1209595420342
theorem ex_e1209595422574 : ¬ IsSelfInterpreter e1209595422574 := cutM3_1 (by decide)
#print axioms ex_e1209595422574
theorem ex_e1209595422582 : ¬ IsSelfInterpreter e1209595422582 := cutM3_1 (by decide)
#print axioms ex_e1209595422582
theorem ex_e1209595422646 : ¬ IsSelfInterpreter e1209595422646 := cutM3_1 (by decide)
#print axioms ex_e1209595422646
theorem ex_e1209595427254 : ¬ IsSelfInterpreter e1209595427254 := cutM3_1 (by decide)
#print axioms ex_e1209595427254
theorem ex_e1209595454902 : ¬ IsSelfInterpreter e1209595454902 := cutM8_1 (by decide)
#print axioms ex_e1209595454902
theorem ex_e1209595455094 : ¬ IsSelfInterpreter e1209595455094 := cutM14_0 (by decide)
#print axioms ex_e1209595455094
end Blc.Floor42.Grades132
