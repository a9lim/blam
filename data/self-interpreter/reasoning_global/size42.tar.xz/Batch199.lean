import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204790074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204790074 : Closed e1211204790074 ∧ code e1211204790074 = 5609251301178 := by decide
theorem cert_e1211204790074 : check e1211204790074 [[],[]] .chain = true := by decide
def e1211204790158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211204790158 : Closed e1211204790158 ∧ code e1211204790158 = 5609251301262 := by decide
theorem cert_e1211204790158 : check e1211204790158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204792350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211204792350 : Closed e1211204792350 ∧ code e1211204792350 = 5609251303454 := by decide
theorem cert_e1211204792350 : check e1211204792350 [[],[]] .chain = true := by decide
def e1211204792518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211204792518 : Closed e1211204792518 ∧ code e1211204792518 = 5609251303622 := by decide
theorem cert_e1211204792518 : check e1211204792518 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204792542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211204792542 : Closed e1211204792542 ∧ code e1211204792542 = 5609251303646 := by decide
theorem cert_e1211204792542 : check e1211204792542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204792546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211204792546 : Closed e1211204792546 ∧ code e1211204792546 = 5609251303650 := by decide
theorem cert_e1211204792546 : check e1211204792546 [[],[]] .chain = true := by decide
def e1211204792558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204792558 : Closed e1211204792558 ∧ code e1211204792558 = 5609251303662 := by decide
theorem cert_e1211204792558 : check e1211204792558 [[],[]] .chain = true := by decide
def e1211204792566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204792566 : Closed e1211204792566 ∧ code e1211204792566 = 5609251303670 := by decide
theorem cert_e1211204792566 : check e1211204792566 [[],[]] .chain = true := by decide
def e1211204792570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211204792570 : Closed e1211204792570 ∧ code e1211204792570 = 5609251303674 := by decide
theorem cert_e1211204792570 : check e1211204792570 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204793046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211204793046 : Closed e1211204793046 ∧ code e1211204793046 = 5609251304150 := by decide
theorem cert_e1211204793046 : check e1211204793046 [[],[]] .chain = true := by decide
def e1211204793050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211204793050 : Closed e1211204793050 ∧ code e1211204793050 = 5609251304154 := by decide
theorem cert_e1211204793050 : check e1211204793050 [[],[]] .chain = true := by decide
def e1211204793066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211204793066 : Closed e1211204793066 ∧ code e1211204793066 = 5609251304170 := by decide
theorem cert_e1211204793066 : check e1211204793066 [[],[]] .chain = true := by decide
def e1211204793094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204793094 : Closed e1211204793094 ∧ code e1211204793094 = 5609251304198 := by decide
theorem cert_e1211204793094 : check e1211204793094 [[],[]] .chain = true := by decide
def e1211204793118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211204793118 : Closed e1211204793118 ∧ code e1211204793118 = 5609251304222 := by decide
theorem cert_e1211204793118 : check e1211204793118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204793142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204793142 : Closed e1211204793142 ∧ code e1211204793142 = 5609251304246 := by decide
theorem cert_e1211204793142 : check e1211204793142 [[],[]] .chain = true := by decide
def e1211204793146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204793146 : Closed e1211204793146 ∧ code e1211204793146 = 5609251304250 := by decide
theorem cert_e1211204793146 : check e1211204793146 [[],[]] .chain = true := by decide
def e1211204793218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211204793218 : Closed e1211204793218 ∧ code e1211204793218 = 5609251304322 := by decide
theorem cert_e1211204793218 : check e1211204793218 [[],[]] .chain = true := by decide
def e1211204793230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211204793230 : Closed e1211204793230 ∧ code e1211204793230 = 5609251304334 := by decide
theorem cert_e1211204793230 : check e1211204793230 [[],[]] .chain = true := by decide
def e1211204793242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211204793242 : Closed e1211204793242 ∧ code e1211204793242 = 5609251304346 := by decide
theorem cert_e1211204793242 : check e1211204793242 [[],[]] .chain = true := by decide
def e1211204793286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211204793286 : Closed e1211204793286 ∧ code e1211204793286 = 5609251304390 := by decide
theorem cert_e1211204793286 : check e1211204793286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204794478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204794478 : Closed e1211204794478 ∧ code e1211204794478 = 5609251305582 := by decide
theorem cert_e1211204794478 : checkPay e1211204794478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left]] 0 [] = true := by decide
def e1211204794490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204794490 : Closed e1211204794490 ∧ code e1211204794490 = 5609251305594 := by decide
theorem cert_e1211204794490 : check e1211204794490 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211204794766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211204794766 : Closed e1211204794766 ∧ code e1211204794766 = 5609251305870 := by decide
theorem cert_e1211204794766 : check e1211204794766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204794822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211204794822 : Closed e1211204794822 ∧ code e1211204794822 = 5609251305926 := by decide
theorem cert_e1211204794822 : check e1211204794822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204902510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204902510 : Closed e1211204902510 ∧ code e1211204902510 = 5609251413614 := by decide
theorem cert_e1211204902510 : check e1211204902510 [[],[]] .chain = true := by decide
def e1211204902522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204902522 : Closed e1211204902522 ∧ code e1211204902522 = 5609251413626 := by decide
theorem cert_e1211204902522 : check e1211204902522 [[],[]] .chain = true := by decide
def e1211204902810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204902810 : Closed e1211204902810 ∧ code e1211204902810 = 5609251413914 := by decide
theorem cert_e1211204902810 : check e1211204902810 [[],[]] .chain = true := by decide
def e1211204906426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e1211204906426 : Closed e1211204906426 ∧ code e1211204906426 = 5609251417530 := by decide
theorem cert_e1211204906426 : check e1211204906426 [[],[]] .smaller = true := by decide
def e1211204906458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e1211204906458 : Closed e1211204906458 ∧ code e1211204906458 = 5609251417562 := by decide
theorem cert_e1211204906458 : check e1211204906458 [[],[]] .smaller = true := by decide
def e1211204906682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e1211204906682 : Closed e1211204906682 ∧ code e1211204906682 = 5609251417786 := by decide
theorem cert_e1211204906682 : check e1211204906682 [[],[]] .smaller = true := by decide
def e1211204906730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e1211204906730 : Closed e1211204906730 ∧ code e1211204906730 = 5609251417834 := by decide
theorem cert_e1211204906730 : check e1211204906730 [[],[]] .smaller = true := by decide
def e1211204906842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e1211204906842 : Closed e1211204906842 ∧ code e1211204906842 = 5609251417946 := by decide
theorem cert_e1211204906842 : check e1211204906842 [[],[]] .smaller = true := by decide
def e1211204906858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e1211204906858 : Closed e1211204906858 ∧ code e1211204906858 = 5609251417962 := by decide
theorem cert_e1211204906858 : check e1211204906858 [[],[]] .smaller = true := by decide
def e1211204907962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e1211204907962 : Closed e1211204907962 ∧ code e1211204907962 = 5609251419066 := by decide
theorem cert_e1211204907962 : check e1211204907962 [[],[]] .smaller = true := by decide
def e1211204907994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e1211204907994 : Closed e1211204907994 ∧ code e1211204907994 = 5609251419098 := by decide
theorem cert_e1211204907994 : check e1211204907994 [[],[]] .smaller = true := by decide
def e1211204909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e1211204909498 : Closed e1211204909498 ∧ code e1211204909498 = 5609251420602 := by decide
theorem cert_e1211204909498 : check e1211204909498 [[],[]] .smaller = true := by decide
def e1211204909546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e1211204909546 : Closed e1211204909546 ∧ code e1211204909546 = 5609251420650 := by decide
theorem cert_e1211204909546 : check e1211204909546 [[],[]] .smaller = true := by decide
def e1211204910298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e1211204910298 : Closed e1211204910298 ∧ code e1211204910298 = 5609251421402 := by decide
theorem cert_e1211204910298 : check e1211204910298 [[],[]] .smaller = true := by decide
def e1211204910314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e1211204910314 : Closed e1211204910314 ∧ code e1211204910314 = 5609251421418 := by decide
theorem cert_e1211204910314 : check e1211204910314 [[],[]] .smaller = true := by decide
def e1211204910574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 2))))))
theorem wire_e1211204910574 : Closed e1211204910574 ∧ code e1211204910574 = 5609251421678 := by decide
theorem cert_e1211204910574 : check e1211204910574 [[],[]] .chain = true := by decide
def e1211204910582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))) (.var 1))))))
theorem wire_e1211204910582 : Closed e1211204910582 ∧ code e1211204910582 = 5609251421686 := by decide
theorem cert_e1211204910582 : check e1211204910582 [[],[]] .chain = true := by decide
def e1211204910830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 2))))))
theorem wire_e1211204910830 : Closed e1211204910830 ∧ code e1211204910830 = 5609251421934 := by decide
theorem cert_e1211204910830 : check e1211204910830 [[],[]] .chain = true := by decide
def e1211204910842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 4))))) (.var 0))))))
theorem wire_e1211204910842 : Closed e1211204910842 ∧ code e1211204910842 = 5609251421946 := by decide
theorem cert_e1211204910842 : check e1211204910842 [[],[]] .chain = true := by decide
def e1211204910966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))) (.var 1))))))
theorem wire_e1211204910966 : Closed e1211204910966 ∧ code e1211204910966 = 5609251422070 := by decide
theorem cert_e1211204910966 : check e1211204910966 [[],[]] .chain = true := by decide
def e1211204910970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 3))))) (.var 0))))))
theorem wire_e1211204910970 : Closed e1211204910970 ∧ code e1211204910970 = 5609251422074 := by decide
theorem cert_e1211204910970 : check e1211204910970 [[],[]] .chain = true := by decide
def e1211204914030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211204914030 : Closed e1211204914030 ∧ code e1211204914030 = 5609251425134 := by decide
theorem cert_e1211204914030 : check e1211204914030 [[],[]] .chain = true := by decide
def e1211204914038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211204914038 : Closed e1211204914038 ∧ code e1211204914038 = 5609251425142 := by decide
theorem cert_e1211204914038 : check e1211204914038 [[],[]] .chain = true := by decide
def e1211204914094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211204914094 : Closed e1211204914094 ∧ code e1211204914094 = 5609251425198 := by decide
theorem cert_e1211204914094 : check e1211204914094 [[],[]] .chain = true := by decide
def e1211204914106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211204914106 : Closed e1211204914106 ∧ code e1211204914106 = 5609251425210 := by decide
theorem cert_e1211204914106 : check e1211204914106 [[],[]] .chain = true := by decide
def e1211204914134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211204914134 : Closed e1211204914134 ∧ code e1211204914134 = 5609251425238 := by decide
theorem cert_e1211204914134 : check e1211204914134 [[],[]] .chain = true := by decide
def e1211204914138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211204914138 : Closed e1211204914138 ∧ code e1211204914138 = 5609251425242 := by decide
theorem cert_e1211204914138 : check e1211204914138 [[],[]] .chain = true := by decide
def e1211204914414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204914414 : Closed e1211204914414 ∧ code e1211204914414 = 5609251425518 := by decide
theorem cert_e1211204914414 : check e1211204914414 [[],[]] .chain = true := by decide
def e1211204914422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204914422 : Closed e1211204914422 ∧ code e1211204914422 = 5609251425526 := by decide
theorem cert_e1211204914422 : check e1211204914422 [[],[]] .chain = true := by decide
def e1211204914798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204914798 : Closed e1211204914798 ∧ code e1211204914798 = 5609251425902 := by decide
theorem cert_e1211204914798 : check e1211204914798 [[],[]] .chain = true := by decide
def e1211204914810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204914810 : Closed e1211204914810 ∧ code e1211204914810 = 5609251425914 := by decide
theorem cert_e1211204914810 : check e1211204914810 [[],[]] .chain = true := by decide
def e1211204914998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204914998 : Closed e1211204914998 ∧ code e1211204914998 = 5609251426102 := by decide
theorem cert_e1211204914998 : check e1211204914998 [[],[]] .chain = true := by decide
def e1211204915002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204915002 : Closed e1211204915002 ∧ code e1211204915002 = 5609251426106 := by decide
theorem cert_e1211204915002 : check e1211204915002 [[],[]] .chain = true := by decide
def e1211204920750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211204920750 : Closed e1211204920750 ∧ code e1211204920750 = 5609251431854 := by decide
theorem cert_e1211204920750 : check e1211204920750 [[],[]] .chain = true := by decide
def e1211204920762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211204920762 : Closed e1211204920762 ∧ code e1211204920762 = 5609251431866 := by decide
theorem cert_e1211204920762 : check e1211204920762 [[],[]] .chain = true := by decide
def e1211204920810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211204920810 : Closed e1211204920810 ∧ code e1211204920810 = 5609251431914 := by decide
theorem cert_e1211204920810 : check e1211204920810 [[],[]] .chain = true := by decide
def e1211204920942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204920942 : Closed e1211204920942 ∧ code e1211204920942 = 5609251432046 := by decide
theorem cert_e1211204920942 : check e1211204920942 [[],[]] .chain = true := by decide
def e1211204920954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204920954 : Closed e1211204920954 ∧ code e1211204920954 = 5609251432058 := by decide
theorem cert_e1211204920954 : check e1211204920954 [[],[]] .chain = true := by decide
def e1211204921242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204921242 : Closed e1211204921242 ∧ code e1211204921242 = 5609251432346 := by decide
theorem cert_e1211204921242 : check e1211204921242 [[],[]] .chain = true := by decide
def e1211204924190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211204924190 : Closed e1211204924190 ∧ code e1211204924190 = 5609251435294 := by decide
theorem cert_e1211204924190 : check e1211204924190 [[],[]] .chain = true := by decide
def e1211204924358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211204924358 : Closed e1211204924358 ∧ code e1211204924358 = 5609251435462 := by decide
theorem cert_e1211204924358 : check e1211204924358 [[],[]] .chain = true := by decide
def e1211204926662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211204926662 : Closed e1211204926662 ∧ code e1211204926662 = 5609251437766 := by decide
theorem cert_e1211204926662 : check e1211204926662 [[],[]] .chain = true := by decide
def e1211204941538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211204941538 : Closed e1211204941538 ∧ code e1211204941538 = 5609251452642 := by decide
theorem cert_e1211204941538 : check e1211204941538 [[],[]] .smaller = true := by decide
def e1211204941550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e1211204941550 : Closed e1211204941550 ∧ code e1211204941550 = 5609251452654 := by decide
theorem cert_e1211204941550 : check e1211204941550 [[],[]] .chain = true := by decide
def e1211204941558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 1))))))
theorem wire_e1211204941558 : Closed e1211204941558 ∧ code e1211204941558 = 5609251452662 := by decide
theorem cert_e1211204941558 : check e1211204941558 [[],[]] .chain = true := by decide
def e1211204941666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211204941666 : Closed e1211204941666 ∧ code e1211204941666 = 5609251452770 := by decide
theorem cert_e1211204941666 : check e1211204941666 [[],[]] .smaller = true := by decide
def e1211204941678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e1211204941678 : Closed e1211204941678 ∧ code e1211204941678 = 5609251452782 := by decide
theorem cert_e1211204941678 : check e1211204941678 [[],[]] .chain = true := by decide
def e1211204941690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))) (.var 0))))))
theorem wire_e1211204941690 : Closed e1211204941690 ∧ code e1211204941690 = 5609251452794 := by decide
theorem cert_e1211204941690 : check e1211204941690 [[],[]] .chain = true := by decide
def e1211204941750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 1))))))
theorem wire_e1211204941750 : Closed e1211204941750 ∧ code e1211204941750 = 5609251452854 := by decide
theorem cert_e1211204941750 : check e1211204941750 [[],[]] .chain = true := by decide
def e1211204941754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))) (.var 0))))))
theorem wire_e1211204941754 : Closed e1211204941754 ∧ code e1211204941754 = 5609251452858 := by decide
theorem cert_e1211204941754 : check e1211204941754 [[],[]] .chain = true := by decide
def e1211204942562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211204942562 : Closed e1211204942562 ∧ code e1211204942562 = 5609251453666 := by decide
theorem cert_e1211204942562 : check e1211204942562 [[],[]] .smaller = true := by decide
def e1211204942574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e1211204942574 : Closed e1211204942574 ∧ code e1211204942574 = 5609251453678 := by decide
theorem cert_e1211204942574 : check e1211204942574 [[],[]] .chain = true := by decide
def e1211204942582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e1211204942582 : Closed e1211204942582 ∧ code e1211204942582 = 5609251453686 := by decide
theorem cert_e1211204942582 : check e1211204942582 [[],[]] .chain = true := by decide
def e1211204942702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e1211204942702 : Closed e1211204942702 ∧ code e1211204942702 = 5609251453806 := by decide
theorem cert_e1211204942702 : check e1211204942702 [[],[]] .chain = true := by decide
def e1211204942714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e1211204942714 : Closed e1211204942714 ∧ code e1211204942714 = 5609251453818 := by decide
theorem cert_e1211204942714 : check e1211204942714 [[],[]] .chain = true := by decide
def e1211204942754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1211204942754 : Closed e1211204942754 ∧ code e1211204942754 = 5609251453858 := by decide
theorem cert_e1211204942754 : check e1211204942754 [[],[]] .smaller = true := by decide
def e1211204942766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e1211204942766 : Closed e1211204942766 ∧ code e1211204942766 = 5609251453870 := by decide
theorem cert_e1211204942766 : check e1211204942766 [[],[]] .chain = true := by decide
def e1211204942806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e1211204942806 : Closed e1211204942806 ∧ code e1211204942806 = 5609251453910 := by decide
theorem cert_e1211204942806 : check e1211204942806 [[],[]] .chain = true := by decide
def e1211204942810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e1211204942810 : Closed e1211204942810 ∧ code e1211204942810 = 5609251453914 := by decide
theorem cert_e1211204942810 : check e1211204942810 [[],[]] .chain = true := by decide
def e1211204943202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211204943202 : Closed e1211204943202 ∧ code e1211204943202 = 5609251454306 := by decide
theorem cert_e1211204943202 : check e1211204943202 [[],[]] .smaller = true := by decide
def e1211204943214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e1211204943214 : Closed e1211204943214 ∧ code e1211204943214 = 5609251454318 := by decide
theorem cert_e1211204943214 : check e1211204943214 [[],[]] .chain = true := by decide
def e1211204943226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e1211204943226 : Closed e1211204943226 ∧ code e1211204943226 = 5609251454330 := by decide
theorem cert_e1211204943226 : check e1211204943226 [[],[]] .chain = true := by decide
def e1211204943266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1211204943266 : Closed e1211204943266 ∧ code e1211204943266 = 5609251454370 := by decide
theorem cert_e1211204943266 : check e1211204943266 [[],[]] .smaller = true := by decide
def e1211204943278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e1211204943278 : Closed e1211204943278 ∧ code e1211204943278 = 5609251454382 := by decide
theorem cert_e1211204943278 : check e1211204943278 [[],[]] .chain = true := by decide
def e1211204943338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e1211204943338 : Closed e1211204943338 ∧ code e1211204943338 = 5609251454442 := by decide
theorem cert_e1211204943338 : check e1211204943338 [[],[]] .chain = true := by decide
def e1211204943542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211204943542 : Closed e1211204943542 ∧ code e1211204943542 = 5609251454646 := by decide
theorem cert_e1211204943542 : check e1211204943542 [[],[]] .chain = true := by decide
def e1211204943546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211204943546 : Closed e1211204943546 ∧ code e1211204943546 = 5609251454650 := by decide
theorem cert_e1211204943546 : check e1211204943546 [[],[]] .chain = true := by decide
def e1211204943574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211204943574 : Closed e1211204943574 ∧ code e1211204943574 = 5609251454678 := by decide
theorem cert_e1211204943574 : check e1211204943574 [[],[]] .chain = true := by decide
def e1211204943578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e1211204943578 : Closed e1211204943578 ∧ code e1211204943578 = 5609251454682 := by decide
theorem cert_e1211204943578 : check e1211204943578 [[],[]] .chain = true := by decide
def e1211204943594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211204943594 : Closed e1211204943594 ∧ code e1211204943594 = 5609251454698 := by decide
theorem cert_e1211204943594 : check e1211204943594 [[],[]] .chain = true := by decide
def e1211204945518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204945518 : Closed e1211204945518 ∧ code e1211204945518 = 5609251456622 := by decide
theorem cert_e1211204945518 : checkPay e1211204945518 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204945530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204945530 : Closed e1211204945530 ∧ code e1211204945530 = 5609251456634 := by decide
theorem cert_e1211204945530 : checkPay e1211204945530 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204947682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e1211204947682 : Closed e1211204947682 ∧ code e1211204947682 = 5609251458786 := by decide
theorem cert_e1211204947682 : check e1211204947682 [[],[]] .smaller = true := by decide
def e1211204947694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e1211204947694 : Closed e1211204947694 ∧ code e1211204947694 = 5609251458798 := by decide
theorem cert_e1211204947694 : check e1211204947694 [[],[]] .chain = true := by decide
def e1211204947702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e1211204947702 : Closed e1211204947702 ∧ code e1211204947702 = 5609251458806 := by decide
theorem cert_e1211204947702 : check e1211204947702 [[],[]] .chain = true := by decide
def e1211204947810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211204947810 : Closed e1211204947810 ∧ code e1211204947810 = 5609251458914 := by decide
theorem cert_e1211204947810 : check e1211204947810 [[],[]] .smaller = true := by decide
def e1211204947822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e1211204947822 : Closed e1211204947822 ∧ code e1211204947822 = 5609251458926 := by decide
theorem cert_e1211204947822 : check e1211204947822 [[],[]] .chain = true := by decide
def e1211204947834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e1211204947834 : Closed e1211204947834 ∧ code e1211204947834 = 5609251458938 := by decide
theorem cert_e1211204947834 : check e1211204947834 [[],[]] .chain = true := by decide
def e1211204947894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e1211204947894 : Closed e1211204947894 ∧ code e1211204947894 = 5609251458998 := by decide
theorem cert_e1211204947894 : check e1211204947894 [[],[]] .chain = true := by decide
def e1211204947898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e1211204947898 : Closed e1211204947898 ∧ code e1211204947898 = 5609251459002 := by decide
theorem cert_e1211204947898 : check e1211204947898 [[],[]] .chain = true := by decide
def e1211204948766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211204948766 : Closed e1211204948766 ∧ code e1211204948766 = 5609251459870 := by decide
theorem cert_e1211204948766 : checkPay e1211204948766 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204948934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211204948934 : Closed e1211204948934 ∧ code e1211204948934 = 5609251460038 := by decide
theorem cert_e1211204948934 : checkPay e1211204948934 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204950510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211204950510 : Closed e1211204950510 ∧ code e1211204950510 = 5609251461614 := by decide
theorem cert_e1211204950510 : checkPay e1211204950510 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204951662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204951662 : Closed e1211204951662 ∧ code e1211204951662 = 5609251462766 := by decide
theorem cert_e1211204951662 : checkPay e1211204951662 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204951674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204951674 : Closed e1211204951674 ∧ code e1211204951674 = 5609251462778 := by decide
theorem cert_e1211204951674 : checkPay e1211204951674 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204952494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e1211204952494 : Closed e1211204952494 ∧ code e1211204952494 = 5609251463598 := by decide
theorem cert_e1211204952494 : checkPay e1211204952494 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left],[.under,.left],[.under]] = true := by decide
def e1211204952686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204952686 : Closed e1211204952686 ∧ code e1211204952686 = 5609251463790 := by decide
theorem cert_e1211204952686 : check e1211204952686 [[],[]] .chain = true := by decide
def e1211204952698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204952698 : Closed e1211204952698 ∧ code e1211204952698 = 5609251463802 := by decide
theorem cert_e1211204952698 : check e1211204952698 [[],[]] .chain = true := by decide
def e1211204953070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 2))))))
theorem wire_e1211204953070 : Closed e1211204953070 ∧ code e1211204953070 = 5609251464174 := by decide
theorem cert_e1211204953070 : checkPay e1211204953070 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left],[.under]] = true := by decide
def e1211204953826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e1211204953826 : Closed e1211204953826 ∧ code e1211204953826 = 5609251464930 := by decide
theorem cert_e1211204953826 : check e1211204953826 [[],[]] .smaller = true := by decide
def e1211204953838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e1211204953838 : Closed e1211204953838 ∧ code e1211204953838 = 5609251464942 := by decide
theorem cert_e1211204953838 : check e1211204953838 [[],[]] .chain = true := by decide
def e1211204953846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e1211204953846 : Closed e1211204953846 ∧ code e1211204953846 = 5609251464950 := by decide
theorem cert_e1211204953846 : check e1211204953846 [[],[]] .chain = true := by decide
def e1211204953966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e1211204953966 : Closed e1211204953966 ∧ code e1211204953966 = 5609251465070 := by decide
theorem cert_e1211204953966 : check e1211204953966 [[],[]] .chain = true := by decide
def e1211204953978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e1211204953978 : Closed e1211204953978 ∧ code e1211204953978 = 5609251465082 := by decide
theorem cert_e1211204953978 : check e1211204953978 [[],[]] .chain = true := by decide
def e1211204954018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e1211204954018 : Closed e1211204954018 ∧ code e1211204954018 = 5609251465122 := by decide
theorem cert_e1211204954018 : check e1211204954018 [[],[]] .smaller = true := by decide
def e1211204954030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e1211204954030 : Closed e1211204954030 ∧ code e1211204954030 = 5609251465134 := by decide
theorem cert_e1211204954030 : check e1211204954030 [[],[]] .chain = true := by decide
def e1211204954070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e1211204954070 : Closed e1211204954070 ∧ code e1211204954070 = 5609251465174 := by decide
theorem cert_e1211204954070 : check e1211204954070 [[],[]] .chain = true := by decide
def e1211204954074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e1211204954074 : Closed e1211204954074 ∧ code e1211204954074 = 5609251465178 := by decide
theorem cert_e1211204954074 : check e1211204954074 [[],[]] .chain = true := by decide
def e1211204954606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211204954606 : Closed e1211204954606 ∧ code e1211204954606 = 5609251465710 := by decide
theorem cert_e1211204954606 : checkPay e1211204954606 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211204955374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204955374 : Closed e1211204955374 ∧ code e1211204955374 = 5609251466478 := by decide
theorem cert_e1211204955374 : check e1211204955374 [[],[]] .chain = true := by decide
def e1211204955382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204955382 : Closed e1211204955382 ∧ code e1211204955382 = 5609251466486 := by decide
theorem cert_e1211204955382 : check e1211204955382 [[],[]] .chain = true := by decide
def e1211204955758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204955758 : Closed e1211204955758 ∧ code e1211204955758 = 5609251466862 := by decide
theorem cert_e1211204955758 : check e1211204955758 [[],[]] .chain = true := by decide
def e1211204955770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204955770 : Closed e1211204955770 ∧ code e1211204955770 = 5609251466874 := by decide
theorem cert_e1211204955770 : check e1211204955770 [[],[]] .chain = true := by decide
def e1211204955934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 3)))))))
theorem wire_e1211204955934 : Closed e1211204955934 ∧ code e1211204955934 = 5609251467038 := by decide
theorem cert_e1211204955934 : checkPay e1211204955934 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e1211204955958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204955958 : Closed e1211204955958 ∧ code e1211204955958 = 5609251467062 := by decide
theorem cert_e1211204955958 : check e1211204955958 [[],[]] .chain = true := by decide
def e1211204955962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204955962 : Closed e1211204955962 ∧ code e1211204955962 = 5609251467066 := by decide
theorem cert_e1211204955962 : check e1211204955962 [[],[]] .chain = true := by decide
def e1211204957026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211204957026 : Closed e1211204957026 ∧ code e1211204957026 = 5609251468130 := by decide
theorem cert_e1211204957026 : check e1211204957026 [[],[]] .smaller = true := by decide
def e1211204957038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211204957038 : Closed e1211204957038 ∧ code e1211204957038 = 5609251468142 := by decide
theorem cert_e1211204957038 : check e1211204957038 [[],[]] .chain = true := by decide
def e1211204957050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e1211204957050 : Closed e1211204957050 ∧ code e1211204957050 = 5609251468154 := by decide
theorem cert_e1211204957050 : check e1211204957050 [[],[]] .chain = true := by decide
def e1211204957090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e1211204957090 : Closed e1211204957090 ∧ code e1211204957090 = 5609251468194 := by decide
theorem cert_e1211204957090 : check e1211204957090 [[],[]] .smaller = true := by decide
def e1211204957102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211204957102 : Closed e1211204957102 ∧ code e1211204957102 = 5609251468206 := by decide
theorem cert_e1211204957102 : check e1211204957102 [[],[]] .chain = true := by decide
def e1211204957162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e1211204957162 : Closed e1211204957162 ∧ code e1211204957162 = 5609251468266 := by decide
theorem cert_e1211204957162 : check e1211204957162 [[],[]] .chain = true := by decide
def e1211204957806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204957806 : Closed e1211204957806 ∧ code e1211204957806 = 5609251468910 := by decide
theorem cert_e1211204957806 : check e1211204957806 [[],[]] .chain = true := by decide
def e1211204957818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204957818 : Closed e1211204957818 ∧ code e1211204957818 = 5609251468922 := by decide
theorem cert_e1211204957818 : check e1211204957818 [[],[]] .chain = true := by decide
def e1211204958106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204958106 : Closed e1211204958106 ∧ code e1211204958106 = 5609251469210 := by decide
theorem cert_e1211204958106 : check e1211204958106 [[],[]] .chain = true := by decide
def e1211204958314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e1211204958314 : Closed e1211204958314 ∧ code e1211204958314 = 5609251469418 := by decide
theorem cert_e1211204958314 : checkPay e1211204958314 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211204958362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204958362 : Closed e1211204958362 ∧ code e1211204958362 = 5609251469466 := by decide
theorem cert_e1211204958362 : check e1211204958362 [[],[]] .chain = true := by decide
def e1211204958446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211204958446 : Closed e1211204958446 ∧ code e1211204958446 = 5609251469550 := by decide
theorem cert_e1211204958446 : checkPay e1211204958446 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.under,.under,.left,.right,.under]] = true := by decide
def e1211204958458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 4))))) (.var 0))))))
theorem wire_e1211204958458 : Closed e1211204958458 ∧ code e1211204958458 = 5609251469562 := by decide
theorem cert_e1211204958458 : checkPay e1211204958458 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.under,.under,.left,.right,.under]] = true := by decide
def e1211204958646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211204958646 : Closed e1211204958646 ∧ code e1211204958646 = 5609251469750 := by decide
theorem cert_e1211204958646 : check e1211204958646 [[],[]] .chain = true := by decide
def e1211204958650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211204958650 : Closed e1211204958650 ∧ code e1211204958650 = 5609251469754 := by decide
theorem cert_e1211204958650 : check e1211204958650 [[],[]] .chain = true := by decide
def e1211204958678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211204958678 : Closed e1211204958678 ∧ code e1211204958678 = 5609251469782 := by decide
theorem cert_e1211204958678 : check e1211204958678 [[],[]] .chain = true := by decide
def e1211204958682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e1211204958682 : Closed e1211204958682 ∧ code e1211204958682 = 5609251469786 := by decide
theorem cert_e1211204958682 : check e1211204958682 [[],[]] .chain = true := by decide
def e1211204958698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211204958698 : Closed e1211204958698 ∧ code e1211204958698 = 5609251469802 := by decide
theorem cert_e1211204958698 : check e1211204958698 [[],[]] .chain = true := by decide
def e1211204958830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204958830 : Closed e1211204958830 ∧ code e1211204958830 = 5609251469934 := by decide
theorem cert_e1211204958830 : checkPay e1211204958830 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211204958842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204958842 : Closed e1211204958842 ∧ code e1211204958842 = 5609251469946 := by decide
theorem cert_e1211204958842 : checkPay e1211204958842 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211204959006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211204959006 : Closed e1211204959006 ∧ code e1211204959006 = 5609251470110 := by decide
theorem cert_e1211204959006 : checkPay e1211204959006 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.under,.under,.left,.right,.under]] = true := by decide
def e1211204959030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204959030 : Closed e1211204959030 ∧ code e1211204959030 = 5609251470134 := by decide
theorem cert_e1211204959030 : check e1211204959030 [[],[]] .chain = true := by decide
def e1211204959034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204959034 : Closed e1211204959034 ∧ code e1211204959034 = 5609251470138 := by decide
theorem cert_e1211204959034 : check e1211204959034 [[],[]] .chain = true := by decide
def e1211204959130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204959130 : Closed e1211204959130 ∧ code e1211204959130 = 5609251470234 := by decide
theorem cert_e1211204959130 : check e1211204959130 [[],[]] .chain = true := by decide
def e1211204959174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1211204959174 : Closed e1211204959174 ∧ code e1211204959174 = 5609251470278 := by decide
theorem cert_e1211204959174 : checkPay e1211204959174 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211204963182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211204963182 : Closed e1211204963182 ∧ code e1211204963182 = 5609251474286 := by decide
theorem cert_e1211204963182 : check e1211204963182 [[],[]] .smaller = true := by decide
def e1211204963190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211204963190 : Closed e1211204963190 ∧ code e1211204963190 = 5609251474294 := by decide
theorem cert_e1211204963190 : check e1211204963190 [[],[]] .smaller = true := by decide
def e1211204963246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211204963246 : Closed e1211204963246 ∧ code e1211204963246 = 5609251474350 := by decide
theorem cert_e1211204963246 : check e1211204963246 [[],[]] .smaller = true := by decide
def e1211204963258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211204963258 : Closed e1211204963258 ∧ code e1211204963258 = 5609251474362 := by decide
theorem cert_e1211204963258 : check e1211204963258 [[],[]] .smaller = true := by decide
def e1211204963286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211204963286 : Closed e1211204963286 ∧ code e1211204963286 = 5609251474390 := by decide
theorem cert_e1211204963286 : check e1211204963286 [[],[]] .smaller = true := by decide
end Blc.Floor42
