import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203943894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211203943894 : Closed e1211203943894 ∧ code e1211203943894 = 5609250454998 := by decide
theorem cert_e1211203943894 : check e1211203943894 [[],[]] .chain = true := by decide
def e1211203943898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211203943898 : Closed e1211203943898 ∧ code e1211203943898 = 5609250455002 := by decide
theorem cert_e1211203943898 : check e1211203943898 [[],[]] .chain = true := by decide
def e1211203947758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203947758 : Closed e1211203947758 ∧ code e1211203947758 = 5609250458862 := by decide
theorem cert_e1211203947758 : check e1211203947758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203947766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203947766 : Closed e1211203947766 ∧ code e1211203947766 = 5609250458870 := by decide
theorem cert_e1211203947766 : check e1211203947766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203951738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 0))))))
theorem wire_e1211203951738 : Closed e1211203951738 ∧ code e1211203951738 = 5609250462842 := by decide
theorem cert_e1211203951738 : check e1211203951738 [[],[]] .smaller = true := by decide
def e1211203952070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 1)))))))
theorem wire_e1211203952070 : Closed e1211203952070 ∧ code e1211203952070 = 5609250463174 := by decide
theorem cert_e1211203952070 : check e1211203952070 [[],[]] .smaller = true := by decide
def e1211203952098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.lam (.var 0)))))))
theorem wire_e1211203952098 : Closed e1211203952098 ∧ code e1211203952098 = 5609250463202 := by decide
theorem cert_e1211203952098 : check e1211203952098 [[],[]] .chain = true := by decide
def e1211203952110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 2))))))
theorem wire_e1211203952110 : Closed e1211203952110 ∧ code e1211203952110 = 5609250463214 := by decide
theorem cert_e1211203952110 : check e1211203952110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203952186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 0))))))
theorem wire_e1211203952186 : Closed e1211203952186 ∧ code e1211203952186 = 5609250463290 := by decide
theorem cert_e1211203952186 : check e1211203952186 [[],[]] .smaller = true := by decide
def e1211203952326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 1)))))))
theorem wire_e1211203952326 : Closed e1211203952326 ∧ code e1211203952326 = 5609250463430 := by decide
theorem cert_e1211203952326 : check e1211203952326 [[],[]] .smaller = true := by decide
def e1211203952366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 2))))) (.var 2))))))
theorem wire_e1211203952366 : Closed e1211203952366 ∧ code e1211203952366 = 5609250463470 := by decide
theorem cert_e1211203952366 : check e1211203952366 [[],[]] .chain = true := by decide
def e1211203952374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))) (.var 1))))))
theorem wire_e1211203952374 : Closed e1211203952374 ∧ code e1211203952374 = 5609250463478 := by decide
theorem cert_e1211203952374 : check e1211203952374 [[],[]] .chain = true := by decide
def e1211203952482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211203952482 : Closed e1211203952482 ∧ code e1211203952482 = 5609250463586 := by decide
theorem cert_e1211203952482 : check e1211203952482 [[],[]] .chain = true := by decide
def e1211203952494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 2))))))
theorem wire_e1211203952494 : Closed e1211203952494 ∧ code e1211203952494 = 5609250463598 := by decide
theorem cert_e1211203952494 : check e1211203952494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211203952502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))) (.var 1))))))
theorem wire_e1211203952502 : Closed e1211203952502 ∧ code e1211203952502 = 5609250463606 := by decide
theorem cert_e1211203952502 : check e1211203952502 [[],[]] .chain = true := by decide
def e1211203954462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203954462 : Closed e1211203954462 ∧ code e1211203954462 = 5609250465566 := by decide
theorem cert_e1211203954462 : check e1211203954462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203954574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203954574 : Closed e1211203954574 ∧ code e1211203954574 = 5609250465678 := by decide
theorem cert_e1211203954574 : check e1211203954574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1211203959278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203959278 : Closed e1211203959278 ∧ code e1211203959278 = 5609250470382 := by decide
theorem cert_e1211203959278 : check e1211203959278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203960046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203960046 : Closed e1211203960046 ∧ code e1211203960046 = 5609250471150 := by decide
theorem cert_e1211203960046 : check e1211203960046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203960054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203960054 : Closed e1211203960054 ∧ code e1211203960054 = 5609250471158 := by decide
theorem cert_e1211203960054 : check e1211203960054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203962094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203962094 : Closed e1211203962094 ∧ code e1211203962094 = 5609250473198 := by decide
theorem cert_e1211203962094 : check e1211203962094 [[],[]] .chain = true := by decide
def e1211203962102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203962102 : Closed e1211203962102 ∧ code e1211203962102 = 5609250473206 := by decide
theorem cert_e1211203962102 : check e1211203962102 [[],[]] .chain = true := by decide
def e1211203964026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 0))))))
theorem wire_e1211203964026 : Closed e1211203964026 ∧ code e1211203964026 = 5609250475130 := by decide
theorem cert_e1211203964026 : check e1211203964026 [[],[]] .smaller = true := by decide
def e1211203964358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 1)))))))
theorem wire_e1211203964358 : Closed e1211203964358 ∧ code e1211203964358 = 5609250475462 := by decide
theorem cert_e1211203964358 : check e1211203964358 [[],[]] .smaller = true := by decide
def e1211203964386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.lam (.var 0)))))))
theorem wire_e1211203964386 : Closed e1211203964386 ∧ code e1211203964386 = 5609250475490 := by decide
theorem cert_e1211203964386 : check e1211203964386 [[],[]] .chain = true := by decide
def e1211203964398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 2))))))
theorem wire_e1211203964398 : Closed e1211203964398 ∧ code e1211203964398 = 5609250475502 := by decide
theorem cert_e1211203964398 : check e1211203964398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203964654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e1211203964654 : Closed e1211203964654 ∧ code e1211203964654 = 5609250475758 := by decide
theorem cert_e1211203964654 : check e1211203964654 [[],[]] .chain = true := by decide
def e1211203964662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e1211203964662 : Closed e1211203964662 ∧ code e1211203964662 = 5609250475766 := by decide
theorem cert_e1211203964662 : check e1211203964662 [[],[]] .chain = true := by decide
def e1211203964698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211203964698 : Closed e1211203964698 ∧ code e1211203964698 = 5609250475802 := by decide
theorem cert_e1211203964698 : check e1211203964698 [[],[]] .smaller = true := by decide
def e1211203964742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211203964742 : Closed e1211203964742 ∧ code e1211203964742 = 5609250475846 := by decide
theorem cert_e1211203964742 : check e1211203964742 [[],[]] .smaller = true := by decide
def e1211203964782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e1211203964782 : Closed e1211203964782 ∧ code e1211203964782 = 5609250475886 := by decide
theorem cert_e1211203964782 : check e1211203964782 [[],[]] .chain = true := by decide
def e1211203964794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e1211203964794 : Closed e1211203964794 ∧ code e1211203964794 = 5609250475898 := by decide
theorem cert_e1211203964794 : check e1211203964794 [[],[]] .chain = true := by decide
def e1211203964834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e1211203964834 : Closed e1211203964834 ∧ code e1211203964834 = 5609250475938 := by decide
theorem cert_e1211203964834 : check e1211203964834 [[],[]] .chain = true := by decide
def e1211203964846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 2))))))
theorem wire_e1211203964846 : Closed e1211203964846 ∧ code e1211203964846 = 5609250475950 := by decide
theorem cert_e1211203964846 : check e1211203964846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203964854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e1211203964854 : Closed e1211203964854 ∧ code e1211203964854 = 5609250475958 := by decide
theorem cert_e1211203964854 : check e1211203964854 [[],[]] .chain = true := by decide
def e1211203964858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e1211203964858 : Closed e1211203964858 ∧ code e1211203964858 = 5609250475962 := by decide
theorem cert_e1211203964858 : check e1211203964858 [[],[]] .chain = true := by decide
def e1211203968238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203968238 : Closed e1211203968238 ∧ code e1211203968238 = 5609250479342 := by decide
theorem cert_e1211203968238 : check e1211203968238 [[],[]] .chain = true := by decide
def e1211203968246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203968246 : Closed e1211203968246 ∧ code e1211203968246 = 5609250479350 := by decide
theorem cert_e1211203968246 : check e1211203968246 [[],[]] .chain = true := by decide
def e1211203968630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203968630 : Closed e1211203968630 ∧ code e1211203968630 = 5609250479734 := by decide
theorem cert_e1211203968630 : check e1211203968630 [[],[]] .chain = true := by decide
def e1211203969454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e1211203969454 : Closed e1211203969454 ∧ code e1211203969454 = 5609250480558 := by decide
theorem cert_e1211203969454 : check e1211203969454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1211203969646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203969646 : Closed e1211203969646 ∧ code e1211203969646 = 5609250480750 := by decide
theorem cert_e1211203969646 : check e1211203969646 [[],[]] .chain = true := by decide
def e1211203969658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203969658 : Closed e1211203969658 ∧ code e1211203969658 = 5609250480762 := by decide
theorem cert_e1211203969658 : check e1211203969658 [[],[]] .chain = true := by decide
def e1211203970030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 2))))))
theorem wire_e1211203970030 : Closed e1211203970030 ∧ code e1211203970030 = 5609250481134 := by decide
theorem cert_e1211203970030 : check e1211203970030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1211203970618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 0))))))
theorem wire_e1211203970618 : Closed e1211203970618 ∧ code e1211203970618 = 5609250481722 := by decide
theorem cert_e1211203970618 : check e1211203970618 [[],[]] .smaller = true := by decide
def e1211203970758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 1)))))))
theorem wire_e1211203970758 : Closed e1211203970758 ∧ code e1211203970758 = 5609250481862 := by decide
theorem cert_e1211203970758 : check e1211203970758 [[],[]] .smaller = true := by decide
def e1211203970798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e1211203970798 : Closed e1211203970798 ∧ code e1211203970798 = 5609250481902 := by decide
theorem cert_e1211203970798 : check e1211203970798 [[],[]] .chain = true := by decide
def e1211203970806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e1211203970806 : Closed e1211203970806 ∧ code e1211203970806 = 5609250481910 := by decide
theorem cert_e1211203970806 : check e1211203970806 [[],[]] .chain = true := by decide
def e1211203970842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211203970842 : Closed e1211203970842 ∧ code e1211203970842 = 5609250481946 := by decide
theorem cert_e1211203970842 : check e1211203970842 [[],[]] .smaller = true := by decide
def e1211203970886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211203970886 : Closed e1211203970886 ∧ code e1211203970886 = 5609250481990 := by decide
theorem cert_e1211203970886 : check e1211203970886 [[],[]] .smaller = true := by decide
def e1211203970926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e1211203970926 : Closed e1211203970926 ∧ code e1211203970926 = 5609250482030 := by decide
theorem cert_e1211203970926 : check e1211203970926 [[],[]] .chain = true := by decide
def e1211203970938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e1211203970938 : Closed e1211203970938 ∧ code e1211203970938 = 5609250482042 := by decide
theorem cert_e1211203970938 : check e1211203970938 [[],[]] .chain = true := by decide
def e1211203970990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e1211203970990 : Closed e1211203970990 ∧ code e1211203970990 = 5609250482094 := by decide
theorem cert_e1211203970990 : check e1211203970990 [[],[]] .chain = true := by decide
def e1211203971030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e1211203971030 : Closed e1211203971030 ∧ code e1211203971030 = 5609250482134 := by decide
theorem cert_e1211203971030 : check e1211203971030 [[],[]] .chain = true := by decide
def e1211203971034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e1211203971034 : Closed e1211203971034 ∧ code e1211203971034 = 5609250482138 := by decide
theorem cert_e1211203971034 : check e1211203971034 [[],[]] .chain = true := by decide
def e1211203971566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203971566 : Closed e1211203971566 ∧ code e1211203971566 = 5609250482670 := by decide
theorem cert_e1211203971566 : check e1211203971566 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1211203972334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203972334 : Closed e1211203972334 ∧ code e1211203972334 = 5609250483438 := by decide
theorem cert_e1211203972334 : check e1211203972334 [[],[]] .chain = true := by decide
def e1211203972342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203972342 : Closed e1211203972342 ∧ code e1211203972342 = 5609250483446 := by decide
theorem cert_e1211203972342 : check e1211203972342 [[],[]] .chain = true := by decide
def e1211203972718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203972718 : Closed e1211203972718 ∧ code e1211203972718 = 5609250483822 := by decide
theorem cert_e1211203972718 : check e1211203972718 [[],[]] .chain = true := by decide
def e1211203972730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203972730 : Closed e1211203972730 ∧ code e1211203972730 = 5609250483834 := by decide
theorem cert_e1211203972730 : check e1211203972730 [[],[]] .chain = true := by decide
def e1211203972894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 3)))))))
theorem wire_e1211203972894 : Closed e1211203972894 ∧ code e1211203972894 = 5609250483998 := by decide
theorem cert_e1211203972894 : check e1211203972894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1211203972918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203972918 : Closed e1211203972918 ∧ code e1211203972918 = 5609250484022 := by decide
theorem cert_e1211203972918 : check e1211203972918 [[],[]] .chain = true := by decide
def e1211203972922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203972922 : Closed e1211203972922 ∧ code e1211203972922 = 5609250484026 := by decide
theorem cert_e1211203972922 : check e1211203972922 [[],[]] .chain = true := by decide
def e1211203973334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e1211203973334 : Closed e1211203973334 ∧ code e1211203973334 = 5609250484438 := by decide
theorem cert_e1211203973334 : checkPay e1211203973334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211203973430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203973430 : Closed e1211203973430 ∧ code e1211203973430 = 5609250484534 := by decide
theorem cert_e1211203973430 : check e1211203973430 [[],[]] .chain = true := by decide
def e1211203973434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203973434 : Closed e1211203973434 ∧ code e1211203973434 = 5609250484538 := by decide
theorem cert_e1211203973434 : check e1211203973434 [[],[]] .chain = true := by decide
def e1211203973614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211203973614 : Closed e1211203973614 ∧ code e1211203973614 = 5609250484718 := by decide
theorem cert_e1211203973614 : check e1211203973614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203973622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 4))))) (.var 1))))))
theorem wire_e1211203973622 : Closed e1211203973622 ∧ code e1211203973622 = 5609250484726 := by decide
theorem cert_e1211203973622 : checkPay e1211203973622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1211203973986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211203973986 : Closed e1211203973986 ∧ code e1211203973986 = 5609250485090 := by decide
theorem cert_e1211203973986 : check e1211203973986 [[],[]] .chain = true := by decide
def e1211203973998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211203973998 : Closed e1211203973998 ∧ code e1211203973998 = 5609250485102 := by decide
theorem cert_e1211203973998 : check e1211203973998 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203974006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211203974006 : Closed e1211203974006 ∧ code e1211203974006 = 5609250485110 := by decide
theorem cert_e1211203974006 : check e1211203974006 [[],[]] .chain = true := by decide
def e1211203974050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e1211203974050 : Closed e1211203974050 ∧ code e1211203974050 = 5609250485154 := by decide
theorem cert_e1211203974050 : check e1211203974050 [[],[]] .chain = true := by decide
def e1211203974062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211203974062 : Closed e1211203974062 ∧ code e1211203974062 = 5609250485166 := by decide
theorem cert_e1211203974062 : check e1211203974062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203974070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e1211203974070 : Closed e1211203974070 ∧ code e1211203974070 = 5609250485174 := by decide
theorem cert_e1211203974070 : check e1211203974070 [[],[]] .chain = true := by decide
def e1211203974074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211203974074 : Closed e1211203974074 ∧ code e1211203974074 = 5609250485178 := by decide
theorem cert_e1211203974074 : check e1211203974074 [[],[]] .chain = true := by decide
def e1211203974102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211203974102 : Closed e1211203974102 ∧ code e1211203974102 = 5609250485206 := by decide
theorem cert_e1211203974102 : check e1211203974102 [[],[]] .chain = true := by decide
def e1211203974106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211203974106 : Closed e1211203974106 ∧ code e1211203974106 = 5609250485210 := by decide
theorem cert_e1211203974106 : check e1211203974106 [[],[]] .chain = true := by decide
def e1211203974382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203974382 : Closed e1211203974382 ∧ code e1211203974382 = 5609250485486 := by decide
theorem cert_e1211203974382 : check e1211203974382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203974390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203974390 : Closed e1211203974390 ∧ code e1211203974390 = 5609250485494 := by decide
theorem cert_e1211203974390 : check e1211203974390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203974774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203974774 : Closed e1211203974774 ∧ code e1211203974774 = 5609250485878 := by decide
theorem cert_e1211203974774 : check e1211203974774 [[],[]] .chain = true := by decide
def e1211203974942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211203974942 : Closed e1211203974942 ∧ code e1211203974942 = 5609250486046 := by decide
theorem cert_e1211203974942 : check e1211203974942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203974966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203974966 : Closed e1211203974966 ∧ code e1211203974966 = 5609250486070 := by decide
theorem cert_e1211203974966 : check e1211203974966 [[],[]] .chain = true := by decide
def e1211203974970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203974970 : Closed e1211203974970 ∧ code e1211203974970 = 5609250486074 := by decide
theorem cert_e1211203974970 : check e1211203974970 [[],[]] .chain = true := by decide
def e1211203975054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e1211203975054 : Closed e1211203975054 ∧ code e1211203975054 = 5609250486158 := by decide
theorem cert_e1211203975054 : check e1211203975054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203983070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211203983070 : Closed e1211203983070 ∧ code e1211203983070 = 5609250494174 := by decide
theorem cert_e1211203983070 : check e1211203983070 [[],[]] .chain = true := by decide
def e1211203983094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211203983094 : Closed e1211203983094 ∧ code e1211203983094 = 5609250494198 := by decide
theorem cert_e1211203983094 : check e1211203983094 [[],[]] .chain = true := by decide
def e1211203983198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211203983198 : Closed e1211203983198 ∧ code e1211203983198 = 5609250494302 := by decide
theorem cert_e1211203983198 : check e1211203983198 [[],[]] .chain = true := by decide
def e1211203983226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211203983226 : Closed e1211203983226 ∧ code e1211203983226 = 5609250494330 := by decide
theorem cert_e1211203983226 : check e1211203983226 [[],[]] .chain = true := by decide
def e1211203983318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211203983318 : Closed e1211203983318 ∧ code e1211203983318 = 5609250494422 := by decide
theorem cert_e1211203983318 : check e1211203983318 [[],[]] .chain = true := by decide
def e1211203983322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211203983322 : Closed e1211203983322 ∧ code e1211203983322 = 5609250494426 := by decide
theorem cert_e1211203983322 : check e1211203983322 [[],[]] .chain = true := by decide
def e1211203983838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211203983838 : Closed e1211203983838 ∧ code e1211203983838 = 5609250494942 := by decide
theorem cert_e1211203983838 : check e1211203983838 [[],[]] .chain = true := by decide
def e1211203983862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211203983862 : Closed e1211203983862 ∧ code e1211203983862 = 5609250494966 := by decide
theorem cert_e1211203983862 : check e1211203983862 [[],[]] .chain = true := by decide
def e1211203984606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211203984606 : Closed e1211203984606 ∧ code e1211203984606 = 5609250495710 := by decide
theorem cert_e1211203984606 : check e1211203984606 [[],[]] .chain = true := by decide
def e1211203984634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211203984634 : Closed e1211203984634 ∧ code e1211203984634 = 5609250495738 := by decide
theorem cert_e1211203984634 : check e1211203984634 [[],[]] .chain = true := by decide
def e1211203985206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211203985206 : Closed e1211203985206 ∧ code e1211203985206 = 5609250496310 := by decide
theorem cert_e1211203985206 : check e1211203985206 [[],[]] .chain = true := by decide
def e1211203985210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211203985210 : Closed e1211203985210 ∧ code e1211203985210 = 5609250496314 := by decide
theorem cert_e1211203985210 : check e1211203985210 [[],[]] .chain = true := by decide
def e1211203999982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211203999982 : Closed e1211203999982 ∧ code e1211203999982 = 5609250511086 := by decide
theorem cert_e1211203999982 : check e1211203999982 [[],[]] .chain = true := by decide
def e1211203999990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211203999990 : Closed e1211203999990 ∧ code e1211203999990 = 5609250511094 := by decide
theorem cert_e1211203999990 : check e1211203999990 [[],[]] .chain = true := by decide
def e1211204000542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211204000542 : Closed e1211204000542 ∧ code e1211204000542 = 5609250511646 := by decide
theorem cert_e1211204000542 : check e1211204000542 [[],[]] .chain = true := by decide
def e1211204000654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211204000654 : Closed e1211204000654 ∧ code e1211204000654 = 5609250511758 := by decide
theorem cert_e1211204000654 : check e1211204000654 [[],[]] .chain = true := by decide
def e1211204000878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211204000878 : Closed e1211204000878 ∧ code e1211204000878 = 5609250511982 := by decide
theorem cert_e1211204000878 : check e1211204000878 [[],[]] .chain = true := by decide
def e1211204000890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211204000890 : Closed e1211204000890 ∧ code e1211204000890 = 5609250511994 := by decide
theorem cert_e1211204000890 : check e1211204000890 [[],[]] .chain = true := by decide
def e1211204001054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211204001054 : Closed e1211204001054 ∧ code e1211204001054 = 5609250512158 := by decide
theorem cert_e1211204001054 : check e1211204001054 [[],[]] .chain = true := by decide
def e1211204001222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211204001222 : Closed e1211204001222 ∧ code e1211204001222 = 5609250512326 := by decide
theorem cert_e1211204001222 : check e1211204001222 [[],[]] .chain = true := by decide
def e1211204001334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211204001334 : Closed e1211204001334 ∧ code e1211204001334 = 5609250512438 := by decide
theorem cert_e1211204001334 : check e1211204001334 [[],[]] .chain = true := by decide
def e1211204001338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211204001338 : Closed e1211204001338 ∧ code e1211204001338 = 5609250512442 := by decide
theorem cert_e1211204001338 : check e1211204001338 [[],[]] .chain = true := by decide
def e1211204001422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211204001422 : Closed e1211204001422 ∧ code e1211204001422 = 5609250512526 := by decide
theorem cert_e1211204001422 : check e1211204001422 [[],[]] .chain = true := by decide
def e1211204001478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211204001478 : Closed e1211204001478 ∧ code e1211204001478 = 5609250512582 := by decide
theorem cert_e1211204001478 : check e1211204001478 [[],[]] .chain = true := by decide
def e1211204003614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211204003614 : Closed e1211204003614 ∧ code e1211204003614 = 5609250514718 := by decide
theorem cert_e1211204003614 : check e1211204003614 [[],[]] .chain = true := by decide
def e1211204003726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211204003726 : Closed e1211204003726 ∧ code e1211204003726 = 5609250514830 := by decide
theorem cert_e1211204003726 : check e1211204003726 [[],[]] .chain = true := by decide
def e1211204006686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211204006686 : Closed e1211204006686 ∧ code e1211204006686 = 5609250517790 := by decide
theorem cert_e1211204006686 : check e1211204006686 [[],[]] .chain = true := by decide
def e1211204006854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211204006854 : Closed e1211204006854 ∧ code e1211204006854 = 5609250517958 := by decide
theorem cert_e1211204006854 : check e1211204006854 [[],[]] .chain = true := by decide
def e1211204008334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211204008334 : Closed e1211204008334 ∧ code e1211204008334 = 5609250519438 := by decide
theorem cert_e1211204008334 : check e1211204008334 [[],[]] .chain = true := by decide
def e1211204008390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211204008390 : Closed e1211204008390 ∧ code e1211204008390 = 5609250519494 := by decide
theorem cert_e1211204008390 : check e1211204008390 [[],[]] .chain = true := by decide
def e1211204045678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211204045678 : Closed e1211204045678 ∧ code e1211204045678 = 5609250556782 := by decide
theorem cert_e1211204045678 : check e1211204045678 [[],[]] .smaller = true := by decide
def e1211204045686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211204045686 : Closed e1211204045686 ∧ code e1211204045686 = 5609250556790 := by decide
theorem cert_e1211204045686 : check e1211204045686 [[],[]] .smaller = true := by decide
def e1211204045742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211204045742 : Closed e1211204045742 ∧ code e1211204045742 = 5609250556846 := by decide
theorem cert_e1211204045742 : check e1211204045742 [[],[]] .smaller = true := by decide
def e1211204045754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211204045754 : Closed e1211204045754 ∧ code e1211204045754 = 5609250556858 := by decide
theorem cert_e1211204045754 : check e1211204045754 [[],[]] .smaller = true := by decide
def e1211204045782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211204045782 : Closed e1211204045782 ∧ code e1211204045782 = 5609250556886 := by decide
theorem cert_e1211204045782 : check e1211204045782 [[],[]] .smaller = true := by decide
def e1211204045786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211204045786 : Closed e1211204045786 ∧ code e1211204045786 = 5609250556890 := by decide
theorem cert_e1211204045786 : check e1211204045786 [[],[]] .smaller = true := by decide
def e1211204046062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204046062 : Closed e1211204046062 ∧ code e1211204046062 = 5609250557166 := by decide
theorem cert_e1211204046062 : check e1211204046062 [[],[]] .smaller = true := by decide
def e1211204046070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204046070 : Closed e1211204046070 ∧ code e1211204046070 = 5609250557174 := by decide
theorem cert_e1211204046070 : check e1211204046070 [[],[]] .smaller = true := by decide
def e1211204046446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204046446 : Closed e1211204046446 ∧ code e1211204046446 = 5609250557550 := by decide
theorem cert_e1211204046446 : check e1211204046446 [[],[]] .smaller = true := by decide
def e1211204046458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204046458 : Closed e1211204046458 ∧ code e1211204046458 = 5609250557562 := by decide
theorem cert_e1211204046458 : check e1211204046458 [[],[]] .smaller = true := by decide
def e1211204046646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204046646 : Closed e1211204046646 ∧ code e1211204046646 = 5609250557750 := by decide
theorem cert_e1211204046646 : check e1211204046646 [[],[]] .smaller = true := by decide
def e1211204046650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204046650 : Closed e1211204046650 ∧ code e1211204046650 = 5609250557754 := by decide
theorem cert_e1211204046650 : check e1211204046650 [[],[]] .smaller = true := by decide
def e1211204054574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211204054574 : Closed e1211204054574 ∧ code e1211204054574 = 5609250565678 := by decide
theorem cert_e1211204054574 : check e1211204054574 [[],[]] .chain = true := by decide
def e1211204054754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211204054754 : Closed e1211204054754 ∧ code e1211204054754 = 5609250565858 := by decide
theorem cert_e1211204054754 : check e1211204054754 [[],[]] .chain = true := by decide
def e1211204054766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1211204054766 : Closed e1211204054766 ∧ code e1211204054766 = 5609250565870 := by decide
theorem cert_e1211204054766 : check e1211204054766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204054806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211204054806 : Closed e1211204054806 ∧ code e1211204054806 = 5609250565910 := by decide
theorem cert_e1211204054806 : check e1211204054806 [[],[]] .chain = true := by decide
def e1211204054882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211204054882 : Closed e1211204054882 ∧ code e1211204054882 = 5609250565986 := by decide
theorem cert_e1211204054882 : check e1211204054882 [[],[]] .chain = true := by decide
def e1211204054894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1211204054894 : Closed e1211204054894 ∧ code e1211204054894 = 5609250565998 := by decide
theorem cert_e1211204054894 : check e1211204054894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204054902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1211204054902 : Closed e1211204054902 ∧ code e1211204054902 = 5609250566006 := by decide
theorem cert_e1211204054902 : check e1211204054902 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204057150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e1211204057150 : Closed e1211204057150 ∧ code e1211204057150 = 5609250568254 := by decide
theorem cert_e1211204057150 : check e1211204057150 [[],[]] .chain = true := by decide
def e1211204057570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211204057570 : Closed e1211204057570 ∧ code e1211204057570 = 5609250568674 := by decide
theorem cert_e1211204057570 : check e1211204057570 [[],[]] .chain = true := by decide
def e1211204057582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1211204057582 : Closed e1211204057582 ∧ code e1211204057582 = 5609250568686 := by decide
theorem cert_e1211204057582 : check e1211204057582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204058142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e1211204058142 : Closed e1211204058142 ∧ code e1211204058142 = 5609250569246 := by decide
theorem cert_e1211204058142 : check e1211204058142 [[],[]] .chain = true := by decide
def e1211204058338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211204058338 : Closed e1211204058338 ∧ code e1211204058338 = 5609250569442 := by decide
theorem cert_e1211204058338 : check e1211204058338 [[],[]] .chain = true := by decide
def e1211204058350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204058350 : Closed e1211204058350 ∧ code e1211204058350 = 5609250569454 := by decide
theorem cert_e1211204058350 : check e1211204058350 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204058358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204058358 : Closed e1211204058358 ∧ code e1211204058358 = 5609250569462 := by decide
theorem cert_e1211204058358 : check e1211204058358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204077534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e1211204077534 : Closed e1211204077534 ∧ code e1211204077534 = 5609250588638 := by decide
theorem cert_e1211204077534 : checkPay e1211204077534 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204081198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211204081198 : Closed e1211204081198 ∧ code e1211204081198 = 5609250592302 := by decide
theorem cert_e1211204081198 : check e1211204081198 [[],[]] .chain = true := by decide
def e1211204081378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211204081378 : Closed e1211204081378 ∧ code e1211204081378 = 5609250592482 := by decide
theorem cert_e1211204081378 : check e1211204081378 [[],[]] .chain = true := by decide
def e1211204081390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1211204081390 : Closed e1211204081390 ∧ code e1211204081390 = 5609250592494 := by decide
theorem cert_e1211204081390 : checkPay e1211204081390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204081518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1211204081518 : Closed e1211204081518 ∧ code e1211204081518 = 5609250592622 := by decide
theorem cert_e1211204081518 : check e1211204081518 [[],[]] .chain = true := by decide
def e1211204081526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1211204081526 : Closed e1211204081526 ∧ code e1211204081526 = 5609250592630 := by decide
theorem cert_e1211204081526 : check e1211204081526 [[],[]] .chain = true := by decide
def e1211204081546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211204081546 : Closed e1211204081546 ∧ code e1211204081546 = 5609250592650 := by decide
theorem cert_e1211204081546 : check e1211204081546 [[],[]] .chain = true := by decide
def e1211204081570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211204081570 : Closed e1211204081570 ∧ code e1211204081570 = 5609250592674 := by decide
theorem cert_e1211204081570 : check e1211204081570 [[],[]] .chain = true := by decide
def e1211204081582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1211204081582 : Closed e1211204081582 ∧ code e1211204081582 = 5609250592686 := by decide
theorem cert_e1211204081582 : checkPay e1211204081582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204081590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1211204081590 : Closed e1211204081590 ∧ code e1211204081590 = 5609250592694 := by decide
theorem cert_e1211204081590 : check e1211204081590 [[],[]] .chain = true := by decide
def e1211204081594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1211204081594 : Closed e1211204081594 ∧ code e1211204081594 = 5609250592698 := by decide
theorem cert_e1211204081594 : checkPay e1211204081594 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204081726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e1211204081726 : Closed e1211204081726 ∧ code e1211204081726 = 5609250592830 := by decide
theorem cert_e1211204081726 : check e1211204081726 [[],[]] .chain = true := by decide
def e1211204082146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211204082146 : Closed e1211204082146 ∧ code e1211204082146 = 5609250593250 := by decide
theorem cert_e1211204082146 : check e1211204082146 [[],[]] .chain = true := by decide
def e1211204082158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1211204082158 : Closed e1211204082158 ∧ code e1211204082158 = 5609250593262 := by decide
theorem cert_e1211204082158 : checkPay e1211204082158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204082926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204082926 : Closed e1211204082926 ∧ code e1211204082926 = 5609250594030 := by decide
theorem cert_e1211204082926 : check e1211204082926 [[],[]] .chain = true := by decide
def e1211204082934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204082934 : Closed e1211204082934 ∧ code e1211204082934 = 5609250594038 := by decide
theorem cert_e1211204082934 : check e1211204082934 [[],[]] .chain = true := by decide
def e1211204083214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e1211204083214 : Closed e1211204083214 ∧ code e1211204083214 = 5609250594318 := by decide
theorem cert_e1211204083214 : check e1211204083214 [[],[]] .chain = true := by decide
def e1211204083226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211204083226 : Closed e1211204083226 ∧ code e1211204083226 = 5609250594330 := by decide
theorem cert_e1211204083226 : checkPay e1211204083226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204083298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211204083298 : Closed e1211204083298 ∧ code e1211204083298 = 5609250594402 := by decide
theorem cert_e1211204083298 : check e1211204083298 [[],[]] .chain = true := by decide
def e1211204083310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204083310 : Closed e1211204083310 ∧ code e1211204083310 = 5609250594414 := by decide
theorem cert_e1211204083310 : checkPay e1211204083310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211204083318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204083318 : Closed e1211204083318 ∧ code e1211204083318 = 5609250594422 := by decide
theorem cert_e1211204083318 : check e1211204083318 [[],[]] .chain = true := by decide
end Blc.Floor42
