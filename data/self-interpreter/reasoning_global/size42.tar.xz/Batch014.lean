import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302825540526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302825540526 : Closed e302825540526 ∧ code e302825540526 = 4700872051630 := by decide
theorem cert_e302825540526 : check e302825540526 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302825540538 : Closed e302825540538 ∧ code e302825540538 = 4700872051642 := by decide
theorem cert_e302825540538 : check e302825540538 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302825540566 : Closed e302825540566 ∧ code e302825540566 = 4700872051670 := by decide
theorem cert_e302825540566 : check e302825540566 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302825540570 : Closed e302825540570 ∧ code e302825540570 = 4700872051674 := by decide
theorem cert_e302825540570 : check e302825540570 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302825540846 : Closed e302825540846 ∧ code e302825540846 = 4700872051950 := by decide
theorem cert_e302825540846 : check e302825540846 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302825540854 : Closed e302825540854 ∧ code e302825540854 = 4700872051958 := by decide
theorem cert_e302825540854 : check e302825540854 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825541230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302825541230 : Closed e302825541230 ∧ code e302825541230 = 4700872052334 := by decide
theorem cert_e302825541230 : check e302825541230 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825541242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302825541242 : Closed e302825541242 ∧ code e302825541242 = 4700872052346 := by decide
theorem cert_e302825541242 : check e302825541242 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825541430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302825541430 : Closed e302825541430 ∧ code e302825541430 = 4700872052534 := by decide
theorem cert_e302825541430 : check e302825541430 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825541434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302825541434 : Closed e302825541434 ∧ code e302825541434 = 4700872052538 := by decide
theorem cert_e302825541434 : check e302825541434 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302826740590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e302826740590 : Closed e302826740590 ∧ code e302826740590 = 4700873251694 := by decide
theorem cert_e302826740590 : check e302826740590 [[.under],[.under]] .chain = true := by decide
def e302826740598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e302826740598 : Closed e302826740598 ∧ code e302826740598 = 4700873251702 := by decide
theorem cert_e302826740598 : check e302826740598 [[.under],[.under]] .chain = true := by decide
def e302826740662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e302826740662 : Closed e302826740662 ∧ code e302826740662 = 4700873251766 := by decide
theorem cert_e302826740662 : check e302826740662 [[.under],[.under]] .chain = true := by decide
def e302826741102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302826741102 : Closed e302826741102 ∧ code e302826741102 = 4700873252206 := by decide
theorem cert_e302826741102 : check e302826741102 [[.under],[.under]] .chain = true := by decide
def e302826741110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302826741110 : Closed e302826741110 ∧ code e302826741110 = 4700873252214 := by decide
theorem cert_e302826741110 : check e302826741110 [[.under],[.under]] .chain = true := by decide
def e302826741166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302826741166 : Closed e302826741166 ∧ code e302826741166 = 4700873252270 := by decide
theorem cert_e302826741166 : check e302826741166 [[.under],[.under]] .chain = true := by decide
def e302826741178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302826741178 : Closed e302826741178 ∧ code e302826741178 = 4700873252282 := by decide
theorem cert_e302826741178 : check e302826741178 [[.under],[.under]] .chain = true := by decide
def e302826741206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302826741206 : Closed e302826741206 ∧ code e302826741206 = 4700873252310 := by decide
theorem cert_e302826741206 : check e302826741206 [[.under],[.under]] .chain = true := by decide
def e302826741210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302826741210 : Closed e302826741210 ∧ code e302826741210 = 4700873252314 := by decide
theorem cert_e302826741210 : check e302826741210 [[.under],[.under]] .chain = true := by decide
def e302826741430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302826741430 : Closed e302826741430 ∧ code e302826741430 = 4700873252534 := by decide
theorem cert_e302826741430 : check e302826741430 [[.under],[.under]] .chain = true := by decide
def e302826741462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302826741462 : Closed e302826741462 ∧ code e302826741462 = 4700873252566 := by decide
theorem cert_e302826741462 : check e302826741462 [[.under],[.under]] .chain = true := by decide
def e302826741466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302826741466 : Closed e302826741466 ∧ code e302826741466 = 4700873252570 := by decide
theorem cert_e302826741466 : check e302826741466 [[.under],[.under]] .chain = true := by decide
def e302826743662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e302826743662 : Closed e302826743662 ∧ code e302826743662 = 4700873254766 := by decide
theorem cert_e302826743662 : check e302826743662 [[.under],[.under]] .chain = true := by decide
def e302826743670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e302826743670 : Closed e302826743670 ∧ code e302826743670 = 4700873254774 := by decide
theorem cert_e302826743670 : check e302826743670 [[.under],[.under]] .chain = true := by decide
def e302826743734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e302826743734 : Closed e302826743734 ∧ code e302826743734 = 4700873254838 := by decide
theorem cert_e302826743734 : check e302826743734 [[.under],[.under]] .chain = true := by decide
def e302826745070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302826745070 : Closed e302826745070 ∧ code e302826745070 = 4700873256174 := by decide
theorem cert_e302826745070 : check e302826745070 [[.under],[.under]] .chain = true := by decide
def e302826745078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302826745078 : Closed e302826745078 ∧ code e302826745078 = 4700873256182 := by decide
theorem cert_e302826745078 : check e302826745078 [[.under],[.under]] .chain = true := by decide
def e302826745462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302826745462 : Closed e302826745462 ∧ code e302826745462 = 4700873256566 := by decide
theorem cert_e302826745462 : check e302826745462 [[.under],[.under]] .chain = true := by decide
def e302826746734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302826746734 : Closed e302826746734 ∧ code e302826746734 = 4700873257838 := by decide
theorem cert_e302826746734 : check e302826746734 [[.under],[.under]] .chain = true := by decide
def e302826746742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302826746742 : Closed e302826746742 ∧ code e302826746742 = 4700873257846 := by decide
theorem cert_e302826746742 : check e302826746742 [[.under],[.under]] .chain = true := by decide
def e302826746798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302826746798 : Closed e302826746798 ∧ code e302826746798 = 4700873257902 := by decide
theorem cert_e302826746798 : check e302826746798 [[.under],[.under]] .chain = true := by decide
def e302826746810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302826746810 : Closed e302826746810 ∧ code e302826746810 = 4700873257914 := by decide
theorem cert_e302826746810 : check e302826746810 [[.under],[.under]] .chain = true := by decide
def e302826746838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302826746838 : Closed e302826746838 ∧ code e302826746838 = 4700873257942 := by decide
theorem cert_e302826746838 : check e302826746838 [[.under],[.under]] .chain = true := by decide
def e302826746842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302826746842 : Closed e302826746842 ∧ code e302826746842 = 4700873257946 := by decide
theorem cert_e302826746842 : check e302826746842 [[.under],[.under]] .chain = true := by decide
def e302826747118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302826747118 : Closed e302826747118 ∧ code e302826747118 = 4700873258222 := by decide
theorem cert_e302826747118 : check e302826747118 [[.under],[.under]] .chain = true := by decide
def e302826747126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302826747126 : Closed e302826747126 ∧ code e302826747126 = 4700873258230 := by decide
theorem cert_e302826747126 : check e302826747126 [[.under],[.under]] .chain = true := by decide
def e302826747502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302826747502 : Closed e302826747502 ∧ code e302826747502 = 4700873258606 := by decide
theorem cert_e302826747502 : check e302826747502 [[.under],[.under]] .chain = true := by decide
def e302826747514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302826747514 : Closed e302826747514 ∧ code e302826747514 = 4700873258618 := by decide
theorem cert_e302826747514 : check e302826747514 [[.under],[.under]] .chain = true := by decide
def e302826747702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302826747702 : Closed e302826747702 ∧ code e302826747702 = 4700873258806 := by decide
theorem cert_e302826747702 : check e302826747702 [[.under],[.under]] .chain = true := by decide
def e302826747706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302826747706 : Closed e302826747706 ∧ code e302826747706 = 4700873258810 := by decide
theorem cert_e302826747706 : check e302826747706 [[.under],[.under]] .chain = true := by decide
def e302826748342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302826748342 : Closed e302826748342 ∧ code e302826748342 = 4700873259446 := by decide
theorem cert_e302826748342 : check e302826748342 [[.under],[.under]] .chain = true := by decide
def e302826748374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302826748374 : Closed e302826748374 ∧ code e302826748374 = 4700873259478 := by decide
theorem cert_e302826748374 : check e302826748374 [[.under],[.under]] .chain = true := by decide
def e302826748378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302826748378 : Closed e302826748378 ∧ code e302826748378 = 4700873259482 := by decide
theorem cert_e302826748378 : check e302826748378 [[.under],[.under]] .chain = true := by decide
def e302826748534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302826748534 : Closed e302826748534 ∧ code e302826748534 = 4700873259638 := by decide
theorem cert_e302826748534 : check e302826748534 [[.under],[.under]] .chain = true := by decide
def e302826748726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302826748726 : Closed e302826748726 ∧ code e302826748726 = 4700873259830 := by decide
theorem cert_e302826748726 : check e302826748726 [[.under],[.under]] .chain = true := by decide
def e302826748730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302826748730 : Closed e302826748730 ∧ code e302826748730 = 4700873259834 := by decide
theorem cert_e302826748730 : check e302826748730 [[.under],[.under]] .chain = true := by decide
def e302826755950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302826755950 : Closed e302826755950 ∧ code e302826755950 = 4700873267054 := by decide
theorem cert_e302826755950 : check e302826755950 [[.under],[.under]] .chain = true := by decide
def e302826755958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302826755958 : Closed e302826755958 ∧ code e302826755958 = 4700873267062 := by decide
theorem cert_e302826755958 : check e302826755958 [[.under],[.under]] .chain = true := by decide
def e302826756022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302826756022 : Closed e302826756022 ∧ code e302826756022 = 4700873267126 := by decide
theorem cert_e302826756022 : check e302826756022 [[.under],[.under]] .chain = true := by decide
def e302826757358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302826757358 : Closed e302826757358 ∧ code e302826757358 = 4700873268462 := by decide
theorem cert_e302826757358 : check e302826757358 [[.under],[.under]] .chain = true := by decide
def e302826757366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302826757366 : Closed e302826757366 ∧ code e302826757366 = 4700873268470 := by decide
theorem cert_e302826757366 : check e302826757366 [[.under],[.under]] .chain = true := by decide
def e302826757750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302826757750 : Closed e302826757750 ∧ code e302826757750 = 4700873268854 := by decide
theorem cert_e302826757750 : check e302826757750 [[.under],[.under]] .chain = true := by decide
def e302826769262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302826769262 : Closed e302826769262 ∧ code e302826769262 = 4700873280366 := by decide
theorem cert_e302826769262 : check e302826769262 [[.under],[.under]] .chain = true := by decide
def e302826769270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302826769270 : Closed e302826769270 ∧ code e302826769270 = 4700873280374 := by decide
theorem cert_e302826769270 : check e302826769270 [[.under],[.under]] .chain = true := by decide
def e302826769326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302826769326 : Closed e302826769326 ∧ code e302826769326 = 4700873280430 := by decide
theorem cert_e302826769326 : check e302826769326 [[.under],[.under]] .chain = true := by decide
def e302826769338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302826769338 : Closed e302826769338 ∧ code e302826769338 = 4700873280442 := by decide
theorem cert_e302826769338 : check e302826769338 [[.under],[.under]] .chain = true := by decide
def e302826769366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302826769366 : Closed e302826769366 ∧ code e302826769366 = 4700873280470 := by decide
theorem cert_e302826769366 : check e302826769366 [[.under],[.under]] .chain = true := by decide
def e302826769370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302826769370 : Closed e302826769370 ∧ code e302826769370 = 4700873280474 := by decide
theorem cert_e302826769370 : check e302826769370 [[.under],[.under]] .chain = true := by decide
def e302826769646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302826769646 : Closed e302826769646 ∧ code e302826769646 = 4700873280750 := by decide
theorem cert_e302826769646 : check e302826769646 [[.under],[.under]] .chain = true := by decide
def e302826769654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302826769654 : Closed e302826769654 ∧ code e302826769654 = 4700873280758 := by decide
theorem cert_e302826769654 : check e302826769654 [[.under],[.under]] .chain = true := by decide
def e302826770030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302826770030 : Closed e302826770030 ∧ code e302826770030 = 4700873281134 := by decide
theorem cert_e302826770030 : check e302826770030 [[.under],[.under]] .chain = true := by decide
def e302826770042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302826770042 : Closed e302826770042 ∧ code e302826770042 = 4700873281146 := by decide
theorem cert_e302826770042 : check e302826770042 [[.under],[.under]] .chain = true := by decide
def e302826770230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302826770230 : Closed e302826770230 ∧ code e302826770230 = 4700873281334 := by decide
theorem cert_e302826770230 : check e302826770230 [[.under],[.under]] .chain = true := by decide
def e302826770234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302826770234 : Closed e302826770234 ∧ code e302826770234 = 4700873281338 := by decide
theorem cert_e302826770234 : check e302826770234 [[.under],[.under]] .chain = true := by decide
def e302826775990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302826775990 : Closed e302826775990 ∧ code e302826775990 = 4700873287094 := by decide
theorem cert_e302826775990 : check e302826775990 [[.under],[.under]] .chain = true := by decide
def e302826776022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302826776022 : Closed e302826776022 ∧ code e302826776022 = 4700873287126 := by decide
theorem cert_e302826776022 : check e302826776022 [[.under],[.under]] .chain = true := by decide
def e302826776026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302826776026 : Closed e302826776026 ∧ code e302826776026 = 4700873287130 := by decide
theorem cert_e302826776026 : check e302826776026 [[.under],[.under]] .chain = true := by decide
def e302826776182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302826776182 : Closed e302826776182 ∧ code e302826776182 = 4700873287286 := by decide
theorem cert_e302826776182 : check e302826776182 [[.under],[.under]] .chain = true := by decide
def e302826776374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302826776374 : Closed e302826776374 ∧ code e302826776374 = 4700873287478 := by decide
theorem cert_e302826776374 : check e302826776374 [[.under],[.under]] .chain = true := by decide
def e302826776378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302826776378 : Closed e302826776378 ∧ code e302826776378 = 4700873287482 := by decide
theorem cert_e302826776378 : check e302826776378 [[.under],[.under]] .chain = true := by decide
def e302827113326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302827113326 : Closed e302827113326 ∧ code e302827113326 = 4700873624430 := by decide
theorem cert_e302827113326 : check e302827113326 [[.under],[.under]] .sourceHead = true := by decide
def e302827113334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302827113334 : Closed e302827113334 ∧ code e302827113334 = 4700873624438 := by decide
theorem cert_e302827113334 : check e302827113334 [[.under],[.under]] .sourceHead = true := by decide
def e302827113390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302827113390 : Closed e302827113390 ∧ code e302827113390 = 4700873624494 := by decide
theorem cert_e302827113390 : check e302827113390 [[.under],[.under]] .sourceHead = true := by decide
def e302827113402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302827113402 : Closed e302827113402 ∧ code e302827113402 = 4700873624506 := by decide
theorem cert_e302827113402 : check e302827113402 [[.under],[.under]] .sourceHead = true := by decide
def e302827113430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302827113430 : Closed e302827113430 ∧ code e302827113430 = 4700873624534 := by decide
theorem cert_e302827113430 : check e302827113430 [[.under],[.under]] .sourceHead = true := by decide
def e302827113434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302827113434 : Closed e302827113434 ∧ code e302827113434 = 4700873624538 := by decide
theorem cert_e302827113434 : check e302827113434 [[.under],[.under]] .sourceHead = true := by decide
def e302827113710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302827113710 : Closed e302827113710 ∧ code e302827113710 = 4700873624814 := by decide
theorem cert_e302827113710 : check e302827113710 [[.under],[.under]] .sourceHead = true := by decide
def e302827113718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302827113718 : Closed e302827113718 ∧ code e302827113718 = 4700873624822 := by decide
theorem cert_e302827113718 : check e302827113718 [[.under],[.under]] .sourceHead = true := by decide
def e302827114094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302827114094 : Closed e302827114094 ∧ code e302827114094 = 4700873625198 := by decide
theorem cert_e302827114094 : check e302827114094 [[.under],[.under]] .sourceHead = true := by decide
def e302827114106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302827114106 : Closed e302827114106 ∧ code e302827114106 = 4700873625210 := by decide
theorem cert_e302827114106 : check e302827114106 [[.under],[.under]] .sourceHead = true := by decide
def e302827114294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302827114294 : Closed e302827114294 ∧ code e302827114294 = 4700873625398 := by decide
theorem cert_e302827114294 : check e302827114294 [[.under],[.under]] .sourceHead = true := by decide
def e302827114298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302827114298 : Closed e302827114298 ∧ code e302827114298 = 4700873625402 := by decide
theorem cert_e302827114298 : check e302827114298 [[.under],[.under]] .sourceHead = true := by decide
def e302896213470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e302896213470 : Closed e302896213470 ∧ code e302896213470 = 4700942724574 := by decide
theorem cert_e302896213470 : check e302896213470 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896213486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e302896213486 : Closed e302896213486 ∧ code e302896213486 = 4700942724590 := by decide
theorem cert_e302896213486 : checkPay e302896213486 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e302896213726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e302896213726 : Closed e302896213726 ∧ code e302896213726 = 4700942724830 := by decide
theorem cert_e302896213726 : check e302896213726 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896213750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e302896213750 : Closed e302896213750 ∧ code e302896213750 = 4700942724854 := by decide
theorem cert_e302896213750 : check e302896213750 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left]] .identityHead = true := by decide
def e302896213870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e302896213870 : Closed e302896213870 ∧ code e302896213870 = 4700942724974 := by decide
theorem cert_e302896213870 : check e302896213870 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302896213878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e302896213878 : Closed e302896213878 ∧ code e302896213878 = 4700942724982 := by decide
theorem cert_e302896213878 : check e302896213878 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302896215518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e302896215518 : Closed e302896215518 ∧ code e302896215518 = 4700942726622 := by decide
theorem cert_e302896215518 : check e302896215518 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302896215534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e302896215534 : Closed e302896215534 ∧ code e302896215534 = 4700942726638 := by decide
theorem cert_e302896215534 : check e302896215534 [[.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302896215902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e302896215902 : Closed e302896215902 ∧ code e302896215902 = 4700942727006 := by decide
private def t_e302896215902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem cert_e302896215902 : ¬ IsSelfInterpreter e302896215902 :=
  wSource (t := t_e302896215902) (replay_sound (ps := []) (t := e302896215902) (by decide)) (by decide)
def e302896215930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e302896215930 : Closed e302896215930 ∧ code e302896215930 = 4700942727034 := by decide
private def t_e302896215930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem cert_e302896215930 : ¬ IsSelfInterpreter e302896215930 :=
  wSource (t := t_e302896215930) (replay_sound (ps := []) (t := e302896215930) (by decide)) (by decide)
def e302896215982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e302896215982 : Closed e302896215982 ∧ code e302896215982 = 4700942727086 := by decide
theorem cert_e302896215982 : check e302896215982 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302896215994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e302896215994 : Closed e302896215994 ∧ code e302896215994 = 4700942727098 := by decide
theorem cert_e302896215994 : check e302896215994 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302896216798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302896216798 : Closed e302896216798 ∧ code e302896216798 = 4700942727902 := by decide
theorem cert_e302896216798 : check e302896216798 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896216822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302896216822 : Closed e302896216822 ∧ code e302896216822 = 4700942727926 := by decide
theorem cert_e302896216822 : check e302896216822 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896216926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302896216926 : Closed e302896216926 ∧ code e302896216926 = 4700942728030 := by decide
private def t_e302896216926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem cert_e302896216926 : ¬ IsSelfInterpreter e302896216926 :=
  wSource (t := t_e302896216926) (replay_sound (ps := []) (t := e302896216926) (by decide)) (by decide)
def e302896216954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302896216954 : Closed e302896216954 ∧ code e302896216954 = 4700942728058 := by decide
private def t_e302896216954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem cert_e302896216954 : ¬ IsSelfInterpreter e302896216954 :=
  wSource (t := t_e302896216954) (replay_sound (ps := []) (t := e302896216954) (by decide)) (by decide)
def e302896217046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302896217046 : Closed e302896217046 ∧ code e302896217046 = 4700942728150 := by decide
theorem cert_e302896217046 : check e302896217046 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896217050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302896217050 : Closed e302896217050 ∧ code e302896217050 = 4700942728154 := by decide
theorem cert_e302896217050 : check e302896217050 [[.under],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896217454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302896217454 : Closed e302896217454 ∧ code e302896217454 = 4700942728558 := by decide
theorem cert_e302896217454 : check e302896217454 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896217462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302896217462 : Closed e302896217462 ∧ code e302896217462 = 4700942728566 := by decide
theorem cert_e302896217462 : check e302896217462 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896217518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302896217518 : Closed e302896217518 ∧ code e302896217518 = 4700942728622 := by decide
theorem cert_e302896217518 : check e302896217518 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896217530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302896217530 : Closed e302896217530 ∧ code e302896217530 = 4700942728634 := by decide
theorem cert_e302896217530 : check e302896217530 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896217558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302896217558 : Closed e302896217558 ∧ code e302896217558 = 4700942728662 := by decide
theorem cert_e302896217558 : check e302896217558 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896217562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302896217562 : Closed e302896217562 ∧ code e302896217562 = 4700942728666 := by decide
theorem cert_e302896217562 : check e302896217562 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896225758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e302896225758 : Closed e302896225758 ∧ code e302896225758 = 4700942736862 := by decide
theorem cert_e302896225758 : check e302896225758 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302896225774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e302896225774 : Closed e302896225774 ∧ code e302896225774 = 4700942736878 := by decide
theorem cert_e302896225774 : check e302896225774 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302896226014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e302896226014 : Closed e302896226014 ∧ code e302896226014 = 4700942737118 := by decide
theorem cert_e302896226014 : check e302896226014 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302896226038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e302896226038 : Closed e302896226038 ∧ code e302896226038 = 4700942737142 := by decide
theorem cert_e302896226038 : check e302896226038 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302896226158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e302896226158 : Closed e302896226158 ∧ code e302896226158 = 4700942737262 := by decide
theorem cert_e302896226158 : check e302896226158 [[.left],[.left],[.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e302896226166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e302896226166 : Closed e302896226166 ∧ code e302896226166 = 4700942737270 := by decide
theorem cert_e302896226166 : check e302896226166 [[.left],[.left],[.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e302896231390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302896231390 : Closed e302896231390 ∧ code e302896231390 = 4700942742494 := by decide
theorem cert_e302896231390 : check e302896231390 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302896231406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302896231406 : Closed e302896231406 ∧ code e302896231406 = 4700942742510 := by decide
theorem cert_e302896231406 : check e302896231406 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896232926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302896232926 : Closed e302896232926 ∧ code e302896232926 = 4700942744030 := by decide
theorem cert_e302896232926 : check e302896232926 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896232950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302896232950 : Closed e302896232950 ∧ code e302896232950 = 4700942744054 := by decide
theorem cert_e302896232950 : check e302896232950 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896233710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302896233710 : Closed e302896233710 ∧ code e302896233710 = 4700942744814 := by decide
theorem cert_e302896233710 : check e302896233710 [[.left],[.left],[.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e302896233718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302896233718 : Closed e302896233718 ∧ code e302896233718 = 4700942744822 := by decide
theorem cert_e302896233718 : check e302896233718 [[.left],[.left],[.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e302896238046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e302896238046 : Closed e302896238046 ∧ code e302896238046 = 4700942749150 := by decide
theorem cert_e302896238046 : check e302896238046 [[.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302896238062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e302896238062 : Closed e302896238062 ∧ code e302896238062 = 4700942749166 := by decide
theorem cert_e302896238062 : check e302896238062 [[.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302896238430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e302896238430 : Closed e302896238430 ∧ code e302896238430 = 4700942749534 := by decide
theorem cert_e302896238430 : check e302896238430 [[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896238458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e302896238458 : Closed e302896238458 ∧ code e302896238458 = 4700942749562 := by decide
theorem cert_e302896238458 : check e302896238458 [[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302896238510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e302896238510 : Closed e302896238510 ∧ code e302896238510 = 4700942749614 := by decide
theorem cert_e302896238510 : check e302896238510 [[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302896238522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e302896238522 : Closed e302896238522 ∧ code e302896238522 = 4700942749626 := by decide
theorem cert_e302896238522 : check e302896238522 [[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302896239582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302896239582 : Closed e302896239582 ∧ code e302896239582 = 4700942750686 := by decide
theorem cert_e302896239582 : check e302896239582 [[.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302896239598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302896239598 : Closed e302896239598 ∧ code e302896239598 = 4700942750702 := by decide
theorem cert_e302896239598 : check e302896239598 [[.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left]] .identityHead = true := by decide
def e302896241886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302896241886 : Closed e302896241886 ∧ code e302896241886 = 4700942752990 := by decide
private def t_e302896241886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem cert_e302896241886 : ¬ IsSelfInterpreter e302896241886 :=
  wSource (t := t_e302896241886) (replay_sound (ps := []) (t := e302896241886) (by decide)) (by decide)
def e302896241914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302896241914 : Closed e302896241914 ∧ code e302896241914 = 4700942753018 := by decide
private def t_e302896241914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem cert_e302896241914 : ¬ IsSelfInterpreter e302896241914 :=
  wSource (t := t_e302896241914) (replay_sound (ps := []) (t := e302896241914) (by decide)) (by decide)
def e302896242286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302896242286 : Closed e302896242286 ∧ code e302896242286 = 4700942753390 := by decide
theorem cert_e302896242286 : checkPay e302896242286 [[.left],[.left],[.left],[.left],[.left],[],[.left],[]] 0 [] = true := by decide
def e302896242298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302896242298 : Closed e302896242298 ∧ code e302896242298 = 4700942753402 := by decide
theorem cert_e302896242298 : checkPay e302896242298 [[.left],[.left],[.left],[.left],[.left],[],[.left],[]] 0 [] = true := by decide
def e302896244446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302896244446 : Closed e302896244446 ∧ code e302896244446 = 4700942755550 := by decide
theorem cert_e302896244446 : check e302896244446 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302896244470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302896244470 : Closed e302896244470 ∧ code e302896244470 = 4700942755574 := by decide
theorem cert_e302896244470 : check e302896244470 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896244574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302896244574 : Closed e302896244574 ∧ code e302896244574 = 4700942755678 := by decide
theorem cert_e302896244574 : check e302896244574 [[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e302896244602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302896244602 : Closed e302896244602 ∧ code e302896244602 = 4700942755706 := by decide
theorem cert_e302896244602 : check e302896244602 [[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302896244694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302896244694 : Closed e302896244694 ∧ code e302896244694 = 4700942755798 := by decide
theorem cert_e302896244694 : check e302896244694 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896244698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302896244698 : Closed e302896244698 ∧ code e302896244698 = 4700942755802 := by decide
theorem cert_e302896244698 : check e302896244698 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302896245214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302896245214 : Closed e302896245214 ∧ code e302896245214 = 4700942756318 := by decide
theorem cert_e302896245214 : check e302896245214 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896245238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302896245238 : Closed e302896245238 ∧ code e302896245238 = 4700942756342 := by decide
theorem cert_e302896245238 : check e302896245238 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896245982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302896245982 : Closed e302896245982 ∧ code e302896245982 = 4700942757086 := by decide
private def t_e302896245982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem cert_e302896245982 : ¬ IsSelfInterpreter e302896245982 :=
  wSource (t := t_e302896245982) (replay_sound (ps := []) (t := e302896245982) (by decide)) (by decide)
def e302896246010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302896246010 : Closed e302896246010 ∧ code e302896246010 = 4700942757114 := by decide
private def t_e302896246010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem cert_e302896246010 : ¬ IsSelfInterpreter e302896246010 :=
  wSource (t := t_e302896246010) (replay_sound (ps := []) (t := e302896246010) (by decide)) (by decide)
def e302896246582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302896246582 : Closed e302896246582 ∧ code e302896246582 = 4700942757686 := by decide
theorem cert_e302896246582 : check e302896246582 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896246586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302896246586 : Closed e302896246586 ∧ code e302896246586 = 4700942757690 := by decide
theorem cert_e302896246586 : check e302896246586 [[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896247662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302896247662 : Closed e302896247662 ∧ code e302896247662 = 4700942758766 := by decide
theorem cert_e302896247662 : checkPay e302896247662 [[.left],[.left],[.left],[.left],[.left],[]] 0 [[],[.left],[],[.left,.right],[.left,.right,.left],[.left,.right]] = true := by decide
def e302896247670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302896247670 : Closed e302896247670 ∧ code e302896247670 = 4700942758774 := by decide
theorem cert_e302896247670 : checkPay e302896247670 [[.left],[.left],[.left],[.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e302896247726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302896247726 : Closed e302896247726 ∧ code e302896247726 = 4700942758830 := by decide
theorem cert_e302896247726 : checkPay e302896247726 [[.left],[.left],[.left],[.left],[.left],[]] 0 [[],[.under,.left,.right]] = true := by decide
def e302896247738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302896247738 : Closed e302896247738 ∧ code e302896247738 = 4700942758842 := by decide
theorem cert_e302896247738 : checkPay e302896247738 [[.left],[.left],[.left],[.left],[.left],[]] 1 [] = true := by decide
def e302896247766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302896247766 : Closed e302896247766 ∧ code e302896247766 = 4700942758870 := by decide
theorem cert_e302896247766 : checkPay e302896247766 [[.left],[.left],[.left],[.left],[.left],[]] 0 [[],[],[.left],[],[.left,.right],[.left,.right,.left],[.left,.right,.left,.left],[.left,.right,.left],[.left,.right]] = true := by decide
def e302896247770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302896247770 : Closed e302896247770 ∧ code e302896247770 = 4700942758874 := by decide
theorem cert_e302896247770 : checkPay e302896247770 [[.left],[.left],[.left],[.left],[.left],[]] 1 [] = true := by decide
def e302896248046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302896248046 : Closed e302896248046 ∧ code e302896248046 = 4700942759150 := by decide
theorem cert_e302896248046 : checkPay e302896248046 [[.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896248054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302896248054 : Closed e302896248054 ∧ code e302896248054 = 4700942759158 := by decide
theorem cert_e302896248054 : checkPay e302896248054 [[.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896248430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302896248430 : Closed e302896248430 ∧ code e302896248430 = 4700942759534 := by decide
theorem cert_e302896248430 : checkPay e302896248430 [[.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896248442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302896248442 : Closed e302896248442 ∧ code e302896248442 = 4700942759546 := by decide
theorem cert_e302896248442 : checkPay e302896248442 [[.left],[.left],[.left],[.left],[.left],[]] 0 [[.under,.under,.right],[.under,.under,.right,.under,.right]] = true := by decide
def e302896248630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302896248630 : Closed e302896248630 ∧ code e302896248630 = 4700942759734 := by decide
theorem cert_e302896248630 : checkPay e302896248630 [[.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896248634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302896248634 : Closed e302896248634 ∧ code e302896248634 = 4700942759738 := by decide
theorem cert_e302896248634 : checkPay e302896248634 [[.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896274910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302896274910 : Closed e302896274910 ∧ code e302896274910 = 4700942786014 := by decide
theorem cert_e302896274910 : check e302896274910 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302896274926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302896274926 : Closed e302896274926 ∧ code e302896274926 = 4700942786030 := by decide
theorem cert_e302896274926 : check e302896274926 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e302896275166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302896275166 : Closed e302896275166 ∧ code e302896275166 = 4700942786270 := by decide
theorem cert_e302896275166 : check e302896275166 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302896275190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302896275190 : Closed e302896275190 ∧ code e302896275190 = 4700942786294 := by decide
theorem cert_e302896275190 : check e302896275190 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e302896275310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302896275310 : Closed e302896275310 ∧ code e302896275310 = 4700942786414 := by decide
theorem cert_e302896275310 : check e302896275310 [[.left],[.left],[.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302896275318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302896275318 : Closed e302896275318 ∧ code e302896275318 = 4700942786422 := by decide
theorem cert_e302896275318 : check e302896275318 [[.left],[.left],[.left],[.left],[.left],[],[]] .identityHead = true := by decide
end Blc.Floor42
