import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211298933166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211298933166 : Closed e1211298933166 ∧ code e1211298933166 = 5609345444270 := by decide
theorem cert_e1211298933166 : check e1211298933166 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211298933178 : Closed e1211298933178 ∧ code e1211298933178 = 5609345444282 := by decide
theorem cert_e1211298933178 : check e1211298933178 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211298933226 : Closed e1211298933226 ∧ code e1211298933226 = 5609345444330 := by decide
theorem cert_e1211298933226 : check e1211298933226 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298933358 : Closed e1211298933358 ∧ code e1211298933358 = 5609345444462 := by decide
theorem cert_e1211298933358 : check e1211298933358 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298933370 : Closed e1211298933370 ∧ code e1211298933370 = 5609345444474 := by decide
theorem cert_e1211298933370 : check e1211298933370 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211298933534 : Closed e1211298933534 ∧ code e1211298933534 = 5609345444638 := by decide
theorem cert_e1211298933534 : check e1211298933534 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298933634 : Closed e1211298933634 ∧ code e1211298933634 = 5609345444738 := by decide
theorem cert_e1211298933634 : check e1211298933634 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211298933646 : Closed e1211298933646 ∧ code e1211298933646 = 5609345444750 := by decide
theorem cert_e1211298933646 : check e1211298933646 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298933658 : Closed e1211298933658 ∧ code e1211298933658 = 5609345444762 := by decide
theorem cert_e1211298933658 : check e1211298933658 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211298933870 : Closed e1211298933870 ∧ code e1211298933870 = 5609345444974 := by decide
theorem cert_e1211298933870 : check e1211298933870 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298933882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211298933882 : Closed e1211298933882 ∧ code e1211298933882 = 5609345444986 := by decide
theorem cert_e1211298933882 : check e1211298933882 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211298934046 : Closed e1211298934046 ∧ code e1211298934046 = 5609345445150 := by decide
theorem cert_e1211298934046 : check e1211298934046 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211298934214 : Closed e1211298934214 ∧ code e1211298934214 = 5609345445318 := by decide
theorem cert_e1211298934214 : check e1211298934214 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211298934282 : Closed e1211298934282 ∧ code e1211298934282 = 5609345445386 := by decide
theorem cert_e1211298934282 : check e1211298934282 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211298934326 : Closed e1211298934326 ∧ code e1211298934326 = 5609345445430 := by decide
theorem cert_e1211298934326 : check e1211298934326 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211298934330 : Closed e1211298934330 ∧ code e1211298934330 = 5609345445434 := by decide
theorem cert_e1211298934330 : check e1211298934330 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211298934378 : Closed e1211298934378 ∧ code e1211298934378 = 5609345445482 := by decide
theorem cert_e1211298934378 : check e1211298934378 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298934402 : Closed e1211298934402 ∧ code e1211298934402 = 5609345445506 := by decide
theorem cert_e1211298934402 : check e1211298934402 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211298934414 : Closed e1211298934414 ∧ code e1211298934414 = 5609345445518 := by decide
theorem cert_e1211298934414 : check e1211298934414 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298934426 : Closed e1211298934426 ∧ code e1211298934426 = 5609345445530 := by decide
theorem cert_e1211298934426 : check e1211298934426 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211298934470 : Closed e1211298934470 ∧ code e1211298934470 = 5609345445574 := by decide
theorem cert_e1211298934470 : check e1211298934470 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211298934870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211298934870 : Closed e1211298934870 ∧ code e1211298934870 = 5609345445974 := by decide
theorem cert_e1211298934870 : check e1211298934870 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298934874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211298934874 : Closed e1211298934874 ∧ code e1211298934874 = 5609345445978 := by decide
theorem cert_e1211298934874 : check e1211298934874 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298935222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e1211298935222 : Closed e1211298935222 ∧ code e1211298935222 = 5609345446326 := by decide
theorem cert_e1211298935222 : check e1211298935222 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1211298935254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211298935254 : Closed e1211298935254 ∧ code e1211298935254 = 5609345446358 := by decide
theorem cert_e1211298935254 : check e1211298935254 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .smaller = true := by decide
def e1211298935258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211298935258 : Closed e1211298935258 ∧ code e1211298935258 = 5609345446362 := by decide
theorem cert_e1211298935258 : check e1211298935258 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211298935638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211298935638 : Closed e1211298935638 ∧ code e1211298935638 = 5609345446742 := by decide
private def t_e1211298935638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem cert_e1211298935638 : ¬ IsSelfInterpreter e1211298935638 :=
  wSource (t := t_e1211298935638) (replay_sound (ps := []) (t := e1211298935638) (by decide)) (by decide)
def e1211298935642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211298935642 : Closed e1211298935642 ∧ code e1211298935642 = 5609345446746 := by decide
private def t_e1211298935642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem cert_e1211298935642 : ¬ IsSelfInterpreter e1211298935642 :=
  wSource (t := t_e1211298935642) (replay_sound (ps := []) (t := e1211298935642) (by decide)) (by decide)
def e1211298935658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211298935658 : Closed e1211298935658 ∧ code e1211298935658 = 5609345446762 := by decide
theorem cert_e1211298935658 : check e1211298935658 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298935722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211298935722 : Closed e1211298935722 ∧ code e1211298935722 = 5609345446826 := by decide
theorem cert_e1211298935722 : check e1211298935722 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298935830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211298935830 : Closed e1211298935830 ∧ code e1211298935830 = 5609345446934 := by decide
private def t_e1211298935830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem cert_e1211298935830 : ¬ IsSelfInterpreter e1211298935830 :=
  wSource (t := t_e1211298935830) (replay_sound (ps := []) (t := e1211298935830) (by decide)) (by decide)
def e1211298935926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211298935926 : Closed e1211298935926 ∧ code e1211298935926 = 5609345447030 := by decide
private def t_e1211298935926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem cert_e1211298935926 : ¬ IsSelfInterpreter e1211298935926 :=
  wSource (t := t_e1211298935926) (replay_sound (ps := []) (t := e1211298935926) (by decide)) (by decide)
def e1211298936022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211298936022 : Closed e1211298936022 ∧ code e1211298936022 = 5609345447126 := by decide
private def t_e1211298936022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1211298936022 : ¬ IsSelfInterpreter e1211298936022 :=
  wSource (t := t_e1211298936022) (replay_sound (ps := []) (t := e1211298936022) (by decide)) (by decide)
def e1211298936026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211298936026 : Closed e1211298936026 ∧ code e1211298936026 = 5609345447130 := by decide
private def t_e1211298936026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e1211298936026 : ¬ IsSelfInterpreter e1211298936026 :=
  wSource (t := t_e1211298936026) (replay_sound (ps := []) (t := e1211298936026) (by decide)) (by decide)
def e1211298936042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211298936042 : Closed e1211298936042 ∧ code e1211298936042 = 5609345447146 := by decide
private def t_e1211298936042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e1211298936042 : ¬ IsSelfInterpreter e1211298936042 :=
  wSource (t := t_e1211298936042) (replay_sound (ps := []) (t := e1211298936042) (by decide)) (by decide)
def e1211298936118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298936118 : Closed e1211298936118 ∧ code e1211298936118 = 5609345447222 := by decide
private def t_e1211298936118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298936118 : ¬ IsSelfInterpreter e1211298936118 :=
  wSource (t := t_e1211298936118) (replay_sound (ps := []) (t := e1211298936118) (by decide)) (by decide)
def e1211298936122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298936122 : Closed e1211298936122 ∧ code e1211298936122 = 5609345447226 := by decide
private def t_e1211298936122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298936122 : ¬ IsSelfInterpreter e1211298936122 :=
  wSource (t := t_e1211298936122) (replay_sound (ps := []) (t := e1211298936122) (by decide)) (by decide)
def e1211298936194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298936194 : Closed e1211298936194 ∧ code e1211298936194 = 5609345447298 := by decide
private def t_e1211298936194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem cert_e1211298936194 : ¬ IsSelfInterpreter e1211298936194 :=
  wSource (t := t_e1211298936194) (replay_sound (ps := []) (t := e1211298936194) (by decide)) (by decide)
def e1211298936206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211298936206 : Closed e1211298936206 ∧ code e1211298936206 = 5609345447310 := by decide
private def t_e1211298936206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem cert_e1211298936206 : ¬ IsSelfInterpreter e1211298936206 :=
  wSource (t := t_e1211298936206) (replay_sound (ps := []) (t := e1211298936206) (by decide)) (by decide)
def e1211298936218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298936218 : Closed e1211298936218 ∧ code e1211298936218 = 5609345447322 := by decide
private def t_e1211298936218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e1211298936218 : ¬ IsSelfInterpreter e1211298936218 :=
  wSource (t := t_e1211298936218) (replay_sound (ps := []) (t := e1211298936218) (by decide)) (by decide)
def e1211298936330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211298936330 : Closed e1211298936330 ∧ code e1211298936330 = 5609345447434 := by decide
theorem cert_e1211298936330 : check e1211298936330 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298936374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211298936374 : Closed e1211298936374 ∧ code e1211298936374 = 5609345447478 := by decide
theorem cert_e1211298936374 : checkPay e1211298936374 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.under,.left,.left],[.under,.left,.left,.right,.under,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.under,.left,.left,.left],[.under,.right,.under,.under,.left,.left],[.under,.right,.under,.under,.left,.left,.left,.left],[.under,.right,.under,.under,.left,.left,.left]] = true := by decide
def e1211298936378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211298936378 : Closed e1211298936378 ∧ code e1211298936378 = 5609345447482 := by decide
theorem cert_e1211298936378 : check e1211298936378 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211298936426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211298936426 : Closed e1211298936426 ∧ code e1211298936426 = 5609345447530 := by decide
theorem cert_e1211298936426 : checkPay e1211298936426 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 1 [[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.right,.under,.left,.left,.right],[.under,.left,.left,.left,.right,.under,.left,.left,.right,.left],[.under,.left,.left,.left,.right,.under,.left,.left,.right,.left,.left],[.under,.left,.left,.left,.right,.under,.left,.left,.right,.left],[.under,.left,.left,.left,.right,.under,.left,.left,.right]] = true := by decide
def e1211298936450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298936450 : Closed e1211298936450 ∧ code e1211298936450 = 5609345447554 := by decide
theorem cert_e1211298936450 : check e1211298936450 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298936462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211298936462 : Closed e1211298936462 ∧ code e1211298936462 = 5609345447566 := by decide
theorem cert_e1211298936462 : checkPay e1211298936462 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left],[.under,.right,.under,.under,.left,.left],[.under,.right,.under,.under,.left,.left,.left,.left],[.under,.right,.under,.under,.left,.left,.left]] = true := by decide
def e1211298936474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298936474 : Closed e1211298936474 ∧ code e1211298936474 = 5609345447578 := by decide
theorem cert_e1211298936474 : checkPay e1211298936474 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.right],[.under,.left,.left,.right,.under,.left,.left,.right,.left],[.under,.left,.left,.right,.under,.left,.left,.right,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.right,.left],[.under,.left,.left,.right,.under,.left,.left,.right]] = true := by decide
def e1211298936518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211298936518 : Closed e1211298936518 ∧ code e1211298936518 = 5609345447622 := by decide
theorem cert_e1211298936518 : check e1211298936518 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211298940142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211298940142 : Closed e1211298940142 ∧ code e1211298940142 = 5609345451246 := by decide
theorem cert_e1211298940142 : check e1211298940142 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211298940150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211298940150 : Closed e1211298940150 ∧ code e1211298940150 = 5609345451254 := by decide
theorem cert_e1211298940150 : check e1211298940150 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211298942702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211298942702 : Closed e1211298942702 ∧ code e1211298942702 = 5609345453806 := by decide
theorem cert_e1211298942702 : check e1211298942702 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298942710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211298942710 : Closed e1211298942710 ∧ code e1211298942710 = 5609345453814 := by decide
private def t_e1211298942710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem cert_e1211298942710 : ¬ IsSelfInterpreter e1211298942710 :=
  wSource (t := t_e1211298942710) (replay_sound (ps := []) (t := e1211298942710) (by decide)) (by decide)
def e1211298942830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211298942830 : Closed e1211298942830 ∧ code e1211298942830 = 5609345453934 := by decide
theorem cert_e1211298942830 : check e1211298942830 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298942842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211298942842 : Closed e1211298942842 ∧ code e1211298942842 = 5609345453946 := by decide
theorem cert_e1211298942842 : check e1211298942842 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298942902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211298942902 : Closed e1211298942902 ∧ code e1211298942902 = 5609345454006 := by decide
private def t_e1211298942902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem cert_e1211298942902 : ¬ IsSelfInterpreter e1211298942902 :=
  wSource (t := t_e1211298942902) (replay_sound (ps := []) (t := e1211298942902) (by decide)) (by decide)
def e1211298942906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211298942906 : Closed e1211298942906 ∧ code e1211298942906 = 5609345454010 := by decide
theorem cert_e1211298942906 : checkPay e1211298942906 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [[.under,.left,.right,.under,.right,.under]] = true := by decide
def e1211298946286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211298946286 : Closed e1211298946286 ∧ code e1211298946286 = 5609345457390 := by decide
theorem cert_e1211298946286 : checkPay e1211298946286 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211298946294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211298946294 : Closed e1211298946294 ∧ code e1211298946294 = 5609345457398 := by decide
theorem cert_e1211298946294 : checkPay e1211298946294 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [[],[.left],[.left,.left],[.right]] = true := by decide
def e1211298946678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211298946678 : Closed e1211298946678 ∧ code e1211298946678 = 5609345457782 := by decide
theorem cert_e1211298946678 : check e1211298946678 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211298950510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211298950510 : Closed e1211298950510 ∧ code e1211298950510 = 5609345461614 := by decide
private def t_e1211298950510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem cert_e1211298950510 : ¬ IsSelfInterpreter e1211298950510 :=
  wSource (t := t_e1211298950510) (replay_sound (ps := []) (t := e1211298950510) (by decide)) (by decide)
def e1211298950518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211298950518 : Closed e1211298950518 ∧ code e1211298950518 = 5609345461622 := by decide
private def t_e1211298950518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem cert_e1211298950518 : ¬ IsSelfInterpreter e1211298950518 :=
  wSource (t := t_e1211298950518) (replay_sound (ps := []) (t := e1211298950518) (by decide)) (by decide)
def e1211298950574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211298950574 : Closed e1211298950574 ∧ code e1211298950574 = 5609345461678 := by decide
theorem cert_e1211298950574 : check e1211298950574 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298950586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211298950586 : Closed e1211298950586 ∧ code e1211298950586 = 5609345461690 := by decide
theorem cert_e1211298950586 : check e1211298950586 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298950614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211298950614 : Closed e1211298950614 ∧ code e1211298950614 = 5609345461718 := by decide
private def t_e1211298950614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem cert_e1211298950614 : ¬ IsSelfInterpreter e1211298950614 :=
  wSource (t := t_e1211298950614) (replay_sound (ps := []) (t := e1211298950614) (by decide)) (by decide)
def e1211298950618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211298950618 : Closed e1211298950618 ∧ code e1211298950618 = 5609345461722 := by decide
private def t_e1211298950618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem cert_e1211298950618 : ¬ IsSelfInterpreter e1211298950618 :=
  wSource (t := t_e1211298950618) (replay_sound (ps := []) (t := e1211298950618) (by decide)) (by decide)
def e1211298950830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211298950830 : Closed e1211298950830 ∧ code e1211298950830 = 5609345461934 := by decide
theorem cert_e1211298950830 : check e1211298950830 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298950842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211298950842 : Closed e1211298950842 ∧ code e1211298950842 = 5609345461946 := by decide
theorem cert_e1211298950842 : check e1211298950842 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298950890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211298950890 : Closed e1211298950890 ∧ code e1211298950890 = 5609345461994 := by decide
theorem cert_e1211298950890 : check e1211298950890 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298950998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211298950998 : Closed e1211298950998 ∧ code e1211298950998 = 5609345462102 := by decide
private def t_e1211298950998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem cert_e1211298950998 : ¬ IsSelfInterpreter e1211298950998 :=
  wSource (t := t_e1211298950998) (replay_sound (ps := []) (t := e1211298950998) (by decide)) (by decide)
def e1211298951002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211298951002 : Closed e1211298951002 ∧ code e1211298951002 = 5609345462106 := by decide
private def t_e1211298951002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem cert_e1211298951002 : ¬ IsSelfInterpreter e1211298951002 :=
  wSource (t := t_e1211298951002) (replay_sound (ps := []) (t := e1211298951002) (by decide)) (by decide)
def e1211298951018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211298951018 : Closed e1211298951018 ∧ code e1211298951018 = 5609345462122 := by decide
theorem cert_e1211298951018 : check e1211298951018 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211298952046 : Closed e1211298952046 ∧ code e1211298952046 = 5609345463150 := by decide
theorem cert_e1211298952046 : check e1211298952046 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211298952054 : Closed e1211298952054 ∧ code e1211298952054 = 5609345463158 := by decide
private def t_e1211298952054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem cert_e1211298952054 : ¬ IsSelfInterpreter e1211298952054 :=
  wSource (t := t_e1211298952054) (replay_sound (ps := []) (t := e1211298952054) (by decide)) (by decide)
def e1211298952110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211298952110 : Closed e1211298952110 ∧ code e1211298952110 = 5609345463214 := by decide
theorem cert_e1211298952110 : check e1211298952110 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211298952122 : Closed e1211298952122 ∧ code e1211298952122 = 5609345463226 := by decide
theorem cert_e1211298952122 : check e1211298952122 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211298952150 : Closed e1211298952150 ∧ code e1211298952150 = 5609345463254 := by decide
private def t_e1211298952150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem cert_e1211298952150 : ¬ IsSelfInterpreter e1211298952150 :=
  wSource (t := t_e1211298952150) (replay_sound (ps := []) (t := e1211298952150) (by decide)) (by decide)
def e1211298952154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211298952154 : Closed e1211298952154 ∧ code e1211298952154 = 5609345463258 := by decide
theorem cert_e1211298952154 : check e1211298952154 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211298952430 : Closed e1211298952430 ∧ code e1211298952430 = 5609345463534 := by decide
private def t_e1211298952430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem cert_e1211298952430 : ¬ IsSelfInterpreter e1211298952430 :=
  wSource (t := t_e1211298952430) (replay_sound (ps := []) (t := e1211298952430) (by decide)) (by decide)
def e1211298952438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211298952438 : Closed e1211298952438 ∧ code e1211298952438 = 5609345463542 := by decide
private def t_e1211298952438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem cert_e1211298952438 : ¬ IsSelfInterpreter e1211298952438 :=
  wSource (t := t_e1211298952438) (replay_sound (ps := []) (t := e1211298952438) (by decide)) (by decide)
def e1211298952814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298952814 : Closed e1211298952814 ∧ code e1211298952814 = 5609345463918 := by decide
theorem cert_e1211298952814 : check e1211298952814 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298952826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298952826 : Closed e1211298952826 ∧ code e1211298952826 = 5609345463930 := by decide
theorem cert_e1211298952826 : check e1211298952826 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298953014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298953014 : Closed e1211298953014 ∧ code e1211298953014 = 5609345464118 := by decide
private def t_e1211298953014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298953014 : ¬ IsSelfInterpreter e1211298953014 :=
  wSource (t := t_e1211298953014) (replay_sound (ps := []) (t := e1211298953014) (by decide)) (by decide)
def e1211298953018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298953018 : Closed e1211298953018 ∧ code e1211298953018 = 5609345464122 := by decide
private def t_e1211298953018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298953018 : ¬ IsSelfInterpreter e1211298953018 :=
  wSource (t := t_e1211298953018) (replay_sound (ps := []) (t := e1211298953018) (by decide)) (by decide)
def e1211298953262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211298953262 : Closed e1211298953262 ∧ code e1211298953262 = 5609345464366 := by decide
theorem cert_e1211298953262 : check e1211298953262 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211298953454 : Closed e1211298953454 ∧ code e1211298953454 = 5609345464558 := by decide
theorem cert_e1211298953454 : check e1211298953454 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211298953462 : Closed e1211298953462 ∧ code e1211298953462 = 5609345464566 := by decide
theorem cert_e1211298953462 : check e1211298953462 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211298953646 : Closed e1211298953646 ∧ code e1211298953646 = 5609345464750 := by decide
theorem cert_e1211298953646 : check e1211298953646 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211298953658 : Closed e1211298953658 ∧ code e1211298953658 = 5609345464762 := by decide
theorem cert_e1211298953658 : check e1211298953658 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211298953706 : Closed e1211298953706 ∧ code e1211298953706 = 5609345464810 := by decide
theorem cert_e1211298953706 : check e1211298953706 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298953838 : Closed e1211298953838 ∧ code e1211298953838 = 5609345464942 := by decide
theorem cert_e1211298953838 : check e1211298953838 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298953850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298953850 : Closed e1211298953850 ∧ code e1211298953850 = 5609345464954 := by decide
theorem cert_e1211298953850 : check e1211298953850 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298954014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211298954014 : Closed e1211298954014 ∧ code e1211298954014 = 5609345465118 := by decide
theorem cert_e1211298954014 : check e1211298954014 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298954114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298954114 : Closed e1211298954114 ∧ code e1211298954114 = 5609345465218 := by decide
theorem cert_e1211298954114 : check e1211298954114 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298954126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211298954126 : Closed e1211298954126 ∧ code e1211298954126 = 5609345465230 := by decide
theorem cert_e1211298954126 : check e1211298954126 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298954138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298954138 : Closed e1211298954138 ∧ code e1211298954138 = 5609345465242 := by decide
theorem cert_e1211298954138 : check e1211298954138 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298954262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211298954262 : Closed e1211298954262 ∧ code e1211298954262 = 5609345465366 := by decide
theorem cert_e1211298954262 : check e1211298954262 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1211298954358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211298954358 : Closed e1211298954358 ∧ code e1211298954358 = 5609345465462 := by decide
theorem cert_e1211298954358 : check e1211298954358 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .smaller = true := by decide
def e1211298954454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211298954454 : Closed e1211298954454 ∧ code e1211298954454 = 5609345465558 := by decide
private def t_e1211298954454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem cert_e1211298954454 : ¬ IsSelfInterpreter e1211298954454 :=
  wSource (t := t_e1211298954454) (replay_sound (ps := []) (t := e1211298954454) (by decide)) (by decide)
def e1211298954458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211298954458 : Closed e1211298954458 ∧ code e1211298954458 = 5609345465562 := by decide
theorem cert_e1211298954458 : check e1211298954458 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211298954474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211298954474 : Closed e1211298954474 ∧ code e1211298954474 = 5609345465578 := by decide
theorem cert_e1211298954474 : check e1211298954474 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298954550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298954550 : Closed e1211298954550 ∧ code e1211298954550 = 5609345465654 := by decide
private def t_e1211298954550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem cert_e1211298954550 : ¬ IsSelfInterpreter e1211298954550 :=
  wSource (t := t_e1211298954550) (replay_sound (ps := []) (t := e1211298954550) (by decide)) (by decide)
def e1211298954554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298954554 : Closed e1211298954554 ∧ code e1211298954554 = 5609345465658 := by decide
private def t_e1211298954554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem cert_e1211298954554 : ¬ IsSelfInterpreter e1211298954554 :=
  wSource (t := t_e1211298954554) (replay_sound (ps := []) (t := e1211298954554) (by decide)) (by decide)
def e1211298954626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211298954626 : Closed e1211298954626 ∧ code e1211298954626 = 5609345465730 := by decide
theorem cert_e1211298954626 : check e1211298954626 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1211298954638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211298954638 : Closed e1211298954638 ∧ code e1211298954638 = 5609345465742 := by decide
theorem cert_e1211298954638 : check e1211298954638 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298954650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211298954650 : Closed e1211298954650 ∧ code e1211298954650 = 5609345465754 := by decide
theorem cert_e1211298954650 : check e1211298954650 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211298956254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211298956254 : Closed e1211298956254 ∧ code e1211298956254 = 5609345467358 := by decide
private def t_e1211298956254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem cert_e1211298956254 : ¬ IsSelfInterpreter e1211298956254 :=
  wSource (t := t_e1211298956254) (replay_sound (ps := []) (t := e1211298956254) (by decide)) (by decide)
def e1211298956270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211298956270 : Closed e1211298956270 ∧ code e1211298956270 = 5609345467374 := by decide
private def t_e1211298956270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem cert_e1211298956270 : ¬ IsSelfInterpreter e1211298956270 :=
  wSource (t := t_e1211298956270) (replay_sound (ps := []) (t := e1211298956270) (by decide)) (by decide)
def e1211298958190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211298958190 : Closed e1211298958190 ∧ code e1211298958190 = 5609345469294 := by decide
private def t_e1211298958190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1211298958190 : ¬ IsSelfInterpreter e1211298958190 :=
  wSource (t := t_e1211298958190) (replay_sound (ps := []) (t := e1211298958190) (by decide)) (by decide)
def e1211298958198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211298958198 : Closed e1211298958198 ∧ code e1211298958198 = 5609345469302 := by decide
private def t_e1211298958198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1211298958198 : ¬ IsSelfInterpreter e1211298958198 :=
  wSource (t := t_e1211298958198) (replay_sound (ps := []) (t := e1211298958198) (by decide)) (by decide)
def e1211298958254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211298958254 : Closed e1211298958254 ∧ code e1211298958254 = 5609345469358 := by decide
private def t_e1211298958254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1211298958254 : ¬ IsSelfInterpreter e1211298958254 :=
  wSource (t := t_e1211298958254) (replay_sound (ps := []) (t := e1211298958254) (by decide)) (by decide)
def e1211298958266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211298958266 : Closed e1211298958266 ∧ code e1211298958266 = 5609345469370 := by decide
private def t_e1211298958266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1211298958266 : ¬ IsSelfInterpreter e1211298958266 :=
  wSource (t := t_e1211298958266) (replay_sound (ps := []) (t := e1211298958266) (by decide)) (by decide)
def e1211298958294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211298958294 : Closed e1211298958294 ∧ code e1211298958294 = 5609345469398 := by decide
private def t_e1211298958294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1211298958294 : ¬ IsSelfInterpreter e1211298958294 :=
  wSource (t := t_e1211298958294) (replay_sound (ps := []) (t := e1211298958294) (by decide)) (by decide)
def e1211298958298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211298958298 : Closed e1211298958298 ∧ code e1211298958298 = 5609345469402 := by decide
private def t_e1211298958298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1211298958298 : ¬ IsSelfInterpreter e1211298958298 :=
  wSource (t := t_e1211298958298) (replay_sound (ps := []) (t := e1211298958298) (by decide)) (by decide)
def e1211298958574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211298958574 : Closed e1211298958574 ∧ code e1211298958574 = 5609345469678 := by decide
private def t_e1211298958574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211298958574 : ¬ IsSelfInterpreter e1211298958574 :=
  wSource (t := t_e1211298958574) (replay_sound (ps := []) (t := e1211298958574) (by decide)) (by decide)
def e1211298958582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211298958582 : Closed e1211298958582 ∧ code e1211298958582 = 5609345469686 := by decide
private def t_e1211298958582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211298958582 : ¬ IsSelfInterpreter e1211298958582 :=
  wSource (t := t_e1211298958582) (replay_sound (ps := []) (t := e1211298958582) (by decide)) (by decide)
def e1211298958958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298958958 : Closed e1211298958958 ∧ code e1211298958958 = 5609345470062 := by decide
private def t_e1211298958958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211298958958 : ¬ IsSelfInterpreter e1211298958958 :=
  wSource (t := t_e1211298958958) (replay_sound (ps := []) (t := e1211298958958) (by decide)) (by decide)
def e1211298958970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298958970 : Closed e1211298958970 ∧ code e1211298958970 = 5609345470074 := by decide
private def t_e1211298958970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211298958970 : ¬ IsSelfInterpreter e1211298958970 :=
  wSource (t := t_e1211298958970) (replay_sound (ps := []) (t := e1211298958970) (by decide)) (by decide)
def e1211298959158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298959158 : Closed e1211298959158 ∧ code e1211298959158 = 5609345470262 := by decide
private def t_e1211298959158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211298959158 : ¬ IsSelfInterpreter e1211298959158 :=
  wSource (t := t_e1211298959158) (replay_sound (ps := []) (t := e1211298959158) (by decide)) (by decide)
def e1211298959162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298959162 : Closed e1211298959162 ∧ code e1211298959162 = 5609345470266 := by decide
private def t_e1211298959162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211298959162 : ¬ IsSelfInterpreter e1211298959162 :=
  wSource (t := t_e1211298959162) (replay_sound (ps := []) (t := e1211298959162) (by decide)) (by decide)
def e1211298963934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211298963934 : Closed e1211298963934 ∧ code e1211298963934 = 5609345475038 := by decide
theorem cert_e1211298963934 : check e1211298963934 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298963958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211298963958 : Closed e1211298963958 ∧ code e1211298963958 = 5609345475062 := by decide
theorem cert_e1211298963958 : check e1211298963958 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298964910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211298964910 : Closed e1211298964910 ∧ code e1211298964910 = 5609345476014 := by decide
theorem cert_e1211298964910 : check e1211298964910 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298964922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211298964922 : Closed e1211298964922 ∧ code e1211298964922 = 5609345476026 := by decide
theorem cert_e1211298964922 : check e1211298964922 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298964970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211298964970 : Closed e1211298964970 ∧ code e1211298964970 = 5609345476074 := by decide
theorem cert_e1211298964970 : check e1211298964970 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298965102 : Closed e1211298965102 ∧ code e1211298965102 = 5609345476206 := by decide
theorem cert_e1211298965102 : check e1211298965102 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298965114 : Closed e1211298965114 ∧ code e1211298965114 = 5609345476218 := by decide
theorem cert_e1211298965114 : check e1211298965114 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211298965278 : Closed e1211298965278 ∧ code e1211298965278 = 5609345476382 := by decide
theorem cert_e1211298965278 : check e1211298965278 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298965378 : Closed e1211298965378 ∧ code e1211298965378 = 5609345476482 := by decide
theorem cert_e1211298965378 : check e1211298965378 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211298965390 : Closed e1211298965390 ∧ code e1211298965390 = 5609345476494 := by decide
theorem cert_e1211298965390 : check e1211298965390 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298965402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298965402 : Closed e1211298965402 ∧ code e1211298965402 = 5609345476506 := by decide
theorem cert_e1211298965402 : check e1211298965402 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211298967790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211298967790 : Closed e1211298967790 ∧ code e1211298967790 = 5609345478894 := by decide
private def t_e1211298967790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e1211298967790 : ¬ IsSelfInterpreter e1211298967790 :=
  wSource (t := t_e1211298967790) (replay_sound (ps := []) (t := e1211298967790) (by decide)) (by decide)
def e1211298967798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211298967798 : Closed e1211298967798 ∧ code e1211298967798 = 5609345478902 := by decide
private def t_e1211298967798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e1211298967798 : ¬ IsSelfInterpreter e1211298967798 :=
  wSource (t := t_e1211298967798) (replay_sound (ps := []) (t := e1211298967798) (by decide)) (by decide)
def e1211298968278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211298968278 : Closed e1211298968278 ∧ code e1211298968278 = 5609345479382 := by decide
private def t_e1211298968278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1211298968278 : ¬ IsSelfInterpreter e1211298968278 :=
  wSource (t := t_e1211298968278) (replay_sound (ps := []) (t := e1211298968278) (by decide)) (by decide)
def e1211298968282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211298968282 : Closed e1211298968282 ∧ code e1211298968282 = 5609345479386 := by decide
private def t_e1211298968282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e1211298968282 : ¬ IsSelfInterpreter e1211298968282 :=
  wSource (t := t_e1211298968282) (replay_sound (ps := []) (t := e1211298968282) (by decide)) (by decide)
def e1211298968298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211298968298 : Closed e1211298968298 ∧ code e1211298968298 = 5609345479402 := by decide
private def t_e1211298968298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e1211298968298 : ¬ IsSelfInterpreter e1211298968298 :=
  wSource (t := t_e1211298968298) (replay_sound (ps := []) (t := e1211298968298) (by decide)) (by decide)
def e1211298968374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298968374 : Closed e1211298968374 ∧ code e1211298968374 = 5609345479478 := by decide
private def t_e1211298968374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211298968374 : ¬ IsSelfInterpreter e1211298968374 :=
  wSource (t := t_e1211298968374) (replay_sound (ps := []) (t := e1211298968374) (by decide)) (by decide)
def e1211298968378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298968378 : Closed e1211298968378 ∧ code e1211298968378 = 5609345479482 := by decide
private def t_e1211298968378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211298968378 : ¬ IsSelfInterpreter e1211298968378 :=
  wSource (t := t_e1211298968378) (replay_sound (ps := []) (t := e1211298968378) (by decide)) (by decide)
def e1211298968450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211298968450 : Closed e1211298968450 ∧ code e1211298968450 = 5609345479554 := by decide
private def t_e1211298968450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem cert_e1211298968450 : ¬ IsSelfInterpreter e1211298968450 :=
  wSource (t := t_e1211298968450) (replay_sound (ps := []) (t := e1211298968450) (by decide)) (by decide)
def e1211298968462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211298968462 : Closed e1211298968462 ∧ code e1211298968462 = 5609345479566 := by decide
private def t_e1211298968462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem cert_e1211298968462 : ¬ IsSelfInterpreter e1211298968462 :=
  wSource (t := t_e1211298968462) (replay_sound (ps := []) (t := e1211298968462) (by decide)) (by decide)
def e1211298968474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298968474 : Closed e1211298968474 ∧ code e1211298968474 = 5609345479578 := by decide
private def t_e1211298968474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211298968474 : ¬ IsSelfInterpreter e1211298968474 :=
  wSource (t := t_e1211298968474) (replay_sound (ps := []) (t := e1211298968474) (by decide)) (by decide)
def e1211298972270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298972270 : Closed e1211298972270 ∧ code e1211298972270 = 5609345483374 := by decide
theorem cert_e1211298972270 : checkPay e1211298972270 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.right],[.left,.right,.left],[.left,.right]] = true := by decide
def e1211298972282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298972282 : Closed e1211298972282 ∧ code e1211298972282 = 5609345483386 := by decide
def e1211298973550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211298973550 : Closed e1211298973550 ∧ code e1211298973550 = 5609345484654 := by decide
theorem cert_e1211298973550 : checkPay e1211298973550 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298973562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1211298973562 : Closed e1211298973562 ∧ code e1211298973562 = 5609345484666 := by decide
theorem cert_e1211298973562 : checkPay e1211298973562 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left]] = true := by decide
def e1211298973658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1211298973658 : Closed e1211298973658 ∧ code e1211298973658 = 5609345484762 := by decide
theorem cert_e1211298973658 : checkPay e1211298973658 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right,.under]] = true := by decide
def e1211298974958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211298974958 : Closed e1211298974958 ∧ code e1211298974958 = 5609345486062 := by decide
theorem cert_e1211298974958 : checkPay e1211298974958 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.right],[.under,.under,.right,.left]] = true := by decide
def e1211298974966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211298974966 : Closed e1211298974966 ∧ code e1211298974966 = 5609345486070 := by decide
theorem cert_e1211298974966 : checkPay e1211298974966 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.right],[.under,.under,.right,.right]] = true := by decide
def e1211298975342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211298975342 : Closed e1211298975342 ∧ code e1211298975342 = 5609345486446 := by decide
theorem cert_e1211298975342 : checkPay e1211298975342 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298975354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211298975354 : Closed e1211298975354 ∧ code e1211298975354 = 5609345486458 := by decide
theorem cert_e1211298975354 : checkPay e1211298975354 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298975542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211298975542 : Closed e1211298975542 ∧ code e1211298975542 = 5609345486646 := by decide
theorem cert_e1211298975542 : checkPay e1211298975542 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298975546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211298975546 : Closed e1211298975546 ∧ code e1211298975546 = 5609345486650 := by decide
theorem cert_e1211298975546 : checkPay e1211298975546 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1211298977454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211298977454 : Closed e1211298977454 ∧ code e1211298977454 = 5609345488558 := by decide
theorem cert_e1211298977454 : checkPay e1211298977454 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298977466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211298977466 : Closed e1211298977466 ∧ code e1211298977466 = 5609345488570 := by decide
theorem cert_e1211298977466 : checkPay e1211298977466 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left]] = true := by decide
def e1211298977514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211298977514 : Closed e1211298977514 ∧ code e1211298977514 = 5609345488618 := by decide
theorem cert_e1211298977514 : checkPay e1211298977514 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left]] = true := by decide
def e1211298977706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1211298977706 : Closed e1211298977706 ∧ code e1211298977706 = 5609345488810 := by decide
theorem cert_e1211298977706 : checkPay e1211298977706 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.right,.left],[.under,.left,.left,.left,.left,.left,.right]] = true := by decide
def e1211298977838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211298977838 : Closed e1211298977838 ∧ code e1211298977838 = 5609345488942 := by decide
theorem cert_e1211298977838 : checkPay e1211298977838 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211298978030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211298978030 : Closed e1211298978030 ∧ code e1211298978030 = 5609345489134 := by decide
theorem cert_e1211298978030 : checkPay e1211298978030 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left]] = true := by decide
def e1211298978038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211298978038 : Closed e1211298978038 ∧ code e1211298978038 = 5609345489142 := by decide
theorem cert_e1211298978038 : checkPay e1211298978038 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left]] = true := by decide
def e1211298978222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211298978222 : Closed e1211298978222 ∧ code e1211298978222 = 5609345489326 := by decide
theorem cert_e1211298978222 : checkPay e1211298978222 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e1211298978234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211298978234 : Closed e1211298978234 ∧ code e1211298978234 = 5609345489338 := by decide
theorem cert_e1211298978234 : checkPay e1211298978234 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.left]] = true := by decide
end Blc.Floor42
