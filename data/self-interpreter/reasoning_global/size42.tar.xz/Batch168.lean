import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211187493342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211187493342 : Closed e1211187493342 ∧ code e1211187493342 = 5609234004446 := by decide
theorem cert_e1211187493342 : check e1211187493342 [[],[]] .three = true := by decide
def e1211187493366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211187493366 : Closed e1211187493366 ∧ code e1211187493366 = 5609234004470 := by decide
theorem cert_e1211187493366 : check e1211187493366 [[],[]] .three = true := by decide
def e1211187493918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211187493918 : Closed e1211187493918 ∧ code e1211187493918 = 5609234005022 := by decide
theorem cert_e1211187493918 : check e1211187493918 [[],[]] .three = true := by decide
def e1211187494114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211187494114 : Closed e1211187494114 ∧ code e1211187494114 = 5609234005218 := by decide
theorem cert_e1211187494114 : check e1211187494114 [[],[]] .three = true := by decide
def e1211187494126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187494126 : Closed e1211187494126 ∧ code e1211187494126 = 5609234005230 := by decide
theorem cert_e1211187494126 : check e1211187494126 [[],[]] .three = true := by decide
def e1211187494134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187494134 : Closed e1211187494134 ∧ code e1211187494134 = 5609234005238 := by decide
theorem cert_e1211187494134 : check e1211187494134 [[],[]] .three = true := by decide
def e1211187530590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211187530590 : Closed e1211187530590 ∧ code e1211187530590 = 5609234041694 := by decide
theorem cert_e1211187530590 : check e1211187530590 [[],[]] .smaller = true := by decide
def e1211187530606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211187530606 : Closed e1211187530606 ∧ code e1211187530606 = 5609234041710 := by decide
theorem cert_e1211187530606 : check e1211187530606 [[],[]] .smaller = true := by decide
def e1211187530614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211187530614 : Closed e1211187530614 ∧ code e1211187530614 = 5609234041718 := by decide
theorem cert_e1211187530614 : check e1211187530614 [[],[]] .smaller = true := by decide
def e1211187530618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211187530618 : Closed e1211187530618 ∧ code e1211187530618 = 5609234041722 := by decide
theorem cert_e1211187530618 : check e1211187530618 [[],[]] .smaller = true := by decide
def e1211187530670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211187530670 : Closed e1211187530670 ∧ code e1211187530670 = 5609234041774 := by decide
theorem cert_e1211187530670 : check e1211187530670 [[],[]] .smaller = true := by decide
def e1211187530682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211187530682 : Closed e1211187530682 ∧ code e1211187530682 = 5609234041786 := by decide
theorem cert_e1211187530682 : check e1211187530682 [[],[]] .smaller = true := by decide
def e1211187530710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211187530710 : Closed e1211187530710 ∧ code e1211187530710 = 5609234041814 := by decide
theorem cert_e1211187530710 : check e1211187530710 [[],[]] .smaller = true := by decide
def e1211187530714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211187530714 : Closed e1211187530714 ∧ code e1211187530714 = 5609234041818 := by decide
theorem cert_e1211187530714 : check e1211187530714 [[],[]] .smaller = true := by decide
def e1211187530730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211187530730 : Closed e1211187530730 ∧ code e1211187530730 = 5609234041834 := by decide
theorem cert_e1211187530730 : check e1211187530730 [[],[]] .smaller = true := by decide
def e1211187530974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187530974 : Closed e1211187530974 ∧ code e1211187530974 = 5609234042078 := by decide
theorem cert_e1211187530974 : check e1211187530974 [[],[]] .smaller = true := by decide
def e1211187530990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211187530990 : Closed e1211187530990 ∧ code e1211187530990 = 5609234042094 := by decide
theorem cert_e1211187530990 : check e1211187530990 [[],[]] .smaller = true := by decide
def e1211187530998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211187530998 : Closed e1211187530998 ∧ code e1211187530998 = 5609234042102 := by decide
theorem cert_e1211187530998 : check e1211187530998 [[],[]] .smaller = true := by decide
def e1211187531002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187531002 : Closed e1211187531002 ∧ code e1211187531002 = 5609234042106 := by decide
theorem cert_e1211187531002 : check e1211187531002 [[],[]] .smaller = true := by decide
def e1211187531326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211187531326 : Closed e1211187531326 ∧ code e1211187531326 = 5609234042430 := by decide
theorem cert_e1211187531326 : check e1211187531326 [[],[]] .smaller = true := by decide
def e1211187531374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187531374 : Closed e1211187531374 ∧ code e1211187531374 = 5609234042478 := by decide
theorem cert_e1211187531374 : check e1211187531374 [[],[]] .smaller = true := by decide
def e1211187531386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187531386 : Closed e1211187531386 ∧ code e1211187531386 = 5609234042490 := by decide
theorem cert_e1211187531386 : check e1211187531386 [[],[]] .smaller = true := by decide
def e1211187531574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187531574 : Closed e1211187531574 ∧ code e1211187531574 = 5609234042678 := by decide
theorem cert_e1211187531574 : check e1211187531574 [[],[]] .smaller = true := by decide
def e1211187531578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187531578 : Closed e1211187531578 ∧ code e1211187531578 = 5609234042682 := by decide
theorem cert_e1211187531578 : check e1211187531578 [[],[]] .smaller = true := by decide
def e1211187531662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211187531662 : Closed e1211187531662 ∧ code e1211187531662 = 5609234042766 := by decide
theorem cert_e1211187531662 : check e1211187531662 [[],[]] .smaller = true := by decide
def e1211187531674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187531674 : Closed e1211187531674 ∧ code e1211187531674 = 5609234042778 := by decide
theorem cert_e1211187531674 : check e1211187531674 [[],[]] .smaller = true := by decide
def e1211187539038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211187539038 : Closed e1211187539038 ∧ code e1211187539038 = 5609234050142 := by decide
theorem cert_e1211187539038 : check e1211187539038 [[],[]] .three = true := by decide
def e1211187539054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211187539054 : Closed e1211187539054 ∧ code e1211187539054 = 5609234050158 := by decide
theorem cert_e1211187539054 : check e1211187539054 [[],[]] .smaller = true := by decide
def e1211187539066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211187539066 : Closed e1211187539066 ∧ code e1211187539066 = 5609234050170 := by decide
theorem cert_e1211187539066 : check e1211187539066 [[],[]] .smaller = true := by decide
def e1211187539230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211187539230 : Closed e1211187539230 ∧ code e1211187539230 = 5609234050334 := by decide
theorem cert_e1211187539230 : check e1211187539230 [[],[]] .smaller = true := by decide
def e1211187539398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211187539398 : Closed e1211187539398 ∧ code e1211187539398 = 5609234050502 := by decide
theorem cert_e1211187539398 : check e1211187539398 [[],[]] .smaller = true := by decide
def e1211187539422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211187539422 : Closed e1211187539422 ∧ code e1211187539422 = 5609234050526 := by decide
theorem cert_e1211187539422 : check e1211187539422 [[],[]] .three = true := by decide
def e1211187539426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211187539426 : Closed e1211187539426 ∧ code e1211187539426 = 5609234050530 := by decide
theorem cert_e1211187539426 : check e1211187539426 [[],[]] .three = true := by decide
def e1211187539438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211187539438 : Closed e1211187539438 ∧ code e1211187539438 = 5609234050542 := by decide
theorem cert_e1211187539438 : check e1211187539438 [[],[]] .three = true := by decide
def e1211187539502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e1211187539502 : Closed e1211187539502 ∧ code e1211187539502 = 5609234050606 := by decide
theorem cert_e1211187539502 : check e1211187539502 [[],[]] .smaller = true := by decide
def e1211187539678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211187539678 : Closed e1211187539678 ∧ code e1211187539678 = 5609234050782 := by decide
theorem cert_e1211187539678 : check e1211187539678 [[],[]] .three = true := by decide
def e1211187539682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e1211187539682 : Closed e1211187539682 ∧ code e1211187539682 = 5609234050786 := by decide
theorem cert_e1211187539682 : check e1211187539682 [[],[]] .smaller = true := by decide
def e1211187539694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211187539694 : Closed e1211187539694 ∧ code e1211187539694 = 5609234050798 := by decide
theorem cert_e1211187539694 : check e1211187539694 [[],[]] .smaller = true := by decide
def e1211187539702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211187539702 : Closed e1211187539702 ∧ code e1211187539702 = 5609234050806 := by decide
theorem cert_e1211187539702 : check e1211187539702 [[],[]] .three = true := by decide
def e1211187539734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211187539734 : Closed e1211187539734 ∧ code e1211187539734 = 5609234050838 := by decide
theorem cert_e1211187539734 : check e1211187539734 [[],[]] .smaller = true := by decide
def e1211187539738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211187539738 : Closed e1211187539738 ∧ code e1211187539738 = 5609234050842 := by decide
theorem cert_e1211187539738 : check e1211187539738 [[],[]] .smaller = true := by decide
def e1211187539782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211187539782 : Closed e1211187539782 ∧ code e1211187539782 = 5609234050886 := by decide
theorem cert_e1211187539782 : check e1211187539782 [[],[]] .smaller = true := by decide
def e1211187539806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211187539806 : Closed e1211187539806 ∧ code e1211187539806 = 5609234050910 := by decide
theorem cert_e1211187539806 : check e1211187539806 [[],[]] .three = true := by decide
def e1211187539810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211187539810 : Closed e1211187539810 ∧ code e1211187539810 = 5609234050914 := by decide
theorem cert_e1211187539810 : check e1211187539810 [[],[]] .smaller = true := by decide
def e1211187539822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211187539822 : Closed e1211187539822 ∧ code e1211187539822 = 5609234050926 := by decide
theorem cert_e1211187539822 : check e1211187539822 [[],[]] .smaller = true := by decide
def e1211187539830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211187539830 : Closed e1211187539830 ∧ code e1211187539830 = 5609234050934 := by decide
theorem cert_e1211187539830 : check e1211187539830 [[],[]] .smaller = true := by decide
def e1211187539834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211187539834 : Closed e1211187539834 ∧ code e1211187539834 = 5609234050938 := by decide
theorem cert_e1211187539834 : check e1211187539834 [[],[]] .three = true := by decide
def e1211187539850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211187539850 : Closed e1211187539850 ∧ code e1211187539850 = 5609234050954 := by decide
theorem cert_e1211187539850 : check e1211187539850 [[],[]] .three = true := by decide
def e1211187539874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211187539874 : Closed e1211187539874 ∧ code e1211187539874 = 5609234050978 := by decide
theorem cert_e1211187539874 : check e1211187539874 [[],[]] .three = true := by decide
def e1211187539886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211187539886 : Closed e1211187539886 ∧ code e1211187539886 = 5609234050990 := by decide
theorem cert_e1211187539886 : check e1211187539886 [[],[]] .three = true := by decide
def e1211187539894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211187539894 : Closed e1211187539894 ∧ code e1211187539894 = 5609234050998 := by decide
theorem cert_e1211187539894 : check e1211187539894 [[],[]] .three = true := by decide
def e1211187539898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211187539898 : Closed e1211187539898 ∧ code e1211187539898 = 5609234051002 := by decide
theorem cert_e1211187539898 : check e1211187539898 [[],[]] .three = true := by decide
def e1211187540094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211187540094 : Closed e1211187540094 ∧ code e1211187540094 = 5609234051198 := by decide
theorem cert_e1211187540094 : check e1211187540094 [[],[]] .three = true := by decide
def e1211187540190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187540190 : Closed e1211187540190 ∧ code e1211187540190 = 5609234051294 := by decide
theorem cert_e1211187540190 : check e1211187540190 [[],[]] .smaller = true := by decide
def e1211187540218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187540218 : Closed e1211187540218 ∧ code e1211187540218 = 5609234051322 := by decide
theorem cert_e1211187540218 : check e1211187540218 [[],[]] .smaller = true := by decide
def e1211187540766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211187540766 : Closed e1211187540766 ∧ code e1211187540766 = 5609234051870 := by decide
theorem cert_e1211187540766 : check e1211187540766 [[],[]] .smaller = true := by decide
def e1211187540934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211187540934 : Closed e1211187540934 ∧ code e1211187540934 = 5609234052038 := by decide
theorem cert_e1211187540934 : check e1211187540934 [[],[]] .smaller = true := by decide
def e1211187540958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211187540958 : Closed e1211187540958 ∧ code e1211187540958 = 5609234052062 := by decide
theorem cert_e1211187540958 : check e1211187540958 [[],[]] .three = true := by decide
def e1211187540962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211187540962 : Closed e1211187540962 ∧ code e1211187540962 = 5609234052066 := by decide
theorem cert_e1211187540962 : check e1211187540962 [[],[]] .three = true := by decide
def e1211187540974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211187540974 : Closed e1211187540974 ∧ code e1211187540974 = 5609234052078 := by decide
theorem cert_e1211187540974 : check e1211187540974 [[],[]] .three = true := by decide
def e1211187542078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e1211187542078 : Closed e1211187542078 ∧ code e1211187542078 = 5609234053182 := by decide
theorem cert_e1211187542078 : check e1211187542078 [[],[]] .smaller = true := by decide
def e1211187542494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211187542494 : Closed e1211187542494 ∧ code e1211187542494 = 5609234053598 := by decide
theorem cert_e1211187542494 : check e1211187542494 [[],[]] .three = true := by decide
def e1211187542498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211187542498 : Closed e1211187542498 ∧ code e1211187542498 = 5609234053602 := by decide
theorem cert_e1211187542498 : check e1211187542498 [[],[]] .smaller = true := by decide
def e1211187542510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211187542510 : Closed e1211187542510 ∧ code e1211187542510 = 5609234053614 := by decide
theorem cert_e1211187542510 : check e1211187542510 [[],[]] .smaller = true := by decide
def e1211187542518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211187542518 : Closed e1211187542518 ∧ code e1211187542518 = 5609234053622 := by decide
theorem cert_e1211187542518 : check e1211187542518 [[],[]] .three = true := by decide
def e1211187543070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211187543070 : Closed e1211187543070 ∧ code e1211187543070 = 5609234054174 := by decide
theorem cert_e1211187543070 : check e1211187543070 [[],[]] .smaller = true := by decide
def e1211187543094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187543094 : Closed e1211187543094 ∧ code e1211187543094 = 5609234054198 := by decide
theorem cert_e1211187543094 : check e1211187543094 [[],[]] .smaller = true := by decide
def e1211187543098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187543098 : Closed e1211187543098 ∧ code e1211187543098 = 5609234054202 := by decide
theorem cert_e1211187543098 : check e1211187543098 [[],[]] .smaller = true := by decide
def e1211187543238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211187543238 : Closed e1211187543238 ∧ code e1211187543238 = 5609234054342 := by decide
theorem cert_e1211187543238 : check e1211187543238 [[],[]] .smaller = true := by decide
def e1211187543262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187543262 : Closed e1211187543262 ∧ code e1211187543262 = 5609234054366 := by decide
theorem cert_e1211187543262 : check e1211187543262 [[],[]] .three = true := by decide
def e1211187543266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211187543266 : Closed e1211187543266 ∧ code e1211187543266 = 5609234054370 := by decide
theorem cert_e1211187543266 : check e1211187543266 [[],[]] .smaller = true := by decide
def e1211187543278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187543278 : Closed e1211187543278 ∧ code e1211187543278 = 5609234054382 := by decide
theorem cert_e1211187543278 : check e1211187543278 [[],[]] .smaller = true := by decide
def e1211187543286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187543286 : Closed e1211187543286 ∧ code e1211187543286 = 5609234054390 := by decide
theorem cert_e1211187543286 : check e1211187543286 [[],[]] .smaller = true := by decide
def e1211187543290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187543290 : Closed e1211187543290 ∧ code e1211187543290 = 5609234054394 := by decide
theorem cert_e1211187543290 : check e1211187543290 [[],[]] .three = true := by decide
def e1211187543566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211187543566 : Closed e1211187543566 ∧ code e1211187543566 = 5609234054670 := by decide
theorem cert_e1211187543566 : check e1211187543566 [[],[]] .three = true := by decide
def e1211187543578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187543578 : Closed e1211187543578 ∧ code e1211187543578 = 5609234054682 := by decide
theorem cert_e1211187543578 : check e1211187543578 [[],[]] .three = true := by decide
def e1211187543614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e1211187543614 : Closed e1211187543614 ∧ code e1211187543614 = 5609234054718 := by decide
theorem cert_e1211187543614 : check e1211187543614 [[],[]] .three = true := by decide
def e1211187543650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211187543650 : Closed e1211187543650 ∧ code e1211187543650 = 5609234054754 := by decide
theorem cert_e1211187543650 : check e1211187543650 [[],[]] .three = true := by decide
def e1211187543662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211187543662 : Closed e1211187543662 ∧ code e1211187543662 = 5609234054766 := by decide
theorem cert_e1211187543662 : check e1211187543662 [[],[]] .three = true := by decide
def e1211187543670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211187543670 : Closed e1211187543670 ∧ code e1211187543670 = 5609234054774 := by decide
theorem cert_e1211187543670 : check e1211187543670 [[],[]] .three = true := by decide
def e1211187543674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211187543674 : Closed e1211187543674 ∧ code e1211187543674 = 5609234054778 := by decide
theorem cert_e1211187543674 : check e1211187543674 [[],[]] .three = true := by decide
def e1211187561902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211187561902 : Closed e1211187561902 ∧ code e1211187561902 = 5609234073006 := by decide
theorem cert_e1211187561902 : check e1211187561902 [[],[]] .smaller = true := by decide
def e1211187561914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211187561914 : Closed e1211187561914 ∧ code e1211187561914 = 5609234073018 := by decide
theorem cert_e1211187561914 : check e1211187561914 [[],[]] .smaller = true := by decide
def e1211187561962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211187561962 : Closed e1211187561962 ∧ code e1211187561962 = 5609234073066 := by decide
theorem cert_e1211187561962 : check e1211187561962 [[],[]] .smaller = true := by decide
def e1211187562094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187562094 : Closed e1211187562094 ∧ code e1211187562094 = 5609234073198 := by decide
theorem cert_e1211187562094 : check e1211187562094 [[],[]] .smaller = true := by decide
def e1211187562106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187562106 : Closed e1211187562106 ∧ code e1211187562106 = 5609234073210 := by decide
theorem cert_e1211187562106 : check e1211187562106 [[],[]] .smaller = true := by decide
def e1211187562270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211187562270 : Closed e1211187562270 ∧ code e1211187562270 = 5609234073374 := by decide
theorem cert_e1211187562270 : check e1211187562270 [[],[]] .smaller = true := by decide
def e1211187562382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211187562382 : Closed e1211187562382 ∧ code e1211187562382 = 5609234073486 := by decide
theorem cert_e1211187562382 : check e1211187562382 [[],[]] .smaller = true := by decide
def e1211187562394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187562394 : Closed e1211187562394 ∧ code e1211187562394 = 5609234073498 := by decide
theorem cert_e1211187562394 : check e1211187562394 [[],[]] .smaller = true := by decide
def e1211187566134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211187566134 : Closed e1211187566134 ∧ code e1211187566134 = 5609234077238 := by decide
theorem cert_e1211187566134 : check e1211187566134 [[],[]] .smaller = true := by decide
def e1211187566138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211187566138 : Closed e1211187566138 ∧ code e1211187566138 = 5609234077242 := by decide
theorem cert_e1211187566138 : check e1211187566138 [[],[]] .smaller = true := by decide
def e1211187566222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211187566222 : Closed e1211187566222 ∧ code e1211187566222 = 5609234077326 := by decide
theorem cert_e1211187566222 : check e1211187566222 [[],[]] .smaller = true := by decide
def e1211187566278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211187566278 : Closed e1211187566278 ∧ code e1211187566278 = 5609234077382 := by decide
theorem cert_e1211187566278 : check e1211187566278 [[],[]] .smaller = true := by decide
def e1211187566302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211187566302 : Closed e1211187566302 ∧ code e1211187566302 = 5609234077406 := by decide
theorem cert_e1211187566302 : check e1211187566302 [[],[]] .three = true := by decide
def e1211187566326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211187566326 : Closed e1211187566326 ∧ code e1211187566326 = 5609234077430 := by decide
theorem cert_e1211187566326 : check e1211187566326 [[],[]] .three = true := by decide
def e1211187566358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211187566358 : Closed e1211187566358 ∧ code e1211187566358 = 5609234077462 := by decide
theorem cert_e1211187566358 : check e1211187566358 [[],[]] .smaller = true := by decide
def e1211187566362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211187566362 : Closed e1211187566362 ∧ code e1211187566362 = 5609234077466 := by decide
theorem cert_e1211187566362 : check e1211187566362 [[],[]] .smaller = true := by decide
def e1211187566406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211187566406 : Closed e1211187566406 ∧ code e1211187566406 = 5609234077510 := by decide
theorem cert_e1211187566406 : check e1211187566406 [[],[]] .smaller = true := by decide
def e1211187566430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211187566430 : Closed e1211187566430 ∧ code e1211187566430 = 5609234077534 := by decide
theorem cert_e1211187566430 : check e1211187566430 [[],[]] .three = true := by decide
def e1211187566434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211187566434 : Closed e1211187566434 ∧ code e1211187566434 = 5609234077538 := by decide
theorem cert_e1211187566434 : check e1211187566434 [[],[]] .smaller = true := by decide
def e1211187566446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211187566446 : Closed e1211187566446 ∧ code e1211187566446 = 5609234077550 := by decide
theorem cert_e1211187566446 : check e1211187566446 [[],[]] .smaller = true := by decide
def e1211187566454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211187566454 : Closed e1211187566454 ∧ code e1211187566454 = 5609234077558 := by decide
theorem cert_e1211187566454 : check e1211187566454 [[],[]] .smaller = true := by decide
def e1211187566458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211187566458 : Closed e1211187566458 ∧ code e1211187566458 = 5609234077562 := by decide
theorem cert_e1211187566458 : check e1211187566458 [[],[]] .three = true := by decide
def e1211187566518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211187566518 : Closed e1211187566518 ∧ code e1211187566518 = 5609234077622 := by decide
theorem cert_e1211187566518 : check e1211187566518 [[],[]] .smaller = true := by decide
def e1211187566550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211187566550 : Closed e1211187566550 ∧ code e1211187566550 = 5609234077654 := by decide
theorem cert_e1211187566550 : check e1211187566550 [[],[]] .three = true := by decide
def e1211187566554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211187566554 : Closed e1211187566554 ∧ code e1211187566554 = 5609234077658 := by decide
theorem cert_e1211187566554 : check e1211187566554 [[],[]] .three = true := by decide
def e1211187566702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187566702 : Closed e1211187566702 ∧ code e1211187566702 = 5609234077806 := by decide
theorem cert_e1211187566702 : check e1211187566702 [[],[]] .smaller = true := by decide
def e1211187566714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187566714 : Closed e1211187566714 ∧ code e1211187566714 = 5609234077818 := by decide
theorem cert_e1211187566714 : check e1211187566714 [[],[]] .smaller = true := by decide
def e1211187566990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211187566990 : Closed e1211187566990 ∧ code e1211187566990 = 5609234078094 := by decide
theorem cert_e1211187566990 : check e1211187566990 [[],[]] .smaller = true := by decide
def e1211187567046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211187567046 : Closed e1211187567046 ∧ code e1211187567046 = 5609234078150 := by decide
theorem cert_e1211187567046 : check e1211187567046 [[],[]] .smaller = true := by decide
def e1211187567070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211187567070 : Closed e1211187567070 ∧ code e1211187567070 = 5609234078174 := by decide
theorem cert_e1211187567070 : check e1211187567070 [[],[]] .three = true := by decide
def e1211187567094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211187567094 : Closed e1211187567094 ∧ code e1211187567094 = 5609234078198 := by decide
theorem cert_e1211187567094 : check e1211187567094 [[],[]] .three = true := by decide
def e1211187567646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211187567646 : Closed e1211187567646 ∧ code e1211187567646 = 5609234078750 := by decide
theorem cert_e1211187567646 : check e1211187567646 [[],[]] .smaller = true := by decide
def e1211187567670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187567670 : Closed e1211187567670 ∧ code e1211187567670 = 5609234078774 := by decide
theorem cert_e1211187567670 : check e1211187567670 [[],[]] .smaller = true := by decide
def e1211187567674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187567674 : Closed e1211187567674 ∧ code e1211187567674 = 5609234078778 := by decide
theorem cert_e1211187567674 : check e1211187567674 [[],[]] .smaller = true := by decide
def e1211187567814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211187567814 : Closed e1211187567814 ∧ code e1211187567814 = 5609234078918 := by decide
theorem cert_e1211187567814 : check e1211187567814 [[],[]] .smaller = true := by decide
def e1211187567838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187567838 : Closed e1211187567838 ∧ code e1211187567838 = 5609234078942 := by decide
theorem cert_e1211187567838 : check e1211187567838 [[],[]] .three = true := by decide
def e1211187567842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211187567842 : Closed e1211187567842 ∧ code e1211187567842 = 5609234078946 := by decide
theorem cert_e1211187567842 : check e1211187567842 [[],[]] .smaller = true := by decide
def e1211187567854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187567854 : Closed e1211187567854 ∧ code e1211187567854 = 5609234078958 := by decide
theorem cert_e1211187567854 : check e1211187567854 [[],[]] .smaller = true := by decide
def e1211187567862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187567862 : Closed e1211187567862 ∧ code e1211187567862 = 5609234078966 := by decide
theorem cert_e1211187567862 : check e1211187567862 [[],[]] .smaller = true := by decide
def e1211187567866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187567866 : Closed e1211187567866 ∧ code e1211187567866 = 5609234078970 := by decide
theorem cert_e1211187567866 : check e1211187567866 [[],[]] .three = true := by decide
def e1211187568190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211187568190 : Closed e1211187568190 ∧ code e1211187568190 = 5609234079294 := by decide
theorem cert_e1211187568190 : check e1211187568190 [[],[]] .three = true := by decide
def e1211187568246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211187568246 : Closed e1211187568246 ∧ code e1211187568246 = 5609234079350 := by decide
theorem cert_e1211187568246 : check e1211187568246 [[],[]] .smaller = true := by decide
def e1211187568414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211187568414 : Closed e1211187568414 ∧ code e1211187568414 = 5609234079518 := by decide
theorem cert_e1211187568414 : check e1211187568414 [[],[]] .three = true := by decide
def e1211187568438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187568438 : Closed e1211187568438 ∧ code e1211187568438 = 5609234079542 := by decide
theorem cert_e1211187568438 : check e1211187568438 [[],[]] .three = true := by decide
def e1211187568442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187568442 : Closed e1211187568442 ∧ code e1211187568442 = 5609234079546 := by decide
theorem cert_e1211187568442 : check e1211187568442 [[],[]] .three = true := by decide
def e1211187579670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211187579670 : Closed e1211187579670 ∧ code e1211187579670 = 5609234090774 := by decide
theorem cert_e1211187579670 : check e1211187579670 [[],[]] .three = true := by decide
def e1211187579746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211187579746 : Closed e1211187579746 ∧ code e1211187579746 = 5609234090850 := by decide
theorem cert_e1211187579746 : check e1211187579746 [[],[]] .three = true := by decide
def e1211187579758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211187579758 : Closed e1211187579758 ∧ code e1211187579758 = 5609234090862 := by decide
theorem cert_e1211187579758 : check e1211187579758 [[],[]] .three = true := by decide
def e1211187579766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211187579766 : Closed e1211187579766 ∧ code e1211187579766 = 5609234090870 := by decide
theorem cert_e1211187579766 : check e1211187579766 [[],[]] .three = true := by decide
def e1211187579786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211187579786 : Closed e1211187579786 ∧ code e1211187579786 = 5609234090890 := by decide
theorem cert_e1211187579786 : check e1211187579786 [[],[]] .three = true := by decide
def e1211187579810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211187579810 : Closed e1211187579810 ∧ code e1211187579810 = 5609234090914 := by decide
theorem cert_e1211187579810 : check e1211187579810 [[],[]] .three = true := by decide
def e1211187579822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211187579822 : Closed e1211187579822 ∧ code e1211187579822 = 5609234090926 := by decide
theorem cert_e1211187579822 : check e1211187579822 [[],[]] .three = true := by decide
def e1211187579830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e1211187579830 : Closed e1211187579830 ∧ code e1211187579830 = 5609234090934 := by decide
theorem cert_e1211187579830 : check e1211187579830 [[],[]] .three = true := by decide
def e1211187579834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211187579834 : Closed e1211187579834 ∧ code e1211187579834 = 5609234090938 := by decide
theorem cert_e1211187579834 : check e1211187579834 [[],[]] .three = true := by decide
def e1211187579862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211187579862 : Closed e1211187579862 ∧ code e1211187579862 = 5609234090966 := by decide
theorem cert_e1211187579862 : check e1211187579862 [[],[]] .three = true := by decide
def e1211187579866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211187579866 : Closed e1211187579866 ∧ code e1211187579866 = 5609234090970 := by decide
theorem cert_e1211187579866 : check e1211187579866 [[],[]] .three = true := by decide
def e1211187579934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211187579934 : Closed e1211187579934 ∧ code e1211187579934 = 5609234091038 := by decide
theorem cert_e1211187579934 : check e1211187579934 [[],[]] .three = true := by decide
def e1211187580130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211187580130 : Closed e1211187580130 ∧ code e1211187580130 = 5609234091234 := by decide
theorem cert_e1211187580130 : check e1211187580130 [[],[]] .three = true := by decide
def e1211187580142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187580142 : Closed e1211187580142 ∧ code e1211187580142 = 5609234091246 := by decide
theorem cert_e1211187580142 : check e1211187580142 [[],[]] .three = true := by decide
def e1211187580150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187580150 : Closed e1211187580150 ∧ code e1211187580150 = 5609234091254 := by decide
theorem cert_e1211187580150 : check e1211187580150 [[],[]] .three = true := by decide
def e1211187580430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211187580430 : Closed e1211187580430 ∧ code e1211187580430 = 5609234091534 := by decide
theorem cert_e1211187580430 : check e1211187580430 [[],[]] .three = true := by decide
def e1211187580442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211187580442 : Closed e1211187580442 ∧ code e1211187580442 = 5609234091546 := by decide
theorem cert_e1211187580442 : check e1211187580442 [[],[]] .three = true := by decide
def e1211187580478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211187580478 : Closed e1211187580478 ∧ code e1211187580478 = 5609234091582 := by decide
theorem cert_e1211187580478 : check e1211187580478 [[],[]] .three = true := by decide
def e1211187580514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211187580514 : Closed e1211187580514 ∧ code e1211187580514 = 5609234091618 := by decide
theorem cert_e1211187580514 : check e1211187580514 [[],[]] .three = true := by decide
def e1211187580526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211187580526 : Closed e1211187580526 ∧ code e1211187580526 = 5609234091630 := by decide
theorem cert_e1211187580526 : check e1211187580526 [[],[]] .three = true := by decide
def e1211187580534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211187580534 : Closed e1211187580534 ∧ code e1211187580534 = 5609234091638 := by decide
theorem cert_e1211187580534 : check e1211187580534 [[],[]] .three = true := by decide
def e1211187580538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211187580538 : Closed e1211187580538 ∧ code e1211187580538 = 5609234091642 := by decide
theorem cert_e1211187580538 : check e1211187580538 [[],[]] .three = true := by decide
def e1211187580702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211187580702 : Closed e1211187580702 ∧ code e1211187580702 = 5609234091806 := by decide
theorem cert_e1211187580702 : check e1211187580702 [[],[]] .three = true := by decide
def e1211187580726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187580726 : Closed e1211187580726 ∧ code e1211187580726 = 5609234091830 := by decide
theorem cert_e1211187580726 : check e1211187580726 [[],[]] .three = true := by decide
def e1211187580730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187580730 : Closed e1211187580730 ∧ code e1211187580730 = 5609234091834 := by decide
theorem cert_e1211187580730 : check e1211187580730 [[],[]] .three = true := by decide
def e1211187580814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211187580814 : Closed e1211187580814 ∧ code e1211187580814 = 5609234091918 := by decide
theorem cert_e1211187580814 : check e1211187580814 [[],[]] .three = true := by decide
def e1211188129246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e1211188129246 : Closed e1211188129246 ∧ code e1211188129246 = 5609234640350 := by decide
theorem cert_e1211188129246 : check e1211188129246 [[],[]] .smaller = true := by decide
def e1211188129262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e1211188129262 : Closed e1211188129262 ∧ code e1211188129262 = 5609234640366 := by decide
theorem cert_e1211188129262 : check e1211188129262 [[],[]] .smaller = true := by decide
def e1211188129630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e1211188129630 : Closed e1211188129630 ∧ code e1211188129630 = 5609234640734 := by decide
theorem cert_e1211188129630 : check e1211188129630 [[],[]] .smaller = true := by decide
def e1211188129658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e1211188129658 : Closed e1211188129658 ∧ code e1211188129658 = 5609234640762 := by decide
theorem cert_e1211188129658 : check e1211188129658 [[],[]] .smaller = true := by decide
def e1211188129710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e1211188129710 : Closed e1211188129710 ∧ code e1211188129710 = 5609234640814 := by decide
theorem cert_e1211188129710 : check e1211188129710 [[],[]] .smaller = true := by decide
def e1211188129722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e1211188129722 : Closed e1211188129722 ∧ code e1211188129722 = 5609234640826 := by decide
theorem cert_e1211188129722 : check e1211188129722 [[],[]] .smaller = true := by decide
def e1211188130782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211188130782 : Closed e1211188130782 ∧ code e1211188130782 = 5609234641886 := by decide
theorem cert_e1211188130782 : check e1211188130782 [[],[]] .smaller = true := by decide
def e1211188130798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211188130798 : Closed e1211188130798 ∧ code e1211188130798 = 5609234641902 := by decide
theorem cert_e1211188130798 : check e1211188130798 [[],[]] .smaller = true := by decide
end Blc.Floor42
