import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131193408758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131193408758 : Closed e1131193408758 ∧ code e1131193408758 = 5529239919862 := by decide
theorem cert_e1131193408758 : check e1131193408758 [[],[.under]] .chain = true := by decide
def e1131193409142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131193409142 : Closed e1131193409142 ∧ code e1131193409142 = 5529239920246 := by decide
theorem cert_e1131193409142 : check e1131193409142 [[],[.under]] .chain = true := by decide
def e1131193420654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131193420654 : Closed e1131193420654 ∧ code e1131193420654 = 5529239931758 := by decide
theorem cert_e1131193420654 : check e1131193420654 [[],[.under]] .chain = true := by decide
def e1131193420662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131193420662 : Closed e1131193420662 ∧ code e1131193420662 = 5529239931766 := by decide
theorem cert_e1131193420662 : check e1131193420662 [[],[.under]] .chain = true := by decide
def e1131193420718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131193420718 : Closed e1131193420718 ∧ code e1131193420718 = 5529239931822 := by decide
theorem cert_e1131193420718 : check e1131193420718 [[],[.under]] .chain = true := by decide
def e1131193420730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131193420730 : Closed e1131193420730 ∧ code e1131193420730 = 5529239931834 := by decide
theorem cert_e1131193420730 : check e1131193420730 [[],[.under]] .chain = true := by decide
def e1131193420758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131193420758 : Closed e1131193420758 ∧ code e1131193420758 = 5529239931862 := by decide
theorem cert_e1131193420758 : check e1131193420758 [[],[.under]] .chain = true := by decide
def e1131193420762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131193420762 : Closed e1131193420762 ∧ code e1131193420762 = 5529239931866 := by decide
theorem cert_e1131193420762 : check e1131193420762 [[],[.under]] .chain = true := by decide
def e1131193421038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131193421038 : Closed e1131193421038 ∧ code e1131193421038 = 5529239932142 := by decide
theorem cert_e1131193421038 : check e1131193421038 [[],[.under]] .chain = true := by decide
def e1131193421046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131193421046 : Closed e1131193421046 ∧ code e1131193421046 = 5529239932150 := by decide
theorem cert_e1131193421046 : check e1131193421046 [[],[.under]] .chain = true := by decide
def e1131193421422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131193421422 : Closed e1131193421422 ∧ code e1131193421422 = 5529239932526 := by decide
theorem cert_e1131193421422 : check e1131193421422 [[],[.under]] .chain = true := by decide
def e1131193421434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131193421434 : Closed e1131193421434 ∧ code e1131193421434 = 5529239932538 := by decide
theorem cert_e1131193421434 : check e1131193421434 [[],[.under]] .chain = true := by decide
def e1131193421622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131193421622 : Closed e1131193421622 ∧ code e1131193421622 = 5529239932726 := by decide
theorem cert_e1131193421622 : check e1131193421622 [[],[.under]] .chain = true := by decide
def e1131193421626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131193421626 : Closed e1131193421626 ∧ code e1131193421626 = 5529239932730 := by decide
theorem cert_e1131193421626 : check e1131193421626 [[],[.under]] .chain = true := by decide
def e1131193427382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1131193427382 : Closed e1131193427382 ∧ code e1131193427382 = 5529239938486 := by decide
theorem cert_e1131193427382 : check e1131193427382 [[],[.under]] .chain = true := by decide
def e1131193427414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1131193427414 : Closed e1131193427414 ∧ code e1131193427414 = 5529239938518 := by decide
theorem cert_e1131193427414 : check e1131193427414 [[],[.under]] .chain = true := by decide
def e1131193427418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1131193427418 : Closed e1131193427418 ∧ code e1131193427418 = 5529239938522 := by decide
theorem cert_e1131193427418 : check e1131193427418 [[],[.under]] .chain = true := by decide
def e1131193427574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131193427574 : Closed e1131193427574 ∧ code e1131193427574 = 5529239938678 := by decide
theorem cert_e1131193427574 : check e1131193427574 [[],[.under]] .chain = true := by decide
def e1131193427766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131193427766 : Closed e1131193427766 ∧ code e1131193427766 = 5529239938870 := by decide
theorem cert_e1131193427766 : check e1131193427766 [[],[.under]] .chain = true := by decide
def e1131193427770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131193427770 : Closed e1131193427770 ∧ code e1131193427770 = 5529239938874 := by decide
theorem cert_e1131193427770 : check e1131193427770 [[],[.under]] .chain = true := by decide
def e1131193764718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131193764718 : Closed e1131193764718 ∧ code e1131193764718 = 5529240275822 := by decide
theorem cert_e1131193764718 : check e1131193764718 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193764726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131193764726 : Closed e1131193764726 ∧ code e1131193764726 = 5529240275830 := by decide
def e1131193764782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131193764782 : Closed e1131193764782 ∧ code e1131193764782 = 5529240275886 := by decide
theorem cert_e1131193764782 : check e1131193764782 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193764794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131193764794 : Closed e1131193764794 ∧ code e1131193764794 = 5529240275898 := by decide
theorem cert_e1131193764794 : check e1131193764794 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193764822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131193764822 : Closed e1131193764822 ∧ code e1131193764822 = 5529240275926 := by decide
def e1131193764826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131193764826 : Closed e1131193764826 ∧ code e1131193764826 = 5529240275930 := by decide
theorem cert_e1131193764826 : check e1131193764826 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193765102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131193765102 : Closed e1131193765102 ∧ code e1131193765102 = 5529240276206 := by decide
theorem cert_e1131193765102 : check e1131193765102 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131193765110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131193765110 : Closed e1131193765110 ∧ code e1131193765110 = 5529240276214 := by decide
theorem cert_e1131193765110 : check e1131193765110 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[],[.left],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e1131193765486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131193765486 : Closed e1131193765486 ∧ code e1131193765486 = 5529240276590 := by decide
def e1131193765498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131193765498 : Closed e1131193765498 ∧ code e1131193765498 = 5529240276602 := by decide
def e1131193765686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131193765686 : Closed e1131193765686 ∧ code e1131193765686 = 5529240276790 := by decide
theorem cert_e1131193765686 : check e1131193765686 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e1131193765690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131193765690 : Closed e1131193765690 ∧ code e1131193765690 = 5529240276794 := by decide
theorem cert_e1131193765690 : check e1131193765690 [[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e1131194363358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1131194363358 : Closed e1131194363358 ∧ code e1131194363358 = 5529240874462 := by decide
theorem cert_e1131194363358 : check e1131194363358 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194363374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1131194363374 : Closed e1131194363374 ∧ code e1131194363374 = 5529240874478 := by decide
theorem cert_e1131194363374 : check e1131194363374 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194363742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1131194363742 : Closed e1131194363742 ∧ code e1131194363742 = 5529240874846 := by decide
theorem cert_e1131194363742 : check e1131194363742 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194363770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1131194363770 : Closed e1131194363770 ∧ code e1131194363770 = 5529240874874 := by decide
theorem cert_e1131194363770 : check e1131194363770 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194363822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1131194363822 : Closed e1131194363822 ∧ code e1131194363822 = 5529240874926 := by decide
theorem cert_e1131194363822 : check e1131194363822 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194363834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1131194363834 : Closed e1131194363834 ∧ code e1131194363834 = 5529240874938 := by decide
theorem cert_e1131194363834 : check e1131194363834 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194364894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1131194364894 : Closed e1131194364894 ∧ code e1131194364894 = 5529240875998 := by decide
theorem cert_e1131194364894 : check e1131194364894 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194364910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1131194364910 : Closed e1131194364910 ∧ code e1131194364910 = 5529240876014 := by decide
theorem cert_e1131194364910 : check e1131194364910 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194367198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1131194367198 : Closed e1131194367198 ∧ code e1131194367198 = 5529240878302 := by decide
theorem cert_e1131194367198 : check e1131194367198 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194367226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1131194367226 : Closed e1131194367226 ∧ code e1131194367226 = 5529240878330 := by decide
theorem cert_e1131194367226 : check e1131194367226 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194367598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131194367598 : Closed e1131194367598 ∧ code e1131194367598 = 5529240878702 := by decide
theorem cert_e1131194367598 : check e1131194367598 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194367610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131194367610 : Closed e1131194367610 ∧ code e1131194367610 = 5529240878714 := by decide
theorem cert_e1131194367610 : check e1131194367610 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1131194396014 : Closed e1131194396014 ∧ code e1131194396014 = 5529240907118 := by decide
private def t_e1131194396014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e1131194396014 : ¬ IsSelfInterpreter e1131194396014 :=
  wSource (t := t_e1131194396014) (replay_sound (ps := []) (t := e1131194396014) (by decide)) (by decide)
def e1131194396022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1131194396022 : Closed e1131194396022 ∧ code e1131194396022 = 5529240907126 := by decide
private def t_e1131194396022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e1131194396022 : ¬ IsSelfInterpreter e1131194396022 :=
  wSource (t := t_e1131194396022) (replay_sound (ps := []) (t := e1131194396022) (by decide)) (by decide)
def e1131194396078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1131194396078 : Closed e1131194396078 ∧ code e1131194396078 = 5529240907182 := by decide
theorem cert_e1131194396078 : check e1131194396078 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1131194396090 : Closed e1131194396090 ∧ code e1131194396090 = 5529240907194 := by decide
theorem cert_e1131194396090 : check e1131194396090 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1131194396118 : Closed e1131194396118 ∧ code e1131194396118 = 5529240907222 := by decide
private def t_e1131194396118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1131194396118 : ¬ IsSelfInterpreter e1131194396118 :=
  wSource (t := t_e1131194396118) (replay_sound (ps := []) (t := e1131194396118) (by decide)) (by decide)
def e1131194396122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1131194396122 : Closed e1131194396122 ∧ code e1131194396122 = 5529240907226 := by decide
private def t_e1131194396122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1131194396122 : ¬ IsSelfInterpreter e1131194396122 :=
  wSource (t := t_e1131194396122) (replay_sound (ps := []) (t := e1131194396122) (by decide)) (by decide)
def e1131194396334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1131194396334 : Closed e1131194396334 ∧ code e1131194396334 = 5529240907438 := by decide
theorem cert_e1131194396334 : check e1131194396334 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1131194396346 : Closed e1131194396346 ∧ code e1131194396346 = 5529240907450 := by decide
theorem cert_e1131194396346 : check e1131194396346 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1131194396394 : Closed e1131194396394 ∧ code e1131194396394 = 5529240907498 := by decide
theorem cert_e1131194396394 : check e1131194396394 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194396502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1131194396502 : Closed e1131194396502 ∧ code e1131194396502 = 5529240907606 := by decide
private def t_e1131194396502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e1131194396502 : ¬ IsSelfInterpreter e1131194396502 :=
  wSource (t := t_e1131194396502) (replay_sound (ps := []) (t := e1131194396502) (by decide)) (by decide)
def e1131194396506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1131194396506 : Closed e1131194396506 ∧ code e1131194396506 = 5529240907610 := by decide
private def t_e1131194396506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e1131194396506 : ¬ IsSelfInterpreter e1131194396506 :=
  wSource (t := t_e1131194396506) (replay_sound (ps := []) (t := e1131194396506) (by decide)) (by decide)
def e1131194396522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1131194396522 : Closed e1131194396522 ∧ code e1131194396522 = 5529240907626 := by decide
theorem cert_e1131194396522 : check e1131194396522 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194397550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1131194397550 : Closed e1131194397550 ∧ code e1131194397550 = 5529240908654 := by decide
theorem cert_e1131194397550 : check e1131194397550 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194397558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1131194397558 : Closed e1131194397558 ∧ code e1131194397558 = 5529240908662 := by decide
private def t_e1131194397558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e1131194397558 : ¬ IsSelfInterpreter e1131194397558 :=
  wSource (t := t_e1131194397558) (replay_sound (ps := []) (t := e1131194397558) (by decide)) (by decide)
def e1131194397614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1131194397614 : Closed e1131194397614 ∧ code e1131194397614 = 5529240908718 := by decide
theorem cert_e1131194397614 : check e1131194397614 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194397626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1131194397626 : Closed e1131194397626 ∧ code e1131194397626 = 5529240908730 := by decide
theorem cert_e1131194397626 : check e1131194397626 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194397654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1131194397654 : Closed e1131194397654 ∧ code e1131194397654 = 5529240908758 := by decide
private def t_e1131194397654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e1131194397654 : ¬ IsSelfInterpreter e1131194397654 :=
  wSource (t := t_e1131194397654) (replay_sound (ps := []) (t := e1131194397654) (by decide)) (by decide)
def e1131194397658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1131194397658 : Closed e1131194397658 ∧ code e1131194397658 = 5529240908762 := by decide
theorem cert_e1131194397658 : check e1131194397658 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194397934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131194397934 : Closed e1131194397934 ∧ code e1131194397934 = 5529240909038 := by decide
private def t_e1131194397934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e1131194397934 : ¬ IsSelfInterpreter e1131194397934 :=
  wSource (t := t_e1131194397934) (replay_sound (ps := []) (t := e1131194397934) (by decide)) (by decide)
def e1131194397942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131194397942 : Closed e1131194397942 ∧ code e1131194397942 = 5529240909046 := by decide
private def t_e1131194397942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e1131194397942 : ¬ IsSelfInterpreter e1131194397942 :=
  wSource (t := t_e1131194397942) (replay_sound (ps := []) (t := e1131194397942) (by decide)) (by decide)
def e1131194398318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131194398318 : Closed e1131194398318 ∧ code e1131194398318 = 5529240909422 := by decide
theorem cert_e1131194398318 : check e1131194398318 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194398330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131194398330 : Closed e1131194398330 ∧ code e1131194398330 = 5529240909434 := by decide
theorem cert_e1131194398330 : check e1131194398330 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194398518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131194398518 : Closed e1131194398518 ∧ code e1131194398518 = 5529240909622 := by decide
private def t_e1131194398518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1131194398518 : ¬ IsSelfInterpreter e1131194398518 :=
  wSource (t := t_e1131194398518) (replay_sound (ps := []) (t := e1131194398518) (by decide)) (by decide)
def e1131194398522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131194398522 : Closed e1131194398522 ∧ code e1131194398522 = 5529240909626 := by decide
private def t_e1131194398522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1131194398522 : ¬ IsSelfInterpreter e1131194398522 :=
  wSource (t := t_e1131194398522) (replay_sound (ps := []) (t := e1131194398522) (by decide)) (by decide)
def e1131194399150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1131194399150 : Closed e1131194399150 ∧ code e1131194399150 = 5529240910254 := by decide
theorem cert_e1131194399150 : check e1131194399150 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1131194399162 : Closed e1131194399162 ∧ code e1131194399162 = 5529240910266 := by decide
theorem cert_e1131194399162 : check e1131194399162 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1131194399210 : Closed e1131194399210 ∧ code e1131194399210 = 5529240910314 := by decide
theorem cert_e1131194399210 : check e1131194399210 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131194399342 : Closed e1131194399342 ∧ code e1131194399342 = 5529240910446 := by decide
theorem cert_e1131194399342 : check e1131194399342 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131194399354 : Closed e1131194399354 ∧ code e1131194399354 = 5529240910458 := by decide
theorem cert_e1131194399354 : check e1131194399354 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1131194399642 : Closed e1131194399642 ∧ code e1131194399642 = 5529240910746 := by decide
theorem cert_e1131194399642 : check e1131194399642 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1131194399958 : Closed e1131194399958 ∧ code e1131194399958 = 5529240911062 := by decide
private def t_e1131194399958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1131194399958 : ¬ IsSelfInterpreter e1131194399958 :=
  wSource (t := t_e1131194399958) (replay_sound (ps := []) (t := e1131194399958) (by decide)) (by decide)
def e1131194399962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1131194399962 : Closed e1131194399962 ∧ code e1131194399962 = 5529240911066 := by decide
theorem cert_e1131194399962 : check e1131194399962 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194399978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1131194399978 : Closed e1131194399978 ∧ code e1131194399978 = 5529240911082 := by decide
theorem cert_e1131194399978 : check e1131194399978 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194400054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131194400054 : Closed e1131194400054 ∧ code e1131194400054 = 5529240911158 := by decide
private def t_e1131194400054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1131194400054 : ¬ IsSelfInterpreter e1131194400054 :=
  wSource (t := t_e1131194400054) (replay_sound (ps := []) (t := e1131194400054) (by decide)) (by decide)
def e1131194400058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131194400058 : Closed e1131194400058 ∧ code e1131194400058 = 5529240911162 := by decide
private def t_e1131194400058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1131194400058 : ¬ IsSelfInterpreter e1131194400058 :=
  wSource (t := t_e1131194400058) (replay_sound (ps := []) (t := e1131194400058) (by decide)) (by decide)
def e1131194400154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1131194400154 : Closed e1131194400154 ∧ code e1131194400154 = 5529240911258 := by decide
theorem cert_e1131194400154 : check e1131194400154 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194401758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1131194401758 : Closed e1131194401758 ∧ code e1131194401758 = 5529240912862 := by decide
theorem cert_e1131194401758 : check e1131194401758 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194401774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1131194401774 : Closed e1131194401774 ∧ code e1131194401774 = 5529240912878 := by decide
theorem cert_e1131194401774 : check e1131194401774 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194403694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131194403694 : Closed e1131194403694 ∧ code e1131194403694 = 5529240914798 := by decide
theorem cert_e1131194403694 : check e1131194403694 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194403702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131194403702 : Closed e1131194403702 ∧ code e1131194403702 = 5529240914806 := by decide
private def t_e1131194403702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1131194403702 : ¬ IsSelfInterpreter e1131194403702 :=
  wSource (t := t_e1131194403702) (replay_sound (ps := []) (t := e1131194403702) (by decide)) (by decide)
def e1131194403758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131194403758 : Closed e1131194403758 ∧ code e1131194403758 = 5529240914862 := by decide
theorem cert_e1131194403758 : check e1131194403758 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194403770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131194403770 : Closed e1131194403770 ∧ code e1131194403770 = 5529240914874 := by decide
theorem cert_e1131194403770 : check e1131194403770 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194403798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131194403798 : Closed e1131194403798 ∧ code e1131194403798 = 5529240914902 := by decide
private def t_e1131194403798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1131194403798 : ¬ IsSelfInterpreter e1131194403798 :=
  wSource (t := t_e1131194403798) (replay_sound (ps := []) (t := e1131194403798) (by decide)) (by decide)
def e1131194403802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131194403802 : Closed e1131194403802 ∧ code e1131194403802 = 5529240914906 := by decide
theorem cert_e1131194403802 : check e1131194403802 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131194404078 : Closed e1131194404078 ∧ code e1131194404078 = 5529240915182 := by decide
theorem cert_e1131194404078 : check e1131194404078 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131194404086 : Closed e1131194404086 ∧ code e1131194404086 = 5529240915190 := by decide
theorem cert_e1131194404086 : check e1131194404086 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131194404462 : Closed e1131194404462 ∧ code e1131194404462 = 5529240915566 := by decide
theorem cert_e1131194404462 : check e1131194404462 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131194404474 : Closed e1131194404474 ∧ code e1131194404474 = 5529240915578 := by decide
theorem cert_e1131194404474 : check e1131194404474 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131194404662 : Closed e1131194404662 ∧ code e1131194404662 = 5529240915766 := by decide
theorem cert_e1131194404662 : check e1131194404662 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194404666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131194404666 : Closed e1131194404666 ∧ code e1131194404666 = 5529240915770 := by decide
theorem cert_e1131194404666 : check e1131194404666 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194409438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1131194409438 : Closed e1131194409438 ∧ code e1131194409438 = 5529240920542 := by decide
theorem cert_e1131194409438 : check e1131194409438 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194409462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1131194409462 : Closed e1131194409462 ∧ code e1131194409462 = 5529240920566 := by decide
theorem cert_e1131194409462 : check e1131194409462 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1131194410414 : Closed e1131194410414 ∧ code e1131194410414 = 5529240921518 := by decide
theorem cert_e1131194410414 : check e1131194410414 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1131194410426 : Closed e1131194410426 ∧ code e1131194410426 = 5529240921530 := by decide
theorem cert_e1131194410426 : check e1131194410426 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1131194410474 : Closed e1131194410474 ∧ code e1131194410474 = 5529240921578 := by decide
theorem cert_e1131194410474 : check e1131194410474 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131194410606 : Closed e1131194410606 ∧ code e1131194410606 = 5529240921710 := by decide
theorem cert_e1131194410606 : check e1131194410606 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131194410618 : Closed e1131194410618 ∧ code e1131194410618 = 5529240921722 := by decide
theorem cert_e1131194410618 : check e1131194410618 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194410906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131194410906 : Closed e1131194410906 ∧ code e1131194410906 = 5529240922010 := by decide
theorem cert_e1131194410906 : check e1131194410906 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1131194413294 : Closed e1131194413294 ∧ code e1131194413294 = 5529240924398 := by decide
theorem cert_e1131194413294 : check e1131194413294 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1131194413302 : Closed e1131194413302 ∧ code e1131194413302 = 5529240924406 := by decide
theorem cert_e1131194413302 : check e1131194413302 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1131194413782 : Closed e1131194413782 ∧ code e1131194413782 = 5529240924886 := by decide
private def t_e1131194413782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e1131194413782 : ¬ IsSelfInterpreter e1131194413782 :=
  wSource (t := t_e1131194413782) (replay_sound (ps := []) (t := e1131194413782) (by decide)) (by decide)
def e1131194413786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1131194413786 : Closed e1131194413786 ∧ code e1131194413786 = 5529240924890 := by decide
theorem cert_e1131194413786 : check e1131194413786 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1131194413802 : Closed e1131194413802 ∧ code e1131194413802 = 5529240924906 := by decide
theorem cert_e1131194413802 : check e1131194413802 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131194413878 : Closed e1131194413878 ∧ code e1131194413878 = 5529240924982 := by decide
theorem cert_e1131194413878 : check e1131194413878 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131194413882 : Closed e1131194413882 ∧ code e1131194413882 = 5529240924986 := by decide
theorem cert_e1131194413882 : check e1131194413882 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194413978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131194413978 : Closed e1131194413978 ∧ code e1131194413978 = 5529240925082 := by decide
theorem cert_e1131194413978 : check e1131194413978 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1131194551150 : Closed e1131194551150 ∧ code e1131194551150 = 5529241062254 := by decide
theorem cert_e1131194551150 : check e1131194551150 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1131194551158 : Closed e1131194551158 ∧ code e1131194551158 = 5529241062262 := by decide
theorem cert_e1131194551158 : check e1131194551158 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1131194551214 : Closed e1131194551214 ∧ code e1131194551214 = 5529241062318 := by decide
theorem cert_e1131194551214 : check e1131194551214 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1131194551226 : Closed e1131194551226 ∧ code e1131194551226 = 5529241062330 := by decide
theorem cert_e1131194551226 : check e1131194551226 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1131194551254 : Closed e1131194551254 ∧ code e1131194551254 = 5529241062358 := by decide
theorem cert_e1131194551254 : check e1131194551254 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1131194551258 : Closed e1131194551258 ∧ code e1131194551258 = 5529241062362 := by decide
theorem cert_e1131194551258 : check e1131194551258 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131194551534 : Closed e1131194551534 ∧ code e1131194551534 = 5529241062638 := by decide
theorem cert_e1131194551534 : check e1131194551534 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131194551542 : Closed e1131194551542 ∧ code e1131194551542 = 5529241062646 := by decide
theorem cert_e1131194551542 : check e1131194551542 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131194551918 : Closed e1131194551918 ∧ code e1131194551918 = 5529241063022 := by decide
theorem cert_e1131194551918 : check e1131194551918 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194551930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131194551930 : Closed e1131194551930 ∧ code e1131194551930 = 5529241063034 := by decide
theorem cert_e1131194551930 : check e1131194551930 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194552118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131194552118 : Closed e1131194552118 ∧ code e1131194552118 = 5529241063222 := by decide
theorem cert_e1131194552118 : check e1131194552118 [[],[.under],[.under,.under]] .three = true := by decide
def e1131194552122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131194552122 : Closed e1131194552122 ∧ code e1131194552122 = 5529241063226 := by decide
theorem cert_e1131194552122 : check e1131194552122 [[],[.under],[.under,.under]] .three = true := by decide
def e1131212201438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1131212201438 : Closed e1131212201438 ∧ code e1131212201438 = 5529258712542 := by decide
theorem cert_e1131212201438 : check e1131212201438 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212201454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1131212201454 : Closed e1131212201454 ∧ code e1131212201454 = 5529258712558 := by decide
theorem cert_e1131212201454 : check e1131212201454 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212201694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1131212201694 : Closed e1131212201694 ∧ code e1131212201694 = 5529258712798 := by decide
theorem cert_e1131212201694 : check e1131212201694 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212201718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1131212201718 : Closed e1131212201718 ∧ code e1131212201718 = 5529258712822 := by decide
private def t_e1131212201718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem cert_e1131212201718 : ¬ IsSelfInterpreter e1131212201718 :=
  wSource (t := t_e1131212201718) (replay_sound (ps := []) (t := e1131212201718) (by decide)) (by decide)
def e1131212201838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1131212201838 : Closed e1131212201838 ∧ code e1131212201838 = 5529258712942 := by decide
theorem cert_e1131212201838 : check e1131212201838 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212201846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1131212201846 : Closed e1131212201846 ∧ code e1131212201846 = 5529258712950 := by decide
private def t_e1131212201846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem cert_e1131212201846 : ¬ IsSelfInterpreter e1131212201846 :=
  wSource (t := t_e1131212201846) (replay_sound (ps := []) (t := e1131212201846) (by decide)) (by decide)
def e1131212207070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1131212207070 : Closed e1131212207070 ∧ code e1131212207070 = 5529258718174 := by decide
theorem cert_e1131212207070 : check e1131212207070 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212207086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1131212207086 : Closed e1131212207086 ∧ code e1131212207086 = 5529258718190 := by decide
theorem cert_e1131212207086 : check e1131212207086 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212208606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131212208606 : Closed e1131212208606 ∧ code e1131212208606 = 5529258719710 := by decide
theorem cert_e1131212208606 : check e1131212208606 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212208630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131212208630 : Closed e1131212208630 ∧ code e1131212208630 = 5529258719734 := by decide
theorem cert_e1131212208630 : check e1131212208630 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212209390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131212209390 : Closed e1131212209390 ∧ code e1131212209390 = 5529258720494 := by decide
theorem cert_e1131212209390 : check e1131212209390 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212209398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131212209398 : Closed e1131212209398 ∧ code e1131212209398 = 5529258720502 := by decide
theorem cert_e1131212209398 : check e1131212209398 [[],[.under],[.under],[.under]] .three = true := by decide
def e1131212266350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1131212266350 : Closed e1131212266350 ∧ code e1131212266350 = 5529258777454 := by decide
theorem cert_e1131212266350 : check e1131212266350 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131212266358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1131212266358 : Closed e1131212266358 ∧ code e1131212266358 = 5529258777462 := by decide
def e1131212266422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1131212266422 : Closed e1131212266422 ∧ code e1131212266422 = 5529258777526 := by decide
def e1131212266862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1131212266862 : Closed e1131212266862 ∧ code e1131212266862 = 5529258777966 := by decide
theorem cert_e1131212266862 : check e1131212266862 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1131212266870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1131212266870 : Closed e1131212266870 ∧ code e1131212266870 = 5529258777974 := by decide
def e1131212266926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1131212266926 : Closed e1131212266926 ∧ code e1131212266926 = 5529258778030 := by decide
private def t_e1131212266926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e1131212266926 : ¬ IsSelfInterpreter e1131212266926 :=
  wSource (t := t_e1131212266926) (replay_sound (ps := []) (t := e1131212266926) (by decide)) (by decide)
def e1131212266938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1131212266938 : Closed e1131212266938 ∧ code e1131212266938 = 5529258778042 := by decide
private def t_e1131212266938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e1131212266938 : ¬ IsSelfInterpreter e1131212266938 :=
  wSource (t := t_e1131212266938) (replay_sound (ps := []) (t := e1131212266938) (by decide)) (by decide)
def e1131212266966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1131212266966 : Closed e1131212266966 ∧ code e1131212266966 = 5529258778070 := by decide
private def t_e1131212266966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1131212266966 : ¬ IsSelfInterpreter e1131212266966 :=
  wSource (t := t_e1131212266966) (replay_sound (ps := []) (t := e1131212266966) (by decide)) (by decide)
def e1131212266970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1131212266970 : Closed e1131212266970 ∧ code e1131212266970 = 5529258778074 := by decide
private def t_e1131212266970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1131212266970 : ¬ IsSelfInterpreter e1131212266970 :=
  wSource (t := t_e1131212266970) (replay_sound (ps := []) (t := e1131212266970) (by decide)) (by decide)
def e1131212267190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1131212267190 : Closed e1131212267190 ∧ code e1131212267190 = 5529258778294 := by decide
theorem cert_e1131212267190 : check e1131212267190 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .identityHead = true := by decide
def e1131212267222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1131212267222 : Closed e1131212267222 ∧ code e1131212267222 = 5529258778326 := by decide
private def t_e1131212267222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem cert_e1131212267222 : ¬ IsSelfInterpreter e1131212267222 :=
  wSource (t := t_e1131212267222) (replay_sound (ps := []) (t := e1131212267222) (by decide)) (by decide)
def e1131212267226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1131212267226 : Closed e1131212267226 ∧ code e1131212267226 = 5529258778330 := by decide
private def t_e1131212267226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem cert_e1131212267226 : ¬ IsSelfInterpreter e1131212267226 :=
  wSource (t := t_e1131212267226) (replay_sound (ps := []) (t := e1131212267226) (by decide)) (by decide)
def e1131212269422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1131212269422 : Closed e1131212269422 ∧ code e1131212269422 = 5529258780526 := by decide
theorem cert_e1131212269422 : check e1131212269422 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1131212269430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1131212269430 : Closed e1131212269430 ∧ code e1131212269430 = 5529258780534 := by decide
theorem cert_e1131212269430 : check e1131212269430 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1131212269494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1131212269494 : Closed e1131212269494 ∧ code e1131212269494 = 5529258780598 := by decide
theorem cert_e1131212269494 : check e1131212269494 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1131212270830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131212270830 : Closed e1131212270830 ∧ code e1131212270830 = 5529258781934 := by decide
theorem cert_e1131212270830 : check e1131212270830 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1131212270838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131212270838 : Closed e1131212270838 ∧ code e1131212270838 = 5529258781942 := by decide
theorem cert_e1131212270838 : check e1131212270838 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1131212271222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131212271222 : Closed e1131212271222 ∧ code e1131212271222 = 5529258782326 := by decide
theorem cert_e1131212271222 : check e1131212271222 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131212272494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1131212272494 : Closed e1131212272494 ∧ code e1131212272494 = 5529258783598 := by decide
theorem cert_e1131212272494 : check e1131212272494 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131212272502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1131212272502 : Closed e1131212272502 ∧ code e1131212272502 = 5529258783606 := by decide
def e1131212272558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1131212272558 : Closed e1131212272558 ∧ code e1131212272558 = 5529258783662 := by decide
theorem cert_e1131212272558 : check e1131212272558 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e1131212272570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1131212272570 : Closed e1131212272570 ∧ code e1131212272570 = 5529258783674 := by decide
private def t_e1131212272570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e1131212272570 : ¬ IsSelfInterpreter e1131212272570 :=
  wSource (t := t_e1131212272570) (replay_sound (ps := []) (t := e1131212272570) (by decide)) (by decide)
def e1131212272598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1131212272598 : Closed e1131212272598 ∧ code e1131212272598 = 5529258783702 := by decide
theorem cert_e1131212272598 : check e1131212272598 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131212272602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1131212272602 : Closed e1131212272602 ∧ code e1131212272602 = 5529258783706 := by decide
private def t_e1131212272602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e1131212272602 : ¬ IsSelfInterpreter e1131212272602 :=
  wSource (t := t_e1131212272602) (replay_sound (ps := []) (t := e1131212272602) (by decide)) (by decide)
def e1131212272878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131212272878 : Closed e1131212272878 ∧ code e1131212272878 = 5529258783982 := by decide
theorem cert_e1131212272878 : check e1131212272878 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1131212272886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131212272886 : Closed e1131212272886 ∧ code e1131212272886 = 5529258783990 := by decide
theorem cert_e1131212272886 : check e1131212272886 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left],[],[],[.under,.left]] .identityHead = true := by decide
end Blc.Floor42
