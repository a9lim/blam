import Tables
import Batch251
namespace Blc.Floor42.Grades251
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211299057262 : ¬ IsSelfInterpreter e1211299057262 := cutM13_0 (by decide)
#print axioms ex_e1211299057262
theorem ex_e1211299062238 : ¬ IsSelfInterpreter e1211299062238 := cutM13_0 (by decide)
#print axioms ex_e1211299062238
theorem ex_e1211299063406 : ¬ IsSelfInterpreter e1211299063406 := cutM13_0 (by decide)
#print axioms ex_e1211299063406
end Blc.Floor42.Grades251
