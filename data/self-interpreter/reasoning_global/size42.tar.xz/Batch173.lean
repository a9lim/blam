import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188736862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211188736862 : Closed e1211188736862 ∧ code e1211188736862 = 5609235247966 := by decide
theorem cert_e1211188736862 : check e1211188736862 [[],[]] .three = true := by decide
def e1211188736866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211188736866 : Closed e1211188736866 ∧ code e1211188736866 = 5609235247970 := by decide
theorem cert_e1211188736866 : check e1211188736866 [[],[]] .smaller = true := by decide
def e1211188736878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211188736878 : Closed e1211188736878 ∧ code e1211188736878 = 5609235247982 := by decide
theorem cert_e1211188736878 : check e1211188736878 [[],[]] .smaller = true := by decide
def e1211188736886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211188736886 : Closed e1211188736886 ∧ code e1211188736886 = 5609235247990 := by decide
theorem cert_e1211188736886 : check e1211188736886 [[],[]] .smaller = true := by decide
def e1211188736890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211188736890 : Closed e1211188736890 ∧ code e1211188736890 = 5609235247994 := by decide
theorem cert_e1211188736890 : check e1211188736890 [[],[]] .three = true := by decide
def e1211188736906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188736906 : Closed e1211188736906 ∧ code e1211188736906 = 5609235248010 := by decide
theorem cert_e1211188736906 : check e1211188736906 [[],[]] .smaller = true := by decide
def e1211188736930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188736930 : Closed e1211188736930 ∧ code e1211188736930 = 5609235248034 := by decide
theorem cert_e1211188736930 : check e1211188736930 [[],[]] .smaller = true := by decide
def e1211188736942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211188736942 : Closed e1211188736942 ∧ code e1211188736942 = 5609235248046 := by decide
theorem cert_e1211188736942 : check e1211188736942 [[],[]] .smaller = true := by decide
def e1211188736954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211188736954 : Closed e1211188736954 ∧ code e1211188736954 = 5609235248058 := by decide
theorem cert_e1211188736954 : check e1211188736954 [[],[]] .smaller = true := by decide
def e1211188736982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211188736982 : Closed e1211188736982 ∧ code e1211188736982 = 5609235248086 := by decide
theorem cert_e1211188736982 : check e1211188736982 [[],[]] .smaller = true := by decide
def e1211188736986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211188736986 : Closed e1211188736986 ∧ code e1211188736986 = 5609235248090 := by decide
theorem cert_e1211188736986 : check e1211188736986 [[],[]] .smaller = true := by decide
def e1211188737002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211188737002 : Closed e1211188737002 ∧ code e1211188737002 = 5609235248106 := by decide
theorem cert_e1211188737002 : check e1211188737002 [[],[]] .three = true := by decide
def e1211188737054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211188737054 : Closed e1211188737054 ∧ code e1211188737054 = 5609235248158 := by decide
theorem cert_e1211188737054 : check e1211188737054 [[],[]] .smaller = true := by decide
def e1211188737078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188737078 : Closed e1211188737078 ∧ code e1211188737078 = 5609235248182 := by decide
theorem cert_e1211188737078 : check e1211188737078 [[],[]] .smaller = true := by decide
def e1211188737082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188737082 : Closed e1211188737082 ∧ code e1211188737082 = 5609235248186 := by decide
theorem cert_e1211188737082 : check e1211188737082 [[],[]] .smaller = true := by decide
def e1211188737222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211188737222 : Closed e1211188737222 ∧ code e1211188737222 = 5609235248326 := by decide
theorem cert_e1211188737222 : check e1211188737222 [[],[]] .smaller = true := by decide
def e1211188737246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188737246 : Closed e1211188737246 ∧ code e1211188737246 = 5609235248350 := by decide
theorem cert_e1211188737246 : check e1211188737246 [[],[]] .three = true := by decide
def e1211188737250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211188737250 : Closed e1211188737250 ∧ code e1211188737250 = 5609235248354 := by decide
theorem cert_e1211188737250 : check e1211188737250 [[],[]] .smaller = true := by decide
def e1211188737262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188737262 : Closed e1211188737262 ∧ code e1211188737262 = 5609235248366 := by decide
theorem cert_e1211188737262 : check e1211188737262 [[],[]] .smaller = true := by decide
def e1211188737270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188737270 : Closed e1211188737270 ∧ code e1211188737270 = 5609235248374 := by decide
theorem cert_e1211188737270 : check e1211188737270 [[],[]] .smaller = true := by decide
def e1211188737274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188737274 : Closed e1211188737274 ∧ code e1211188737274 = 5609235248378 := by decide
theorem cert_e1211188737274 : check e1211188737274 [[],[]] .three = true := by decide
def e1211188737550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188737550 : Closed e1211188737550 ∧ code e1211188737550 = 5609235248654 := by decide
theorem cert_e1211188737550 : check e1211188737550 [[],[]] .smaller = true := by decide
def e1211188737598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211188737598 : Closed e1211188737598 ∧ code e1211188737598 = 5609235248702 := by decide
theorem cert_e1211188737598 : check e1211188737598 [[],[]] .three = true := by decide
def e1211188737634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188737634 : Closed e1211188737634 ∧ code e1211188737634 = 5609235248738 := by decide
theorem cert_e1211188737634 : check e1211188737634 [[],[]] .smaller = true := by decide
def e1211188737646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188737646 : Closed e1211188737646 ∧ code e1211188737646 = 5609235248750 := by decide
theorem cert_e1211188737646 : check e1211188737646 [[],[]] .smaller = true := by decide
def e1211188737658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188737658 : Closed e1211188737658 ∧ code e1211188737658 = 5609235248762 := by decide
theorem cert_e1211188737658 : check e1211188737658 [[],[]] .smaller = true := by decide
def e1211188737846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188737846 : Closed e1211188737846 ∧ code e1211188737846 = 5609235248950 := by decide
theorem cert_e1211188737846 : check e1211188737846 [[],[]] .smaller = true := by decide
def e1211188737850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188737850 : Closed e1211188737850 ∧ code e1211188737850 = 5609235248954 := by decide
theorem cert_e1211188737850 : check e1211188737850 [[],[]] .smaller = true := by decide
def e1211188737934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211188737934 : Closed e1211188737934 ∧ code e1211188737934 = 5609235249038 := by decide
theorem cert_e1211188737934 : check e1211188737934 [[],[]] .three = true := by decide
def e1211188737946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188737946 : Closed e1211188737946 ∧ code e1211188737946 = 5609235249050 := by decide
theorem cert_e1211188737946 : check e1211188737946 [[],[]] .three = true := by decide
def e1211188738270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211188738270 : Closed e1211188738270 ∧ code e1211188738270 = 5609235249374 := by decide
theorem cert_e1211188738270 : check e1211188738270 [[],[]] .three = true := by decide
def e1211188738298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211188738298 : Closed e1211188738298 ∧ code e1211188738298 = 5609235249402 := by decide
theorem cert_e1211188738298 : check e1211188738298 [[],[]] .three = true := by decide
def e1211188738486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211188738486 : Closed e1211188738486 ∧ code e1211188738486 = 5609235249590 := by decide
theorem cert_e1211188738486 : check e1211188738486 [[],[]] .smaller = true := by decide
def e1211188738518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211188738518 : Closed e1211188738518 ∧ code e1211188738518 = 5609235249622 := by decide
theorem cert_e1211188738518 : check e1211188738518 [[],[]] .smaller = true := by decide
def e1211188738522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211188738522 : Closed e1211188738522 ∧ code e1211188738522 = 5609235249626 := by decide
theorem cert_e1211188738522 : check e1211188738522 [[],[]] .smaller = true := by decide
def e1211188738622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211188738622 : Closed e1211188738622 ∧ code e1211188738622 = 5609235249726 := by decide
theorem cert_e1211188738622 : check e1211188738622 [[],[]] .three = true := by decide
def e1211188738678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188738678 : Closed e1211188738678 ∧ code e1211188738678 = 5609235249782 := by decide
theorem cert_e1211188738678 : check e1211188738678 [[],[]] .smaller = true := by decide
def e1211188738870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188738870 : Closed e1211188738870 ∧ code e1211188738870 = 5609235249974 := by decide
theorem cert_e1211188738870 : check e1211188738870 [[],[]] .smaller = true := by decide
def e1211188738874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188738874 : Closed e1211188738874 ∧ code e1211188738874 = 5609235249978 := by decide
theorem cert_e1211188738874 : check e1211188738874 [[],[]] .smaller = true := by decide
def e1211188739014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211188739014 : Closed e1211188739014 ∧ code e1211188739014 = 5609235250118 := by decide
theorem cert_e1211188739014 : check e1211188739014 [[],[]] .three = true := by decide
def e1211188739182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211188739182 : Closed e1211188739182 ∧ code e1211188739182 = 5609235250286 := by decide
theorem cert_e1211188739182 : check e1211188739182 [[],[]] .three = true := by decide
def e1211188739190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211188739190 : Closed e1211188739190 ∧ code e1211188739190 = 5609235250294 := by decide
theorem cert_e1211188739190 : check e1211188739190 [[],[]] .three = true := by decide
def e1211188739194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211188739194 : Closed e1211188739194 ∧ code e1211188739194 = 5609235250298 := by decide
theorem cert_e1211188739194 : check e1211188739194 [[],[]] .three = true := by decide
def e1211188739286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211188739286 : Closed e1211188739286 ∧ code e1211188739286 = 5609235250390 := by decide
theorem cert_e1211188739286 : check e1211188739286 [[],[]] .three = true := by decide
def e1211188739290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211188739290 : Closed e1211188739290 ∧ code e1211188739290 = 5609235250394 := by decide
theorem cert_e1211188739290 : check e1211188739290 [[],[]] .three = true := by decide
def e1211188739306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211188739306 : Closed e1211188739306 ∧ code e1211188739306 = 5609235250410 := by decide
theorem cert_e1211188739306 : check e1211188739306 [[],[]] .three = true := by decide
def e1211188739358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211188739358 : Closed e1211188739358 ∧ code e1211188739358 = 5609235250462 := by decide
theorem cert_e1211188739358 : check e1211188739358 [[],[]] .three = true := by decide
def e1211188739382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188739382 : Closed e1211188739382 ∧ code e1211188739382 = 5609235250486 := by decide
theorem cert_e1211188739382 : check e1211188739382 [[],[]] .three = true := by decide
def e1211188739386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188739386 : Closed e1211188739386 ∧ code e1211188739386 = 5609235250490 := by decide
theorem cert_e1211188739386 : check e1211188739386 [[],[]] .three = true := by decide
def e1211188739470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211188739470 : Closed e1211188739470 ∧ code e1211188739470 = 5609235250574 := by decide
theorem cert_e1211188739470 : check e1211188739470 [[],[]] .three = true := by decide
def e1211188739482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188739482 : Closed e1211188739482 ∧ code e1211188739482 = 5609235250586 := by decide
theorem cert_e1211188739482 : check e1211188739482 [[],[]] .three = true := by decide
def e1211188739526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211188739526 : Closed e1211188739526 ∧ code e1211188739526 = 5609235250630 := by decide
theorem cert_e1211188739526 : check e1211188739526 [[],[]] .three = true := by decide
def e1211188741550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211188741550 : Closed e1211188741550 ∧ code e1211188741550 = 5609235252654 := by decide
theorem cert_e1211188741550 : check e1211188741550 [[],[]] .smaller = true := by decide
def e1211188741562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211188741562 : Closed e1211188741562 ∧ code e1211188741562 = 5609235252666 := by decide
theorem cert_e1211188741562 : check e1211188741562 [[],[]] .smaller = true := by decide
def e1211188741610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211188741610 : Closed e1211188741610 ∧ code e1211188741610 = 5609235252714 := by decide
theorem cert_e1211188741610 : check e1211188741610 [[],[]] .smaller = true := by decide
def e1211188741742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188741742 : Closed e1211188741742 ∧ code e1211188741742 = 5609235252846 := by decide
theorem cert_e1211188741742 : check e1211188741742 [[],[]] .smaller = true := by decide
def e1211188741754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188741754 : Closed e1211188741754 ∧ code e1211188741754 = 5609235252858 := by decide
theorem cert_e1211188741754 : check e1211188741754 [[],[]] .smaller = true := by decide
def e1211188741918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211188741918 : Closed e1211188741918 ∧ code e1211188741918 = 5609235253022 := by decide
theorem cert_e1211188741918 : check e1211188741918 [[],[]] .smaller = true := by decide
def e1211188742030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211188742030 : Closed e1211188742030 ∧ code e1211188742030 = 5609235253134 := by decide
theorem cert_e1211188742030 : check e1211188742030 [[],[]] .smaller = true := by decide
def e1211188742042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188742042 : Closed e1211188742042 ∧ code e1211188742042 = 5609235253146 := by decide
theorem cert_e1211188742042 : check e1211188742042 [[],[]] .smaller = true := by decide
def e1211188745782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211188745782 : Closed e1211188745782 ∧ code e1211188745782 = 5609235256886 := by decide
theorem cert_e1211188745782 : check e1211188745782 [[],[]] .smaller = true := by decide
def e1211188745786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211188745786 : Closed e1211188745786 ∧ code e1211188745786 = 5609235256890 := by decide
theorem cert_e1211188745786 : check e1211188745786 [[],[]] .smaller = true := by decide
def e1211188745870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211188745870 : Closed e1211188745870 ∧ code e1211188745870 = 5609235256974 := by decide
theorem cert_e1211188745870 : check e1211188745870 [[],[]] .smaller = true := by decide
def e1211188745926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211188745926 : Closed e1211188745926 ∧ code e1211188745926 = 5609235257030 := by decide
theorem cert_e1211188745926 : check e1211188745926 [[],[]] .smaller = true := by decide
def e1211188745950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211188745950 : Closed e1211188745950 ∧ code e1211188745950 = 5609235257054 := by decide
theorem cert_e1211188745950 : check e1211188745950 [[],[]] .three = true := by decide
def e1211188745974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211188745974 : Closed e1211188745974 ∧ code e1211188745974 = 5609235257078 := by decide
theorem cert_e1211188745974 : check e1211188745974 [[],[]] .three = true := by decide
def e1211188746006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211188746006 : Closed e1211188746006 ∧ code e1211188746006 = 5609235257110 := by decide
theorem cert_e1211188746006 : check e1211188746006 [[],[]] .smaller = true := by decide
def e1211188746010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211188746010 : Closed e1211188746010 ∧ code e1211188746010 = 5609235257114 := by decide
theorem cert_e1211188746010 : check e1211188746010 [[],[]] .smaller = true := by decide
def e1211188746054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211188746054 : Closed e1211188746054 ∧ code e1211188746054 = 5609235257158 := by decide
theorem cert_e1211188746054 : check e1211188746054 [[],[]] .smaller = true := by decide
def e1211188746078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211188746078 : Closed e1211188746078 ∧ code e1211188746078 = 5609235257182 := by decide
theorem cert_e1211188746078 : check e1211188746078 [[],[]] .three = true := by decide
def e1211188746082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211188746082 : Closed e1211188746082 ∧ code e1211188746082 = 5609235257186 := by decide
theorem cert_e1211188746082 : check e1211188746082 [[],[]] .smaller = true := by decide
def e1211188746094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211188746094 : Closed e1211188746094 ∧ code e1211188746094 = 5609235257198 := by decide
theorem cert_e1211188746094 : check e1211188746094 [[],[]] .smaller = true := by decide
def e1211188746102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211188746102 : Closed e1211188746102 ∧ code e1211188746102 = 5609235257206 := by decide
theorem cert_e1211188746102 : check e1211188746102 [[],[]] .smaller = true := by decide
def e1211188746106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211188746106 : Closed e1211188746106 ∧ code e1211188746106 = 5609235257210 := by decide
theorem cert_e1211188746106 : check e1211188746106 [[],[]] .three = true := by decide
def e1211188746166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211188746166 : Closed e1211188746166 ∧ code e1211188746166 = 5609235257270 := by decide
theorem cert_e1211188746166 : check e1211188746166 [[],[]] .smaller = true := by decide
def e1211188746198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211188746198 : Closed e1211188746198 ∧ code e1211188746198 = 5609235257302 := by decide
theorem cert_e1211188746198 : check e1211188746198 [[],[]] .three = true := by decide
def e1211188746202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211188746202 : Closed e1211188746202 ∧ code e1211188746202 = 5609235257306 := by decide
theorem cert_e1211188746202 : check e1211188746202 [[],[]] .three = true := by decide
def e1211188746350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188746350 : Closed e1211188746350 ∧ code e1211188746350 = 5609235257454 := by decide
theorem cert_e1211188746350 : check e1211188746350 [[],[]] .smaller = true := by decide
def e1211188746362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188746362 : Closed e1211188746362 ∧ code e1211188746362 = 5609235257466 := by decide
theorem cert_e1211188746362 : check e1211188746362 [[],[]] .smaller = true := by decide
def e1211188746638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211188746638 : Closed e1211188746638 ∧ code e1211188746638 = 5609235257742 := by decide
theorem cert_e1211188746638 : check e1211188746638 [[],[]] .smaller = true := by decide
def e1211188746694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211188746694 : Closed e1211188746694 ∧ code e1211188746694 = 5609235257798 := by decide
theorem cert_e1211188746694 : check e1211188746694 [[],[]] .smaller = true := by decide
def e1211188746718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188746718 : Closed e1211188746718 ∧ code e1211188746718 = 5609235257822 := by decide
theorem cert_e1211188746718 : check e1211188746718 [[],[]] .three = true := by decide
def e1211188746742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188746742 : Closed e1211188746742 ∧ code e1211188746742 = 5609235257846 := by decide
theorem cert_e1211188746742 : check e1211188746742 [[],[]] .three = true := by decide
def e1211188747294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211188747294 : Closed e1211188747294 ∧ code e1211188747294 = 5609235258398 := by decide
theorem cert_e1211188747294 : check e1211188747294 [[],[]] .smaller = true := by decide
def e1211188747318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188747318 : Closed e1211188747318 ∧ code e1211188747318 = 5609235258422 := by decide
theorem cert_e1211188747318 : check e1211188747318 [[],[]] .smaller = true := by decide
def e1211188747322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188747322 : Closed e1211188747322 ∧ code e1211188747322 = 5609235258426 := by decide
theorem cert_e1211188747322 : check e1211188747322 [[],[]] .smaller = true := by decide
def e1211188747462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211188747462 : Closed e1211188747462 ∧ code e1211188747462 = 5609235258566 := by decide
theorem cert_e1211188747462 : check e1211188747462 [[],[]] .smaller = true := by decide
def e1211188747486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188747486 : Closed e1211188747486 ∧ code e1211188747486 = 5609235258590 := by decide
theorem cert_e1211188747486 : check e1211188747486 [[],[]] .three = true := by decide
def e1211188747490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211188747490 : Closed e1211188747490 ∧ code e1211188747490 = 5609235258594 := by decide
theorem cert_e1211188747490 : check e1211188747490 [[],[]] .smaller = true := by decide
def e1211188747502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188747502 : Closed e1211188747502 ∧ code e1211188747502 = 5609235258606 := by decide
theorem cert_e1211188747502 : check e1211188747502 [[],[]] .smaller = true := by decide
def e1211188747510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188747510 : Closed e1211188747510 ∧ code e1211188747510 = 5609235258614 := by decide
theorem cert_e1211188747510 : check e1211188747510 [[],[]] .smaller = true := by decide
def e1211188747514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188747514 : Closed e1211188747514 ∧ code e1211188747514 = 5609235258618 := by decide
theorem cert_e1211188747514 : check e1211188747514 [[],[]] .three = true := by decide
def e1211188747838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211188747838 : Closed e1211188747838 ∧ code e1211188747838 = 5609235258942 := by decide
theorem cert_e1211188747838 : check e1211188747838 [[],[]] .three = true := by decide
def e1211188747894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188747894 : Closed e1211188747894 ∧ code e1211188747894 = 5609235258998 := by decide
theorem cert_e1211188747894 : check e1211188747894 [[],[]] .smaller = true := by decide
def e1211188748062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211188748062 : Closed e1211188748062 ∧ code e1211188748062 = 5609235259166 := by decide
theorem cert_e1211188748062 : check e1211188748062 [[],[]] .three = true := by decide
def e1211188748086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188748086 : Closed e1211188748086 ∧ code e1211188748086 = 5609235259190 := by decide
theorem cert_e1211188748086 : check e1211188748086 [[],[]] .three = true := by decide
def e1211188748090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188748090 : Closed e1211188748090 ∧ code e1211188748090 = 5609235259194 := by decide
theorem cert_e1211188748090 : check e1211188748090 [[],[]] .three = true := by decide
def e1211188757206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211188757206 : Closed e1211188757206 ∧ code e1211188757206 = 5609235268310 := by decide
theorem cert_e1211188757206 : check e1211188757206 [[],[]] .smaller = true := by decide
def e1211188757210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211188757210 : Closed e1211188757210 ∧ code e1211188757210 = 5609235268314 := by decide
theorem cert_e1211188757210 : check e1211188757210 [[],[]] .smaller = true := by decide
def e1211188757226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211188757226 : Closed e1211188757226 ∧ code e1211188757226 = 5609235268330 := by decide
theorem cert_e1211188757226 : check e1211188757226 [[],[]] .smaller = true := by decide
def e1211188757302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188757302 : Closed e1211188757302 ∧ code e1211188757302 = 5609235268406 := by decide
theorem cert_e1211188757302 : check e1211188757302 [[],[]] .smaller = true := by decide
def e1211188757306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188757306 : Closed e1211188757306 ∧ code e1211188757306 = 5609235268410 := by decide
theorem cert_e1211188757306 : check e1211188757306 [[],[]] .smaller = true := by decide
def e1211188757390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e1211188757390 : Closed e1211188757390 ∧ code e1211188757390 = 5609235268494 := by decide
theorem cert_e1211188757390 : check e1211188757390 [[],[]] .smaller = true := by decide
def e1211188757402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188757402 : Closed e1211188757402 ∧ code e1211188757402 = 5609235268506 := by decide
theorem cert_e1211188757402 : check e1211188757402 [[],[]] .smaller = true := by decide
def e1211188759318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211188759318 : Closed e1211188759318 ∧ code e1211188759318 = 5609235270422 := by decide
theorem cert_e1211188759318 : check e1211188759318 [[],[]] .smaller = true := by decide
def e1211188759322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211188759322 : Closed e1211188759322 ∧ code e1211188759322 = 5609235270426 := by decide
theorem cert_e1211188759322 : check e1211188759322 [[],[]] .smaller = true := by decide
def e1211188759366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211188759366 : Closed e1211188759366 ∧ code e1211188759366 = 5609235270470 := by decide
theorem cert_e1211188759366 : check e1211188759366 [[],[]] .smaller = true := by decide
def e1211188759390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211188759390 : Closed e1211188759390 ∧ code e1211188759390 = 5609235270494 := by decide
theorem cert_e1211188759390 : check e1211188759390 [[],[]] .three = true := by decide
def e1211188759394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211188759394 : Closed e1211188759394 ∧ code e1211188759394 = 5609235270498 := by decide
theorem cert_e1211188759394 : check e1211188759394 [[],[]] .smaller = true := by decide
def e1211188759406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211188759406 : Closed e1211188759406 ∧ code e1211188759406 = 5609235270510 := by decide
theorem cert_e1211188759406 : check e1211188759406 [[],[]] .smaller = true := by decide
def e1211188759414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211188759414 : Closed e1211188759414 ∧ code e1211188759414 = 5609235270518 := by decide
theorem cert_e1211188759414 : check e1211188759414 [[],[]] .smaller = true := by decide
def e1211188759418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211188759418 : Closed e1211188759418 ∧ code e1211188759418 = 5609235270522 := by decide
theorem cert_e1211188759418 : check e1211188759418 [[],[]] .three = true := by decide
def e1211188759434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188759434 : Closed e1211188759434 ∧ code e1211188759434 = 5609235270538 := by decide
theorem cert_e1211188759434 : check e1211188759434 [[],[]] .smaller = true := by decide
def e1211188759458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188759458 : Closed e1211188759458 ∧ code e1211188759458 = 5609235270562 := by decide
theorem cert_e1211188759458 : check e1211188759458 [[],[]] .smaller = true := by decide
def e1211188759470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211188759470 : Closed e1211188759470 ∧ code e1211188759470 = 5609235270574 := by decide
theorem cert_e1211188759470 : check e1211188759470 [[],[]] .smaller = true := by decide
def e1211188759482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211188759482 : Closed e1211188759482 ∧ code e1211188759482 = 5609235270586 := by decide
theorem cert_e1211188759482 : check e1211188759482 [[],[]] .smaller = true := by decide
def e1211188759510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211188759510 : Closed e1211188759510 ∧ code e1211188759510 = 5609235270614 := by decide
theorem cert_e1211188759510 : check e1211188759510 [[],[]] .smaller = true := by decide
def e1211188759514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211188759514 : Closed e1211188759514 ∧ code e1211188759514 = 5609235270618 := by decide
theorem cert_e1211188759514 : check e1211188759514 [[],[]] .smaller = true := by decide
def e1211188759530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211188759530 : Closed e1211188759530 ∧ code e1211188759530 = 5609235270634 := by decide
theorem cert_e1211188759530 : check e1211188759530 [[],[]] .three = true := by decide
def e1211188759582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211188759582 : Closed e1211188759582 ∧ code e1211188759582 = 5609235270686 := by decide
theorem cert_e1211188759582 : check e1211188759582 [[],[]] .smaller = true := by decide
def e1211188759606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188759606 : Closed e1211188759606 ∧ code e1211188759606 = 5609235270710 := by decide
theorem cert_e1211188759606 : check e1211188759606 [[],[]] .smaller = true := by decide
def e1211188759610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188759610 : Closed e1211188759610 ∧ code e1211188759610 = 5609235270714 := by decide
theorem cert_e1211188759610 : check e1211188759610 [[],[]] .smaller = true := by decide
def e1211188759750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211188759750 : Closed e1211188759750 ∧ code e1211188759750 = 5609235270854 := by decide
theorem cert_e1211188759750 : check e1211188759750 [[],[]] .smaller = true := by decide
def e1211188759774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188759774 : Closed e1211188759774 ∧ code e1211188759774 = 5609235270878 := by decide
theorem cert_e1211188759774 : check e1211188759774 [[],[]] .three = true := by decide
def e1211188759778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211188759778 : Closed e1211188759778 ∧ code e1211188759778 = 5609235270882 := by decide
theorem cert_e1211188759778 : check e1211188759778 [[],[]] .smaller = true := by decide
def e1211188759790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188759790 : Closed e1211188759790 ∧ code e1211188759790 = 5609235270894 := by decide
theorem cert_e1211188759790 : check e1211188759790 [[],[]] .smaller = true := by decide
def e1211188759798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188759798 : Closed e1211188759798 ∧ code e1211188759798 = 5609235270902 := by decide
theorem cert_e1211188759798 : check e1211188759798 [[],[]] .smaller = true := by decide
def e1211188759802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188759802 : Closed e1211188759802 ∧ code e1211188759802 = 5609235270906 := by decide
theorem cert_e1211188759802 : check e1211188759802 [[],[]] .three = true := by decide
def e1211188760078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188760078 : Closed e1211188760078 ∧ code e1211188760078 = 5609235271182 := by decide
theorem cert_e1211188760078 : check e1211188760078 [[],[]] .smaller = true := by decide
def e1211188760126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211188760126 : Closed e1211188760126 ∧ code e1211188760126 = 5609235271230 := by decide
theorem cert_e1211188760126 : check e1211188760126 [[],[]] .three = true := by decide
def e1211188760162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188760162 : Closed e1211188760162 ∧ code e1211188760162 = 5609235271266 := by decide
theorem cert_e1211188760162 : check e1211188760162 [[],[]] .smaller = true := by decide
def e1211188760174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188760174 : Closed e1211188760174 ∧ code e1211188760174 = 5609235271278 := by decide
theorem cert_e1211188760174 : check e1211188760174 [[],[]] .smaller = true := by decide
def e1211188760186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188760186 : Closed e1211188760186 ∧ code e1211188760186 = 5609235271290 := by decide
theorem cert_e1211188760186 : check e1211188760186 [[],[]] .smaller = true := by decide
def e1211188760374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188760374 : Closed e1211188760374 ∧ code e1211188760374 = 5609235271478 := by decide
theorem cert_e1211188760374 : check e1211188760374 [[],[]] .smaller = true := by decide
def e1211188760378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188760378 : Closed e1211188760378 ∧ code e1211188760378 = 5609235271482 := by decide
theorem cert_e1211188760378 : check e1211188760378 [[],[]] .smaller = true := by decide
def e1211188760462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211188760462 : Closed e1211188760462 ∧ code e1211188760462 = 5609235271566 := by decide
theorem cert_e1211188760462 : check e1211188760462 [[],[]] .three = true := by decide
def e1211188760474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188760474 : Closed e1211188760474 ∧ code e1211188760474 = 5609235271578 := by decide
theorem cert_e1211188760474 : check e1211188760474 [[],[]] .three = true := by decide
def e1211188766134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211188766134 : Closed e1211188766134 ∧ code e1211188766134 = 5609235277238 := by decide
theorem cert_e1211188766134 : check e1211188766134 [[],[]] .smaller = true := by decide
def e1211188766166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211188766166 : Closed e1211188766166 ∧ code e1211188766166 = 5609235277270 := by decide
theorem cert_e1211188766166 : check e1211188766166 [[],[]] .smaller = true := by decide
def e1211188766170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211188766170 : Closed e1211188766170 ∧ code e1211188766170 = 5609235277274 := by decide
theorem cert_e1211188766170 : check e1211188766170 [[],[]] .smaller = true := by decide
def e1211188766270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211188766270 : Closed e1211188766270 ∧ code e1211188766270 = 5609235277374 := by decide
theorem cert_e1211188766270 : check e1211188766270 [[],[]] .three = true := by decide
def e1211188766326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188766326 : Closed e1211188766326 ∧ code e1211188766326 = 5609235277430 := by decide
theorem cert_e1211188766326 : check e1211188766326 [[],[]] .smaller = true := by decide
def e1211188766518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188766518 : Closed e1211188766518 ∧ code e1211188766518 = 5609235277622 := by decide
theorem cert_e1211188766518 : check e1211188766518 [[],[]] .smaller = true := by decide
def e1211188766522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188766522 : Closed e1211188766522 ∧ code e1211188766522 = 5609235277626 := by decide
theorem cert_e1211188766522 : check e1211188766522 [[],[]] .smaller = true := by decide
def e1211188766662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211188766662 : Closed e1211188766662 ∧ code e1211188766662 = 5609235277766 := by decide
theorem cert_e1211188766662 : check e1211188766662 [[],[]] .three = true := by decide
def e1211188769494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211188769494 : Closed e1211188769494 ∧ code e1211188769494 = 5609235280598 := by decide
theorem cert_e1211188769494 : check e1211188769494 [[],[]] .three = true := by decide
def e1211188769498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211188769498 : Closed e1211188769498 ∧ code e1211188769498 = 5609235280602 := by decide
theorem cert_e1211188769498 : check e1211188769498 [[],[]] .three = true := by decide
def e1211188769514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211188769514 : Closed e1211188769514 ∧ code e1211188769514 = 5609235280618 := by decide
theorem cert_e1211188769514 : check e1211188769514 [[],[]] .three = true := by decide
def e1211188769566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211188769566 : Closed e1211188769566 ∧ code e1211188769566 = 5609235280670 := by decide
theorem cert_e1211188769566 : check e1211188769566 [[],[]] .three = true := by decide
def e1211188769590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188769590 : Closed e1211188769590 ∧ code e1211188769590 = 5609235280694 := by decide
theorem cert_e1211188769590 : check e1211188769590 [[],[]] .three = true := by decide
def e1211188769594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188769594 : Closed e1211188769594 ∧ code e1211188769594 = 5609235280698 := by decide
theorem cert_e1211188769594 : check e1211188769594 [[],[]] .three = true := by decide
def e1211188769678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211188769678 : Closed e1211188769678 ∧ code e1211188769678 = 5609235280782 := by decide
theorem cert_e1211188769678 : check e1211188769678 [[],[]] .three = true := by decide
def e1211188769690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188769690 : Closed e1211188769690 ∧ code e1211188769690 = 5609235280794 := by decide
theorem cert_e1211188769690 : check e1211188769690 [[],[]] .three = true := by decide
def e1211188769734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211188769734 : Closed e1211188769734 ∧ code e1211188769734 = 5609235280838 := by decide
theorem cert_e1211188769734 : check e1211188769734 [[],[]] .three = true := by decide
def e1211188915646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e1211188915646 : Closed e1211188915646 ∧ code e1211188915646 = 5609235426750 := by decide
theorem cert_e1211188915646 : check e1211188915646 [[],[]] .three = true := by decide
def e1211188915702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e1211188915702 : Closed e1211188915702 ∧ code e1211188915702 = 5609235426806 := by decide
private def t_e1211188915702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem cert_e1211188915702 : ¬ IsSelfInterpreter e1211188915702 :=
  wSource (t := t_e1211188915702) (replay_sound (ps := []) (t := e1211188915702) (by decide)) (by decide)
def e1211188915902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e1211188915902 : Closed e1211188915902 ∧ code e1211188915902 = 5609235427006 := by decide
theorem cert_e1211188915902 : check e1211188915902 [[],[]] .three = true := by decide
def e1211188915934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211188915934 : Closed e1211188915934 ∧ code e1211188915934 = 5609235427038 := by decide
theorem cert_e1211188915934 : check e1211188915934 [[],[]] .three = true := by decide
def e1211188915950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211188915950 : Closed e1211188915950 ∧ code e1211188915950 = 5609235427054 := by decide
theorem cert_e1211188915950 : check e1211188915950 [[],[]] .three = true := by decide
def e1211188915958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211188915958 : Closed e1211188915958 ∧ code e1211188915958 = 5609235427062 := by decide
theorem cert_e1211188915958 : check e1211188915958 [[],[]] .three = true := by decide
end Blc.Floor42
