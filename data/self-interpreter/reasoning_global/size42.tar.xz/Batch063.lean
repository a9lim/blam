import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194027940378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194027940378 : Closed e1194027940378 ∧ code e1194027940378 = 5592074451482 := by decide
theorem cert_e1194027940378 : check e1194027940378 [[],[.left]] .chain = true := by decide
def e1194028028102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194028028102 : Closed e1194028028102 ∧ code e1194028028102 = 5592074539206 := by decide
theorem cert_e1194028028102 : check e1194028028102 [[],[.left]] .chain = true := by decide
def e1194028034074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194028034074 : Closed e1194028034074 ∧ code e1194028034074 = 5592074545178 := by decide
theorem cert_e1194028034074 : check e1194028034074 [[]] .width = true := by decide
def e1194028055066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194028055066 : Closed e1194028055066 ∧ code e1194028055066 = 5592074566170 := by decide
theorem cert_e1194028055066 : check e1194028055066 [[],[.left]] .chain = true := by decide
def e1194028093638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194028093638 : Closed e1194028093638 ∧ code e1194028093638 = 5592074604742 := by decide
theorem cert_e1194028093638 : check e1194028093638 [[],[.left]] .chain = true := by decide
def e1194028132378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194028132378 : Closed e1194028132378 ∧ code e1194028132378 = 5592074643482 := by decide
theorem cert_e1194028132378 : check e1194028132378 [[]] .width = true := by decide
def e1194031086106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194031086106 : Closed e1194031086106 ∧ code e1194031086106 = 5592077597210 := by decide
theorem cert_e1194031086106 : check e1194031086106 [[],[.left]] .chain = true := by decide
def e1194031173830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194031173830 : Closed e1194031173830 ∧ code e1194031173830 = 5592077684934 := by decide
theorem cert_e1194031173830 : check e1194031173830 [[],[.left]] .chain = true := by decide
def e1194031179802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194031179802 : Closed e1194031179802 ∧ code e1194031179802 = 5592077690906 := by decide
theorem cert_e1194031179802 : check e1194031179802 [[]] .width = true := by decide
def e1194031258138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194031258138 : Closed e1194031258138 ∧ code e1194031258138 = 5592077769242 := by decide
theorem cert_e1194031258138 : check e1194031258138 [[],[.left]] .chain = true := by decide
def e1194031272134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194031272134 : Closed e1194031272134 ∧ code e1194031272134 = 5592077783238 := by decide
theorem cert_e1194031272134 : check e1194031272134 [[],[.left]] .chain = true := by decide
def e1194031282714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194031282714 : Closed e1194031282714 ∧ code e1194031282714 = 5592077793818 := by decide
theorem cert_e1194031282714 : check e1194031282714 [[]] .width = true := by decide
def e1194031294490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194031294490 : Closed e1194031294490 ∧ code e1194031294490 = 5592077805594 := by decide
theorem cert_e1194031294490 : check e1194031294490 [[]] .width = true := by decide
def e1194031299098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194031299098 : Closed e1194031299098 ∧ code e1194031299098 = 5592077810202 := by decide
theorem cert_e1194031299098 : check e1194031299098 [[]] .width = true := by decide
def e1194032773658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194032773658 : Closed e1194032773658 ∧ code e1194032773658 = 5592079284762 := by decide
theorem cert_e1194032773658 : check e1194032773658 [[],[.left]] .chain = true := by decide
def e1194032812230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194032812230 : Closed e1194032812230 ∧ code e1194032812230 = 5592079323334 := by decide
theorem cert_e1194032812230 : check e1194032812230 [[],[.left]] .chain = true := by decide
def e1194032831002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194032831002 : Closed e1194032831002 ∧ code e1194032831002 = 5592079342106 := by decide
theorem cert_e1194032831002 : check e1194032831002 [[],[.left]] .chain = true := by decide
def e1194032844998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194032844998 : Closed e1194032844998 ∧ code e1194032844998 = 5592079356102 := by decide
theorem cert_e1194032844998 : check e1194032844998 [[],[.left]] .chain = true := by decide
def e1194032855578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194032855578 : Closed e1194032855578 ∧ code e1194032855578 = 5592079366682 := by decide
theorem cert_e1194032855578 : check e1194032855578 [[]] .width = true := by decide
def e1194032880154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194032880154 : Closed e1194032880154 ∧ code e1194032880154 = 5592079391258 := by decide
theorem cert_e1194032880154 : check e1194032880154 [[]] .width = true := by decide
def e1194033637402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194033637402 : Closed e1194033637402 ∧ code e1194033637402 = 5592080148506 := by decide
theorem cert_e1194033637402 : check e1194033637402 [[]] .width = true := by decide
def e1194033653786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194033653786 : Closed e1194033653786 ∧ code e1194033653786 = 5592080164890 := by decide
theorem cert_e1194033653786 : check e1194033653786 [[]] .width = true := by decide
def e1194033658394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194033658394 : Closed e1194033658394 ∧ code e1194033658394 = 5592080169498 := by decide
theorem cert_e1194033658394 : check e1194033658394 [[]] .width = true := by decide
def e1194033666586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194033666586 : Closed e1194033666586 ∧ code e1194033666586 = 5592080177690 := by decide
theorem cert_e1194033666586 : check e1194033666586 [[]] .width = true := by decide
def e1194091985434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194091985434 : Closed e1194091985434 ∧ code e1194091985434 = 5592138496538 := by decide
theorem cert_e1194091985434 : check e1194091985434 [[]] .width = true := by decide
def e1194091993626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194091993626 : Closed e1194091993626 ∧ code e1194091993626 = 5592138504730 := by decide
theorem cert_e1194091993626 : check e1194091993626 [[]] .width = true := by decide
def e1194092059162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092059162 : Closed e1194092059162 ∧ code e1194092059162 = 5592138570266 := by decide
theorem cert_e1194092059162 : check e1194092059162 [[]] .width = true := by decide
def e1194092509722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092509722 : Closed e1194092509722 ∧ code e1194092509722 = 5592139020826 := by decide
theorem cert_e1194092509722 : check e1194092509722 [[]] .width = true := by decide
def e1194092517914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092517914 : Closed e1194092517914 ∧ code e1194092517914 = 5592139029018 := by decide
theorem cert_e1194092517914 : check e1194092517914 [[]] .width = true := by decide
def e1194092575258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092575258 : Closed e1194092575258 ∧ code e1194092575258 = 5592139086362 := by decide
private def t_e1194092575258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092575258 : ¬ IsSelfInterpreter e1194092575258 :=
  wSource (t := t_e1194092575258) (replay_sound (ps := []) (t := e1194092575258) (by decide)) (by decide)
def e1194092587546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092587546 : Closed e1194092587546 ∧ code e1194092587546 = 5592139098650 := by decide
private def t_e1194092587546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092587546 : ¬ IsSelfInterpreter e1194092587546 :=
  wSource (t := t_e1194092587546) (replay_sound (ps := []) (t := e1194092587546) (by decide)) (by decide)
def e1194092616218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092616218 : Closed e1194092616218 ∧ code e1194092616218 = 5592139127322 := by decide
private def t_e1194092616218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092616218 : ¬ IsSelfInterpreter e1194092616218 :=
  wSource (t := t_e1194092616218) (replay_sound (ps := []) (t := e1194092616218) (by decide)) (by decide)
def e1194092620314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092620314 : Closed e1194092620314 ∧ code e1194092620314 = 5592139131418 := by decide
private def t_e1194092620314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092620314 : ¬ IsSelfInterpreter e1194092620314 :=
  wSource (t := t_e1194092620314) (replay_sound (ps := []) (t := e1194092620314) (by decide)) (by decide)
def e1194092845594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092845594 : Closed e1194092845594 ∧ code e1194092845594 = 5592139356698 := by decide
theorem cert_e1194092845594 : check e1194092845594 [[]] .width = true := by decide
def e1194092878362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092878362 : Closed e1194092878362 ∧ code e1194092878362 = 5592139389466 := by decide
private def t_e1194092878362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092878362 : ¬ IsSelfInterpreter e1194092878362 :=
  wSource (t := t_e1194092878362) (replay_sound (ps := []) (t := e1194092878362) (by decide)) (by decide)
def e1194092882458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194092882458 : Closed e1194092882458 ∧ code e1194092882458 = 5592139393562 := by decide
private def t_e1194092882458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194092882458 : ¬ IsSelfInterpreter e1194092882458 :=
  wSource (t := t_e1194092882458) (replay_sound (ps := []) (t := e1194092882458) (by decide)) (by decide)
def e1194094159898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194094159898 : Closed e1194094159898 ∧ code e1194094159898 = 5592140671002 := by decide
theorem cert_e1194094159898 : check e1194094159898 [[]] .width = true := by decide
def e1194094192666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194094192666 : Closed e1194094192666 ∧ code e1194094192666 = 5592140703770 := by decide
theorem cert_e1194094192666 : check e1194094192666 [[]] .width = true := by decide
def e1194095131162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194095131162 : Closed e1194095131162 ∧ code e1194095131162 = 5592141642266 := by decide
theorem cert_e1194095131162 : check e1194095131162 [[]] .width = true := by decide
def e1194095139354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194095139354 : Closed e1194095139354 ∧ code e1194095139354 = 5592141650458 := by decide
theorem cert_e1194095139354 : check e1194095139354 [[]] .width = true := by decide
def e1194095204890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194095204890 : Closed e1194095204890 ∧ code e1194095204890 = 5592141715994 := by decide
theorem cert_e1194095204890 : check e1194095204890 [[]] .width = true := by decide
def e1194096453658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194096453658 : Closed e1194096453658 ∧ code e1194096453658 = 5592142964762 := by decide
theorem cert_e1194096453658 : check e1194096453658 [[]] .width = true := by decide
def e1194096572954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194096572954 : Closed e1194096572954 ∧ code e1194096572954 = 5592143084058 := by decide
theorem cert_e1194096572954 : check e1194096572954 [[]] .width = true := by decide
def e1194096581146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194096581146 : Closed e1194096581146 ∧ code e1194096581146 = 5592143092250 := by decide
theorem cert_e1194096581146 : check e1194096581146 [[]] .width = true := by decide
def e1194096791750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194096791750 : Closed e1194096791750 ∧ code e1194096791750 = 5592143302854 := by decide
theorem cert_e1194096791750 : check e1194096791750 [[]] .width = true := by decide
def e1194096793626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194096793626 : Closed e1194096793626 ∧ code e1194096793626 = 5592143304730 := by decide
theorem cert_e1194096793626 : check e1194096793626 [[]] .width = true := by decide
def e1194096804038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194096804038 : Closed e1194096804038 ∧ code e1194096804038 = 5592143315142 := by decide
theorem cert_e1194096804038 : check e1194096804038 [[]] .width = true := by decide
def e1194096912410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194096912410 : Closed e1194096912410 ∧ code e1194096912410 = 5592143423514 := by decide
theorem cert_e1194096912410 : check e1194096912410 [[]] .width = true := by decide
def e1194096974362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194096974362 : Closed e1194096974362 ∧ code e1194096974362 = 5592143485466 := by decide
theorem cert_e1194096974362 : check e1194096974362 [[]] .width = true := by decide
def e1194097053894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194097053894 : Closed e1194097053894 ∧ code e1194097053894 = 5592143564998 := by decide
theorem cert_e1194097053894 : check e1194097053894 [[]] .width = true := by decide
def e1194097055770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194097055770 : Closed e1194097055770 ∧ code e1194097055770 = 5592143566874 := by decide
theorem cert_e1194097055770 : check e1194097055770 [[]] .width = true := by decide
def e1194097066182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194097066182 : Closed e1194097066182 ∧ code e1194097066182 = 5592143577286 := by decide
theorem cert_e1194097066182 : check e1194097066182 [[]] .width = true := by decide
def e1194097829914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194097829914 : Closed e1194097829914 ∧ code e1194097829914 = 5592144341018 := by decide
theorem cert_e1194097829914 : check e1194097829914 [[]] .width = true := by decide
def e1194097879066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194097879066 : Closed e1194097879066 ∧ code e1194097879066 = 5592144390170 := by decide
theorem cert_e1194097879066 : check e1194097879066 [[]] .width = true := by decide
def e1194098276890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098276890 : Closed e1194098276890 ∧ code e1194098276890 = 5592144787994 := by decide
theorem cert_e1194098276890 : check e1194098276890 [[]] .width = true := by decide
def e1194098285082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098285082 : Closed e1194098285082 ∧ code e1194098285082 = 5592144796186 := by decide
theorem cert_e1194098285082 : check e1194098285082 [[]] .width = true := by decide
def e1194098342426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098342426 : Closed e1194098342426 ∧ code e1194098342426 = 5592144853530 := by decide
theorem cert_e1194098342426 : check e1194098342426 [[]] .width = true := by decide
def e1194098354714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098354714 : Closed e1194098354714 ∧ code e1194098354714 = 5592144865818 := by decide
private def t_e1194098354714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194098354714 : ¬ IsSelfInterpreter e1194098354714 :=
  wSource (t := t_e1194098354714) (replay_sound (ps := []) (t := e1194098354714) (by decide)) (by decide)
def e1194098383386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098383386 : Closed e1194098383386 ∧ code e1194098383386 = 5592144894490 := by decide
theorem cert_e1194098383386 : check e1194098383386 [[]] .width = true := by decide
def e1194098387482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098387482 : Closed e1194098387482 ∧ code e1194098387482 = 5592144898586 := by decide
private def t_e1194098387482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194098387482 : ¬ IsSelfInterpreter e1194098387482 :=
  wSource (t := t_e1194098387482) (replay_sound (ps := []) (t := e1194098387482) (by decide)) (by decide)
def e1194098550810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194098550810 : Closed e1194098550810 ∧ code e1194098550810 = 5592145061914 := by decide
theorem cert_e1194098550810 : check e1194098550810 [[]] .width = true := by decide
def e1194098670106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098670106 : Closed e1194098670106 ∧ code e1194098670106 = 5592145181210 := by decide
theorem cert_e1194098670106 : check e1194098670106 [[]] .width = true := by decide
def e1194098678298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194098678298 : Closed e1194098678298 ∧ code e1194098678298 = 5592145189402 := by decide
theorem cert_e1194098678298 : check e1194098678298 [[]] .width = true := by decide
def e1194098888902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194098888902 : Closed e1194098888902 ∧ code e1194098888902 = 5592145400006 := by decide
theorem cert_e1194098888902 : check e1194098888902 [[]] .width = true := by decide
def e1194098890778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194098890778 : Closed e1194098890778 ∧ code e1194098890778 = 5592145401882 := by decide
theorem cert_e1194098890778 : check e1194098890778 [[]] .width = true := by decide
def e1194098901190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194098901190 : Closed e1194098901190 ∧ code e1194098901190 = 5592145412294 := by decide
theorem cert_e1194098901190 : check e1194098901190 [[]] .width = true := by decide
def e1194099063322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099063322 : Closed e1194099063322 ∧ code e1194099063322 = 5592145574426 := by decide
private def t_e1194099063322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194099063322 : ¬ IsSelfInterpreter e1194099063322 :=
  wSource (t := t_e1194099063322) (replay_sound (ps := []) (t := e1194099063322) (by decide)) (by decide)
def e1194099075610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099075610 : Closed e1194099075610 ∧ code e1194099075610 = 5592145586714 := by decide
private def t_e1194099075610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194099075610 : ¬ IsSelfInterpreter e1194099075610 :=
  wSource (t := t_e1194099075610) (replay_sound (ps := []) (t := e1194099075610) (by decide)) (by decide)
def e1194099238938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194099238938 : Closed e1194099238938 ∧ code e1194099238938 = 5592145750042 := by decide
theorem cert_e1194099238938 : check e1194099238938 [[]] .width = true := by decide
def e1194099268122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099268122 : Closed e1194099268122 ∧ code e1194099268122 = 5592145779226 := by decide
private def t_e1194099268122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194099268122 : ¬ IsSelfInterpreter e1194099268122 :=
  wSource (t := t_e1194099268122) (replay_sound (ps := []) (t := e1194099268122) (by decide)) (by decide)
def e1194099272218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099272218 : Closed e1194099272218 ∧ code e1194099272218 = 5592145783322 := by decide
private def t_e1194099272218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194099272218 : ¬ IsSelfInterpreter e1194099272218 :=
  wSource (t := t_e1194099272218) (replay_sound (ps := []) (t := e1194099272218) (by decide)) (by decide)
def e1194099282118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194099282118 : Closed e1194099282118 ∧ code e1194099282118 = 5592145793222 := by decide
theorem cert_e1194099282118 : check e1194099282118 [[]] .width = true := by decide
def e1194099283994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194099283994 : Closed e1194099283994 ∧ code e1194099283994 = 5592145795098 := by decide
theorem cert_e1194099283994 : check e1194099283994 [[]] .width = true := by decide
def e1194099294406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194099294406 : Closed e1194099294406 ∧ code e1194099294406 = 5592145805510 := by decide
theorem cert_e1194099294406 : check e1194099294406 [[]] .width = true := by decide
def e1194099697690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194099697690 : Closed e1194099697690 ∧ code e1194099697690 = 5592146208794 := by decide
theorem cert_e1194099697690 : check e1194099697690 [[]] .width = true := by decide
def e1194099714074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194099714074 : Closed e1194099714074 ∧ code e1194099714074 = 5592146225178 := by decide
theorem cert_e1194099714074 : check e1194099714074 [[]] .width = true := by decide
def e1194099923482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099923482 : Closed e1194099923482 ∧ code e1194099923482 = 5592146434586 := by decide
theorem cert_e1194099923482 : check e1194099923482 [[]] .width = true := by decide
def e1194099956250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099956250 : Closed e1194099956250 ∧ code e1194099956250 = 5592146467354 := by decide
theorem cert_e1194099956250 : check e1194099956250 [[]] .width = true := by decide
def e1194099960346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194099960346 : Closed e1194099960346 ∧ code e1194099960346 = 5592146471450 := by decide
private def t_e1194099960346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194099960346 : ¬ IsSelfInterpreter e1194099960346 :=
  wSource (t := t_e1194099960346) (replay_sound (ps := []) (t := e1194099960346) (by decide)) (by decide)
def e1194100058138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194100058138 : Closed e1194100058138 ∧ code e1194100058138 = 5592146569242 := by decide
theorem cert_e1194100058138 : check e1194100058138 [[]] .width = true := by decide
def e1194100120090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194100120090 : Closed e1194100120090 ∧ code e1194100120090 = 5592146631194 := by decide
theorem cert_e1194100120090 : check e1194100120090 [[]] .width = true := by decide
def e1194100199622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194100199622 : Closed e1194100199622 ∧ code e1194100199622 = 5592146710726 := by decide
theorem cert_e1194100199622 : check e1194100199622 [[]] .width = true := by decide
def e1194100201498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194100201498 : Closed e1194100201498 ∧ code e1194100201498 = 5592146712602 := by decide
theorem cert_e1194100201498 : check e1194100201498 [[]] .width = true := by decide
def e1194100211910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194100211910 : Closed e1194100211910 ∧ code e1194100211910 = 5592146723014 := by decide
theorem cert_e1194100211910 : check e1194100211910 [[]] .width = true := by decide
def e1194100287514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194100287514 : Closed e1194100287514 ∧ code e1194100287514 = 5592146798618 := by decide
theorem cert_e1194100287514 : check e1194100287514 [[]] .width = true := by decide
def e1194100316698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194100316698 : Closed e1194100316698 ∧ code e1194100316698 = 5592146827802 := by decide
private def t_e1194100316698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194100316698 : ¬ IsSelfInterpreter e1194100316698 :=
  wSource (t := t_e1194100316698) (replay_sound (ps := []) (t := e1194100316698) (by decide)) (by decide)
def e1194100320794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194100320794 : Closed e1194100320794 ∧ code e1194100320794 = 5592146831898 := by decide
private def t_e1194100320794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194100320794 : ¬ IsSelfInterpreter e1194100320794 :=
  wSource (t := t_e1194100320794) (replay_sound (ps := []) (t := e1194100320794) (by decide)) (by decide)
def e1194100330694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194100330694 : Closed e1194100330694 ∧ code e1194100330694 = 5592146841798 := by decide
theorem cert_e1194100330694 : check e1194100330694 [[]] .width = true := by decide
def e1194100332570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194100332570 : Closed e1194100332570 ∧ code e1194100332570 = 5592146843674 := by decide
theorem cert_e1194100332570 : check e1194100332570 [[]] .width = true := by decide
def e1194100342982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194100342982 : Closed e1194100342982 ∧ code e1194100342982 = 5592146854086 := by decide
theorem cert_e1194100342982 : check e1194100342982 [[]] .width = true := by decide
def e1194107714074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194107714074 : Closed e1194107714074 ∧ code e1194107714074 = 5592154225178 := by decide
theorem cert_e1194107714074 : check e1194107714074 [[]] .width = true := by decide
def e1194107722266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194107722266 : Closed e1194107722266 ∧ code e1194107722266 = 5592154233370 := by decide
theorem cert_e1194107722266 : check e1194107722266 [[]] .width = true := by decide
def e1194107787802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194107787802 : Closed e1194107787802 ∧ code e1194107787802 = 5592154298906 := by decide
theorem cert_e1194107787802 : check e1194107787802 [[]] .width = true := by decide
def e1194109036570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194109036570 : Closed e1194109036570 ∧ code e1194109036570 = 5592155547674 := by decide
theorem cert_e1194109036570 : check e1194109036570 [[]] .width = true := by decide
def e1194109155866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194109155866 : Closed e1194109155866 ∧ code e1194109155866 = 5592155666970 := by decide
theorem cert_e1194109155866 : check e1194109155866 [[]] .width = true := by decide
def e1194109164058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194109164058 : Closed e1194109164058 ∧ code e1194109164058 = 5592155675162 := by decide
theorem cert_e1194109164058 : check e1194109164058 [[]] .width = true := by decide
def e1194109374662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194109374662 : Closed e1194109374662 ∧ code e1194109374662 = 5592155885766 := by decide
theorem cert_e1194109374662 : check e1194109374662 [[]] .width = true := by decide
def e1194109376538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194109376538 : Closed e1194109376538 ∧ code e1194109376538 = 5592155887642 := by decide
theorem cert_e1194109376538 : check e1194109376538 [[]] .width = true := by decide
def e1194109386950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194109386950 : Closed e1194109386950 ∧ code e1194109386950 = 5592155898054 := by decide
theorem cert_e1194109386950 : check e1194109386950 [[]] .width = true := by decide
def e1194109495322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194109495322 : Closed e1194109495322 ∧ code e1194109495322 = 5592156006426 := by decide
theorem cert_e1194109495322 : check e1194109495322 [[]] .width = true := by decide
def e1194109557274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194109557274 : Closed e1194109557274 ∧ code e1194109557274 = 5592156068378 := by decide
theorem cert_e1194109557274 : check e1194109557274 [[]] .width = true := by decide
def e1194109636806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194109636806 : Closed e1194109636806 ∧ code e1194109636806 = 5592156147910 := by decide
theorem cert_e1194109636806 : check e1194109636806 [[]] .width = true := by decide
def e1194109638682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194109638682 : Closed e1194109638682 ∧ code e1194109638682 = 5592156149786 := by decide
theorem cert_e1194109638682 : check e1194109638682 [[]] .width = true := by decide
def e1194109649094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194109649094 : Closed e1194109649094 ∧ code e1194109649094 = 5592156160198 := by decide
theorem cert_e1194109649094 : check e1194109649094 [[]] .width = true := by decide
def e1194121345562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121345562 : Closed e1194121345562 ∧ code e1194121345562 = 5592167856666 := by decide
theorem cert_e1194121345562 : check e1194121345562 [[]] .width = true := by decide
def e1194121353754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121353754 : Closed e1194121353754 ∧ code e1194121353754 = 5592167864858 := by decide
theorem cert_e1194121353754 : check e1194121353754 [[]] .width = true := by decide
def e1194121411098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121411098 : Closed e1194121411098 ∧ code e1194121411098 = 5592167922202 := by decide
theorem cert_e1194121411098 : check e1194121411098 [[]] .width = true := by decide
def e1194121423386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121423386 : Closed e1194121423386 ∧ code e1194121423386 = 5592167934490 := by decide
private def t_e1194121423386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194121423386 : ¬ IsSelfInterpreter e1194121423386 :=
  wSource (t := t_e1194121423386) (replay_sound (ps := []) (t := e1194121423386) (by decide)) (by decide)
def e1194121452058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121452058 : Closed e1194121452058 ∧ code e1194121452058 = 5592167963162 := by decide
theorem cert_e1194121452058 : check e1194121452058 [[]] .width = true := by decide
def e1194121456154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121456154 : Closed e1194121456154 ∧ code e1194121456154 = 5592167967258 := by decide
private def t_e1194121456154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194121456154 : ¬ IsSelfInterpreter e1194121456154 :=
  wSource (t := t_e1194121456154) (replay_sound (ps := []) (t := e1194121456154) (by decide)) (by decide)
def e1194121619482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194121619482 : Closed e1194121619482 ∧ code e1194121619482 = 5592168130586 := by decide
theorem cert_e1194121619482 : check e1194121619482 [[]] .width = true := by decide
def e1194121738778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121738778 : Closed e1194121738778 ∧ code e1194121738778 = 5592168249882 := by decide
theorem cert_e1194121738778 : check e1194121738778 [[]] .width = true := by decide
def e1194121746970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194121746970 : Closed e1194121746970 ∧ code e1194121746970 = 5592168258074 := by decide
theorem cert_e1194121746970 : check e1194121746970 [[]] .width = true := by decide
def e1194121957574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194121957574 : Closed e1194121957574 ∧ code e1194121957574 = 5592168468678 := by decide
theorem cert_e1194121957574 : check e1194121957574 [[]] .width = true := by decide
def e1194121959450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194121959450 : Closed e1194121959450 ∧ code e1194121959450 = 5592168470554 := by decide
theorem cert_e1194121959450 : check e1194121959450 [[]] .width = true := by decide
def e1194121969862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194121969862 : Closed e1194121969862 ∧ code e1194121969862 = 5592168480966 := by decide
theorem cert_e1194121969862 : check e1194121969862 [[]] .width = true := by decide
def e1194122131994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194122131994 : Closed e1194122131994 ∧ code e1194122131994 = 5592168643098 := by decide
theorem cert_e1194122131994 : check e1194122131994 [[]] .width = true := by decide
def e1194122144282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194122144282 : Closed e1194122144282 ∧ code e1194122144282 = 5592168655386 := by decide
theorem cert_e1194122144282 : check e1194122144282 [[]] .width = true := by decide
def e1194122307610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194122307610 : Closed e1194122307610 ∧ code e1194122307610 = 5592168818714 := by decide
theorem cert_e1194122307610 : check e1194122307610 [[]] .width = true := by decide
def e1194122336794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194122336794 : Closed e1194122336794 ∧ code e1194122336794 = 5592168847898 := by decide
theorem cert_e1194122336794 : check e1194122336794 [[]] .width = true := by decide
def e1194122340890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194122340890 : Closed e1194122340890 ∧ code e1194122340890 = 5592168851994 := by decide
theorem cert_e1194122340890 : check e1194122340890 [[]] .width = true := by decide
def e1194122350790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194122350790 : Closed e1194122350790 ∧ code e1194122350790 = 5592168861894 := by decide
theorem cert_e1194122350790 : check e1194122350790 [[]] .width = true := by decide
def e1194122352666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194122352666 : Closed e1194122352666 ∧ code e1194122352666 = 5592168863770 := by decide
theorem cert_e1194122352666 : check e1194122352666 [[]] .width = true := by decide
def e1194122363078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194122363078 : Closed e1194122363078 ∧ code e1194122363078 = 5592168874182 := by decide
theorem cert_e1194122363078 : check e1194122363078 [[]] .width = true := by decide
def e1194128235034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128235034 : Closed e1194128235034 ∧ code e1194128235034 = 5592174746138 := by decide
theorem cert_e1194128235034 : check e1194128235034 [[]] .width = true := by decide
def e1194128267802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128267802 : Closed e1194128267802 ∧ code e1194128267802 = 5592174778906 := by decide
theorem cert_e1194128267802 : check e1194128267802 [[]] .width = true := by decide
def e1194128271898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128271898 : Closed e1194128271898 ∧ code e1194128271898 = 5592174783002 := by decide
private def t_e1194128271898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194128271898 : ¬ IsSelfInterpreter e1194128271898 :=
  wSource (t := t_e1194128271898) (replay_sound (ps := []) (t := e1194128271898) (by decide)) (by decide)
def e1194128369690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194128369690 : Closed e1194128369690 ∧ code e1194128369690 = 5592174880794 := by decide
theorem cert_e1194128369690 : check e1194128369690 [[]] .width = true := by decide
def e1194128431642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128431642 : Closed e1194128431642 ∧ code e1194128431642 = 5592174942746 := by decide
theorem cert_e1194128431642 : check e1194128431642 [[]] .width = true := by decide
def e1194128511174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194128511174 : Closed e1194128511174 ∧ code e1194128511174 = 5592175022278 := by decide
theorem cert_e1194128511174 : check e1194128511174 [[]] .width = true := by decide
def e1194128513050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194128513050 : Closed e1194128513050 ∧ code e1194128513050 = 5592175024154 := by decide
theorem cert_e1194128513050 : check e1194128513050 [[]] .width = true := by decide
def e1194128523462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194128523462 : Closed e1194128523462 ∧ code e1194128523462 = 5592175034566 := by decide
theorem cert_e1194128523462 : check e1194128523462 [[]] .width = true := by decide
def e1194128599066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194128599066 : Closed e1194128599066 ∧ code e1194128599066 = 5592175110170 := by decide
theorem cert_e1194128599066 : check e1194128599066 [[]] .width = true := by decide
def e1194128628250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128628250 : Closed e1194128628250 ∧ code e1194128628250 = 5592175139354 := by decide
theorem cert_e1194128628250 : check e1194128628250 [[]] .width = true := by decide
def e1194128632346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194128632346 : Closed e1194128632346 ∧ code e1194128632346 = 5592175143450 := by decide
theorem cert_e1194128632346 : check e1194128632346 [[]] .width = true := by decide
def e1194128642246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194128642246 : Closed e1194128642246 ∧ code e1194128642246 = 5592175153350 := by decide
theorem cert_e1194128642246 : check e1194128642246 [[]] .width = true := by decide
def e1194128644122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194128644122 : Closed e1194128644122 ∧ code e1194128644122 = 5592175155226 := by decide
theorem cert_e1194128644122 : check e1194128644122 [[]] .width = true := by decide
def e1194128654534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1194128654534 : Closed e1194128654534 ∧ code e1194128654534 = 5592175165638 := by decide
theorem cert_e1194128654534 : check e1194128654534 [[]] .width = true := by decide
def e1194168769390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1194168769390 : Closed e1194168769390 ∧ code e1194168769390 = 5592215280494 := by decide
theorem cert_e1194168769390 : check e1194168769390 [[],[.left],[]] .sourceHead = true := by decide
def e1194168769398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1194168769398 : Closed e1194168769398 ∧ code e1194168769398 = 5592215280502 := by decide
theorem cert_e1194168769398 : check e1194168769398 [[],[.left],[]] .sourceHead = true := by decide
def e1194168769462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1194168769462 : Closed e1194168769462 ∧ code e1194168769462 = 5592215280566 := by decide
theorem cert_e1194168769462 : check e1194168769462 [[],[.left],[]] .sourceHead = true := by decide
def e1194168769902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1194168769902 : Closed e1194168769902 ∧ code e1194168769902 = 5592215281006 := by decide
def e1194168769910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1194168769910 : Closed e1194168769910 ∧ code e1194168769910 = 5592215281014 := by decide
theorem cert_e1194168769910 : check e1194168769910 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1194168769966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1194168769966 : Closed e1194168769966 ∧ code e1194168769966 = 5592215281070 := by decide
theorem cert_e1194168769966 : check e1194168769966 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e1194168769978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1194168769978 : Closed e1194168769978 ∧ code e1194168769978 = 5592215281082 := by decide
theorem cert_e1194168769978 : check e1194168769978 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e1194168770006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1194168770006 : Closed e1194168770006 ∧ code e1194168770006 = 5592215281110 := by decide
theorem cert_e1194168770006 : check e1194168770006 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1194168770010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1194168770010 : Closed e1194168770010 ∧ code e1194168770010 = 5592215281114 := by decide
def e1194168770230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1194168770230 : Closed e1194168770230 ∧ code e1194168770230 = 5592215281334 := by decide
theorem cert_e1194168770230 : check e1194168770230 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e1194168770262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1194168770262 : Closed e1194168770262 ∧ code e1194168770262 = 5592215281366 := by decide
theorem cert_e1194168770262 : check e1194168770262 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e1194168770266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1194168770266 : Closed e1194168770266 ∧ code e1194168770266 = 5592215281370 := by decide
theorem cert_e1194168770266 : check e1194168770266 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e1194168772462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1194168772462 : Closed e1194168772462 ∧ code e1194168772462 = 5592215283566 := by decide
theorem cert_e1194168772462 : check e1194168772462 [[],[.left],[]] .sourceHead = true := by decide
def e1194168772470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1194168772470 : Closed e1194168772470 ∧ code e1194168772470 = 5592215283574 := by decide
theorem cert_e1194168772470 : check e1194168772470 [[],[.left],[]] .sourceHead = true := by decide
def e1194168772534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1194168772534 : Closed e1194168772534 ∧ code e1194168772534 = 5592215283638 := by decide
theorem cert_e1194168772534 : check e1194168772534 [[],[.left],[]] .sourceHead = true := by decide
def e1194168773870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194168773870 : Closed e1194168773870 ∧ code e1194168773870 = 5592215284974 := by decide
theorem cert_e1194168773870 : check e1194168773870 [[],[.left],[]] .sourceHead = true := by decide
def e1194168773878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194168773878 : Closed e1194168773878 ∧ code e1194168773878 = 5592215284982 := by decide
theorem cert_e1194168773878 : check e1194168773878 [[],[.left],[]] .sourceHead = true := by decide
def e1194168774262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1194168774262 : Closed e1194168774262 ∧ code e1194168774262 = 5592215285366 := by decide
theorem cert_e1194168774262 : check e1194168774262 [[],[.left],[]] .sourceHead = true := by decide
def e1194168775534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1194168775534 : Closed e1194168775534 ∧ code e1194168775534 = 5592215286638 := by decide
theorem cert_e1194168775534 : check e1194168775534 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e1194168775542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1194168775542 : Closed e1194168775542 ∧ code e1194168775542 = 5592215286646 := by decide
theorem cert_e1194168775542 : check e1194168775542 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194168775598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1194168775598 : Closed e1194168775598 ∧ code e1194168775598 = 5592215286702 := by decide
theorem cert_e1194168775598 : check e1194168775598 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e1194168775610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1194168775610 : Closed e1194168775610 ∧ code e1194168775610 = 5592215286714 := by decide
theorem cert_e1194168775610 : check e1194168775610 [[],[.left],[],[.under,.left]] .chain = true := by decide
end Blc.Floor42
