import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e431157718382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e431157718382 : Closed e431157718382 ∧ code e431157718382 = 4829204229486 := by decide
theorem cert_e431157718382 : check e431157718382 [] .sourceHead = true := by decide
def e431157718390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e431157718390 : Closed e431157718390 ∧ code e431157718390 = 4829204229494 := by decide
theorem cert_e431157718390 : check e431157718390 [] .sourceHead = true := by decide
def e431157718446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e431157718446 : Closed e431157718446 ∧ code e431157718446 = 4829204229550 := by decide
theorem cert_e431157718446 : check e431157718446 [] .sourceHead = true := by decide
def e431157718458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e431157718458 : Closed e431157718458 ∧ code e431157718458 = 4829204229562 := by decide
theorem cert_e431157718458 : check e431157718458 [] .sourceHead = true := by decide
def e431157718486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e431157718486 : Closed e431157718486 ∧ code e431157718486 = 4829204229590 := by decide
theorem cert_e431157718486 : check e431157718486 [] .sourceHead = true := by decide
def e431157718490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e431157718490 : Closed e431157718490 ∧ code e431157718490 = 4829204229594 := by decide
theorem cert_e431157718490 : check e431157718490 [] .sourceHead = true := by decide
def e431157718702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e431157718702 : Closed e431157718702 ∧ code e431157718702 = 4829204229806 := by decide
theorem cert_e431157718702 : check e431157718702 [] .sourceHead = true := by decide
def e431157718714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e431157718714 : Closed e431157718714 ∧ code e431157718714 = 4829204229818 := by decide
theorem cert_e431157718714 : check e431157718714 [] .sourceHead = true := by decide
def e431157718762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e431157718762 : Closed e431157718762 ∧ code e431157718762 = 4829204229866 := by decide
theorem cert_e431157718762 : check e431157718762 [] .sourceHead = true := by decide
def e431157718870 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e431157718870 : Closed e431157718870 ∧ code e431157718870 = 4829204229974 := by decide
theorem cert_e431157718870 : check e431157718870 [] .sourceHead = true := by decide
def e431157718874 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e431157718874 : Closed e431157718874 ∧ code e431157718874 = 4829204229978 := by decide
theorem cert_e431157718874 : check e431157718874 [] .sourceHead = true := by decide
def e431157718890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e431157718890 : Closed e431157718890 ∧ code e431157718890 = 4829204229994 := by decide
theorem cert_e431157718890 : check e431157718890 [] .sourceHead = true := by decide
def e431157719918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e431157719918 : Closed e431157719918 ∧ code e431157719918 = 4829204231022 := by decide
theorem cert_e431157719918 : check e431157719918 [] .sourceHead = true := by decide
def e431157719926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e431157719926 : Closed e431157719926 ∧ code e431157719926 = 4829204231030 := by decide
theorem cert_e431157719926 : check e431157719926 [] .sourceHead = true := by decide
def e431157719982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e431157719982 : Closed e431157719982 ∧ code e431157719982 = 4829204231086 := by decide
theorem cert_e431157719982 : check e431157719982 [] .sourceHead = true := by decide
def e431157719994 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e431157719994 : Closed e431157719994 ∧ code e431157719994 = 4829204231098 := by decide
theorem cert_e431157719994 : check e431157719994 [] .sourceHead = true := by decide
def e431157720022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e431157720022 : Closed e431157720022 ∧ code e431157720022 = 4829204231126 := by decide
theorem cert_e431157720022 : check e431157720022 [] .sourceHead = true := by decide
def e431157720026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e431157720026 : Closed e431157720026 ∧ code e431157720026 = 4829204231130 := by decide
theorem cert_e431157720026 : check e431157720026 [] .sourceHead = true := by decide
def e431157720302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e431157720302 : Closed e431157720302 ∧ code e431157720302 = 4829204231406 := by decide
theorem cert_e431157720302 : check e431157720302 [] .sourceHead = true := by decide
def e431157720310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e431157720310 : Closed e431157720310 ∧ code e431157720310 = 4829204231414 := by decide
theorem cert_e431157720310 : check e431157720310 [] .sourceHead = true := by decide
def e431157720686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e431157720686 : Closed e431157720686 ∧ code e431157720686 = 4829204231790 := by decide
theorem cert_e431157720686 : check e431157720686 [] .sourceHead = true := by decide
def e431157720698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e431157720698 : Closed e431157720698 ∧ code e431157720698 = 4829204231802 := by decide
theorem cert_e431157720698 : check e431157720698 [] .sourceHead = true := by decide
def e431157720886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e431157720886 : Closed e431157720886 ∧ code e431157720886 = 4829204231990 := by decide
theorem cert_e431157720886 : check e431157720886 [] .sourceHead = true := by decide
def e431157720890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e431157720890 : Closed e431157720890 ∧ code e431157720890 = 4829204231994 := by decide
theorem cert_e431157720890 : check e431157720890 [] .sourceHead = true := by decide
def e431157721518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e431157721518 : Closed e431157721518 ∧ code e431157721518 = 4829204232622 := by decide
theorem cert_e431157721518 : check e431157721518 [] .sourceHead = true := by decide
def e431157721530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e431157721530 : Closed e431157721530 ∧ code e431157721530 = 4829204232634 := by decide
theorem cert_e431157721530 : check e431157721530 [] .sourceHead = true := by decide
def e431157721578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e431157721578 : Closed e431157721578 ∧ code e431157721578 = 4829204232682 := by decide
theorem cert_e431157721578 : check e431157721578 [] .sourceHead = true := by decide
def e431157721710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e431157721710 : Closed e431157721710 ∧ code e431157721710 = 4829204232814 := by decide
theorem cert_e431157721710 : check e431157721710 [] .sourceHead = true := by decide
def e431157721722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e431157721722 : Closed e431157721722 ∧ code e431157721722 = 4829204232826 := by decide
theorem cert_e431157721722 : check e431157721722 [] .sourceHead = true := by decide
def e431157722010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e431157722010 : Closed e431157722010 ∧ code e431157722010 = 4829204233114 := by decide
theorem cert_e431157722010 : check e431157722010 [] .sourceHead = true := by decide
def e431157722326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e431157722326 : Closed e431157722326 ∧ code e431157722326 = 4829204233430 := by decide
theorem cert_e431157722326 : check e431157722326 [] .sourceHead = true := by decide
def e431157722330 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e431157722330 : Closed e431157722330 ∧ code e431157722330 = 4829204233434 := by decide
theorem cert_e431157722330 : check e431157722330 [] .sourceHead = true := by decide
def e431157722346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e431157722346 : Closed e431157722346 ∧ code e431157722346 = 4829204233450 := by decide
theorem cert_e431157722346 : check e431157722346 [] .sourceHead = true := by decide
def e431157722422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e431157722422 : Closed e431157722422 ∧ code e431157722422 = 4829204233526 := by decide
theorem cert_e431157722422 : check e431157722422 [] .sourceHead = true := by decide
def e431157722426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e431157722426 : Closed e431157722426 ∧ code e431157722426 = 4829204233530 := by decide
theorem cert_e431157722426 : check e431157722426 [] .sourceHead = true := by decide
def e431157722522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e431157722522 : Closed e431157722522 ∧ code e431157722522 = 4829204233626 := by decide
theorem cert_e431157722522 : check e431157722522 [] .sourceHead = true := by decide
def e431157726062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e431157726062 : Closed e431157726062 ∧ code e431157726062 = 4829204237166 := by decide
theorem cert_e431157726062 : check e431157726062 [] .sourceHead = true := by decide
def e431157726070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e431157726070 : Closed e431157726070 ∧ code e431157726070 = 4829204237174 := by decide
theorem cert_e431157726070 : check e431157726070 [] .sourceHead = true := by decide
def e431157726126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e431157726126 : Closed e431157726126 ∧ code e431157726126 = 4829204237230 := by decide
theorem cert_e431157726126 : check e431157726126 [] .sourceHead = true := by decide
def e431157726138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e431157726138 : Closed e431157726138 ∧ code e431157726138 = 4829204237242 := by decide
theorem cert_e431157726138 : check e431157726138 [] .sourceHead = true := by decide
def e431157726166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e431157726166 : Closed e431157726166 ∧ code e431157726166 = 4829204237270 := by decide
theorem cert_e431157726166 : check e431157726166 [] .sourceHead = true := by decide
def e431157726170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e431157726170 : Closed e431157726170 ∧ code e431157726170 = 4829204237274 := by decide
theorem cert_e431157726170 : check e431157726170 [] .sourceHead = true := by decide
def e431157726446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e431157726446 : Closed e431157726446 ∧ code e431157726446 = 4829204237550 := by decide
theorem cert_e431157726446 : check e431157726446 [] .sourceHead = true := by decide
def e431157726454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e431157726454 : Closed e431157726454 ∧ code e431157726454 = 4829204237558 := by decide
theorem cert_e431157726454 : check e431157726454 [] .sourceHead = true := by decide
def e431157726830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e431157726830 : Closed e431157726830 ∧ code e431157726830 = 4829204237934 := by decide
theorem cert_e431157726830 : check e431157726830 [] .sourceHead = true := by decide
def e431157726842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e431157726842 : Closed e431157726842 ∧ code e431157726842 = 4829204237946 := by decide
theorem cert_e431157726842 : check e431157726842 [] .sourceHead = true := by decide
def e431157727030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e431157727030 : Closed e431157727030 ∧ code e431157727030 = 4829204238134 := by decide
theorem cert_e431157727030 : check e431157727030 [] .sourceHead = true := by decide
def e431157727034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e431157727034 : Closed e431157727034 ∧ code e431157727034 = 4829204238138 := by decide
theorem cert_e431157727034 : check e431157727034 [] .sourceHead = true := by decide
def e431157732782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e431157732782 : Closed e431157732782 ∧ code e431157732782 = 4829204243886 := by decide
theorem cert_e431157732782 : check e431157732782 [] .sourceHead = true := by decide
def e431157732794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e431157732794 : Closed e431157732794 ∧ code e431157732794 = 4829204243898 := by decide
theorem cert_e431157732794 : check e431157732794 [] .sourceHead = true := by decide
def e431157732842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e431157732842 : Closed e431157732842 ∧ code e431157732842 = 4829204243946 := by decide
theorem cert_e431157732842 : check e431157732842 [] .sourceHead = true := by decide
def e431157732974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e431157732974 : Closed e431157732974 ∧ code e431157732974 = 4829204244078 := by decide
theorem cert_e431157732974 : check e431157732974 [] .sourceHead = true := by decide
def e431157732986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e431157732986 : Closed e431157732986 ∧ code e431157732986 = 4829204244090 := by decide
theorem cert_e431157732986 : check e431157732986 [] .sourceHead = true := by decide
def e431157733274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e431157733274 : Closed e431157733274 ∧ code e431157733274 = 4829204244378 := by decide
theorem cert_e431157733274 : check e431157733274 [] .sourceHead = true := by decide
def e431157736150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e431157736150 : Closed e431157736150 ∧ code e431157736150 = 4829204247254 := by decide
theorem cert_e431157736150 : check e431157736150 [] .sourceHead = true := by decide
def e431157736154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e431157736154 : Closed e431157736154 ∧ code e431157736154 = 4829204247258 := by decide
theorem cert_e431157736154 : check e431157736154 [] .sourceHead = true := by decide
def e431157736170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e431157736170 : Closed e431157736170 ∧ code e431157736170 = 4829204247274 := by decide
theorem cert_e431157736170 : check e431157736170 [] .sourceHead = true := by decide
def e431157736246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e431157736246 : Closed e431157736246 ∧ code e431157736246 = 4829204247350 := by decide
theorem cert_e431157736246 : check e431157736246 [] .sourceHead = true := by decide
def e431157736250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e431157736250 : Closed e431157736250 ∧ code e431157736250 = 4829204247354 := by decide
theorem cert_e431157736250 : check e431157736250 [] .sourceHead = true := by decide
def e431157736346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e431157736346 : Closed e431157736346 ∧ code e431157736346 = 4829204247450 := by decide
theorem cert_e431157736346 : check e431157736346 [] .sourceHead = true := by decide
def e431157873518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e431157873518 : Closed e431157873518 ∧ code e431157873518 = 4829204384622 := by decide
theorem cert_e431157873518 : check e431157873518 [] .sourceHead = true := by decide
def e431157873526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e431157873526 : Closed e431157873526 ∧ code e431157873526 = 4829204384630 := by decide
theorem cert_e431157873526 : check e431157873526 [] .sourceHead = true := by decide
def e431157873582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e431157873582 : Closed e431157873582 ∧ code e431157873582 = 4829204384686 := by decide
theorem cert_e431157873582 : check e431157873582 [] .sourceHead = true := by decide
def e431157873594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e431157873594 : Closed e431157873594 ∧ code e431157873594 = 4829204384698 := by decide
theorem cert_e431157873594 : check e431157873594 [] .sourceHead = true := by decide
def e431157873622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e431157873622 : Closed e431157873622 ∧ code e431157873622 = 4829204384726 := by decide
theorem cert_e431157873622 : check e431157873622 [] .sourceHead = true := by decide
def e431157873626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e431157873626 : Closed e431157873626 ∧ code e431157873626 = 4829204384730 := by decide
theorem cert_e431157873626 : check e431157873626 [] .sourceHead = true := by decide
def e431157873902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e431157873902 : Closed e431157873902 ∧ code e431157873902 = 4829204385006 := by decide
theorem cert_e431157873902 : check e431157873902 [] .sourceHead = true := by decide
def e431157873910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e431157873910 : Closed e431157873910 ∧ code e431157873910 = 4829204385014 := by decide
theorem cert_e431157873910 : check e431157873910 [] .sourceHead = true := by decide
def e431157874286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e431157874286 : Closed e431157874286 ∧ code e431157874286 = 4829204385390 := by decide
theorem cert_e431157874286 : check e431157874286 [] .sourceHead = true := by decide
def e431157874298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e431157874298 : Closed e431157874298 ∧ code e431157874298 = 4829204385402 := by decide
theorem cert_e431157874298 : check e431157874298 [] .sourceHead = true := by decide
def e431157874486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e431157874486 : Closed e431157874486 ∧ code e431157874486 = 4829204385590 := by decide
theorem cert_e431157874486 : check e431157874486 [] .sourceHead = true := by decide
def e431157874490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e431157874490 : Closed e431157874490 ∧ code e431157874490 = 4829204385594 := by decide
theorem cert_e431157874490 : check e431157874490 [] .sourceHead = true := by decide
def e431158463342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e431158463342 : Closed e431158463342 ∧ code e431158463342 = 4829204974446 := by decide
theorem cert_e431158463342 : check e431158463342 [] .sourceHead = true := by decide
def e431158463350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e431158463350 : Closed e431158463350 ∧ code e431158463350 = 4829204974454 := by decide
theorem cert_e431158463350 : check e431158463350 [] .sourceHead = true := by decide
def e431158463406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e431158463406 : Closed e431158463406 ∧ code e431158463406 = 4829204974510 := by decide
theorem cert_e431158463406 : check e431158463406 [] .sourceHead = true := by decide
def e431158463418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e431158463418 : Closed e431158463418 ∧ code e431158463418 = 4829204974522 := by decide
theorem cert_e431158463418 : check e431158463418 [] .sourceHead = true := by decide
def e431158463446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e431158463446 : Closed e431158463446 ∧ code e431158463446 = 4829204974550 := by decide
theorem cert_e431158463446 : check e431158463446 [] .sourceHead = true := by decide
def e431158463450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e431158463450 : Closed e431158463450 ∧ code e431158463450 = 4829204974554 := by decide
theorem cert_e431158463450 : check e431158463450 [] .sourceHead = true := by decide
def e431158463726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e431158463726 : Closed e431158463726 ∧ code e431158463726 = 4829204974830 := by decide
theorem cert_e431158463726 : check e431158463726 [] .sourceHead = true := by decide
def e431158463734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e431158463734 : Closed e431158463734 ∧ code e431158463734 = 4829204974838 := by decide
theorem cert_e431158463734 : check e431158463734 [] .sourceHead = true := by decide
def e431158464110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e431158464110 : Closed e431158464110 ∧ code e431158464110 = 4829204975214 := by decide
theorem cert_e431158464110 : check e431158464110 [] .sourceHead = true := by decide
def e431158464122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e431158464122 : Closed e431158464122 ∧ code e431158464122 = 4829204975226 := by decide
theorem cert_e431158464122 : check e431158464122 [] .sourceHead = true := by decide
def e431158464310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e431158464310 : Closed e431158464310 ∧ code e431158464310 = 4829204975414 := by decide
theorem cert_e431158464310 : check e431158464310 [] .sourceHead = true := by decide
def e431158464314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e431158464314 : Closed e431158464314 ∧ code e431158464314 = 4829204975418 := by decide
theorem cert_e431158464314 : check e431158464314 [] .sourceHead = true := by decide
def e431241648862 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e431241648862 : Closed e431241648862 ∧ code e431241648862 = 4829288159966 := by decide
theorem cert_e431241648862 : check e431241648862 [] .sourceHead = true := by decide
def e431241648886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e431241648886 : Closed e431241648886 ∧ code e431241648886 = 4829288159990 := by decide
theorem cert_e431241648886 : check e431241648886 [] .sourceHead = true := by decide
def e431241648990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e431241648990 : Closed e431241648990 ∧ code e431241648990 = 4829288160094 := by decide
theorem cert_e431241648990 : check e431241648990 [] .sourceHead = true := by decide
def e431241649006 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e431241649006 : Closed e431241649006 ∧ code e431241649006 = 4829288160110 := by decide
theorem cert_e431241649006 : check e431241649006 [] .sourceHead = true := by decide
def e431241649014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e431241649014 : Closed e431241649014 ∧ code e431241649014 = 4829288160118 := by decide
theorem cert_e431241649014 : check e431241649014 [] .sourceHead = true := by decide
def e431241649018 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e431241649018 : Closed e431241649018 ∧ code e431241649018 = 4829288160122 := by decide
theorem cert_e431241649018 : check e431241649018 [] .sourceHead = true := by decide
def e431241649078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e431241649078 : Closed e431241649078 ∧ code e431241649078 = 4829288160182 := by decide
theorem cert_e431241649078 : check e431241649078 [] .sourceHead = true := by decide
def e431241649110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e431241649110 : Closed e431241649110 ∧ code e431241649110 = 4829288160214 := by decide
theorem cert_e431241649110 : check e431241649110 [] .sourceHead = true := by decide
def e431241649114 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e431241649114 : Closed e431241649114 ∧ code e431241649114 = 4829288160218 := by decide
theorem cert_e431241649114 : check e431241649114 [] .sourceHead = true := by decide
def e431241649502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e431241649502 : Closed e431241649502 ∧ code e431241649502 = 4829288160606 := by decide
theorem cert_e431241649502 : check e431241649502 [] .sourceHead = true := by decide
def e431241649518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e431241649518 : Closed e431241649518 ∧ code e431241649518 = 4829288160622 := by decide
theorem cert_e431241649518 : check e431241649518 [] .sourceHead = true := by decide
def e431241649526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e431241649526 : Closed e431241649526 ∧ code e431241649526 = 4829288160630 := by decide
theorem cert_e431241649526 : check e431241649526 [] .sourceHead = true := by decide
def e431241649530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e431241649530 : Closed e431241649530 ∧ code e431241649530 = 4829288160634 := by decide
theorem cert_e431241649530 : check e431241649530 [] .sourceHead = true := by decide
def e431241649582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e431241649582 : Closed e431241649582 ∧ code e431241649582 = 4829288160686 := by decide
theorem cert_e431241649582 : check e431241649582 [] .sourceHead = true := by decide
def e431241649594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e431241649594 : Closed e431241649594 ∧ code e431241649594 = 4829288160698 := by decide
theorem cert_e431241649594 : check e431241649594 [] .sourceHead = true := by decide
def e431241649622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e431241649622 : Closed e431241649622 ∧ code e431241649622 = 4829288160726 := by decide
theorem cert_e431241649622 : check e431241649622 [] .sourceHead = true := by decide
def e431241649626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e431241649626 : Closed e431241649626 ∧ code e431241649626 = 4829288160730 := by decide
theorem cert_e431241649626 : check e431241649626 [] .sourceHead = true := by decide
def e431241649642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e431241649642 : Closed e431241649642 ∧ code e431241649642 = 4829288160746 := by decide
theorem cert_e431241649642 : check e431241649642 [] .sourceHead = true := by decide
def e431241649846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e431241649846 : Closed e431241649846 ∧ code e431241649846 = 4829288160950 := by decide
theorem cert_e431241649846 : check e431241649846 [] .sourceHead = true := by decide
def e431241649878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e431241649878 : Closed e431241649878 ∧ code e431241649878 = 4829288160982 := by decide
theorem cert_e431241649878 : check e431241649878 [] .sourceHead = true := by decide
def e431241649882 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e431241649882 : Closed e431241649882 ∧ code e431241649882 = 4829288160986 := by decide
theorem cert_e431241649882 : check e431241649882 [] .sourceHead = true := by decide
def e431241650006 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e431241650006 : Closed e431241650006 ∧ code e431241650006 = 4829288161110 := by decide
theorem cert_e431241650006 : check e431241650006 [] .sourceHead = true := by decide
def e431241650010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e431241650010 : Closed e431241650010 ∧ code e431241650010 = 4829288161114 := by decide
theorem cert_e431241650010 : check e431241650010 [] .sourceHead = true := by decide
def e431241650026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e431241650026 : Closed e431241650026 ∧ code e431241650026 = 4829288161130 := by decide
theorem cert_e431241650026 : check e431241650026 [] .sourceHead = true := by decide
def e431241651934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e431241651934 : Closed e431241651934 ∧ code e431241651934 = 4829288163038 := by decide
theorem cert_e431241651934 : check e431241651934 [] .sourceHead = true := by decide
def e431241651958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e431241651958 : Closed e431241651958 ∧ code e431241651958 = 4829288163062 := by decide
theorem cert_e431241651958 : check e431241651958 [] .sourceHead = true := by decide
def e431241652062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e431241652062 : Closed e431241652062 ∧ code e431241652062 = 4829288163166 := by decide
theorem cert_e431241652062 : check e431241652062 [] .sourceHead = true := by decide
def e431241652078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e431241652078 : Closed e431241652078 ∧ code e431241652078 = 4829288163182 := by decide
theorem cert_e431241652078 : check e431241652078 [] .sourceHead = true := by decide
def e431241652086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e431241652086 : Closed e431241652086 ∧ code e431241652086 = 4829288163190 := by decide
theorem cert_e431241652086 : check e431241652086 [] .sourceHead = true := by decide
def e431241652090 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e431241652090 : Closed e431241652090 ∧ code e431241652090 = 4829288163194 := by decide
theorem cert_e431241652090 : check e431241652090 [] .sourceHead = true := by decide
def e431241652150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e431241652150 : Closed e431241652150 ∧ code e431241652150 = 4829288163254 := by decide
theorem cert_e431241652150 : check e431241652150 [] .sourceHead = true := by decide
def e431241652182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e431241652182 : Closed e431241652182 ∧ code e431241652182 = 4829288163286 := by decide
theorem cert_e431241652182 : check e431241652182 [] .sourceHead = true := by decide
def e431241652186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e431241652186 : Closed e431241652186 ∧ code e431241652186 = 4829288163290 := by decide
theorem cert_e431241652186 : check e431241652186 [] .sourceHead = true := by decide
def e431241652702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e431241652702 : Closed e431241652702 ∧ code e431241652702 = 4829288163806 := by decide
theorem cert_e431241652702 : check e431241652702 [] .sourceHead = true := by decide
def e431241652726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e431241652726 : Closed e431241652726 ∧ code e431241652726 = 4829288163830 := by decide
theorem cert_e431241652726 : check e431241652726 [] .sourceHead = true := by decide
def e431241653470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e431241653470 : Closed e431241653470 ∧ code e431241653470 = 4829288164574 := by decide
theorem cert_e431241653470 : check e431241653470 [] .sourceHead = true := by decide
def e431241653486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e431241653486 : Closed e431241653486 ∧ code e431241653486 = 4829288164590 := by decide
theorem cert_e431241653486 : check e431241653486 [] .sourceHead = true := by decide
def e431241653494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e431241653494 : Closed e431241653494 ∧ code e431241653494 = 4829288164598 := by decide
theorem cert_e431241653494 : check e431241653494 [] .sourceHead = true := by decide
def e431241653498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e431241653498 : Closed e431241653498 ∧ code e431241653498 = 4829288164602 := by decide
theorem cert_e431241653498 : check e431241653498 [] .sourceHead = true := by decide
def e431241653878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e431241653878 : Closed e431241653878 ∧ code e431241653878 = 4829288164982 := by decide
theorem cert_e431241653878 : check e431241653878 [] .sourceHead = true := by decide
def e431241654070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e431241654070 : Closed e431241654070 ∧ code e431241654070 = 4829288165174 := by decide
theorem cert_e431241654070 : check e431241654070 [] .sourceHead = true := by decide
def e431241654074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e431241654074 : Closed e431241654074 ∧ code e431241654074 = 4829288165178 := by decide
theorem cert_e431241654074 : check e431241654074 [] .sourceHead = true := by decide
def e431241655134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e431241655134 : Closed e431241655134 ∧ code e431241655134 = 4829288166238 := by decide
theorem cert_e431241655134 : check e431241655134 [] .sourceHead = true := by decide
def e431241655150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e431241655150 : Closed e431241655150 ∧ code e431241655150 = 4829288166254 := by decide
theorem cert_e431241655150 : check e431241655150 [] .sourceHead = true := by decide
def e431241655158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e431241655158 : Closed e431241655158 ∧ code e431241655158 = 4829288166262 := by decide
theorem cert_e431241655158 : check e431241655158 [] .sourceHead = true := by decide
def e431241655162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e431241655162 : Closed e431241655162 ∧ code e431241655162 = 4829288166266 := by decide
theorem cert_e431241655162 : check e431241655162 [] .sourceHead = true := by decide
def e431241655214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e431241655214 : Closed e431241655214 ∧ code e431241655214 = 4829288166318 := by decide
theorem cert_e431241655214 : check e431241655214 [] .sourceHead = true := by decide
def e431241655226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e431241655226 : Closed e431241655226 ∧ code e431241655226 = 4829288166330 := by decide
theorem cert_e431241655226 : check e431241655226 [] .sourceHead = true := by decide
def e431241655254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e431241655254 : Closed e431241655254 ∧ code e431241655254 = 4829288166358 := by decide
theorem cert_e431241655254 : check e431241655254 [] .sourceHead = true := by decide
def e431241655258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e431241655258 : Closed e431241655258 ∧ code e431241655258 = 4829288166362 := by decide
theorem cert_e431241655258 : check e431241655258 [] .sourceHead = true := by decide
def e431241655274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e431241655274 : Closed e431241655274 ∧ code e431241655274 = 4829288166378 := by decide
theorem cert_e431241655274 : check e431241655274 [] .sourceHead = true := by decide
def e431241655518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e431241655518 : Closed e431241655518 ∧ code e431241655518 = 4829288166622 := by decide
theorem cert_e431241655518 : check e431241655518 [] .sourceHead = true := by decide
def e431241655534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e431241655534 : Closed e431241655534 ∧ code e431241655534 = 4829288166638 := by decide
theorem cert_e431241655534 : check e431241655534 [] .sourceHead = true := by decide
def e431241655542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e431241655542 : Closed e431241655542 ∧ code e431241655542 = 4829288166646 := by decide
theorem cert_e431241655542 : check e431241655542 [] .sourceHead = true := by decide
def e431241655546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e431241655546 : Closed e431241655546 ∧ code e431241655546 = 4829288166650 := by decide
theorem cert_e431241655546 : check e431241655546 [] .sourceHead = true := by decide
def e431241655918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e431241655918 : Closed e431241655918 ∧ code e431241655918 = 4829288167022 := by decide
theorem cert_e431241655918 : check e431241655918 [] .sourceHead = true := by decide
def e431241655930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e431241655930 : Closed e431241655930 ∧ code e431241655930 = 4829288167034 := by decide
theorem cert_e431241655930 : check e431241655930 [] .sourceHead = true := by decide
def e431241656118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e431241656118 : Closed e431241656118 ∧ code e431241656118 = 4829288167222 := by decide
theorem cert_e431241656118 : check e431241656118 [] .sourceHead = true := by decide
def e431241656122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e431241656122 : Closed e431241656122 ∧ code e431241656122 = 4829288167226 := by decide
theorem cert_e431241656122 : check e431241656122 [] .sourceHead = true := by decide
def e431241656218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e431241656218 : Closed e431241656218 ∧ code e431241656218 = 4829288167322 := by decide
theorem cert_e431241656218 : check e431241656218 [] .sourceHead = true := by decide
def e431241656758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e431241656758 : Closed e431241656758 ∧ code e431241656758 = 4829288167862 := by decide
theorem cert_e431241656758 : check e431241656758 [] .sourceHead = true := by decide
def e431241656790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e431241656790 : Closed e431241656790 ∧ code e431241656790 = 4829288167894 := by decide
theorem cert_e431241656790 : check e431241656790 [] .sourceHead = true := by decide
def e431241656794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e431241656794 : Closed e431241656794 ∧ code e431241656794 = 4829288167898 := by decide
theorem cert_e431241656794 : check e431241656794 [] .sourceHead = true := by decide
def e431241656950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e431241656950 : Closed e431241656950 ∧ code e431241656950 = 4829288168054 := by decide
theorem cert_e431241656950 : check e431241656950 [] .sourceHead = true := by decide
def e431241657142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e431241657142 : Closed e431241657142 ∧ code e431241657142 = 4829288168246 := by decide
theorem cert_e431241657142 : check e431241657142 [] .sourceHead = true := by decide
def e431241657146 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e431241657146 : Closed e431241657146 ∧ code e431241657146 = 4829288168250 := by decide
theorem cert_e431241657146 : check e431241657146 [] .sourceHead = true := by decide
def e431241657558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e431241657558 : Closed e431241657558 ∧ code e431241657558 = 4829288168662 := by decide
theorem cert_e431241657558 : check e431241657558 [] .sourceHead = true := by decide
def e431241657562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e431241657562 : Closed e431241657562 ∧ code e431241657562 = 4829288168666 := by decide
theorem cert_e431241657562 : check e431241657562 [] .sourceHead = true := by decide
def e431241657578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e431241657578 : Closed e431241657578 ∧ code e431241657578 = 4829288168682 := by decide
theorem cert_e431241657578 : check e431241657578 [] .sourceHead = true := by decide
def e431241657654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e431241657654 : Closed e431241657654 ∧ code e431241657654 = 4829288168758 := by decide
theorem cert_e431241657654 : check e431241657654 [] .sourceHead = true := by decide
def e431241657658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e431241657658 : Closed e431241657658 ∧ code e431241657658 = 4829288168762 := by decide
theorem cert_e431241657658 : check e431241657658 [] .sourceHead = true := by decide
def e431241657754 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e431241657754 : Closed e431241657754 ∧ code e431241657754 = 4829288168858 := by decide
theorem cert_e431241657754 : check e431241657754 [] .sourceHead = true := by decide
def e431241664222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e431241664222 : Closed e431241664222 ∧ code e431241664222 = 4829288175326 := by decide
theorem cert_e431241664222 : check e431241664222 [] .sourceHead = true := by decide
def e431241664246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e431241664246 : Closed e431241664246 ∧ code e431241664246 = 4829288175350 := by decide
theorem cert_e431241664246 : check e431241664246 [] .sourceHead = true := by decide
def e431241664350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e431241664350 : Closed e431241664350 ∧ code e431241664350 = 4829288175454 := by decide
theorem cert_e431241664350 : check e431241664350 [] .sourceHead = true := by decide
def e431241664366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e431241664366 : Closed e431241664366 ∧ code e431241664366 = 4829288175470 := by decide
theorem cert_e431241664366 : check e431241664366 [] .sourceHead = true := by decide
end Blc.Floor42
