import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131187115894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1131187115894 : Closed e1131187115894 ∧ code e1131187115894 = 5529233626998 := by decide
theorem cert_e1131187115894 : check e1131187115894 [[],[.under]] .smaller = true := by decide
def e1131187115898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1131187115898 : Closed e1131187115898 ∧ code e1131187115898 = 5529233627002 := by decide
theorem cert_e1131187115898 : check e1131187115898 [[],[.under]] .smaller = true := by decide
def e1131187115958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1131187115958 : Closed e1131187115958 ∧ code e1131187115958 = 5529233627062 := by decide
theorem cert_e1131187115958 : check e1131187115958 [[],[.under]] .smaller = true := by decide
def e1131187115990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1131187115990 : Closed e1131187115990 ∧ code e1131187115990 = 5529233627094 := by decide
theorem cert_e1131187115990 : check e1131187115990 [[],[.under]] .smaller = true := by decide
def e1131187115994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1131187115994 : Closed e1131187115994 ∧ code e1131187115994 = 5529233627098 := by decide
theorem cert_e1131187115994 : check e1131187115994 [[],[.under]] .smaller = true := by decide
def e1131187116510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1131187116510 : Closed e1131187116510 ∧ code e1131187116510 = 5529233627614 := by decide
theorem cert_e1131187116510 : check e1131187116510 [[],[.under]] .smaller = true := by decide
def e1131187116534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1131187116534 : Closed e1131187116534 ∧ code e1131187116534 = 5529233627638 := by decide
theorem cert_e1131187116534 : check e1131187116534 [[],[.under]] .smaller = true := by decide
def e1131187117278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1131187117278 : Closed e1131187117278 ∧ code e1131187117278 = 5529233628382 := by decide
theorem cert_e1131187117278 : check e1131187117278 [[],[.under]] .smaller = true := by decide
def e1131187117294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1131187117294 : Closed e1131187117294 ∧ code e1131187117294 = 5529233628398 := by decide
theorem cert_e1131187117294 : check e1131187117294 [[],[.under]] .smaller = true := by decide
def e1131187117302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1131187117302 : Closed e1131187117302 ∧ code e1131187117302 = 5529233628406 := by decide
theorem cert_e1131187117302 : check e1131187117302 [[],[.under]] .smaller = true := by decide
def e1131187117306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1131187117306 : Closed e1131187117306 ∧ code e1131187117306 = 5529233628410 := by decide
theorem cert_e1131187117306 : check e1131187117306 [[],[.under]] .smaller = true := by decide
def e1131187117686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1131187117686 : Closed e1131187117686 ∧ code e1131187117686 = 5529233628790 := by decide
theorem cert_e1131187117686 : check e1131187117686 [[],[.under]] .smaller = true := by decide
def e1131187117878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187117878 : Closed e1131187117878 ∧ code e1131187117878 = 5529233628982 := by decide
theorem cert_e1131187117878 : check e1131187117878 [[],[.under]] .smaller = true := by decide
def e1131187117882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187117882 : Closed e1131187117882 ∧ code e1131187117882 = 5529233628986 := by decide
theorem cert_e1131187117882 : check e1131187117882 [[],[.under]] .smaller = true := by decide
def e1131187129182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1131187129182 : Closed e1131187129182 ∧ code e1131187129182 = 5529233640286 := by decide
theorem cert_e1131187129182 : check e1131187129182 [[],[.under]] .smaller = true := by decide
def e1131187129198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1131187129198 : Closed e1131187129198 ∧ code e1131187129198 = 5529233640302 := by decide
theorem cert_e1131187129198 : check e1131187129198 [[],[.under]] .smaller = true := by decide
def e1131187129206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1131187129206 : Closed e1131187129206 ∧ code e1131187129206 = 5529233640310 := by decide
theorem cert_e1131187129206 : check e1131187129206 [[],[.under]] .smaller = true := by decide
def e1131187129210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1131187129210 : Closed e1131187129210 ∧ code e1131187129210 = 5529233640314 := by decide
theorem cert_e1131187129210 : check e1131187129210 [[],[.under]] .smaller = true := by decide
def e1131187129262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1131187129262 : Closed e1131187129262 ∧ code e1131187129262 = 5529233640366 := by decide
theorem cert_e1131187129262 : check e1131187129262 [[],[.under]] .smaller = true := by decide
def e1131187129274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1131187129274 : Closed e1131187129274 ∧ code e1131187129274 = 5529233640378 := by decide
theorem cert_e1131187129274 : check e1131187129274 [[],[.under]] .smaller = true := by decide
def e1131187129302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1131187129302 : Closed e1131187129302 ∧ code e1131187129302 = 5529233640406 := by decide
theorem cert_e1131187129302 : check e1131187129302 [[],[.under]] .smaller = true := by decide
def e1131187129306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1131187129306 : Closed e1131187129306 ∧ code e1131187129306 = 5529233640410 := by decide
theorem cert_e1131187129306 : check e1131187129306 [[],[.under]] .smaller = true := by decide
def e1131187129322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1131187129322 : Closed e1131187129322 ∧ code e1131187129322 = 5529233640426 := by decide
theorem cert_e1131187129322 : check e1131187129322 [[],[.under]] .smaller = true := by decide
def e1131187129566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1131187129566 : Closed e1131187129566 ∧ code e1131187129566 = 5529233640670 := by decide
theorem cert_e1131187129566 : check e1131187129566 [[],[.under]] .smaller = true := by decide
def e1131187129582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1131187129582 : Closed e1131187129582 ∧ code e1131187129582 = 5529233640686 := by decide
theorem cert_e1131187129582 : check e1131187129582 [[],[.under]] .smaller = true := by decide
def e1131187129590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1131187129590 : Closed e1131187129590 ∧ code e1131187129590 = 5529233640694 := by decide
theorem cert_e1131187129590 : check e1131187129590 [[],[.under]] .smaller = true := by decide
def e1131187129594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1131187129594 : Closed e1131187129594 ∧ code e1131187129594 = 5529233640698 := by decide
theorem cert_e1131187129594 : check e1131187129594 [[],[.under]] .smaller = true := by decide
def e1131187129966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1131187129966 : Closed e1131187129966 ∧ code e1131187129966 = 5529233641070 := by decide
theorem cert_e1131187129966 : check e1131187129966 [[],[.under]] .smaller = true := by decide
def e1131187129978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1131187129978 : Closed e1131187129978 ∧ code e1131187129978 = 5529233641082 := by decide
theorem cert_e1131187129978 : check e1131187129978 [[],[.under]] .smaller = true := by decide
def e1131187130166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187130166 : Closed e1131187130166 ∧ code e1131187130166 = 5529233641270 := by decide
theorem cert_e1131187130166 : check e1131187130166 [[],[.under]] .smaller = true := by decide
def e1131187130170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187130170 : Closed e1131187130170 ∧ code e1131187130170 = 5529233641274 := by decide
theorem cert_e1131187130170 : check e1131187130170 [[],[.under]] .smaller = true := by decide
def e1131187130266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1131187130266 : Closed e1131187130266 ∧ code e1131187130266 = 5529233641370 := by decide
theorem cert_e1131187130266 : check e1131187130266 [[],[.under]] .smaller = true := by decide
def e1131187135926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1131187135926 : Closed e1131187135926 ∧ code e1131187135926 = 5529233647030 := by decide
theorem cert_e1131187135926 : check e1131187135926 [[],[.under]] .smaller = true := by decide
def e1131187135958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1131187135958 : Closed e1131187135958 ∧ code e1131187135958 = 5529233647062 := by decide
theorem cert_e1131187135958 : check e1131187135958 [[],[.under]] .smaller = true := by decide
def e1131187135962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1131187135962 : Closed e1131187135962 ∧ code e1131187135962 = 5529233647066 := by decide
theorem cert_e1131187135962 : check e1131187135962 [[],[.under]] .smaller = true := by decide
def e1131187136118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1131187136118 : Closed e1131187136118 ∧ code e1131187136118 = 5529233647222 := by decide
theorem cert_e1131187136118 : check e1131187136118 [[],[.under]] .smaller = true := by decide
def e1131187136310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187136310 : Closed e1131187136310 ∧ code e1131187136310 = 5529233647414 := by decide
theorem cert_e1131187136310 : check e1131187136310 [[],[.under]] .smaller = true := by decide
def e1131187136314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187136314 : Closed e1131187136314 ∧ code e1131187136314 = 5529233647418 := by decide
theorem cert_e1131187136314 : check e1131187136314 [[],[.under]] .smaller = true := by decide
def e1131187139286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1131187139286 : Closed e1131187139286 ∧ code e1131187139286 = 5529233650390 := by decide
theorem cert_e1131187139286 : check e1131187139286 [[],[.under]] .smaller = true := by decide
def e1131187139290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1131187139290 : Closed e1131187139290 ∧ code e1131187139290 = 5529233650394 := by decide
theorem cert_e1131187139290 : check e1131187139290 [[],[.under]] .smaller = true := by decide
def e1131187139306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1131187139306 : Closed e1131187139306 ∧ code e1131187139306 = 5529233650410 := by decide
theorem cert_e1131187139306 : check e1131187139306 [[],[.under]] .smaller = true := by decide
def e1131187139382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187139382 : Closed e1131187139382 ∧ code e1131187139382 = 5529233650486 := by decide
theorem cert_e1131187139382 : check e1131187139382 [[],[.under]] .smaller = true := by decide
def e1131187139386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187139386 : Closed e1131187139386 ∧ code e1131187139386 = 5529233650490 := by decide
theorem cert_e1131187139386 : check e1131187139386 [[],[.under]] .smaller = true := by decide
def e1131187139482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1131187139482 : Closed e1131187139482 ∧ code e1131187139482 = 5529233650586 := by decide
theorem cert_e1131187139482 : check e1131187139482 [[],[.under]] .smaller = true := by decide
def e1131187364718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1131187364718 : Closed e1131187364718 ∧ code e1131187364718 = 5529233875822 := by decide
theorem cert_e1131187364718 : check e1131187364718 [[],[.under]] .smaller = true := by decide
def e1131187364726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1131187364726 : Closed e1131187364726 ∧ code e1131187364726 = 5529233875830 := by decide
theorem cert_e1131187364726 : check e1131187364726 [[],[.under]] .smaller = true := by decide
def e1131187364782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1131187364782 : Closed e1131187364782 ∧ code e1131187364782 = 5529233875886 := by decide
theorem cert_e1131187364782 : check e1131187364782 [[],[.under]] .smaller = true := by decide
def e1131187364794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1131187364794 : Closed e1131187364794 ∧ code e1131187364794 = 5529233875898 := by decide
theorem cert_e1131187364794 : check e1131187364794 [[],[.under]] .smaller = true := by decide
def e1131187364822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1131187364822 : Closed e1131187364822 ∧ code e1131187364822 = 5529233875926 := by decide
theorem cert_e1131187364822 : check e1131187364822 [[],[.under]] .smaller = true := by decide
def e1131187364826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1131187364826 : Closed e1131187364826 ∧ code e1131187364826 = 5529233875930 := by decide
theorem cert_e1131187364826 : check e1131187364826 [[],[.under]] .smaller = true := by decide
def e1131187366126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1131187366126 : Closed e1131187366126 ∧ code e1131187366126 = 5529233877230 := by decide
theorem cert_e1131187366126 : check e1131187366126 [[],[.under]] .smaller = true := by decide
def e1131187366134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1131187366134 : Closed e1131187366134 ∧ code e1131187366134 = 5529233877238 := by decide
theorem cert_e1131187366134 : check e1131187366134 [[],[.under]] .smaller = true := by decide
def e1131187366686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1131187366686 : Closed e1131187366686 ∧ code e1131187366686 = 5529233877790 := by decide
theorem cert_e1131187366686 : check e1131187366686 [[],[.under]] .smaller = true := by decide
def e1131187366798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1131187366798 : Closed e1131187366798 ∧ code e1131187366798 = 5529233877902 := by decide
theorem cert_e1131187366798 : check e1131187366798 [[],[.under]] .smaller = true := by decide
def e1131187367022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1131187367022 : Closed e1131187367022 ∧ code e1131187367022 = 5529233878126 := by decide
theorem cert_e1131187367022 : check e1131187367022 [[],[.under]] .smaller = true := by decide
def e1131187367034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1131187367034 : Closed e1131187367034 ∧ code e1131187367034 = 5529233878138 := by decide
theorem cert_e1131187367034 : check e1131187367034 [[],[.under]] .smaller = true := by decide
def e1131187367198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1131187367198 : Closed e1131187367198 ∧ code e1131187367198 = 5529233878302 := by decide
theorem cert_e1131187367198 : check e1131187367198 [[],[.under]] .smaller = true := by decide
def e1131187367366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1131187367366 : Closed e1131187367366 ∧ code e1131187367366 = 5529233878470 := by decide
theorem cert_e1131187367366 : check e1131187367366 [[],[.under]] .smaller = true := by decide
def e1131187367478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1131187367478 : Closed e1131187367478 ∧ code e1131187367478 = 5529233878582 := by decide
theorem cert_e1131187367478 : check e1131187367478 [[],[.under]] .smaller = true := by decide
def e1131187367482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1131187367482 : Closed e1131187367482 ∧ code e1131187367482 = 5529233878586 := by decide
theorem cert_e1131187367482 : check e1131187367482 [[],[.under]] .smaller = true := by decide
def e1131187367566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1131187367566 : Closed e1131187367566 ∧ code e1131187367566 = 5529233878670 := by decide
theorem cert_e1131187367566 : check e1131187367566 [[],[.under]] .smaller = true := by decide
def e1131187367622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1131187367622 : Closed e1131187367622 ∧ code e1131187367622 = 5529233878726 := by decide
theorem cert_e1131187367622 : check e1131187367622 [[],[.under]] .smaller = true := by decide
def e1131187368366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1131187368366 : Closed e1131187368366 ∧ code e1131187368366 = 5529233879470 := by decide
theorem cert_e1131187368366 : check e1131187368366 [[],[.under]] .smaller = true := by decide
def e1131187368378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1131187368378 : Closed e1131187368378 ∧ code e1131187368378 = 5529233879482 := by decide
theorem cert_e1131187368378 : check e1131187368378 [[],[.under]] .smaller = true := by decide
def e1131187368426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1131187368426 : Closed e1131187368426 ∧ code e1131187368426 = 5529233879530 := by decide
theorem cert_e1131187368426 : check e1131187368426 [[],[.under]] .smaller = true := by decide
def e1131187369070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1131187369070 : Closed e1131187369070 ∧ code e1131187369070 = 5529233880174 := by decide
theorem cert_e1131187369070 : check e1131187369070 [[],[.under]] .smaller = true := by decide
def e1131187369082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1131187369082 : Closed e1131187369082 ∧ code e1131187369082 = 5529233880186 := by decide
theorem cert_e1131187369082 : check e1131187369082 [[],[.under]] .smaller = true := by decide
def e1131187369246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1131187369246 : Closed e1131187369246 ∧ code e1131187369246 = 5529233880350 := by decide
theorem cert_e1131187369246 : check e1131187369246 [[],[.under]] .smaller = true := by decide
def e1131187369414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1131187369414 : Closed e1131187369414 ∧ code e1131187369414 = 5529233880518 := by decide
theorem cert_e1131187369414 : check e1131187369414 [[],[.under]] .smaller = true := by decide
def e1131187369754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1131187369754 : Closed e1131187369754 ∧ code e1131187369754 = 5529233880858 := by decide
theorem cert_e1131187369754 : check e1131187369754 [[],[.under]] .smaller = true := by decide
def e1131187369798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1131187369798 : Closed e1131187369798 ∧ code e1131187369798 = 5529233880902 := by decide
theorem cert_e1131187369798 : check e1131187369798 [[],[.under]] .smaller = true := by decide
def e1131187370198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1131187370198 : Closed e1131187370198 ∧ code e1131187370198 = 5529233881302 := by decide
theorem cert_e1131187370198 : check e1131187370198 [[],[.under]] .smaller = true := by decide
def e1131187370202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1131187370202 : Closed e1131187370202 ∧ code e1131187370202 = 5529233881306 := by decide
theorem cert_e1131187370202 : check e1131187370202 [[],[.under]] .smaller = true := by decide
def e1131187370218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1131187370218 : Closed e1131187370218 ∧ code e1131187370218 = 5529233881322 := by decide
theorem cert_e1131187370218 : check e1131187370218 [[],[.under]] .smaller = true := by decide
def e1131187370550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1131187370550 : Closed e1131187370550 ∧ code e1131187370550 = 5529233881654 := by decide
theorem cert_e1131187370550 : check e1131187370550 [[],[.under]] .smaller = true := by decide
def e1131187370554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1131187370554 : Closed e1131187370554 ∧ code e1131187370554 = 5529233881658 := by decide
theorem cert_e1131187370554 : check e1131187370554 [[],[.under]] .smaller = true := by decide
def e1131187370638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1131187370638 : Closed e1131187370638 ∧ code e1131187370638 = 5529233881742 := by decide
theorem cert_e1131187370638 : check e1131187370638 [[],[.under]] .smaller = true := by decide
def e1131187370694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1131187370694 : Closed e1131187370694 ∧ code e1131187370694 = 5529233881798 := by decide
theorem cert_e1131187370694 : check e1131187370694 [[],[.under]] .smaller = true := by decide
def e1131187370778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1131187370778 : Closed e1131187370778 ∧ code e1131187370778 = 5529233881882 := by decide
theorem cert_e1131187370778 : check e1131187370778 [[],[.under]] .smaller = true := by decide
def e1131187370822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1131187370822 : Closed e1131187370822 ∧ code e1131187370822 = 5529233881926 := by decide
theorem cert_e1131187370822 : check e1131187370822 [[],[.under]] .smaller = true := by decide
def e1131187375342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1131187375342 : Closed e1131187375342 ∧ code e1131187375342 = 5529233886446 := by decide
theorem cert_e1131187375342 : check e1131187375342 [[],[.under]] .smaller = true := by decide
def e1131187375350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1131187375350 : Closed e1131187375350 ∧ code e1131187375350 = 5529233886454 := by decide
theorem cert_e1131187375350 : check e1131187375350 [[],[.under]] .smaller = true := by decide
def e1131187375726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1131187375726 : Closed e1131187375726 ∧ code e1131187375726 = 5529233886830 := by decide
theorem cert_e1131187375726 : check e1131187375726 [[],[.under]] .smaller = true := by decide
def e1131187375738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1131187375738 : Closed e1131187375738 ∧ code e1131187375738 = 5529233886842 := by decide
theorem cert_e1131187375738 : check e1131187375738 [[],[.under]] .smaller = true := by decide
def e1131187375926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1131187375926 : Closed e1131187375926 ∧ code e1131187375926 = 5529233887030 := by decide
theorem cert_e1131187375926 : check e1131187375926 [[],[.under]] .smaller = true := by decide
def e1131187375930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1131187375930 : Closed e1131187375930 ∧ code e1131187375930 = 5529233887034 := by decide
theorem cert_e1131187375930 : check e1131187375930 [[],[.under]] .smaller = true := by decide
def e1131187378414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1131187378414 : Closed e1131187378414 ∧ code e1131187378414 = 5529233889518 := by decide
theorem cert_e1131187378414 : check e1131187378414 [[],[.under]] .smaller = true := by decide
def e1131187378422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1131187378422 : Closed e1131187378422 ∧ code e1131187378422 = 5529233889526 := by decide
theorem cert_e1131187378422 : check e1131187378422 [[],[.under]] .smaller = true := by decide
def e1131187378974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1131187378974 : Closed e1131187378974 ∧ code e1131187378974 = 5529233890078 := by decide
theorem cert_e1131187378974 : check e1131187378974 [[],[.under]] .smaller = true := by decide
def e1131187379086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1131187379086 : Closed e1131187379086 ∧ code e1131187379086 = 5529233890190 := by decide
theorem cert_e1131187379086 : check e1131187379086 [[],[.under]] .smaller = true := by decide
def e1131187379310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1131187379310 : Closed e1131187379310 ∧ code e1131187379310 = 5529233890414 := by decide
theorem cert_e1131187379310 : check e1131187379310 [[],[.under]] .smaller = true := by decide
def e1131187379322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1131187379322 : Closed e1131187379322 ∧ code e1131187379322 = 5529233890426 := by decide
theorem cert_e1131187379322 : check e1131187379322 [[],[.under]] .smaller = true := by decide
def e1131187379486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1131187379486 : Closed e1131187379486 ∧ code e1131187379486 = 5529233890590 := by decide
theorem cert_e1131187379486 : check e1131187379486 [[],[.under]] .smaller = true := by decide
def e1131187379654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1131187379654 : Closed e1131187379654 ∧ code e1131187379654 = 5529233890758 := by decide
theorem cert_e1131187379654 : check e1131187379654 [[],[.under]] .smaller = true := by decide
def e1131187379766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1131187379766 : Closed e1131187379766 ∧ code e1131187379766 = 5529233890870 := by decide
theorem cert_e1131187379766 : check e1131187379766 [[],[.under]] .smaller = true := by decide
def e1131187379770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1131187379770 : Closed e1131187379770 ∧ code e1131187379770 = 5529233890874 := by decide
theorem cert_e1131187379770 : check e1131187379770 [[],[.under]] .smaller = true := by decide
def e1131187379854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1131187379854 : Closed e1131187379854 ∧ code e1131187379854 = 5529233890958 := by decide
theorem cert_e1131187379854 : check e1131187379854 [[],[.under]] .smaller = true := by decide
def e1131187379910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1131187379910 : Closed e1131187379910 ∧ code e1131187379910 = 5529233891014 := by decide
theorem cert_e1131187379910 : check e1131187379910 [[],[.under]] .smaller = true := by decide
def e1131187382046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1131187382046 : Closed e1131187382046 ∧ code e1131187382046 = 5529233893150 := by decide
theorem cert_e1131187382046 : check e1131187382046 [[],[.under]] .smaller = true := by decide
def e1131187382158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1131187382158 : Closed e1131187382158 ∧ code e1131187382158 = 5529233893262 := by decide
theorem cert_e1131187382158 : check e1131187382158 [[],[.under]] .smaller = true := by decide
def e1131187385118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1131187385118 : Closed e1131187385118 ∧ code e1131187385118 = 5529233896222 := by decide
theorem cert_e1131187385118 : check e1131187385118 [[],[.under]] .smaller = true := by decide
def e1131187385286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1131187385286 : Closed e1131187385286 ∧ code e1131187385286 = 5529233896390 := by decide
theorem cert_e1131187385286 : check e1131187385286 [[],[.under]] .smaller = true := by decide
def e1131187386766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1131187386766 : Closed e1131187386766 ∧ code e1131187386766 = 5529233897870 := by decide
theorem cert_e1131187386766 : check e1131187386766 [[],[.under]] .smaller = true := by decide
def e1131187386822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1131187386822 : Closed e1131187386822 ∧ code e1131187386822 = 5529233897926 := by decide
theorem cert_e1131187386822 : check e1131187386822 [[],[.under]] .smaller = true := by decide
def e1131187390062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1131187390062 : Closed e1131187390062 ∧ code e1131187390062 = 5529233901166 := by decide
theorem cert_e1131187390062 : check e1131187390062 [[],[.under]] .smaller = true := by decide
def e1131187390074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1131187390074 : Closed e1131187390074 ∧ code e1131187390074 = 5529233901178 := by decide
theorem cert_e1131187390074 : check e1131187390074 [[],[.under]] .smaller = true := by decide
def e1131187390362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1131187390362 : Closed e1131187390362 ∧ code e1131187390362 = 5529233901466 := by decide
theorem cert_e1131187390362 : check e1131187390362 [[],[.under]] .smaller = true := by decide
def e1131187391598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1131187391598 : Closed e1131187391598 ∧ code e1131187391598 = 5529233902702 := by decide
theorem cert_e1131187391598 : check e1131187391598 [[],[.under]] .smaller = true := by decide
def e1131187391610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1131187391610 : Closed e1131187391610 ∧ code e1131187391610 = 5529233902714 := by decide
theorem cert_e1131187391610 : check e1131187391610 [[],[.under]] .smaller = true := by decide
def e1131187391774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1131187391774 : Closed e1131187391774 ∧ code e1131187391774 = 5529233902878 := by decide
theorem cert_e1131187391774 : check e1131187391774 [[],[.under]] .smaller = true := by decide
def e1131187391942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1131187391942 : Closed e1131187391942 ∧ code e1131187391942 = 5529233903046 := by decide
theorem cert_e1131187391942 : check e1131187391942 [[],[.under]] .smaller = true := by decide
def e1131187392282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1131187392282 : Closed e1131187392282 ∧ code e1131187392282 = 5529233903386 := by decide
theorem cert_e1131187392282 : check e1131187392282 [[],[.under]] .smaller = true := by decide
def e1131187392326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1131187392326 : Closed e1131187392326 ∧ code e1131187392326 = 5529233903430 := by decide
theorem cert_e1131187392326 : check e1131187392326 [[],[.under]] .smaller = true := by decide
def e1131187393310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1131187393310 : Closed e1131187393310 ∧ code e1131187393310 = 5529233904414 := by decide
theorem cert_e1131187393310 : check e1131187393310 [[],[.under]] .smaller = true := by decide
def e1131187393478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1131187393478 : Closed e1131187393478 ∧ code e1131187393478 = 5529233904582 := by decide
theorem cert_e1131187393478 : check e1131187393478 [[],[.under]] .smaller = true := by decide
def e1131187395782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1131187395782 : Closed e1131187395782 ∧ code e1131187395782 = 5529233906886 := by decide
theorem cert_e1131187395782 : check e1131187395782 [[],[.under]] .smaller = true := by decide
def e1131187397430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1131187397430 : Closed e1131187397430 ∧ code e1131187397430 = 5529233908534 := by decide
theorem cert_e1131187397430 : check e1131187397430 [[],[.under]] .smaller = true := by decide
def e1131187397434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1131187397434 : Closed e1131187397434 ∧ code e1131187397434 = 5529233908538 := by decide
theorem cert_e1131187397434 : check e1131187397434 [[],[.under]] .smaller = true := by decide
def e1131187397530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1131187397530 : Closed e1131187397530 ∧ code e1131187397530 = 5529233908634 := by decide
theorem cert_e1131187397530 : check e1131187397530 [[],[.under]] .smaller = true := by decide
def e1131187398198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1131187398198 : Closed e1131187398198 ∧ code e1131187398198 = 5529233909302 := by decide
theorem cert_e1131187398198 : check e1131187398198 [[],[.under]] .smaller = true := by decide
def e1131187398202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1131187398202 : Closed e1131187398202 ∧ code e1131187398202 = 5529233909306 := by decide
theorem cert_e1131187398202 : check e1131187398202 [[],[.under]] .smaller = true := by decide
def e1131187398286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1131187398286 : Closed e1131187398286 ∧ code e1131187398286 = 5529233909390 := by decide
theorem cert_e1131187398286 : check e1131187398286 [[],[.under]] .smaller = true := by decide
def e1131187398342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1131187398342 : Closed e1131187398342 ∧ code e1131187398342 = 5529233909446 := by decide
theorem cert_e1131187398342 : check e1131187398342 [[],[.under]] .smaller = true := by decide
def e1131187398426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1131187398426 : Closed e1131187398426 ∧ code e1131187398426 = 5529233909530 := by decide
theorem cert_e1131187398426 : check e1131187398426 [[],[.under]] .smaller = true := by decide
def e1131187398470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1131187398470 : Closed e1131187398470 ∧ code e1131187398470 = 5529233909574 := by decide
theorem cert_e1131187398470 : check e1131187398470 [[],[.under]] .smaller = true := by decide
def e1131187399054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1131187399054 : Closed e1131187399054 ∧ code e1131187399054 = 5529233910158 := by decide
theorem cert_e1131187399054 : check e1131187399054 [[],[.under]] .smaller = true := by decide
def e1131187399110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1131187399110 : Closed e1131187399110 ∧ code e1131187399110 = 5529233910214 := by decide
theorem cert_e1131187399110 : check e1131187399110 [[],[.under]] .smaller = true := by decide
def e1131187399878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1131187399878 : Closed e1131187399878 ∧ code e1131187399878 = 5529233910982 := by decide
theorem cert_e1131187399878 : check e1131187399878 [[],[.under]] .smaller = true := by decide
def e1131187410654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1131187410654 : Closed e1131187410654 ∧ code e1131187410654 = 5529233921758 := by decide
theorem cert_e1131187410654 : check e1131187410654 [[],[.under]] .smaller = true := by decide
def e1131187410678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1131187410678 : Closed e1131187410678 ∧ code e1131187410678 = 5529233921782 := by decide
theorem cert_e1131187410678 : check e1131187410678 [[],[.under]] .smaller = true := by decide
def e1131187410782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1131187410782 : Closed e1131187410782 ∧ code e1131187410782 = 5529233921886 := by decide
theorem cert_e1131187410782 : check e1131187410782 [[],[.under]] .smaller = true := by decide
def e1131187410810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1131187410810 : Closed e1131187410810 ∧ code e1131187410810 = 5529233921914 := by decide
theorem cert_e1131187410810 : check e1131187410810 [[],[.under]] .smaller = true := by decide
def e1131187410902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1131187410902 : Closed e1131187410902 ∧ code e1131187410902 = 5529233922006 := by decide
theorem cert_e1131187410902 : check e1131187410902 [[],[.under]] .smaller = true := by decide
def e1131187410906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1131187410906 : Closed e1131187410906 ∧ code e1131187410906 = 5529233922010 := by decide
theorem cert_e1131187410906 : check e1131187410906 [[],[.under]] .smaller = true := by decide
def e1131187411422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1131187411422 : Closed e1131187411422 ∧ code e1131187411422 = 5529233922526 := by decide
theorem cert_e1131187411422 : check e1131187411422 [[],[.under]] .smaller = true := by decide
def e1131187411446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1131187411446 : Closed e1131187411446 ∧ code e1131187411446 = 5529233922550 := by decide
theorem cert_e1131187411446 : check e1131187411446 [[],[.under]] .smaller = true := by decide
def e1131187412190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1131187412190 : Closed e1131187412190 ∧ code e1131187412190 = 5529233923294 := by decide
theorem cert_e1131187412190 : check e1131187412190 [[],[.under]] .smaller = true := by decide
def e1131187412218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1131187412218 : Closed e1131187412218 ∧ code e1131187412218 = 5529233923322 := by decide
theorem cert_e1131187412218 : check e1131187412218 [[],[.under]] .smaller = true := by decide
def e1131187412790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187412790 : Closed e1131187412790 ∧ code e1131187412790 = 5529233923894 := by decide
theorem cert_e1131187412790 : check e1131187412790 [[],[.under]] .smaller = true := by decide
def e1131187412794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187412794 : Closed e1131187412794 ∧ code e1131187412794 = 5529233923898 := by decide
theorem cert_e1131187412794 : check e1131187412794 [[],[.under]] .smaller = true := by decide
def e1131187427566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1131187427566 : Closed e1131187427566 ∧ code e1131187427566 = 5529233938670 := by decide
theorem cert_e1131187427566 : check e1131187427566 [[],[.under]] .smaller = true := by decide
def e1131187427574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1131187427574 : Closed e1131187427574 ∧ code e1131187427574 = 5529233938678 := by decide
theorem cert_e1131187427574 : check e1131187427574 [[],[.under]] .smaller = true := by decide
def e1131187428126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1131187428126 : Closed e1131187428126 ∧ code e1131187428126 = 5529233939230 := by decide
theorem cert_e1131187428126 : check e1131187428126 [[],[.under]] .smaller = true := by decide
def e1131187428238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1131187428238 : Closed e1131187428238 ∧ code e1131187428238 = 5529233939342 := by decide
theorem cert_e1131187428238 : check e1131187428238 [[],[.under]] .smaller = true := by decide
def e1131187428462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1131187428462 : Closed e1131187428462 ∧ code e1131187428462 = 5529233939566 := by decide
theorem cert_e1131187428462 : check e1131187428462 [[],[.under]] .smaller = true := by decide
def e1131187428474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1131187428474 : Closed e1131187428474 ∧ code e1131187428474 = 5529233939578 := by decide
theorem cert_e1131187428474 : check e1131187428474 [[],[.under]] .smaller = true := by decide
def e1131187428638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1131187428638 : Closed e1131187428638 ∧ code e1131187428638 = 5529233939742 := by decide
theorem cert_e1131187428638 : check e1131187428638 [[],[.under]] .smaller = true := by decide
def e1131187428806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1131187428806 : Closed e1131187428806 ∧ code e1131187428806 = 5529233939910 := by decide
theorem cert_e1131187428806 : check e1131187428806 [[],[.under]] .smaller = true := by decide
def e1131187428918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1131187428918 : Closed e1131187428918 ∧ code e1131187428918 = 5529233940022 := by decide
theorem cert_e1131187428918 : check e1131187428918 [[],[.under]] .smaller = true := by decide
def e1131187428922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1131187428922 : Closed e1131187428922 ∧ code e1131187428922 = 5529233940026 := by decide
theorem cert_e1131187428922 : check e1131187428922 [[],[.under]] .smaller = true := by decide
def e1131187429006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1131187429006 : Closed e1131187429006 ∧ code e1131187429006 = 5529233940110 := by decide
theorem cert_e1131187429006 : check e1131187429006 [[],[.under]] .smaller = true := by decide
def e1131187429062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1131187429062 : Closed e1131187429062 ∧ code e1131187429062 = 5529233940166 := by decide
theorem cert_e1131187429062 : check e1131187429062 [[],[.under]] .smaller = true := by decide
def e1131187431198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1131187431198 : Closed e1131187431198 ∧ code e1131187431198 = 5529233942302 := by decide
theorem cert_e1131187431198 : check e1131187431198 [[],[.under]] .smaller = true := by decide
def e1131187431310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1131187431310 : Closed e1131187431310 ∧ code e1131187431310 = 5529233942414 := by decide
theorem cert_e1131187431310 : check e1131187431310 [[],[.under]] .smaller = true := by decide
def e1131187434270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1131187434270 : Closed e1131187434270 ∧ code e1131187434270 = 5529233945374 := by decide
theorem cert_e1131187434270 : check e1131187434270 [[],[.under]] .smaller = true := by decide
def e1131187434438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1131187434438 : Closed e1131187434438 ∧ code e1131187434438 = 5529233945542 := by decide
theorem cert_e1131187434438 : check e1131187434438 [[],[.under]] .smaller = true := by decide
def e1131187435918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1131187435918 : Closed e1131187435918 ∧ code e1131187435918 = 5529233947022 := by decide
theorem cert_e1131187435918 : check e1131187435918 [[],[.under]] .smaller = true := by decide
def e1131187435974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1131187435974 : Closed e1131187435974 ∧ code e1131187435974 = 5529233947078 := by decide
theorem cert_e1131187435974 : check e1131187435974 [[],[.under]] .smaller = true := by decide
def e1131187473262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1131187473262 : Closed e1131187473262 ∧ code e1131187473262 = 5529233984366 := by decide
theorem cert_e1131187473262 : check e1131187473262 [[],[.under]] .smaller = true := by decide
def e1131187473270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1131187473270 : Closed e1131187473270 ∧ code e1131187473270 = 5529233984374 := by decide
theorem cert_e1131187473270 : check e1131187473270 [[],[.under]] .smaller = true := by decide
end Blc.Floor42
