import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204394870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1211204394870 : Closed e1211204394870 ∧ code e1211204394870 = 5609250905974 := by decide
theorem cert_e1211204394870 : check e1211204394870 [[],[]] .chain = true := by decide
def e1211204396830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211204396830 : Closed e1211204396830 ∧ code e1211204396830 = 5609250907934 := by decide
theorem cert_e1211204396830 : check e1211204396830 [[],[]] .smaller = true := by decide
def e1211204396942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211204396942 : Closed e1211204396942 ∧ code e1211204396942 = 5609250908046 := by decide
theorem cert_e1211204396942 : check e1211204396942 [[],[]] .smaller = true := by decide
def e1211204399902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211204399902 : Closed e1211204399902 ∧ code e1211204399902 = 5609250911006 := by decide
theorem cert_e1211204399902 : check e1211204399902 [[],[]] .smaller = true := by decide
def e1211204400070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211204400070 : Closed e1211204400070 ∧ code e1211204400070 = 5609250911174 := by decide
theorem cert_e1211204400070 : check e1211204400070 [[],[]] .smaller = true := by decide
def e1211204400094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211204400094 : Closed e1211204400094 ∧ code e1211204400094 = 5609250911198 := by decide
theorem cert_e1211204400094 : check e1211204400094 [[],[]] .chain = true := by decide
def e1211204400110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211204400110 : Closed e1211204400110 ∧ code e1211204400110 = 5609250911214 := by decide
theorem cert_e1211204400110 : check e1211204400110 [[],[]] .chain = true := by decide
def e1211204401550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211204401550 : Closed e1211204401550 ∧ code e1211204401550 = 5609250912654 := by decide
theorem cert_e1211204401550 : check e1211204401550 [[],[]] .smaller = true := by decide
def e1211204401606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211204401606 : Closed e1211204401606 ∧ code e1211204401606 = 5609250912710 := by decide
theorem cert_e1211204401606 : check e1211204401606 [[],[]] .smaller = true := by decide
def e1211204401630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211204401630 : Closed e1211204401630 ∧ code e1211204401630 = 5609250912734 := by decide
theorem cert_e1211204401630 : check e1211204401630 [[],[]] .chain = true := by decide
def e1211204401654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211204401654 : Closed e1211204401654 ∧ code e1211204401654 = 5609250912758 := by decide
theorem cert_e1211204401654 : check e1211204401654 [[],[]] .chain = true := by decide
def e1211204402414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204402414 : Closed e1211204402414 ∧ code e1211204402414 = 5609250913518 := by decide
theorem cert_e1211204402414 : check e1211204402414 [[],[]] .chain = true := by decide
def e1211204402422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204402422 : Closed e1211204402422 ∧ code e1211204402422 = 5609250913526 := by decide
theorem cert_e1211204402422 : check e1211204402422 [[],[]] .chain = true := by decide
def e1211204459374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211204459374 : Closed e1211204459374 ∧ code e1211204459374 = 5609250970478 := by decide
theorem cert_e1211204459374 : check e1211204459374 [[],[]] .chain = true := by decide
def e1211204459382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211204459382 : Closed e1211204459382 ∧ code e1211204459382 = 5609250970486 := by decide
theorem cert_e1211204459382 : check e1211204459382 [[],[]] .chain = true := by decide
def e1211204459446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211204459446 : Closed e1211204459446 ∧ code e1211204459446 = 5609250970550 := by decide
theorem cert_e1211204459446 : check e1211204459446 [[],[]] .chain = true := by decide
def e1211204459886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211204459886 : Closed e1211204459886 ∧ code e1211204459886 = 5609250970990 := by decide
theorem cert_e1211204459886 : check e1211204459886 [[],[]] .chain = true := by decide
def e1211204459894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211204459894 : Closed e1211204459894 ∧ code e1211204459894 = 5609250970998 := by decide
theorem cert_e1211204459894 : check e1211204459894 [[],[]] .chain = true := by decide
def e1211204459950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211204459950 : Closed e1211204459950 ∧ code e1211204459950 = 5609250971054 := by decide
theorem cert_e1211204459950 : check e1211204459950 [[],[]] .chain = true := by decide
def e1211204459962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211204459962 : Closed e1211204459962 ∧ code e1211204459962 = 5609250971066 := by decide
theorem cert_e1211204459962 : check e1211204459962 [[],[]] .chain = true := by decide
def e1211204459990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211204459990 : Closed e1211204459990 ∧ code e1211204459990 = 5609250971094 := by decide
theorem cert_e1211204459990 : check e1211204459990 [[],[]] .chain = true := by decide
def e1211204459994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211204459994 : Closed e1211204459994 ∧ code e1211204459994 = 5609250971098 := by decide
theorem cert_e1211204459994 : check e1211204459994 [[],[]] .chain = true := by decide
def e1211204460214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211204460214 : Closed e1211204460214 ∧ code e1211204460214 = 5609250971318 := by decide
theorem cert_e1211204460214 : check e1211204460214 [[],[]] .chain = true := by decide
def e1211204460246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211204460246 : Closed e1211204460246 ∧ code e1211204460246 = 5609250971350 := by decide
theorem cert_e1211204460246 : check e1211204460246 [[],[]] .chain = true := by decide
def e1211204460250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211204460250 : Closed e1211204460250 ∧ code e1211204460250 = 5609250971354 := by decide
theorem cert_e1211204460250 : check e1211204460250 [[],[]] .chain = true := by decide
def e1211204462446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211204462446 : Closed e1211204462446 ∧ code e1211204462446 = 5609250973550 := by decide
theorem cert_e1211204462446 : check e1211204462446 [[],[]] .chain = true := by decide
def e1211204462454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211204462454 : Closed e1211204462454 ∧ code e1211204462454 = 5609250973558 := by decide
theorem cert_e1211204462454 : check e1211204462454 [[],[]] .chain = true := by decide
def e1211204462518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211204462518 : Closed e1211204462518 ∧ code e1211204462518 = 5609250973622 := by decide
theorem cert_e1211204462518 : check e1211204462518 [[],[]] .chain = true := by decide
def e1211204463854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204463854 : Closed e1211204463854 ∧ code e1211204463854 = 5609250974958 := by decide
theorem cert_e1211204463854 : check e1211204463854 [[],[]] .chain = true := by decide
def e1211204463862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204463862 : Closed e1211204463862 ∧ code e1211204463862 = 5609250974966 := by decide
theorem cert_e1211204463862 : check e1211204463862 [[],[]] .chain = true := by decide
def e1211204464246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204464246 : Closed e1211204464246 ∧ code e1211204464246 = 5609250975350 := by decide
theorem cert_e1211204464246 : check e1211204464246 [[],[]] .chain = true := by decide
def e1211204464750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211204464750 : Closed e1211204464750 ∧ code e1211204464750 = 5609250975854 := by decide
theorem cert_e1211204464750 : check e1211204464750 [[],[]] .chain = true := by decide
def e1211204464926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211204464926 : Closed e1211204464926 ∧ code e1211204464926 = 5609250976030 := by decide
theorem cert_e1211204464926 : check e1211204464926 [[],[]] .chain = true := by decide
def e1211204465122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211204465122 : Closed e1211204465122 ∧ code e1211204465122 = 5609250976226 := by decide
theorem cert_e1211204465122 : check e1211204465122 [[],[]] .chain = true := by decide
def e1211204465134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211204465134 : Closed e1211204465134 ∧ code e1211204465134 = 5609250976238 := by decide
theorem cert_e1211204465134 : check e1211204465134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204465518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211204465518 : Closed e1211204465518 ∧ code e1211204465518 = 5609250976622 := by decide
theorem cert_e1211204465518 : check e1211204465518 [[],[]] .chain = true := by decide
def e1211204465526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211204465526 : Closed e1211204465526 ∧ code e1211204465526 = 5609250976630 := by decide
theorem cert_e1211204465526 : check e1211204465526 [[],[]] .chain = true := by decide
def e1211204465582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211204465582 : Closed e1211204465582 ∧ code e1211204465582 = 5609250976686 := by decide
theorem cert_e1211204465582 : check e1211204465582 [[],[]] .chain = true := by decide
def e1211204465594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211204465594 : Closed e1211204465594 ∧ code e1211204465594 = 5609250976698 := by decide
theorem cert_e1211204465594 : check e1211204465594 [[],[]] .chain = true := by decide
def e1211204465622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211204465622 : Closed e1211204465622 ∧ code e1211204465622 = 5609250976726 := by decide
theorem cert_e1211204465622 : check e1211204465622 [[],[]] .chain = true := by decide
def e1211204465626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211204465626 : Closed e1211204465626 ∧ code e1211204465626 = 5609250976730 := by decide
theorem cert_e1211204465626 : check e1211204465626 [[],[]] .chain = true := by decide
def e1211204465902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204465902 : Closed e1211204465902 ∧ code e1211204465902 = 5609250977006 := by decide
theorem cert_e1211204465902 : check e1211204465902 [[],[]] .chain = true := by decide
def e1211204465910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204465910 : Closed e1211204465910 ∧ code e1211204465910 = 5609250977014 := by decide
theorem cert_e1211204465910 : check e1211204465910 [[],[]] .chain = true := by decide
def e1211204466286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204466286 : Closed e1211204466286 ∧ code e1211204466286 = 5609250977390 := by decide
theorem cert_e1211204466286 : check e1211204466286 [[],[]] .chain = true := by decide
def e1211204466298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204466298 : Closed e1211204466298 ∧ code e1211204466298 = 5609250977402 := by decide
theorem cert_e1211204466298 : check e1211204466298 [[],[]] .chain = true := by decide
def e1211204466438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204466438 : Closed e1211204466438 ∧ code e1211204466438 = 5609250977542 := by decide
theorem cert_e1211204466438 : check e1211204466438 [[],[]] .chain = true := by decide
def e1211204466462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211204466462 : Closed e1211204466462 ∧ code e1211204466462 = 5609250977566 := by decide
theorem cert_e1211204466462 : check e1211204466462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204466486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204466486 : Closed e1211204466486 ∧ code e1211204466486 = 5609250977590 := by decide
theorem cert_e1211204466486 : check e1211204466486 [[],[]] .chain = true := by decide
def e1211204466490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204466490 : Closed e1211204466490 ∧ code e1211204466490 = 5609250977594 := by decide
theorem cert_e1211204466490 : check e1211204466490 [[],[]] .chain = true := by decide
def e1211204466742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211204466742 : Closed e1211204466742 ∧ code e1211204466742 = 5609250977846 := by decide
theorem cert_e1211204466742 : check e1211204466742 [[],[]] .chain = true := by decide
def e1211204466830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211204466830 : Closed e1211204466830 ∧ code e1211204466830 = 5609250977934 := by decide
theorem cert_e1211204466830 : check e1211204466830 [[],[]] .chain = true := by decide
def e1211204466914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211204466914 : Closed e1211204466914 ∧ code e1211204466914 = 5609250978018 := by decide
theorem cert_e1211204466914 : check e1211204466914 [[],[]] .chain = true := by decide
def e1211204466926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211204466926 : Closed e1211204466926 ∧ code e1211204466926 = 5609250978030 := by decide
theorem cert_e1211204466926 : check e1211204466926 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204466934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211204466934 : Closed e1211204466934 ∧ code e1211204466934 = 5609250978038 := by decide
theorem cert_e1211204466934 : check e1211204466934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204467126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211204467126 : Closed e1211204467126 ∧ code e1211204467126 = 5609250978230 := by decide
theorem cert_e1211204467126 : check e1211204467126 [[],[]] .chain = true := by decide
def e1211204467158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211204467158 : Closed e1211204467158 ∧ code e1211204467158 = 5609250978262 := by decide
theorem cert_e1211204467158 : check e1211204467158 [[],[]] .chain = true := by decide
def e1211204467162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211204467162 : Closed e1211204467162 ∧ code e1211204467162 = 5609250978266 := by decide
theorem cert_e1211204467162 : check e1211204467162 [[],[]] .chain = true := by decide
def e1211204467318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204467318 : Closed e1211204467318 ∧ code e1211204467318 = 5609250978422 := by decide
theorem cert_e1211204467318 : check e1211204467318 [[],[]] .chain = true := by decide
def e1211204467462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204467462 : Closed e1211204467462 ∧ code e1211204467462 = 5609250978566 := by decide
theorem cert_e1211204467462 : check e1211204467462 [[],[]] .chain = true := by decide
def e1211204467486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211204467486 : Closed e1211204467486 ∧ code e1211204467486 = 5609250978590 := by decide
theorem cert_e1211204467486 : check e1211204467486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204467510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204467510 : Closed e1211204467510 ∧ code e1211204467510 = 5609250978614 := by decide
theorem cert_e1211204467510 : check e1211204467510 [[],[]] .chain = true := by decide
def e1211204467514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204467514 : Closed e1211204467514 ∧ code e1211204467514 = 5609250978618 := by decide
theorem cert_e1211204467514 : check e1211204467514 [[],[]] .chain = true := by decide
def e1211204467598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211204467598 : Closed e1211204467598 ∧ code e1211204467598 = 5609250978702 := by decide
theorem cert_e1211204467598 : check e1211204467598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204474734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211204474734 : Closed e1211204474734 ∧ code e1211204474734 = 5609250985838 := by decide
theorem cert_e1211204474734 : check e1211204474734 [[],[]] .chain = true := by decide
def e1211204474742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211204474742 : Closed e1211204474742 ∧ code e1211204474742 = 5609250985846 := by decide
theorem cert_e1211204474742 : check e1211204474742 [[],[]] .chain = true := by decide
def e1211204474806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211204474806 : Closed e1211204474806 ∧ code e1211204474806 = 5609250985910 := by decide
theorem cert_e1211204474806 : check e1211204474806 [[],[]] .chain = true := by decide
def e1211204476142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204476142 : Closed e1211204476142 ∧ code e1211204476142 = 5609250987246 := by decide
theorem cert_e1211204476142 : check e1211204476142 [[],[]] .chain = true := by decide
def e1211204476150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204476150 : Closed e1211204476150 ∧ code e1211204476150 = 5609250987254 := by decide
theorem cert_e1211204476150 : check e1211204476150 [[],[]] .chain = true := by decide
def e1211204476534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211204476534 : Closed e1211204476534 ∧ code e1211204476534 = 5609250987638 := by decide
theorem cert_e1211204476534 : check e1211204476534 [[],[]] .chain = true := by decide
def e1211204485246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211204485246 : Closed e1211204485246 ∧ code e1211204485246 = 5609250996350 := by decide
theorem cert_e1211204485246 : check e1211204485246 [[],[]] .chain = true := by decide
def e1211204486110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211204486110 : Closed e1211204486110 ∧ code e1211204486110 = 5609250997214 := by decide
theorem cert_e1211204486110 : check e1211204486110 [[],[]] .chain = true := by decide
def e1211204486114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211204486114 : Closed e1211204486114 ∧ code e1211204486114 = 5609250997218 := by decide
theorem cert_e1211204486114 : check e1211204486114 [[],[]] .chain = true := by decide
def e1211204486126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211204486126 : Closed e1211204486126 ∧ code e1211204486126 = 5609250997230 := by decide
theorem cert_e1211204486126 : check e1211204486126 [[],[]] .chain = true := by decide
def e1211204488046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211204488046 : Closed e1211204488046 ∧ code e1211204488046 = 5609250999150 := by decide
theorem cert_e1211204488046 : check e1211204488046 [[],[]] .chain = true := by decide
def e1211204488054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211204488054 : Closed e1211204488054 ∧ code e1211204488054 = 5609250999158 := by decide
theorem cert_e1211204488054 : check e1211204488054 [[],[]] .chain = true := by decide
def e1211204488110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211204488110 : Closed e1211204488110 ∧ code e1211204488110 = 5609250999214 := by decide
theorem cert_e1211204488110 : check e1211204488110 [[],[]] .chain = true := by decide
def e1211204488122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211204488122 : Closed e1211204488122 ∧ code e1211204488122 = 5609250999226 := by decide
theorem cert_e1211204488122 : check e1211204488122 [[],[]] .chain = true := by decide
def e1211204488150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211204488150 : Closed e1211204488150 ∧ code e1211204488150 = 5609250999254 := by decide
theorem cert_e1211204488150 : check e1211204488150 [[],[]] .chain = true := by decide
def e1211204488154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211204488154 : Closed e1211204488154 ∧ code e1211204488154 = 5609250999258 := by decide
theorem cert_e1211204488154 : check e1211204488154 [[],[]] .chain = true := by decide
def e1211204488430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204488430 : Closed e1211204488430 ∧ code e1211204488430 = 5609250999534 := by decide
theorem cert_e1211204488430 : check e1211204488430 [[],[]] .chain = true := by decide
def e1211204488438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204488438 : Closed e1211204488438 ∧ code e1211204488438 = 5609250999542 := by decide
theorem cert_e1211204488438 : check e1211204488438 [[],[]] .chain = true := by decide
def e1211204488814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204488814 : Closed e1211204488814 ∧ code e1211204488814 = 5609250999918 := by decide
theorem cert_e1211204488814 : check e1211204488814 [[],[]] .chain = true := by decide
def e1211204488826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204488826 : Closed e1211204488826 ∧ code e1211204488826 = 5609250999930 := by decide
theorem cert_e1211204488826 : check e1211204488826 [[],[]] .chain = true := by decide
def e1211204488966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204488966 : Closed e1211204488966 ∧ code e1211204488966 = 5609251000070 := by decide
theorem cert_e1211204488966 : check e1211204488966 [[],[]] .chain = true := by decide
def e1211204488990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211204488990 : Closed e1211204488990 ∧ code e1211204488990 = 5609251000094 := by decide
theorem cert_e1211204488990 : check e1211204488990 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204489014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204489014 : Closed e1211204489014 ∧ code e1211204489014 = 5609251000118 := by decide
theorem cert_e1211204489014 : check e1211204489014 [[],[]] .chain = true := by decide
def e1211204489018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204489018 : Closed e1211204489018 ∧ code e1211204489018 = 5609251000122 := by decide
theorem cert_e1211204489018 : check e1211204489018 [[],[]] .chain = true := by decide
def e1211204493374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211204493374 : Closed e1211204493374 ∧ code e1211204493374 = 5609251004478 := by decide
theorem cert_e1211204493374 : check e1211204493374 [[],[]] .chain = true := by decide
def e1211204493794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211204493794 : Closed e1211204493794 ∧ code e1211204493794 = 5609251004898 := by decide
theorem cert_e1211204493794 : check e1211204493794 [[],[]] .chain = true := by decide
def e1211204493806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211204493806 : Closed e1211204493806 ∧ code e1211204493806 = 5609251004910 := by decide
theorem cert_e1211204493806 : check e1211204493806 [[],[]] .chain = true := by decide
def e1211204494774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211204494774 : Closed e1211204494774 ∧ code e1211204494774 = 5609251005878 := by decide
theorem cert_e1211204494774 : check e1211204494774 [[],[]] .chain = true := by decide
def e1211204494806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211204494806 : Closed e1211204494806 ∧ code e1211204494806 = 5609251005910 := by decide
theorem cert_e1211204494806 : check e1211204494806 [[],[]] .chain = true := by decide
def e1211204494810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211204494810 : Closed e1211204494810 ∧ code e1211204494810 = 5609251005914 := by decide
theorem cert_e1211204494810 : check e1211204494810 [[],[]] .chain = true := by decide
def e1211204494966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211204494966 : Closed e1211204494966 ∧ code e1211204494966 = 5609251006070 := by decide
theorem cert_e1211204494966 : check e1211204494966 [[],[]] .chain = true := by decide
def e1211204495110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211204495110 : Closed e1211204495110 ∧ code e1211204495110 = 5609251006214 := by decide
theorem cert_e1211204495110 : check e1211204495110 [[],[]] .chain = true := by decide
def e1211204495134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211204495134 : Closed e1211204495134 ∧ code e1211204495134 = 5609251006238 := by decide
theorem cert_e1211204495134 : check e1211204495134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204495158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204495158 : Closed e1211204495158 ∧ code e1211204495158 = 5609251006262 := by decide
theorem cert_e1211204495158 : check e1211204495158 [[],[]] .chain = true := by decide
def e1211204495162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204495162 : Closed e1211204495162 ∧ code e1211204495162 = 5609251006266 := by decide
theorem cert_e1211204495162 : check e1211204495162 [[],[]] .chain = true := by decide
def e1211204495246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211204495246 : Closed e1211204495246 ∧ code e1211204495246 = 5609251006350 := by decide
theorem cert_e1211204495246 : check e1211204495246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204635502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211204635502 : Closed e1211204635502 ∧ code e1211204635502 = 5609251146606 := by decide
theorem cert_e1211204635502 : check e1211204635502 [[],[]] .smaller = true := by decide
def e1211204635510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211204635510 : Closed e1211204635510 ∧ code e1211204635510 = 5609251146614 := by decide
theorem cert_e1211204635510 : check e1211204635510 [[],[]] .smaller = true := by decide
def e1211204635566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211204635566 : Closed e1211204635566 ∧ code e1211204635566 = 5609251146670 := by decide
theorem cert_e1211204635566 : check e1211204635566 [[],[]] .smaller = true := by decide
def e1211204635578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211204635578 : Closed e1211204635578 ∧ code e1211204635578 = 5609251146682 := by decide
theorem cert_e1211204635578 : check e1211204635578 [[],[]] .smaller = true := by decide
def e1211204635606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211204635606 : Closed e1211204635606 ∧ code e1211204635606 = 5609251146710 := by decide
theorem cert_e1211204635606 : check e1211204635606 [[],[]] .smaller = true := by decide
def e1211204635610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211204635610 : Closed e1211204635610 ∧ code e1211204635610 = 5609251146714 := by decide
theorem cert_e1211204635610 : check e1211204635610 [[],[]] .smaller = true := by decide
def e1211204635886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211204635886 : Closed e1211204635886 ∧ code e1211204635886 = 5609251146990 := by decide
theorem cert_e1211204635886 : check e1211204635886 [[],[]] .smaller = true := by decide
def e1211204635894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211204635894 : Closed e1211204635894 ∧ code e1211204635894 = 5609251146998 := by decide
theorem cert_e1211204635894 : check e1211204635894 [[],[]] .smaller = true := by decide
def e1211204636270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211204636270 : Closed e1211204636270 ∧ code e1211204636270 = 5609251147374 := by decide
theorem cert_e1211204636270 : check e1211204636270 [[],[]] .smaller = true := by decide
def e1211204636282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211204636282 : Closed e1211204636282 ∧ code e1211204636282 = 5609251147386 := by decide
theorem cert_e1211204636282 : check e1211204636282 [[],[]] .smaller = true := by decide
def e1211204636470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211204636470 : Closed e1211204636470 ∧ code e1211204636470 = 5609251147574 := by decide
theorem cert_e1211204636470 : check e1211204636470 [[],[]] .smaller = true := by decide
def e1211204636474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211204636474 : Closed e1211204636474 ∧ code e1211204636474 = 5609251147578 := by decide
theorem cert_e1211204636474 : check e1211204636474 [[],[]] .smaller = true := by decide
def e1211204636606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e1211204636606 : Closed e1211204636606 ∧ code e1211204636606 = 5609251147710 := by decide
theorem cert_e1211204636606 : check e1211204636606 [[],[]] .chain = true := by decide
def e1211204636638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e1211204636638 : Closed e1211204636638 ∧ code e1211204636638 = 5609251147742 := by decide
theorem cert_e1211204636638 : check e1211204636638 [[],[]] .chain = true := by decide
def e1211204644318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211204644318 : Closed e1211204644318 ∧ code e1211204644318 = 5609251155422 := by decide
theorem cert_e1211204644318 : check e1211204644318 [[],[]] .chain = true := by decide
def e1211204644334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211204644334 : Closed e1211204644334 ∧ code e1211204644334 = 5609251155438 := by decide
theorem cert_e1211204644334 : check e1211204644334 [[],[]] .chain = true := by decide
def e1211204644574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1211204644574 : Closed e1211204644574 ∧ code e1211204644574 = 5609251155678 := by decide
theorem cert_e1211204644574 : check e1211204644574 [[],[]] .chain = true := by decide
def e1211204644598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1211204644598 : Closed e1211204644598 ∧ code e1211204644598 = 5609251155702 := by decide
theorem cert_e1211204644598 : check e1211204644598 [[],[]] .chain = true := by decide
def e1211204644702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211204644702 : Closed e1211204644702 ∧ code e1211204644702 = 5609251155806 := by decide
theorem cert_e1211204644702 : check e1211204644702 [[],[]] .chain = true := by decide
def e1211204644730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211204644730 : Closed e1211204644730 ∧ code e1211204644730 = 5609251155834 := by decide
theorem cert_e1211204644730 : check e1211204644730 [[],[]] .chain = true := by decide
def e1211204644782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211204644782 : Closed e1211204644782 ∧ code e1211204644782 = 5609251155886 := by decide
theorem cert_e1211204644782 : check e1211204644782 [[],[]] .chain = true := by decide
def e1211204644790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1211204644790 : Closed e1211204644790 ∧ code e1211204644790 = 5609251155894 := by decide
theorem cert_e1211204644790 : check e1211204644790 [[],[]] .chain = true := by decide
def e1211204644794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211204644794 : Closed e1211204644794 ∧ code e1211204644794 = 5609251155898 := by decide
theorem cert_e1211204644794 : check e1211204644794 [[],[]] .chain = true := by decide
def e1211204645854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211204645854 : Closed e1211204645854 ∧ code e1211204645854 = 5609251156958 := by decide
theorem cert_e1211204645854 : check e1211204645854 [[],[]] .chain = true := by decide
def e1211204645870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211204645870 : Closed e1211204645870 ∧ code e1211204645870 = 5609251156974 := by decide
theorem cert_e1211204645870 : check e1211204645870 [[],[]] .chain = true := by decide
def e1211204647390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211204647390 : Closed e1211204647390 ∧ code e1211204647390 = 5609251158494 := by decide
theorem cert_e1211204647390 : check e1211204647390 [[],[]] .chain = true := by decide
def e1211204647414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211204647414 : Closed e1211204647414 ∧ code e1211204647414 = 5609251158518 := by decide
theorem cert_e1211204647414 : check e1211204647414 [[],[]] .chain = true := by decide
def e1211204648158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211204648158 : Closed e1211204648158 ∧ code e1211204648158 = 5609251159262 := by decide
theorem cert_e1211204648158 : check e1211204648158 [[],[]] .chain = true := by decide
def e1211204648186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211204648186 : Closed e1211204648186 ∧ code e1211204648186 = 5609251159290 := by decide
theorem cert_e1211204648186 : check e1211204648186 [[],[]] .chain = true := by decide
def e1211204648474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211204648474 : Closed e1211204648474 ∧ code e1211204648474 = 5609251159578 := by decide
theorem cert_e1211204648474 : check e1211204648474 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204648510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e1211204648510 : Closed e1211204648510 ∧ code e1211204648510 = 5609251159614 := by decide
theorem cert_e1211204648510 : check e1211204648510 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204648558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204648558 : Closed e1211204648558 ∧ code e1211204648558 = 5609251159662 := by decide
theorem cert_e1211204648558 : check e1211204648558 [[],[]] .chain = true := by decide
def e1211204648566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211204648566 : Closed e1211204648566 ∧ code e1211204648566 = 5609251159670 := by decide
theorem cert_e1211204648566 : check e1211204648566 [[],[]] .chain = true := by decide
def e1211204648570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204648570 : Closed e1211204648570 ∧ code e1211204648570 = 5609251159674 := by decide
theorem cert_e1211204648570 : check e1211204648570 [[],[]] .chain = true := by decide
def e1211204676974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211204676974 : Closed e1211204676974 ∧ code e1211204676974 = 5609251188078 := by decide
theorem cert_e1211204676974 : check e1211204676974 [[],[]] .chain = true := by decide
def e1211204676982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211204676982 : Closed e1211204676982 ∧ code e1211204676982 = 5609251188086 := by decide
theorem cert_e1211204676982 : check e1211204676982 [[],[]] .chain = true := by decide
def e1211204677038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211204677038 : Closed e1211204677038 ∧ code e1211204677038 = 5609251188142 := by decide
theorem cert_e1211204677038 : check e1211204677038 [[],[]] .chain = true := by decide
def e1211204677050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211204677050 : Closed e1211204677050 ∧ code e1211204677050 = 5609251188154 := by decide
theorem cert_e1211204677050 : check e1211204677050 [[],[]] .chain = true := by decide
def e1211204677078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211204677078 : Closed e1211204677078 ∧ code e1211204677078 = 5609251188182 := by decide
theorem cert_e1211204677078 : check e1211204677078 [[],[]] .chain = true := by decide
def e1211204677082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211204677082 : Closed e1211204677082 ∧ code e1211204677082 = 5609251188186 := by decide
theorem cert_e1211204677082 : check e1211204677082 [[],[]] .chain = true := by decide
def e1211204677294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211204677294 : Closed e1211204677294 ∧ code e1211204677294 = 5609251188398 := by decide
theorem cert_e1211204677294 : check e1211204677294 [[],[]] .chain = true := by decide
def e1211204677306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211204677306 : Closed e1211204677306 ∧ code e1211204677306 = 5609251188410 := by decide
theorem cert_e1211204677306 : check e1211204677306 [[],[]] .chain = true := by decide
def e1211204677354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211204677354 : Closed e1211204677354 ∧ code e1211204677354 = 5609251188458 := by decide
theorem cert_e1211204677354 : check e1211204677354 [[],[]] .chain = true := by decide
def e1211204677462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211204677462 : Closed e1211204677462 ∧ code e1211204677462 = 5609251188566 := by decide
theorem cert_e1211204677462 : check e1211204677462 [[],[]] .chain = true := by decide
def e1211204677466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211204677466 : Closed e1211204677466 ∧ code e1211204677466 = 5609251188570 := by decide
theorem cert_e1211204677466 : check e1211204677466 [[],[]] .chain = true := by decide
def e1211204677482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211204677482 : Closed e1211204677482 ∧ code e1211204677482 = 5609251188586 := by decide
theorem cert_e1211204677482 : check e1211204677482 [[],[]] .chain = true := by decide
def e1211204677742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211204677742 : Closed e1211204677742 ∧ code e1211204677742 = 5609251188846 := by decide
theorem cert_e1211204677742 : check e1211204677742 [[],[]] .chain = true := by decide
def e1211204677918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211204677918 : Closed e1211204677918 ∧ code e1211204677918 = 5609251189022 := by decide
theorem cert_e1211204677918 : check e1211204677918 [[],[]] .chain = true := by decide
def e1211204678114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211204678114 : Closed e1211204678114 ∧ code e1211204678114 = 5609251189218 := by decide
theorem cert_e1211204678114 : check e1211204678114 [[],[]] .chain = true := by decide
def e1211204678126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211204678126 : Closed e1211204678126 ∧ code e1211204678126 = 5609251189230 := by decide
theorem cert_e1211204678126 : check e1211204678126 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204678510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211204678510 : Closed e1211204678510 ∧ code e1211204678510 = 5609251189614 := by decide
theorem cert_e1211204678510 : check e1211204678510 [[],[]] .chain = true := by decide
def e1211204678518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211204678518 : Closed e1211204678518 ∧ code e1211204678518 = 5609251189622 := by decide
theorem cert_e1211204678518 : check e1211204678518 [[],[]] .chain = true := by decide
def e1211204678574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211204678574 : Closed e1211204678574 ∧ code e1211204678574 = 5609251189678 := by decide
theorem cert_e1211204678574 : check e1211204678574 [[],[]] .chain = true := by decide
def e1211204678586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211204678586 : Closed e1211204678586 ∧ code e1211204678586 = 5609251189690 := by decide
theorem cert_e1211204678586 : check e1211204678586 [[],[]] .chain = true := by decide
def e1211204678614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211204678614 : Closed e1211204678614 ∧ code e1211204678614 = 5609251189718 := by decide
theorem cert_e1211204678614 : check e1211204678614 [[],[]] .chain = true := by decide
def e1211204678618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211204678618 : Closed e1211204678618 ∧ code e1211204678618 = 5609251189722 := by decide
theorem cert_e1211204678618 : check e1211204678618 [[],[]] .chain = true := by decide
def e1211204678894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211204678894 : Closed e1211204678894 ∧ code e1211204678894 = 5609251189998 := by decide
theorem cert_e1211204678894 : check e1211204678894 [[],[]] .chain = true := by decide
def e1211204678902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211204678902 : Closed e1211204678902 ∧ code e1211204678902 = 5609251190006 := by decide
theorem cert_e1211204678902 : check e1211204678902 [[],[]] .chain = true := by decide
def e1211204679278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211204679278 : Closed e1211204679278 ∧ code e1211204679278 = 5609251190382 := by decide
theorem cert_e1211204679278 : check e1211204679278 [[],[]] .chain = true := by decide
def e1211204679290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204679290 : Closed e1211204679290 ∧ code e1211204679290 = 5609251190394 := by decide
theorem cert_e1211204679290 : check e1211204679290 [[],[]] .chain = true := by decide
def e1211204679430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204679430 : Closed e1211204679430 ∧ code e1211204679430 = 5609251190534 := by decide
theorem cert_e1211204679430 : check e1211204679430 [[],[]] .chain = true := by decide
end Blc.Floor42
