import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1129768158678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129768158678 : Closed e1129768158678 ∧ code e1129768158678 = 5527814669782 := by decide
theorem cert_e1129768158678 : check e1129768158678 [[]] .width = true := by decide
def e1129768158682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129768158682 : Closed e1129768158682 ∧ code e1129768158682 = 5527814669786 := by decide
theorem cert_e1129768158682 : check e1129768158682 [[]] .width = true := by decide
def e1129768158734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129768158734 : Closed e1129768158734 ∧ code e1129768158734 = 5527814669838 := by decide
theorem cert_e1129768158734 : check e1129768158734 [[]] .width = true := by decide
def e1129768158746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129768158746 : Closed e1129768158746 ∧ code e1129768158746 = 5527814669850 := by decide
theorem cert_e1129768158746 : check e1129768158746 [[]] .width = true := by decide
def e1129768158818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129768158818 : Closed e1129768158818 ∧ code e1129768158818 = 5527814669922 := by decide
theorem cert_e1129768158818 : check e1129768158818 [[]] .width = true := by decide
def e1129768158838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129768158838 : Closed e1129768158838 ∧ code e1129768158838 = 5527814669942 := by decide
theorem cert_e1129768158838 : check e1129768158838 [[]] .width = true := by decide
def e1129768159030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129768159030 : Closed e1129768159030 ∧ code e1129768159030 = 5527814670134 := by decide
theorem cert_e1129768159030 : check e1129768159030 [[]] .width = true := by decide
def e1129768159034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129768159034 : Closed e1129768159034 ∧ code e1129768159034 = 5527814670138 := by decide
theorem cert_e1129768159034 : check e1129768159034 [[]] .width = true := by decide
def e1129768162730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129768162730 : Closed e1129768162730 ∧ code e1129768162730 = 5527814673834 := by decide
theorem cert_e1129768162730 : check e1129768162730 [[]] .width = true := by decide
def e1129768162826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129768162826 : Closed e1129768162826 ∧ code e1129768162826 = 5527814673930 := by decide
theorem cert_e1129768162826 : check e1129768162826 [[]] .width = true := by decide
def e1129768162922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129768162922 : Closed e1129768162922 ∧ code e1129768162922 = 5527814674026 := by decide
theorem cert_e1129768162922 : check e1129768162922 [[]] .width = true := by decide
def e1129768162946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129768162946 : Closed e1129768162946 ∧ code e1129768162946 = 5527814674050 := by decide
theorem cert_e1129768162946 : check e1129768162946 [[]] .width = true := by decide
def e1129768162970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129768162970 : Closed e1129768162970 ∧ code e1129768162970 = 5527814674074 := by decide
theorem cert_e1129768162970 : check e1129768162970 [[]] .width = true := by decide
def e1129768163354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129768163354 : Closed e1129768163354 ∧ code e1129768163354 = 5527814674458 := by decide
theorem cert_e1129768163354 : check e1129768163354 [[]] .width = true := by decide
def e1129768163446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129768163446 : Closed e1129768163446 ∧ code e1129768163446 = 5527814674550 := by decide
theorem cert_e1129768163446 : check e1129768163446 [[]] .width = true := by decide
def e1129768163690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129768163690 : Closed e1129768163690 ∧ code e1129768163690 = 5527814674794 := by decide
theorem cert_e1129768163690 : check e1129768163690 [[]] .width = true := by decide
def e1129768163714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129768163714 : Closed e1129768163714 ∧ code e1129768163714 = 5527814674818 := by decide
theorem cert_e1129768163714 : check e1129768163714 [[]] .width = true := by decide
def e1129768163738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129768163738 : Closed e1129768163738 ∧ code e1129768163738 = 5527814674842 := by decide
theorem cert_e1129768163738 : check e1129768163738 [[]] .width = true := by decide
def e1129768403142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129768403142 : Closed e1129768403142 ∧ code e1129768403142 = 5527814914246 := by decide
theorem cert_e1129768403142 : check e1129768403142 [[]] .width = true := by decide
def e1129768509466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129768509466 : Closed e1129768509466 ∧ code e1129768509466 = 5527815020570 := by decide
theorem cert_e1129768509466 : check e1129768509466 [[]] .width = true := by decide
def e1129768509558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129768509558 : Closed e1129768509558 ∧ code e1129768509558 = 5527815020662 := by decide
private def t_e1129768509558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129768509558 : ¬ IsSelfInterpreter e1129768509558 :=
  wSource (t := t_e1129768509558) (replay_sound (ps := []) (t := e1129768509558) (by decide)) (by decide)
def e1129768509802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129768509802 : Closed e1129768509802 ∧ code e1129768509802 = 5527815020906 := by decide
private def t_e1129768509802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129768509802 : ¬ IsSelfInterpreter e1129768509802 :=
  wSource (t := t_e1129768509802) (replay_sound (ps := []) (t := e1129768509802) (by decide)) (by decide)
def e1129768509850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129768509850 : Closed e1129768509850 ∧ code e1129768509850 = 5527815020954 := by decide
private def t_e1129768509850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129768509850 : ¬ IsSelfInterpreter e1129768509850 :=
  wSource (t := t_e1129768509850) (replay_sound (ps := []) (t := e1129768509850) (by decide)) (by decide)
def e1129768525850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129768525850 : Closed e1129768525850 ∧ code e1129768525850 = 5527815036954 := by decide
theorem cert_e1129768525850 : check e1129768525850 [[]] .width = true := by decide
def e1129768525942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129768525942 : Closed e1129768525942 ∧ code e1129768525942 = 5527815037046 := by decide
private def t_e1129768525942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129768525942 : ¬ IsSelfInterpreter e1129768525942 :=
  wSource (t := t_e1129768525942) (replay_sound (ps := []) (t := e1129768525942) (by decide)) (by decide)
def e1129768526186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129768526186 : Closed e1129768526186 ∧ code e1129768526186 = 5527815037290 := by decide
private def t_e1129768526186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129768526186 : ¬ IsSelfInterpreter e1129768526186 :=
  wSource (t := t_e1129768526186) (replay_sound (ps := []) (t := e1129768526186) (by decide)) (by decide)
def e1129768526234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129768526234 : Closed e1129768526234 ∧ code e1129768526234 = 5527815037338 := by decide
private def t_e1129768526234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129768526234 : ¬ IsSelfInterpreter e1129768526234 :=
  wSource (t := t_e1129768526234) (replay_sound (ps := []) (t := e1129768526234) (by decide)) (by decide)
def e1129768530118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129768530118 : Closed e1129768530118 ∧ code e1129768530118 = 5527815041222 := by decide
theorem cert_e1129768530118 : check e1129768530118 [[]] .width = true := by decide
def e1129768531994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129768531994 : Closed e1129768531994 ∧ code e1129768531994 = 5527815043098 := by decide
theorem cert_e1129768531994 : check e1129768531994 [[]] .width = true := by decide
def e1129768540186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129768540186 : Closed e1129768540186 ∧ code e1129768540186 = 5527815051290 := by decide
theorem cert_e1129768540186 : check e1129768540186 [[]] .width = true := by decide
def e1129768681498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129768681498 : Closed e1129768681498 ∧ code e1129768681498 = 5527815192602 := by decide
theorem cert_e1129768681498 : check e1129768681498 [[]] .width = true := by decide
def e1129768681590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129768681590 : Closed e1129768681590 ∧ code e1129768681590 = 5527815192694 := by decide
theorem cert_e1129768681590 : check e1129768681590 [[]] .width = true := by decide
def e1129768681834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129768681834 : Closed e1129768681834 ∧ code e1129768681834 = 5527815192938 := by decide
theorem cert_e1129768681834 : check e1129768681834 [[]] .width = true := by decide
def e1129768681882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129768681882 : Closed e1129768681882 ∧ code e1129768681882 = 5527815192986 := by decide
theorem cert_e1129768681882 : check e1129768681882 [[]] .width = true := by decide
def e1129768681966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129768681966 : Closed e1129768681966 ∧ code e1129768681966 = 5527815193070 := by decide
private def t_e1129768681966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e1129768681966 : ¬ IsSelfInterpreter e1129768681966 :=
  wSource (t := t_e1129768681966) (replay_sound (ps := []) (t := e1129768681966) (by decide)) (by decide)
def e1129768682890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129768682890 : Closed e1129768682890 ∧ code e1129768682890 = 5527815193994 := by decide
theorem cert_e1129768682890 : check e1129768682890 [[]] .width = true := by decide
def e1129768682914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129768682914 : Closed e1129768682914 ∧ code e1129768682914 = 5527815194018 := by decide
theorem cert_e1129768682914 : check e1129768682914 [[]] .width = true := by decide
def e1129768682934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129768682934 : Closed e1129768682934 ∧ code e1129768682934 = 5527815194038 := by decide
theorem cert_e1129768682934 : check e1129768682934 [[]] .width = true := by decide
def e1129768682966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129768682966 : Closed e1129768682966 ∧ code e1129768682966 = 5527815194070 := by decide
theorem cert_e1129768682966 : check e1129768682966 [[]] .width = true := by decide
def e1129768682970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129768682970 : Closed e1129768682970 ∧ code e1129768682970 = 5527815194074 := by decide
private def t_e1129768682970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e1129768682970 : ¬ IsSelfInterpreter e1129768682970 :=
  wSource (t := t_e1129768682970) (replay_sound (ps := []) (t := e1129768682970) (by decide)) (by decide)
def e1129768683022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129768683022 : Closed e1129768683022 ∧ code e1129768683022 = 5527815194126 := by decide
theorem cert_e1129768683022 : check e1129768683022 [[]] .width = true := by decide
def e1129768683034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129768683034 : Closed e1129768683034 ∧ code e1129768683034 = 5527815194138 := by decide
theorem cert_e1129768683034 : check e1129768683034 [[]] .width = true := by decide
def e1129768683106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129768683106 : Closed e1129768683106 ∧ code e1129768683106 = 5527815194210 := by decide
theorem cert_e1129768683106 : check e1129768683106 [[]] .width = true := by decide
def e1129768683126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129768683126 : Closed e1129768683126 ∧ code e1129768683126 = 5527815194230 := by decide
theorem cert_e1129768683126 : check e1129768683126 [[]] .width = true := by decide
def e1129768683318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129768683318 : Closed e1129768683318 ∧ code e1129768683318 = 5527815194422 := by decide
theorem cert_e1129768683318 : check e1129768683318 [[]] .width = true := by decide
def e1129768683322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129768683322 : Closed e1129768683322 ∧ code e1129768683322 = 5527815194426 := by decide
theorem cert_e1129768683322 : check e1129768683322 [[]] .width = true := by decide
def e1129768687018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129768687018 : Closed e1129768687018 ∧ code e1129768687018 = 5527815198122 := by decide
private def t_e1129768687018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e1129768687018 : ¬ IsSelfInterpreter e1129768687018 :=
  wSource (t := t_e1129768687018) (replay_sound (ps := []) (t := e1129768687018) (by decide)) (by decide)
def e1129768687114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129768687114 : Closed e1129768687114 ∧ code e1129768687114 = 5527815198218 := by decide
theorem cert_e1129768687114 : check e1129768687114 [[]] .width = true := by decide
def e1129768687210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129768687210 : Closed e1129768687210 ∧ code e1129768687210 = 5527815198314 := by decide
private def t_e1129768687210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e1129768687210 : ¬ IsSelfInterpreter e1129768687210 :=
  wSource (t := t_e1129768687210) (replay_sound (ps := []) (t := e1129768687210) (by decide)) (by decide)
def e1129768687234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129768687234 : Closed e1129768687234 ∧ code e1129768687234 = 5527815198338 := by decide
private def t_e1129768687234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e1129768687234 : ¬ IsSelfInterpreter e1129768687234 :=
  wSource (t := t_e1129768687234) (replay_sound (ps := []) (t := e1129768687234) (by decide)) (by decide)
def e1129768687258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129768687258 : Closed e1129768687258 ∧ code e1129768687258 = 5527815198362 := by decide
private def t_e1129768687258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e1129768687258 : ¬ IsSelfInterpreter e1129768687258 :=
  wSource (t := t_e1129768687258) (replay_sound (ps := []) (t := e1129768687258) (by decide)) (by decide)
def e1129768687642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129768687642 : Closed e1129768687642 ∧ code e1129768687642 = 5527815198746 := by decide
theorem cert_e1129768687642 : check e1129768687642 [[]] .width = true := by decide
def e1129768687734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129768687734 : Closed e1129768687734 ∧ code e1129768687734 = 5527815198838 := by decide
private def t_e1129768687734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e1129768687734 : ¬ IsSelfInterpreter e1129768687734 :=
  wSource (t := t_e1129768687734) (replay_sound (ps := []) (t := e1129768687734) (by decide)) (by decide)
def e1129768687978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129768687978 : Closed e1129768687978 ∧ code e1129768687978 = 5527815199082 := by decide
private def t_e1129768687978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e1129768687978 : ¬ IsSelfInterpreter e1129768687978 :=
  wSource (t := t_e1129768687978) (replay_sound (ps := []) (t := e1129768687978) (by decide)) (by decide)
def e1129768688002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129768688002 : Closed e1129768688002 ∧ code e1129768688002 = 5527815199106 := by decide
theorem cert_e1129768688002 : check e1129768688002 [[]] .width = true := by decide
def e1129768688026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129768688026 : Closed e1129768688026 ∧ code e1129768688026 = 5527815199130 := by decide
private def t_e1129768688026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e1129768688026 : ¬ IsSelfInterpreter e1129768688026 :=
  wSource (t := t_e1129768688026) (replay_sound (ps := []) (t := e1129768688026) (by decide)) (by decide)
def e1129770238150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129770238150 : Closed e1129770238150 ∧ code e1129770238150 = 5527816749254 := by decide
theorem cert_e1129770238150 : check e1129770238150 [[]] .width = true := by decide
def e1129770336454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129770336454 : Closed e1129770336454 ∧ code e1129770336454 = 5527816847558 := by decide
theorem cert_e1129770336454 : check e1129770336454 [[]] .width = true := by decide
def e1129771098138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129771098138 : Closed e1129771098138 ∧ code e1129771098138 = 5527817609242 := by decide
theorem cert_e1129771098138 : check e1129771098138 [[]] .width = true := by decide
def e1129771098230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129771098230 : Closed e1129771098230 ∧ code e1129771098230 = 5527817609334 := by decide
theorem cert_e1129771098230 : check e1129771098230 [[]] .width = true := by decide
def e1129771098474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129771098474 : Closed e1129771098474 ∧ code e1129771098474 = 5527817609578 := by decide
theorem cert_e1129771098474 : check e1129771098474 [[]] .width = true := by decide
def e1129771098522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129771098522 : Closed e1129771098522 ∧ code e1129771098522 = 5527817609626 := by decide
theorem cert_e1129771098522 : check e1129771098522 [[]] .width = true := by decide
def e1129771135174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771135174 : Closed e1129771135174 ∧ code e1129771135174 = 5527817646278 := by decide
theorem cert_e1129771135174 : check e1129771135174 [[]] .width = true := by decide
def e1129771147290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129771147290 : Closed e1129771147290 ∧ code e1129771147290 = 5527817658394 := by decide
theorem cert_e1129771147290 : check e1129771147290 [[]] .width = true := by decide
def e1129771147382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129771147382 : Closed e1129771147382 ∧ code e1129771147382 = 5527817658486 := by decide
theorem cert_e1129771147382 : check e1129771147382 [[]] .width = true := by decide
def e1129771147626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129771147626 : Closed e1129771147626 ∧ code e1129771147626 = 5527817658730 := by decide
theorem cert_e1129771147626 : check e1129771147626 [[]] .width = true := by decide
def e1129771147674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129771147674 : Closed e1129771147674 ∧ code e1129771147674 = 5527817658778 := by decide
theorem cert_e1129771147674 : check e1129771147674 [[]] .width = true := by decide
def e1129771151558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771151558 : Closed e1129771151558 ∧ code e1129771151558 = 5527817662662 := by decide
theorem cert_e1129771151558 : check e1129771151558 [[]] .width = true := by decide
def e1129771153434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129771153434 : Closed e1129771153434 ∧ code e1129771153434 = 5527817664538 := by decide
theorem cert_e1129771153434 : check e1129771153434 [[]] .width = true := by decide
def e1129771266246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771266246 : Closed e1129771266246 ∧ code e1129771266246 = 5527817777350 := by decide
theorem cert_e1129771266246 : check e1129771266246 [[]] .width = true := by decide
def e1129771290822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771290822 : Closed e1129771290822 ∧ code e1129771290822 = 5527817801926 := by decide
theorem cert_e1129771290822 : check e1129771290822 [[]] .width = true := by decide
def e1129771343898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129771343898 : Closed e1129771343898 ∧ code e1129771343898 = 5527817855002 := by decide
theorem cert_e1129771343898 : check e1129771343898 [[]] .width = true := by decide
def e1129771343990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129771343990 : Closed e1129771343990 ∧ code e1129771343990 = 5527817855094 := by decide
theorem cert_e1129771343990 : check e1129771343990 [[]] .width = true := by decide
def e1129771344234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129771344234 : Closed e1129771344234 ∧ code e1129771344234 = 5527817855338 := by decide
theorem cert_e1129771344234 : check e1129771344234 [[]] .width = true := by decide
def e1129771344282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129771344282 : Closed e1129771344282 ∧ code e1129771344282 = 5527817855386 := by decide
theorem cert_e1129771344282 : check e1129771344282 [[]] .width = true := by decide
def e1129771348166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771348166 : Closed e1129771348166 ∧ code e1129771348166 = 5527817859270 := by decide
theorem cert_e1129771348166 : check e1129771348166 [[]] .width = true := by decide
def e1129771350042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129771350042 : Closed e1129771350042 ∧ code e1129771350042 = 5527817861146 := by decide
theorem cert_e1129771350042 : check e1129771350042 [[]] .width = true := by decide
def e1129771356358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771356358 : Closed e1129771356358 ∧ code e1129771356358 = 5527817867462 := by decide
theorem cert_e1129771356358 : check e1129771356358 [[]] .width = true := by decide
def e1129771362330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129771362330 : Closed e1129771362330 ∧ code e1129771362330 = 5527817873434 := by decide
theorem cert_e1129771362330 : check e1129771362330 [[]] .width = true := by decide
def e1129771679942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129771679942 : Closed e1129771679942 ∧ code e1129771679942 = 5527818191046 := by decide
theorem cert_e1129771679942 : check e1129771679942 [[]] .width = true := by decide
def e1129771884570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129771884570 : Closed e1129771884570 ∧ code e1129771884570 = 5527818395674 := by decide
theorem cert_e1129771884570 : check e1129771884570 [[]] .width = true := by decide
def e1129771884662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129771884662 : Closed e1129771884662 ∧ code e1129771884662 = 5527818395766 := by decide
theorem cert_e1129771884662 : check e1129771884662 [[]] .width = true := by decide
def e1129771884906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129771884906 : Closed e1129771884906 ∧ code e1129771884906 = 5527818396010 := by decide
theorem cert_e1129771884906 : check e1129771884906 [[]] .width = true := by decide
def e1129771884954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129771884954 : Closed e1129771884954 ∧ code e1129771884954 = 5527818396058 := by decide
theorem cert_e1129771884954 : check e1129771884954 [[]] .width = true := by decide
def e1129771921606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771921606 : Closed e1129771921606 ∧ code e1129771921606 = 5527818432710 := by decide
theorem cert_e1129771921606 : check e1129771921606 [[]] .width = true := by decide
def e1129771933722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129771933722 : Closed e1129771933722 ∧ code e1129771933722 = 5527818444826 := by decide
theorem cert_e1129771933722 : check e1129771933722 [[]] .width = true := by decide
def e1129771933814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129771933814 : Closed e1129771933814 ∧ code e1129771933814 = 5527818444918 := by decide
theorem cert_e1129771933814 : check e1129771933814 [[]] .width = true := by decide
def e1129771934058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129771934058 : Closed e1129771934058 ∧ code e1129771934058 = 5527818445162 := by decide
theorem cert_e1129771934058 : check e1129771934058 [[]] .width = true := by decide
def e1129771934106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129771934106 : Closed e1129771934106 ∧ code e1129771934106 = 5527818445210 := by decide
theorem cert_e1129771934106 : check e1129771934106 [[]] .width = true := by decide
def e1129771937990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129771937990 : Closed e1129771937990 ∧ code e1129771937990 = 5527818449094 := by decide
theorem cert_e1129771937990 : check e1129771937990 [[]] .width = true := by decide
def e1129771939866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129771939866 : Closed e1129771939866 ∧ code e1129771939866 = 5527818450970 := by decide
theorem cert_e1129771939866 : check e1129771939866 [[]] .width = true := by decide
def e1129772351514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129772351514 : Closed e1129772351514 ∧ code e1129772351514 = 5527818862618 := by decide
theorem cert_e1129772351514 : check e1129772351514 [[]] .width = true := by decide
def e1129772351606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129772351606 : Closed e1129772351606 ∧ code e1129772351606 = 5527818862710 := by decide
theorem cert_e1129772351606 : check e1129772351606 [[]] .width = true := by decide
def e1129772351850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129772351850 : Closed e1129772351850 ∧ code e1129772351850 = 5527818862954 := by decide
theorem cert_e1129772351850 : check e1129772351850 [[]] .width = true := by decide
def e1129772351898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129772351898 : Closed e1129772351898 ∧ code e1129772351898 = 5527818863002 := by decide
theorem cert_e1129772351898 : check e1129772351898 [[]] .width = true := by decide
def e1129772351982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129772351982 : Closed e1129772351982 ∧ code e1129772351982 = 5527818863086 := by decide
theorem cert_e1129772351982 : check e1129772351982 [[]] .width = true := by decide
def e1129772352906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129772352906 : Closed e1129772352906 ∧ code e1129772352906 = 5527818864010 := by decide
theorem cert_e1129772352906 : check e1129772352906 [[]] .width = true := by decide
def e1129772352930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129772352930 : Closed e1129772352930 ∧ code e1129772352930 = 5527818864034 := by decide
theorem cert_e1129772352930 : check e1129772352930 [[]] .width = true := by decide
def e1129772352950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129772352950 : Closed e1129772352950 ∧ code e1129772352950 = 5527818864054 := by decide
theorem cert_e1129772352950 : check e1129772352950 [[]] .width = true := by decide
def e1129772352982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129772352982 : Closed e1129772352982 ∧ code e1129772352982 = 5527818864086 := by decide
theorem cert_e1129772352982 : check e1129772352982 [[]] .width = true := by decide
def e1129772352986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129772352986 : Closed e1129772352986 ∧ code e1129772352986 = 5527818864090 := by decide
theorem cert_e1129772352986 : check e1129772352986 [[]] .width = true := by decide
def e1129772353038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129772353038 : Closed e1129772353038 ∧ code e1129772353038 = 5527818864142 := by decide
theorem cert_e1129772353038 : check e1129772353038 [[]] .width = true := by decide
def e1129772353050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129772353050 : Closed e1129772353050 ∧ code e1129772353050 = 5527818864154 := by decide
theorem cert_e1129772353050 : check e1129772353050 [[]] .width = true := by decide
def e1129772353122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129772353122 : Closed e1129772353122 ∧ code e1129772353122 = 5527818864226 := by decide
theorem cert_e1129772353122 : check e1129772353122 [[]] .width = true := by decide
def e1129772353142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129772353142 : Closed e1129772353142 ∧ code e1129772353142 = 5527818864246 := by decide
theorem cert_e1129772353142 : check e1129772353142 [[]] .width = true := by decide
def e1129772353334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129772353334 : Closed e1129772353334 ∧ code e1129772353334 = 5527818864438 := by decide
theorem cert_e1129772353334 : check e1129772353334 [[]] .width = true := by decide
def e1129772353338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129772353338 : Closed e1129772353338 ∧ code e1129772353338 = 5527818864442 := by decide
theorem cert_e1129772353338 : check e1129772353338 [[]] .width = true := by decide
def e1129772357034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129772357034 : Closed e1129772357034 ∧ code e1129772357034 = 5527818868138 := by decide
theorem cert_e1129772357034 : check e1129772357034 [[]] .width = true := by decide
def e1129772357130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129772357130 : Closed e1129772357130 ∧ code e1129772357130 = 5527818868234 := by decide
theorem cert_e1129772357130 : check e1129772357130 [[]] .width = true := by decide
def e1129772357226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129772357226 : Closed e1129772357226 ∧ code e1129772357226 = 5527818868330 := by decide
theorem cert_e1129772357226 : check e1129772357226 [[]] .width = true := by decide
def e1129772357250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129772357250 : Closed e1129772357250 ∧ code e1129772357250 = 5527818868354 := by decide
theorem cert_e1129772357250 : check e1129772357250 [[]] .width = true := by decide
def e1129772357274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129772357274 : Closed e1129772357274 ∧ code e1129772357274 = 5527818868378 := by decide
theorem cert_e1129772357274 : check e1129772357274 [[]] .width = true := by decide
def e1129772357658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129772357658 : Closed e1129772357658 ∧ code e1129772357658 = 5527818868762 := by decide
theorem cert_e1129772357658 : check e1129772357658 [[]] .width = true := by decide
def e1129772357750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129772357750 : Closed e1129772357750 ∧ code e1129772357750 = 5527818868854 := by decide
theorem cert_e1129772357750 : check e1129772357750 [[]] .width = true := by decide
def e1129772357994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129772357994 : Closed e1129772357994 ∧ code e1129772357994 = 5527818869098 := by decide
theorem cert_e1129772357994 : check e1129772357994 [[]] .width = true := by decide
def e1129772358018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129772358018 : Closed e1129772358018 ∧ code e1129772358018 = 5527818869122 := by decide
theorem cert_e1129772358018 : check e1129772358018 [[]] .width = true := by decide
def e1129772358042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129772358042 : Closed e1129772358042 ∧ code e1129772358042 = 5527818869146 := by decide
theorem cert_e1129772358042 : check e1129772358042 [[]] .width = true := by decide
def e1129772708038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129772708038 : Closed e1129772708038 ∧ code e1129772708038 = 5527819219142 := by decide
theorem cert_e1129772708038 : check e1129772708038 [[]] .width = true := by decide
def e1129772732614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129772732614 : Closed e1129772732614 ∧ code e1129772732614 = 5527819243718 := by decide
theorem cert_e1129772732614 : check e1129772732614 [[]] .width = true := by decide
def e1129773056198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129773056198 : Closed e1129773056198 ∧ code e1129773056198 = 5527819567302 := by decide
theorem cert_e1129773056198 : check e1129773056198 [[]] .width = true := by decide
def e1129773113370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129773113370 : Closed e1129773113370 ∧ code e1129773113370 = 5527819624474 := by decide
theorem cert_e1129773113370 : check e1129773113370 [[]] .width = true := by decide
def e1129773113462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129773113462 : Closed e1129773113462 ∧ code e1129773113462 = 5527819624566 := by decide
theorem cert_e1129773113462 : check e1129773113462 [[]] .width = true := by decide
def e1129773113706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129773113706 : Closed e1129773113706 ∧ code e1129773113706 = 5527819624810 := by decide
theorem cert_e1129773113706 : check e1129773113706 [[]] .width = true := by decide
def e1129773113754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129773113754 : Closed e1129773113754 ∧ code e1129773113754 = 5527819624858 := by decide
theorem cert_e1129773113754 : check e1129773113754 [[]] .width = true := by decide
def e1129773117638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129773117638 : Closed e1129773117638 ∧ code e1129773117638 = 5527819628742 := by decide
theorem cert_e1129773117638 : check e1129773117638 [[]] .width = true := by decide
def e1129773119514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129773119514 : Closed e1129773119514 ∧ code e1129773119514 = 5527819630618 := by decide
theorem cert_e1129773119514 : check e1129773119514 [[]] .width = true := by decide
def e1129773125830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129773125830 : Closed e1129773125830 ∧ code e1129773125830 = 5527819636934 := by decide
theorem cert_e1129773125830 : check e1129773125830 [[]] .width = true := by decide
def e1129773131802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129773131802 : Closed e1129773131802 ∧ code e1129773131802 = 5527819642906 := by decide
theorem cert_e1129773131802 : check e1129773131802 [[]] .width = true := by decide
def e1129773137946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129773137946 : Closed e1129773137946 ∧ code e1129773137946 = 5527819649050 := by decide
theorem cert_e1129773137946 : check e1129773137946 [[]] .width = true := by decide
def e1129773138038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129773138038 : Closed e1129773138038 ∧ code e1129773138038 = 5527819649142 := by decide
theorem cert_e1129773138038 : check e1129773138038 [[]] .width = true := by decide
def e1129773138282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129773138282 : Closed e1129773138282 ∧ code e1129773138282 = 5527819649386 := by decide
theorem cert_e1129773138282 : check e1129773138282 [[]] .width = true := by decide
def e1129773138330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129773138330 : Closed e1129773138330 ∧ code e1129773138330 = 5527819649434 := by decide
theorem cert_e1129773138330 : check e1129773138330 [[]] .width = true := by decide
def e1129773138414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129773138414 : Closed e1129773138414 ∧ code e1129773138414 = 5527819649518 := by decide
theorem cert_e1129773138414 : check e1129773138414 [[]] .width = true := by decide
def e1129773139338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129773139338 : Closed e1129773139338 ∧ code e1129773139338 = 5527819650442 := by decide
theorem cert_e1129773139338 : check e1129773139338 [[]] .width = true := by decide
def e1129773139362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129773139362 : Closed e1129773139362 ∧ code e1129773139362 = 5527819650466 := by decide
theorem cert_e1129773139362 : check e1129773139362 [[]] .width = true := by decide
def e1129773139382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129773139382 : Closed e1129773139382 ∧ code e1129773139382 = 5527819650486 := by decide
theorem cert_e1129773139382 : check e1129773139382 [[]] .width = true := by decide
def e1129773139414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129773139414 : Closed e1129773139414 ∧ code e1129773139414 = 5527819650518 := by decide
theorem cert_e1129773139414 : check e1129773139414 [[]] .width = true := by decide
def e1129773139418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129773139418 : Closed e1129773139418 ∧ code e1129773139418 = 5527819650522 := by decide
theorem cert_e1129773139418 : check e1129773139418 [[]] .width = true := by decide
def e1129773139470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129773139470 : Closed e1129773139470 ∧ code e1129773139470 = 5527819650574 := by decide
theorem cert_e1129773139470 : check e1129773139470 [[]] .width = true := by decide
def e1129773139482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129773139482 : Closed e1129773139482 ∧ code e1129773139482 = 5527819650586 := by decide
theorem cert_e1129773139482 : check e1129773139482 [[]] .width = true := by decide
def e1129773139554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129773139554 : Closed e1129773139554 ∧ code e1129773139554 = 5527819650658 := by decide
theorem cert_e1129773139554 : check e1129773139554 [[]] .width = true := by decide
def e1129773139574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129773139574 : Closed e1129773139574 ∧ code e1129773139574 = 5527819650678 := by decide
theorem cert_e1129773139574 : check e1129773139574 [[]] .width = true := by decide
def e1129773139766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129773139766 : Closed e1129773139766 ∧ code e1129773139766 = 5527819650870 := by decide
theorem cert_e1129773139766 : check e1129773139766 [[]] .width = true := by decide
def e1129773139770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129773139770 : Closed e1129773139770 ∧ code e1129773139770 = 5527819650874 := by decide
theorem cert_e1129773139770 : check e1129773139770 [[]] .width = true := by decide
def e1129773143466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129773143466 : Closed e1129773143466 ∧ code e1129773143466 = 5527819654570 := by decide
theorem cert_e1129773143466 : check e1129773143466 [[]] .width = true := by decide
def e1129773143562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129773143562 : Closed e1129773143562 ∧ code e1129773143562 = 5527819654666 := by decide
theorem cert_e1129773143562 : check e1129773143562 [[]] .width = true := by decide
def e1129773143658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129773143658 : Closed e1129773143658 ∧ code e1129773143658 = 5527819654762 := by decide
theorem cert_e1129773143658 : check e1129773143658 [[]] .width = true := by decide
def e1129773143682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129773143682 : Closed e1129773143682 ∧ code e1129773143682 = 5527819654786 := by decide
theorem cert_e1129773143682 : check e1129773143682 [[]] .width = true := by decide
def e1129773143706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129773143706 : Closed e1129773143706 ∧ code e1129773143706 = 5527819654810 := by decide
theorem cert_e1129773143706 : check e1129773143706 [[]] .width = true := by decide
def e1129773144090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129773144090 : Closed e1129773144090 ∧ code e1129773144090 = 5527819655194 := by decide
theorem cert_e1129773144090 : check e1129773144090 [[]] .width = true := by decide
def e1129773144182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129773144182 : Closed e1129773144182 ∧ code e1129773144182 = 5527819655286 := by decide
theorem cert_e1129773144182 : check e1129773144182 [[]] .width = true := by decide
def e1129773144426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129773144426 : Closed e1129773144426 ∧ code e1129773144426 = 5527819655530 := by decide
theorem cert_e1129773144426 : check e1129773144426 [[]] .width = true := by decide
def e1129773144450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129773144450 : Closed e1129773144450 ∧ code e1129773144450 = 5527819655554 := by decide
theorem cert_e1129773144450 : check e1129773144450 [[]] .width = true := by decide
def e1129773144474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129773144474 : Closed e1129773144474 ∧ code e1129773144474 = 5527819655578 := by decide
theorem cert_e1129773144474 : check e1129773144474 [[]] .width = true := by decide
def e1129773973702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129773973702 : Closed e1129773973702 ∧ code e1129773973702 = 5527820484806 := by decide
theorem cert_e1129773973702 : check e1129773973702 [[]] .width = true := by decide
def e1129774006470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129774006470 : Closed e1129774006470 ∧ code e1129774006470 = 5527820517574 := by decide
theorem cert_e1129774006470 : check e1129774006470 [[]] .width = true := by decide
def e1129774407706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129774407706 : Closed e1129774407706 ∧ code e1129774407706 = 5527820918810 := by decide
theorem cert_e1129774407706 : check e1129774407706 [[]] .width = true := by decide
def e1129774407798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129774407798 : Closed e1129774407798 ∧ code e1129774407798 = 5527820918902 := by decide
private def t_e1129774407798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129774407798 : ¬ IsSelfInterpreter e1129774407798 :=
  wSource (t := t_e1129774407798) (replay_sound (ps := []) (t := e1129774407798) (by decide)) (by decide)
def e1129774408042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129774408042 : Closed e1129774408042 ∧ code e1129774408042 = 5527820919146 := by decide
private def t_e1129774408042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129774408042 : ¬ IsSelfInterpreter e1129774408042 :=
  wSource (t := t_e1129774408042) (replay_sound (ps := []) (t := e1129774408042) (by decide)) (by decide)
def e1129774408090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129774408090 : Closed e1129774408090 ∧ code e1129774408090 = 5527820919194 := by decide
private def t_e1129774408090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129774408090 : ¬ IsSelfInterpreter e1129774408090 :=
  wSource (t := t_e1129774408090) (replay_sound (ps := []) (t := e1129774408090) (by decide)) (by decide)
end Blc.Floor42
