import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801446378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e302801446378 : Closed e302801446378 ∧ code e302801446378 = 4700847957482 := by decide
theorem cert_e302801446378 : check e302801446378 [[.under],[.under]] .three = true := by decide
def e302801446510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801446510 : Closed e302801446510 ∧ code e302801446510 = 4700847957614 := by decide
theorem cert_e302801446510 : check e302801446510 [[.under],[.under]] .three = true := by decide
def e302801446522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801446522 : Closed e302801446522 ∧ code e302801446522 = 4700847957626 := by decide
theorem cert_e302801446522 : check e302801446522 [[.under],[.under]] .three = true := by decide
def e302801446810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801446810 : Closed e302801446810 ∧ code e302801446810 = 4700847957914 := by decide
theorem cert_e302801446810 : check e302801446810 [[.under],[.under]] .three = true := by decide
def e302801449686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302801449686 : Closed e302801449686 ∧ code e302801449686 = 4700847960790 := by decide
theorem cert_e302801449686 : check e302801449686 [[.under],[.under]] .three = true := by decide
def e302801449690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302801449690 : Closed e302801449690 ∧ code e302801449690 = 4700847960794 := by decide
theorem cert_e302801449690 : check e302801449690 [[.under],[.under]] .three = true := by decide
def e302801449706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302801449706 : Closed e302801449706 ∧ code e302801449706 = 4700847960810 := by decide
theorem cert_e302801449706 : check e302801449706 [[.under],[.under]] .three = true := by decide
def e302801449782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801449782 : Closed e302801449782 ∧ code e302801449782 = 4700847960886 := by decide
theorem cert_e302801449782 : check e302801449782 [[.under],[.under]] .three = true := by decide
def e302801449786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801449786 : Closed e302801449786 ∧ code e302801449786 = 4700847960890 := by decide
theorem cert_e302801449786 : check e302801449786 [[.under],[.under]] .three = true := by decide
def e302801449882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801449882 : Closed e302801449882 ∧ code e302801449882 = 4700847960986 := by decide
theorem cert_e302801449882 : check e302801449882 [[.under],[.under]] .three = true := by decide
def e302801841630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e302801841630 : Closed e302801841630 ∧ code e302801841630 = 4700848352734 := by decide
theorem cert_e302801841630 : check e302801841630 [[.under],[.under]] .three = true := by decide
def e302801841646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e302801841646 : Closed e302801841646 ∧ code e302801841646 = 4700848352750 := by decide
theorem cert_e302801841646 : check e302801841646 [[.under],[.under]] .three = true := by decide
def e302801841886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e302801841886 : Closed e302801841886 ∧ code e302801841886 = 4700848352990 := by decide
theorem cert_e302801841886 : check e302801841886 [[.under],[.under]] .three = true := by decide
def e302801841910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e302801841910 : Closed e302801841910 ∧ code e302801841910 = 4700848353014 := by decide
theorem cert_e302801841910 : check e302801841910 [[.under],[.under]] .three = true := by decide
def e302801842030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e302801842030 : Closed e302801842030 ∧ code e302801842030 = 4700848353134 := by decide
theorem cert_e302801842030 : check e302801842030 [[.under],[.under]] .three = true := by decide
def e302801842038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e302801842038 : Closed e302801842038 ∧ code e302801842038 = 4700848353142 := by decide
theorem cert_e302801842038 : check e302801842038 [[.under],[.under]] .three = true := by decide
def e302801843678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e302801843678 : Closed e302801843678 ∧ code e302801843678 = 4700848354782 := by decide
theorem cert_e302801843678 : check e302801843678 [[.under],[.under]] .three = true := by decide
def e302801843694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e302801843694 : Closed e302801843694 ∧ code e302801843694 = 4700848354798 := by decide
theorem cert_e302801843694 : check e302801843694 [[.under],[.under]] .three = true := by decide
def e302801844062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e302801844062 : Closed e302801844062 ∧ code e302801844062 = 4700848355166 := by decide
theorem cert_e302801844062 : check e302801844062 [[.under],[.under]] .three = true := by decide
def e302801844090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e302801844090 : Closed e302801844090 ∧ code e302801844090 = 4700848355194 := by decide
theorem cert_e302801844090 : check e302801844090 [[.under],[.under]] .three = true := by decide
def e302801844142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e302801844142 : Closed e302801844142 ∧ code e302801844142 = 4700848355246 := by decide
theorem cert_e302801844142 : check e302801844142 [[.under],[.under]] .three = true := by decide
def e302801844154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e302801844154 : Closed e302801844154 ∧ code e302801844154 = 4700848355258 := by decide
theorem cert_e302801844154 : check e302801844154 [[.under],[.under]] .three = true := by decide
def e302801844958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302801844958 : Closed e302801844958 ∧ code e302801844958 = 4700848356062 := by decide
theorem cert_e302801844958 : check e302801844958 [[.under],[.under]] .three = true := by decide
def e302801844982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302801844982 : Closed e302801844982 ∧ code e302801844982 = 4700848356086 := by decide
theorem cert_e302801844982 : check e302801844982 [[.under],[.under]] .three = true := by decide
def e302801845086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302801845086 : Closed e302801845086 ∧ code e302801845086 = 4700848356190 := by decide
theorem cert_e302801845086 : check e302801845086 [[.under],[.under]] .three = true := by decide
def e302801845114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302801845114 : Closed e302801845114 ∧ code e302801845114 = 4700848356218 := by decide
theorem cert_e302801845114 : check e302801845114 [[.under],[.under]] .three = true := by decide
def e302801845206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302801845206 : Closed e302801845206 ∧ code e302801845206 = 4700848356310 := by decide
theorem cert_e302801845206 : check e302801845206 [[.under],[.under]] .three = true := by decide
def e302801845210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302801845210 : Closed e302801845210 ∧ code e302801845210 = 4700848356314 := by decide
theorem cert_e302801845210 : check e302801845210 [[.under],[.under]] .three = true := by decide
def e302801845614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302801845614 : Closed e302801845614 ∧ code e302801845614 = 4700848356718 := by decide
theorem cert_e302801845614 : check e302801845614 [[.under],[.under]] .three = true := by decide
def e302801845622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302801845622 : Closed e302801845622 ∧ code e302801845622 = 4700848356726 := by decide
theorem cert_e302801845622 : check e302801845622 [[.under],[.under]] .three = true := by decide
def e302801845678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302801845678 : Closed e302801845678 ∧ code e302801845678 = 4700848356782 := by decide
theorem cert_e302801845678 : check e302801845678 [[.under],[.under]] .three = true := by decide
def e302801845690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302801845690 : Closed e302801845690 ∧ code e302801845690 = 4700848356794 := by decide
theorem cert_e302801845690 : check e302801845690 [[.under],[.under]] .three = true := by decide
def e302801845718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302801845718 : Closed e302801845718 ∧ code e302801845718 = 4700848356822 := by decide
theorem cert_e302801845718 : check e302801845718 [[.under],[.under]] .three = true := by decide
def e302801845722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302801845722 : Closed e302801845722 ∧ code e302801845722 = 4700848356826 := by decide
theorem cert_e302801845722 : check e302801845722 [[.under],[.under]] .three = true := by decide
def e302801853918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e302801853918 : Closed e302801853918 ∧ code e302801853918 = 4700848365022 := by decide
theorem cert_e302801853918 : check e302801853918 [[.under],[.under]] .three = true := by decide
def e302801853934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e302801853934 : Closed e302801853934 ∧ code e302801853934 = 4700848365038 := by decide
theorem cert_e302801853934 : check e302801853934 [[.under],[.under]] .three = true := by decide
def e302801854174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e302801854174 : Closed e302801854174 ∧ code e302801854174 = 4700848365278 := by decide
theorem cert_e302801854174 : check e302801854174 [[.under],[.under]] .three = true := by decide
def e302801854198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e302801854198 : Closed e302801854198 ∧ code e302801854198 = 4700848365302 := by decide
theorem cert_e302801854198 : check e302801854198 [[.under],[.under]] .three = true := by decide
def e302801854318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e302801854318 : Closed e302801854318 ∧ code e302801854318 = 4700848365422 := by decide
theorem cert_e302801854318 : check e302801854318 [[.under],[.under]] .three = true := by decide
def e302801854326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e302801854326 : Closed e302801854326 ∧ code e302801854326 = 4700848365430 := by decide
theorem cert_e302801854326 : check e302801854326 [[.under],[.under]] .three = true := by decide
def e302801859550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801859550 : Closed e302801859550 ∧ code e302801859550 = 4700848370654 := by decide
theorem cert_e302801859550 : check e302801859550 [[.under],[.under]] .three = true := by decide
def e302801859566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801859566 : Closed e302801859566 ∧ code e302801859566 = 4700848370670 := by decide
theorem cert_e302801859566 : check e302801859566 [[.under],[.under]] .three = true := by decide
def e302801861086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801861086 : Closed e302801861086 ∧ code e302801861086 = 4700848372190 := by decide
theorem cert_e302801861086 : check e302801861086 [[.under],[.under]] .three = true := by decide
def e302801861110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801861110 : Closed e302801861110 ∧ code e302801861110 = 4700848372214 := by decide
theorem cert_e302801861110 : check e302801861110 [[.under],[.under]] .three = true := by decide
def e302801861870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801861870 : Closed e302801861870 ∧ code e302801861870 = 4700848372974 := by decide
theorem cert_e302801861870 : check e302801861870 [[.under],[.under]] .three = true := by decide
def e302801861878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801861878 : Closed e302801861878 ∧ code e302801861878 = 4700848372982 := by decide
theorem cert_e302801861878 : check e302801861878 [[.under],[.under]] .three = true := by decide
def e302801866206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e302801866206 : Closed e302801866206 ∧ code e302801866206 = 4700848377310 := by decide
theorem cert_e302801866206 : check e302801866206 [[.under],[.under]] .three = true := by decide
def e302801866222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e302801866222 : Closed e302801866222 ∧ code e302801866222 = 4700848377326 := by decide
theorem cert_e302801866222 : check e302801866222 [[.under],[.under]] .three = true := by decide
def e302801866590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e302801866590 : Closed e302801866590 ∧ code e302801866590 = 4700848377694 := by decide
theorem cert_e302801866590 : check e302801866590 [[.under],[.under]] .three = true := by decide
def e302801866618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e302801866618 : Closed e302801866618 ∧ code e302801866618 = 4700848377722 := by decide
theorem cert_e302801866618 : check e302801866618 [[.under],[.under]] .three = true := by decide
def e302801866670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e302801866670 : Closed e302801866670 ∧ code e302801866670 = 4700848377774 := by decide
theorem cert_e302801866670 : check e302801866670 [[.under],[.under]] .three = true := by decide
def e302801866682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e302801866682 : Closed e302801866682 ∧ code e302801866682 = 4700848377786 := by decide
theorem cert_e302801866682 : check e302801866682 [[.under],[.under]] .three = true := by decide
def e302801867742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801867742 : Closed e302801867742 ∧ code e302801867742 = 4700848378846 := by decide
theorem cert_e302801867742 : check e302801867742 [[.under],[.under]] .three = true := by decide
def e302801867758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801867758 : Closed e302801867758 ∧ code e302801867758 = 4700848378862 := by decide
theorem cert_e302801867758 : check e302801867758 [[.under],[.under]] .three = true := by decide
def e302801870046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801870046 : Closed e302801870046 ∧ code e302801870046 = 4700848381150 := by decide
theorem cert_e302801870046 : check e302801870046 [[.under],[.under]] .three = true := by decide
def e302801870074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801870074 : Closed e302801870074 ∧ code e302801870074 = 4700848381178 := by decide
theorem cert_e302801870074 : check e302801870074 [[.under],[.under]] .three = true := by decide
def e302801870446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801870446 : Closed e302801870446 ∧ code e302801870446 = 4700848381550 := by decide
theorem cert_e302801870446 : check e302801870446 [[.under],[.under]] .three = true := by decide
def e302801870458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801870458 : Closed e302801870458 ∧ code e302801870458 = 4700848381562 := by decide
theorem cert_e302801870458 : check e302801870458 [[.under],[.under]] .three = true := by decide
def e302801872606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302801872606 : Closed e302801872606 ∧ code e302801872606 = 4700848383710 := by decide
theorem cert_e302801872606 : check e302801872606 [[.under],[.under]] .three = true := by decide
def e302801872630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302801872630 : Closed e302801872630 ∧ code e302801872630 = 4700848383734 := by decide
theorem cert_e302801872630 : check e302801872630 [[.under],[.under]] .three = true := by decide
def e302801872734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302801872734 : Closed e302801872734 ∧ code e302801872734 = 4700848383838 := by decide
theorem cert_e302801872734 : check e302801872734 [[.under],[.under]] .three = true := by decide
def e302801872762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302801872762 : Closed e302801872762 ∧ code e302801872762 = 4700848383866 := by decide
theorem cert_e302801872762 : check e302801872762 [[.under],[.under]] .three = true := by decide
def e302801872854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302801872854 : Closed e302801872854 ∧ code e302801872854 = 4700848383958 := by decide
theorem cert_e302801872854 : check e302801872854 [[.under],[.under]] .three = true := by decide
def e302801872858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302801872858 : Closed e302801872858 ∧ code e302801872858 = 4700848383962 := by decide
theorem cert_e302801872858 : check e302801872858 [[.under],[.under]] .three = true := by decide
def e302801873374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801873374 : Closed e302801873374 ∧ code e302801873374 = 4700848384478 := by decide
theorem cert_e302801873374 : check e302801873374 [[.under],[.under]] .three = true := by decide
def e302801873398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801873398 : Closed e302801873398 ∧ code e302801873398 = 4700848384502 := by decide
theorem cert_e302801873398 : check e302801873398 [[.under],[.under]] .three = true := by decide
def e302801874142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801874142 : Closed e302801874142 ∧ code e302801874142 = 4700848385246 := by decide
theorem cert_e302801874142 : check e302801874142 [[.under],[.under]] .three = true := by decide
def e302801874170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801874170 : Closed e302801874170 ∧ code e302801874170 = 4700848385274 := by decide
theorem cert_e302801874170 : check e302801874170 [[.under],[.under]] .three = true := by decide
def e302801874742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801874742 : Closed e302801874742 ∧ code e302801874742 = 4700848385846 := by decide
theorem cert_e302801874742 : check e302801874742 [[.under],[.under]] .three = true := by decide
def e302801874746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801874746 : Closed e302801874746 ∧ code e302801874746 = 4700848385850 := by decide
theorem cert_e302801874746 : check e302801874746 [[.under],[.under]] .three = true := by decide
def e302801875822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302801875822 : Closed e302801875822 ∧ code e302801875822 = 4700848386926 := by decide
theorem cert_e302801875822 : check e302801875822 [[.under],[.under]] .three = true := by decide
def e302801875830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302801875830 : Closed e302801875830 ∧ code e302801875830 = 4700848386934 := by decide
theorem cert_e302801875830 : check e302801875830 [[.under],[.under]] .three = true := by decide
def e302801875886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302801875886 : Closed e302801875886 ∧ code e302801875886 = 4700848386990 := by decide
theorem cert_e302801875886 : check e302801875886 [[.under],[.under]] .three = true := by decide
def e302801875898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302801875898 : Closed e302801875898 ∧ code e302801875898 = 4700848387002 := by decide
theorem cert_e302801875898 : check e302801875898 [[.under],[.under]] .three = true := by decide
def e302801875926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302801875926 : Closed e302801875926 ∧ code e302801875926 = 4700848387030 := by decide
theorem cert_e302801875926 : check e302801875926 [[.under],[.under]] .three = true := by decide
def e302801875930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302801875930 : Closed e302801875930 ∧ code e302801875930 = 4700848387034 := by decide
theorem cert_e302801875930 : check e302801875930 [[.under],[.under]] .three = true := by decide
def e302801876206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801876206 : Closed e302801876206 ∧ code e302801876206 = 4700848387310 := by decide
theorem cert_e302801876206 : check e302801876206 [[.under],[.under]] .three = true := by decide
def e302801876214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801876214 : Closed e302801876214 ∧ code e302801876214 = 4700848387318 := by decide
theorem cert_e302801876214 : check e302801876214 [[.under],[.under]] .three = true := by decide
def e302801876590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801876590 : Closed e302801876590 ∧ code e302801876590 = 4700848387694 := by decide
theorem cert_e302801876590 : check e302801876590 [[.under],[.under]] .three = true := by decide
def e302801876602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801876602 : Closed e302801876602 ∧ code e302801876602 = 4700848387706 := by decide
theorem cert_e302801876602 : check e302801876602 [[.under],[.under]] .three = true := by decide
def e302801876790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801876790 : Closed e302801876790 ∧ code e302801876790 = 4700848387894 := by decide
theorem cert_e302801876790 : check e302801876790 [[.under],[.under]] .three = true := by decide
def e302801876794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801876794 : Closed e302801876794 ∧ code e302801876794 = 4700848387898 := by decide
theorem cert_e302801876794 : check e302801876794 [[.under],[.under]] .three = true := by decide
def e302801903070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302801903070 : Closed e302801903070 ∧ code e302801903070 = 4700848414174 := by decide
theorem cert_e302801903070 : check e302801903070 [[.under],[.under]] .three = true := by decide
def e302801903086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302801903086 : Closed e302801903086 ∧ code e302801903086 = 4700848414190 := by decide
theorem cert_e302801903086 : check e302801903086 [[.under],[.under]] .three = true := by decide
def e302801903326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302801903326 : Closed e302801903326 ∧ code e302801903326 = 4700848414430 := by decide
theorem cert_e302801903326 : check e302801903326 [[.under],[.under]] .three = true := by decide
def e302801903350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302801903350 : Closed e302801903350 ∧ code e302801903350 = 4700848414454 := by decide
theorem cert_e302801903350 : check e302801903350 [[.under],[.under]] .three = true := by decide
def e302801903470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302801903470 : Closed e302801903470 ∧ code e302801903470 = 4700848414574 := by decide
theorem cert_e302801903470 : check e302801903470 [[.under],[.under]] .three = true := by decide
def e302801903478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302801903478 : Closed e302801903478 ∧ code e302801903478 = 4700848414582 := by decide
theorem cert_e302801903478 : check e302801903478 [[.under],[.under]] .three = true := by decide
def e302801908702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302801908702 : Closed e302801908702 ∧ code e302801908702 = 4700848419806 := by decide
theorem cert_e302801908702 : check e302801908702 [[.under],[.under]] .three = true := by decide
def e302801908718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302801908718 : Closed e302801908718 ∧ code e302801908718 = 4700848419822 := by decide
theorem cert_e302801908718 : check e302801908718 [[.under],[.under]] .three = true := by decide
def e302801910238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302801910238 : Closed e302801910238 ∧ code e302801910238 = 4700848421342 := by decide
theorem cert_e302801910238 : check e302801910238 [[.under],[.under]] .three = true := by decide
def e302801910262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302801910262 : Closed e302801910262 ∧ code e302801910262 = 4700848421366 := by decide
theorem cert_e302801910262 : check e302801910262 [[.under],[.under]] .three = true := by decide
def e302801911022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801911022 : Closed e302801911022 ∧ code e302801911022 = 4700848422126 := by decide
theorem cert_e302801911022 : check e302801911022 [[.under],[.under]] .three = true := by decide
def e302801911030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801911030 : Closed e302801911030 ∧ code e302801911030 = 4700848422134 := by decide
theorem cert_e302801911030 : check e302801911030 [[.under],[.under]] .three = true := by decide
def e302801956318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302801956318 : Closed e302801956318 ∧ code e302801956318 = 4700848467422 := by decide
theorem cert_e302801956318 : check e302801956318 [[.under],[.under]] .three = true := by decide
def e302801956334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302801956334 : Closed e302801956334 ∧ code e302801956334 = 4700848467438 := by decide
theorem cert_e302801956334 : check e302801956334 [[.under],[.under]] .three = true := by decide
def e302801956702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302801956702 : Closed e302801956702 ∧ code e302801956702 = 4700848467806 := by decide
theorem cert_e302801956702 : check e302801956702 [[.under],[.under]] .three = true := by decide
def e302801956730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302801956730 : Closed e302801956730 ∧ code e302801956730 = 4700848467834 := by decide
theorem cert_e302801956730 : check e302801956730 [[.under],[.under]] .three = true := by decide
def e302801956782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302801956782 : Closed e302801956782 ∧ code e302801956782 = 4700848467886 := by decide
theorem cert_e302801956782 : check e302801956782 [[.under],[.under]] .three = true := by decide
def e302801956794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302801956794 : Closed e302801956794 ∧ code e302801956794 = 4700848467898 := by decide
theorem cert_e302801956794 : check e302801956794 [[.under],[.under]] .three = true := by decide
def e302801957854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302801957854 : Closed e302801957854 ∧ code e302801957854 = 4700848468958 := by decide
theorem cert_e302801957854 : check e302801957854 [[.under],[.under]] .three = true := by decide
def e302801957870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302801957870 : Closed e302801957870 ∧ code e302801957870 = 4700848468974 := by decide
theorem cert_e302801957870 : check e302801957870 [[.under],[.under]] .three = true := by decide
def e302801960158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801960158 : Closed e302801960158 ∧ code e302801960158 = 4700848471262 := by decide
theorem cert_e302801960158 : check e302801960158 [[.under],[.under]] .three = true := by decide
def e302801960186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801960186 : Closed e302801960186 ∧ code e302801960186 = 4700848471290 := by decide
theorem cert_e302801960186 : check e302801960186 [[.under],[.under]] .three = true := by decide
def e302801960558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801960558 : Closed e302801960558 ∧ code e302801960558 = 4700848471662 := by decide
theorem cert_e302801960558 : check e302801960558 [[.under],[.under]] .three = true := by decide
def e302801960570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801960570 : Closed e302801960570 ∧ code e302801960570 = 4700848471674 := by decide
theorem cert_e302801960570 : check e302801960570 [[.under],[.under]] .three = true := by decide
def e302801983198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302801983198 : Closed e302801983198 ∧ code e302801983198 = 4700848494302 := by decide
theorem cert_e302801983198 : check e302801983198 [[.under],[.under]] .three = true := by decide
def e302801983222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302801983222 : Closed e302801983222 ∧ code e302801983222 = 4700848494326 := by decide
theorem cert_e302801983222 : check e302801983222 [[.under],[.under]] .three = true := by decide
def e302801983326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302801983326 : Closed e302801983326 ∧ code e302801983326 = 4700848494430 := by decide
theorem cert_e302801983326 : check e302801983326 [[.under],[.under]] .three = true := by decide
def e302801983354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302801983354 : Closed e302801983354 ∧ code e302801983354 = 4700848494458 := by decide
theorem cert_e302801983354 : check e302801983354 [[.under],[.under]] .three = true := by decide
def e302801983446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302801983446 : Closed e302801983446 ∧ code e302801983446 = 4700848494550 := by decide
theorem cert_e302801983446 : check e302801983446 [[.under],[.under]] .three = true := by decide
def e302801983450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302801983450 : Closed e302801983450 ∧ code e302801983450 = 4700848494554 := by decide
theorem cert_e302801983450 : check e302801983450 [[.under],[.under]] .three = true := by decide
def e302801983966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302801983966 : Closed e302801983966 ∧ code e302801983966 = 4700848495070 := by decide
theorem cert_e302801983966 : check e302801983966 [[.under],[.under]] .three = true := by decide
def e302801983990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302801983990 : Closed e302801983990 ∧ code e302801983990 = 4700848495094 := by decide
theorem cert_e302801983990 : check e302801983990 [[.under],[.under]] .three = true := by decide
def e302801984734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801984734 : Closed e302801984734 ∧ code e302801984734 = 4700848495838 := by decide
theorem cert_e302801984734 : check e302801984734 [[.under],[.under]] .three = true := by decide
def e302801984762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801984762 : Closed e302801984762 ∧ code e302801984762 = 4700848495866 := by decide
theorem cert_e302801984762 : check e302801984762 [[.under],[.under]] .three = true := by decide
def e302801985334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801985334 : Closed e302801985334 ∧ code e302801985334 = 4700848496438 := by decide
theorem cert_e302801985334 : check e302801985334 [[.under],[.under]] .three = true := by decide
def e302801985338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801985338 : Closed e302801985338 ∧ code e302801985338 = 4700848496442 := by decide
theorem cert_e302801985338 : check e302801985338 [[.under],[.under]] .three = true := by decide
def e302801996654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302801996654 : Closed e302801996654 ∧ code e302801996654 = 4700848507758 := by decide
theorem cert_e302801996654 : check e302801996654 [[.under],[.under]] .three = true := by decide
def e302801996662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302801996662 : Closed e302801996662 ∧ code e302801996662 = 4700848507766 := by decide
theorem cert_e302801996662 : check e302801996662 [[.under],[.under]] .three = true := by decide
def e302801996718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302801996718 : Closed e302801996718 ∧ code e302801996718 = 4700848507822 := by decide
theorem cert_e302801996718 : check e302801996718 [[.under],[.under]] .three = true := by decide
def e302801996730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302801996730 : Closed e302801996730 ∧ code e302801996730 = 4700848507834 := by decide
theorem cert_e302801996730 : check e302801996730 [[.under],[.under]] .three = true := by decide
def e302801996758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302801996758 : Closed e302801996758 ∧ code e302801996758 = 4700848507862 := by decide
theorem cert_e302801996758 : check e302801996758 [[.under],[.under]] .three = true := by decide
def e302801996762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302801996762 : Closed e302801996762 ∧ code e302801996762 = 4700848507866 := by decide
theorem cert_e302801996762 : check e302801996762 [[.under],[.under]] .three = true := by decide
def e302801997038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801997038 : Closed e302801997038 ∧ code e302801997038 = 4700848508142 := by decide
theorem cert_e302801997038 : check e302801997038 [[.under],[.under]] .three = true := by decide
def e302801997046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801997046 : Closed e302801997046 ∧ code e302801997046 = 4700848508150 := by decide
theorem cert_e302801997046 : check e302801997046 [[.under],[.under]] .three = true := by decide
def e302801997422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801997422 : Closed e302801997422 ∧ code e302801997422 = 4700848508526 := by decide
theorem cert_e302801997422 : check e302801997422 [[.under],[.under]] .three = true := by decide
def e302801997434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801997434 : Closed e302801997434 ∧ code e302801997434 = 4700848508538 := by decide
theorem cert_e302801997434 : check e302801997434 [[.under],[.under]] .three = true := by decide
def e302801997622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801997622 : Closed e302801997622 ∧ code e302801997622 = 4700848508726 := by decide
theorem cert_e302801997622 : check e302801997622 [[.under],[.under]] .three = true := by decide
def e302801997626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801997626 : Closed e302801997626 ∧ code e302801997626 = 4700848508730 := by decide
theorem cert_e302801997626 : check e302801997626 [[.under],[.under]] .three = true := by decide
def e302802712030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e302802712030 : Closed e302802712030 ∧ code e302802712030 = 4700849223134 := by decide
theorem cert_e302802712030 : check e302802712030 [[.under],[.under]] .three = true := by decide
def e302802712046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e302802712046 : Closed e302802712046 ∧ code e302802712046 = 4700849223150 := by decide
theorem cert_e302802712046 : check e302802712046 [[.under],[.under]] .three = true := by decide
def e302802712414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e302802712414 : Closed e302802712414 ∧ code e302802712414 = 4700849223518 := by decide
theorem cert_e302802712414 : check e302802712414 [[.under],[.under]] .three = true := by decide
def e302802712442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e302802712442 : Closed e302802712442 ∧ code e302802712442 = 4700849223546 := by decide
theorem cert_e302802712442 : check e302802712442 [[.under],[.under]] .three = true := by decide
def e302802712494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e302802712494 : Closed e302802712494 ∧ code e302802712494 = 4700849223598 := by decide
theorem cert_e302802712494 : check e302802712494 [[.under],[.under]] .three = true := by decide
def e302802712506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e302802712506 : Closed e302802712506 ∧ code e302802712506 = 4700849223610 := by decide
theorem cert_e302802712506 : check e302802712506 [[.under],[.under]] .three = true := by decide
def e302802713950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302802713950 : Closed e302802713950 ∧ code e302802713950 = 4700849225054 := by decide
theorem cert_e302802713950 : check e302802713950 [[.under],[.under]] .three = true := by decide
def e302802713978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302802713978 : Closed e302802713978 ∧ code e302802713978 = 4700849225082 := by decide
theorem cert_e302802713978 : check e302802713978 [[.under],[.under]] .three = true := by decide
def e302802714090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302802714090 : Closed e302802714090 ∧ code e302802714090 = 4700849225194 := by decide
theorem cert_e302802714090 : check e302802714090 [[.under],[.under]] .three = true := by decide
def e302802714286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302802714286 : Closed e302802714286 ∧ code e302802714286 = 4700849225390 := by decide
theorem cert_e302802714286 : check e302802714286 [[.under],[.under]] .three = true := by decide
def e302802714298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302802714298 : Closed e302802714298 ∧ code e302802714298 = 4700849225402 := by decide
theorem cert_e302802714298 : check e302802714298 [[.under],[.under]] .three = true := by decide
def e302802714346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302802714346 : Closed e302802714346 ∧ code e302802714346 = 4700849225450 := by decide
theorem cert_e302802714346 : check e302802714346 [[.under],[.under]] .three = true := by decide
def e302802718174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e302802718174 : Closed e302802718174 ∧ code e302802718174 = 4700849229278 := by decide
theorem cert_e302802718174 : check e302802718174 [[.under],[.under]] .three = true := by decide
def e302802718190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e302802718190 : Closed e302802718190 ∧ code e302802718190 = 4700849229294 := by decide
theorem cert_e302802718190 : check e302802718190 [[.under],[.under]] .three = true := by decide
def e302802718558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e302802718558 : Closed e302802718558 ∧ code e302802718558 = 4700849229662 := by decide
theorem cert_e302802718558 : check e302802718558 [[.under],[.under]] .three = true := by decide
def e302802718586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e302802718586 : Closed e302802718586 ∧ code e302802718586 = 4700849229690 := by decide
theorem cert_e302802718586 : check e302802718586 [[.under],[.under]] .three = true := by decide
def e302802718638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e302802718638 : Closed e302802718638 ∧ code e302802718638 = 4700849229742 := by decide
theorem cert_e302802718638 : check e302802718638 [[.under],[.under]] .three = true := by decide
def e302802718650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e302802718650 : Closed e302802718650 ∧ code e302802718650 = 4700849229754 := by decide
theorem cert_e302802718650 : check e302802718650 [[.under],[.under]] .three = true := by decide
def e302802719710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302802719710 : Closed e302802719710 ∧ code e302802719710 = 4700849230814 := by decide
theorem cert_e302802719710 : check e302802719710 [[.under],[.under]] .three = true := by decide
def e302802719726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302802719726 : Closed e302802719726 ∧ code e302802719726 = 4700849230830 := by decide
theorem cert_e302802719726 : check e302802719726 [[.under],[.under]] .three = true := by decide
def e302802722014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302802722014 : Closed e302802722014 ∧ code e302802722014 = 4700849233118 := by decide
theorem cert_e302802722014 : check e302802722014 [[.under],[.under]] .three = true := by decide
def e302802722042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302802722042 : Closed e302802722042 ∧ code e302802722042 = 4700849233146 := by decide
theorem cert_e302802722042 : check e302802722042 [[.under],[.under]] .three = true := by decide
def e302802722414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802722414 : Closed e302802722414 ∧ code e302802722414 = 4700849233518 := by decide
theorem cert_e302802722414 : check e302802722414 [[.under],[.under]] .three = true := by decide
def e302802722426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802722426 : Closed e302802722426 ∧ code e302802722426 = 4700849233530 := by decide
theorem cert_e302802722426 : check e302802722426 [[.under],[.under]] .three = true := by decide
def e302802727774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302802727774 : Closed e302802727774 ∧ code e302802727774 = 4700849238878 := by decide
theorem cert_e302802727774 : check e302802727774 [[.under],[.under]] .three = true := by decide
def e302802727802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302802727802 : Closed e302802727802 ∧ code e302802727802 = 4700849238906 := by decide
theorem cert_e302802727802 : check e302802727802 [[.under],[.under]] .three = true := by decide
def e302802727914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302802727914 : Closed e302802727914 ∧ code e302802727914 = 4700849239018 := by decide
theorem cert_e302802727914 : check e302802727914 [[.under],[.under]] .three = true := by decide
def e302802728158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302802728158 : Closed e302802728158 ∧ code e302802728158 = 4700849239262 := by decide
theorem cert_e302802728158 : check e302802728158 [[.under],[.under]] .three = true := by decide
def e302802728186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302802728186 : Closed e302802728186 ∧ code e302802728186 = 4700849239290 := by decide
theorem cert_e302802728186 : check e302802728186 [[.under],[.under]] .three = true := by decide
def e302802728858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302802728858 : Closed e302802728858 ∧ code e302802728858 = 4700849239962 := by decide
theorem cert_e302802728858 : check e302802728858 [[.under],[.under]] .three = true := by decide
end Blc.Floor42
