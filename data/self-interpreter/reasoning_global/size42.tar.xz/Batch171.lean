import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188311962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188311962 : Closed e1211188311962 ∧ code e1211188311962 = 5609234823066 := by decide
theorem cert_e1211188311962 : check e1211188311962 [[],[]] .three = true := by decide
def e1211188312122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211188312122 : Closed e1211188312122 ∧ code e1211188312122 = 5609234823226 := by decide
theorem cert_e1211188312122 : check e1211188312122 [[],[]] .three = true := by decide
def e1211188312170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e1211188312170 : Closed e1211188312170 ∧ code e1211188312170 = 5609234823274 := by decide
theorem cert_e1211188312170 : check e1211188312170 [[],[]] .three = true := by decide
def e1211188312218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188312218 : Closed e1211188312218 ∧ code e1211188312218 = 5609234823322 := by decide
theorem cert_e1211188312218 : check e1211188312218 [[],[]] .three = true := by decide
def e1211188312262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211188312262 : Closed e1211188312262 ∧ code e1211188312262 = 5609234823366 := by decide
theorem cert_e1211188312262 : check e1211188312262 [[],[]] .three = true := by decide
def e1211188312286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211188312286 : Closed e1211188312286 ∧ code e1211188312286 = 5609234823390 := by decide
theorem cert_e1211188312286 : check e1211188312286 [[],[]] .three = true := by decide
def e1211188312302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211188312302 : Closed e1211188312302 ∧ code e1211188312302 = 5609234823406 := by decide
theorem cert_e1211188312302 : check e1211188312302 [[],[]] .three = true := by decide
def e1211188312310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211188312310 : Closed e1211188312310 ∧ code e1211188312310 = 5609234823414 := by decide
theorem cert_e1211188312310 : check e1211188312310 [[],[]] .three = true := by decide
def e1211188312314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211188312314 : Closed e1211188312314 ∧ code e1211188312314 = 5609234823418 := by decide
theorem cert_e1211188312314 : check e1211188312314 [[],[]] .three = true := by decide
def e1211188312458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188312458 : Closed e1211188312458 ∧ code e1211188312458 = 5609234823562 := by decide
theorem cert_e1211188312458 : check e1211188312458 [[],[]] .three = true := by decide
def e1211188312482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188312482 : Closed e1211188312482 ∧ code e1211188312482 = 5609234823586 := by decide
theorem cert_e1211188312482 : check e1211188312482 [[],[]] .three = true := by decide
def e1211188312494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211188312494 : Closed e1211188312494 ∧ code e1211188312494 = 5609234823598 := by decide
theorem cert_e1211188312494 : check e1211188312494 [[],[]] .three = true := by decide
def e1211188312502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211188312502 : Closed e1211188312502 ∧ code e1211188312502 = 5609234823606 := by decide
theorem cert_e1211188312502 : check e1211188312502 [[],[]] .three = true := by decide
def e1211188312506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211188312506 : Closed e1211188312506 ∧ code e1211188312506 = 5609234823610 := by decide
theorem cert_e1211188312506 : check e1211188312506 [[],[]] .three = true := by decide
def e1211188312534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211188312534 : Closed e1211188312534 ∧ code e1211188312534 = 5609234823638 := by decide
theorem cert_e1211188312534 : check e1211188312534 [[],[]] .three = true := by decide
def e1211188312538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211188312538 : Closed e1211188312538 ∧ code e1211188312538 = 5609234823642 := by decide
theorem cert_e1211188312538 : check e1211188312538 [[],[]] .three = true := by decide
def e1211188312554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211188312554 : Closed e1211188312554 ∧ code e1211188312554 = 5609234823658 := by decide
theorem cert_e1211188312554 : check e1211188312554 [[],[]] .three = true := by decide
def e1211188312590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188312590 : Closed e1211188312590 ∧ code e1211188312590 = 5609234823694 := by decide
theorem cert_e1211188312590 : check e1211188312590 [[],[]] .three = true := by decide
def e1211188312602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188312602 : Closed e1211188312602 ∧ code e1211188312602 = 5609234823706 := by decide
theorem cert_e1211188312602 : check e1211188312602 [[],[]] .three = true := by decide
def e1211188312638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211188312638 : Closed e1211188312638 ∧ code e1211188312638 = 5609234823742 := by decide
theorem cert_e1211188312638 : check e1211188312638 [[],[]] .three = true := by decide
def e1211188312674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188312674 : Closed e1211188312674 ∧ code e1211188312674 = 5609234823778 := by decide
theorem cert_e1211188312674 : check e1211188312674 [[],[]] .three = true := by decide
def e1211188312686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188312686 : Closed e1211188312686 ∧ code e1211188312686 = 5609234823790 := by decide
theorem cert_e1211188312686 : check e1211188312686 [[],[]] .three = true := by decide
def e1211188312694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188312694 : Closed e1211188312694 ∧ code e1211188312694 = 5609234823798 := by decide
theorem cert_e1211188312694 : check e1211188312694 [[],[]] .three = true := by decide
def e1211188312698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188312698 : Closed e1211188312698 ∧ code e1211188312698 = 5609234823802 := by decide
theorem cert_e1211188312698 : check e1211188312698 [[],[]] .three = true := by decide
def e1211188312862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211188312862 : Closed e1211188312862 ∧ code e1211188312862 = 5609234823966 := by decide
theorem cert_e1211188312862 : check e1211188312862 [[],[]] .three = true := by decide
def e1211188312886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188312886 : Closed e1211188312886 ∧ code e1211188312886 = 5609234823990 := by decide
theorem cert_e1211188312886 : check e1211188312886 [[],[]] .three = true := by decide
def e1211188312890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188312890 : Closed e1211188312890 ∧ code e1211188312890 = 5609234823994 := by decide
theorem cert_e1211188312890 : check e1211188312890 [[],[]] .three = true := by decide
def e1211188312974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211188312974 : Closed e1211188312974 ∧ code e1211188312974 = 5609234824078 := by decide
theorem cert_e1211188312974 : check e1211188312974 [[],[]] .three = true := by decide
def e1211188312986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188312986 : Closed e1211188312986 ∧ code e1211188312986 = 5609234824090 := by decide
theorem cert_e1211188312986 : check e1211188312986 [[],[]] .three = true := by decide
def e1211188313030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211188313030 : Closed e1211188313030 ∧ code e1211188313030 = 5609234824134 := by decide
theorem cert_e1211188313030 : check e1211188313030 [[],[]] .three = true := by decide
def e1211188317022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211188317022 : Closed e1211188317022 ∧ code e1211188317022 = 5609234828126 := by decide
theorem cert_e1211188317022 : check e1211188317022 [[],[]] .smaller = true := by decide
def e1211188317038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211188317038 : Closed e1211188317038 ∧ code e1211188317038 = 5609234828142 := by decide
theorem cert_e1211188317038 : check e1211188317038 [[],[]] .smaller = true := by decide
def e1211188317046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211188317046 : Closed e1211188317046 ∧ code e1211188317046 = 5609234828150 := by decide
theorem cert_e1211188317046 : check e1211188317046 [[],[]] .smaller = true := by decide
def e1211188317050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211188317050 : Closed e1211188317050 ∧ code e1211188317050 = 5609234828154 := by decide
theorem cert_e1211188317050 : check e1211188317050 [[],[]] .smaller = true := by decide
def e1211188317102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211188317102 : Closed e1211188317102 ∧ code e1211188317102 = 5609234828206 := by decide
theorem cert_e1211188317102 : check e1211188317102 [[],[]] .smaller = true := by decide
def e1211188317114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211188317114 : Closed e1211188317114 ∧ code e1211188317114 = 5609234828218 := by decide
theorem cert_e1211188317114 : check e1211188317114 [[],[]] .smaller = true := by decide
def e1211188317142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211188317142 : Closed e1211188317142 ∧ code e1211188317142 = 5609234828246 := by decide
theorem cert_e1211188317142 : check e1211188317142 [[],[]] .smaller = true := by decide
def e1211188317146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211188317146 : Closed e1211188317146 ∧ code e1211188317146 = 5609234828250 := by decide
theorem cert_e1211188317146 : check e1211188317146 [[],[]] .smaller = true := by decide
def e1211188317162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211188317162 : Closed e1211188317162 ∧ code e1211188317162 = 5609234828266 := by decide
theorem cert_e1211188317162 : check e1211188317162 [[],[]] .smaller = true := by decide
def e1211188317406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211188317406 : Closed e1211188317406 ∧ code e1211188317406 = 5609234828510 := by decide
theorem cert_e1211188317406 : check e1211188317406 [[],[]] .smaller = true := by decide
def e1211188317422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211188317422 : Closed e1211188317422 ∧ code e1211188317422 = 5609234828526 := by decide
theorem cert_e1211188317422 : check e1211188317422 [[],[]] .smaller = true := by decide
def e1211188317430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211188317430 : Closed e1211188317430 ∧ code e1211188317430 = 5609234828534 := by decide
theorem cert_e1211188317430 : check e1211188317430 [[],[]] .smaller = true := by decide
def e1211188317434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211188317434 : Closed e1211188317434 ∧ code e1211188317434 = 5609234828538 := by decide
theorem cert_e1211188317434 : check e1211188317434 [[],[]] .smaller = true := by decide
def e1211188317758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211188317758 : Closed e1211188317758 ∧ code e1211188317758 = 5609234828862 := by decide
theorem cert_e1211188317758 : check e1211188317758 [[],[]] .smaller = true := by decide
def e1211188317806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188317806 : Closed e1211188317806 ∧ code e1211188317806 = 5609234828910 := by decide
theorem cert_e1211188317806 : check e1211188317806 [[],[]] .smaller = true := by decide
def e1211188317818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188317818 : Closed e1211188317818 ∧ code e1211188317818 = 5609234828922 := by decide
theorem cert_e1211188317818 : check e1211188317818 [[],[]] .smaller = true := by decide
def e1211188318006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188318006 : Closed e1211188318006 ∧ code e1211188318006 = 5609234829110 := by decide
theorem cert_e1211188318006 : check e1211188318006 [[],[]] .smaller = true := by decide
def e1211188318010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188318010 : Closed e1211188318010 ∧ code e1211188318010 = 5609234829114 := by decide
theorem cert_e1211188318010 : check e1211188318010 [[],[]] .smaller = true := by decide
def e1211188318094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211188318094 : Closed e1211188318094 ∧ code e1211188318094 = 5609234829198 := by decide
theorem cert_e1211188318094 : check e1211188318094 [[],[]] .smaller = true := by decide
def e1211188318106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188318106 : Closed e1211188318106 ∧ code e1211188318106 = 5609234829210 := by decide
theorem cert_e1211188318106 : check e1211188318106 [[],[]] .smaller = true := by decide
def e1211188325470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211188325470 : Closed e1211188325470 ∧ code e1211188325470 = 5609234836574 := by decide
theorem cert_e1211188325470 : check e1211188325470 [[],[]] .three = true := by decide
def e1211188325486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211188325486 : Closed e1211188325486 ∧ code e1211188325486 = 5609234836590 := by decide
theorem cert_e1211188325486 : check e1211188325486 [[],[]] .smaller = true := by decide
def e1211188325498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211188325498 : Closed e1211188325498 ∧ code e1211188325498 = 5609234836602 := by decide
theorem cert_e1211188325498 : check e1211188325498 [[],[]] .smaller = true := by decide
def e1211188325662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211188325662 : Closed e1211188325662 ∧ code e1211188325662 = 5609234836766 := by decide
theorem cert_e1211188325662 : check e1211188325662 [[],[]] .smaller = true := by decide
def e1211188325830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211188325830 : Closed e1211188325830 ∧ code e1211188325830 = 5609234836934 := by decide
theorem cert_e1211188325830 : check e1211188325830 [[],[]] .smaller = true := by decide
def e1211188325854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211188325854 : Closed e1211188325854 ∧ code e1211188325854 = 5609234836958 := by decide
theorem cert_e1211188325854 : check e1211188325854 [[],[]] .three = true := by decide
def e1211188325858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211188325858 : Closed e1211188325858 ∧ code e1211188325858 = 5609234836962 := by decide
theorem cert_e1211188325858 : check e1211188325858 [[],[]] .three = true := by decide
def e1211188325870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211188325870 : Closed e1211188325870 ∧ code e1211188325870 = 5609234836974 := by decide
theorem cert_e1211188325870 : check e1211188325870 [[],[]] .three = true := by decide
def e1211188325934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e1211188325934 : Closed e1211188325934 ∧ code e1211188325934 = 5609234837038 := by decide
theorem cert_e1211188325934 : check e1211188325934 [[],[]] .smaller = true := by decide
def e1211188326110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211188326110 : Closed e1211188326110 ∧ code e1211188326110 = 5609234837214 := by decide
theorem cert_e1211188326110 : check e1211188326110 [[],[]] .three = true := by decide
def e1211188326114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e1211188326114 : Closed e1211188326114 ∧ code e1211188326114 = 5609234837218 := by decide
theorem cert_e1211188326114 : check e1211188326114 [[],[]] .smaller = true := by decide
def e1211188326126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211188326126 : Closed e1211188326126 ∧ code e1211188326126 = 5609234837230 := by decide
theorem cert_e1211188326126 : check e1211188326126 [[],[]] .smaller = true := by decide
def e1211188326134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211188326134 : Closed e1211188326134 ∧ code e1211188326134 = 5609234837238 := by decide
theorem cert_e1211188326134 : check e1211188326134 [[],[]] .three = true := by decide
def e1211188326166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211188326166 : Closed e1211188326166 ∧ code e1211188326166 = 5609234837270 := by decide
theorem cert_e1211188326166 : check e1211188326166 [[],[]] .smaller = true := by decide
def e1211188326170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211188326170 : Closed e1211188326170 ∧ code e1211188326170 = 5609234837274 := by decide
theorem cert_e1211188326170 : check e1211188326170 [[],[]] .smaller = true := by decide
def e1211188326214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211188326214 : Closed e1211188326214 ∧ code e1211188326214 = 5609234837318 := by decide
theorem cert_e1211188326214 : check e1211188326214 [[],[]] .smaller = true := by decide
def e1211188326238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211188326238 : Closed e1211188326238 ∧ code e1211188326238 = 5609234837342 := by decide
theorem cert_e1211188326238 : check e1211188326238 [[],[]] .three = true := by decide
def e1211188326242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211188326242 : Closed e1211188326242 ∧ code e1211188326242 = 5609234837346 := by decide
theorem cert_e1211188326242 : check e1211188326242 [[],[]] .smaller = true := by decide
def e1211188326254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211188326254 : Closed e1211188326254 ∧ code e1211188326254 = 5609234837358 := by decide
theorem cert_e1211188326254 : check e1211188326254 [[],[]] .smaller = true := by decide
def e1211188326262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211188326262 : Closed e1211188326262 ∧ code e1211188326262 = 5609234837366 := by decide
theorem cert_e1211188326262 : check e1211188326262 [[],[]] .smaller = true := by decide
def e1211188326266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211188326266 : Closed e1211188326266 ∧ code e1211188326266 = 5609234837370 := by decide
theorem cert_e1211188326266 : check e1211188326266 [[],[]] .three = true := by decide
def e1211188326282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188326282 : Closed e1211188326282 ∧ code e1211188326282 = 5609234837386 := by decide
theorem cert_e1211188326282 : check e1211188326282 [[],[]] .three = true := by decide
def e1211188326306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188326306 : Closed e1211188326306 ∧ code e1211188326306 = 5609234837410 := by decide
theorem cert_e1211188326306 : check e1211188326306 [[],[]] .three = true := by decide
def e1211188326318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211188326318 : Closed e1211188326318 ∧ code e1211188326318 = 5609234837422 := by decide
theorem cert_e1211188326318 : check e1211188326318 [[],[]] .three = true := by decide
def e1211188326326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211188326326 : Closed e1211188326326 ∧ code e1211188326326 = 5609234837430 := by decide
theorem cert_e1211188326326 : check e1211188326326 [[],[]] .three = true := by decide
def e1211188326330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211188326330 : Closed e1211188326330 ∧ code e1211188326330 = 5609234837434 := by decide
theorem cert_e1211188326330 : check e1211188326330 [[],[]] .three = true := by decide
def e1211188326526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211188326526 : Closed e1211188326526 ∧ code e1211188326526 = 5609234837630 := by decide
theorem cert_e1211188326526 : check e1211188326526 [[],[]] .three = true := by decide
def e1211188326622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211188326622 : Closed e1211188326622 ∧ code e1211188326622 = 5609234837726 := by decide
theorem cert_e1211188326622 : check e1211188326622 [[],[]] .smaller = true := by decide
def e1211188326650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211188326650 : Closed e1211188326650 ∧ code e1211188326650 = 5609234837754 := by decide
theorem cert_e1211188326650 : check e1211188326650 [[],[]] .smaller = true := by decide
def e1211188327198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211188327198 : Closed e1211188327198 ∧ code e1211188327198 = 5609234838302 := by decide
theorem cert_e1211188327198 : check e1211188327198 [[],[]] .smaller = true := by decide
def e1211188327366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211188327366 : Closed e1211188327366 ∧ code e1211188327366 = 5609234838470 := by decide
theorem cert_e1211188327366 : check e1211188327366 [[],[]] .smaller = true := by decide
def e1211188327390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211188327390 : Closed e1211188327390 ∧ code e1211188327390 = 5609234838494 := by decide
theorem cert_e1211188327390 : check e1211188327390 [[],[]] .three = true := by decide
def e1211188327394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211188327394 : Closed e1211188327394 ∧ code e1211188327394 = 5609234838498 := by decide
theorem cert_e1211188327394 : check e1211188327394 [[],[]] .three = true := by decide
def e1211188327406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211188327406 : Closed e1211188327406 ∧ code e1211188327406 = 5609234838510 := by decide
theorem cert_e1211188327406 : check e1211188327406 [[],[]] .three = true := by decide
def e1211188328510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e1211188328510 : Closed e1211188328510 ∧ code e1211188328510 = 5609234839614 := by decide
theorem cert_e1211188328510 : check e1211188328510 [[],[]] .smaller = true := by decide
def e1211188328926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188328926 : Closed e1211188328926 ∧ code e1211188328926 = 5609234840030 := by decide
theorem cert_e1211188328926 : check e1211188328926 [[],[]] .three = true := by decide
def e1211188328930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211188328930 : Closed e1211188328930 ∧ code e1211188328930 = 5609234840034 := by decide
theorem cert_e1211188328930 : check e1211188328930 [[],[]] .smaller = true := by decide
def e1211188328942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211188328942 : Closed e1211188328942 ∧ code e1211188328942 = 5609234840046 := by decide
theorem cert_e1211188328942 : check e1211188328942 [[],[]] .smaller = true := by decide
def e1211188328950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188328950 : Closed e1211188328950 ∧ code e1211188328950 = 5609234840054 := by decide
theorem cert_e1211188328950 : check e1211188328950 [[],[]] .three = true := by decide
def e1211188329502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211188329502 : Closed e1211188329502 ∧ code e1211188329502 = 5609234840606 := by decide
theorem cert_e1211188329502 : check e1211188329502 [[],[]] .smaller = true := by decide
def e1211188329526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188329526 : Closed e1211188329526 ∧ code e1211188329526 = 5609234840630 := by decide
theorem cert_e1211188329526 : check e1211188329526 [[],[]] .smaller = true := by decide
def e1211188329530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188329530 : Closed e1211188329530 ∧ code e1211188329530 = 5609234840634 := by decide
theorem cert_e1211188329530 : check e1211188329530 [[],[]] .smaller = true := by decide
def e1211188329670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211188329670 : Closed e1211188329670 ∧ code e1211188329670 = 5609234840774 := by decide
theorem cert_e1211188329670 : check e1211188329670 [[],[]] .smaller = true := by decide
def e1211188329694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188329694 : Closed e1211188329694 ∧ code e1211188329694 = 5609234840798 := by decide
theorem cert_e1211188329694 : check e1211188329694 [[],[]] .three = true := by decide
def e1211188329698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211188329698 : Closed e1211188329698 ∧ code e1211188329698 = 5609234840802 := by decide
theorem cert_e1211188329698 : check e1211188329698 [[],[]] .smaller = true := by decide
def e1211188329710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188329710 : Closed e1211188329710 ∧ code e1211188329710 = 5609234840814 := by decide
theorem cert_e1211188329710 : check e1211188329710 [[],[]] .smaller = true := by decide
def e1211188329718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188329718 : Closed e1211188329718 ∧ code e1211188329718 = 5609234840822 := by decide
theorem cert_e1211188329718 : check e1211188329718 [[],[]] .smaller = true := by decide
def e1211188329722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188329722 : Closed e1211188329722 ∧ code e1211188329722 = 5609234840826 := by decide
theorem cert_e1211188329722 : check e1211188329722 [[],[]] .three = true := by decide
def e1211188329998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188329998 : Closed e1211188329998 ∧ code e1211188329998 = 5609234841102 := by decide
theorem cert_e1211188329998 : check e1211188329998 [[],[]] .three = true := by decide
def e1211188330010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188330010 : Closed e1211188330010 ∧ code e1211188330010 = 5609234841114 := by decide
theorem cert_e1211188330010 : check e1211188330010 [[],[]] .three = true := by decide
def e1211188330046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e1211188330046 : Closed e1211188330046 ∧ code e1211188330046 = 5609234841150 := by decide
theorem cert_e1211188330046 : check e1211188330046 [[],[]] .three = true := by decide
def e1211188330082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188330082 : Closed e1211188330082 ∧ code e1211188330082 = 5609234841186 := by decide
theorem cert_e1211188330082 : check e1211188330082 [[],[]] .three = true := by decide
def e1211188330094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188330094 : Closed e1211188330094 ∧ code e1211188330094 = 5609234841198 := by decide
theorem cert_e1211188330094 : check e1211188330094 [[],[]] .three = true := by decide
def e1211188330102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188330102 : Closed e1211188330102 ∧ code e1211188330102 = 5609234841206 := by decide
theorem cert_e1211188330102 : check e1211188330102 [[],[]] .three = true := by decide
def e1211188330106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188330106 : Closed e1211188330106 ∧ code e1211188330106 = 5609234841210 := by decide
theorem cert_e1211188330106 : check e1211188330106 [[],[]] .three = true := by decide
def e1211188352558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e1211188352558 : Closed e1211188352558 ∧ code e1211188352558 = 5609234863662 := by decide
theorem cert_e1211188352558 : check e1211188352558 [[],[]] .smaller = true := by decide
def e1211188352734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211188352734 : Closed e1211188352734 ∧ code e1211188352734 = 5609234863838 := by decide
theorem cert_e1211188352734 : check e1211188352734 [[],[]] .three = true := by decide
def e1211188352738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e1211188352738 : Closed e1211188352738 ∧ code e1211188352738 = 5609234863842 := by decide
theorem cert_e1211188352738 : check e1211188352738 [[],[]] .smaller = true := by decide
def e1211188352750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211188352750 : Closed e1211188352750 ∧ code e1211188352750 = 5609234863854 := by decide
theorem cert_e1211188352750 : check e1211188352750 [[],[]] .smaller = true := by decide
def e1211188352758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211188352758 : Closed e1211188352758 ∧ code e1211188352758 = 5609234863862 := by decide
theorem cert_e1211188352758 : check e1211188352758 [[],[]] .three = true := by decide
def e1211188352862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211188352862 : Closed e1211188352862 ∧ code e1211188352862 = 5609234863966 := by decide
theorem cert_e1211188352862 : check e1211188352862 [[],[]] .three = true := by decide
def e1211188352890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211188352890 : Closed e1211188352890 ∧ code e1211188352890 = 5609234863994 := by decide
theorem cert_e1211188352890 : check e1211188352890 [[],[]] .three = true := by decide
def e1211188352906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188352906 : Closed e1211188352906 ∧ code e1211188352906 = 5609234864010 := by decide
theorem cert_e1211188352906 : check e1211188352906 [[],[]] .smaller = true := by decide
def e1211188352930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188352930 : Closed e1211188352930 ∧ code e1211188352930 = 5609234864034 := by decide
theorem cert_e1211188352930 : check e1211188352930 [[],[]] .smaller = true := by decide
def e1211188352942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211188352942 : Closed e1211188352942 ∧ code e1211188352942 = 5609234864046 := by decide
theorem cert_e1211188352942 : check e1211188352942 [[],[]] .smaller = true := by decide
def e1211188352954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211188352954 : Closed e1211188352954 ∧ code e1211188352954 = 5609234864058 := by decide
theorem cert_e1211188352954 : check e1211188352954 [[],[]] .smaller = true := by decide
def e1211188352982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211188352982 : Closed e1211188352982 ∧ code e1211188352982 = 5609234864086 := by decide
theorem cert_e1211188352982 : check e1211188352982 [[],[]] .three = true := by decide
def e1211188352986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211188352986 : Closed e1211188352986 ∧ code e1211188352986 = 5609234864090 := by decide
theorem cert_e1211188352986 : check e1211188352986 [[],[]] .three = true := by decide
def e1211188353086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e1211188353086 : Closed e1211188353086 ∧ code e1211188353086 = 5609234864190 := by decide
theorem cert_e1211188353086 : check e1211188353086 [[],[]] .smaller = true := by decide
def e1211188353502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188353502 : Closed e1211188353502 ∧ code e1211188353502 = 5609234864606 := by decide
theorem cert_e1211188353502 : check e1211188353502 [[],[]] .three = true := by decide
def e1211188353506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211188353506 : Closed e1211188353506 ∧ code e1211188353506 = 5609234864610 := by decide
theorem cert_e1211188353506 : check e1211188353506 [[],[]] .smaller = true := by decide
def e1211188353518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211188353518 : Closed e1211188353518 ∧ code e1211188353518 = 5609234864622 := by decide
theorem cert_e1211188353518 : check e1211188353518 [[],[]] .smaller = true := by decide
def e1211188353526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188353526 : Closed e1211188353526 ∧ code e1211188353526 = 5609234864630 := by decide
theorem cert_e1211188353526 : check e1211188353526 [[],[]] .three = true := by decide
def e1211188354270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188354270 : Closed e1211188354270 ∧ code e1211188354270 = 5609234865374 := by decide
theorem cert_e1211188354270 : check e1211188354270 [[],[]] .three = true := by decide
def e1211188354298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188354298 : Closed e1211188354298 ∧ code e1211188354298 = 5609234865402 := by decide
theorem cert_e1211188354298 : check e1211188354298 [[],[]] .three = true := by decide
def e1211188354574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188354574 : Closed e1211188354574 ∧ code e1211188354574 = 5609234865678 := by decide
theorem cert_e1211188354574 : check e1211188354574 [[],[]] .smaller = true := by decide
def e1211188354622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211188354622 : Closed e1211188354622 ∧ code e1211188354622 = 5609234865726 := by decide
theorem cert_e1211188354622 : check e1211188354622 [[],[]] .three = true := by decide
def e1211188354658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188354658 : Closed e1211188354658 ∧ code e1211188354658 = 5609234865762 := by decide
theorem cert_e1211188354658 : check e1211188354658 [[],[]] .smaller = true := by decide
def e1211188354670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188354670 : Closed e1211188354670 ∧ code e1211188354670 = 5609234865774 := by decide
theorem cert_e1211188354670 : check e1211188354670 [[],[]] .smaller = true := by decide
def e1211188354682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188354682 : Closed e1211188354682 ∧ code e1211188354682 = 5609234865786 := by decide
theorem cert_e1211188354682 : check e1211188354682 [[],[]] .smaller = true := by decide
def e1211188354846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211188354846 : Closed e1211188354846 ∧ code e1211188354846 = 5609234865950 := by decide
theorem cert_e1211188354846 : check e1211188354846 [[],[]] .three = true := by decide
def e1211188354870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188354870 : Closed e1211188354870 ∧ code e1211188354870 = 5609234865974 := by decide
theorem cert_e1211188354870 : check e1211188354870 [[],[]] .three = true := by decide
def e1211188354874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188354874 : Closed e1211188354874 ∧ code e1211188354874 = 5609234865978 := by decide
theorem cert_e1211188354874 : check e1211188354874 [[],[]] .three = true := by decide
def e1211188363990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211188363990 : Closed e1211188363990 ∧ code e1211188363990 = 5609234875094 := by decide
theorem cert_e1211188363990 : check e1211188363990 [[],[]] .smaller = true := by decide
def e1211188363994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211188363994 : Closed e1211188363994 ∧ code e1211188363994 = 5609234875098 := by decide
theorem cert_e1211188363994 : check e1211188363994 [[],[]] .smaller = true := by decide
def e1211188364010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211188364010 : Closed e1211188364010 ∧ code e1211188364010 = 5609234875114 := by decide
theorem cert_e1211188364010 : check e1211188364010 [[],[]] .smaller = true := by decide
def e1211188364086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188364086 : Closed e1211188364086 ∧ code e1211188364086 = 5609234875190 := by decide
theorem cert_e1211188364086 : check e1211188364086 [[],[]] .smaller = true := by decide
def e1211188364090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188364090 : Closed e1211188364090 ∧ code e1211188364090 = 5609234875194 := by decide
theorem cert_e1211188364090 : check e1211188364090 [[],[]] .smaller = true := by decide
def e1211188364174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e1211188364174 : Closed e1211188364174 ∧ code e1211188364174 = 5609234875278 := by decide
theorem cert_e1211188364174 : check e1211188364174 [[],[]] .smaller = true := by decide
def e1211188364186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188364186 : Closed e1211188364186 ∧ code e1211188364186 = 5609234875290 := by decide
theorem cert_e1211188364186 : check e1211188364186 [[],[]] .smaller = true := by decide
def e1211188366102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211188366102 : Closed e1211188366102 ∧ code e1211188366102 = 5609234877206 := by decide
theorem cert_e1211188366102 : check e1211188366102 [[],[]] .smaller = true := by decide
def e1211188366106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211188366106 : Closed e1211188366106 ∧ code e1211188366106 = 5609234877210 := by decide
theorem cert_e1211188366106 : check e1211188366106 [[],[]] .smaller = true := by decide
def e1211188366150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211188366150 : Closed e1211188366150 ∧ code e1211188366150 = 5609234877254 := by decide
theorem cert_e1211188366150 : check e1211188366150 [[],[]] .smaller = true := by decide
def e1211188366174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211188366174 : Closed e1211188366174 ∧ code e1211188366174 = 5609234877278 := by decide
theorem cert_e1211188366174 : check e1211188366174 [[],[]] .three = true := by decide
def e1211188366178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211188366178 : Closed e1211188366178 ∧ code e1211188366178 = 5609234877282 := by decide
theorem cert_e1211188366178 : check e1211188366178 [[],[]] .smaller = true := by decide
def e1211188366190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211188366190 : Closed e1211188366190 ∧ code e1211188366190 = 5609234877294 := by decide
theorem cert_e1211188366190 : check e1211188366190 [[],[]] .smaller = true := by decide
def e1211188366198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211188366198 : Closed e1211188366198 ∧ code e1211188366198 = 5609234877302 := by decide
theorem cert_e1211188366198 : check e1211188366198 [[],[]] .smaller = true := by decide
def e1211188366202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211188366202 : Closed e1211188366202 ∧ code e1211188366202 = 5609234877306 := by decide
theorem cert_e1211188366202 : check e1211188366202 [[],[]] .three = true := by decide
def e1211188366218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188366218 : Closed e1211188366218 ∧ code e1211188366218 = 5609234877322 := by decide
theorem cert_e1211188366218 : check e1211188366218 [[],[]] .smaller = true := by decide
def e1211188366242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188366242 : Closed e1211188366242 ∧ code e1211188366242 = 5609234877346 := by decide
theorem cert_e1211188366242 : check e1211188366242 [[],[]] .smaller = true := by decide
def e1211188366254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211188366254 : Closed e1211188366254 ∧ code e1211188366254 = 5609234877358 := by decide
theorem cert_e1211188366254 : check e1211188366254 [[],[]] .smaller = true := by decide
def e1211188366266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211188366266 : Closed e1211188366266 ∧ code e1211188366266 = 5609234877370 := by decide
theorem cert_e1211188366266 : check e1211188366266 [[],[]] .smaller = true := by decide
def e1211188366294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211188366294 : Closed e1211188366294 ∧ code e1211188366294 = 5609234877398 := by decide
theorem cert_e1211188366294 : check e1211188366294 [[],[]] .smaller = true := by decide
def e1211188366298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211188366298 : Closed e1211188366298 ∧ code e1211188366298 = 5609234877402 := by decide
theorem cert_e1211188366298 : check e1211188366298 [[],[]] .smaller = true := by decide
def e1211188366314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211188366314 : Closed e1211188366314 ∧ code e1211188366314 = 5609234877418 := by decide
theorem cert_e1211188366314 : check e1211188366314 [[],[]] .three = true := by decide
def e1211188366366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211188366366 : Closed e1211188366366 ∧ code e1211188366366 = 5609234877470 := by decide
theorem cert_e1211188366366 : check e1211188366366 [[],[]] .smaller = true := by decide
def e1211188366390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188366390 : Closed e1211188366390 ∧ code e1211188366390 = 5609234877494 := by decide
theorem cert_e1211188366390 : check e1211188366390 [[],[]] .smaller = true := by decide
def e1211188366394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188366394 : Closed e1211188366394 ∧ code e1211188366394 = 5609234877498 := by decide
theorem cert_e1211188366394 : check e1211188366394 [[],[]] .smaller = true := by decide
def e1211188366534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211188366534 : Closed e1211188366534 ∧ code e1211188366534 = 5609234877638 := by decide
theorem cert_e1211188366534 : check e1211188366534 [[],[]] .smaller = true := by decide
def e1211188366558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211188366558 : Closed e1211188366558 ∧ code e1211188366558 = 5609234877662 := by decide
theorem cert_e1211188366558 : check e1211188366558 [[],[]] .three = true := by decide
end Blc.Floor42
