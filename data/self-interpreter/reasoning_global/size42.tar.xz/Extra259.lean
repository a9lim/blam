import Batch259
import ExtraBase
namespace Blc.Floor42.Extra259
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211584857542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem ex_e1211584857542 : ¬ IsSelfInterpreter e1211584857542 := by
  intro he
  have hp := replay_sound (t := e1211584857542) (u := t_e1211584857542) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.lam (.var 1)))) (r := (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (so_closed_lam (by decide) (SO.var 0))) (SO.var 2)) (so_dead (by decide) (SO.var 1))) (SO.app (SO.app (SO.var 0) (so_closed_lam (by decide) (SO.var 0))) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1211584857542
private def t_e1211584858042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem ex_e1211584858042 : ¬ IsSelfInterpreter e1211584858042 := by
  intro he
  have hp := replay_sound (t := e1211584858042) (u := t_e1211584858042) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (so_dead (by decide) (SO.var 3))) (SO.var 2)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (so_dead (by decide) (SO.var 2))) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1211584858042
private def t_e1211584865210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem ex_e1211584865210 : ¬ IsSelfInterpreter e1211584865210 := by
  intro he
  have hp := replay_sound (t := e1211584865210) (u := t_e1211584865210) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (SO.app (SO.app (SO.app (SO.var 2) (so_dead (by decide) (SO.var 2))) (SO.var 2)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (so_dead (by decide) (SO.var 1))) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1211584865210
private def t_e1211584865242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem ex_e1211584865242 : ¬ IsSelfInterpreter e1211584865242 := by
  intro he
  have hp := replay_sound (t := e1211584865242) (u := t_e1211584865242) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (r := (.app (.var 0) (.lam (.var 1)))) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (so_dead (by decide) (SO.var 3))) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (so_dead (by decide) (SO.var 2))) (SO.var 0)) (by decide) (by rfl)) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1))) (by decide) (by rfl)))))
#print axioms ex_e1211584865242
end Blc.Floor42.Extra259
