import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205814926810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1205814926810 : Closed e1205814926810 ∧ code e1205814926810 = 5603861437914 := by decide
theorem cert_e1205814926810 : check e1205814926810 [[],[]] .chain = true := by decide
def e1205814926890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e1205814926890 : Closed e1205814926890 ∧ code e1205814926890 = 5603861437994 := by decide
theorem cert_e1205814926890 : check e1205814926890 [[],[]] .chain = true := by decide
def e1205814926986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814926986 : Closed e1205814926986 ∧ code e1205814926986 = 5603861438090 := by decide
theorem cert_e1205814926986 : check e1205814926986 [[],[]] .chain = true := by decide
def e1205814927010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814927010 : Closed e1205814927010 ∧ code e1205814927010 = 5603861438114 := by decide
theorem cert_e1205814927010 : check e1205814927010 [[],[]] .chain = true := by decide
def e1205814927022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1205814927022 : Closed e1205814927022 ∧ code e1205814927022 = 5603861438126 := by decide
theorem cert_e1205814927022 : check e1205814927022 [[],[]] .sourceHead = true := by decide
def e1205814927030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1205814927030 : Closed e1205814927030 ∧ code e1205814927030 = 5603861438134 := by decide
theorem cert_e1205814927030 : check e1205814927030 [[],[]] .chain = true := by decide
def e1205814927034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1205814927034 : Closed e1205814927034 ∧ code e1205814927034 = 5603861438138 := by decide
theorem cert_e1205814927034 : check e1205814927034 [[],[]] .sourceHead = true := by decide
def e1205814927062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1205814927062 : Closed e1205814927062 ∧ code e1205814927062 = 5603861438166 := by decide
theorem cert_e1205814927062 : check e1205814927062 [[],[]] .chain = true := by decide
def e1205814927066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1205814927066 : Closed e1205814927066 ∧ code e1205814927066 = 5603861438170 := by decide
theorem cert_e1205814927066 : check e1205814927066 [[],[]] .chain = true := by decide
def e1205814927082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1205814927082 : Closed e1205814927082 ∧ code e1205814927082 = 5603861438186 := by decide
theorem cert_e1205814927082 : check e1205814927082 [[],[]] .sourceHead = true := by decide
def e1205814927598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e1205814927598 : Closed e1205814927598 ∧ code e1205814927598 = 5603861438702 := by decide
theorem cert_e1205814927598 : check e1205814927598 [[],[]] .chain = true := by decide
def e1205814927610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e1205814927610 : Closed e1205814927610 ∧ code e1205814927610 = 5603861438714 := by decide
theorem cert_e1205814927610 : check e1205814927610 [[],[]] .chain = true := by decide
def e1205814927790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1205814927790 : Closed e1205814927790 ∧ code e1205814927790 = 5603861438894 := by decide
theorem cert_e1205814927790 : check e1205814927790 [[],[]] .sourceHead = true := by decide
def e1205814927982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814927982 : Closed e1205814927982 ∧ code e1205814927982 = 5603861439086 := by decide
theorem cert_e1205814927982 : check e1205814927982 [[],[]] .chain = true := by decide
def e1205814927994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814927994 : Closed e1205814927994 ∧ code e1205814927994 = 5603861439098 := by decide
theorem cert_e1205814927994 : check e1205814927994 [[],[]] .chain = true := by decide
def e1205814928158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e1205814928158 : Closed e1205814928158 ∧ code e1205814928158 = 5603861439262 := by decide
theorem cert_e1205814928158 : check e1205814928158 [[],[]] .chain = true := by decide
def e1205814928326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e1205814928326 : Closed e1205814928326 ∧ code e1205814928326 = 5603861439430 := by decide
theorem cert_e1205814928326 : check e1205814928326 [[],[]] .chain = true := by decide
def e1205814928942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205814928942 : Closed e1205814928942 ∧ code e1205814928942 = 5603861440046 := by decide
theorem cert_e1205814928942 : check e1205814928942 [[],[]] .chain = true := by decide
def e1205814929122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205814929122 : Closed e1205814929122 ∧ code e1205814929122 = 5603861440226 := by decide
theorem cert_e1205814929122 : check e1205814929122 [[],[]] .chain = true := by decide
def e1205814929134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1205814929134 : Closed e1205814929134 ∧ code e1205814929134 = 5603861440238 := by decide
theorem cert_e1205814929134 : check e1205814929134 [[],[]] .sourceHead = true := by decide
def e1205814929262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1205814929262 : Closed e1205814929262 ∧ code e1205814929262 = 5603861440366 := by decide
theorem cert_e1205814929262 : check e1205814929262 [[],[]] .chain = true := by decide
def e1205814929270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1205814929270 : Closed e1205814929270 ∧ code e1205814929270 = 5603861440374 := by decide
theorem cert_e1205814929270 : check e1205814929270 [[],[]] .chain = true := by decide
def e1205814929290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814929290 : Closed e1205814929290 ∧ code e1205814929290 = 5603861440394 := by decide
theorem cert_e1205814929290 : check e1205814929290 [[],[]] .chain = true := by decide
def e1205814929314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814929314 : Closed e1205814929314 ∧ code e1205814929314 = 5603861440418 := by decide
theorem cert_e1205814929314 : check e1205814929314 [[],[]] .chain = true := by decide
def e1205814929326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1205814929326 : Closed e1205814929326 ∧ code e1205814929326 = 5603861440430 := by decide
theorem cert_e1205814929326 : check e1205814929326 [[],[]] .sourceHead = true := by decide
def e1205814929334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1205814929334 : Closed e1205814929334 ∧ code e1205814929334 = 5603861440438 := by decide
theorem cert_e1205814929334 : check e1205814929334 [[],[]] .chain = true := by decide
def e1205814929338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1205814929338 : Closed e1205814929338 ∧ code e1205814929338 = 5603861440442 := by decide
theorem cert_e1205814929338 : check e1205814929338 [[],[]] .sourceHead = true := by decide
def e1205814929470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e1205814929470 : Closed e1205814929470 ∧ code e1205814929470 = 5603861440574 := by decide
theorem cert_e1205814929470 : check e1205814929470 [[],[]] .chain = true := by decide
def e1205814929890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205814929890 : Closed e1205814929890 ∧ code e1205814929890 = 5603861440994 := by decide
theorem cert_e1205814929890 : check e1205814929890 [[],[]] .chain = true := by decide
def e1205814929902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1205814929902 : Closed e1205814929902 ∧ code e1205814929902 = 5603861441006 := by decide
theorem cert_e1205814929902 : check e1205814929902 [[],[]] .sourceHead = true := by decide
def e1205814930670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814930670 : Closed e1205814930670 ∧ code e1205814930670 = 5603861441774 := by decide
theorem cert_e1205814930670 : check e1205814930670 [[],[]] .chain = true := by decide
def e1205814930678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814930678 : Closed e1205814930678 ∧ code e1205814930678 = 5603861441782 := by decide
theorem cert_e1205814930678 : check e1205814930678 [[],[]] .chain = true := by decide
def e1205814930958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814930958 : Closed e1205814930958 ∧ code e1205814930958 = 5603861442062 := by decide
theorem cert_e1205814930958 : check e1205814930958 [[],[]] .chain = true := by decide
def e1205814930970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814930970 : Closed e1205814930970 ∧ code e1205814930970 = 5603861442074 := by decide
theorem cert_e1205814930970 : check e1205814930970 [[],[]] .sourceHead = true := by decide
def e1205814931042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814931042 : Closed e1205814931042 ∧ code e1205814931042 = 5603861442146 := by decide
theorem cert_e1205814931042 : check e1205814931042 [[],[]] .chain = true := by decide
def e1205814931054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814931054 : Closed e1205814931054 ∧ code e1205814931054 = 5603861442158 := by decide
theorem cert_e1205814931054 : check e1205814931054 [[],[]] .sourceHead = true := by decide
def e1205814931062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814931062 : Closed e1205814931062 ∧ code e1205814931062 = 5603861442166 := by decide
theorem cert_e1205814931062 : check e1205814931062 [[],[]] .chain = true := by decide
def e1205814931066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814931066 : Closed e1205814931066 ∧ code e1205814931066 = 5603861442170 := by decide
theorem cert_e1205814931066 : check e1205814931066 [[],[]] .sourceHead = true := by decide
def e1205814932334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1205814932334 : Closed e1205814932334 ∧ code e1205814932334 = 5603861443438 := by decide
theorem cert_e1205814932334 : check e1205814932334 [[],[]] .chain = true := by decide
def e1205814932342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1205814932342 : Closed e1205814932342 ∧ code e1205814932342 = 5603861443446 := by decide
theorem cert_e1205814932342 : check e1205814932342 [[],[]] .chain = true := by decide
def e1205814932398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1205814932398 : Closed e1205814932398 ∧ code e1205814932398 = 5603861443502 := by decide
theorem cert_e1205814932398 : check e1205814932398 [[],[]] .chain = true := by decide
def e1205814932410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1205814932410 : Closed e1205814932410 ∧ code e1205814932410 = 5603861443514 := by decide
theorem cert_e1205814932410 : check e1205814932410 [[],[]] .chain = true := by decide
def e1205814932438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1205814932438 : Closed e1205814932438 ∧ code e1205814932438 = 5603861443542 := by decide
theorem cert_e1205814932438 : check e1205814932438 [[],[]] .chain = true := by decide
def e1205814932442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1205814932442 : Closed e1205814932442 ∧ code e1205814932442 = 5603861443546 := by decide
theorem cert_e1205814932442 : check e1205814932442 [[],[]] .chain = true := by decide
def e1205814932718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814932718 : Closed e1205814932718 ∧ code e1205814932718 = 5603861443822 := by decide
theorem cert_e1205814932718 : check e1205814932718 [[],[]] .chain = true := by decide
def e1205814932726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814932726 : Closed e1205814932726 ∧ code e1205814932726 = 5603861443830 := by decide
theorem cert_e1205814932726 : check e1205814932726 [[],[]] .chain = true := by decide
def e1205814933102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814933102 : Closed e1205814933102 ∧ code e1205814933102 = 5603861444206 := by decide
theorem cert_e1205814933102 : check e1205814933102 [[],[]] .chain = true := by decide
def e1205814933114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814933114 : Closed e1205814933114 ∧ code e1205814933114 = 5603861444218 := by decide
theorem cert_e1205814933114 : check e1205814933114 [[],[]] .chain = true := by decide
def e1205814933302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814933302 : Closed e1205814933302 ∧ code e1205814933302 = 5603861444406 := by decide
theorem cert_e1205814933302 : check e1205814933302 [[],[]] .chain = true := by decide
def e1205814933306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814933306 : Closed e1205814933306 ∧ code e1205814933306 = 5603861444410 := by decide
theorem cert_e1205814933306 : check e1205814933306 [[],[]] .chain = true := by decide
def e1205814933562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e1205814933562 : Closed e1205814933562 ∧ code e1205814933562 = 5603861444666 := by decide
theorem cert_e1205814933562 : check e1205814933562 [[],[]] .chain = true := by decide
def e1205814933610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1205814933610 : Closed e1205814933610 ∧ code e1205814933610 = 5603861444714 := by decide
theorem cert_e1205814933610 : check e1205814933610 [[],[]] .sourceHead = true := by decide
def e1205814933658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814933658 : Closed e1205814933658 ∧ code e1205814933658 = 5603861444762 := by decide
theorem cert_e1205814933658 : check e1205814933658 [[],[]] .chain = true := by decide
def e1205814933702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e1205814933702 : Closed e1205814933702 ∧ code e1205814933702 = 5603861444806 := by decide
theorem cert_e1205814933702 : check e1205814933702 [[],[]] .chain = true := by decide
def e1205814933898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814933898 : Closed e1205814933898 ∧ code e1205814933898 = 5603861445002 := by decide
theorem cert_e1205814933898 : check e1205814933898 [[],[]] .chain = true := by decide
def e1205814933922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814933922 : Closed e1205814933922 ∧ code e1205814933922 = 5603861445026 := by decide
theorem cert_e1205814933922 : check e1205814933922 [[],[]] .chain = true := by decide
def e1205814933934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1205814933934 : Closed e1205814933934 ∧ code e1205814933934 = 5603861445038 := by decide
theorem cert_e1205814933934 : check e1205814933934 [[],[]] .sourceHead = true := by decide
def e1205814933942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1205814933942 : Closed e1205814933942 ∧ code e1205814933942 = 5603861445046 := by decide
theorem cert_e1205814933942 : check e1205814933942 [[],[]] .chain = true := by decide
def e1205814933946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1205814933946 : Closed e1205814933946 ∧ code e1205814933946 = 5603861445050 := by decide
theorem cert_e1205814933946 : check e1205814933946 [[],[]] .sourceHead = true := by decide
def e1205814933974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1205814933974 : Closed e1205814933974 ∧ code e1205814933974 = 5603861445078 := by decide
theorem cert_e1205814933974 : check e1205814933974 [[],[]] .chain = true := by decide
def e1205814933978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1205814933978 : Closed e1205814933978 ∧ code e1205814933978 = 5603861445082 := by decide
theorem cert_e1205814933978 : check e1205814933978 [[],[]] .chain = true := by decide
def e1205814933994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1205814933994 : Closed e1205814933994 ∧ code e1205814933994 = 5603861445098 := by decide
theorem cert_e1205814933994 : check e1205814933994 [[],[]] .sourceHead = true := by decide
def e1205814934030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814934030 : Closed e1205814934030 ∧ code e1205814934030 = 5603861445134 := by decide
theorem cert_e1205814934030 : check e1205814934030 [[],[]] .chain = true := by decide
def e1205814934042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814934042 : Closed e1205814934042 ∧ code e1205814934042 = 5603861445146 := by decide
theorem cert_e1205814934042 : check e1205814934042 [[],[]] .sourceHead = true := by decide
def e1205814934114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814934114 : Closed e1205814934114 ∧ code e1205814934114 = 5603861445218 := by decide
theorem cert_e1205814934114 : check e1205814934114 [[],[]] .chain = true := by decide
def e1205814934126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814934126 : Closed e1205814934126 ∧ code e1205814934126 = 5603861445230 := by decide
theorem cert_e1205814934126 : check e1205814934126 [[],[]] .sourceHead = true := by decide
def e1205814934134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814934134 : Closed e1205814934134 ∧ code e1205814934134 = 5603861445238 := by decide
theorem cert_e1205814934134 : check e1205814934134 [[],[]] .chain = true := by decide
def e1205814934138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814934138 : Closed e1205814934138 ∧ code e1205814934138 = 5603861445242 := by decide
theorem cert_e1205814934138 : check e1205814934138 [[],[]] .sourceHead = true := by decide
def e1205814934326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814934326 : Closed e1205814934326 ∧ code e1205814934326 = 5603861445430 := by decide
theorem cert_e1205814934326 : check e1205814934326 [[],[]] .chain = true := by decide
def e1205814934330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814934330 : Closed e1205814934330 ∧ code e1205814934330 = 5603861445434 := by decide
theorem cert_e1205814934330 : check e1205814934330 [[],[]] .chain = true := by decide
def e1205814934426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814934426 : Closed e1205814934426 ∧ code e1205814934426 = 5603861445530 := by decide
theorem cert_e1205814934426 : check e1205814934426 [[],[]] .sourceHead = true := by decide
def e1205814936022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1205814936022 : Closed e1205814936022 ∧ code e1205814936022 = 5603861447126 := by decide
theorem cert_e1205814936022 : check e1205814936022 [[],[]] .chain = true := by decide
def e1205814936026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1205814936026 : Closed e1205814936026 ∧ code e1205814936026 = 5603861447130 := by decide
theorem cert_e1205814936026 : check e1205814936026 [[],[]] .chain = true := by decide
def e1205814936042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e1205814936042 : Closed e1205814936042 ∧ code e1205814936042 = 5603861447146 := by decide
theorem cert_e1205814936042 : check e1205814936042 [[],[]] .chain = true := by decide
def e1205814936406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1205814936406 : Closed e1205814936406 ∧ code e1205814936406 = 5603861447510 := by decide
theorem cert_e1205814936406 : check e1205814936406 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814936410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1205814936410 : Closed e1205814936410 ∧ code e1205814936410 = 5603861447514 := by decide
theorem cert_e1205814936410 : check e1205814936410 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814936790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1205814936790 : Closed e1205814936790 ∧ code e1205814936790 = 5603861447894 := by decide
theorem cert_e1205814936790 : check e1205814936790 [[],[]] .chain = true := by decide
def e1205814936794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1205814936794 : Closed e1205814936794 ∧ code e1205814936794 = 5603861447898 := by decide
theorem cert_e1205814936794 : check e1205814936794 [[],[]] .chain = true := by decide
def e1205814936810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1205814936810 : Closed e1205814936810 ∧ code e1205814936810 = 5603861447914 := by decide
theorem cert_e1205814936810 : check e1205814936810 [[],[]] .chain = true := by decide
def e1205814936886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814936886 : Closed e1205814936886 ∧ code e1205814936886 = 5603861447990 := by decide
theorem cert_e1205814936886 : check e1205814936886 [[],[]] .chain = true := by decide
def e1205814936890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814936890 : Closed e1205814936890 ∧ code e1205814936890 = 5603861447994 := by decide
theorem cert_e1205814936890 : check e1205814936890 [[],[]] .chain = true := by decide
def e1205814936986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814936986 : Closed e1205814936986 ∧ code e1205814936986 = 5603861448090 := by decide
theorem cert_e1205814936986 : check e1205814936986 [[],[]] .chain = true := by decide
def e1205814937142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1205814937142 : Closed e1205814937142 ∧ code e1205814937142 = 5603861448246 := by decide
theorem cert_e1205814937142 : check e1205814937142 [[],[]] .chain = true := by decide
def e1205814937146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1205814937146 : Closed e1205814937146 ∧ code e1205814937146 = 5603861448250 := by decide
theorem cert_e1205814937146 : check e1205814937146 [[],[]] .chain = true := by decide
def e1205814937230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1205814937230 : Closed e1205814937230 ∧ code e1205814937230 = 5603861448334 := by decide
theorem cert_e1205814937230 : check e1205814937230 [[],[]] .chain = true := by decide
def e1205814937286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1205814937286 : Closed e1205814937286 ∧ code e1205814937286 = 5603861448390 := by decide
theorem cert_e1205814937286 : check e1205814937286 [[],[]] .chain = true := by decide
def e1205814937370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1205814937370 : Closed e1205814937370 ∧ code e1205814937370 = 5603861448474 := by decide
theorem cert_e1205814937370 : check e1205814937370 [[],[]] .chain = true := by decide
def e1205814937414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1205814937414 : Closed e1205814937414 ∧ code e1205814937414 = 5603861448518 := by decide
theorem cert_e1205814937414 : check e1205814937414 [[],[]] .chain = true := by decide
def e1205814938710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1205814938710 : Closed e1205814938710 ∧ code e1205814938710 = 5603861449814 := by decide
theorem cert_e1205814938710 : check e1205814938710 [[],[]] .chain = true := by decide
def e1205814938714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1205814938714 : Closed e1205814938714 ∧ code e1205814938714 = 5603861449818 := by decide
theorem cert_e1205814938714 : check e1205814938714 [[],[]] .chain = true := by decide
def e1205814938902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814938902 : Closed e1205814938902 ∧ code e1205814938902 = 5603861450006 := by decide
theorem cert_e1205814938902 : check e1205814938902 [[],[]] .chain = true := by decide
def e1205814938978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814938978 : Closed e1205814938978 ∧ code e1205814938978 = 5603861450082 := by decide
theorem cert_e1205814938978 : check e1205814938978 [[],[]] .chain = true := by decide
def e1205814938990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1205814938990 : Closed e1205814938990 ∧ code e1205814938990 = 5603861450094 := by decide
theorem cert_e1205814938990 : check e1205814938990 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814938998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1205814938998 : Closed e1205814938998 ∧ code e1205814938998 = 5603861450102 := by decide
theorem cert_e1205814938998 : check e1205814938998 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814939018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814939018 : Closed e1205814939018 ∧ code e1205814939018 = 5603861450122 := by decide
theorem cert_e1205814939018 : check e1205814939018 [[],[]] .chain = true := by decide
def e1205814939042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814939042 : Closed e1205814939042 ∧ code e1205814939042 = 5603861450146 := by decide
theorem cert_e1205814939042 : check e1205814939042 [[],[]] .chain = true := by decide
def e1205814939054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1205814939054 : Closed e1205814939054 ∧ code e1205814939054 = 5603861450158 := by decide
theorem cert_e1205814939054 : check e1205814939054 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814939062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e1205814939062 : Closed e1205814939062 ∧ code e1205814939062 = 5603861450166 := by decide
theorem cert_e1205814939062 : check e1205814939062 [[],[]] .chain = true := by decide
def e1205814939066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1205814939066 : Closed e1205814939066 ∧ code e1205814939066 = 5603861450170 := by decide
theorem cert_e1205814939066 : check e1205814939066 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814939094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1205814939094 : Closed e1205814939094 ∧ code e1205814939094 = 5603861450198 := by decide
theorem cert_e1205814939094 : check e1205814939094 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814939098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1205814939098 : Closed e1205814939098 ∧ code e1205814939098 = 5603861450202 := by decide
theorem cert_e1205814939098 : check e1205814939098 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814939178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e1205814939178 : Closed e1205814939178 ∧ code e1205814939178 = 5603861450282 := by decide
theorem cert_e1205814939178 : check e1205814939178 [[],[]] .chain = true := by decide
def e1205814939274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814939274 : Closed e1205814939274 ∧ code e1205814939274 = 5603861450378 := by decide
theorem cert_e1205814939274 : check e1205814939274 [[],[]] .chain = true := by decide
def e1205814939298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814939298 : Closed e1205814939298 ∧ code e1205814939298 = 5603861450402 := by decide
theorem cert_e1205814939298 : check e1205814939298 [[],[]] .chain = true := by decide
def e1205814939310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1205814939310 : Closed e1205814939310 ∧ code e1205814939310 = 5603861450414 := by decide
theorem cert_e1205814939310 : check e1205814939310 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814939318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1205814939318 : Closed e1205814939318 ∧ code e1205814939318 = 5603861450422 := by decide
theorem cert_e1205814939318 : check e1205814939318 [[],[]] .chain = true := by decide
def e1205814939322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1205814939322 : Closed e1205814939322 ∧ code e1205814939322 = 5603861450426 := by decide
theorem cert_e1205814939322 : check e1205814939322 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814939350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1205814939350 : Closed e1205814939350 ∧ code e1205814939350 = 5603861450454 := by decide
theorem cert_e1205814939350 : check e1205814939350 [[],[]] .chain = true := by decide
def e1205814939354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1205814939354 : Closed e1205814939354 ∧ code e1205814939354 = 5603861450458 := by decide
theorem cert_e1205814939354 : check e1205814939354 [[],[]] .chain = true := by decide
def e1205814939370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1205814939370 : Closed e1205814939370 ∧ code e1205814939370 = 5603861450474 := by decide
theorem cert_e1205814939370 : check e1205814939370 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e1205814939478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1205814939478 : Closed e1205814939478 ∧ code e1205814939478 = 5603861450582 := by decide
theorem cert_e1205814939478 : check e1205814939478 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814939482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1205814939482 : Closed e1205814939482 ∧ code e1205814939482 = 5603861450586 := by decide
theorem cert_e1205814939482 : check e1205814939482 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814939498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1205814939498 : Closed e1205814939498 ∧ code e1205814939498 = 5603861450602 := by decide
theorem cert_e1205814939498 : check e1205814939498 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e1205814939766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e1205814939766 : Closed e1205814939766 ∧ code e1205814939766 = 5603861450870 := by decide
theorem cert_e1205814939766 : check e1205814939766 [[],[]] .chain = true := by decide
def e1205814939770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e1205814939770 : Closed e1205814939770 ∧ code e1205814939770 = 5603861450874 := by decide
theorem cert_e1205814939770 : check e1205814939770 [[],[]] .chain = true := by decide
def e1205814939862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1205814939862 : Closed e1205814939862 ∧ code e1205814939862 = 5603861450966 := by decide
theorem cert_e1205814939862 : check e1205814939862 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e1205814939958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814939958 : Closed e1205814939958 ∧ code e1205814939958 = 5603861451062 := by decide
theorem cert_e1205814939958 : check e1205814939958 [[],[]] .chain = true := by decide
def e1205814939962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814939962 : Closed e1205814939962 ∧ code e1205814939962 = 5603861451066 := by decide
theorem cert_e1205814939962 : check e1205814939962 [[],[]] .chain = true := by decide
def e1205814940046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e1205814940046 : Closed e1205814940046 ∧ code e1205814940046 = 5603861451150 := by decide
theorem cert_e1205814940046 : check e1205814940046 [[],[]] .chain = true := by decide
def e1205814940102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e1205814940102 : Closed e1205814940102 ∧ code e1205814940102 = 5603861451206 := by decide
theorem cert_e1205814940102 : check e1205814940102 [[],[]] .chain = true := by decide
def e1205814940438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205814940438 : Closed e1205814940438 ∧ code e1205814940438 = 5603861451542 := by decide
theorem cert_e1205814940438 : check e1205814940438 [[],[]] .chain = true := by decide
def e1205814940514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205814940514 : Closed e1205814940514 ∧ code e1205814940514 = 5603861451618 := by decide
theorem cert_e1205814940514 : check e1205814940514 [[],[]] .chain = true := by decide
def e1205814940526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1205814940526 : Closed e1205814940526 ∧ code e1205814940526 = 5603861451630 := by decide
theorem cert_e1205814940526 : check e1205814940526 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1205814940534 : Closed e1205814940534 ∧ code e1205814940534 = 5603861451638 := by decide
theorem cert_e1205814940534 : check e1205814940534 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814940554 : Closed e1205814940554 ∧ code e1205814940554 = 5603861451658 := by decide
theorem cert_e1205814940554 : check e1205814940554 [[],[]] .chain = true := by decide
def e1205814940578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814940578 : Closed e1205814940578 ∧ code e1205814940578 = 5603861451682 := by decide
theorem cert_e1205814940578 : check e1205814940578 [[],[]] .chain = true := by decide
def e1205814940590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1205814940590 : Closed e1205814940590 ∧ code e1205814940590 = 5603861451694 := by decide
theorem cert_e1205814940590 : check e1205814940590 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e1205814940598 : Closed e1205814940598 ∧ code e1205814940598 = 5603861451702 := by decide
theorem cert_e1205814940598 : check e1205814940598 [[],[]] .chain = true := by decide
def e1205814940602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1205814940602 : Closed e1205814940602 ∧ code e1205814940602 = 5603861451706 := by decide
theorem cert_e1205814940602 : check e1205814940602 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1205814940630 : Closed e1205814940630 ∧ code e1205814940630 = 5603861451734 := by decide
theorem cert_e1205814940630 : check e1205814940630 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1205814940634 : Closed e1205814940634 ∧ code e1205814940634 = 5603861451738 := by decide
theorem cert_e1205814940634 : check e1205814940634 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e1205814940702 : Closed e1205814940702 ∧ code e1205814940702 = 5603861451806 := by decide
theorem cert_e1205814940702 : check e1205814940702 [[],[]] .chain = true := by decide
def e1205814940898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205814940898 : Closed e1205814940898 ∧ code e1205814940898 = 5603861452002 := by decide
theorem cert_e1205814940898 : check e1205814940898 [[],[]] .chain = true := by decide
def e1205814940910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814940910 : Closed e1205814940910 ∧ code e1205814940910 = 5603861452014 := by decide
theorem cert_e1205814940910 : check e1205814940910 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814940918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814940918 : Closed e1205814940918 ∧ code e1205814940918 = 5603861452022 := by decide
theorem cert_e1205814940918 : check e1205814940918 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814941198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814941198 : Closed e1205814941198 ∧ code e1205814941198 = 5603861452302 := by decide
theorem cert_e1205814941198 : check e1205814941198 [[],[]] .chain = true := by decide
def e1205814941210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814941210 : Closed e1205814941210 ∧ code e1205814941210 = 5603861452314 := by decide
theorem cert_e1205814941210 : check e1205814941210 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .width = true := by decide
def e1205814941282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814941282 : Closed e1205814941282 ∧ code e1205814941282 = 5603861452386 := by decide
theorem cert_e1205814941282 : check e1205814941282 [[],[]] .chain = true := by decide
def e1205814941294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814941294 : Closed e1205814941294 ∧ code e1205814941294 = 5603861452398 := by decide
theorem cert_e1205814941294 : check e1205814941294 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814941302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814941302 : Closed e1205814941302 ∧ code e1205814941302 = 5603861452406 := by decide
theorem cert_e1205814941302 : check e1205814941302 [[],[]] .chain = true := by decide
def e1205814941306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814941306 : Closed e1205814941306 ∧ code e1205814941306 = 5603861452410 := by decide
theorem cert_e1205814941306 : check e1205814941306 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814941494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814941494 : Closed e1205814941494 ∧ code e1205814941494 = 5603861452598 := by decide
theorem cert_e1205814941494 : check e1205814941494 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814941498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814941498 : Closed e1205814941498 ∧ code e1205814941498 = 5603861452602 := by decide
theorem cert_e1205814941498 : check e1205814941498 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814941754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e1205814941754 : Closed e1205814941754 ∧ code e1205814941754 = 5603861452858 := by decide
theorem cert_e1205814941754 : check e1205814941754 [[],[]] .chain = true := by decide
def e1205814941802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1205814941802 : Closed e1205814941802 ∧ code e1205814941802 = 5603861452906 := by decide
theorem cert_e1205814941802 : check e1205814941802 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e1205814941850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814941850 : Closed e1205814941850 ∧ code e1205814941850 = 5603861452954 := by decide
theorem cert_e1205814941850 : check e1205814941850 [[],[]] .chain = true := by decide
def e1205814941894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e1205814941894 : Closed e1205814941894 ∧ code e1205814941894 = 5603861452998 := by decide
theorem cert_e1205814941894 : check e1205814941894 [[],[]] .chain = true := by decide
def e1205814942090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814942090 : Closed e1205814942090 ∧ code e1205814942090 = 5603861453194 := by decide
theorem cert_e1205814942090 : check e1205814942090 [[],[]] .chain = true := by decide
def e1205814942114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814942114 : Closed e1205814942114 ∧ code e1205814942114 = 5603861453218 := by decide
theorem cert_e1205814942114 : check e1205814942114 [[],[]] .chain = true := by decide
def e1205814942126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1205814942126 : Closed e1205814942126 ∧ code e1205814942126 = 5603861453230 := by decide
theorem cert_e1205814942126 : check e1205814942126 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1205814942134 : Closed e1205814942134 ∧ code e1205814942134 = 5603861453238 := by decide
theorem cert_e1205814942134 : check e1205814942134 [[],[]] .chain = true := by decide
def e1205814942138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1205814942138 : Closed e1205814942138 ∧ code e1205814942138 = 5603861453242 := by decide
theorem cert_e1205814942138 : check e1205814942138 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1205814942166 : Closed e1205814942166 ∧ code e1205814942166 = 5603861453270 := by decide
theorem cert_e1205814942166 : check e1205814942166 [[],[]] .chain = true := by decide
def e1205814942170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1205814942170 : Closed e1205814942170 ∧ code e1205814942170 = 5603861453274 := by decide
theorem cert_e1205814942170 : check e1205814942170 [[],[]] .chain = true := by decide
def e1205814942186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1205814942186 : Closed e1205814942186 ∧ code e1205814942186 = 5603861453290 := by decide
theorem cert_e1205814942186 : check e1205814942186 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e1205814942222 : Closed e1205814942222 ∧ code e1205814942222 = 5603861453326 := by decide
theorem cert_e1205814942222 : check e1205814942222 [[],[]] .chain = true := by decide
def e1205814942234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205814942234 : Closed e1205814942234 ∧ code e1205814942234 = 5603861453338 := by decide
theorem cert_e1205814942234 : check e1205814942234 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e1205814942306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205814942306 : Closed e1205814942306 ∧ code e1205814942306 = 5603861453410 := by decide
theorem cert_e1205814942306 : check e1205814942306 [[],[]] .chain = true := by decide
def e1205814942318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814942318 : Closed e1205814942318 ∧ code e1205814942318 = 5603861453422 := by decide
theorem cert_e1205814942318 : check e1205814942318 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1205814942326 : Closed e1205814942326 ∧ code e1205814942326 = 5603861453430 := by decide
theorem cert_e1205814942326 : check e1205814942326 [[],[]] .chain = true := by decide
end Blc.Floor42
