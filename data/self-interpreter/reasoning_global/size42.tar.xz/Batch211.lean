import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211206311566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211206311566 : Closed e1211206311566 ∧ code e1211206311566 = 5609252822670 := by decide
theorem cert_e1211206311566 : check e1211206311566 [[],[]] .smaller = true := by decide
def e1211206311622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211206311622 : Closed e1211206311622 ∧ code e1211206311622 = 5609252822726 := by decide
theorem cert_e1211206311622 : check e1211206311622 [[],[]] .smaller = true := by decide
def e1211206311646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e1211206311646 : Closed e1211206311646 ∧ code e1211206311646 = 5609252822750 := by decide
theorem cert_e1211206311646 : check e1211206311646 [[],[]] .chain = true := by decide
def e1211206311670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e1211206311670 : Closed e1211206311670 ∧ code e1211206311670 = 5609252822774 := by decide
theorem cert_e1211206311670 : check e1211206311670 [[],[]] .chain = true := by decide
def e1211206311702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211206311702 : Closed e1211206311702 ∧ code e1211206311702 = 5609252822806 := by decide
theorem cert_e1211206311702 : check e1211206311702 [[],[]] .chain = true := by decide
def e1211206311778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211206311778 : Closed e1211206311778 ∧ code e1211206311778 = 5609252822882 := by decide
theorem cert_e1211206311778 : check e1211206311778 [[],[]] .chain = true := by decide
def e1211206311790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e1211206311790 : Closed e1211206311790 ∧ code e1211206311790 = 5609252822894 := by decide
theorem cert_e1211206311790 : check e1211206311790 [[],[]] .chain = true := by decide
def e1211206311798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e1211206311798 : Closed e1211206311798 ∧ code e1211206311798 = 5609252822902 := by decide
theorem cert_e1211206311798 : check e1211206311798 [[],[]] .chain = true := by decide
def e1211206313758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211206313758 : Closed e1211206313758 ∧ code e1211206313758 = 5609252824862 := by decide
theorem cert_e1211206313758 : check e1211206313758 [[],[]] .smaller = true := by decide
def e1211206313870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211206313870 : Closed e1211206313870 ∧ code e1211206313870 = 5609252824974 := by decide
theorem cert_e1211206313870 : check e1211206313870 [[],[]] .smaller = true := by decide
def e1211206316158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211206316158 : Closed e1211206316158 ∧ code e1211206316158 = 5609252827262 := by decide
theorem cert_e1211206316158 : check e1211206316158 [[],[]] .chain = true := by decide
def e1211206316254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206316254 : Closed e1211206316254 ∧ code e1211206316254 = 5609252827358 := by decide
theorem cert_e1211206316254 : check e1211206316254 [[],[]] .smaller = true := by decide
def e1211206316282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206316282 : Closed e1211206316282 ∧ code e1211206316282 = 5609252827386 := by decide
theorem cert_e1211206316282 : check e1211206316282 [[],[]] .smaller = true := by decide
def e1211206316830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211206316830 : Closed e1211206316830 ∧ code e1211206316830 = 5609252827934 := by decide
theorem cert_e1211206316830 : check e1211206316830 [[],[]] .smaller = true := by decide
def e1211206316998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211206316998 : Closed e1211206316998 ∧ code e1211206316998 = 5609252828102 := by decide
theorem cert_e1211206316998 : check e1211206316998 [[],[]] .smaller = true := by decide
def e1211206317022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211206317022 : Closed e1211206317022 ∧ code e1211206317022 = 5609252828126 := by decide
theorem cert_e1211206317022 : check e1211206317022 [[],[]] .chain = true := by decide
def e1211206317026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211206317026 : Closed e1211206317026 ∧ code e1211206317026 = 5609252828130 := by decide
theorem cert_e1211206317026 : check e1211206317026 [[],[]] .chain = true := by decide
def e1211206317038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211206317038 : Closed e1211206317038 ∧ code e1211206317038 = 5609252828142 := by decide
theorem cert_e1211206317038 : check e1211206317038 [[],[]] .chain = true := by decide
def e1211206318190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211206318190 : Closed e1211206318190 ∧ code e1211206318190 = 5609252829294 := by decide
theorem cert_e1211206318190 : check e1211206318190 [[],[]] .smaller = true := by decide
def e1211206318202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211206318202 : Closed e1211206318202 ∧ code e1211206318202 = 5609252829306 := by decide
theorem cert_e1211206318202 : check e1211206318202 [[],[]] .smaller = true := by decide
def e1211206318478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211206318478 : Closed e1211206318478 ∧ code e1211206318478 = 5609252829582 := by decide
theorem cert_e1211206318478 : check e1211206318478 [[],[]] .smaller = true := by decide
def e1211206318534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211206318534 : Closed e1211206318534 ∧ code e1211206318534 = 5609252829638 := by decide
theorem cert_e1211206318534 : check e1211206318534 [[],[]] .smaller = true := by decide
def e1211206318558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211206318558 : Closed e1211206318558 ∧ code e1211206318558 = 5609252829662 := by decide
theorem cert_e1211206318558 : check e1211206318558 [[],[]] .chain = true := by decide
def e1211206318582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211206318582 : Closed e1211206318582 ∧ code e1211206318582 = 5609252829686 := by decide
theorem cert_e1211206318582 : check e1211206318582 [[],[]] .chain = true := by decide
def e1211206319134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211206319134 : Closed e1211206319134 ∧ code e1211206319134 = 5609252830238 := by decide
theorem cert_e1211206319134 : check e1211206319134 [[],[]] .chain = true := by decide
def e1211206319330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211206319330 : Closed e1211206319330 ∧ code e1211206319330 = 5609252830434 := by decide
theorem cert_e1211206319330 : check e1211206319330 [[],[]] .chain = true := by decide
def e1211206319342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211206319342 : Closed e1211206319342 ∧ code e1211206319342 = 5609252830446 := by decide
theorem cert_e1211206319342 : check e1211206319342 [[],[]] .chain = true := by decide
def e1211206319350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211206319350 : Closed e1211206319350 ∧ code e1211206319350 = 5609252830454 := by decide
theorem cert_e1211206319350 : check e1211206319350 [[],[]] .chain = true := by decide
def e1211206320606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211206320606 : Closed e1211206320606 ∧ code e1211206320606 = 5609252831710 := by decide
theorem cert_e1211206320606 : check e1211206320606 [[],[]] .chain = true := by decide
def e1211206320634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211206320634 : Closed e1211206320634 ∧ code e1211206320634 = 5609252831738 := by decide
theorem cert_e1211206320634 : check e1211206320634 [[],[]] .chain = true := by decide
def e1211206321006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211206321006 : Closed e1211206321006 ∧ code e1211206321006 = 5609252832110 := by decide
theorem cert_e1211206321006 : check e1211206321006 [[],[]] .smaller = true := by decide
def e1211206321018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211206321018 : Closed e1211206321018 ∧ code e1211206321018 = 5609252832122 := by decide
theorem cert_e1211206321018 : check e1211206321018 [[],[]] .smaller = true := by decide
def e1211206321070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211206321070 : Closed e1211206321070 ∧ code e1211206321070 = 5609252832174 := by decide
theorem cert_e1211206321070 : check e1211206321070 [[],[]] .smaller = true := by decide
def e1211206321130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211206321130 : Closed e1211206321130 ∧ code e1211206321130 = 5609252832234 := by decide
theorem cert_e1211206321130 : check e1211206321130 [[],[]] .smaller = true := by decide
def e1211206321374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211206321374 : Closed e1211206321374 ∧ code e1211206321374 = 5609252832478 := by decide
theorem cert_e1211206321374 : check e1211206321374 [[],[]] .chain = true := by decide
def e1211206321402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211206321402 : Closed e1211206321402 ∧ code e1211206321402 = 5609252832506 := by decide
theorem cert_e1211206321402 : check e1211206321402 [[],[]] .chain = true := by decide
def e1211206321726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211206321726 : Closed e1211206321726 ∧ code e1211206321726 = 5609252832830 := by decide
theorem cert_e1211206321726 : check e1211206321726 [[],[]] .chain = true := by decide
def e1211206321774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211206321774 : Closed e1211206321774 ∧ code e1211206321774 = 5609252832878 := by decide
theorem cert_e1211206321774 : check e1211206321774 [[],[]] .smaller = true := by decide
def e1211206321786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211206321786 : Closed e1211206321786 ∧ code e1211206321786 = 5609252832890 := by decide
theorem cert_e1211206321786 : check e1211206321786 [[],[]] .smaller = true := by decide
def e1211206322074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211206322074 : Closed e1211206322074 ∧ code e1211206322074 = 5609252833178 := by decide
theorem cert_e1211206322074 : check e1211206322074 [[],[]] .smaller = true := by decide
def e1211206322118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211206322118 : Closed e1211206322118 ∧ code e1211206322118 = 5609252833222 := by decide
theorem cert_e1211206322118 : check e1211206322118 [[],[]] .chain = true := by decide
def e1211206323294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211206323294 : Closed e1211206323294 ∧ code e1211206323294 = 5609252834398 := by decide
theorem cert_e1211206323294 : check e1211206323294 [[],[]] .chain = true := by decide
def e1211206323310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211206323310 : Closed e1211206323310 ∧ code e1211206323310 = 5609252834414 := by decide
theorem cert_e1211206323310 : check e1211206323310 [[],[]] .smaller = true := by decide
def e1211206323322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211206323322 : Closed e1211206323322 ∧ code e1211206323322 = 5609252834426 := by decide
theorem cert_e1211206323322 : check e1211206323322 [[],[]] .smaller = true := by decide
def e1211206323486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211206323486 : Closed e1211206323486 ∧ code e1211206323486 = 5609252834590 := by decide
theorem cert_e1211206323486 : check e1211206323486 [[],[]] .smaller = true := by decide
def e1211206323654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211206323654 : Closed e1211206323654 ∧ code e1211206323654 = 5609252834758 := by decide
theorem cert_e1211206323654 : check e1211206323654 [[],[]] .smaller = true := by decide
def e1211206323678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211206323678 : Closed e1211206323678 ∧ code e1211206323678 = 5609252834782 := by decide
theorem cert_e1211206323678 : check e1211206323678 [[],[]] .chain = true := by decide
def e1211206323682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211206323682 : Closed e1211206323682 ∧ code e1211206323682 = 5609252834786 := by decide
theorem cert_e1211206323682 : check e1211206323682 [[],[]] .chain = true := by decide
def e1211206323694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211206323694 : Closed e1211206323694 ∧ code e1211206323694 = 5609252834798 := by decide
theorem cert_e1211206323694 : check e1211206323694 [[],[]] .chain = true := by decide
def e1211206323994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211206323994 : Closed e1211206323994 ∧ code e1211206323994 = 5609252835098 := by decide
theorem cert_e1211206323994 : check e1211206323994 [[],[]] .smaller = true := by decide
def e1211206324038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211206324038 : Closed e1211206324038 ∧ code e1211206324038 = 5609252835142 := by decide
theorem cert_e1211206324038 : check e1211206324038 [[],[]] .smaller = true := by decide
def e1211206324062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211206324062 : Closed e1211206324062 ∧ code e1211206324062 = 5609252835166 := by decide
theorem cert_e1211206324062 : check e1211206324062 [[],[]] .chain = true := by decide
def e1211206324090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211206324090 : Closed e1211206324090 ∧ code e1211206324090 = 5609252835194 := by decide
theorem cert_e1211206324090 : check e1211206324090 [[],[]] .chain = true := by decide
def e1211206324106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211206324106 : Closed e1211206324106 ∧ code e1211206324106 = 5609252835210 := by decide
theorem cert_e1211206324106 : check e1211206324106 [[],[]] .chain = true := by decide
def e1211206324130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211206324130 : Closed e1211206324130 ∧ code e1211206324130 = 5609252835234 := by decide
theorem cert_e1211206324130 : check e1211206324130 [[],[]] .chain = true := by decide
def e1211206324142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211206324142 : Closed e1211206324142 ∧ code e1211206324142 = 5609252835246 := by decide
theorem cert_e1211206324142 : check e1211206324142 [[],[]] .chain = true := by decide
def e1211206324154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211206324154 : Closed e1211206324154 ∧ code e1211206324154 = 5609252835258 := by decide
theorem cert_e1211206324154 : check e1211206324154 [[],[]] .chain = true := by decide
def e1211206324350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211206324350 : Closed e1211206324350 ∧ code e1211206324350 = 5609252835454 := by decide
theorem cert_e1211206324350 : check e1211206324350 [[],[]] .chain = true := by decide
def e1211206324446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206324446 : Closed e1211206324446 ∧ code e1211206324446 = 5609252835550 := by decide
theorem cert_e1211206324446 : check e1211206324446 [[],[]] .smaller = true := by decide
def e1211206324474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206324474 : Closed e1211206324474 ∧ code e1211206324474 = 5609252835578 := by decide
theorem cert_e1211206324474 : check e1211206324474 [[],[]] .smaller = true := by decide
def e1211206325022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211206325022 : Closed e1211206325022 ∧ code e1211206325022 = 5609252836126 := by decide
theorem cert_e1211206325022 : check e1211206325022 [[],[]] .smaller = true := by decide
def e1211206325190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211206325190 : Closed e1211206325190 ∧ code e1211206325190 = 5609252836294 := by decide
theorem cert_e1211206325190 : check e1211206325190 [[],[]] .smaller = true := by decide
def e1211206325214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211206325214 : Closed e1211206325214 ∧ code e1211206325214 = 5609252836318 := by decide
theorem cert_e1211206325214 : check e1211206325214 [[],[]] .chain = true := by decide
def e1211206325218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211206325218 : Closed e1211206325218 ∧ code e1211206325218 = 5609252836322 := by decide
theorem cert_e1211206325218 : check e1211206325218 [[],[]] .chain = true := by decide
def e1211206325230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211206325230 : Closed e1211206325230 ∧ code e1211206325230 = 5609252836334 := by decide
theorem cert_e1211206325230 : check e1211206325230 [[],[]] .chain = true := by decide
def e1211206327350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206327350 : Closed e1211206327350 ∧ code e1211206327350 = 5609252838454 := by decide
theorem cert_e1211206327350 : check e1211206327350 [[],[]] .smaller = true := by decide
def e1211206327354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206327354 : Closed e1211206327354 ∧ code e1211206327354 = 5609252838458 := by decide
theorem cert_e1211206327354 : check e1211206327354 [[],[]] .smaller = true := by decide
def e1211206327494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211206327494 : Closed e1211206327494 ∧ code e1211206327494 = 5609252838598 := by decide
theorem cert_e1211206327494 : check e1211206327494 [[],[]] .smaller = true := by decide
def e1211206327518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211206327518 : Closed e1211206327518 ∧ code e1211206327518 = 5609252838622 := by decide
theorem cert_e1211206327518 : check e1211206327518 [[],[]] .chain = true := by decide
def e1211206327546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211206327546 : Closed e1211206327546 ∧ code e1211206327546 = 5609252838650 := by decide
theorem cert_e1211206327546 : check e1211206327546 [[],[]] .chain = true := by decide
def e1211206327822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211206327822 : Closed e1211206327822 ∧ code e1211206327822 = 5609252838926 := by decide
theorem cert_e1211206327822 : check e1211206327822 [[],[]] .chain = true := by decide
def e1211206327906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211206327906 : Closed e1211206327906 ∧ code e1211206327906 = 5609252839010 := by decide
theorem cert_e1211206327906 : check e1211206327906 [[],[]] .chain = true := by decide
def e1211206327918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211206327918 : Closed e1211206327918 ∧ code e1211206327918 = 5609252839022 := by decide
theorem cert_e1211206327918 : check e1211206327918 [[],[]] .chain = true := by decide
def e1211206327930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211206327930 : Closed e1211206327930 ∧ code e1211206327930 = 5609252839034 := by decide
theorem cert_e1211206327930 : check e1211206327930 [[],[]] .chain = true := by decide
def e1211206328758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211206328758 : Closed e1211206328758 ∧ code e1211206328758 = 5609252839862 := by decide
theorem cert_e1211206328758 : check e1211206328758 [[],[]] .smaller = true := by decide
def e1211206328762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e1211206328762 : Closed e1211206328762 ∧ code e1211206328762 = 5609252839866 := by decide
theorem cert_e1211206328762 : check e1211206328762 [[],[]] .smaller = true := by decide
def e1211206328790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211206328790 : Closed e1211206328790 ∧ code e1211206328790 = 5609252839894 := by decide
theorem cert_e1211206328790 : check e1211206328790 [[],[]] .smaller = true := by decide
def e1211206328810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e1211206328810 : Closed e1211206328810 ∧ code e1211206328810 = 5609252839914 := by decide
theorem cert_e1211206328810 : check e1211206328810 [[],[]] .smaller = true := by decide
def e1211206329142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211206329142 : Closed e1211206329142 ∧ code e1211206329142 = 5609252840246 := by decide
theorem cert_e1211206329142 : check e1211206329142 [[],[]] .smaller = true := by decide
def e1211206329146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211206329146 : Closed e1211206329146 ∧ code e1211206329146 = 5609252840250 := by decide
theorem cert_e1211206329146 : check e1211206329146 [[],[]] .smaller = true := by decide
def e1211206329242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211206329242 : Closed e1211206329242 ∧ code e1211206329242 = 5609252840346 := by decide
theorem cert_e1211206329242 : check e1211206329242 [[],[]] .smaller = true := by decide
def e1211206329310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211206329310 : Closed e1211206329310 ∧ code e1211206329310 = 5609252840414 := by decide
theorem cert_e1211206329310 : check e1211206329310 [[],[]] .chain = true := by decide
def e1211206329326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211206329326 : Closed e1211206329326 ∧ code e1211206329326 = 5609252840430 := by decide
theorem cert_e1211206329326 : check e1211206329326 [[],[]] .chain = true := by decide
def e1211206329910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211206329910 : Closed e1211206329910 ∧ code e1211206329910 = 5609252841014 := by decide
theorem cert_e1211206329910 : check e1211206329910 [[],[]] .smaller = true := by decide
def e1211206329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211206329914 : Closed e1211206329914 ∧ code e1211206329914 = 5609252841018 := by decide
theorem cert_e1211206329914 : check e1211206329914 [[],[]] .smaller = true := by decide
def e1211206329998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211206329998 : Closed e1211206329998 ∧ code e1211206329998 = 5609252841102 := by decide
theorem cert_e1211206329998 : check e1211206329998 [[],[]] .smaller = true := by decide
def e1211206330054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211206330054 : Closed e1211206330054 ∧ code e1211206330054 = 5609252841158 := by decide
theorem cert_e1211206330054 : check e1211206330054 [[],[]] .smaller = true := by decide
def e1211206330078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211206330078 : Closed e1211206330078 ∧ code e1211206330078 = 5609252841182 := by decide
theorem cert_e1211206330078 : check e1211206330078 [[],[]] .chain = true := by decide
def e1211206330102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211206330102 : Closed e1211206330102 ∧ code e1211206330102 = 5609252841206 := by decide
theorem cert_e1211206330102 : check e1211206330102 [[],[]] .chain = true := by decide
def e1211206330138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211206330138 : Closed e1211206330138 ∧ code e1211206330138 = 5609252841242 := by decide
theorem cert_e1211206330138 : check e1211206330138 [[],[]] .smaller = true := by decide
def e1211206330182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211206330182 : Closed e1211206330182 ∧ code e1211206330182 = 5609252841286 := by decide
theorem cert_e1211206330182 : check e1211206330182 [[],[]] .smaller = true := by decide
def e1211206330206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211206330206 : Closed e1211206330206 ∧ code e1211206330206 = 5609252841310 := by decide
theorem cert_e1211206330206 : check e1211206330206 [[],[]] .chain = true := by decide
def e1211206330234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211206330234 : Closed e1211206330234 ∧ code e1211206330234 = 5609252841338 := by decide
theorem cert_e1211206330234 : check e1211206330234 [[],[]] .chain = true := by decide
def e1211206330326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211206330326 : Closed e1211206330326 ∧ code e1211206330326 = 5609252841430 := by decide
theorem cert_e1211206330326 : check e1211206330326 [[],[]] .chain = true := by decide
def e1211206330330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211206330330 : Closed e1211206330330 ∧ code e1211206330330 = 5609252841434 := by decide
theorem cert_e1211206330330 : check e1211206330330 [[],[]] .chain = true := by decide
def e1211206330478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211206330478 : Closed e1211206330478 ∧ code e1211206330478 = 5609252841582 := by decide
theorem cert_e1211206330478 : check e1211206330478 [[],[]] .smaller = true := by decide
def e1211206330490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211206330490 : Closed e1211206330490 ∧ code e1211206330490 = 5609252841594 := by decide
theorem cert_e1211206330490 : check e1211206330490 [[],[]] .smaller = true := by decide
def e1211206330766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211206330766 : Closed e1211206330766 ∧ code e1211206330766 = 5609252841870 := by decide
theorem cert_e1211206330766 : check e1211206330766 [[],[]] .smaller = true := by decide
def e1211206330822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211206330822 : Closed e1211206330822 ∧ code e1211206330822 = 5609252841926 := by decide
theorem cert_e1211206330822 : check e1211206330822 [[],[]] .smaller = true := by decide
def e1211206330846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211206330846 : Closed e1211206330846 ∧ code e1211206330846 = 5609252841950 := by decide
theorem cert_e1211206330846 : check e1211206330846 [[],[]] .chain = true := by decide
def e1211206330870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211206330870 : Closed e1211206330870 ∧ code e1211206330870 = 5609252841974 := by decide
theorem cert_e1211206330870 : check e1211206330870 [[],[]] .chain = true := by decide
def e1211206331446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206331446 : Closed e1211206331446 ∧ code e1211206331446 = 5609252842550 := by decide
theorem cert_e1211206331446 : check e1211206331446 [[],[]] .smaller = true := by decide
def e1211206331450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206331450 : Closed e1211206331450 ∧ code e1211206331450 = 5609252842554 := by decide
theorem cert_e1211206331450 : check e1211206331450 [[],[]] .smaller = true := by decide
def e1211206331590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211206331590 : Closed e1211206331590 ∧ code e1211206331590 = 5609252842694 := by decide
theorem cert_e1211206331590 : check e1211206331590 [[],[]] .smaller = true := by decide
def e1211206331614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211206331614 : Closed e1211206331614 ∧ code e1211206331614 = 5609252842718 := by decide
theorem cert_e1211206331614 : check e1211206331614 [[],[]] .chain = true := by decide
def e1211206331642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211206331642 : Closed e1211206331642 ∧ code e1211206331642 = 5609252842746 := by decide
theorem cert_e1211206331642 : check e1211206331642 [[],[]] .chain = true := by decide
def e1211206331966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211206331966 : Closed e1211206331966 ∧ code e1211206331966 = 5609252843070 := by decide
theorem cert_e1211206331966 : check e1211206331966 [[],[]] .chain = true := by decide
def e1211206332190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211206332190 : Closed e1211206332190 ∧ code e1211206332190 = 5609252843294 := by decide
theorem cert_e1211206332190 : check e1211206332190 [[],[]] .chain = true := by decide
def e1211206332214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211206332214 : Closed e1211206332214 ∧ code e1211206332214 = 5609252843318 := by decide
theorem cert_e1211206332214 : check e1211206332214 [[],[]] .chain = true := by decide
def e1211206332218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211206332218 : Closed e1211206332218 ∧ code e1211206332218 = 5609252843322 := by decide
theorem cert_e1211206332218 : check e1211206332218 [[],[]] .chain = true := by decide
def e1211206332534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211206332534 : Closed e1211206332534 ∧ code e1211206332534 = 5609252843638 := by decide
theorem cert_e1211206332534 : check e1211206332534 [[],[]] .chain = true := by decide
def e1211206332538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211206332538 : Closed e1211206332538 ∧ code e1211206332538 = 5609252843642 := by decide
theorem cert_e1211206332538 : check e1211206332538 [[],[]] .chain = true := by decide
def e1211206332726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211206332726 : Closed e1211206332726 ∧ code e1211206332726 = 5609252843830 := by decide
theorem cert_e1211206332726 : check e1211206332726 [[],[]] .chain = true := by decide
def e1211206332730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211206332730 : Closed e1211206332730 ∧ code e1211206332730 = 5609252843834 := by decide
theorem cert_e1211206332730 : check e1211206332730 [[],[]] .chain = true := by decide
def e1211206332814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211206332814 : Closed e1211206332814 ∧ code e1211206332814 = 5609252843918 := by decide
theorem cert_e1211206332814 : check e1211206332814 [[],[]] .chain = true := by decide
def e1211206332870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211206332870 : Closed e1211206332870 ∧ code e1211206332870 = 5609252843974 := by decide
theorem cert_e1211206332870 : check e1211206332870 [[],[]] .chain = true := by decide
def e1211206332910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211206332910 : Closed e1211206332910 ∧ code e1211206332910 = 5609252844014 := by decide
theorem cert_e1211206332910 : check e1211206332910 [[],[]] .chain = true := by decide
def e1211206333206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211206333206 : Closed e1211206333206 ∧ code e1211206333206 = 5609252844310 := by decide
theorem cert_e1211206333206 : check e1211206333206 [[],[]] .chain = true := by decide
def e1211206333282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211206333282 : Closed e1211206333282 ∧ code e1211206333282 = 5609252844386 := by decide
theorem cert_e1211206333282 : check e1211206333282 [[],[]] .chain = true := by decide
def e1211206333294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211206333294 : Closed e1211206333294 ∧ code e1211206333294 = 5609252844398 := by decide
theorem cert_e1211206333294 : check e1211206333294 [[],[]] .chain = true := by decide
def e1211206333302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211206333302 : Closed e1211206333302 ∧ code e1211206333302 = 5609252844406 := by decide
theorem cert_e1211206333302 : check e1211206333302 [[],[]] .chain = true := by decide
def e1211206333322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211206333322 : Closed e1211206333322 ∧ code e1211206333322 = 5609252844426 := by decide
theorem cert_e1211206333322 : check e1211206333322 [[],[]] .chain = true := by decide
def e1211206333346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211206333346 : Closed e1211206333346 ∧ code e1211206333346 = 5609252844450 := by decide
theorem cert_e1211206333346 : check e1211206333346 [[],[]] .chain = true := by decide
def e1211206333358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211206333358 : Closed e1211206333358 ∧ code e1211206333358 = 5609252844462 := by decide
theorem cert_e1211206333358 : check e1211206333358 [[],[]] .chain = true := by decide
def e1211206333370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211206333370 : Closed e1211206333370 ∧ code e1211206333370 = 5609252844474 := by decide
theorem cert_e1211206333370 : check e1211206333370 [[],[]] .chain = true := by decide
def e1211206333398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211206333398 : Closed e1211206333398 ∧ code e1211206333398 = 5609252844502 := by decide
theorem cert_e1211206333398 : check e1211206333398 [[],[]] .chain = true := by decide
def e1211206333402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211206333402 : Closed e1211206333402 ∧ code e1211206333402 = 5609252844506 := by decide
theorem cert_e1211206333402 : check e1211206333402 [[],[]] .chain = true := by decide
def e1211206333470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211206333470 : Closed e1211206333470 ∧ code e1211206333470 = 5609252844574 := by decide
theorem cert_e1211206333470 : check e1211206333470 [[],[]] .chain = true := by decide
def e1211206333666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211206333666 : Closed e1211206333666 ∧ code e1211206333666 = 5609252844770 := by decide
theorem cert_e1211206333666 : check e1211206333666 [[],[]] .chain = true := by decide
def e1211206333678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211206333678 : Closed e1211206333678 ∧ code e1211206333678 = 5609252844782 := by decide
theorem cert_e1211206333678 : check e1211206333678 [[],[]] .chain = true := by decide
def e1211206333686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211206333686 : Closed e1211206333686 ∧ code e1211206333686 = 5609252844790 := by decide
theorem cert_e1211206333686 : check e1211206333686 [[],[]] .chain = true := by decide
def e1211206333966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211206333966 : Closed e1211206333966 ∧ code e1211206333966 = 5609252845070 := by decide
theorem cert_e1211206333966 : check e1211206333966 [[],[]] .chain = true := by decide
def e1211206334050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211206334050 : Closed e1211206334050 ∧ code e1211206334050 = 5609252845154 := by decide
theorem cert_e1211206334050 : check e1211206334050 [[],[]] .chain = true := by decide
def e1211206334062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211206334062 : Closed e1211206334062 ∧ code e1211206334062 = 5609252845166 := by decide
theorem cert_e1211206334062 : check e1211206334062 [[],[]] .chain = true := by decide
def e1211206334074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211206334074 : Closed e1211206334074 ∧ code e1211206334074 = 5609252845178 := by decide
theorem cert_e1211206334074 : check e1211206334074 [[],[]] .chain = true := by decide
def e1211206334238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211206334238 : Closed e1211206334238 ∧ code e1211206334238 = 5609252845342 := by decide
theorem cert_e1211206334238 : check e1211206334238 [[],[]] .chain = true := by decide
def e1211206334262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211206334262 : Closed e1211206334262 ∧ code e1211206334262 = 5609252845366 := by decide
theorem cert_e1211206334262 : check e1211206334262 [[],[]] .chain = true := by decide
def e1211206334266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211206334266 : Closed e1211206334266 ∧ code e1211206334266 = 5609252845370 := by decide
theorem cert_e1211206334266 : check e1211206334266 [[],[]] .chain = true := by decide
def e1211206342366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211206342366 : Closed e1211206342366 ∧ code e1211206342366 = 5609252853470 := by decide
theorem cert_e1211206342366 : check e1211206342366 [[],[]] .smaller = true := by decide
def e1211206342390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211206342390 : Closed e1211206342390 ∧ code e1211206342390 = 5609252853494 := by decide
theorem cert_e1211206342390 : check e1211206342390 [[],[]] .smaller = true := by decide
def e1211206342494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211206342494 : Closed e1211206342494 ∧ code e1211206342494 = 5609252853598 := by decide
theorem cert_e1211206342494 : check e1211206342494 [[],[]] .smaller = true := by decide
def e1211206342522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211206342522 : Closed e1211206342522 ∧ code e1211206342522 = 5609252853626 := by decide
theorem cert_e1211206342522 : check e1211206342522 [[],[]] .smaller = true := by decide
def e1211206342614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211206342614 : Closed e1211206342614 ∧ code e1211206342614 = 5609252853718 := by decide
theorem cert_e1211206342614 : check e1211206342614 [[],[]] .smaller = true := by decide
def e1211206342618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211206342618 : Closed e1211206342618 ∧ code e1211206342618 = 5609252853722 := by decide
theorem cert_e1211206342618 : check e1211206342618 [[],[]] .smaller = true := by decide
def e1211206343134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211206343134 : Closed e1211206343134 ∧ code e1211206343134 = 5609252854238 := by decide
theorem cert_e1211206343134 : check e1211206343134 [[],[]] .smaller = true := by decide
def e1211206343158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211206343158 : Closed e1211206343158 ∧ code e1211206343158 = 5609252854262 := by decide
theorem cert_e1211206343158 : check e1211206343158 [[],[]] .smaller = true := by decide
def e1211206343902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211206343902 : Closed e1211206343902 ∧ code e1211206343902 = 5609252855006 := by decide
theorem cert_e1211206343902 : check e1211206343902 [[],[]] .smaller = true := by decide
def e1211206343930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211206343930 : Closed e1211206343930 ∧ code e1211206343930 = 5609252855034 := by decide
theorem cert_e1211206343930 : check e1211206343930 [[],[]] .smaller = true := by decide
def e1211206344254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211206344254 : Closed e1211206344254 ∧ code e1211206344254 = 5609252855358 := by decide
theorem cert_e1211206344254 : check e1211206344254 [[],[]] .smaller = true := by decide
def e1211206344478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211206344478 : Closed e1211206344478 ∧ code e1211206344478 = 5609252855582 := by decide
theorem cert_e1211206344478 : check e1211206344478 [[],[]] .smaller = true := by decide
def e1211206344502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206344502 : Closed e1211206344502 ∧ code e1211206344502 = 5609252855606 := by decide
theorem cert_e1211206344502 : check e1211206344502 [[],[]] .smaller = true := by decide
def e1211206344506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206344506 : Closed e1211206344506 ∧ code e1211206344506 = 5609252855610 := by decide
theorem cert_e1211206344506 : check e1211206344506 [[],[]] .smaller = true := by decide
def e1211206359278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211206359278 : Closed e1211206359278 ∧ code e1211206359278 = 5609252870382 := by decide
theorem cert_e1211206359278 : check e1211206359278 [[],[]] .smaller = true := by decide
def e1211206359286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211206359286 : Closed e1211206359286 ∧ code e1211206359286 = 5609252870390 := by decide
theorem cert_e1211206359286 : check e1211206359286 [[],[]] .smaller = true := by decide
def e1211206359838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211206359838 : Closed e1211206359838 ∧ code e1211206359838 = 5609252870942 := by decide
theorem cert_e1211206359838 : check e1211206359838 [[],[]] .smaller = true := by decide
def e1211206359950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211206359950 : Closed e1211206359950 ∧ code e1211206359950 = 5609252871054 := by decide
theorem cert_e1211206359950 : check e1211206359950 [[],[]] .smaller = true := by decide
def e1211206360158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211206360158 : Closed e1211206360158 ∧ code e1211206360158 = 5609252871262 := by decide
theorem cert_e1211206360158 : check e1211206360158 [[],[]] .chain = true := by decide
def e1211206360174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211206360174 : Closed e1211206360174 ∧ code e1211206360174 = 5609252871278 := by decide
theorem cert_e1211206360174 : check e1211206360174 [[],[]] .smaller = true := by decide
def e1211206360186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211206360186 : Closed e1211206360186 ∧ code e1211206360186 = 5609252871290 := by decide
theorem cert_e1211206360186 : check e1211206360186 [[],[]] .smaller = true := by decide
def e1211206360350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211206360350 : Closed e1211206360350 ∧ code e1211206360350 = 5609252871454 := by decide
theorem cert_e1211206360350 : check e1211206360350 [[],[]] .smaller = true := by decide
end Blc.Floor42
