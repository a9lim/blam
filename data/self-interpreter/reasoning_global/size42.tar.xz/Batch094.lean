import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1204402834350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204402834350 : Closed e1204402834350 ∧ code e1204402834350 = 5602449345454 := by decide
theorem cert_e1204402834350 : check e1204402834350 [[],[]] .smaller = true := by decide
def e1204402834362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204402834362 : Closed e1204402834362 ∧ code e1204402834362 = 5602449345466 := by decide
theorem cert_e1204402834362 : check e1204402834362 [[],[]] .smaller = true := by decide
def e1204402834390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204402834390 : Closed e1204402834390 ∧ code e1204402834390 = 5602449345494 := by decide
theorem cert_e1204402834390 : check e1204402834390 [[],[]] .smaller = true := by decide
def e1204402834394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204402834394 : Closed e1204402834394 ∧ code e1204402834394 = 5602449345498 := by decide
theorem cert_e1204402834394 : check e1204402834394 [[],[]] .smaller = true := by decide
def e1204402834670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204402834670 : Closed e1204402834670 ∧ code e1204402834670 = 5602449345774 := by decide
theorem cert_e1204402834670 : check e1204402834670 [[],[]] .smaller = true := by decide
def e1204402834678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204402834678 : Closed e1204402834678 ∧ code e1204402834678 = 5602449345782 := by decide
theorem cert_e1204402834678 : check e1204402834678 [[],[]] .smaller = true := by decide
def e1204402835054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204402835054 : Closed e1204402835054 ∧ code e1204402835054 = 5602449346158 := by decide
theorem cert_e1204402835054 : check e1204402835054 [[],[]] .smaller = true := by decide
def e1204402835066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204402835066 : Closed e1204402835066 ∧ code e1204402835066 = 5602449346170 := by decide
theorem cert_e1204402835066 : check e1204402835066 [[],[]] .smaller = true := by decide
def e1204402835254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204402835254 : Closed e1204402835254 ∧ code e1204402835254 = 5602449346358 := by decide
theorem cert_e1204402835254 : check e1204402835254 [[],[]] .smaller = true := by decide
def e1204402835258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204402835258 : Closed e1204402835258 ∧ code e1204402835258 = 5602449346362 := by decide
theorem cert_e1204402835258 : check e1204402835258 [[],[]] .smaller = true := by decide
def e1204402841006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1204402841006 : Closed e1204402841006 ∧ code e1204402841006 = 5602449352110 := by decide
theorem cert_e1204402841006 : check e1204402841006 [[],[]] .smaller = true := by decide
def e1204402841018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1204402841018 : Closed e1204402841018 ∧ code e1204402841018 = 5602449352122 := by decide
theorem cert_e1204402841018 : check e1204402841018 [[],[]] .smaller = true := by decide
def e1204402841066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1204402841066 : Closed e1204402841066 ∧ code e1204402841066 = 5602449352170 := by decide
theorem cert_e1204402841066 : check e1204402841066 [[],[]] .smaller = true := by decide
def e1204402841198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204402841198 : Closed e1204402841198 ∧ code e1204402841198 = 5602449352302 := by decide
theorem cert_e1204402841198 : check e1204402841198 [[],[]] .smaller = true := by decide
def e1204402841210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204402841210 : Closed e1204402841210 ∧ code e1204402841210 = 5602449352314 := by decide
theorem cert_e1204402841210 : check e1204402841210 [[],[]] .smaller = true := by decide
def e1204402841498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1204402841498 : Closed e1204402841498 ∧ code e1204402841498 = 5602449352602 := by decide
theorem cert_e1204402841498 : check e1204402841498 [[],[]] .smaller = true := by decide
def e1204402844374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1204402844374 : Closed e1204402844374 ∧ code e1204402844374 = 5602449355478 := by decide
theorem cert_e1204402844374 : check e1204402844374 [[],[]] .smaller = true := by decide
def e1204402844378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1204402844378 : Closed e1204402844378 ∧ code e1204402844378 = 5602449355482 := by decide
theorem cert_e1204402844378 : check e1204402844378 [[],[]] .smaller = true := by decide
def e1204402844394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1204402844394 : Closed e1204402844394 ∧ code e1204402844394 = 5602449355498 := by decide
theorem cert_e1204402844394 : check e1204402844394 [[],[]] .smaller = true := by decide
def e1204402844470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204402844470 : Closed e1204402844470 ∧ code e1204402844470 = 5602449355574 := by decide
theorem cert_e1204402844470 : check e1204402844470 [[],[]] .smaller = true := by decide
def e1204402844474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204402844474 : Closed e1204402844474 ∧ code e1204402844474 = 5602449355578 := by decide
theorem cert_e1204402844474 : check e1204402844474 [[],[]] .smaller = true := by decide
def e1204402844570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1204402844570 : Closed e1204402844570 ∧ code e1204402844570 = 5602449355674 := by decide
theorem cert_e1204402844570 : check e1204402844570 [[],[]] .smaller = true := by decide
def e1204402960110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1204402960110 : Closed e1204402960110 ∧ code e1204402960110 = 5602449471214 := by decide
theorem cert_e1204402960110 : check e1204402960110 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1204402960238 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1204402960238 : Closed e1204402960238 ∧ code e1204402960238 = 5602449471342 := by decide
theorem cert_e1204402960238 : check e1204402960238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204402960246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1204402960246 : Closed e1204402960246 ∧ code e1204402960246 = 5602449471350 := by decide
theorem cert_e1204402960246 : check e1204402960246 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204402961134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1204402961134 : Closed e1204402961134 ∧ code e1204402961134 = 5602449472238 := by decide
theorem cert_e1204402961134 : check e1204402961134 [[],[]] .sourceHead = true := by decide
def e1204402961326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1204402961326 : Closed e1204402961326 ∧ code e1204402961326 = 5602449472430 := by decide
theorem cert_e1204402961326 : check e1204402961326 [[],[]] .sourceHead = true := by decide
def e1204402961338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1204402961338 : Closed e1204402961338 ∧ code e1204402961338 = 5602449472442 := by decide
theorem cert_e1204402961338 : check e1204402961338 [[],[]] .sourceHead = true := by decide
def e1204402961774 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1204402961774 : Closed e1204402961774 ∧ code e1204402961774 = 5602449472878 := by decide
theorem cert_e1204402961774 : checkPay e1204402961774 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e1204402961782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1204402961782 : Closed e1204402961782 ∧ code e1204402961782 = 5602449472886 := by decide
theorem cert_e1204402961782 : check e1204402961782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left]] .identityHead = true := by decide
def e1204402961838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1204402961838 : Closed e1204402961838 ∧ code e1204402961838 = 5602449472942 := by decide
theorem cert_e1204402961838 : check e1204402961838 [[],[],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1204402961850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1204402961850 : Closed e1204402961850 ∧ code e1204402961850 = 5602449472954 := by decide
theorem cert_e1204402961850 : check e1204402961850 [[],[],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1204402961878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1204402961878 : Closed e1204402961878 ∧ code e1204402961878 = 5602449472982 := by decide
private def t_e1204402961878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e1204402961878 : ¬ IsSelfInterpreter e1204402961878 :=
  wSource (t := t_e1204402961878) (replay_sound (ps := []) (t := e1204402961878) (by decide)) (by decide)
def e1204402961882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1204402961882 : Closed e1204402961882 ∧ code e1204402961882 = 5602449472986 := by decide
private def t_e1204402961882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e1204402961882 : ¬ IsSelfInterpreter e1204402961882 :=
  wSource (t := t_e1204402961882) (replay_sound (ps := []) (t := e1204402961882) (by decide)) (by decide)
def e1204402966254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1204402966254 : Closed e1204402966254 ∧ code e1204402966254 = 5602449477358 := by decide
theorem cert_e1204402966254 : check e1204402966254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204402966382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1204402966382 : Closed e1204402966382 ∧ code e1204402966382 = 5602449477486 := by decide
theorem cert_e1204402966382 : check e1204402966382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1204402966390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1204402966390 : Closed e1204402966390 ∧ code e1204402966390 = 5602449477494 := by decide
theorem cert_e1204402966390 : check e1204402966390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1204402969070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1204402969070 : Closed e1204402969070 ∧ code e1204402969070 = 5602449480174 := by decide
theorem cert_e1204402969070 : check e1204402969070 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204402969838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204402969838 : Closed e1204402969838 ∧ code e1204402969838 = 5602449480942 := by decide
theorem cert_e1204402969838 : check e1204402969838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204402969846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204402969846 : Closed e1204402969846 ∧ code e1204402969846 = 5602449480950 := by decide
theorem cert_e1204402969846 : check e1204402969846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204402972398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1204402972398 : Closed e1204402972398 ∧ code e1204402972398 = 5602449483502 := by decide
theorem cert_e1204402972398 : checkPay e1204402972398 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1204402972590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1204402972590 : Closed e1204402972590 ∧ code e1204402972590 = 5602449483694 := by decide
theorem cert_e1204402972590 : checkPay e1204402972590 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] = true := by decide
def e1204402972602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1204402972602 : Closed e1204402972602 ∧ code e1204402972602 = 5602449483706 := by decide
theorem cert_e1204402972602 : checkPay e1204402972602 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1204402973166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1204402973166 : Closed e1204402973166 ∧ code e1204402973166 = 5602449484270 := by decide
theorem cert_e1204402973166 : checkPay e1204402973166 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204402974318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204402974318 : Closed e1204402974318 ∧ code e1204402974318 = 5602449485422 := by decide
theorem cert_e1204402974318 : checkPay e1204402974318 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204402974330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204402974330 : Closed e1204402974330 ∧ code e1204402974330 = 5602449485434 := by decide
theorem cert_e1204402974330 : checkPay e1204402974330 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204402975598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1204402975598 : Closed e1204402975598 ∧ code e1204402975598 = 5602449486702 := by decide
theorem cert_e1204402975598 : check e1204402975598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1204402975606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1204402975606 : Closed e1204402975606 ∧ code e1204402975606 = 5602449486710 := by decide
theorem cert_e1204402975606 : check e1204402975606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e1204402975662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1204402975662 : Closed e1204402975662 ∧ code e1204402975662 = 5602449486766 := by decide
theorem cert_e1204402975662 : check e1204402975662 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1204402975674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1204402975674 : Closed e1204402975674 ∧ code e1204402975674 = 5602449486778 := by decide
theorem cert_e1204402975674 : check e1204402975674 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1204402975702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1204402975702 : Closed e1204402975702 ∧ code e1204402975702 = 5602449486806 := by decide
theorem cert_e1204402975702 : check e1204402975702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1204402975706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1204402975706 : Closed e1204402975706 ∧ code e1204402975706 = 5602449486810 := by decide
theorem cert_e1204402975706 : check e1204402975706 [[],[],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1204402975982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204402975982 : Closed e1204402975982 ∧ code e1204402975982 = 5602449487086 := by decide
theorem cert_e1204402975982 : check e1204402975982 [[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1204402975990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204402975990 : Closed e1204402975990 ∧ code e1204402975990 = 5602449487094 := by decide
theorem cert_e1204402975990 : check e1204402975990 [[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e1204402976366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204402976366 : Closed e1204402976366 ∧ code e1204402976366 = 5602449487470 := by decide
theorem cert_e1204402976366 : checkPay e1204402976366 [[.left,.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1204402976378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204402976378 : Closed e1204402976378 ∧ code e1204402976378 = 5602449487482 := by decide
theorem cert_e1204402976378 : checkPay e1204402976378 [[.left,.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1204402976566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204402976566 : Closed e1204402976566 ∧ code e1204402976566 = 5602449487670 := by decide
private def t_e1204402976566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e1204402976566 : ¬ IsSelfInterpreter e1204402976566 :=
  wSource (t := t_e1204402976566) (replay_sound (ps := []) (t := e1204402976566) (by decide)) (by decide)
def e1204402976570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204402976570 : Closed e1204402976570 ∧ code e1204402976570 = 5602449487674 := by decide
private def t_e1204402976570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e1204402976570 : ¬ IsSelfInterpreter e1204402976570 :=
  wSource (t := t_e1204402976570) (replay_sound (ps := []) (t := e1204402976570) (by decide)) (by decide)
def e1204402981742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204402981742 : Closed e1204402981742 ∧ code e1204402981742 = 5602449492846 := by decide
theorem cert_e1204402981742 : check e1204402981742 [[],[]] .smaller = true := by decide
def e1204402981750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204402981750 : Closed e1204402981750 ∧ code e1204402981750 = 5602449492854 := by decide
theorem cert_e1204402981750 : check e1204402981750 [[],[]] .smaller = true := by decide
def e1204402981806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204402981806 : Closed e1204402981806 ∧ code e1204402981806 = 5602449492910 := by decide
theorem cert_e1204402981806 : check e1204402981806 [[],[]] .smaller = true := by decide
def e1204402981818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204402981818 : Closed e1204402981818 ∧ code e1204402981818 = 5602449492922 := by decide
theorem cert_e1204402981818 : check e1204402981818 [[],[]] .smaller = true := by decide
def e1204402981846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204402981846 : Closed e1204402981846 ∧ code e1204402981846 = 5602449492950 := by decide
theorem cert_e1204402981846 : check e1204402981846 [[],[]] .smaller = true := by decide
def e1204402981850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204402981850 : Closed e1204402981850 ∧ code e1204402981850 = 5602449492954 := by decide
theorem cert_e1204402981850 : check e1204402981850 [[],[]] .smaller = true := by decide
def e1204402982126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204402982126 : Closed e1204402982126 ∧ code e1204402982126 = 5602449493230 := by decide
theorem cert_e1204402982126 : check e1204402982126 [[],[]] .smaller = true := by decide
def e1204402982134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204402982134 : Closed e1204402982134 ∧ code e1204402982134 = 5602449493238 := by decide
theorem cert_e1204402982134 : check e1204402982134 [[],[]] .smaller = true := by decide
def e1204402982510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204402982510 : Closed e1204402982510 ∧ code e1204402982510 = 5602449493614 := by decide
theorem cert_e1204402982510 : check e1204402982510 [[],[]] .smaller = true := by decide
def e1204402982522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204402982522 : Closed e1204402982522 ∧ code e1204402982522 = 5602449493626 := by decide
theorem cert_e1204402982522 : check e1204402982522 [[],[]] .smaller = true := by decide
def e1204402982710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204402982710 : Closed e1204402982710 ∧ code e1204402982710 = 5602449493814 := by decide
theorem cert_e1204402982710 : check e1204402982710 [[],[]] .smaller = true := by decide
def e1204402982714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204402982714 : Closed e1204402982714 ∧ code e1204402982714 = 5602449493818 := by decide
theorem cert_e1204402982714 : check e1204402982714 [[],[]] .smaller = true := by decide
def e1204402990830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1204402990830 : Closed e1204402990830 ∧ code e1204402990830 = 5602449501934 := by decide
theorem cert_e1204402990830 : check e1204402990830 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204402990958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1204402990958 : Closed e1204402990958 ∧ code e1204402990958 = 5602449502062 := by decide
theorem cert_e1204402990958 : check e1204402990958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1204402990966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1204402990966 : Closed e1204402990966 ∧ code e1204402990966 = 5602449502070 := by decide
theorem cert_e1204402990966 : check e1204402990966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1204402993646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1204402993646 : Closed e1204402993646 ∧ code e1204402993646 = 5602449504750 := by decide
theorem cert_e1204402993646 : check e1204402993646 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204402994414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1204402994414 : Closed e1204402994414 ∧ code e1204402994414 = 5602449505518 := by decide
theorem cert_e1204402994414 : check e1204402994414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1204402994422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1204402994422 : Closed e1204402994422 ∧ code e1204402994422 = 5602449505526 := by decide
theorem cert_e1204402994422 : check e1204402994422 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1204403017454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1204403017454 : Closed e1204403017454 ∧ code e1204403017454 = 5602449528558 := by decide
theorem cert_e1204403017454 : check e1204403017454 [[],[]] .sourceHead = true := by decide
def e1204403017646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1204403017646 : Closed e1204403017646 ∧ code e1204403017646 = 5602449528750 := by decide
theorem cert_e1204403017646 : check e1204403017646 [[],[]] .sourceHead = true := by decide
def e1204403017658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1204403017658 : Closed e1204403017658 ∧ code e1204403017658 = 5602449528762 := by decide
theorem cert_e1204403017658 : check e1204403017658 [[],[]] .sourceHead = true := by decide
def e1204403018222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1204403018222 : Closed e1204403018222 ∧ code e1204403018222 = 5602449529326 := by decide
theorem cert_e1204403018222 : check e1204403018222 [[],[]] .sourceHead = true := by decide
def e1204403019374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1204403019374 : Closed e1204403019374 ∧ code e1204403019374 = 5602449530478 := by decide
theorem cert_e1204403019374 : check e1204403019374 [[],[]] .sourceHead = true := by decide
def e1204403019386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1204403019386 : Closed e1204403019386 ∧ code e1204403019386 = 5602449530490 := by decide
theorem cert_e1204403019386 : check e1204403019386 [[],[]] .sourceHead = true := by decide
def e1204403030894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204403030894 : Closed e1204403030894 ∧ code e1204403030894 = 5602449541998 := by decide
theorem cert_e1204403030894 : check e1204403030894 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1204403030902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204403030902 : Closed e1204403030902 ∧ code e1204403030902 = 5602449542006 := by decide
theorem cert_e1204403030902 : check e1204403030902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204403030958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204403030958 : Closed e1204403030958 ∧ code e1204403030958 = 5602449542062 := by decide
theorem cert_e1204403030958 : check e1204403030958 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1204403030970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204403030970 : Closed e1204403030970 ∧ code e1204403030970 = 5602449542074 := by decide
theorem cert_e1204403030970 : check e1204403030970 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1204403030998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204403030998 : Closed e1204403030998 ∧ code e1204403030998 = 5602449542102 := by decide
theorem cert_e1204403030998 : check e1204403030998 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1204403031002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204403031002 : Closed e1204403031002 ∧ code e1204403031002 = 5602449542106 := by decide
theorem cert_e1204403031002 : check e1204403031002 [[],[],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1204403031278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204403031278 : Closed e1204403031278 ∧ code e1204403031278 = 5602449542382 := by decide
theorem cert_e1204403031278 : check e1204403031278 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1204403031286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204403031286 : Closed e1204403031286 ∧ code e1204403031286 = 5602449542390 := by decide
theorem cert_e1204403031286 : check e1204403031286 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1204403031662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204403031662 : Closed e1204403031662 ∧ code e1204403031662 = 5602449542766 := by decide
theorem cert_e1204403031662 : checkPay e1204403031662 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1204403031674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204403031674 : Closed e1204403031674 ∧ code e1204403031674 = 5602449542778 := by decide
theorem cert_e1204403031674 : checkPay e1204403031674 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[],[.left],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] = true := by decide
def e1204403031862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204403031862 : Closed e1204403031862 ∧ code e1204403031862 = 5602449542966 := by decide
theorem cert_e1204403031862 : check e1204403031862 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1204403031866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204403031866 : Closed e1204403031866 ∧ code e1204403031866 = 5602449542970 := by decide
theorem cert_e1204403031866 : check e1204403031866 [[],[],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1204403571566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204403571566 : Closed e1204403571566 ∧ code e1204403571566 = 5602450082670 := by decide
theorem cert_e1204403571566 : check e1204403571566 [[],[]] .smaller = true := by decide
def e1204403571574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204403571574 : Closed e1204403571574 ∧ code e1204403571574 = 5602450082678 := by decide
theorem cert_e1204403571574 : check e1204403571574 [[],[]] .smaller = true := by decide
def e1204403571630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204403571630 : Closed e1204403571630 ∧ code e1204403571630 = 5602450082734 := by decide
theorem cert_e1204403571630 : check e1204403571630 [[],[]] .smaller = true := by decide
def e1204403571642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204403571642 : Closed e1204403571642 ∧ code e1204403571642 = 5602450082746 := by decide
theorem cert_e1204403571642 : check e1204403571642 [[],[]] .smaller = true := by decide
def e1204403571670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204403571670 : Closed e1204403571670 ∧ code e1204403571670 = 5602450082774 := by decide
theorem cert_e1204403571670 : check e1204403571670 [[],[]] .smaller = true := by decide
def e1204403571674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204403571674 : Closed e1204403571674 ∧ code e1204403571674 = 5602450082778 := by decide
theorem cert_e1204403571674 : check e1204403571674 [[],[]] .smaller = true := by decide
def e1204403571950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204403571950 : Closed e1204403571950 ∧ code e1204403571950 = 5602450083054 := by decide
theorem cert_e1204403571950 : check e1204403571950 [[],[]] .smaller = true := by decide
def e1204403571958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204403571958 : Closed e1204403571958 ∧ code e1204403571958 = 5602450083062 := by decide
theorem cert_e1204403571958 : check e1204403571958 [[],[]] .smaller = true := by decide
def e1204403572334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204403572334 : Closed e1204403572334 ∧ code e1204403572334 = 5602450083438 := by decide
theorem cert_e1204403572334 : check e1204403572334 [[],[]] .smaller = true := by decide
def e1204403572346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204403572346 : Closed e1204403572346 ∧ code e1204403572346 = 5602450083450 := by decide
theorem cert_e1204403572346 : check e1204403572346 [[],[]] .smaller = true := by decide
def e1204403572534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204403572534 : Closed e1204403572534 ∧ code e1204403572534 = 5602450083638 := by decide
theorem cert_e1204403572534 : check e1204403572534 [[],[]] .smaller = true := by decide
def e1204403572538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204403572538 : Closed e1204403572538 ∧ code e1204403572538 = 5602450083642 := by decide
theorem cert_e1204403572538 : check e1204403572538 [[],[]] .smaller = true := by decide
def e1204472887322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472887322 : Closed e1204472887322 ∧ code e1204472887322 = 5602519398426 := by decide
theorem cert_e1204472887322 : check e1204472887322 [[],[]] .smaller = true := by decide
def e1204472895514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472895514 : Closed e1204472895514 ∧ code e1204472895514 = 5602519406618 := by decide
theorem cert_e1204472895514 : check e1204472895514 [[],[]] .smaller = true := by decide
def e1204472897050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204472897050 : Closed e1204472897050 ∧ code e1204472897050 = 5602519408154 := by decide
theorem cert_e1204472897050 : check e1204472897050 [[]] .width = true := by decide
def e1204472901146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204472901146 : Closed e1204472901146 ∧ code e1204472901146 = 5602519412250 := by decide
theorem cert_e1204472901146 : check e1204472901146 [[]] .width = true := by decide
def e1204472952858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472952858 : Closed e1204472952858 ∧ code e1204472952858 = 5602519463962 := by decide
theorem cert_e1204472952858 : check e1204472952858 [[],[]] .smaller = true := by decide
def e1204472965146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472965146 : Closed e1204472965146 ∧ code e1204472965146 = 5602519476250 := by decide
theorem cert_e1204472965146 : check e1204472965146 [[],[]] .smaller = true := by decide
def e1204472993818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472993818 : Closed e1204472993818 ∧ code e1204472993818 = 5602519504922 := by decide
theorem cert_e1204472993818 : check e1204472993818 [[],[]] .smaller = true := by decide
def e1204472995354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204472995354 : Closed e1204472995354 ∧ code e1204472995354 = 5602519506458 := by decide
theorem cert_e1204472995354 : check e1204472995354 [[]] .width = true := by decide
def e1204472997914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204472997914 : Closed e1204472997914 ∧ code e1204472997914 = 5602519509018 := by decide
theorem cert_e1204472997914 : check e1204472997914 [[],[]] .smaller = true := by decide
def e1204473002522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473002522 : Closed e1204473002522 ∧ code e1204473002522 = 5602519513626 := by decide
private def t_e1204473002522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204473002522 : ¬ IsSelfInterpreter e1204473002522 :=
  wSource (t := t_e1204473002522) (replay_sound (ps := []) (t := e1204473002522) (by decide)) (by decide)
def e1204473015834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473015834 : Closed e1204473015834 ∧ code e1204473015834 = 5602519526938 := by decide
theorem cert_e1204473015834 : check e1204473015834 [[]] .width = true := by decide
def e1204473018906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473018906 : Closed e1204473018906 ∧ code e1204473018906 = 5602519530010 := by decide
private def t_e1204473018906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204473018906 : ¬ IsSelfInterpreter e1204473018906 :=
  wSource (t := t_e1204473018906) (replay_sound (ps := []) (t := e1204473018906) (by decide)) (by decide)
def e1204473280538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473280538 : Closed e1204473280538 ∧ code e1204473280538 = 5602519791642 := by decide
theorem cert_e1204473280538 : check e1204473280538 [[],[]] .smaller = true := by decide
def e1204473288730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473288730 : Closed e1204473288730 ∧ code e1204473288730 = 5602519799834 := by decide
theorem cert_e1204473288730 : check e1204473288730 [[],[]] .smaller = true := by decide
def e1204473290266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473290266 : Closed e1204473290266 ∧ code e1204473290266 = 5602519801370 := by decide
theorem cert_e1204473290266 : check e1204473290266 [[]] .width = true := by decide
def e1204473294362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473294362 : Closed e1204473294362 ∧ code e1204473294362 = 5602519805466 := by decide
theorem cert_e1204473294362 : check e1204473294362 [[]] .width = true := by decide
def e1204473673754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473673754 : Closed e1204473673754 ∧ code e1204473673754 = 5602520184858 := by decide
theorem cert_e1204473673754 : check e1204473673754 [[],[]] .smaller = true := by decide
def e1204473686042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473686042 : Closed e1204473686042 ∧ code e1204473686042 = 5602520197146 := by decide
theorem cert_e1204473686042 : check e1204473686042 [[],[]] .smaller = true := by decide
def e1204473878554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473878554 : Closed e1204473878554 ∧ code e1204473878554 = 5602520389658 := by decide
theorem cert_e1204473878554 : check e1204473878554 [[],[]] .smaller = true := by decide
def e1204473880090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473880090 : Closed e1204473880090 ∧ code e1204473880090 = 5602520391194 := by decide
theorem cert_e1204473880090 : check e1204473880090 [[]] .width = true := by decide
def e1204473882650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1204473882650 : Closed e1204473882650 ∧ code e1204473882650 = 5602520393754 := by decide
theorem cert_e1204473882650 : check e1204473882650 [[],[]] .smaller = true := by decide
def e1204473887258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473887258 : Closed e1204473887258 ∧ code e1204473887258 = 5602520398362 := by decide
theorem cert_e1204473887258 : check e1204473887258 [[]] .width = true := by decide
def e1204473982490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473982490 : Closed e1204473982490 ∧ code e1204473982490 = 5602520493594 := by decide
theorem cert_e1204473982490 : check e1204473982490 [[]] .width = true := by decide
def e1204473985562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204473985562 : Closed e1204473985562 ∧ code e1204473985562 = 5602520496666 := by decide
theorem cert_e1204473985562 : check e1204473985562 [[]] .width = true := by decide
def e1204481256986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481256986 : Closed e1204481256986 ∧ code e1204481256986 = 5602527768090 := by decide
private def t_e1204481256986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481256986 : ¬ IsSelfInterpreter e1204481256986 :=
  wSource (t := t_e1204481256986) (replay_sound (ps := []) (t := e1204481256986) (by decide)) (by decide)
def e1204481259034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481259034 : Closed e1204481259034 ∧ code e1204481259034 = 5602527770138 := by decide
private def t_e1204481259034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481259034 : ¬ IsSelfInterpreter e1204481259034 :=
  wSource (t := t_e1204481259034) (replay_sound (ps := []) (t := e1204481259034) (by decide)) (by decide)
def e1204481273370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481273370 : Closed e1204481273370 ∧ code e1204481273370 = 5602527784474 := by decide
private def t_e1204481273370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481273370 : ¬ IsSelfInterpreter e1204481273370 :=
  wSource (t := t_e1204481273370) (replay_sound (ps := []) (t := e1204481273370) (by decide)) (by decide)
def e1204481276442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481276442 : Closed e1204481276442 ∧ code e1204481276442 = 5602527787546 := by decide
private def t_e1204481276442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481276442 : ¬ IsSelfInterpreter e1204481276442 :=
  wSource (t := t_e1204481276442) (replay_sound (ps := []) (t := e1204481276442) (by decide)) (by decide)
def e1204481283610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481283610 : Closed e1204481283610 ∧ code e1204481283610 = 5602527794714 := by decide
private def t_e1204481283610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481283610 : ¬ IsSelfInterpreter e1204481283610 :=
  wSource (t := t_e1204481283610) (replay_sound (ps := []) (t := e1204481283610) (by decide)) (by decide)
def e1204481284634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481284634 : Closed e1204481284634 ∧ code e1204481284634 = 5602527795738 := by decide
private def t_e1204481284634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481284634 : ¬ IsSelfInterpreter e1204481284634 :=
  wSource (t := t_e1204481284634) (replay_sound (ps := []) (t := e1204481284634) (by decide)) (by decide)
def e1204481338906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481338906 : Closed e1204481338906 ∧ code e1204481338906 = 5602527850010 := by decide
private def t_e1204481338906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481338906 : ¬ IsSelfInterpreter e1204481338906 :=
  wSource (t := t_e1204481338906) (replay_sound (ps := []) (t := e1204481338906) (by decide)) (by decide)
def e1204481341978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481341978 : Closed e1204481341978 ∧ code e1204481341978 = 5602527853082 := by decide
private def t_e1204481341978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481341978 : ¬ IsSelfInterpreter e1204481341978 :=
  wSource (t := t_e1204481341978) (replay_sound (ps := []) (t := e1204481341978) (by decide)) (by decide)
def e1204481354266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481354266 : Closed e1204481354266 ∧ code e1204481354266 = 5602527865370 := by decide
private def t_e1204481354266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481354266 : ¬ IsSelfInterpreter e1204481354266 :=
  wSource (t := t_e1204481354266) (replay_sound (ps := []) (t := e1204481354266) (by decide)) (by decide)
def e1204481381914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481381914 : Closed e1204481381914 ∧ code e1204481381914 = 5602527893018 := by decide
private def t_e1204481381914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481381914 : ¬ IsSelfInterpreter e1204481381914 :=
  wSource (t := t_e1204481381914) (replay_sound (ps := []) (t := e1204481381914) (by decide)) (by decide)
def e1204481382938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481382938 : Closed e1204481382938 ∧ code e1204481382938 = 5602527894042 := by decide
private def t_e1204481382938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481382938 : ¬ IsSelfInterpreter e1204481382938 :=
  wSource (t := t_e1204481382938) (replay_sound (ps := []) (t := e1204481382938) (by decide)) (by decide)
def e1204481387034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481387034 : Closed e1204481387034 ∧ code e1204481387034 = 5602527898138 := by decide
private def t_e1204481387034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481387034 : ¬ IsSelfInterpreter e1204481387034 :=
  wSource (t := t_e1204481387034) (replay_sound (ps := []) (t := e1204481387034) (by decide)) (by decide)
def e1204481650202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481650202 : Closed e1204481650202 ∧ code e1204481650202 = 5602528161306 := by decide
private def t_e1204481650202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481650202 : ¬ IsSelfInterpreter e1204481650202 :=
  wSource (t := t_e1204481650202) (replay_sound (ps := []) (t := e1204481650202) (by decide)) (by decide)
def e1204481652250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481652250 : Closed e1204481652250 ∧ code e1204481652250 = 5602528163354 := by decide
private def t_e1204481652250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481652250 : ¬ IsSelfInterpreter e1204481652250 :=
  wSource (t := t_e1204481652250) (replay_sound (ps := []) (t := e1204481652250) (by decide)) (by decide)
def e1204481666586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481666586 : Closed e1204481666586 ∧ code e1204481666586 = 5602528177690 := by decide
private def t_e1204481666586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481666586 : ¬ IsSelfInterpreter e1204481666586 :=
  wSource (t := t_e1204481666586) (replay_sound (ps := []) (t := e1204481666586) (by decide)) (by decide)
def e1204481669658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481669658 : Closed e1204481669658 ∧ code e1204481669658 = 5602528180762 := by decide
private def t_e1204481669658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481669658 : ¬ IsSelfInterpreter e1204481669658 :=
  wSource (t := t_e1204481669658) (replay_sound (ps := []) (t := e1204481669658) (by decide)) (by decide)
def e1204481676826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481676826 : Closed e1204481676826 ∧ code e1204481676826 = 5602528187930 := by decide
private def t_e1204481676826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481676826 : ¬ IsSelfInterpreter e1204481676826 :=
  wSource (t := t_e1204481676826) (replay_sound (ps := []) (t := e1204481676826) (by decide)) (by decide)
def e1204481677850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481677850 : Closed e1204481677850 ∧ code e1204481677850 = 5602528188954 := by decide
private def t_e1204481677850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481677850 : ¬ IsSelfInterpreter e1204481677850 :=
  wSource (t := t_e1204481677850) (replay_sound (ps := []) (t := e1204481677850) (by decide)) (by decide)
def e1204481748506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481748506 : Closed e1204481748506 ∧ code e1204481748506 = 5602528259610 := by decide
private def t_e1204481748506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481748506 : ¬ IsSelfInterpreter e1204481748506 :=
  wSource (t := t_e1204481748506) (replay_sound (ps := []) (t := e1204481748506) (by decide)) (by decide)
def e1204481750554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481750554 : Closed e1204481750554 ∧ code e1204481750554 = 5602528261658 := by decide
private def t_e1204481750554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481750554 : ¬ IsSelfInterpreter e1204481750554 :=
  wSource (t := t_e1204481750554) (replay_sound (ps := []) (t := e1204481750554) (by decide)) (by decide)
def e1204481846810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481846810 : Closed e1204481846810 ∧ code e1204481846810 = 5602528357914 := by decide
private def t_e1204481846810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481846810 : ¬ IsSelfInterpreter e1204481846810 :=
  wSource (t := t_e1204481846810) (replay_sound (ps := []) (t := e1204481846810) (by decide)) (by decide)
def e1204481849882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481849882 : Closed e1204481849882 ∧ code e1204481849882 = 5602528360986 := by decide
private def t_e1204481849882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481849882 : ¬ IsSelfInterpreter e1204481849882 :=
  wSource (t := t_e1204481849882) (replay_sound (ps := []) (t := e1204481849882) (by decide)) (by decide)
def e1204481875994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204481875994 : Closed e1204481875994 ∧ code e1204481875994 = 5602528387098 := by decide
theorem cert_e1204481875994 : check e1204481875994 [[]] .width = true := by decide
def e1204481876086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204481876086 : Closed e1204481876086 ∧ code e1204481876086 = 5602528387190 := by decide
private def t_e1204481876086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204481876086 : ¬ IsSelfInterpreter e1204481876086 :=
  wSource (t := t_e1204481876086) (replay_sound (ps := []) (t := e1204481876086) (by decide)) (by decide)
def e1204481876330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1204481876330 : Closed e1204481876330 ∧ code e1204481876330 = 5602528387434 := by decide
private def t_e1204481876330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1204481876330 : ¬ IsSelfInterpreter e1204481876330 :=
  wSource (t := t_e1204481876330) (replay_sound (ps := []) (t := e1204481876330) (by decide)) (by decide)
def e1204481876378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1204481876378 : Closed e1204481876378 ∧ code e1204481876378 = 5602528387482 := by decide
private def t_e1204481876378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1204481876378 : ¬ IsSelfInterpreter e1204481876378 :=
  wSource (t := t_e1204481876378) (replay_sound (ps := []) (t := e1204481876378) (by decide)) (by decide)
def e1204481898010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481898010 : Closed e1204481898010 ∧ code e1204481898010 = 5602528409114 := by decide
private def t_e1204481898010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481898010 : ¬ IsSelfInterpreter e1204481898010 :=
  wSource (t := t_e1204481898010) (replay_sound (ps := []) (t := e1204481898010) (by decide)) (by decide)
def e1204481899034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204481899034 : Closed e1204481899034 ∧ code e1204481899034 = 5602528410138 := by decide
private def t_e1204481899034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204481899034 : ¬ IsSelfInterpreter e1204481899034 :=
  wSource (t := t_e1204481899034) (replay_sound (ps := []) (t := e1204481899034) (by decide)) (by decide)
def e1204481908762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1204481908762 : Closed e1204481908762 ∧ code e1204481908762 = 5602528419866 := by decide
theorem cert_e1204481908762 : check e1204481908762 [[]] .width = true := by decide
def e1204481908854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1204481908854 : Closed e1204481908854 ∧ code e1204481908854 = 5602528419958 := by decide
private def t_e1204481908854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1204481908854 : ¬ IsSelfInterpreter e1204481908854 :=
  wSource (t := t_e1204481908854) (replay_sound (ps := []) (t := e1204481908854) (by decide)) (by decide)
end Blc.Floor42
