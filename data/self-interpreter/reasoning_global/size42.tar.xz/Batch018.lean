import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e303204161774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e303204161774 : Closed e303204161774 ∧ code e303204161774 = 4701250672878 := by decide
theorem cert_e303204161774 : check e303204161774 [[.under]] .sourceHead = true := by decide
def e303204161782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e303204161782 : Closed e303204161782 ∧ code e303204161782 = 4701250672886 := by decide
theorem cert_e303204161782 : check e303204161782 [[.under]] .sourceHead = true := by decide
def e303204162334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e303204162334 : Closed e303204162334 ∧ code e303204162334 = 4701250673438 := by decide
theorem cert_e303204162334 : check e303204162334 [[.under]] .sourceHead = true := by decide
def e303204162446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e303204162446 : Closed e303204162446 ∧ code e303204162446 = 4701250673550 := by decide
theorem cert_e303204162446 : check e303204162446 [[.under]] .sourceHead = true := by decide
def e303204162670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e303204162670 : Closed e303204162670 ∧ code e303204162670 = 4701250673774 := by decide
theorem cert_e303204162670 : check e303204162670 [[.under]] .sourceHead = true := by decide
def e303204162682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e303204162682 : Closed e303204162682 ∧ code e303204162682 = 4701250673786 := by decide
theorem cert_e303204162682 : check e303204162682 [[.under]] .sourceHead = true := by decide
def e303204162846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e303204162846 : Closed e303204162846 ∧ code e303204162846 = 4701250673950 := by decide
theorem cert_e303204162846 : check e303204162846 [[.under]] .sourceHead = true := by decide
def e303204163014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e303204163014 : Closed e303204163014 ∧ code e303204163014 = 4701250674118 := by decide
theorem cert_e303204163014 : check e303204163014 [[.under]] .sourceHead = true := by decide
def e303204163126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e303204163126 : Closed e303204163126 ∧ code e303204163126 = 4701250674230 := by decide
theorem cert_e303204163126 : check e303204163126 [[.under]] .sourceHead = true := by decide
def e303204163130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e303204163130 : Closed e303204163130 ∧ code e303204163130 = 4701250674234 := by decide
theorem cert_e303204163130 : check e303204163130 [[.under]] .sourceHead = true := by decide
def e303204163214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e303204163214 : Closed e303204163214 ∧ code e303204163214 = 4701250674318 := by decide
theorem cert_e303204163214 : check e303204163214 [[.under]] .sourceHead = true := by decide
def e303204163270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e303204163270 : Closed e303204163270 ∧ code e303204163270 = 4701250674374 := by decide
theorem cert_e303204163270 : check e303204163270 [[.under]] .sourceHead = true := by decide
def e303204165406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e303204165406 : Closed e303204165406 ∧ code e303204165406 = 4701250676510 := by decide
theorem cert_e303204165406 : check e303204165406 [[.under]] .sourceHead = true := by decide
def e303204165518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e303204165518 : Closed e303204165518 ∧ code e303204165518 = 4701250676622 := by decide
theorem cert_e303204165518 : check e303204165518 [[.under]] .sourceHead = true := by decide
def e303204168478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e303204168478 : Closed e303204168478 ∧ code e303204168478 = 4701250679582 := by decide
theorem cert_e303204168478 : check e303204168478 [[.under]] .sourceHead = true := by decide
def e303204168646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e303204168646 : Closed e303204168646 ∧ code e303204168646 = 4701250679750 := by decide
theorem cert_e303204168646 : check e303204168646 [[.under]] .sourceHead = true := by decide
def e303204170126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e303204170126 : Closed e303204170126 ∧ code e303204170126 = 4701250681230 := by decide
theorem cert_e303204170126 : check e303204170126 [[.under]] .sourceHead = true := by decide
def e303204170182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e303204170182 : Closed e303204170182 ∧ code e303204170182 = 4701250681286 := by decide
theorem cert_e303204170182 : check e303204170182 [[.under]] .sourceHead = true := by decide
def e305815137646 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e305815137646 : Closed e305815137646 ∧ code e305815137646 = 4703861648750 := by decide
theorem cert_e305815137646 : check e305815137646 [[.under]] .sourceHead = true := by decide
def e305815137654 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e305815137654 : Closed e305815137654 ∧ code e305815137654 = 4703861648758 := by decide
theorem cert_e305815137654 : check e305815137654 [[.under]] .sourceHead = true := by decide
def e305815137710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e305815137710 : Closed e305815137710 ∧ code e305815137710 = 4703861648814 := by decide
theorem cert_e305815137710 : check e305815137710 [[.under]] .sourceHead = true := by decide
def e305815137722 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e305815137722 : Closed e305815137722 ∧ code e305815137722 = 4703861648826 := by decide
theorem cert_e305815137722 : check e305815137722 [[.under]] .sourceHead = true := by decide
def e305815137750 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e305815137750 : Closed e305815137750 ∧ code e305815137750 = 4703861648854 := by decide
theorem cert_e305815137750 : check e305815137750 [[.under]] .sourceHead = true := by decide
def e305815137754 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e305815137754 : Closed e305815137754 ∧ code e305815137754 = 4703861648858 := by decide
theorem cert_e305815137754 : check e305815137754 [[.under]] .sourceHead = true := by decide
def e305815137966 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e305815137966 : Closed e305815137966 ∧ code e305815137966 = 4703861649070 := by decide
theorem cert_e305815137966 : check e305815137966 [[.under]] .sourceHead = true := by decide
def e305815137978 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e305815137978 : Closed e305815137978 ∧ code e305815137978 = 4703861649082 := by decide
theorem cert_e305815137978 : check e305815137978 [[.under]] .sourceHead = true := by decide
def e305815138026 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e305815138026 : Closed e305815138026 ∧ code e305815138026 = 4703861649130 := by decide
theorem cert_e305815138026 : check e305815138026 [[.under]] .sourceHead = true := by decide
def e305815138134 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e305815138134 : Closed e305815138134 ∧ code e305815138134 = 4703861649238 := by decide
theorem cert_e305815138134 : check e305815138134 [[.under]] .sourceHead = true := by decide
def e305815138138 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e305815138138 : Closed e305815138138 ∧ code e305815138138 = 4703861649242 := by decide
theorem cert_e305815138138 : check e305815138138 [[.under]] .sourceHead = true := by decide
def e305815138154 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e305815138154 : Closed e305815138154 ∧ code e305815138154 = 4703861649258 := by decide
theorem cert_e305815138154 : check e305815138154 [[.under]] .sourceHead = true := by decide
def e305815139182 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e305815139182 : Closed e305815139182 ∧ code e305815139182 = 4703861650286 := by decide
theorem cert_e305815139182 : check e305815139182 [[.under]] .sourceHead = true := by decide
def e305815139190 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e305815139190 : Closed e305815139190 ∧ code e305815139190 = 4703861650294 := by decide
theorem cert_e305815139190 : check e305815139190 [[.under]] .sourceHead = true := by decide
def e305815139246 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e305815139246 : Closed e305815139246 ∧ code e305815139246 = 4703861650350 := by decide
theorem cert_e305815139246 : check e305815139246 [[.under]] .sourceHead = true := by decide
def e305815139258 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e305815139258 : Closed e305815139258 ∧ code e305815139258 = 4703861650362 := by decide
theorem cert_e305815139258 : check e305815139258 [[.under]] .sourceHead = true := by decide
def e305815139286 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e305815139286 : Closed e305815139286 ∧ code e305815139286 = 4703861650390 := by decide
theorem cert_e305815139286 : check e305815139286 [[.under]] .sourceHead = true := by decide
def e305815139290 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e305815139290 : Closed e305815139290 ∧ code e305815139290 = 4703861650394 := by decide
theorem cert_e305815139290 : check e305815139290 [[.under]] .sourceHead = true := by decide
def e305815139566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e305815139566 : Closed e305815139566 ∧ code e305815139566 = 4703861650670 := by decide
theorem cert_e305815139566 : check e305815139566 [[.under]] .sourceHead = true := by decide
def e305815139574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e305815139574 : Closed e305815139574 ∧ code e305815139574 = 4703861650678 := by decide
theorem cert_e305815139574 : check e305815139574 [[.under]] .sourceHead = true := by decide
def e305815139950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e305815139950 : Closed e305815139950 ∧ code e305815139950 = 4703861651054 := by decide
theorem cert_e305815139950 : check e305815139950 [[.under]] .sourceHead = true := by decide
def e305815139962 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e305815139962 : Closed e305815139962 ∧ code e305815139962 = 4703861651066 := by decide
theorem cert_e305815139962 : check e305815139962 [[.under]] .sourceHead = true := by decide
def e305815140150 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e305815140150 : Closed e305815140150 ∧ code e305815140150 = 4703861651254 := by decide
theorem cert_e305815140150 : check e305815140150 [[.under]] .sourceHead = true := by decide
def e305815140154 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e305815140154 : Closed e305815140154 ∧ code e305815140154 = 4703861651258 := by decide
theorem cert_e305815140154 : check e305815140154 [[.under]] .sourceHead = true := by decide
def e305815140782 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e305815140782 : Closed e305815140782 ∧ code e305815140782 = 4703861651886 := by decide
theorem cert_e305815140782 : check e305815140782 [[.under]] .sourceHead = true := by decide
def e305815140794 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e305815140794 : Closed e305815140794 ∧ code e305815140794 = 4703861651898 := by decide
theorem cert_e305815140794 : check e305815140794 [[.under]] .sourceHead = true := by decide
def e305815140842 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e305815140842 : Closed e305815140842 ∧ code e305815140842 = 4703861651946 := by decide
theorem cert_e305815140842 : check e305815140842 [[.under]] .sourceHead = true := by decide
def e305815140974 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e305815140974 : Closed e305815140974 ∧ code e305815140974 = 4703861652078 := by decide
theorem cert_e305815140974 : check e305815140974 [[.under]] .sourceHead = true := by decide
def e305815140986 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e305815140986 : Closed e305815140986 ∧ code e305815140986 = 4703861652090 := by decide
theorem cert_e305815140986 : check e305815140986 [[.under]] .sourceHead = true := by decide
def e305815141274 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e305815141274 : Closed e305815141274 ∧ code e305815141274 = 4703861652378 := by decide
theorem cert_e305815141274 : check e305815141274 [[.under]] .sourceHead = true := by decide
def e305815141590 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e305815141590 : Closed e305815141590 ∧ code e305815141590 = 4703861652694 := by decide
theorem cert_e305815141590 : check e305815141590 [[.under]] .sourceHead = true := by decide
def e305815141594 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e305815141594 : Closed e305815141594 ∧ code e305815141594 = 4703861652698 := by decide
theorem cert_e305815141594 : check e305815141594 [[.under]] .sourceHead = true := by decide
def e305815141610 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e305815141610 : Closed e305815141610 ∧ code e305815141610 = 4703861652714 := by decide
theorem cert_e305815141610 : check e305815141610 [[.under]] .sourceHead = true := by decide
def e305815141686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e305815141686 : Closed e305815141686 ∧ code e305815141686 = 4703861652790 := by decide
theorem cert_e305815141686 : check e305815141686 [[.under]] .sourceHead = true := by decide
def e305815141690 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e305815141690 : Closed e305815141690 ∧ code e305815141690 = 4703861652794 := by decide
theorem cert_e305815141690 : check e305815141690 [[.under]] .sourceHead = true := by decide
def e305815141786 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e305815141786 : Closed e305815141786 ∧ code e305815141786 = 4703861652890 := by decide
theorem cert_e305815141786 : check e305815141786 [[.under]] .sourceHead = true := by decide
def e305815145326 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e305815145326 : Closed e305815145326 ∧ code e305815145326 = 4703861656430 := by decide
theorem cert_e305815145326 : check e305815145326 [[.under]] .sourceHead = true := by decide
def e305815145334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e305815145334 : Closed e305815145334 ∧ code e305815145334 = 4703861656438 := by decide
theorem cert_e305815145334 : check e305815145334 [[.under]] .sourceHead = true := by decide
def e305815145390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e305815145390 : Closed e305815145390 ∧ code e305815145390 = 4703861656494 := by decide
theorem cert_e305815145390 : check e305815145390 [[.under]] .sourceHead = true := by decide
def e305815145402 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e305815145402 : Closed e305815145402 ∧ code e305815145402 = 4703861656506 := by decide
theorem cert_e305815145402 : check e305815145402 [[.under]] .sourceHead = true := by decide
def e305815145430 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e305815145430 : Closed e305815145430 ∧ code e305815145430 = 4703861656534 := by decide
theorem cert_e305815145430 : check e305815145430 [[.under]] .sourceHead = true := by decide
def e305815145434 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e305815145434 : Closed e305815145434 ∧ code e305815145434 = 4703861656538 := by decide
theorem cert_e305815145434 : check e305815145434 [[.under]] .sourceHead = true := by decide
def e305815145710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e305815145710 : Closed e305815145710 ∧ code e305815145710 = 4703861656814 := by decide
theorem cert_e305815145710 : check e305815145710 [[.under]] .sourceHead = true := by decide
def e305815145718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e305815145718 : Closed e305815145718 ∧ code e305815145718 = 4703861656822 := by decide
theorem cert_e305815145718 : check e305815145718 [[.under]] .sourceHead = true := by decide
def e305815146094 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e305815146094 : Closed e305815146094 ∧ code e305815146094 = 4703861657198 := by decide
theorem cert_e305815146094 : check e305815146094 [[.under]] .sourceHead = true := by decide
def e305815146106 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e305815146106 : Closed e305815146106 ∧ code e305815146106 = 4703861657210 := by decide
theorem cert_e305815146106 : check e305815146106 [[.under]] .sourceHead = true := by decide
def e305815146294 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e305815146294 : Closed e305815146294 ∧ code e305815146294 = 4703861657398 := by decide
theorem cert_e305815146294 : check e305815146294 [[.under]] .sourceHead = true := by decide
def e305815146298 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e305815146298 : Closed e305815146298 ∧ code e305815146298 = 4703861657402 := by decide
theorem cert_e305815146298 : check e305815146298 [[.under]] .sourceHead = true := by decide
def e305815152046 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e305815152046 : Closed e305815152046 ∧ code e305815152046 = 4703861663150 := by decide
theorem cert_e305815152046 : check e305815152046 [[.under]] .sourceHead = true := by decide
def e305815152058 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e305815152058 : Closed e305815152058 ∧ code e305815152058 = 4703861663162 := by decide
theorem cert_e305815152058 : check e305815152058 [[.under]] .sourceHead = true := by decide
def e305815152106 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e305815152106 : Closed e305815152106 ∧ code e305815152106 = 4703861663210 := by decide
theorem cert_e305815152106 : check e305815152106 [[.under]] .sourceHead = true := by decide
def e305815152238 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e305815152238 : Closed e305815152238 ∧ code e305815152238 = 4703861663342 := by decide
theorem cert_e305815152238 : check e305815152238 [[.under]] .sourceHead = true := by decide
def e305815152250 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e305815152250 : Closed e305815152250 ∧ code e305815152250 = 4703861663354 := by decide
theorem cert_e305815152250 : check e305815152250 [[.under]] .sourceHead = true := by decide
def e305815152538 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e305815152538 : Closed e305815152538 ∧ code e305815152538 = 4703861663642 := by decide
theorem cert_e305815152538 : check e305815152538 [[.under]] .sourceHead = true := by decide
def e305815155414 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e305815155414 : Closed e305815155414 ∧ code e305815155414 = 4703861666518 := by decide
theorem cert_e305815155414 : check e305815155414 [[.under]] .sourceHead = true := by decide
def e305815155418 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e305815155418 : Closed e305815155418 ∧ code e305815155418 = 4703861666522 := by decide
theorem cert_e305815155418 : check e305815155418 [[.under]] .sourceHead = true := by decide
def e305815155434 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e305815155434 : Closed e305815155434 ∧ code e305815155434 = 4703861666538 := by decide
theorem cert_e305815155434 : check e305815155434 [[.under]] .sourceHead = true := by decide
def e305815155510 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e305815155510 : Closed e305815155510 ∧ code e305815155510 = 4703861666614 := by decide
theorem cert_e305815155510 : check e305815155510 [[.under]] .sourceHead = true := by decide
def e305815155514 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e305815155514 : Closed e305815155514 ∧ code e305815155514 = 4703861666618 := by decide
theorem cert_e305815155514 : check e305815155514 [[.under]] .sourceHead = true := by decide
def e305815155610 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e305815155610 : Closed e305815155610 ∧ code e305815155610 = 4703861666714 := by decide
theorem cert_e305815155610 : check e305815155610 [[.under]] .sourceHead = true := by decide
def e305815271150 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e305815271150 : Closed e305815271150 ∧ code e305815271150 = 4703861782254 := by decide
theorem cert_e305815271150 : check e305815271150 [[.under]] .sourceHead = true := by decide
def e305815271278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e305815271278 : Closed e305815271278 ∧ code e305815271278 = 4703861782382 := by decide
theorem cert_e305815271278 : check e305815271278 [[.under]] .sourceHead = true := by decide
def e305815271286 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e305815271286 : Closed e305815271286 ∧ code e305815271286 = 4703861782390 := by decide
theorem cert_e305815271286 : check e305815271286 [[.under]] .sourceHead = true := by decide
def e305815272174 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e305815272174 : Closed e305815272174 ∧ code e305815272174 = 4703861783278 := by decide
theorem cert_e305815272174 : check e305815272174 [[.under]] .sourceHead = true := by decide
def e305815272366 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e305815272366 : Closed e305815272366 ∧ code e305815272366 = 4703861783470 := by decide
theorem cert_e305815272366 : check e305815272366 [[.under]] .sourceHead = true := by decide
def e305815272378 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e305815272378 : Closed e305815272378 ∧ code e305815272378 = 4703861783482 := by decide
theorem cert_e305815272378 : check e305815272378 [[.under]] .sourceHead = true := by decide
def e305815272814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e305815272814 : Closed e305815272814 ∧ code e305815272814 = 4703861783918 := by decide
theorem cert_e305815272814 : check e305815272814 [[.under]] .sourceHead = true := by decide
def e305815272822 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e305815272822 : Closed e305815272822 ∧ code e305815272822 = 4703861783926 := by decide
theorem cert_e305815272822 : check e305815272822 [[.under]] .sourceHead = true := by decide
def e305815272878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e305815272878 : Closed e305815272878 ∧ code e305815272878 = 4703861783982 := by decide
theorem cert_e305815272878 : check e305815272878 [[.under]] .sourceHead = true := by decide
def e305815272890 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e305815272890 : Closed e305815272890 ∧ code e305815272890 = 4703861783994 := by decide
theorem cert_e305815272890 : check e305815272890 [[.under]] .sourceHead = true := by decide
def e305815272918 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e305815272918 : Closed e305815272918 ∧ code e305815272918 = 4703861784022 := by decide
theorem cert_e305815272918 : check e305815272918 [[.under]] .sourceHead = true := by decide
def e305815272922 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e305815272922 : Closed e305815272922 ∧ code e305815272922 = 4703861784026 := by decide
theorem cert_e305815272922 : check e305815272922 [[.under]] .sourceHead = true := by decide
def e305815277294 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e305815277294 : Closed e305815277294 ∧ code e305815277294 = 4703861788398 := by decide
theorem cert_e305815277294 : check e305815277294 [[.under]] .sourceHead = true := by decide
def e305815277422 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e305815277422 : Closed e305815277422 ∧ code e305815277422 = 4703861788526 := by decide
theorem cert_e305815277422 : check e305815277422 [[.under]] .sourceHead = true := by decide
def e305815277430 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e305815277430 : Closed e305815277430 ∧ code e305815277430 = 4703861788534 := by decide
theorem cert_e305815277430 : check e305815277430 [[.under]] .sourceHead = true := by decide
def e305815280110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e305815280110 : Closed e305815280110 ∧ code e305815280110 = 4703861791214 := by decide
theorem cert_e305815280110 : check e305815280110 [[.under]] .sourceHead = true := by decide
def e305815280878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e305815280878 : Closed e305815280878 ∧ code e305815280878 = 4703861791982 := by decide
theorem cert_e305815280878 : check e305815280878 [[.under]] .sourceHead = true := by decide
def e305815280886 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e305815280886 : Closed e305815280886 ∧ code e305815280886 = 4703861791990 := by decide
theorem cert_e305815280886 : check e305815280886 [[.under]] .sourceHead = true := by decide
def e305815283438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e305815283438 : Closed e305815283438 ∧ code e305815283438 = 4703861794542 := by decide
theorem cert_e305815283438 : check e305815283438 [[.under]] .sourceHead = true := by decide
def e305815283630 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e305815283630 : Closed e305815283630 ∧ code e305815283630 = 4703861794734 := by decide
theorem cert_e305815283630 : check e305815283630 [[.under]] .sourceHead = true := by decide
def e305815283642 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e305815283642 : Closed e305815283642 ∧ code e305815283642 = 4703861794746 := by decide
theorem cert_e305815283642 : check e305815283642 [[.under]] .sourceHead = true := by decide
def e305815284206 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e305815284206 : Closed e305815284206 ∧ code e305815284206 = 4703861795310 := by decide
theorem cert_e305815284206 : check e305815284206 [[.under]] .sourceHead = true := by decide
def e305815285358 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e305815285358 : Closed e305815285358 ∧ code e305815285358 = 4703861796462 := by decide
theorem cert_e305815285358 : check e305815285358 [[.under]] .sourceHead = true := by decide
def e305815285370 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e305815285370 : Closed e305815285370 ∧ code e305815285370 = 4703861796474 := by decide
theorem cert_e305815285370 : check e305815285370 [[.under]] .sourceHead = true := by decide
def e305815286638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e305815286638 : Closed e305815286638 ∧ code e305815286638 = 4703861797742 := by decide
theorem cert_e305815286638 : check e305815286638 [[.under]] .sourceHead = true := by decide
def e305815286646 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e305815286646 : Closed e305815286646 ∧ code e305815286646 = 4703861797750 := by decide
theorem cert_e305815286646 : check e305815286646 [[.under]] .sourceHead = true := by decide
def e305815286702 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e305815286702 : Closed e305815286702 ∧ code e305815286702 = 4703861797806 := by decide
theorem cert_e305815286702 : check e305815286702 [[.under]] .sourceHead = true := by decide
def e305815286714 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e305815286714 : Closed e305815286714 ∧ code e305815286714 = 4703861797818 := by decide
theorem cert_e305815286714 : check e305815286714 [[.under]] .sourceHead = true := by decide
def e305815286742 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e305815286742 : Closed e305815286742 ∧ code e305815286742 = 4703861797846 := by decide
theorem cert_e305815286742 : check e305815286742 [[.under]] .sourceHead = true := by decide
def e305815286746 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e305815286746 : Closed e305815286746 ∧ code e305815286746 = 4703861797850 := by decide
theorem cert_e305815286746 : check e305815286746 [[.under]] .sourceHead = true := by decide
def e305815287022 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e305815287022 : Closed e305815287022 ∧ code e305815287022 = 4703861798126 := by decide
theorem cert_e305815287022 : check e305815287022 [[.under]] .sourceHead = true := by decide
def e305815287030 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e305815287030 : Closed e305815287030 ∧ code e305815287030 = 4703861798134 := by decide
theorem cert_e305815287030 : check e305815287030 [[.under]] .sourceHead = true := by decide
def e305815287406 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e305815287406 : Closed e305815287406 ∧ code e305815287406 = 4703861798510 := by decide
theorem cert_e305815287406 : check e305815287406 [[.under]] .sourceHead = true := by decide
def e305815287418 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e305815287418 : Closed e305815287418 ∧ code e305815287418 = 4703861798522 := by decide
theorem cert_e305815287418 : check e305815287418 [[.under]] .sourceHead = true := by decide
def e305815287606 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e305815287606 : Closed e305815287606 ∧ code e305815287606 = 4703861798710 := by decide
theorem cert_e305815287606 : check e305815287606 [[.under]] .sourceHead = true := by decide
def e305815287610 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e305815287610 : Closed e305815287610 ∧ code e305815287610 = 4703861798714 := by decide
theorem cert_e305815287610 : check e305815287610 [[.under]] .sourceHead = true := by decide
def e305815292782 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e305815292782 : Closed e305815292782 ∧ code e305815292782 = 4703861803886 := by decide
theorem cert_e305815292782 : check e305815292782 [[.under]] .sourceHead = true := by decide
def e305815292790 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e305815292790 : Closed e305815292790 ∧ code e305815292790 = 4703861803894 := by decide
theorem cert_e305815292790 : check e305815292790 [[.under]] .sourceHead = true := by decide
def e305815292846 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e305815292846 : Closed e305815292846 ∧ code e305815292846 = 4703861803950 := by decide
theorem cert_e305815292846 : check e305815292846 [[.under]] .sourceHead = true := by decide
def e305815292858 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e305815292858 : Closed e305815292858 ∧ code e305815292858 = 4703861803962 := by decide
theorem cert_e305815292858 : check e305815292858 [[.under]] .sourceHead = true := by decide
def e305815292886 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e305815292886 : Closed e305815292886 ∧ code e305815292886 = 4703861803990 := by decide
theorem cert_e305815292886 : check e305815292886 [[.under]] .sourceHead = true := by decide
def e305815292890 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e305815292890 : Closed e305815292890 ∧ code e305815292890 = 4703861803994 := by decide
theorem cert_e305815292890 : check e305815292890 [[.under]] .sourceHead = true := by decide
def e305815293166 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e305815293166 : Closed e305815293166 ∧ code e305815293166 = 4703861804270 := by decide
theorem cert_e305815293166 : check e305815293166 [[.under]] .sourceHead = true := by decide
def e305815293174 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e305815293174 : Closed e305815293174 ∧ code e305815293174 = 4703861804278 := by decide
theorem cert_e305815293174 : check e305815293174 [[.under]] .sourceHead = true := by decide
def e305815293550 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e305815293550 : Closed e305815293550 ∧ code e305815293550 = 4703861804654 := by decide
theorem cert_e305815293550 : check e305815293550 [[.under]] .sourceHead = true := by decide
def e305815293562 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e305815293562 : Closed e305815293562 ∧ code e305815293562 = 4703861804666 := by decide
theorem cert_e305815293562 : check e305815293562 [[.under]] .sourceHead = true := by decide
def e305815293750 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e305815293750 : Closed e305815293750 ∧ code e305815293750 = 4703861804854 := by decide
theorem cert_e305815293750 : check e305815293750 [[.under]] .sourceHead = true := by decide
def e305815293754 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e305815293754 : Closed e305815293754 ∧ code e305815293754 = 4703861804858 := by decide
theorem cert_e305815293754 : check e305815293754 [[.under]] .sourceHead = true := by decide
def e305815301870 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e305815301870 : Closed e305815301870 ∧ code e305815301870 = 4703861812974 := by decide
theorem cert_e305815301870 : check e305815301870 [[.under]] .sourceHead = true := by decide
def e305815301998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e305815301998 : Closed e305815301998 ∧ code e305815301998 = 4703861813102 := by decide
theorem cert_e305815301998 : check e305815301998 [[.under]] .sourceHead = true := by decide
def e305815302006 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e305815302006 : Closed e305815302006 ∧ code e305815302006 = 4703861813110 := by decide
theorem cert_e305815302006 : check e305815302006 [[.under]] .sourceHead = true := by decide
def e305815304686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e305815304686 : Closed e305815304686 ∧ code e305815304686 = 4703861815790 := by decide
theorem cert_e305815304686 : check e305815304686 [[.under]] .sourceHead = true := by decide
def e305815305454 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e305815305454 : Closed e305815305454 ∧ code e305815305454 = 4703861816558 := by decide
theorem cert_e305815305454 : check e305815305454 [[.under]] .sourceHead = true := by decide
def e305815305462 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e305815305462 : Closed e305815305462 ∧ code e305815305462 = 4703861816566 := by decide
theorem cert_e305815305462 : check e305815305462 [[.under]] .sourceHead = true := by decide
def e305815328494 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e305815328494 : Closed e305815328494 ∧ code e305815328494 = 4703861839598 := by decide
theorem cert_e305815328494 : check e305815328494 [[.under]] .sourceHead = true := by decide
def e305815328686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e305815328686 : Closed e305815328686 ∧ code e305815328686 = 4703861839790 := by decide
theorem cert_e305815328686 : check e305815328686 [[.under]] .sourceHead = true := by decide
def e305815328698 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e305815328698 : Closed e305815328698 ∧ code e305815328698 = 4703861839802 := by decide
theorem cert_e305815328698 : check e305815328698 [[.under]] .sourceHead = true := by decide
def e305815329262 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e305815329262 : Closed e305815329262 ∧ code e305815329262 = 4703861840366 := by decide
theorem cert_e305815329262 : check e305815329262 [[.under]] .sourceHead = true := by decide
def e305815330414 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e305815330414 : Closed e305815330414 ∧ code e305815330414 = 4703861841518 := by decide
theorem cert_e305815330414 : check e305815330414 [[.under]] .sourceHead = true := by decide
def e305815330426 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e305815330426 : Closed e305815330426 ∧ code e305815330426 = 4703861841530 := by decide
theorem cert_e305815330426 : check e305815330426 [[.under]] .sourceHead = true := by decide
def e305815341934 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e305815341934 : Closed e305815341934 ∧ code e305815341934 = 4703861853038 := by decide
theorem cert_e305815341934 : check e305815341934 [[.under]] .sourceHead = true := by decide
def e305815341942 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e305815341942 : Closed e305815341942 ∧ code e305815341942 = 4703861853046 := by decide
theorem cert_e305815341942 : check e305815341942 [[.under]] .sourceHead = true := by decide
def e305815341998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e305815341998 : Closed e305815341998 ∧ code e305815341998 = 4703861853102 := by decide
theorem cert_e305815341998 : check e305815341998 [[.under]] .sourceHead = true := by decide
def e305815342010 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e305815342010 : Closed e305815342010 ∧ code e305815342010 = 4703861853114 := by decide
theorem cert_e305815342010 : check e305815342010 [[.under]] .sourceHead = true := by decide
def e305815342038 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e305815342038 : Closed e305815342038 ∧ code e305815342038 = 4703861853142 := by decide
theorem cert_e305815342038 : check e305815342038 [[.under]] .sourceHead = true := by decide
def e305815342042 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e305815342042 : Closed e305815342042 ∧ code e305815342042 = 4703861853146 := by decide
theorem cert_e305815342042 : check e305815342042 [[.under]] .sourceHead = true := by decide
def e305815342318 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e305815342318 : Closed e305815342318 ∧ code e305815342318 = 4703861853422 := by decide
theorem cert_e305815342318 : check e305815342318 [[.under]] .sourceHead = true := by decide
def e305815342326 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e305815342326 : Closed e305815342326 ∧ code e305815342326 = 4703861853430 := by decide
theorem cert_e305815342326 : check e305815342326 [[.under]] .sourceHead = true := by decide
def e305815342702 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e305815342702 : Closed e305815342702 ∧ code e305815342702 = 4703861853806 := by decide
theorem cert_e305815342702 : check e305815342702 [[.under]] .sourceHead = true := by decide
def e305815342714 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e305815342714 : Closed e305815342714 ∧ code e305815342714 = 4703861853818 := by decide
theorem cert_e305815342714 : check e305815342714 [[.under]] .sourceHead = true := by decide
def e305815342902 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e305815342902 : Closed e305815342902 ∧ code e305815342902 = 4703861854006 := by decide
theorem cert_e305815342902 : check e305815342902 [[.under]] .sourceHead = true := by decide
def e305815342906 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e305815342906 : Closed e305815342906 ∧ code e305815342906 = 4703861854010 := by decide
theorem cert_e305815342906 : check e305815342906 [[.under]] .sourceHead = true := by decide
def e305815882606 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e305815882606 : Closed e305815882606 ∧ code e305815882606 = 4703862393710 := by decide
theorem cert_e305815882606 : check e305815882606 [[.under]] .sourceHead = true := by decide
def e305815882614 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e305815882614 : Closed e305815882614 ∧ code e305815882614 = 4703862393718 := by decide
theorem cert_e305815882614 : check e305815882614 [[.under]] .sourceHead = true := by decide
def e305815882670 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e305815882670 : Closed e305815882670 ∧ code e305815882670 = 4703862393774 := by decide
theorem cert_e305815882670 : check e305815882670 [[.under]] .sourceHead = true := by decide
def e305815882682 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e305815882682 : Closed e305815882682 ∧ code e305815882682 = 4703862393786 := by decide
theorem cert_e305815882682 : check e305815882682 [[.under]] .sourceHead = true := by decide
def e305815882710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e305815882710 : Closed e305815882710 ∧ code e305815882710 = 4703862393814 := by decide
theorem cert_e305815882710 : check e305815882710 [[.under]] .sourceHead = true := by decide
def e305815882714 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e305815882714 : Closed e305815882714 ∧ code e305815882714 = 4703862393818 := by decide
theorem cert_e305815882714 : check e305815882714 [[.under]] .sourceHead = true := by decide
def e305815882990 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e305815882990 : Closed e305815882990 ∧ code e305815882990 = 4703862394094 := by decide
theorem cert_e305815882990 : check e305815882990 [[.under]] .sourceHead = true := by decide
def e305815882998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e305815882998 : Closed e305815882998 ∧ code e305815882998 = 4703862394102 := by decide
theorem cert_e305815882998 : check e305815882998 [[.under]] .sourceHead = true := by decide
def e305815883374 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e305815883374 : Closed e305815883374 ∧ code e305815883374 = 4703862394478 := by decide
theorem cert_e305815883374 : check e305815883374 [[.under]] .sourceHead = true := by decide
def e305815883386 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e305815883386 : Closed e305815883386 ∧ code e305815883386 = 4703862394490 := by decide
theorem cert_e305815883386 : check e305815883386 [[.under]] .sourceHead = true := by decide
end Blc.Floor42
