import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211282877850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282877850 : Closed e1211282877850 ∧ code e1211282877850 = 5609329388954 := by decide
theorem cert_e1211282877850 : check e1211282877850 [[],[]] .chain = true := by decide
def e1211282877894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211282877894 : Closed e1211282877894 ∧ code e1211282877894 = 5609329388998 := by decide
theorem cert_e1211282877894 : check e1211282877894 [[],[]] .sourceHead = true := by decide
def e1211282878006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211282878006 : Closed e1211282878006 ∧ code e1211282878006 = 5609329389110 := by decide
theorem cert_e1211282878006 : check e1211282878006 [[],[]] .sourceHead = true := by decide
def e1211282878010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211282878010 : Closed e1211282878010 ∧ code e1211282878010 = 5609329389114 := by decide
theorem cert_e1211282878010 : check e1211282878010 [[],[]] .sourceHead = true := by decide
def e1211282878094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211282878094 : Closed e1211282878094 ∧ code e1211282878094 = 5609329389198 := by decide
theorem cert_e1211282878094 : check e1211282878094 [[],[]] .sourceHead = true := by decide
def e1211282878150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211282878150 : Closed e1211282878150 ∧ code e1211282878150 = 5609329389254 := by decide
theorem cert_e1211282878150 : check e1211282878150 [[],[]] .sourceHead = true := by decide
def e1211282883566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 2)))))))
theorem wire_e1211282883566 : Closed e1211282883566 ∧ code e1211282883566 = 5609329394670 := by decide
theorem cert_e1211282883566 : check e1211282883566 [[],[]] .chain = true := by decide
def e1211282883574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e1211282883574 : Closed e1211282883574 ∧ code e1211282883574 = 5609329394678 := by decide
theorem cert_e1211282883574 : check e1211282883574 [[],[]] .chain = true := by decide
def e1211282885870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282885870 : Closed e1211282885870 ∧ code e1211282885870 = 5609329396974 := by decide
theorem cert_e1211282885870 : check e1211282885870 [[],[]] .chain = true := by decide
def e1211282885878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282885878 : Closed e1211282885878 ∧ code e1211282885878 = 5609329396982 := by decide
theorem cert_e1211282885878 : check e1211282885878 [[],[]] .chain = true := by decide
def e1211282886430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 3))))))))
theorem wire_e1211282886430 : Closed e1211282886430 ∧ code e1211282886430 = 5609329397534 := by decide
theorem cert_e1211282886430 : check e1211282886430 [[],[]] .chain = true := by decide
def e1211282886542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e1211282886542 : Closed e1211282886542 ∧ code e1211282886542 = 5609329397646 := by decide
theorem cert_e1211282886542 : check e1211282886542 [[],[]] .chain = true := by decide
def e1211282890286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211282890286 : Closed e1211282890286 ∧ code e1211282890286 = 5609329401390 := by decide
theorem cert_e1211282890286 : check e1211282890286 [[],[]] .chain = true := by decide
def e1211282890478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e1211282890478 : Closed e1211282890478 ∧ code e1211282890478 = 5609329401582 := by decide
theorem cert_e1211282890478 : check e1211282890478 [[],[]] .chain = true := by decide
def e1211282890486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e1211282890486 : Closed e1211282890486 ∧ code e1211282890486 = 5609329401590 := by decide
theorem cert_e1211282890486 : check e1211282890486 [[],[]] .chain = true := by decide
def e1211282890518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211282890518 : Closed e1211282890518 ∧ code e1211282890518 = 5609329401622 := by decide
theorem cert_e1211282890518 : check e1211282890518 [[],[]] .chain = true := by decide
def e1211282890614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e1211282890614 : Closed e1211282890614 ∧ code e1211282890614 = 5609329401718 := by decide
theorem cert_e1211282890614 : check e1211282890614 [[],[]] .chain = true := by decide
def e1211282892574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211282892574 : Closed e1211282892574 ∧ code e1211282892574 = 5609329403678 := by decide
theorem cert_e1211282892574 : check e1211282892574 [[],[]] .chain = true := by decide
def e1211282892686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211282892686 : Closed e1211282892686 ∧ code e1211282892686 = 5609329403790 := by decide
theorem cert_e1211282892686 : check e1211282892686 [[],[]] .chain = true := by decide
def e1211282896958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211282896958 : Closed e1211282896958 ∧ code e1211282896958 = 5609329408062 := by decide
theorem cert_e1211282896958 : check e1211282896958 [[],[]] .chain = true := by decide
def e1211282897378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211282897378 : Closed e1211282897378 ∧ code e1211282897378 = 5609329408482 := by decide
theorem cert_e1211282897378 : check e1211282897378 [[],[]] .chain = true := by decide
def e1211282897390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211282897390 : Closed e1211282897390 ∧ code e1211282897390 = 5609329408494 := by decide
theorem cert_e1211282897390 : check e1211282897390 [[],[]] .sourceHead = true := by decide
def e1211282897950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211282897950 : Closed e1211282897950 ∧ code e1211282897950 = 5609329409054 := by decide
theorem cert_e1211282897950 : check e1211282897950 [[],[]] .chain = true := by decide
def e1211282898146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211282898146 : Closed e1211282898146 ∧ code e1211282898146 = 5609329409250 := by decide
theorem cert_e1211282898146 : check e1211282898146 [[],[]] .chain = true := by decide
def e1211282898158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282898158 : Closed e1211282898158 ∧ code e1211282898158 = 5609329409262 := by decide
theorem cert_e1211282898158 : check e1211282898158 [[],[]] .sourceHead = true := by decide
def e1211282898166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282898166 : Closed e1211282898166 ∧ code e1211282898166 = 5609329409270 := by decide
theorem cert_e1211282898166 : check e1211282898166 [[],[]] .sourceHead = true := by decide
def e1211282905966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e1211282905966 : Closed e1211282905966 ∧ code e1211282905966 = 5609329417070 := by decide
theorem cert_e1211282905966 : check e1211282905966 [[],[]] .chain = true := by decide
def e1211282905974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e1211282905974 : Closed e1211282905974 ∧ code e1211282905974 = 5609329417078 := by decide
theorem cert_e1211282905974 : check e1211282905974 [[],[]] .chain = true := by decide
def e1211282906038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e1211282906038 : Closed e1211282906038 ∧ code e1211282906038 = 5609329417142 := by decide
theorem cert_e1211282906038 : check e1211282906038 [[],[]] .chain = true := by decide
def e1211282906478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211282906478 : Closed e1211282906478 ∧ code e1211282906478 = 5609329417582 := by decide
theorem cert_e1211282906478 : check e1211282906478 [[],[]] .chain = true := by decide
def e1211282906486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211282906486 : Closed e1211282906486 ∧ code e1211282906486 = 5609329417590 := by decide
theorem cert_e1211282906486 : check e1211282906486 [[],[]] .chain = true := by decide
def e1211282906542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211282906542 : Closed e1211282906542 ∧ code e1211282906542 = 5609329417646 := by decide
theorem cert_e1211282906542 : check e1211282906542 [[],[]] .chain = true := by decide
def e1211282906554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211282906554 : Closed e1211282906554 ∧ code e1211282906554 = 5609329417658 := by decide
theorem cert_e1211282906554 : check e1211282906554 [[],[]] .chain = true := by decide
def e1211282906582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211282906582 : Closed e1211282906582 ∧ code e1211282906582 = 5609329417686 := by decide
theorem cert_e1211282906582 : check e1211282906582 [[],[]] .chain = true := by decide
def e1211282906586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211282906586 : Closed e1211282906586 ∧ code e1211282906586 = 5609329417690 := by decide
theorem cert_e1211282906586 : check e1211282906586 [[],[]] .chain = true := by decide
def e1211282906806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211282906806 : Closed e1211282906806 ∧ code e1211282906806 = 5609329417910 := by decide
theorem cert_e1211282906806 : check e1211282906806 [[],[]] .chain = true := by decide
def e1211282906838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211282906838 : Closed e1211282906838 ∧ code e1211282906838 = 5609329417942 := by decide
theorem cert_e1211282906838 : check e1211282906838 [[],[]] .chain = true := by decide
def e1211282906842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211282906842 : Closed e1211282906842 ∧ code e1211282906842 = 5609329417946 := by decide
theorem cert_e1211282906842 : check e1211282906842 [[],[]] .chain = true := by decide
def e1211282909038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211282909038 : Closed e1211282909038 ∧ code e1211282909038 = 5609329420142 := by decide
theorem cert_e1211282909038 : check e1211282909038 [[],[]] .chain = true := by decide
def e1211282909046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211282909046 : Closed e1211282909046 ∧ code e1211282909046 = 5609329420150 := by decide
theorem cert_e1211282909046 : check e1211282909046 [[],[]] .chain = true := by decide
def e1211282909110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211282909110 : Closed e1211282909110 ∧ code e1211282909110 = 5609329420214 := by decide
theorem cert_e1211282909110 : check e1211282909110 [[],[]] .chain = true := by decide
def e1211282910446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282910446 : Closed e1211282910446 ∧ code e1211282910446 = 5609329421550 := by decide
theorem cert_e1211282910446 : check e1211282910446 [[],[]] .chain = true := by decide
def e1211282910454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282910454 : Closed e1211282910454 ∧ code e1211282910454 = 5609329421558 := by decide
theorem cert_e1211282910454 : check e1211282910454 [[],[]] .chain = true := by decide
def e1211282910838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282910838 : Closed e1211282910838 ∧ code e1211282910838 = 5609329421942 := by decide
theorem cert_e1211282910838 : check e1211282910838 [[],[]] .chain = true := by decide
def e1211282911342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211282911342 : Closed e1211282911342 ∧ code e1211282911342 = 5609329422446 := by decide
theorem cert_e1211282911342 : check e1211282911342 [[],[]] .chain = true := by decide
def e1211282911518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211282911518 : Closed e1211282911518 ∧ code e1211282911518 = 5609329422622 := by decide
theorem cert_e1211282911518 : check e1211282911518 [[],[]] .chain = true := by decide
def e1211282911714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211282911714 : Closed e1211282911714 ∧ code e1211282911714 = 5609329422818 := by decide
theorem cert_e1211282911714 : check e1211282911714 [[],[]] .chain = true := by decide
def e1211282911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211282911726 : Closed e1211282911726 ∧ code e1211282911726 = 5609329422830 := by decide
theorem cert_e1211282911726 : check e1211282911726 [[],[]] .sourceHead = true := by decide
def e1211282912110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211282912110 : Closed e1211282912110 ∧ code e1211282912110 = 5609329423214 := by decide
theorem cert_e1211282912110 : check e1211282912110 [[],[]] .chain = true := by decide
def e1211282912118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211282912118 : Closed e1211282912118 ∧ code e1211282912118 = 5609329423222 := by decide
theorem cert_e1211282912118 : check e1211282912118 [[],[]] .chain = true := by decide
def e1211282912174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211282912174 : Closed e1211282912174 ∧ code e1211282912174 = 5609329423278 := by decide
theorem cert_e1211282912174 : check e1211282912174 [[],[]] .chain = true := by decide
def e1211282912186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211282912186 : Closed e1211282912186 ∧ code e1211282912186 = 5609329423290 := by decide
theorem cert_e1211282912186 : check e1211282912186 [[],[]] .chain = true := by decide
def e1211282912214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211282912214 : Closed e1211282912214 ∧ code e1211282912214 = 5609329423318 := by decide
theorem cert_e1211282912214 : check e1211282912214 [[],[]] .chain = true := by decide
def e1211282912218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211282912218 : Closed e1211282912218 ∧ code e1211282912218 = 5609329423322 := by decide
theorem cert_e1211282912218 : check e1211282912218 [[],[]] .chain = true := by decide
def e1211282912494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282912494 : Closed e1211282912494 ∧ code e1211282912494 = 5609329423598 := by decide
theorem cert_e1211282912494 : check e1211282912494 [[],[]] .chain = true := by decide
def e1211282912502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282912502 : Closed e1211282912502 ∧ code e1211282912502 = 5609329423606 := by decide
theorem cert_e1211282912502 : check e1211282912502 [[],[]] .chain = true := by decide
def e1211282912878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282912878 : Closed e1211282912878 ∧ code e1211282912878 = 5609329423982 := by decide
theorem cert_e1211282912878 : check e1211282912878 [[],[]] .chain = true := by decide
def e1211282912890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282912890 : Closed e1211282912890 ∧ code e1211282912890 = 5609329423994 := by decide
theorem cert_e1211282912890 : check e1211282912890 [[],[]] .chain = true := by decide
def e1211282913030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282913030 : Closed e1211282913030 ∧ code e1211282913030 = 5609329424134 := by decide
theorem cert_e1211282913030 : check e1211282913030 [[],[]] .chain = true := by decide
def e1211282913054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211282913054 : Closed e1211282913054 ∧ code e1211282913054 = 5609329424158 := by decide
theorem cert_e1211282913054 : check e1211282913054 [[],[]] .sourceHead = true := by decide
def e1211282913078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282913078 : Closed e1211282913078 ∧ code e1211282913078 = 5609329424182 := by decide
theorem cert_e1211282913078 : check e1211282913078 [[],[]] .chain = true := by decide
def e1211282913082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282913082 : Closed e1211282913082 ∧ code e1211282913082 = 5609329424186 := by decide
theorem cert_e1211282913082 : check e1211282913082 [[],[]] .chain = true := by decide
def e1211282913334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211282913334 : Closed e1211282913334 ∧ code e1211282913334 = 5609329424438 := by decide
theorem cert_e1211282913334 : check e1211282913334 [[],[]] .chain = true := by decide
def e1211282913422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211282913422 : Closed e1211282913422 ∧ code e1211282913422 = 5609329424526 := by decide
theorem cert_e1211282913422 : check e1211282913422 [[],[]] .chain = true := by decide
def e1211282913506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211282913506 : Closed e1211282913506 ∧ code e1211282913506 = 5609329424610 := by decide
theorem cert_e1211282913506 : check e1211282913506 [[],[]] .chain = true := by decide
def e1211282913518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211282913518 : Closed e1211282913518 ∧ code e1211282913518 = 5609329424622 := by decide
theorem cert_e1211282913518 : check e1211282913518 [[],[]] .sourceHead = true := by decide
def e1211282913526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211282913526 : Closed e1211282913526 ∧ code e1211282913526 = 5609329424630 := by decide
theorem cert_e1211282913526 : check e1211282913526 [[],[]] .sourceHead = true := by decide
def e1211282913718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211282913718 : Closed e1211282913718 ∧ code e1211282913718 = 5609329424822 := by decide
theorem cert_e1211282913718 : check e1211282913718 [[],[]] .chain = true := by decide
def e1211282913750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211282913750 : Closed e1211282913750 ∧ code e1211282913750 = 5609329424854 := by decide
theorem cert_e1211282913750 : check e1211282913750 [[],[]] .chain = true := by decide
def e1211282913754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211282913754 : Closed e1211282913754 ∧ code e1211282913754 = 5609329424858 := by decide
theorem cert_e1211282913754 : check e1211282913754 [[],[]] .chain = true := by decide
def e1211282913910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282913910 : Closed e1211282913910 ∧ code e1211282913910 = 5609329425014 := by decide
theorem cert_e1211282913910 : check e1211282913910 [[],[]] .chain = true := by decide
def e1211282914054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282914054 : Closed e1211282914054 ∧ code e1211282914054 = 5609329425158 := by decide
theorem cert_e1211282914054 : check e1211282914054 [[],[]] .chain = true := by decide
def e1211282914078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211282914078 : Closed e1211282914078 ∧ code e1211282914078 = 5609329425182 := by decide
theorem cert_e1211282914078 : check e1211282914078 [[],[]] .sourceHead = true := by decide
def e1211282914102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282914102 : Closed e1211282914102 ∧ code e1211282914102 = 5609329425206 := by decide
theorem cert_e1211282914102 : check e1211282914102 [[],[]] .chain = true := by decide
def e1211282914106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282914106 : Closed e1211282914106 ∧ code e1211282914106 = 5609329425210 := by decide
theorem cert_e1211282914106 : check e1211282914106 [[],[]] .chain = true := by decide
def e1211282914190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211282914190 : Closed e1211282914190 ∧ code e1211282914190 = 5609329425294 := by decide
theorem cert_e1211282914190 : check e1211282914190 [[],[]] .sourceHead = true := by decide
def e1211282921326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211282921326 : Closed e1211282921326 ∧ code e1211282921326 = 5609329432430 := by decide
theorem cert_e1211282921326 : check e1211282921326 [[],[]] .chain = true := by decide
def e1211282921334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211282921334 : Closed e1211282921334 ∧ code e1211282921334 = 5609329432438 := by decide
theorem cert_e1211282921334 : check e1211282921334 [[],[]] .chain = true := by decide
def e1211282921398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211282921398 : Closed e1211282921398 ∧ code e1211282921398 = 5609329432502 := by decide
theorem cert_e1211282921398 : check e1211282921398 [[],[]] .chain = true := by decide
def e1211282922734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211282922734 : Closed e1211282922734 ∧ code e1211282922734 = 5609329433838 := by decide
theorem cert_e1211282922734 : check e1211282922734 [[],[]] .chain = true := by decide
def e1211282922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211282922742 : Closed e1211282922742 ∧ code e1211282922742 = 5609329433846 := by decide
theorem cert_e1211282922742 : check e1211282922742 [[],[]] .chain = true := by decide
def e1211282923126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211282923126 : Closed e1211282923126 ∧ code e1211282923126 = 5609329434230 := by decide
theorem cert_e1211282923126 : check e1211282923126 [[],[]] .chain = true := by decide
def e1211282931838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211282931838 : Closed e1211282931838 ∧ code e1211282931838 = 5609329442942 := by decide
theorem cert_e1211282931838 : check e1211282931838 [[],[]] .chain = true := by decide
def e1211282932702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211282932702 : Closed e1211282932702 ∧ code e1211282932702 = 5609329443806 := by decide
theorem cert_e1211282932702 : check e1211282932702 [[],[]] .chain = true := by decide
def e1211282932706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211282932706 : Closed e1211282932706 ∧ code e1211282932706 = 5609329443810 := by decide
theorem cert_e1211282932706 : check e1211282932706 [[],[]] .chain = true := by decide
def e1211282932718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211282932718 : Closed e1211282932718 ∧ code e1211282932718 = 5609329443822 := by decide
theorem cert_e1211282932718 : check e1211282932718 [[],[]] .chain = true := by decide
def e1211282934638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211282934638 : Closed e1211282934638 ∧ code e1211282934638 = 5609329445742 := by decide
theorem cert_e1211282934638 : check e1211282934638 [[],[]] .chain = true := by decide
def e1211282934646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211282934646 : Closed e1211282934646 ∧ code e1211282934646 = 5609329445750 := by decide
theorem cert_e1211282934646 : check e1211282934646 [[],[]] .chain = true := by decide
def e1211282934702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211282934702 : Closed e1211282934702 ∧ code e1211282934702 = 5609329445806 := by decide
theorem cert_e1211282934702 : check e1211282934702 [[],[]] .chain = true := by decide
def e1211282934714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211282934714 : Closed e1211282934714 ∧ code e1211282934714 = 5609329445818 := by decide
theorem cert_e1211282934714 : check e1211282934714 [[],[]] .chain = true := by decide
def e1211282934742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211282934742 : Closed e1211282934742 ∧ code e1211282934742 = 5609329445846 := by decide
theorem cert_e1211282934742 : check e1211282934742 [[],[]] .chain = true := by decide
def e1211282934746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211282934746 : Closed e1211282934746 ∧ code e1211282934746 = 5609329445850 := by decide
theorem cert_e1211282934746 : check e1211282934746 [[],[]] .chain = true := by decide
def e1211282935022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211282935022 : Closed e1211282935022 ∧ code e1211282935022 = 5609329446126 := by decide
theorem cert_e1211282935022 : check e1211282935022 [[],[]] .chain = true := by decide
def e1211282935030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211282935030 : Closed e1211282935030 ∧ code e1211282935030 = 5609329446134 := by decide
theorem cert_e1211282935030 : check e1211282935030 [[],[]] .chain = true := by decide
def e1211282935406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211282935406 : Closed e1211282935406 ∧ code e1211282935406 = 5609329446510 := by decide
theorem cert_e1211282935406 : check e1211282935406 [[],[]] .chain = true := by decide
def e1211282935418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211282935418 : Closed e1211282935418 ∧ code e1211282935418 = 5609329446522 := by decide
theorem cert_e1211282935418 : check e1211282935418 [[],[]] .chain = true := by decide
def e1211282935558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282935558 : Closed e1211282935558 ∧ code e1211282935558 = 5609329446662 := by decide
theorem cert_e1211282935558 : check e1211282935558 [[],[]] .chain = true := by decide
def e1211282935582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211282935582 : Closed e1211282935582 ∧ code e1211282935582 = 5609329446686 := by decide
theorem cert_e1211282935582 : check e1211282935582 [[],[]] .sourceHead = true := by decide
def e1211282935606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282935606 : Closed e1211282935606 ∧ code e1211282935606 = 5609329446710 := by decide
theorem cert_e1211282935606 : check e1211282935606 [[],[]] .chain = true := by decide
def e1211282935610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282935610 : Closed e1211282935610 ∧ code e1211282935610 = 5609329446714 := by decide
theorem cert_e1211282935610 : check e1211282935610 [[],[]] .chain = true := by decide
def e1211282939966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211282939966 : Closed e1211282939966 ∧ code e1211282939966 = 5609329451070 := by decide
theorem cert_e1211282939966 : check e1211282939966 [[],[]] .chain = true := by decide
def e1211282940386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211282940386 : Closed e1211282940386 ∧ code e1211282940386 = 5609329451490 := by decide
theorem cert_e1211282940386 : check e1211282940386 [[],[]] .chain = true := by decide
def e1211282940398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211282940398 : Closed e1211282940398 ∧ code e1211282940398 = 5609329451502 := by decide
theorem cert_e1211282940398 : check e1211282940398 [[],[]] .chain = true := by decide
def e1211282941366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211282941366 : Closed e1211282941366 ∧ code e1211282941366 = 5609329452470 := by decide
theorem cert_e1211282941366 : check e1211282941366 [[],[]] .chain = true := by decide
def e1211282941398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211282941398 : Closed e1211282941398 ∧ code e1211282941398 = 5609329452502 := by decide
theorem cert_e1211282941398 : check e1211282941398 [[],[]] .chain = true := by decide
def e1211282941402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211282941402 : Closed e1211282941402 ∧ code e1211282941402 = 5609329452506 := by decide
theorem cert_e1211282941402 : check e1211282941402 [[],[]] .chain = true := by decide
def e1211282941558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211282941558 : Closed e1211282941558 ∧ code e1211282941558 = 5609329452662 := by decide
theorem cert_e1211282941558 : check e1211282941558 [[],[]] .chain = true := by decide
def e1211282941702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211282941702 : Closed e1211282941702 ∧ code e1211282941702 = 5609329452806 := by decide
theorem cert_e1211282941702 : check e1211282941702 [[],[]] .chain = true := by decide
def e1211282941726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211282941726 : Closed e1211282941726 ∧ code e1211282941726 = 5609329452830 := by decide
theorem cert_e1211282941726 : check e1211282941726 [[],[]] .sourceHead = true := by decide
def e1211282941750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211282941750 : Closed e1211282941750 ∧ code e1211282941750 = 5609329452854 := by decide
theorem cert_e1211282941750 : check e1211282941750 [[],[]] .chain = true := by decide
def e1211282941754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211282941754 : Closed e1211282941754 ∧ code e1211282941754 = 5609329452858 := by decide
theorem cert_e1211282941754 : check e1211282941754 [[],[]] .chain = true := by decide
def e1211282941838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211282941838 : Closed e1211282941838 ∧ code e1211282941838 = 5609329452942 := by decide
theorem cert_e1211282941838 : check e1211282941838 [[],[]] .sourceHead = true := by decide
def e1211282948590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211282948590 : Closed e1211282948590 ∧ code e1211282948590 = 5609329459694 := by decide
theorem cert_e1211282948590 : check e1211282948590 [[],[]] .chain = true := by decide
def e1211282948602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211282948602 : Closed e1211282948602 ∧ code e1211282948602 = 5609329459706 := by decide
theorem cert_e1211282948602 : check e1211282948602 [[],[]] .chain = true := by decide
def e1211282949742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282949742 : Closed e1211282949742 ∧ code e1211282949742 = 5609329460846 := by decide
theorem cert_e1211282949742 : check e1211282949742 [[],[]] .chain = true := by decide
def e1211282949754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282949754 : Closed e1211282949754 ∧ code e1211282949754 = 5609329460858 := by decide
theorem cert_e1211282949754 : check e1211282949754 [[],[]] .chain = true := by decide
def e1211282949918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211282949918 : Closed e1211282949918 ∧ code e1211282949918 = 5609329461022 := by decide
theorem cert_e1211282949918 : check e1211282949918 [[],[]] .chain = true := by decide
def e1211282950086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211282950086 : Closed e1211282950086 ∧ code e1211282950086 = 5609329461190 := by decide
theorem cert_e1211282950086 : check e1211282950086 [[],[]] .chain = true := by decide
def e1211282951726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211282951726 : Closed e1211282951726 ∧ code e1211282951726 = 5609329462830 := by decide
theorem cert_e1211282951726 : check e1211282951726 [[],[]] .chain = true := by decide
def e1211282951918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211282951918 : Closed e1211282951918 ∧ code e1211282951918 = 5609329463022 := by decide
theorem cert_e1211282951918 : check e1211282951918 [[],[]] .chain = true := by decide
def e1211282951926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211282951926 : Closed e1211282951926 ∧ code e1211282951926 = 5609329463030 := by decide
theorem cert_e1211282951926 : check e1211282951926 [[],[]] .chain = true := by decide
def e1211282952046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211282952046 : Closed e1211282952046 ∧ code e1211282952046 = 5609329463150 := by decide
theorem cert_e1211282952046 : check e1211282952046 [[],[]] .chain = true := by decide
def e1211282952058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211282952058 : Closed e1211282952058 ∧ code e1211282952058 = 5609329463162 := by decide
theorem cert_e1211282952058 : check e1211282952058 [[],[]] .chain = true := by decide
def e1211282952074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211282952074 : Closed e1211282952074 ∧ code e1211282952074 = 5609329463178 := by decide
theorem cert_e1211282952074 : check e1211282952074 [[],[]] .chain = true := by decide
def e1211282952118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211282952118 : Closed e1211282952118 ∧ code e1211282952118 = 5609329463222 := by decide
theorem cert_e1211282952118 : check e1211282952118 [[],[]] .chain = true := by decide
def e1211282952122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211282952122 : Closed e1211282952122 ∧ code e1211282952122 = 5609329463226 := by decide
theorem cert_e1211282952122 : check e1211282952122 [[],[]] .chain = true := by decide
def e1211282952990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211282952990 : Closed e1211282952990 ∧ code e1211282952990 = 5609329464094 := by decide
theorem cert_e1211282952990 : check e1211282952990 [[],[]] .chain = true := by decide
def e1211282953158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211282953158 : Closed e1211282953158 ∧ code e1211282953158 = 5609329464262 := by decide
theorem cert_e1211282953158 : check e1211282953158 [[],[]] .chain = true := by decide
def e1211282954302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211282954302 : Closed e1211282954302 ∧ code e1211282954302 = 5609329465406 := by decide
theorem cert_e1211282954302 : check e1211282954302 [[],[]] .chain = true := by decide
def e1211282954722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211282954722 : Closed e1211282954722 ∧ code e1211282954722 = 5609329465826 := by decide
theorem cert_e1211282954722 : check e1211282954722 [[],[]] .chain = true := by decide
def e1211282954734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211282954734 : Closed e1211282954734 ∧ code e1211282954734 = 5609329465838 := by decide
theorem cert_e1211282954734 : check e1211282954734 [[],[]] .sourceHead = true := by decide
def e1211282955790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211282955790 : Closed e1211282955790 ∧ code e1211282955790 = 5609329466894 := by decide
theorem cert_e1211282955790 : check e1211282955790 [[],[]] .chain = true := by decide
def e1211282955874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211282955874 : Closed e1211282955874 ∧ code e1211282955874 = 5609329466978 := by decide
theorem cert_e1211282955874 : check e1211282955874 [[],[]] .chain = true := by decide
def e1211282955886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282955886 : Closed e1211282955886 ∧ code e1211282955886 = 5609329466990 := by decide
theorem cert_e1211282955886 : check e1211282955886 [[],[]] .sourceHead = true := by decide
def e1211282955898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282955898 : Closed e1211282955898 ∧ code e1211282955898 = 5609329467002 := by decide
theorem cert_e1211282955898 : check e1211282955898 [[],[]] .sourceHead = true := by decide
def e1211282959726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211282959726 : Closed e1211282959726 ∧ code e1211282959726 = 5609329470830 := by decide
theorem cert_e1211282959726 : check e1211282959726 [[],[]] .chain = true := by decide
def e1211282959734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211282959734 : Closed e1211282959734 ∧ code e1211282959734 = 5609329470838 := by decide
theorem cert_e1211282959734 : check e1211282959734 [[],[]] .chain = true := by decide
def e1211282959790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211282959790 : Closed e1211282959790 ∧ code e1211282959790 = 5609329470894 := by decide
theorem cert_e1211282959790 : check e1211282959790 [[],[]] .chain = true := by decide
def e1211282959802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211282959802 : Closed e1211282959802 ∧ code e1211282959802 = 5609329470906 := by decide
theorem cert_e1211282959802 : check e1211282959802 [[],[]] .chain = true := by decide
def e1211282959830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211282959830 : Closed e1211282959830 ∧ code e1211282959830 = 5609329470934 := by decide
theorem cert_e1211282959830 : check e1211282959830 [[],[]] .chain = true := by decide
def e1211282959834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211282959834 : Closed e1211282959834 ∧ code e1211282959834 = 5609329470938 := by decide
theorem cert_e1211282959834 : check e1211282959834 [[],[]] .chain = true := by decide
def e1211282960046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211282960046 : Closed e1211282960046 ∧ code e1211282960046 = 5609329471150 := by decide
theorem cert_e1211282960046 : check e1211282960046 [[],[]] .chain = true := by decide
def e1211282960058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211282960058 : Closed e1211282960058 ∧ code e1211282960058 = 5609329471162 := by decide
theorem cert_e1211282960058 : check e1211282960058 [[],[]] .chain = true := by decide
def e1211282960106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211282960106 : Closed e1211282960106 ∧ code e1211282960106 = 5609329471210 := by decide
theorem cert_e1211282960106 : check e1211282960106 [[],[]] .chain = true := by decide
def e1211282960214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211282960214 : Closed e1211282960214 ∧ code e1211282960214 = 5609329471318 := by decide
theorem cert_e1211282960214 : check e1211282960214 [[],[]] .chain = true := by decide
def e1211282960218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211282960218 : Closed e1211282960218 ∧ code e1211282960218 = 5609329471322 := by decide
theorem cert_e1211282960218 : check e1211282960218 [[],[]] .chain = true := by decide
def e1211282960234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211282960234 : Closed e1211282960234 ∧ code e1211282960234 = 5609329471338 := by decide
theorem cert_e1211282960234 : check e1211282960234 [[],[]] .chain = true := by decide
def e1211282960494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211282960494 : Closed e1211282960494 ∧ code e1211282960494 = 5609329471598 := by decide
theorem cert_e1211282960494 : check e1211282960494 [[],[]] .chain = true := by decide
def e1211282960670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211282960670 : Closed e1211282960670 ∧ code e1211282960670 = 5609329471774 := by decide
theorem cert_e1211282960670 : check e1211282960670 [[],[]] .chain = true := by decide
def e1211282960866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211282960866 : Closed e1211282960866 ∧ code e1211282960866 = 5609329471970 := by decide
theorem cert_e1211282960866 : check e1211282960866 [[],[]] .chain = true := by decide
def e1211282960878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211282960878 : Closed e1211282960878 ∧ code e1211282960878 = 5609329471982 := by decide
theorem cert_e1211282960878 : check e1211282960878 [[],[]] .sourceHead = true := by decide
def e1211282961262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211282961262 : Closed e1211282961262 ∧ code e1211282961262 = 5609329472366 := by decide
theorem cert_e1211282961262 : check e1211282961262 [[],[]] .chain = true := by decide
def e1211282961270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211282961270 : Closed e1211282961270 ∧ code e1211282961270 = 5609329472374 := by decide
theorem cert_e1211282961270 : check e1211282961270 [[],[]] .chain = true := by decide
def e1211282961326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211282961326 : Closed e1211282961326 ∧ code e1211282961326 = 5609329472430 := by decide
theorem cert_e1211282961326 : check e1211282961326 [[],[]] .chain = true := by decide
def e1211282961338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211282961338 : Closed e1211282961338 ∧ code e1211282961338 = 5609329472442 := by decide
theorem cert_e1211282961338 : check e1211282961338 [[],[]] .chain = true := by decide
def e1211282961366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211282961366 : Closed e1211282961366 ∧ code e1211282961366 = 5609329472470 := by decide
theorem cert_e1211282961366 : check e1211282961366 [[],[]] .chain = true := by decide
def e1211282961370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211282961370 : Closed e1211282961370 ∧ code e1211282961370 = 5609329472474 := by decide
theorem cert_e1211282961370 : check e1211282961370 [[],[]] .chain = true := by decide
def e1211282961646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282961646 : Closed e1211282961646 ∧ code e1211282961646 = 5609329472750 := by decide
theorem cert_e1211282961646 : check e1211282961646 [[],[]] .chain = true := by decide
def e1211282961654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282961654 : Closed e1211282961654 ∧ code e1211282961654 = 5609329472758 := by decide
theorem cert_e1211282961654 : check e1211282961654 [[],[]] .chain = true := by decide
def e1211282962030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282962030 : Closed e1211282962030 ∧ code e1211282962030 = 5609329473134 := by decide
theorem cert_e1211282962030 : check e1211282962030 [[],[]] .chain = true := by decide
end Blc.Floor42
