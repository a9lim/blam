import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211585328070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211585328070 : Closed e1211585328070 ∧ code e1211585328070 = 5609631839174 := by decide
theorem cert_e1211585328070 : checkPay e1211585328070 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left]] 0 [[.under,.under,.right,.left],[.under,.under,.right,.left],[.under,.under,.right,.right,.left],[.under,.under,.right,.right,.left]] = true := by decide
def e1211585402590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211585402590 : Closed e1211585402590 ∧ code e1211585402590 = 5609631913694 := by decide
theorem cert_e1211585402590 : check e1211585402590 [[],[],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211585402614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211585402614 : Closed e1211585402614 ∧ code e1211585402614 = 5609631913718 := by decide
private def t_e1211585402614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem cert_e1211585402614 : ¬ IsSelfInterpreter e1211585402614 :=
  wSource (t := t_e1211585402614) (replay_sound (ps := []) (t := e1211585402614) (by decide)) (by decide)
def e1211585402718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211585402718 : Closed e1211585402718 ∧ code e1211585402718 = 5609631913822 := by decide
theorem cert_e1211585402718 : check e1211585402718 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211585402734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211585402734 : Closed e1211585402734 ∧ code e1211585402734 = 5609631913838 := by decide
theorem cert_e1211585402734 : check e1211585402734 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585402742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211585402742 : Closed e1211585402742 ∧ code e1211585402742 = 5609631913846 := by decide
theorem cert_e1211585402742 : check e1211585402742 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585402746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211585402746 : Closed e1211585402746 ∧ code e1211585402746 = 5609631913850 := by decide
theorem cert_e1211585402746 : check e1211585402746 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211585402806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211585402806 : Closed e1211585402806 ∧ code e1211585402806 = 5609631913910 := by decide
theorem cert_e1211585402806 : check e1211585402806 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585402838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211585402838 : Closed e1211585402838 ∧ code e1211585402838 = 5609631913942 := by decide
private def t_e1211585402838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem cert_e1211585402838 : ¬ IsSelfInterpreter e1211585402838 :=
  wSource (t := t_e1211585402838) (replay_sound (ps := []) (t := e1211585402838) (by decide)) (by decide)
def e1211585402842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211585402842 : Closed e1211585402842 ∧ code e1211585402842 = 5609631913946 := by decide
theorem cert_e1211585402842 : check e1211585402842 [[],[],[],[],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211585403358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211585403358 : Closed e1211585403358 ∧ code e1211585403358 = 5609631914462 := by decide
theorem cert_e1211585403358 : checkPay e1211585403358 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e1211585403382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211585403382 : Closed e1211585403382 ∧ code e1211585403382 = 5609631914486 := by decide
theorem cert_e1211585403382 : check e1211585403382 [[],[],[],[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211585404126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211585404126 : Closed e1211585404126 ∧ code e1211585404126 = 5609631915230 := by decide
theorem cert_e1211585404126 : check e1211585404126 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211585404142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585404142 : Closed e1211585404142 ∧ code e1211585404142 = 5609631915246 := by decide
theorem cert_e1211585404142 : check e1211585404142 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585404150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585404150 : Closed e1211585404150 ∧ code e1211585404150 = 5609631915254 := by decide
theorem cert_e1211585404150 : check e1211585404150 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585404154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211585404154 : Closed e1211585404154 ∧ code e1211585404154 = 5609631915258 := by decide
theorem cert_e1211585404154 : check e1211585404154 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e1211585404534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211585404534 : Closed e1211585404534 ∧ code e1211585404534 = 5609631915638 := by decide
theorem cert_e1211585404534 : check e1211585404534 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e1211585404726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585404726 : Closed e1211585404726 ∧ code e1211585404726 = 5609631915830 := by decide
def e1211585404730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585404730 : Closed e1211585404730 ∧ code e1211585404730 = 5609631915834 := by decide
theorem cert_e1211585404730 : check e1211585404730 [[],[],[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1211585418934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211585418934 : Closed e1211585418934 ∧ code e1211585418934 = 5609631930038 := by decide
theorem cert_e1211585418934 : check e1211585418934 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585418966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211585418966 : Closed e1211585418966 ∧ code e1211585418966 = 5609631930070 := by decide
theorem cert_e1211585418966 : check e1211585418966 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585418970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211585418970 : Closed e1211585418970 ∧ code e1211585418970 = 5609631930074 := by decide
theorem cert_e1211585418970 : check e1211585418970 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211585419094 : Closed e1211585419094 ∧ code e1211585419094 = 5609631930198 := by decide
theorem cert_e1211585419094 : check e1211585419094 [[],[],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211585419098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211585419098 : Closed e1211585419098 ∧ code e1211585419098 = 5609631930202 := by decide
def e1211585419114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211585419114 : Closed e1211585419114 ∧ code e1211585419114 = 5609631930218 := by decide
private def t_e1211585419114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e1211585419114 : ¬ IsSelfInterpreter e1211585419114 :=
  wSource (t := t_e1211585419114) (replay_sound (ps := []) (t := e1211585419114) (by decide)) (by decide)
def e1211585419318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211585419318 : Closed e1211585419318 ∧ code e1211585419318 = 5609631930422 := by decide
theorem cert_e1211585419318 : check e1211585419318 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211585419406 : Closed e1211585419406 ∧ code e1211585419406 = 5609631930510 := by decide
theorem cert_e1211585419406 : check e1211585419406 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211585419490 : Closed e1211585419490 ∧ code e1211585419490 = 5609631930594 := by decide
theorem cert_e1211585419490 : check e1211585419490 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211585419502 : Closed e1211585419502 ∧ code e1211585419502 = 5609631930606 := by decide
theorem cert_e1211585419502 : check e1211585419502 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211585419510 : Closed e1211585419510 ∧ code e1211585419510 = 5609631930614 := by decide
theorem cert_e1211585419510 : check e1211585419510 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211585419702 : Closed e1211585419702 ∧ code e1211585419702 = 5609631930806 := by decide
theorem cert_e1211585419702 : check e1211585419702 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211585419734 : Closed e1211585419734 ∧ code e1211585419734 = 5609631930838 := by decide
theorem cert_e1211585419734 : check e1211585419734 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211585419738 : Closed e1211585419738 ∧ code e1211585419738 = 5609631930842 := by decide
theorem cert_e1211585419738 : check e1211585419738 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585419894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211585419894 : Closed e1211585419894 ∧ code e1211585419894 = 5609631930998 := by decide
theorem cert_e1211585419894 : check e1211585419894 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585420038 : Closed e1211585420038 ∧ code e1211585420038 = 5609631931142 := by decide
theorem cert_e1211585420038 : check e1211585420038 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211585420062 : Closed e1211585420062 ∧ code e1211585420062 = 5609631931166 := by decide
theorem cert_e1211585420062 : check e1211585420062 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585420086 : Closed e1211585420086 ∧ code e1211585420086 = 5609631931190 := by decide
theorem cert_e1211585420086 : check e1211585420086 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585420090 : Closed e1211585420090 ∧ code e1211585420090 = 5609631931194 := by decide
theorem cert_e1211585420090 : check e1211585420090 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211585420174 : Closed e1211585420174 ∧ code e1211585420174 = 5609631931278 := by decide
theorem cert_e1211585420174 : check e1211585420174 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585420314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211585420314 : Closed e1211585420314 ∧ code e1211585420314 = 5609631931418 := by decide
theorem cert_e1211585420314 : check e1211585420314 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211585420358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211585420358 : Closed e1211585420358 ∧ code e1211585420358 = 5609631931462 := by decide
theorem cert_e1211585420358 : check e1211585420358 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e1211585420386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211585420386 : Closed e1211585420386 ∧ code e1211585420386 = 5609631931490 := by decide
theorem cert_e1211585420386 : check e1211585420386 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211585420398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211585420398 : Closed e1211585420398 ∧ code e1211585420398 = 5609631931502 := by decide
def e1211585420410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211585420410 : Closed e1211585420410 ∧ code e1211585420410 = 5609631931514 := by decide
def e1211585420502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211585420502 : Closed e1211585420502 ∧ code e1211585420502 = 5609631931606 := by decide
def e1211585420506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211585420506 : Closed e1211585420506 ∧ code e1211585420506 = 5609631931610 := by decide
def e1211585420522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211585420522 : Closed e1211585420522 ∧ code e1211585420522 = 5609631931626 := by decide
def e1211585420550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585420550 : Closed e1211585420550 ∧ code e1211585420550 = 5609631931654 := by decide
theorem cert_e1211585420550 : check e1211585420550 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1211585420574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211585420574 : Closed e1211585420574 ∧ code e1211585420574 = 5609631931678 := by decide
def e1211585420598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585420598 : Closed e1211585420598 ∧ code e1211585420598 = 5609631931702 := by decide
def e1211585420602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585420602 : Closed e1211585420602 ∧ code e1211585420602 = 5609631931706 := by decide
def e1211585420698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211585420698 : Closed e1211585420698 ∧ code e1211585420698 = 5609631931802 := by decide
private def t_e1211585420698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211585420698 : ¬ IsSelfInterpreter e1211585420698 :=
  wSource (t := t_e1211585420698) (replay_sound (ps := []) (t := e1211585420698) (by decide)) (by decide)
def e1211585420742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211585420742 : Closed e1211585420742 ∧ code e1211585420742 = 5609631931846 := by decide
private def t_e1211585420742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e1211585420742 : ¬ IsSelfInterpreter e1211585420742 :=
  wSource (t := t_e1211585420742) (replay_sound (ps := []) (t := e1211585420742) (by decide)) (by decide)
def e1211585420854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211585420854 : Closed e1211585420854 ∧ code e1211585420854 = 5609631931958 := by decide
theorem cert_e1211585420854 : check e1211585420854 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211585420858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211585420858 : Closed e1211585420858 ∧ code e1211585420858 = 5609631931962 := by decide
def e1211585420942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211585420942 : Closed e1211585420942 ∧ code e1211585420942 = 5609631932046 := by decide
theorem cert_e1211585420942 : check e1211585420942 [[],[],[],[],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211585420998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211585420998 : Closed e1211585420998 ∧ code e1211585420998 = 5609631932102 := by decide
private def t_e1211585420998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e1211585420998 : ¬ IsSelfInterpreter e1211585420998 :=
  wSource (t := t_e1211585420998) (replay_sound (ps := []) (t := e1211585420998) (by decide)) (by decide)
def e1211585421374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211585421374 : Closed e1211585421374 ∧ code e1211585421374 = 5609631932478 := by decide
theorem cert_e1211585421374 : check e1211585421374 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585421794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211585421794 : Closed e1211585421794 ∧ code e1211585421794 = 5609631932898 := by decide
theorem cert_e1211585421794 : check e1211585421794 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585421806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211585421806 : Closed e1211585421806 ∧ code e1211585421806 = 5609631932910 := by decide
theorem cert_e1211585421806 : check e1211585421806 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585422774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211585422774 : Closed e1211585422774 ∧ code e1211585422774 = 5609631933878 := by decide
theorem cert_e1211585422774 : check e1211585422774 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585422806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211585422806 : Closed e1211585422806 ∧ code e1211585422806 = 5609631933910 := by decide
theorem cert_e1211585422806 : check e1211585422806 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585422810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211585422810 : Closed e1211585422810 ∧ code e1211585422810 = 5609631933914 := by decide
theorem cert_e1211585422810 : check e1211585422810 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585422966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211585422966 : Closed e1211585422966 ∧ code e1211585422966 = 5609631934070 := by decide
theorem cert_e1211585422966 : check e1211585422966 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585423110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585423110 : Closed e1211585423110 ∧ code e1211585423110 = 5609631934214 := by decide
theorem cert_e1211585423110 : check e1211585423110 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585423134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211585423134 : Closed e1211585423134 ∧ code e1211585423134 = 5609631934238 := by decide
theorem cert_e1211585423134 : check e1211585423134 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585423158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585423158 : Closed e1211585423158 ∧ code e1211585423158 = 5609631934262 := by decide
theorem cert_e1211585423158 : check e1211585423158 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585423162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585423162 : Closed e1211585423162 ∧ code e1211585423162 = 5609631934266 := by decide
theorem cert_e1211585423162 : check e1211585423162 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585423246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211585423246 : Closed e1211585423246 ∧ code e1211585423246 = 5609631934350 := by decide
theorem cert_e1211585423246 : check e1211585423246 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585425438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211585425438 : Closed e1211585425438 ∧ code e1211585425438 = 5609631936542 := by decide
theorem cert_e1211585425438 : check e1211585425438 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585425634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211585425634 : Closed e1211585425634 ∧ code e1211585425634 = 5609631936738 := by decide
theorem cert_e1211585425634 : check e1211585425634 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585425646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585425646 : Closed e1211585425646 ∧ code e1211585425646 = 5609631936750 := by decide
def e1211585425654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585425654 : Closed e1211585425654 ∧ code e1211585425654 = 5609631936758 := by decide
def e1211585426134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211585426134 : Closed e1211585426134 ∧ code e1211585426134 = 5609631937238 := by decide
def e1211585426138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211585426138 : Closed e1211585426138 ∧ code e1211585426138 = 5609631937242 := by decide
def e1211585426154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211585426154 : Closed e1211585426154 ∧ code e1211585426154 = 5609631937258 := by decide
def e1211585426182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585426182 : Closed e1211585426182 ∧ code e1211585426182 = 5609631937286 := by decide
theorem cert_e1211585426182 : check e1211585426182 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211585426206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211585426206 : Closed e1211585426206 ∧ code e1211585426206 = 5609631937310 := by decide
def e1211585426230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585426230 : Closed e1211585426230 ∧ code e1211585426230 = 5609631937334 := by decide
def e1211585426234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585426234 : Closed e1211585426234 ∧ code e1211585426234 = 5609631937338 := by decide
def e1211585426330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211585426330 : Closed e1211585426330 ∧ code e1211585426330 = 5609631937434 := by decide
def e1211585426374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211585426374 : Closed e1211585426374 ∧ code e1211585426374 = 5609631937478 := by decide
def e1211585427854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211585427854 : Closed e1211585427854 ∧ code e1211585427854 = 5609631938958 := by decide
def e1211585427910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211585427910 : Closed e1211585427910 ∧ code e1211585427910 = 5609631939014 := by decide
def e1211589221238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e1211589221238 : Closed e1211589221238 ∧ code e1211589221238 = 5609635732342 := by decide
private def t_e1211589221238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem cert_e1211589221238 : ¬ IsSelfInterpreter e1211589221238 :=
  wSource (t := t_e1211589221238) (replay_sound (ps := []) (t := e1211589221238) (by decide)) (by decide)
def e1211589221302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e1211589221302 : Closed e1211589221302 ∧ code e1211589221302 = 5609635732406 := by decide
private def t_e1211589221302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem cert_e1211589221302 : ¬ IsSelfInterpreter e1211589221302 :=
  wSource (t := t_e1211589221302) (replay_sound (ps := []) (t := e1211589221302) (by decide)) (by decide)
def e1211589221750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211589221750 : Closed e1211589221750 ∧ code e1211589221750 = 5609635732854 := by decide
private def t_e1211589221750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem cert_e1211589221750 : ¬ IsSelfInterpreter e1211589221750 :=
  wSource (t := t_e1211589221750) (replay_sound (ps := []) (t := e1211589221750) (by decide)) (by decide)
def e1211589221846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211589221846 : Closed e1211589221846 ∧ code e1211589221846 = 5609635732950 := by decide
private def t_e1211589221846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem cert_e1211589221846 : ¬ IsSelfInterpreter e1211589221846 :=
  wSource (t := t_e1211589221846) (replay_sound (ps := []) (t := e1211589221846) (by decide)) (by decide)
def e1211589222070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211589222070 : Closed e1211589222070 ∧ code e1211589222070 = 5609635733174 := by decide
private def t_e1211589222070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem cert_e1211589222070 : ¬ IsSelfInterpreter e1211589222070 :=
  wSource (t := t_e1211589222070) (replay_sound (ps := []) (t := e1211589222070) (by decide)) (by decide)
def e1211589222102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211589222102 : Closed e1211589222102 ∧ code e1211589222102 = 5609635733206 := by decide
private def t_e1211589222102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem cert_e1211589222102 : ¬ IsSelfInterpreter e1211589222102 :=
  wSource (t := t_e1211589222102) (replay_sound (ps := []) (t := e1211589222102) (by decide)) (by decide)
def e1211589224310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211589224310 : Closed e1211589224310 ∧ code e1211589224310 = 5609635735414 := by decide
private def t_e1211589224310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem cert_e1211589224310 : ¬ IsSelfInterpreter e1211589224310 :=
  wSource (t := t_e1211589224310) (replay_sound (ps := []) (t := e1211589224310) (by decide)) (by decide)
def e1211589224374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211589224374 : Closed e1211589224374 ∧ code e1211589224374 = 5609635735478 := by decide
private def t_e1211589224374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem cert_e1211589224374 : ¬ IsSelfInterpreter e1211589224374 :=
  wSource (t := t_e1211589224374) (replay_sound (ps := []) (t := e1211589224374) (by decide)) (by decide)
def e1211589227382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211589227382 : Closed e1211589227382 ∧ code e1211589227382 = 5609635738486 := by decide
private def t_e1211589227382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem cert_e1211589227382 : ¬ IsSelfInterpreter e1211589227382 :=
  wSource (t := t_e1211589227382) (replay_sound (ps := []) (t := e1211589227382) (by decide)) (by decide)
def e1211589227478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211589227478 : Closed e1211589227478 ∧ code e1211589227478 = 5609635738582 := by decide
private def t_e1211589227478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem cert_e1211589227478 : ¬ IsSelfInterpreter e1211589227478 :=
  wSource (t := t_e1211589227478) (replay_sound (ps := []) (t := e1211589227478) (by decide)) (by decide)
def e1211589228982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211589228982 : Closed e1211589228982 ∧ code e1211589228982 = 5609635740086 := by decide
private def t_e1211589228982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem cert_e1211589228982 : ¬ IsSelfInterpreter e1211589228982 :=
  wSource (t := t_e1211589228982) (replay_sound (ps := []) (t := e1211589228982) (by decide)) (by decide)
def e1211589229014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211589229014 : Closed e1211589229014 ∧ code e1211589229014 = 5609635740118 := by decide
private def t_e1211589229014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem cert_e1211589229014 : ¬ IsSelfInterpreter e1211589229014 :=
  wSource (t := t_e1211589229014) (replay_sound (ps := []) (t := e1211589229014) (by decide)) (by decide)
def e1211589397358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211589397358 : Closed e1211589397358 ∧ code e1211589397358 = 5609635908462 := by decide
private def t_e1211589397358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1211589397358 : ¬ IsSelfInterpreter e1211589397358 :=
  wSource (t := t_e1211589397358) (replay_sound (ps := []) (t := e1211589397358) (by decide)) (by decide)
def e1211589397366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211589397366 : Closed e1211589397366 ∧ code e1211589397366 = 5609635908470 := by decide
private def t_e1211589397366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1211589397366 : ¬ IsSelfInterpreter e1211589397366 :=
  wSource (t := t_e1211589397366) (replay_sound (ps := []) (t := e1211589397366) (by decide)) (by decide)
def e1211589397422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211589397422 : Closed e1211589397422 ∧ code e1211589397422 = 5609635908526 := by decide
private def t_e1211589397422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1211589397422 : ¬ IsSelfInterpreter e1211589397422 :=
  wSource (t := t_e1211589397422) (replay_sound (ps := []) (t := e1211589397422) (by decide)) (by decide)
def e1211589397434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211589397434 : Closed e1211589397434 ∧ code e1211589397434 = 5609635908538 := by decide
private def t_e1211589397434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1211589397434 : ¬ IsSelfInterpreter e1211589397434 :=
  wSource (t := t_e1211589397434) (replay_sound (ps := []) (t := e1211589397434) (by decide)) (by decide)
def e1211589397462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211589397462 : Closed e1211589397462 ∧ code e1211589397462 = 5609635908566 := by decide
private def t_e1211589397462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1211589397462 : ¬ IsSelfInterpreter e1211589397462 :=
  wSource (t := t_e1211589397462) (replay_sound (ps := []) (t := e1211589397462) (by decide)) (by decide)
def e1211589397466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211589397466 : Closed e1211589397466 ∧ code e1211589397466 = 5609635908570 := by decide
private def t_e1211589397466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1211589397466 : ¬ IsSelfInterpreter e1211589397466 :=
  wSource (t := t_e1211589397466) (replay_sound (ps := []) (t := e1211589397466) (by decide)) (by decide)
def e1211589397742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211589397742 : Closed e1211589397742 ∧ code e1211589397742 = 5609635908846 := by decide
private def t_e1211589397742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211589397742 : ¬ IsSelfInterpreter e1211589397742 :=
  wSource (t := t_e1211589397742) (replay_sound (ps := []) (t := e1211589397742) (by decide)) (by decide)
def e1211589397750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211589397750 : Closed e1211589397750 ∧ code e1211589397750 = 5609635908854 := by decide
private def t_e1211589397750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211589397750 : ¬ IsSelfInterpreter e1211589397750 :=
  wSource (t := t_e1211589397750) (replay_sound (ps := []) (t := e1211589397750) (by decide)) (by decide)
def e1211589398126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211589398126 : Closed e1211589398126 ∧ code e1211589398126 = 5609635909230 := by decide
private def t_e1211589398126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211589398126 : ¬ IsSelfInterpreter e1211589398126 :=
  wSource (t := t_e1211589398126) (replay_sound (ps := []) (t := e1211589398126) (by decide)) (by decide)
def e1211589398138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211589398138 : Closed e1211589398138 ∧ code e1211589398138 = 5609635909242 := by decide
private def t_e1211589398138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211589398138 : ¬ IsSelfInterpreter e1211589398138 :=
  wSource (t := t_e1211589398138) (replay_sound (ps := []) (t := e1211589398138) (by decide)) (by decide)
def e1211589398326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211589398326 : Closed e1211589398326 ∧ code e1211589398326 = 5609635909430 := by decide
private def t_e1211589398326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211589398326 : ¬ IsSelfInterpreter e1211589398326 :=
  wSource (t := t_e1211589398326) (replay_sound (ps := []) (t := e1211589398326) (by decide)) (by decide)
def e1211589398330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211589398330 : Closed e1211589398330 ∧ code e1211589398330 = 5609635909434 := by decide
private def t_e1211589398330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211589398330 : ¬ IsSelfInterpreter e1211589398330 :=
  wSource (t := t_e1211589398330) (replay_sound (ps := []) (t := e1211589398330) (by decide)) (by decide)
def e1211589471674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211589471674 : Closed e1211589471674 ∧ code e1211589471674 = 5609635982778 := by decide
private def t_e1211589471674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem cert_e1211589471674 : ¬ IsSelfInterpreter e1211589471674 :=
  wSource (t := t_e1211589471674) (replay_sound (ps := []) (t := e1211589471674) (by decide)) (by decide)
def e1211589471706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211589471706 : Closed e1211589471706 ∧ code e1211589471706 = 5609635982810 := by decide
private def t_e1211589471706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem cert_e1211589471706 : ¬ IsSelfInterpreter e1211589471706 :=
  wSource (t := t_e1211589471706) (replay_sound (ps := []) (t := e1211589471706) (by decide)) (by decide)
def e1211589471930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211589471930 : Closed e1211589471930 ∧ code e1211589471930 = 5609635983034 := by decide
private def t_e1211589471930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem cert_e1211589471930 : ¬ IsSelfInterpreter e1211589471930 :=
  wSource (t := t_e1211589471930) (replay_sound (ps := []) (t := e1211589471930) (by decide)) (by decide)
def e1211589471978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211589471978 : Closed e1211589471978 ∧ code e1211589471978 = 5609635983082 := by decide
private def t_e1211589471978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem cert_e1211589471978 : ¬ IsSelfInterpreter e1211589471978 :=
  wSource (t := t_e1211589471978) (replay_sound (ps := []) (t := e1211589471978) (by decide)) (by decide)
def e1211589472090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211589472090 : Closed e1211589472090 ∧ code e1211589472090 = 5609635983194 := by decide
private def t_e1211589472090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem cert_e1211589472090 : ¬ IsSelfInterpreter e1211589472090 :=
  wSource (t := t_e1211589472090) (replay_sound (ps := []) (t := e1211589472090) (by decide)) (by decide)
def e1211589472106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211589472106 : Closed e1211589472106 ∧ code e1211589472106 = 5609635983210 := by decide
private def t_e1211589472106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem cert_e1211589472106 : ¬ IsSelfInterpreter e1211589472106 :=
  wSource (t := t_e1211589472106) (replay_sound (ps := []) (t := e1211589472106) (by decide)) (by decide)
def e1211589473210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211589473210 : Closed e1211589473210 ∧ code e1211589473210 = 5609635984314 := by decide
private def t_e1211589473210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem cert_e1211589473210 : ¬ IsSelfInterpreter e1211589473210 :=
  wSource (t := t_e1211589473210) (replay_sound (ps := []) (t := e1211589473210) (by decide)) (by decide)
def e1211589473242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211589473242 : Closed e1211589473242 ∧ code e1211589473242 = 5609635984346 := by decide
private def t_e1211589473242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem cert_e1211589473242 : ¬ IsSelfInterpreter e1211589473242 :=
  wSource (t := t_e1211589473242) (replay_sound (ps := []) (t := e1211589473242) (by decide)) (by decide)
def e1211589474746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211589474746 : Closed e1211589474746 ∧ code e1211589474746 = 5609635985850 := by decide
private def t_e1211589474746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem cert_e1211589474746 : ¬ IsSelfInterpreter e1211589474746 :=
  wSource (t := t_e1211589474746) (replay_sound (ps := []) (t := e1211589474746) (by decide)) (by decide)
def e1211589474794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211589474794 : Closed e1211589474794 ∧ code e1211589474794 = 5609635985898 := by decide
private def t_e1211589474794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem cert_e1211589474794 : ¬ IsSelfInterpreter e1211589474794 :=
  wSource (t := t_e1211589474794) (replay_sound (ps := []) (t := e1211589474794) (by decide)) (by decide)
def e1211589475546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211589475546 : Closed e1211589475546 ∧ code e1211589475546 = 5609635986650 := by decide
private def t_e1211589475546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem cert_e1211589475546 : ¬ IsSelfInterpreter e1211589475546 :=
  wSource (t := t_e1211589475546) (replay_sound (ps := []) (t := e1211589475546) (by decide)) (by decide)
def e1211589475562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211589475562 : Closed e1211589475562 ∧ code e1211589475562 = 5609635986666 := by decide
private def t_e1211589475562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem cert_e1211589475562 : ¬ IsSelfInterpreter e1211589475562 :=
  wSource (t := t_e1211589475562) (replay_sound (ps := []) (t := e1211589475562) (by decide)) (by decide)
def e1211589528430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211589528430 : Closed e1211589528430 ∧ code e1211589528430 = 5609636039534 := by decide
private def t_e1211589528430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1211589528430 : ¬ IsSelfInterpreter e1211589528430 :=
  wSource (t := t_e1211589528430) (replay_sound (ps := []) (t := e1211589528430) (by decide)) (by decide)
def e1211589528438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211589528438 : Closed e1211589528438 ∧ code e1211589528438 = 5609636039542 := by decide
private def t_e1211589528438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1211589528438 : ¬ IsSelfInterpreter e1211589528438 :=
  wSource (t := t_e1211589528438) (replay_sound (ps := []) (t := e1211589528438) (by decide)) (by decide)
def e1211589528494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211589528494 : Closed e1211589528494 ∧ code e1211589528494 = 5609636039598 := by decide
private def t_e1211589528494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1211589528494 : ¬ IsSelfInterpreter e1211589528494 :=
  wSource (t := t_e1211589528494) (replay_sound (ps := []) (t := e1211589528494) (by decide)) (by decide)
def e1211589528506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211589528506 : Closed e1211589528506 ∧ code e1211589528506 = 5609636039610 := by decide
private def t_e1211589528506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1211589528506 : ¬ IsSelfInterpreter e1211589528506 :=
  wSource (t := t_e1211589528506) (replay_sound (ps := []) (t := e1211589528506) (by decide)) (by decide)
def e1211589528534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211589528534 : Closed e1211589528534 ∧ code e1211589528534 = 5609636039638 := by decide
private def t_e1211589528534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1211589528534 : ¬ IsSelfInterpreter e1211589528534 :=
  wSource (t := t_e1211589528534) (replay_sound (ps := []) (t := e1211589528534) (by decide)) (by decide)
def e1211589528538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211589528538 : Closed e1211589528538 ∧ code e1211589528538 = 5609636039642 := by decide
private def t_e1211589528538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1211589528538 : ¬ IsSelfInterpreter e1211589528538 :=
  wSource (t := t_e1211589528538) (replay_sound (ps := []) (t := e1211589528538) (by decide)) (by decide)
def e1211589528814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211589528814 : Closed e1211589528814 ∧ code e1211589528814 = 5609636039918 := by decide
private def t_e1211589528814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211589528814 : ¬ IsSelfInterpreter e1211589528814 :=
  wSource (t := t_e1211589528814) (replay_sound (ps := []) (t := e1211589528814) (by decide)) (by decide)
def e1211589528822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211589528822 : Closed e1211589528822 ∧ code e1211589528822 = 5609636039926 := by decide
private def t_e1211589528822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211589528822 : ¬ IsSelfInterpreter e1211589528822 :=
  wSource (t := t_e1211589528822) (replay_sound (ps := []) (t := e1211589528822) (by decide)) (by decide)
def e1211589529198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211589529198 : Closed e1211589529198 ∧ code e1211589529198 = 5609636040302 := by decide
private def t_e1211589529198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211589529198 : ¬ IsSelfInterpreter e1211589529198 :=
  wSource (t := t_e1211589529198) (replay_sound (ps := []) (t := e1211589529198) (by decide)) (by decide)
def e1211589529210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211589529210 : Closed e1211589529210 ∧ code e1211589529210 = 5609636040314 := by decide
private def t_e1211589529210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211589529210 : ¬ IsSelfInterpreter e1211589529210 :=
  wSource (t := t_e1211589529210) (replay_sound (ps := []) (t := e1211589529210) (by decide)) (by decide)
def e1211589529398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211589529398 : Closed e1211589529398 ∧ code e1211589529398 = 5609636040502 := by decide
private def t_e1211589529398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211589529398 : ¬ IsSelfInterpreter e1211589529398 :=
  wSource (t := t_e1211589529398) (replay_sound (ps := []) (t := e1211589529398) (by decide)) (by decide)
def e1211589529402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211589529402 : Closed e1211589529402 ∧ code e1211589529402 = 5609636040506 := by decide
private def t_e1211589529402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211589529402 : ¬ IsSelfInterpreter e1211589529402 :=
  wSource (t := t_e1211589529402) (replay_sound (ps := []) (t := e1211589529402) (by decide)) (by decide)
def e1211589727966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211589727966 : Closed e1211589727966 ∧ code e1211589727966 = 5609636239070 := by decide
theorem cert_e1211589727966 : check e1211589727966 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589727990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211589727990 : Closed e1211589727990 ∧ code e1211589727990 = 5609636239094 := by decide
theorem cert_e1211589727990 : check e1211589727990 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211589728094 : Closed e1211589728094 ∧ code e1211589728094 = 5609636239198 := by decide
theorem cert_e1211589728094 : check e1211589728094 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211589728122 : Closed e1211589728122 ∧ code e1211589728122 = 5609636239226 := by decide
theorem cert_e1211589728122 : check e1211589728122 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211589728214 : Closed e1211589728214 ∧ code e1211589728214 = 5609636239318 := by decide
theorem cert_e1211589728214 : check e1211589728214 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211589728218 : Closed e1211589728218 ∧ code e1211589728218 = 5609636239322 := by decide
theorem cert_e1211589728218 : check e1211589728218 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211589728734 : Closed e1211589728734 ∧ code e1211589728734 = 5609636239838 := by decide
theorem cert_e1211589728734 : check e1211589728734 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589728758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211589728758 : Closed e1211589728758 ∧ code e1211589728758 = 5609636239862 := by decide
theorem cert_e1211589728758 : check e1211589728758 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589729502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211589729502 : Closed e1211589729502 ∧ code e1211589729502 = 5609636240606 := by decide
theorem cert_e1211589729502 : check e1211589729502 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589729530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211589729530 : Closed e1211589729530 ∧ code e1211589729530 = 5609636240634 := by decide
theorem cert_e1211589729530 : check e1211589729530 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589730102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211589730102 : Closed e1211589730102 ∧ code e1211589730102 = 5609636241206 := by decide
theorem cert_e1211589730102 : check e1211589730102 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589730106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211589730106 : Closed e1211589730106 ∧ code e1211589730106 = 5609636241210 := by decide
theorem cert_e1211589730106 : check e1211589730106 [[],[],[],[],[],[]] .smaller = true := by decide
def e1211589744878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211589744878 : Closed e1211589744878 ∧ code e1211589744878 = 5609636255982 := by decide
theorem cert_e1211589744878 : check e1211589744878 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589744886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211589744886 : Closed e1211589744886 ∧ code e1211589744886 = 5609636255990 := by decide
theorem cert_e1211589744886 : check e1211589744886 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589745438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211589745438 : Closed e1211589745438 ∧ code e1211589745438 = 5609636256542 := by decide
theorem cert_e1211589745438 : check e1211589745438 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589745550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211589745550 : Closed e1211589745550 ∧ code e1211589745550 = 5609636256654 := by decide
theorem cert_e1211589745550 : check e1211589745550 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589745774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211589745774 : Closed e1211589745774 ∧ code e1211589745774 = 5609636256878 := by decide
theorem cert_e1211589745774 : check e1211589745774 [[],[],[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211589745786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211589745786 : Closed e1211589745786 ∧ code e1211589745786 = 5609636256890 := by decide
theorem cert_e1211589745786 : check e1211589745786 [[],[],[],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e1211589745950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211589745950 : Closed e1211589745950 ∧ code e1211589745950 = 5609636257054 := by decide
theorem cert_e1211589745950 : check e1211589745950 [[],[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211589746118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211589746118 : Closed e1211589746118 ∧ code e1211589746118 = 5609636257222 := by decide
private def t_e1211589746118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem cert_e1211589746118 : ¬ IsSelfInterpreter e1211589746118 :=
  wSource (t := t_e1211589746118) (replay_sound (ps := []) (t := e1211589746118) (by decide)) (by decide)
def e1211589746142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211589746142 : Closed e1211589746142 ∧ code e1211589746142 = 5609636257246 := by decide
private def t_e1211589746142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem cert_e1211589746142 : ¬ IsSelfInterpreter e1211589746142 :=
  wSource (t := t_e1211589746142) (replay_sound (ps := []) (t := e1211589746142) (by decide)) (by decide)
def e1211589746158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211589746158 : Closed e1211589746158 ∧ code e1211589746158 = 5609636257262 := by decide
private def t_e1211589746158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem cert_e1211589746158 : ¬ IsSelfInterpreter e1211589746158 :=
  wSource (t := t_e1211589746158) (replay_sound (ps := []) (t := e1211589746158) (by decide)) (by decide)
def e1211589746230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211589746230 : Closed e1211589746230 ∧ code e1211589746230 = 5609636257334 := by decide
theorem cert_e1211589746230 : check e1211589746230 [[],[],[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211589746234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211589746234 : Closed e1211589746234 ∧ code e1211589746234 = 5609636257338 := by decide
theorem cert_e1211589746234 : check e1211589746234 [[],[],[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211589746318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211589746318 : Closed e1211589746318 ∧ code e1211589746318 = 5609636257422 := by decide
theorem cert_e1211589746318 : check e1211589746318 [[],[],[],[],[],[],[.under,.left]] .chain = true := by decide
def e1211589746374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211589746374 : Closed e1211589746374 ∧ code e1211589746374 = 5609636257478 := by decide
private def t_e1211589746374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem cert_e1211589746374 : ¬ IsSelfInterpreter e1211589746374 :=
  wSource (t := t_e1211589746374) (replay_sound (ps := []) (t := e1211589746374) (by decide)) (by decide)
def e1211589746398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211589746398 : Closed e1211589746398 ∧ code e1211589746398 = 5609636257502 := by decide
private def t_e1211589746398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem cert_e1211589746398 : ¬ IsSelfInterpreter e1211589746398 :=
  wSource (t := t_e1211589746398) (replay_sound (ps := []) (t := e1211589746398) (by decide)) (by decide)
def e1211589746422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211589746422 : Closed e1211589746422 ∧ code e1211589746422 = 5609636257526 := by decide
private def t_e1211589746422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem cert_e1211589746422 : ¬ IsSelfInterpreter e1211589746422 :=
  wSource (t := t_e1211589746422) (replay_sound (ps := []) (t := e1211589746422) (by decide)) (by decide)
end Blc.Floor42
