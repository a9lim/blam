import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203728610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203728610 : Closed e1211203728610 ∧ code e1211203728610 = 5609250239714 := by decide
theorem cert_e1211203728610 : check e1211203728610 [[],[]] .chain = true := by decide
def e1211203728622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203728622 : Closed e1211203728622 ∧ code e1211203728622 = 5609250239726 := by decide
theorem cert_e1211203728622 : check e1211203728622 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203728630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203728630 : Closed e1211203728630 ∧ code e1211203728630 = 5609250239734 := by decide
theorem cert_e1211203728630 : check e1211203728630 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203728910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203728910 : Closed e1211203728910 ∧ code e1211203728910 = 5609250240014 := by decide
theorem cert_e1211203728910 : check e1211203728910 [[],[]] .chain = true := by decide
def e1211203728922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203728922 : Closed e1211203728922 ∧ code e1211203728922 = 5609250240026 := by decide
theorem cert_e1211203728922 : check e1211203728922 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203728994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203728994 : Closed e1211203728994 ∧ code e1211203728994 = 5609250240098 := by decide
theorem cert_e1211203728994 : check e1211203728994 [[],[]] .chain = true := by decide
def e1211203729006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203729006 : Closed e1211203729006 ∧ code e1211203729006 = 5609250240110 := by decide
theorem cert_e1211203729006 : check e1211203729006 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203729014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203729014 : Closed e1211203729014 ∧ code e1211203729014 = 5609250240118 := by decide
theorem cert_e1211203729014 : check e1211203729014 [[],[]] .chain = true := by decide
def e1211203729018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203729018 : Closed e1211203729018 ∧ code e1211203729018 = 5609250240122 := by decide
theorem cert_e1211203729018 : check e1211203729018 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203729206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203729206 : Closed e1211203729206 ∧ code e1211203729206 = 5609250240310 := by decide
theorem cert_e1211203729206 : check e1211203729206 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203729210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203729210 : Closed e1211203729210 ∧ code e1211203729210 = 5609250240314 := by decide
theorem cert_e1211203729210 : check e1211203729210 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203729466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203729466 : Closed e1211203729466 ∧ code e1211203729466 = 5609250240570 := by decide
theorem cert_e1211203729466 : check e1211203729466 [[],[]] .chain = true := by decide
def e1211203729514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211203729514 : Closed e1211203729514 ∧ code e1211203729514 = 5609250240618 := by decide
theorem cert_e1211203729514 : check e1211203729514 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203729562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203729562 : Closed e1211203729562 ∧ code e1211203729562 = 5609250240666 := by decide
theorem cert_e1211203729562 : check e1211203729562 [[],[]] .chain = true := by decide
def e1211203729606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203729606 : Closed e1211203729606 ∧ code e1211203729606 = 5609250240710 := by decide
theorem cert_e1211203729606 : check e1211203729606 [[],[]] .chain = true := by decide
def e1211203729802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203729802 : Closed e1211203729802 ∧ code e1211203729802 = 5609250240906 := by decide
theorem cert_e1211203729802 : check e1211203729802 [[],[]] .chain = true := by decide
def e1211203729826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203729826 : Closed e1211203729826 ∧ code e1211203729826 = 5609250240930 := by decide
theorem cert_e1211203729826 : check e1211203729826 [[],[]] .chain = true := by decide
def e1211203729838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203729838 : Closed e1211203729838 ∧ code e1211203729838 = 5609250240942 := by decide
theorem cert_e1211203729838 : checkPay e1211203729838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] 1 [] = true := by decide
def e1211203729846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203729846 : Closed e1211203729846 ∧ code e1211203729846 = 5609250240950 := by decide
theorem cert_e1211203729846 : check e1211203729846 [[],[]] .chain = true := by decide
def e1211203729850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203729850 : Closed e1211203729850 ∧ code e1211203729850 = 5609250240954 := by decide
theorem cert_e1211203729850 : check e1211203729850 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203729878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203729878 : Closed e1211203729878 ∧ code e1211203729878 = 5609250240982 := by decide
theorem cert_e1211203729878 : check e1211203729878 [[],[]] .chain = true := by decide
def e1211203729882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203729882 : Closed e1211203729882 ∧ code e1211203729882 = 5609250240986 := by decide
theorem cert_e1211203729882 : check e1211203729882 [[],[]] .chain = true := by decide
def e1211203729898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203729898 : Closed e1211203729898 ∧ code e1211203729898 = 5609250241002 := by decide
theorem cert_e1211203729898 : check e1211203729898 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203729934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203729934 : Closed e1211203729934 ∧ code e1211203729934 = 5609250241038 := by decide
theorem cert_e1211203729934 : check e1211203729934 [[],[]] .chain = true := by decide
def e1211203729946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203729946 : Closed e1211203729946 ∧ code e1211203729946 = 5609250241050 := by decide
theorem cert_e1211203729946 : check e1211203729946 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203730018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203730018 : Closed e1211203730018 ∧ code e1211203730018 = 5609250241122 := by decide
theorem cert_e1211203730018 : check e1211203730018 [[],[]] .chain = true := by decide
def e1211203730030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203730030 : Closed e1211203730030 ∧ code e1211203730030 = 5609250241134 := by decide
theorem cert_e1211203730030 : checkPay e1211203730030 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] 0 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e1211203730038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203730038 : Closed e1211203730038 ∧ code e1211203730038 = 5609250241142 := by decide
theorem cert_e1211203730038 : check e1211203730038 [[],[]] .chain = true := by decide
def e1211203730042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203730042 : Closed e1211203730042 ∧ code e1211203730042 = 5609250241146 := by decide
theorem cert_e1211203730042 : checkPay e1211203730042 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] 0 [[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.right]] = true := by decide
def e1211203730230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203730230 : Closed e1211203730230 ∧ code e1211203730230 = 5609250241334 := by decide
theorem cert_e1211203730230 : check e1211203730230 [[],[]] .chain = true := by decide
def e1211203730234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203730234 : Closed e1211203730234 ∧ code e1211203730234 = 5609250241338 := by decide
theorem cert_e1211203730234 : check e1211203730234 [[],[]] .chain = true := by decide
def e1211203730330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203730330 : Closed e1211203730330 ∧ code e1211203730330 = 5609250241434 := by decide
theorem cert_e1211203730330 : check e1211203730330 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203730646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203730646 : Closed e1211203730646 ∧ code e1211203730646 = 5609250241750 := by decide
theorem cert_e1211203730646 : check e1211203730646 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203730650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203730650 : Closed e1211203730650 ∧ code e1211203730650 = 5609250241754 := by decide
theorem cert_e1211203730650 : check e1211203730650 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203730666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203730666 : Closed e1211203730666 ∧ code e1211203730666 = 5609250241770 := by decide
theorem cert_e1211203730666 : check e1211203730666 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203730742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203730742 : Closed e1211203730742 ∧ code e1211203730742 = 5609250241846 := by decide
theorem cert_e1211203730742 : check e1211203730742 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203730746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203730746 : Closed e1211203730746 ∧ code e1211203730746 = 5609250241850 := by decide
theorem cert_e1211203730746 : check e1211203730746 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203730842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203730842 : Closed e1211203730842 ∧ code e1211203730842 = 5609250241946 := by decide
theorem cert_e1211203730842 : check e1211203730842 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203738294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203738294 : Closed e1211203738294 ∧ code e1211203738294 = 5609250249398 := by decide
theorem cert_e1211203738294 : check e1211203738294 [[],[]] .chain = true := by decide
def e1211203738326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203738326 : Closed e1211203738326 ∧ code e1211203738326 = 5609250249430 := by decide
theorem cert_e1211203738326 : check e1211203738326 [[],[]] .chain = true := by decide
def e1211203738330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203738330 : Closed e1211203738330 ∧ code e1211203738330 = 5609250249434 := by decide
theorem cert_e1211203738330 : check e1211203738330 [[],[]] .chain = true := by decide
def e1211203738454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203738454 : Closed e1211203738454 ∧ code e1211203738454 = 5609250249558 := by decide
theorem cert_e1211203738454 : check e1211203738454 [[],[]] .chain = true := by decide
def e1211203738458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203738458 : Closed e1211203738458 ∧ code e1211203738458 = 5609250249562 := by decide
theorem cert_e1211203738458 : check e1211203738458 [[],[]] .chain = true := by decide
def e1211203738474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203738474 : Closed e1211203738474 ∧ code e1211203738474 = 5609250249578 := by decide
theorem cert_e1211203738474 : check e1211203738474 [[],[]] .chain = true := by decide
def e1211203738966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203738966 : Closed e1211203738966 ∧ code e1211203738966 = 5609250250070 := by decide
theorem cert_e1211203738966 : check e1211203738966 [[],[]] .chain = true := by decide
def e1211203738970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203738970 : Closed e1211203738970 ∧ code e1211203738970 = 5609250250074 := by decide
theorem cert_e1211203738970 : check e1211203738970 [[],[]] .chain = true := by decide
def e1211203738986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203738986 : Closed e1211203738986 ∧ code e1211203738986 = 5609250250090 := by decide
theorem cert_e1211203738986 : check e1211203738986 [[],[]] .chain = true := by decide
def e1211203739050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203739050 : Closed e1211203739050 ∧ code e1211203739050 = 5609250250154 := by decide
theorem cert_e1211203739050 : check e1211203739050 [[],[]] .chain = true := by decide
def e1211203739830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 1))))))
theorem wire_e1211203739830 : Closed e1211203739830 ∧ code e1211203739830 = 5609250250934 := by decide
theorem cert_e1211203739830 : check e1211203739830 [[],[]] .chain = true := by decide
def e1211203739862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e1211203739862 : Closed e1211203739862 ∧ code e1211203739862 = 5609250250966 := by decide
theorem cert_e1211203739862 : check e1211203739862 [[],[]] .chain = true := by decide
def e1211203739866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e1211203739866 : Closed e1211203739866 ∧ code e1211203739866 = 5609250250970 := by decide
theorem cert_e1211203739866 : check e1211203739866 [[],[]] .chain = true := by decide
def e1211203740214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203740214 : Closed e1211203740214 ∧ code e1211203740214 = 5609250251318 := by decide
theorem cert_e1211203740214 : check e1211203740214 [[],[]] .chain = true := by decide
def e1211203740218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203740218 : Closed e1211203740218 ∧ code e1211203740218 = 5609250251322 := by decide
theorem cert_e1211203740218 : check e1211203740218 [[],[]] .chain = true := by decide
def e1211203740302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203740302 : Closed e1211203740302 ∧ code e1211203740302 = 5609250251406 := by decide
theorem cert_e1211203740302 : check e1211203740302 [[],[]] .chain = true := by decide
def e1211203740358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203740358 : Closed e1211203740358 ∧ code e1211203740358 = 5609250251462 := by decide
theorem cert_e1211203740358 : check e1211203740358 [[],[]] .chain = true := by decide
def e1211203740438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203740438 : Closed e1211203740438 ∧ code e1211203740438 = 5609250251542 := by decide
theorem cert_e1211203740438 : check e1211203740438 [[],[]] .chain = true := by decide
def e1211203740514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203740514 : Closed e1211203740514 ∧ code e1211203740514 = 5609250251618 := by decide
theorem cert_e1211203740514 : check e1211203740514 [[],[]] .chain = true := by decide
def e1211203740526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203740526 : Closed e1211203740526 ∧ code e1211203740526 = 5609250251630 := by decide
theorem cert_e1211203740526 : check e1211203740526 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203740534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203740534 : Closed e1211203740534 ∧ code e1211203740534 = 5609250251638 := by decide
theorem cert_e1211203740534 : check e1211203740534 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203740554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203740554 : Closed e1211203740554 ∧ code e1211203740554 = 5609250251658 := by decide
theorem cert_e1211203740554 : check e1211203740554 [[],[]] .chain = true := by decide
def e1211203740578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203740578 : Closed e1211203740578 ∧ code e1211203740578 = 5609250251682 := by decide
theorem cert_e1211203740578 : check e1211203740578 [[],[]] .chain = true := by decide
def e1211203740590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203740590 : Closed e1211203740590 ∧ code e1211203740590 = 5609250251694 := by decide
theorem cert_e1211203740590 : check e1211203740590 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203740598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e1211203740598 : Closed e1211203740598 ∧ code e1211203740598 = 5609250251702 := by decide
theorem cert_e1211203740598 : check e1211203740598 [[],[]] .chain = true := by decide
def e1211203740602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203740602 : Closed e1211203740602 ∧ code e1211203740602 = 5609250251706 := by decide
theorem cert_e1211203740602 : check e1211203740602 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203740630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203740630 : Closed e1211203740630 ∧ code e1211203740630 = 5609250251734 := by decide
theorem cert_e1211203740630 : check e1211203740630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203740634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203740634 : Closed e1211203740634 ∧ code e1211203740634 = 5609250251738 := by decide
theorem cert_e1211203740634 : check e1211203740634 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203741366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e1211203741366 : Closed e1211203741366 ∧ code e1211203741366 = 5609250252470 := by decide
theorem cert_e1211203741366 : check e1211203741366 [[],[]] .chain = true := by decide
def e1211203741398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203741398 : Closed e1211203741398 ∧ code e1211203741398 = 5609250252502 := by decide
theorem cert_e1211203741398 : check e1211203741398 [[],[]] .chain = true := by decide
def e1211203741402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203741402 : Closed e1211203741402 ∧ code e1211203741402 = 5609250252506 := by decide
theorem cert_e1211203741402 : check e1211203741402 [[],[]] .chain = true := by decide
def e1211203741526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203741526 : Closed e1211203741526 ∧ code e1211203741526 = 5609250252630 := by decide
theorem cert_e1211203741526 : check e1211203741526 [[],[]] .chain = true := by decide
def e1211203741530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203741530 : Closed e1211203741530 ∧ code e1211203741530 = 5609250252634 := by decide
theorem cert_e1211203741530 : check e1211203741530 [[],[]] .chain = true := by decide
def e1211203741546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203741546 : Closed e1211203741546 ∧ code e1211203741546 = 5609250252650 := by decide
theorem cert_e1211203741546 : check e1211203741546 [[],[]] .chain = true := by decide
def e1211203741750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203741750 : Closed e1211203741750 ∧ code e1211203741750 = 5609250252854 := by decide
theorem cert_e1211203741750 : check e1211203741750 [[],[]] .chain = true := by decide
def e1211203741838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203741838 : Closed e1211203741838 ∧ code e1211203741838 = 5609250252942 := by decide
theorem cert_e1211203741838 : check e1211203741838 [[],[]] .chain = true := by decide
def e1211203741922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203741922 : Closed e1211203741922 ∧ code e1211203741922 = 5609250253026 := by decide
theorem cert_e1211203741922 : check e1211203741922 [[],[]] .chain = true := by decide
def e1211203741934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203741934 : Closed e1211203741934 ∧ code e1211203741934 = 5609250253038 := by decide
theorem cert_e1211203741934 : check e1211203741934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203741942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203741942 : Closed e1211203741942 ∧ code e1211203741942 = 5609250253046 := by decide
theorem cert_e1211203741942 : check e1211203741942 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203742134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203742134 : Closed e1211203742134 ∧ code e1211203742134 = 5609250253238 := by decide
theorem cert_e1211203742134 : check e1211203742134 [[],[]] .chain = true := by decide
def e1211203742166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203742166 : Closed e1211203742166 ∧ code e1211203742166 = 5609250253270 := by decide
theorem cert_e1211203742166 : check e1211203742166 [[],[]] .chain = true := by decide
def e1211203742170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203742170 : Closed e1211203742170 ∧ code e1211203742170 = 5609250253274 := by decide
theorem cert_e1211203742170 : check e1211203742170 [[],[]] .chain = true := by decide
def e1211203742326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203742326 : Closed e1211203742326 ∧ code e1211203742326 = 5609250253430 := by decide
theorem cert_e1211203742326 : check e1211203742326 [[],[]] .chain = true := by decide
def e1211203742470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203742470 : Closed e1211203742470 ∧ code e1211203742470 = 5609250253574 := by decide
theorem cert_e1211203742470 : check e1211203742470 [[],[]] .chain = true := by decide
def e1211203742494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203742494 : Closed e1211203742494 ∧ code e1211203742494 = 5609250253598 := by decide
theorem cert_e1211203742494 : check e1211203742494 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203742518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203742518 : Closed e1211203742518 ∧ code e1211203742518 = 5609250253622 := by decide
theorem cert_e1211203742518 : check e1211203742518 [[],[]] .chain = true := by decide
def e1211203742522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203742522 : Closed e1211203742522 ∧ code e1211203742522 = 5609250253626 := by decide
theorem cert_e1211203742522 : check e1211203742522 [[],[]] .chain = true := by decide
def e1211203742606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203742606 : Closed e1211203742606 ∧ code e1211203742606 = 5609250253710 := by decide
theorem cert_e1211203742606 : check e1211203742606 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203742742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203742742 : Closed e1211203742742 ∧ code e1211203742742 = 5609250253846 := by decide
theorem cert_e1211203742742 : check e1211203742742 [[],[]] .chain = true := by decide
def e1211203742746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203742746 : Closed e1211203742746 ∧ code e1211203742746 = 5609250253850 := by decide
theorem cert_e1211203742746 : check e1211203742746 [[],[]] .chain = true := by decide
def e1211203742790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203742790 : Closed e1211203742790 ∧ code e1211203742790 = 5609250253894 := by decide
theorem cert_e1211203742790 : check e1211203742790 [[],[]] .chain = true := by decide
def e1211203742818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203742818 : Closed e1211203742818 ∧ code e1211203742818 = 5609250253922 := by decide
theorem cert_e1211203742818 : check e1211203742818 [[],[]] .chain = true := by decide
def e1211203742830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203742830 : Closed e1211203742830 ∧ code e1211203742830 = 5609250253934 := by decide
theorem cert_e1211203742830 : check e1211203742830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203742838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203742838 : Closed e1211203742838 ∧ code e1211203742838 = 5609250253942 := by decide
theorem cert_e1211203742838 : check e1211203742838 [[],[]] .chain = true := by decide
def e1211203742842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203742842 : Closed e1211203742842 ∧ code e1211203742842 = 5609250253946 := by decide
theorem cert_e1211203742842 : check e1211203742842 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203742934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203742934 : Closed e1211203742934 ∧ code e1211203742934 = 5609250254038 := by decide
theorem cert_e1211203742934 : check e1211203742934 [[],[]] .chain = true := by decide
def e1211203742938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203742938 : Closed e1211203742938 ∧ code e1211203742938 = 5609250254042 := by decide
theorem cert_e1211203742938 : check e1211203742938 [[],[]] .chain = true := by decide
def e1211203742954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203742954 : Closed e1211203742954 ∧ code e1211203742954 = 5609250254058 := by decide
theorem cert_e1211203742954 : check e1211203742954 [[],[]] .chain = true := by decide
def e1211203742982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203742982 : Closed e1211203742982 ∧ code e1211203742982 = 5609250254086 := by decide
theorem cert_e1211203742982 : check e1211203742982 [[],[]] .chain = true := by decide
def e1211203743006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203743006 : Closed e1211203743006 ∧ code e1211203743006 = 5609250254110 := by decide
theorem cert_e1211203743006 : check e1211203743006 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203743030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203743030 : Closed e1211203743030 ∧ code e1211203743030 = 5609250254134 := by decide
theorem cert_e1211203743030 : check e1211203743030 [[],[]] .chain = true := by decide
def e1211203743034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203743034 : Closed e1211203743034 ∧ code e1211203743034 = 5609250254138 := by decide
theorem cert_e1211203743034 : check e1211203743034 [[],[]] .chain = true := by decide
def e1211203743106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203743106 : Closed e1211203743106 ∧ code e1211203743106 = 5609250254210 := by decide
theorem cert_e1211203743106 : check e1211203743106 [[],[]] .chain = true := by decide
def e1211203743118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203743118 : Closed e1211203743118 ∧ code e1211203743118 = 5609250254222 := by decide
theorem cert_e1211203743118 : check e1211203743118 [[],[]] .chain = true := by decide
def e1211203743130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203743130 : Closed e1211203743130 ∧ code e1211203743130 = 5609250254234 := by decide
theorem cert_e1211203743130 : check e1211203743130 [[],[]] .chain = true := by decide
def e1211203743174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203743174 : Closed e1211203743174 ∧ code e1211203743174 = 5609250254278 := by decide
theorem cert_e1211203743174 : check e1211203743174 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203743286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203743286 : Closed e1211203743286 ∧ code e1211203743286 = 5609250254390 := by decide
theorem cert_e1211203743286 : check e1211203743286 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203743290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203743290 : Closed e1211203743290 ∧ code e1211203743290 = 5609250254394 := by decide
theorem cert_e1211203743290 : check e1211203743290 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203743374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203743374 : Closed e1211203743374 ∧ code e1211203743374 = 5609250254478 := by decide
theorem cert_e1211203743374 : check e1211203743374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203743430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203743430 : Closed e1211203743430 ∧ code e1211203743430 = 5609250254534 := by decide
theorem cert_e1211203743430 : check e1211203743430 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211203743830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e1211203743830 : Closed e1211203743830 ∧ code e1211203743830 = 5609250254934 := by decide
theorem cert_e1211203743830 : check e1211203743830 [[],[]] .chain = true := by decide
def e1211203743834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e1211203743834 : Closed e1211203743834 ∧ code e1211203743834 = 5609250254938 := by decide
theorem cert_e1211203743834 : check e1211203743834 [[],[]] .chain = true := by decide
def e1211203743850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e1211203743850 : Closed e1211203743850 ∧ code e1211203743850 = 5609250254954 := by decide
theorem cert_e1211203743850 : check e1211203743850 [[],[]] .chain = true := by decide
def e1211203744026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203744026 : Closed e1211203744026 ∧ code e1211203744026 = 5609250255130 := by decide
theorem cert_e1211203744026 : check e1211203744026 [[],[]] .chain = true := by decide
def e1211203744070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203744070 : Closed e1211203744070 ∧ code e1211203744070 = 5609250255174 := by decide
theorem cert_e1211203744070 : check e1211203744070 [[],[]] .chain = true := by decide
def e1211203744138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203744138 : Closed e1211203744138 ∧ code e1211203744138 = 5609250255242 := by decide
theorem cert_e1211203744138 : check e1211203744138 [[],[]] .chain = true := by decide
def e1211203744162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203744162 : Closed e1211203744162 ∧ code e1211203744162 = 5609250255266 := by decide
theorem cert_e1211203744162 : check e1211203744162 [[],[]] .chain = true := by decide
def e1211203744174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203744174 : Closed e1211203744174 ∧ code e1211203744174 = 5609250255278 := by decide
theorem cert_e1211203744174 : check e1211203744174 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203744182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e1211203744182 : Closed e1211203744182 ∧ code e1211203744182 = 5609250255286 := by decide
theorem cert_e1211203744182 : check e1211203744182 [[],[]] .chain = true := by decide
def e1211203744186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203744186 : Closed e1211203744186 ∧ code e1211203744186 = 5609250255290 := by decide
theorem cert_e1211203744186 : check e1211203744186 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203744214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203744214 : Closed e1211203744214 ∧ code e1211203744214 = 5609250255318 := by decide
theorem cert_e1211203744214 : check e1211203744214 [[],[]] .chain = true := by decide
def e1211203744218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203744218 : Closed e1211203744218 ∧ code e1211203744218 = 5609250255322 := by decide
theorem cert_e1211203744218 : check e1211203744218 [[],[]] .chain = true := by decide
def e1211203744234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e1211203744234 : Closed e1211203744234 ∧ code e1211203744234 = 5609250255338 := by decide
theorem cert_e1211203744234 : check e1211203744234 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203744598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203744598 : Closed e1211203744598 ∧ code e1211203744598 = 5609250255702 := by decide
theorem cert_e1211203744598 : check e1211203744598 [[],[]] .chain = true := by decide
def e1211203744602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203744602 : Closed e1211203744602 ∧ code e1211203744602 = 5609250255706 := by decide
theorem cert_e1211203744602 : check e1211203744602 [[],[]] .chain = true := by decide
def e1211203744618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203744618 : Closed e1211203744618 ∧ code e1211203744618 = 5609250255722 := by decide
theorem cert_e1211203744618 : check e1211203744618 [[],[]] .chain = true := by decide
def e1211203744682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e1211203744682 : Closed e1211203744682 ∧ code e1211203744682 = 5609250255786 := by decide
theorem cert_e1211203744682 : check e1211203744682 [[],[]] .chain = true := by decide
def e1211203744790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203744790 : Closed e1211203744790 ∧ code e1211203744790 = 5609250255894 := by decide
theorem cert_e1211203744790 : check e1211203744790 [[],[]] .chain = true := by decide
def e1211203744794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203744794 : Closed e1211203744794 ∧ code e1211203744794 = 5609250255898 := by decide
theorem cert_e1211203744794 : check e1211203744794 [[],[]] .chain = true := by decide
def e1211203744838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203744838 : Closed e1211203744838 ∧ code e1211203744838 = 5609250255942 := by decide
theorem cert_e1211203744838 : check e1211203744838 [[],[]] .chain = true := by decide
def e1211203744866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203744866 : Closed e1211203744866 ∧ code e1211203744866 = 5609250255970 := by decide
theorem cert_e1211203744866 : check e1211203744866 [[],[]] .chain = true := by decide
def e1211203744878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203744878 : Closed e1211203744878 ∧ code e1211203744878 = 5609250255982 := by decide
theorem cert_e1211203744878 : check e1211203744878 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203744886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203744886 : Closed e1211203744886 ∧ code e1211203744886 = 5609250255990 := by decide
theorem cert_e1211203744886 : check e1211203744886 [[],[]] .chain = true := by decide
def e1211203744890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203744890 : Closed e1211203744890 ∧ code e1211203744890 = 5609250255994 := by decide
theorem cert_e1211203744890 : check e1211203744890 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203744982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203744982 : Closed e1211203744982 ∧ code e1211203744982 = 5609250256086 := by decide
theorem cert_e1211203744982 : check e1211203744982 [[],[]] .chain = true := by decide
def e1211203744986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203744986 : Closed e1211203744986 ∧ code e1211203744986 = 5609250256090 := by decide
theorem cert_e1211203744986 : check e1211203744986 [[],[]] .chain = true := by decide
def e1211203745002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203745002 : Closed e1211203745002 ∧ code e1211203745002 = 5609250256106 := by decide
theorem cert_e1211203745002 : check e1211203745002 [[],[]] .chain = true := by decide
def e1211203745030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203745030 : Closed e1211203745030 ∧ code e1211203745030 = 5609250256134 := by decide
theorem cert_e1211203745030 : check e1211203745030 [[],[]] .chain = true := by decide
def e1211203745054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203745054 : Closed e1211203745054 ∧ code e1211203745054 = 5609250256158 := by decide
theorem cert_e1211203745054 : check e1211203745054 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203745078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203745078 : Closed e1211203745078 ∧ code e1211203745078 = 5609250256182 := by decide
theorem cert_e1211203745078 : check e1211203745078 [[],[]] .chain = true := by decide
def e1211203745082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203745082 : Closed e1211203745082 ∧ code e1211203745082 = 5609250256186 := by decide
theorem cert_e1211203745082 : check e1211203745082 [[],[]] .chain = true := by decide
def e1211203745154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203745154 : Closed e1211203745154 ∧ code e1211203745154 = 5609250256258 := by decide
theorem cert_e1211203745154 : check e1211203745154 [[],[]] .chain = true := by decide
def e1211203745166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203745166 : Closed e1211203745166 ∧ code e1211203745166 = 5609250256270 := by decide
theorem cert_e1211203745166 : check e1211203745166 [[],[]] .chain = true := by decide
def e1211203745178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203745178 : Closed e1211203745178 ∧ code e1211203745178 = 5609250256282 := by decide
theorem cert_e1211203745178 : check e1211203745178 [[],[]] .chain = true := by decide
def e1211203745222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203745222 : Closed e1211203745222 ∧ code e1211203745222 = 5609250256326 := by decide
theorem cert_e1211203745222 : check e1211203745222 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203745290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203745290 : Closed e1211203745290 ∧ code e1211203745290 = 5609250256394 := by decide
theorem cert_e1211203745290 : check e1211203745290 [[],[]] .chain = true := by decide
def e1211203745334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203745334 : Closed e1211203745334 ∧ code e1211203745334 = 5609250256438 := by decide
theorem cert_e1211203745334 : check e1211203745334 [[],[]] .chain = true := by decide
def e1211203745338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203745338 : Closed e1211203745338 ∧ code e1211203745338 = 5609250256442 := by decide
theorem cert_e1211203745338 : check e1211203745338 [[],[]] .chain = true := by decide
def e1211203745386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203745386 : Closed e1211203745386 ∧ code e1211203745386 = 5609250256490 := by decide
theorem cert_e1211203745386 : check e1211203745386 [[],[]] .chain = true := by decide
def e1211203745410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203745410 : Closed e1211203745410 ∧ code e1211203745410 = 5609250256514 := by decide
theorem cert_e1211203745410 : check e1211203745410 [[],[]] .chain = true := by decide
def e1211203745422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203745422 : Closed e1211203745422 ∧ code e1211203745422 = 5609250256526 := by decide
theorem cert_e1211203745422 : check e1211203745422 [[],[]] .chain = true := by decide
def e1211203745434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203745434 : Closed e1211203745434 ∧ code e1211203745434 = 5609250256538 := by decide
theorem cert_e1211203745434 : check e1211203745434 [[],[]] .chain = true := by decide
def e1211203745478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203745478 : Closed e1211203745478 ∧ code e1211203745478 = 5609250256582 := by decide
theorem cert_e1211203745478 : check e1211203745478 [[],[]] .chain = true := by decide
def e1211203745562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203745562 : Closed e1211203745562 ∧ code e1211203745562 = 5609250256666 := by decide
theorem cert_e1211203745562 : check e1211203745562 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203745606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203745606 : Closed e1211203745606 ∧ code e1211203745606 = 5609250256710 := by decide
theorem cert_e1211203745606 : check e1211203745606 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203746006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203746006 : Closed e1211203746006 ∧ code e1211203746006 = 5609250257110 := by decide
theorem cert_e1211203746006 : check e1211203746006 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203746010 : Closed e1211203746010 ∧ code e1211203746010 = 5609250257114 := by decide
theorem cert_e1211203746010 : check e1211203746010 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203746026 : Closed e1211203746026 ∧ code e1211203746026 = 5609250257130 := by decide
theorem cert_e1211203746026 : check e1211203746026 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203746358 : Closed e1211203746358 ∧ code e1211203746358 = 5609250257462 := by decide
theorem cert_e1211203746358 : check e1211203746358 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203746362 : Closed e1211203746362 ∧ code e1211203746362 = 5609250257466 := by decide
theorem cert_e1211203746362 : check e1211203746362 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203746446 : Closed e1211203746446 ∧ code e1211203746446 = 5609250257550 := by decide
theorem cert_e1211203746446 : check e1211203746446 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203746502 : Closed e1211203746502 ∧ code e1211203746502 = 5609250257606 := by decide
theorem cert_e1211203746502 : check e1211203746502 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor42
