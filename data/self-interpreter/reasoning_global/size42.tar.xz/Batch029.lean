import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e413499743070 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e413499743070 : Closed e413499743070 ∧ code e413499743070 = 4811546254174 := by decide
theorem cert_e413499743070 : check e413499743070 [] .sourceHead = true := by decide
def e413499743086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e413499743086 : Closed e413499743086 ∧ code e413499743086 = 4811546254190 := by decide
theorem cert_e413499743086 : check e413499743086 [] .sourceHead = true := by decide
def e413499743094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e413499743094 : Closed e413499743094 ∧ code e413499743094 = 4811546254198 := by decide
theorem cert_e413499743094 : check e413499743094 [] .sourceHead = true := by decide
def e413499743098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e413499743098 : Closed e413499743098 ∧ code e413499743098 = 4811546254202 := by decide
theorem cert_e413499743098 : check e413499743098 [] .sourceHead = true := by decide
def e413499743158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e413499743158 : Closed e413499743158 ∧ code e413499743158 = 4811546254262 := by decide
theorem cert_e413499743158 : check e413499743158 [] .sourceHead = true := by decide
def e413499743190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e413499743190 : Closed e413499743190 ∧ code e413499743190 = 4811546254294 := by decide
theorem cert_e413499743190 : check e413499743190 [] .sourceHead = true := by decide
def e413499743194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e413499743194 : Closed e413499743194 ∧ code e413499743194 = 4811546254298 := by decide
theorem cert_e413499743194 : check e413499743194 [] .sourceHead = true := by decide
def e413499743582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e413499743582 : Closed e413499743582 ∧ code e413499743582 = 4811546254686 := by decide
theorem cert_e413499743582 : check e413499743582 [] .sourceHead = true := by decide
def e413499743598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e413499743598 : Closed e413499743598 ∧ code e413499743598 = 4811546254702 := by decide
theorem cert_e413499743598 : check e413499743598 [] .sourceHead = true := by decide
def e413499743606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e413499743606 : Closed e413499743606 ∧ code e413499743606 = 4811546254710 := by decide
theorem cert_e413499743606 : check e413499743606 [] .sourceHead = true := by decide
def e413499743610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e413499743610 : Closed e413499743610 ∧ code e413499743610 = 4811546254714 := by decide
theorem cert_e413499743610 : check e413499743610 [] .sourceHead = true := by decide
def e413499743662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e413499743662 : Closed e413499743662 ∧ code e413499743662 = 4811546254766 := by decide
theorem cert_e413499743662 : check e413499743662 [] .sourceHead = true := by decide
def e413499743674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e413499743674 : Closed e413499743674 ∧ code e413499743674 = 4811546254778 := by decide
theorem cert_e413499743674 : check e413499743674 [] .sourceHead = true := by decide
def e413499743702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e413499743702 : Closed e413499743702 ∧ code e413499743702 = 4811546254806 := by decide
theorem cert_e413499743702 : check e413499743702 [] .sourceHead = true := by decide
def e413499743706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e413499743706 : Closed e413499743706 ∧ code e413499743706 = 4811546254810 := by decide
theorem cert_e413499743706 : check e413499743706 [] .sourceHead = true := by decide
def e413499743722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e413499743722 : Closed e413499743722 ∧ code e413499743722 = 4811546254826 := by decide
theorem cert_e413499743722 : check e413499743722 [] .sourceHead = true := by decide
def e413499743926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e413499743926 : Closed e413499743926 ∧ code e413499743926 = 4811546255030 := by decide
theorem cert_e413499743926 : check e413499743926 [] .sourceHead = true := by decide
def e413499743958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e413499743958 : Closed e413499743958 ∧ code e413499743958 = 4811546255062 := by decide
theorem cert_e413499743958 : check e413499743958 [] .sourceHead = true := by decide
def e413499743962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e413499743962 : Closed e413499743962 ∧ code e413499743962 = 4811546255066 := by decide
theorem cert_e413499743962 : check e413499743962 [] .sourceHead = true := by decide
def e413499744086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e413499744086 : Closed e413499744086 ∧ code e413499744086 = 4811546255190 := by decide
theorem cert_e413499744086 : check e413499744086 [] .sourceHead = true := by decide
def e413499744090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e413499744090 : Closed e413499744090 ∧ code e413499744090 = 4811546255194 := by decide
theorem cert_e413499744090 : check e413499744090 [] .sourceHead = true := by decide
def e413499744106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e413499744106 : Closed e413499744106 ∧ code e413499744106 = 4811546255210 := by decide
theorem cert_e413499744106 : check e413499744106 [] .sourceHead = true := by decide
def e413499746014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e413499746014 : Closed e413499746014 ∧ code e413499746014 = 4811546257118 := by decide
theorem cert_e413499746014 : check e413499746014 [] .sourceHead = true := by decide
def e413499746038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e413499746038 : Closed e413499746038 ∧ code e413499746038 = 4811546257142 := by decide
theorem cert_e413499746038 : check e413499746038 [] .sourceHead = true := by decide
def e413499746142 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e413499746142 : Closed e413499746142 ∧ code e413499746142 = 4811546257246 := by decide
theorem cert_e413499746142 : check e413499746142 [] .sourceHead = true := by decide
def e413499746158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e413499746158 : Closed e413499746158 ∧ code e413499746158 = 4811546257262 := by decide
theorem cert_e413499746158 : check e413499746158 [] .sourceHead = true := by decide
def e413499746166 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e413499746166 : Closed e413499746166 ∧ code e413499746166 = 4811546257270 := by decide
theorem cert_e413499746166 : check e413499746166 [] .sourceHead = true := by decide
def e413499746170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e413499746170 : Closed e413499746170 ∧ code e413499746170 = 4811546257274 := by decide
theorem cert_e413499746170 : check e413499746170 [] .sourceHead = true := by decide
def e413499746230 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e413499746230 : Closed e413499746230 ∧ code e413499746230 = 4811546257334 := by decide
theorem cert_e413499746230 : check e413499746230 [] .sourceHead = true := by decide
def e413499746262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e413499746262 : Closed e413499746262 ∧ code e413499746262 = 4811546257366 := by decide
theorem cert_e413499746262 : check e413499746262 [] .sourceHead = true := by decide
def e413499746266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e413499746266 : Closed e413499746266 ∧ code e413499746266 = 4811546257370 := by decide
theorem cert_e413499746266 : check e413499746266 [] .sourceHead = true := by decide
def e413499746782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e413499746782 : Closed e413499746782 ∧ code e413499746782 = 4811546257886 := by decide
theorem cert_e413499746782 : check e413499746782 [] .sourceHead = true := by decide
def e413499746806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e413499746806 : Closed e413499746806 ∧ code e413499746806 = 4811546257910 := by decide
theorem cert_e413499746806 : check e413499746806 [] .sourceHead = true := by decide
def e413499747550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e413499747550 : Closed e413499747550 ∧ code e413499747550 = 4811546258654 := by decide
theorem cert_e413499747550 : check e413499747550 [] .sourceHead = true := by decide
def e413499747566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e413499747566 : Closed e413499747566 ∧ code e413499747566 = 4811546258670 := by decide
theorem cert_e413499747566 : check e413499747566 [] .sourceHead = true := by decide
def e413499747574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e413499747574 : Closed e413499747574 ∧ code e413499747574 = 4811546258678 := by decide
theorem cert_e413499747574 : check e413499747574 [] .sourceHead = true := by decide
def e413499747578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e413499747578 : Closed e413499747578 ∧ code e413499747578 = 4811546258682 := by decide
theorem cert_e413499747578 : check e413499747578 [] .sourceHead = true := by decide
def e413499747958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e413499747958 : Closed e413499747958 ∧ code e413499747958 = 4811546259062 := by decide
theorem cert_e413499747958 : check e413499747958 [] .sourceHead = true := by decide
def e413499748150 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e413499748150 : Closed e413499748150 ∧ code e413499748150 = 4811546259254 := by decide
theorem cert_e413499748150 : check e413499748150 [] .sourceHead = true := by decide
def e413499748154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e413499748154 : Closed e413499748154 ∧ code e413499748154 = 4811546259258 := by decide
theorem cert_e413499748154 : check e413499748154 [] .sourceHead = true := by decide
def e413499749214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e413499749214 : Closed e413499749214 ∧ code e413499749214 = 4811546260318 := by decide
theorem cert_e413499749214 : check e413499749214 [] .sourceHead = true := by decide
def e413499749230 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e413499749230 : Closed e413499749230 ∧ code e413499749230 = 4811546260334 := by decide
theorem cert_e413499749230 : check e413499749230 [] .sourceHead = true := by decide
def e413499749238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e413499749238 : Closed e413499749238 ∧ code e413499749238 = 4811546260342 := by decide
theorem cert_e413499749238 : check e413499749238 [] .sourceHead = true := by decide
def e413499749242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e413499749242 : Closed e413499749242 ∧ code e413499749242 = 4811546260346 := by decide
theorem cert_e413499749242 : check e413499749242 [] .sourceHead = true := by decide
def e413499749294 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e413499749294 : Closed e413499749294 ∧ code e413499749294 = 4811546260398 := by decide
theorem cert_e413499749294 : check e413499749294 [] .sourceHead = true := by decide
def e413499749306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e413499749306 : Closed e413499749306 ∧ code e413499749306 = 4811546260410 := by decide
theorem cert_e413499749306 : check e413499749306 [] .sourceHead = true := by decide
def e413499749334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e413499749334 : Closed e413499749334 ∧ code e413499749334 = 4811546260438 := by decide
theorem cert_e413499749334 : check e413499749334 [] .sourceHead = true := by decide
def e413499749338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e413499749338 : Closed e413499749338 ∧ code e413499749338 = 4811546260442 := by decide
theorem cert_e413499749338 : check e413499749338 [] .sourceHead = true := by decide
def e413499749354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e413499749354 : Closed e413499749354 ∧ code e413499749354 = 4811546260458 := by decide
theorem cert_e413499749354 : check e413499749354 [] .sourceHead = true := by decide
def e413499749598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e413499749598 : Closed e413499749598 ∧ code e413499749598 = 4811546260702 := by decide
theorem cert_e413499749598 : check e413499749598 [] .sourceHead = true := by decide
def e413499749614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e413499749614 : Closed e413499749614 ∧ code e413499749614 = 4811546260718 := by decide
theorem cert_e413499749614 : check e413499749614 [] .sourceHead = true := by decide
def e413499749622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e413499749622 : Closed e413499749622 ∧ code e413499749622 = 4811546260726 := by decide
theorem cert_e413499749622 : check e413499749622 [] .sourceHead = true := by decide
def e413499749626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e413499749626 : Closed e413499749626 ∧ code e413499749626 = 4811546260730 := by decide
theorem cert_e413499749626 : check e413499749626 [] .sourceHead = true := by decide
def e413499749998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e413499749998 : Closed e413499749998 ∧ code e413499749998 = 4811546261102 := by decide
theorem cert_e413499749998 : check e413499749998 [] .sourceHead = true := by decide
def e413499750010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e413499750010 : Closed e413499750010 ∧ code e413499750010 = 4811546261114 := by decide
theorem cert_e413499750010 : check e413499750010 [] .sourceHead = true := by decide
def e413499750198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e413499750198 : Closed e413499750198 ∧ code e413499750198 = 4811546261302 := by decide
theorem cert_e413499750198 : check e413499750198 [] .sourceHead = true := by decide
def e413499750202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e413499750202 : Closed e413499750202 ∧ code e413499750202 = 4811546261306 := by decide
theorem cert_e413499750202 : check e413499750202 [] .sourceHead = true := by decide
def e413499750298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e413499750298 : Closed e413499750298 ∧ code e413499750298 = 4811546261402 := by decide
theorem cert_e413499750298 : check e413499750298 [] .sourceHead = true := by decide
def e413499750838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e413499750838 : Closed e413499750838 ∧ code e413499750838 = 4811546261942 := by decide
theorem cert_e413499750838 : check e413499750838 [] .sourceHead = true := by decide
def e413499750870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e413499750870 : Closed e413499750870 ∧ code e413499750870 = 4811546261974 := by decide
theorem cert_e413499750870 : check e413499750870 [] .sourceHead = true := by decide
def e413499750874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e413499750874 : Closed e413499750874 ∧ code e413499750874 = 4811546261978 := by decide
theorem cert_e413499750874 : check e413499750874 [] .sourceHead = true := by decide
def e413499751030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e413499751030 : Closed e413499751030 ∧ code e413499751030 = 4811546262134 := by decide
theorem cert_e413499751030 : check e413499751030 [] .sourceHead = true := by decide
def e413499751222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e413499751222 : Closed e413499751222 ∧ code e413499751222 = 4811546262326 := by decide
theorem cert_e413499751222 : check e413499751222 [] .sourceHead = true := by decide
def e413499751226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e413499751226 : Closed e413499751226 ∧ code e413499751226 = 4811546262330 := by decide
theorem cert_e413499751226 : check e413499751226 [] .sourceHead = true := by decide
def e413499751638 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e413499751638 : Closed e413499751638 ∧ code e413499751638 = 4811546262742 := by decide
theorem cert_e413499751638 : check e413499751638 [] .sourceHead = true := by decide
def e413499751642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e413499751642 : Closed e413499751642 ∧ code e413499751642 = 4811546262746 := by decide
theorem cert_e413499751642 : check e413499751642 [] .sourceHead = true := by decide
def e413499751658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e413499751658 : Closed e413499751658 ∧ code e413499751658 = 4811546262762 := by decide
theorem cert_e413499751658 : check e413499751658 [] .sourceHead = true := by decide
def e413499751734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e413499751734 : Closed e413499751734 ∧ code e413499751734 = 4811546262838 := by decide
theorem cert_e413499751734 : check e413499751734 [] .sourceHead = true := by decide
def e413499751738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e413499751738 : Closed e413499751738 ∧ code e413499751738 = 4811546262842 := by decide
theorem cert_e413499751738 : check e413499751738 [] .sourceHead = true := by decide
def e413499751834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e413499751834 : Closed e413499751834 ∧ code e413499751834 = 4811546262938 := by decide
theorem cert_e413499751834 : check e413499751834 [] .sourceHead = true := by decide
def e413499758302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e413499758302 : Closed e413499758302 ∧ code e413499758302 = 4811546269406 := by decide
theorem cert_e413499758302 : check e413499758302 [] .sourceHead = true := by decide
def e413499758326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e413499758326 : Closed e413499758326 ∧ code e413499758326 = 4811546269430 := by decide
theorem cert_e413499758326 : check e413499758326 [] .sourceHead = true := by decide
def e413499758430 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e413499758430 : Closed e413499758430 ∧ code e413499758430 = 4811546269534 := by decide
theorem cert_e413499758430 : check e413499758430 [] .sourceHead = true := by decide
def e413499758446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e413499758446 : Closed e413499758446 ∧ code e413499758446 = 4811546269550 := by decide
theorem cert_e413499758446 : check e413499758446 [] .sourceHead = true := by decide
def e413499758454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e413499758454 : Closed e413499758454 ∧ code e413499758454 = 4811546269558 := by decide
theorem cert_e413499758454 : check e413499758454 [] .sourceHead = true := by decide
def e413499758458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e413499758458 : Closed e413499758458 ∧ code e413499758458 = 4811546269562 := by decide
theorem cert_e413499758458 : check e413499758458 [] .sourceHead = true := by decide
def e413499758518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e413499758518 : Closed e413499758518 ∧ code e413499758518 = 4811546269622 := by decide
theorem cert_e413499758518 : check e413499758518 [] .sourceHead = true := by decide
def e413499758550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e413499758550 : Closed e413499758550 ∧ code e413499758550 = 4811546269654 := by decide
theorem cert_e413499758550 : check e413499758550 [] .sourceHead = true := by decide
def e413499758554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e413499758554 : Closed e413499758554 ∧ code e413499758554 = 4811546269658 := by decide
theorem cert_e413499758554 : check e413499758554 [] .sourceHead = true := by decide
def e413499759070 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e413499759070 : Closed e413499759070 ∧ code e413499759070 = 4811546270174 := by decide
theorem cert_e413499759070 : check e413499759070 [] .sourceHead = true := by decide
def e413499759094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e413499759094 : Closed e413499759094 ∧ code e413499759094 = 4811546270198 := by decide
theorem cert_e413499759094 : check e413499759094 [] .sourceHead = true := by decide
def e413499759838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e413499759838 : Closed e413499759838 ∧ code e413499759838 = 4811546270942 := by decide
theorem cert_e413499759838 : check e413499759838 [] .sourceHead = true := by decide
def e413499759854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e413499759854 : Closed e413499759854 ∧ code e413499759854 = 4811546270958 := by decide
theorem cert_e413499759854 : check e413499759854 [] .sourceHead = true := by decide
def e413499759862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e413499759862 : Closed e413499759862 ∧ code e413499759862 = 4811546270966 := by decide
theorem cert_e413499759862 : check e413499759862 [] .sourceHead = true := by decide
def e413499759866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e413499759866 : Closed e413499759866 ∧ code e413499759866 = 4811546270970 := by decide
theorem cert_e413499759866 : check e413499759866 [] .sourceHead = true := by decide
def e413499760246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e413499760246 : Closed e413499760246 ∧ code e413499760246 = 4811546271350 := by decide
theorem cert_e413499760246 : check e413499760246 [] .sourceHead = true := by decide
def e413499760438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e413499760438 : Closed e413499760438 ∧ code e413499760438 = 4811546271542 := by decide
theorem cert_e413499760438 : check e413499760438 [] .sourceHead = true := by decide
def e413499760442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e413499760442 : Closed e413499760442 ∧ code e413499760442 = 4811546271546 := by decide
theorem cert_e413499760442 : check e413499760442 [] .sourceHead = true := by decide
def e413499771742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e413499771742 : Closed e413499771742 ∧ code e413499771742 = 4811546282846 := by decide
theorem cert_e413499771742 : check e413499771742 [] .sourceHead = true := by decide
def e413499771758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e413499771758 : Closed e413499771758 ∧ code e413499771758 = 4811546282862 := by decide
theorem cert_e413499771758 : check e413499771758 [] .sourceHead = true := by decide
def e413499771766 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e413499771766 : Closed e413499771766 ∧ code e413499771766 = 4811546282870 := by decide
theorem cert_e413499771766 : check e413499771766 [] .sourceHead = true := by decide
def e413499771770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e413499771770 : Closed e413499771770 ∧ code e413499771770 = 4811546282874 := by decide
theorem cert_e413499771770 : check e413499771770 [] .sourceHead = true := by decide
def e413499771822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e413499771822 : Closed e413499771822 ∧ code e413499771822 = 4811546282926 := by decide
theorem cert_e413499771822 : check e413499771822 [] .sourceHead = true := by decide
def e413499771834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e413499771834 : Closed e413499771834 ∧ code e413499771834 = 4811546282938 := by decide
theorem cert_e413499771834 : check e413499771834 [] .sourceHead = true := by decide
def e413499771862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e413499771862 : Closed e413499771862 ∧ code e413499771862 = 4811546282966 := by decide
theorem cert_e413499771862 : check e413499771862 [] .sourceHead = true := by decide
def e413499771866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e413499771866 : Closed e413499771866 ∧ code e413499771866 = 4811546282970 := by decide
theorem cert_e413499771866 : check e413499771866 [] .sourceHead = true := by decide
def e413499771882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e413499771882 : Closed e413499771882 ∧ code e413499771882 = 4811546282986 := by decide
theorem cert_e413499771882 : check e413499771882 [] .sourceHead = true := by decide
def e413499772126 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e413499772126 : Closed e413499772126 ∧ code e413499772126 = 4811546283230 := by decide
theorem cert_e413499772126 : check e413499772126 [] .sourceHead = true := by decide
def e413499772142 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e413499772142 : Closed e413499772142 ∧ code e413499772142 = 4811546283246 := by decide
theorem cert_e413499772142 : check e413499772142 [] .sourceHead = true := by decide
def e413499772150 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e413499772150 : Closed e413499772150 ∧ code e413499772150 = 4811546283254 := by decide
theorem cert_e413499772150 : check e413499772150 [] .sourceHead = true := by decide
def e413499772154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e413499772154 : Closed e413499772154 ∧ code e413499772154 = 4811546283258 := by decide
theorem cert_e413499772154 : check e413499772154 [] .sourceHead = true := by decide
def e413499772526 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e413499772526 : Closed e413499772526 ∧ code e413499772526 = 4811546283630 := by decide
theorem cert_e413499772526 : check e413499772526 [] .sourceHead = true := by decide
def e413499772538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e413499772538 : Closed e413499772538 ∧ code e413499772538 = 4811546283642 := by decide
theorem cert_e413499772538 : check e413499772538 [] .sourceHead = true := by decide
def e413499772726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e413499772726 : Closed e413499772726 ∧ code e413499772726 = 4811546283830 := by decide
theorem cert_e413499772726 : check e413499772726 [] .sourceHead = true := by decide
def e413499772730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e413499772730 : Closed e413499772730 ∧ code e413499772730 = 4811546283834 := by decide
theorem cert_e413499772730 : check e413499772730 [] .sourceHead = true := by decide
def e413499772826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e413499772826 : Closed e413499772826 ∧ code e413499772826 = 4811546283930 := by decide
theorem cert_e413499772826 : check e413499772826 [] .sourceHead = true := by decide
def e413499778486 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e413499778486 : Closed e413499778486 ∧ code e413499778486 = 4811546289590 := by decide
theorem cert_e413499778486 : check e413499778486 [] .sourceHead = true := by decide
def e413499778518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e413499778518 : Closed e413499778518 ∧ code e413499778518 = 4811546289622 := by decide
theorem cert_e413499778518 : check e413499778518 [] .sourceHead = true := by decide
def e413499778522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e413499778522 : Closed e413499778522 ∧ code e413499778522 = 4811546289626 := by decide
theorem cert_e413499778522 : check e413499778522 [] .sourceHead = true := by decide
def e413499778678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e413499778678 : Closed e413499778678 ∧ code e413499778678 = 4811546289782 := by decide
theorem cert_e413499778678 : check e413499778678 [] .sourceHead = true := by decide
def e413499778870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e413499778870 : Closed e413499778870 ∧ code e413499778870 = 4811546289974 := by decide
theorem cert_e413499778870 : check e413499778870 [] .sourceHead = true := by decide
def e413499778874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e413499778874 : Closed e413499778874 ∧ code e413499778874 = 4811546289978 := by decide
theorem cert_e413499778874 : check e413499778874 [] .sourceHead = true := by decide
def e413499781846 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e413499781846 : Closed e413499781846 ∧ code e413499781846 = 4811546292950 := by decide
theorem cert_e413499781846 : check e413499781846 [] .sourceHead = true := by decide
def e413499781850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e413499781850 : Closed e413499781850 ∧ code e413499781850 = 4811546292954 := by decide
theorem cert_e413499781850 : check e413499781850 [] .sourceHead = true := by decide
def e413499781866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e413499781866 : Closed e413499781866 ∧ code e413499781866 = 4811546292970 := by decide
theorem cert_e413499781866 : check e413499781866 [] .sourceHead = true := by decide
def e413499781942 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e413499781942 : Closed e413499781942 ∧ code e413499781942 = 4811546293046 := by decide
theorem cert_e413499781942 : check e413499781942 [] .sourceHead = true := by decide
def e413499781946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e413499781946 : Closed e413499781946 ∧ code e413499781946 = 4811546293050 := by decide
theorem cert_e413499781946 : check e413499781946 [] .sourceHead = true := by decide
def e413499782042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e413499782042 : Closed e413499782042 ∧ code e413499782042 = 4811546293146 := by decide
theorem cert_e413499782042 : check e413499782042 [] .sourceHead = true := by decide
def e413500007278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e413500007278 : Closed e413500007278 ∧ code e413500007278 = 4811546518382 := by decide
theorem cert_e413500007278 : check e413500007278 [] .sourceHead = true := by decide
def e413500007286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e413500007286 : Closed e413500007286 ∧ code e413500007286 = 4811546518390 := by decide
theorem cert_e413500007286 : check e413500007286 [] .sourceHead = true := by decide
def e413500007342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e413500007342 : Closed e413500007342 ∧ code e413500007342 = 4811546518446 := by decide
theorem cert_e413500007342 : check e413500007342 [] .sourceHead = true := by decide
def e413500007354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e413500007354 : Closed e413500007354 ∧ code e413500007354 = 4811546518458 := by decide
theorem cert_e413500007354 : check e413500007354 [] .sourceHead = true := by decide
def e413500007382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e413500007382 : Closed e413500007382 ∧ code e413500007382 = 4811546518486 := by decide
theorem cert_e413500007382 : check e413500007382 [] .sourceHead = true := by decide
def e413500007386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e413500007386 : Closed e413500007386 ∧ code e413500007386 = 4811546518490 := by decide
theorem cert_e413500007386 : check e413500007386 [] .sourceHead = true := by decide
def e413500008686 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e413500008686 : Closed e413500008686 ∧ code e413500008686 = 4811546519790 := by decide
theorem cert_e413500008686 : check e413500008686 [] .sourceHead = true := by decide
def e413500008694 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e413500008694 : Closed e413500008694 ∧ code e413500008694 = 4811546519798 := by decide
theorem cert_e413500008694 : check e413500008694 [] .sourceHead = true := by decide
def e413500009246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e413500009246 : Closed e413500009246 ∧ code e413500009246 = 4811546520350 := by decide
theorem cert_e413500009246 : check e413500009246 [] .sourceHead = true := by decide
def e413500009358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e413500009358 : Closed e413500009358 ∧ code e413500009358 = 4811546520462 := by decide
theorem cert_e413500009358 : check e413500009358 [] .sourceHead = true := by decide
def e413500009582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e413500009582 : Closed e413500009582 ∧ code e413500009582 = 4811546520686 := by decide
theorem cert_e413500009582 : check e413500009582 [] .sourceHead = true := by decide
def e413500009594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e413500009594 : Closed e413500009594 ∧ code e413500009594 = 4811546520698 := by decide
theorem cert_e413500009594 : check e413500009594 [] .sourceHead = true := by decide
def e413500009758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e413500009758 : Closed e413500009758 ∧ code e413500009758 = 4811546520862 := by decide
theorem cert_e413500009758 : check e413500009758 [] .sourceHead = true := by decide
def e413500009926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e413500009926 : Closed e413500009926 ∧ code e413500009926 = 4811546521030 := by decide
theorem cert_e413500009926 : check e413500009926 [] .sourceHead = true := by decide
def e413500010038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e413500010038 : Closed e413500010038 ∧ code e413500010038 = 4811546521142 := by decide
theorem cert_e413500010038 : check e413500010038 [] .sourceHead = true := by decide
def e413500010042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e413500010042 : Closed e413500010042 ∧ code e413500010042 = 4811546521146 := by decide
theorem cert_e413500010042 : check e413500010042 [] .sourceHead = true := by decide
def e413500010126 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e413500010126 : Closed e413500010126 ∧ code e413500010126 = 4811546521230 := by decide
theorem cert_e413500010126 : check e413500010126 [] .sourceHead = true := by decide
def e413500010182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e413500010182 : Closed e413500010182 ∧ code e413500010182 = 4811546521286 := by decide
theorem cert_e413500010182 : check e413500010182 [] .sourceHead = true := by decide
def e413500010926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e413500010926 : Closed e413500010926 ∧ code e413500010926 = 4811546522030 := by decide
theorem cert_e413500010926 : check e413500010926 [] .sourceHead = true := by decide
def e413500010938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e413500010938 : Closed e413500010938 ∧ code e413500010938 = 4811546522042 := by decide
theorem cert_e413500010938 : check e413500010938 [] .sourceHead = true := by decide
def e413500010986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e413500010986 : Closed e413500010986 ∧ code e413500010986 = 4811546522090 := by decide
theorem cert_e413500010986 : check e413500010986 [] .sourceHead = true := by decide
def e413500011630 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e413500011630 : Closed e413500011630 ∧ code e413500011630 = 4811546522734 := by decide
theorem cert_e413500011630 : check e413500011630 [] .sourceHead = true := by decide
def e413500011642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e413500011642 : Closed e413500011642 ∧ code e413500011642 = 4811546522746 := by decide
theorem cert_e413500011642 : check e413500011642 [] .sourceHead = true := by decide
def e413500011806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e413500011806 : Closed e413500011806 ∧ code e413500011806 = 4811546522910 := by decide
theorem cert_e413500011806 : check e413500011806 [] .sourceHead = true := by decide
def e413500011974 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e413500011974 : Closed e413500011974 ∧ code e413500011974 = 4811546523078 := by decide
theorem cert_e413500011974 : check e413500011974 [] .sourceHead = true := by decide
def e413500012314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e413500012314 : Closed e413500012314 ∧ code e413500012314 = 4811546523418 := by decide
theorem cert_e413500012314 : check e413500012314 [] .sourceHead = true := by decide
def e413500012358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e413500012358 : Closed e413500012358 ∧ code e413500012358 = 4811546523462 := by decide
theorem cert_e413500012358 : check e413500012358 [] .sourceHead = true := by decide
def e413500012758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e413500012758 : Closed e413500012758 ∧ code e413500012758 = 4811546523862 := by decide
theorem cert_e413500012758 : check e413500012758 [] .sourceHead = true := by decide
def e413500012762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e413500012762 : Closed e413500012762 ∧ code e413500012762 = 4811546523866 := by decide
theorem cert_e413500012762 : check e413500012762 [] .sourceHead = true := by decide
def e413500012778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e413500012778 : Closed e413500012778 ∧ code e413500012778 = 4811546523882 := by decide
theorem cert_e413500012778 : check e413500012778 [] .sourceHead = true := by decide
def e413500013110 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e413500013110 : Closed e413500013110 ∧ code e413500013110 = 4811546524214 := by decide
theorem cert_e413500013110 : check e413500013110 [] .sourceHead = true := by decide
def e413500013114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e413500013114 : Closed e413500013114 ∧ code e413500013114 = 4811546524218 := by decide
theorem cert_e413500013114 : check e413500013114 [] .sourceHead = true := by decide
def e413500013198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e413500013198 : Closed e413500013198 ∧ code e413500013198 = 4811546524302 := by decide
theorem cert_e413500013198 : check e413500013198 [] .sourceHead = true := by decide
def e413500013254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e413500013254 : Closed e413500013254 ∧ code e413500013254 = 4811546524358 := by decide
theorem cert_e413500013254 : check e413500013254 [] .sourceHead = true := by decide
def e413500013338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e413500013338 : Closed e413500013338 ∧ code e413500013338 = 4811546524442 := by decide
theorem cert_e413500013338 : check e413500013338 [] .sourceHead = true := by decide
def e413500013382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e413500013382 : Closed e413500013382 ∧ code e413500013382 = 4811546524486 := by decide
theorem cert_e413500013382 : check e413500013382 [] .sourceHead = true := by decide
def e413500017902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e413500017902 : Closed e413500017902 ∧ code e413500017902 = 4811546529006 := by decide
theorem cert_e413500017902 : check e413500017902 [] .sourceHead = true := by decide
def e413500017910 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e413500017910 : Closed e413500017910 ∧ code e413500017910 = 4811546529014 := by decide
theorem cert_e413500017910 : check e413500017910 [] .sourceHead = true := by decide
def e413500018286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e413500018286 : Closed e413500018286 ∧ code e413500018286 = 4811546529390 := by decide
theorem cert_e413500018286 : check e413500018286 [] .sourceHead = true := by decide
def e413500018298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e413500018298 : Closed e413500018298 ∧ code e413500018298 = 4811546529402 := by decide
theorem cert_e413500018298 : check e413500018298 [] .sourceHead = true := by decide
def e413500018486 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e413500018486 : Closed e413500018486 ∧ code e413500018486 = 4811546529590 := by decide
theorem cert_e413500018486 : check e413500018486 [] .sourceHead = true := by decide
def e413500018490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e413500018490 : Closed e413500018490 ∧ code e413500018490 = 4811546529594 := by decide
theorem cert_e413500018490 : check e413500018490 [] .sourceHead = true := by decide
end Blc.Floor42
