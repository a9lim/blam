import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1203024703714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203024703714 : Closed e1203024703714 ∧ code e1203024703714 = 5601071214818 := by decide
theorem cert_e1203024703714 : check e1203024703714 [[]] .width = true := by decide
def e1203024704262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203024704262 : Closed e1203024704262 ∧ code e1203024704262 = 5601071215366 := by decide
theorem cert_e1203024704262 : check e1203024704262 [[]] .width = true := by decide
def e1203025014982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203025014982 : Closed e1203025014982 ∧ code e1203025014982 = 5601071526086 := by decide
theorem cert_e1203025014982 : check e1203025014982 [[]] .width = true := by decide
def e1203025066010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203025066010 : Closed e1203025066010 ∧ code e1203025066010 = 5601071577114 := by decide
theorem cert_e1203025066010 : check e1203025066010 [[]] .width = true := by decide
def e1203025078298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203025078298 : Closed e1203025078298 ∧ code e1203025078298 = 5601071589402 := by decide
theorem cert_e1203025078298 : check e1203025078298 [[]] .width = true := by decide
def e1203025182746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203025182746 : Closed e1203025182746 ∧ code e1203025182746 = 5601071693850 := by decide
theorem cert_e1203025182746 : check e1203025182746 [[]] .width = true := by decide
def e1203025182838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203025182838 : Closed e1203025182838 ∧ code e1203025182838 = 5601071693942 := by decide
theorem cert_e1203025182838 : check e1203025182838 [[]] .width = true := by decide
def e1203025183082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203025183082 : Closed e1203025183082 ∧ code e1203025183082 = 5601071694186 := by decide
theorem cert_e1203025183082 : check e1203025183082 [[]] .width = true := by decide
def e1203025183130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203025183130 : Closed e1203025183130 ∧ code e1203025183130 = 5601071694234 := by decide
theorem cert_e1203025183130 : check e1203025183130 [[]] .width = true := by decide
def e1203025184138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203025184138 : Closed e1203025184138 ∧ code e1203025184138 = 5601071695242 := by decide
theorem cert_e1203025184138 : check e1203025184138 [[]] .width = true := by decide
def e1203025184162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203025184162 : Closed e1203025184162 ∧ code e1203025184162 = 5601071695266 := by decide
theorem cert_e1203025184162 : check e1203025184162 [[]] .width = true := by decide
def e1203025184270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203025184270 : Closed e1203025184270 ∧ code e1203025184270 = 5601071695374 := by decide
theorem cert_e1203025184270 : check e1203025184270 [[]] .width = true := by decide
def e1203025184282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203025184282 : Closed e1203025184282 ∧ code e1203025184282 = 5601071695386 := by decide
theorem cert_e1203025184282 : check e1203025184282 [[]] .width = true := by decide
def e1203025184354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203025184354 : Closed e1203025184354 ∧ code e1203025184354 = 5601071695458 := by decide
theorem cert_e1203025184354 : check e1203025184354 [[]] .width = true := by decide
def e1203025360922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203025360922 : Closed e1203025360922 ∧ code e1203025360922 = 5601071872026 := by decide
theorem cert_e1203025360922 : check e1203025360922 [[]] .width = true := by decide
def e1203025395910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203025395910 : Closed e1203025395910 ∧ code e1203025395910 = 5601071907014 := by decide
theorem cert_e1203025395910 : check e1203025395910 [[]] .width = true := by decide
def e1203025416390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203025416390 : Closed e1203025416390 ∧ code e1203025416390 = 5601071927494 := by decide
theorem cert_e1203025416390 : check e1203025416390 [[]] .width = true := by decide
def e1203025418266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203025418266 : Closed e1203025418266 ∧ code e1203025418266 = 5601071929370 := by decide
theorem cert_e1203025418266 : check e1203025418266 [[]] .width = true := by decide
def e1203025419802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203025419802 : Closed e1203025419802 ∧ code e1203025419802 = 5601071930906 := by decide
theorem cert_e1203025419802 : check e1203025419802 [[]] .width = true := by decide
def e1203025428678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203025428678 : Closed e1203025428678 ∧ code e1203025428678 = 5601071939782 := by decide
theorem cert_e1203025428678 : check e1203025428678 [[]] .width = true := by decide
def e1203025436698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203025436698 : Closed e1203025436698 ∧ code e1203025436698 = 5601071947802 := by decide
theorem cert_e1203025436698 : check e1203025436698 [[]] .width = true := by decide
def e1203025436790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203025436790 : Closed e1203025436790 ∧ code e1203025436790 = 5601071947894 := by decide
theorem cert_e1203025436790 : check e1203025436790 [[]] .width = true := by decide
def e1203025437034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203025437034 : Closed e1203025437034 ∧ code e1203025437034 = 5601071948138 := by decide
theorem cert_e1203025437034 : check e1203025437034 [[]] .width = true := by decide
def e1203025437082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203025437082 : Closed e1203025437082 ∧ code e1203025437082 = 5601071948186 := by decide
theorem cert_e1203025437082 : check e1203025437082 [[]] .width = true := by decide
def e1203025440966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203025440966 : Closed e1203025440966 ∧ code e1203025440966 = 5601071952070 := by decide
theorem cert_e1203025440966 : check e1203025440966 [[]] .width = true := by decide
def e1203025448474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203025448474 : Closed e1203025448474 ∧ code e1203025448474 = 5601071959578 := by decide
theorem cert_e1203025448474 : check e1203025448474 [[]] .width = true := by decide
def e1203025457350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203025457350 : Closed e1203025457350 ∧ code e1203025457350 = 5601071968454 := by decide
theorem cert_e1203025457350 : check e1203025457350 [[]] .width = true := by decide
def e1203025739974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203025739974 : Closed e1203025739974 ∧ code e1203025739974 = 5601072251078 := by decide
theorem cert_e1203025739974 : check e1203025739974 [[]] .width = true := by decide
def e1203025740502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203025740502 : Closed e1203025740502 ∧ code e1203025740502 = 5601072251606 := by decide
theorem cert_e1203025740502 : check e1203025740502 [[]] .width = true := by decide
def e1203025740506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203025740506 : Closed e1203025740506 ∧ code e1203025740506 = 5601072251610 := by decide
theorem cert_e1203025740506 : check e1203025740506 [[]] .width = true := by decide
def e1203025740522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203025740522 : Closed e1203025740522 ∧ code e1203025740522 = 5601072251626 := by decide
theorem cert_e1203025740522 : check e1203025740522 [[]] .width = true := by decide
def e1203025740598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203025740598 : Closed e1203025740598 ∧ code e1203025740598 = 5601072251702 := by decide
theorem cert_e1203025740598 : check e1203025740598 [[]] .width = true := by decide
def e1203025740602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203025740602 : Closed e1203025740602 ∧ code e1203025740602 = 5601072251706 := by decide
theorem cert_e1203025740602 : check e1203025740602 [[]] .width = true := by decide
def e1203025740686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203025740686 : Closed e1203025740686 ∧ code e1203025740686 = 5601072251790 := by decide
theorem cert_e1203025740686 : check e1203025740686 [[]] .width = true := by decide
def e1203025740698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203025740698 : Closed e1203025740698 ∧ code e1203025740698 = 5601072251802 := by decide
theorem cert_e1203025740698 : check e1203025740698 [[]] .width = true := by decide
def e1203025742618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203025742618 : Closed e1203025742618 ∧ code e1203025742618 = 5601072253722 := by decide
theorem cert_e1203025742618 : check e1203025742618 [[]] .width = true := by decide
def e1203025742662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203025742662 : Closed e1203025742662 ∧ code e1203025742662 = 5601072253766 := by decide
theorem cert_e1203025742662 : check e1203025742662 [[]] .width = true := by decide
def e1203025742774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203025742774 : Closed e1203025742774 ∧ code e1203025742774 = 5601072253878 := by decide
theorem cert_e1203025742774 : check e1203025742774 [[]] .width = true := by decide
def e1203025742902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203025742902 : Closed e1203025742902 ∧ code e1203025742902 = 5601072254006 := by decide
theorem cert_e1203025742902 : check e1203025742902 [[]] .width = true := by decide
def e1203025742906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203025742906 : Closed e1203025742906 ∧ code e1203025742906 = 5601072254010 := by decide
theorem cert_e1203025742906 : check e1203025742906 [[]] .width = true := by decide
def e1203025743046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203025743046 : Closed e1203025743046 ∧ code e1203025743046 = 5601072254150 := by decide
theorem cert_e1203025743046 : check e1203025743046 [[]] .width = true := by decide
def e1203025743386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203025743386 : Closed e1203025743386 ∧ code e1203025743386 = 5601072254490 := by decide
theorem cert_e1203025743386 : check e1203025743386 [[]] .width = true := by decide
def e1203025743478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203025743478 : Closed e1203025743478 ∧ code e1203025743478 = 5601072254582 := by decide
theorem cert_e1203025743478 : check e1203025743478 [[]] .width = true := by decide
def e1203025751066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203025751066 : Closed e1203025751066 ∧ code e1203025751066 = 5601072262170 := by decide
theorem cert_e1203025751066 : check e1203025751066 [[]] .width = true := by decide
def e1203025751110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203025751110 : Closed e1203025751110 ∧ code e1203025751110 = 5601072262214 := by decide
theorem cert_e1203025751110 : check e1203025751110 [[]] .width = true := by decide
def e1203025751138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203025751138 : Closed e1203025751138 ∧ code e1203025751138 = 5601072262242 := by decide
theorem cert_e1203025751138 : check e1203025751138 [[]] .width = true := by decide
def e1203025751302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203025751302 : Closed e1203025751302 ∧ code e1203025751302 = 5601072262406 := by decide
theorem cert_e1203025751302 : check e1203025751302 [[]] .width = true := by decide
def e1203025752094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203025752094 : Closed e1203025752094 ∧ code e1203025752094 = 5601072263198 := by decide
theorem cert_e1203025752094 : check e1203025752094 [[]] .width = true := by decide
def e1203025752262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203025752262 : Closed e1203025752262 ∧ code e1203025752262 = 5601072263366 := by decide
theorem cert_e1203025752262 : check e1203025752262 [[]] .width = true := by decide
def e1203025752290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203025752290 : Closed e1203025752290 ∧ code e1203025752290 = 5601072263394 := by decide
theorem cert_e1203025752290 : check e1203025752290 [[]] .width = true := by decide
def e1203025752838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203025752838 : Closed e1203025752838 ∧ code e1203025752838 = 5601072263942 := by decide
theorem cert_e1203025752838 : check e1203025752838 [[]] .width = true := by decide
def e1203064520902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203064520902 : Closed e1203064520902 ∧ code e1203064520902 = 5601111032006 := by decide
theorem cert_e1203064520902 : check e1203064520902 [[]] .width = true := by decide
def e1203064717510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203064717510 : Closed e1203064717510 ∧ code e1203064717510 = 5601111228614 := by decide
theorem cert_e1203064717510 : check e1203064717510 [[]] .width = true := by decide
def e1203072233670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203072233670 : Closed e1203072233670 ∧ code e1203072233670 = 5601118744774 := by decide
theorem cert_e1203072233670 : check e1203072233670 [[]] .width = true := by decide
def e1203072251930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203072251930 : Closed e1203072251930 ∧ code e1203072251930 = 5601118763034 := by decide
theorem cert_e1203072251930 : check e1203072251930 [[]] .width = true := by decide
def e1203072265754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203072265754 : Closed e1203072265754 ∧ code e1203072265754 = 5601118776858 := by decide
theorem cert_e1203072265754 : check e1203072265754 [[]] .width = true := by decide
def e1203072516294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203072516294 : Closed e1203072516294 ∧ code e1203072516294 = 5601119027398 := by decide
theorem cert_e1203072516294 : check e1203072516294 [[]] .width = true := by decide
def e1203072589850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203072589850 : Closed e1203072589850 ∧ code e1203072589850 = 5601119100954 := by decide
theorem cert_e1203072589850 : check e1203072589850 [[]] .width = true := by decide
def e1203072589942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203072589942 : Closed e1203072589942 ∧ code e1203072589942 = 5601119101046 := by decide
theorem cert_e1203072589942 : check e1203072589942 [[]] .width = true := by decide
def e1203072590186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203072590186 : Closed e1203072590186 ∧ code e1203072590186 = 5601119101290 := by decide
theorem cert_e1203072590186 : check e1203072590186 [[]] .width = true := by decide
def e1203072590234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203072590234 : Closed e1203072590234 ∧ code e1203072590234 = 5601119101338 := by decide
theorem cert_e1203072590234 : check e1203072590234 [[]] .width = true := by decide
def e1203072602310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203072602310 : Closed e1203072602310 ∧ code e1203072602310 = 5601119113414 := by decide
theorem cert_e1203072602310 : check e1203072602310 [[]] .width = true := by decide
def e1203072604186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203072604186 : Closed e1203072604186 ∧ code e1203072604186 = 5601119115290 := by decide
theorem cert_e1203072604186 : check e1203072604186 [[]] .width = true := by decide
def e1203072605722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203072605722 : Closed e1203072605722 ∧ code e1203072605722 = 5601119116826 := by decide
theorem cert_e1203072605722 : check e1203072605722 [[]] .width = true := by decide
def e1203072614598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203072614598 : Closed e1203072614598 ∧ code e1203072614598 = 5601119125702 := by decide
theorem cert_e1203072614598 : check e1203072614598 [[]] .width = true := by decide
def e1203072622618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203072622618 : Closed e1203072622618 ∧ code e1203072622618 = 5601119133722 := by decide
theorem cert_e1203072622618 : check e1203072622618 [[]] .width = true := by decide
def e1203072622710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203072622710 : Closed e1203072622710 ∧ code e1203072622710 = 5601119133814 := by decide
theorem cert_e1203072622710 : check e1203072622710 [[]] .width = true := by decide
def e1203072622954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203072622954 : Closed e1203072622954 ∧ code e1203072622954 = 5601119134058 := by decide
theorem cert_e1203072622954 : check e1203072622954 [[]] .width = true := by decide
def e1203072623002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203072623002 : Closed e1203072623002 ∧ code e1203072623002 = 5601119134106 := by decide
theorem cert_e1203072623002 : check e1203072623002 [[]] .width = true := by decide
def e1203072626886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203072626886 : Closed e1203072626886 ∧ code e1203072626886 = 5601119137990 := by decide
theorem cert_e1203072626886 : check e1203072626886 [[]] .width = true := by decide
def e1203072851994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203072851994 : Closed e1203072851994 ∧ code e1203072851994 = 5601119363098 := by decide
theorem cert_e1203072851994 : check e1203072851994 [[]] .width = true := by decide
def e1203072852086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203072852086 : Closed e1203072852086 ∧ code e1203072852086 = 5601119363190 := by decide
theorem cert_e1203072852086 : check e1203072852086 [[]] .width = true := by decide
def e1203072852330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203072852330 : Closed e1203072852330 ∧ code e1203072852330 = 5601119363434 := by decide
theorem cert_e1203072852330 : check e1203072852330 [[]] .width = true := by decide
def e1203072852378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203072852378 : Closed e1203072852378 ∧ code e1203072852378 = 5601119363482 := by decide
theorem cert_e1203072852378 : check e1203072852378 [[]] .width = true := by decide
def e1203072901146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203072901146 : Closed e1203072901146 ∧ code e1203072901146 = 5601119412250 := by decide
theorem cert_e1203072901146 : check e1203072901146 [[]] .width = true := by decide
def e1203072901238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203072901238 : Closed e1203072901238 ∧ code e1203072901238 = 5601119412342 := by decide
private def t_e1203072901238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1203072901238 : ¬ IsSelfInterpreter e1203072901238 :=
  wSource (t := t_e1203072901238) (replay_sound (ps := []) (t := e1203072901238) (by decide)) (by decide)
def e1203072901482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203072901482 : Closed e1203072901482 ∧ code e1203072901482 = 5601119412586 := by decide
private def t_e1203072901482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1203072901482 : ¬ IsSelfInterpreter e1203072901482 :=
  wSource (t := t_e1203072901482) (replay_sound (ps := []) (t := e1203072901482) (by decide)) (by decide)
def e1203072901530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203072901530 : Closed e1203072901530 ∧ code e1203072901530 = 5601119412634 := by decide
private def t_e1203072901530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1203072901530 : ¬ IsSelfInterpreter e1203072901530 :=
  wSource (t := t_e1203072901530) (replay_sound (ps := []) (t := e1203072901530) (by decide)) (by decide)
def e1203072946374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203072946374 : Closed e1203072946374 ∧ code e1203072946374 = 5601119457478 := by decide
theorem cert_e1203072946374 : check e1203072946374 [[]] .width = true := by decide
def e1203072952346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203072952346 : Closed e1203072952346 ∧ code e1203072952346 = 5601119463450 := by decide
theorem cert_e1203072952346 : check e1203072952346 [[]] .width = true := by decide
def e1203072953882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203072953882 : Closed e1203072953882 ∧ code e1203072953882 = 5601119464986 := by decide
theorem cert_e1203072953882 : check e1203072953882 [[]] .width = true := by decide
def e1203072956954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203072956954 : Closed e1203072956954 ∧ code e1203072956954 = 5601119468058 := by decide
theorem cert_e1203072956954 : check e1203072956954 [[]] .width = true := by decide
def e1203072995526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203072995526 : Closed e1203072995526 ∧ code e1203072995526 = 5601119506630 := by decide
theorem cert_e1203072995526 : check e1203072995526 [[]] .width = true := by decide
def e1203072997402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203072997402 : Closed e1203072997402 ∧ code e1203072997402 = 5601119508506 := by decide
theorem cert_e1203072997402 : check e1203072997402 [[]] .width = true := by decide
def e1203072998938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203072998938 : Closed e1203072998938 ∧ code e1203072998938 = 5601119510042 := by decide
theorem cert_e1203072998938 : check e1203072998938 [[]] .width = true := by decide
def e1203073007814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203073007814 : Closed e1203073007814 ∧ code e1203073007814 = 5601119518918 := by decide
theorem cert_e1203073007814 : check e1203073007814 [[]] .width = true := by decide
def e1203073015834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203073015834 : Closed e1203073015834 ∧ code e1203073015834 = 5601119526938 := by decide
theorem cert_e1203073015834 : check e1203073015834 [[]] .width = true := by decide
def e1203073015926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203073015926 : Closed e1203073015926 ∧ code e1203073015926 = 5601119527030 := by decide
theorem cert_e1203073015926 : check e1203073015926 [[]] .width = true := by decide
def e1203073016170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203073016170 : Closed e1203073016170 ∧ code e1203073016170 = 5601119527274 := by decide
theorem cert_e1203073016170 : check e1203073016170 [[]] .width = true := by decide
def e1203073016218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203073016218 : Closed e1203073016218 ∧ code e1203073016218 = 5601119527322 := by decide
theorem cert_e1203073016218 : check e1203073016218 [[]] .width = true := by decide
def e1203073020102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203073020102 : Closed e1203073020102 ∧ code e1203073020102 = 5601119531206 := by decide
theorem cert_e1203073020102 : check e1203073020102 [[]] .width = true := by decide
def e1203073032218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203073032218 : Closed e1203073032218 ∧ code e1203073032218 = 5601119543322 := by decide
theorem cert_e1203073032218 : check e1203073032218 [[]] .width = true := by decide
def e1203073032310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203073032310 : Closed e1203073032310 ∧ code e1203073032310 = 5601119543414 := by decide
private def t_e1203073032310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1203073032310 : ¬ IsSelfInterpreter e1203073032310 :=
  wSource (t := t_e1203073032310) (replay_sound (ps := []) (t := e1203073032310) (by decide)) (by decide)
def e1203073032554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203073032554 : Closed e1203073032554 ∧ code e1203073032554 = 5601119543658 := by decide
private def t_e1203073032554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1203073032554 : ¬ IsSelfInterpreter e1203073032554 :=
  wSource (t := t_e1203073032554) (replay_sound (ps := []) (t := e1203073032554) (by decide)) (by decide)
def e1203073032602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203073032602 : Closed e1203073032602 ∧ code e1203073032602 = 5601119543706 := by decide
private def t_e1203073032602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1203073032602 : ¬ IsSelfInterpreter e1203073032602 :=
  wSource (t := t_e1203073032602) (replay_sound (ps := []) (t := e1203073032602) (by decide)) (by decide)
def e1203073041946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203073041946 : Closed e1203073041946 ∧ code e1203073041946 = 5601119553050 := by decide
private def t_e1203073041946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1203073041946 : ¬ IsSelfInterpreter e1203073041946 :=
  wSource (t := t_e1203073041946) (replay_sound (ps := []) (t := e1203073041946) (by decide)) (by decide)
def e1203073044678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203073044678 : Closed e1203073044678 ∧ code e1203073044678 = 5601119555782 := by decide
theorem cert_e1203073044678 : check e1203073044678 [[]] .width = true := by decide
def e1203073679386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203073679386 : Closed e1203073679386 ∧ code e1203073679386 = 5601120190490 := by decide
theorem cert_e1203073679386 : check e1203073679386 [[]] .width = true := by decide
def e1203073679478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203073679478 : Closed e1203073679478 ∧ code e1203073679478 = 5601120190582 := by decide
theorem cert_e1203073679478 : check e1203073679478 [[]] .width = true := by decide
def e1203073679722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203073679722 : Closed e1203073679722 ∧ code e1203073679722 = 5601120190826 := by decide
theorem cert_e1203073679722 : check e1203073679722 [[]] .width = true := by decide
def e1203073679770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203073679770 : Closed e1203073679770 ∧ code e1203073679770 = 5601120190874 := by decide
theorem cert_e1203073679770 : check e1203073679770 [[]] .width = true := by decide
def e1203073680778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203073680778 : Closed e1203073680778 ∧ code e1203073680778 = 5601120191882 := by decide
theorem cert_e1203073680778 : check e1203073680778 [[]] .width = true := by decide
def e1203073680802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203073680802 : Closed e1203073680802 ∧ code e1203073680802 = 5601120191906 := by decide
theorem cert_e1203073680802 : check e1203073680802 [[]] .width = true := by decide
def e1203073680910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203073680910 : Closed e1203073680910 ∧ code e1203073680910 = 5601120192014 := by decide
theorem cert_e1203073680910 : check e1203073680910 [[]] .width = true := by decide
def e1203073680922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203073680922 : Closed e1203073680922 ∧ code e1203073680922 = 5601120192026 := by decide
theorem cert_e1203073680922 : check e1203073680922 [[]] .width = true := by decide
def e1203073680994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203073680994 : Closed e1203073680994 ∧ code e1203073680994 = 5601120192098 := by decide
theorem cert_e1203073680994 : check e1203073680994 [[]] .width = true := by decide
def e1203074089158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203074089158 : Closed e1203074089158 ∧ code e1203074089158 = 5601120600262 := by decide
theorem cert_e1203074089158 : check e1203074089158 [[]] .width = true := by decide
def e1203074162714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203074162714 : Closed e1203074162714 ∧ code e1203074162714 = 5601120673818 := by decide
theorem cert_e1203074162714 : check e1203074162714 [[]] .width = true := by decide
def e1203074162806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203074162806 : Closed e1203074162806 ∧ code e1203074162806 = 5601120673910 := by decide
theorem cert_e1203074162806 : check e1203074162806 [[]] .width = true := by decide
def e1203074163050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203074163050 : Closed e1203074163050 ∧ code e1203074163050 = 5601120674154 := by decide
theorem cert_e1203074163050 : check e1203074163050 [[]] .width = true := by decide
def e1203074163098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203074163098 : Closed e1203074163098 ∧ code e1203074163098 = 5601120674202 := by decide
theorem cert_e1203074163098 : check e1203074163098 [[]] .width = true := by decide
def e1203074175174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203074175174 : Closed e1203074175174 ∧ code e1203074175174 = 5601120686278 := by decide
theorem cert_e1203074175174 : check e1203074175174 [[]] .width = true := by decide
def e1203074177050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203074177050 : Closed e1203074177050 ∧ code e1203074177050 = 5601120688154 := by decide
theorem cert_e1203074177050 : check e1203074177050 [[]] .width = true := by decide
def e1203074178586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203074178586 : Closed e1203074178586 ∧ code e1203074178586 = 5601120689690 := by decide
theorem cert_e1203074178586 : check e1203074178586 [[]] .width = true := by decide
def e1203074187462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203074187462 : Closed e1203074187462 ∧ code e1203074187462 = 5601120698566 := by decide
theorem cert_e1203074187462 : check e1203074187462 [[]] .width = true := by decide
def e1203074195482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203074195482 : Closed e1203074195482 ∧ code e1203074195482 = 5601120706586 := by decide
theorem cert_e1203074195482 : check e1203074195482 [[]] .width = true := by decide
def e1203074195574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203074195574 : Closed e1203074195574 ∧ code e1203074195574 = 5601120706678 := by decide
theorem cert_e1203074195574 : check e1203074195574 [[]] .width = true := by decide
def e1203074195818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203074195818 : Closed e1203074195818 ∧ code e1203074195818 = 5601120706922 := by decide
theorem cert_e1203074195818 : check e1203074195818 [[]] .width = true := by decide
def e1203074195866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203074195866 : Closed e1203074195866 ∧ code e1203074195866 = 5601120706970 := by decide
theorem cert_e1203074195866 : check e1203074195866 [[]] .width = true := by decide
def e1203074199750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203074199750 : Closed e1203074199750 ∧ code e1203074199750 = 5601120710854 := by decide
theorem cert_e1203074199750 : check e1203074199750 [[]] .width = true := by decide
def e1203075023046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203075023046 : Closed e1203075023046 ∧ code e1203075023046 = 5601121534150 := by decide
theorem cert_e1203075023046 : check e1203075023046 [[]] .width = true := by decide
def e1203075023574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203075023574 : Closed e1203075023574 ∧ code e1203075023574 = 5601121534678 := by decide
theorem cert_e1203075023574 : check e1203075023574 [[]] .width = true := by decide
def e1203075023578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203075023578 : Closed e1203075023578 ∧ code e1203075023578 = 5601121534682 := by decide
theorem cert_e1203075023578 : check e1203075023578 [[]] .width = true := by decide
def e1203075023594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203075023594 : Closed e1203075023594 ∧ code e1203075023594 = 5601121534698 := by decide
theorem cert_e1203075023594 : check e1203075023594 [[]] .width = true := by decide
def e1203075023670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203075023670 : Closed e1203075023670 ∧ code e1203075023670 = 5601121534774 := by decide
theorem cert_e1203075023670 : check e1203075023670 [[]] .width = true := by decide
def e1203075023674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203075023674 : Closed e1203075023674 ∧ code e1203075023674 = 5601121534778 := by decide
theorem cert_e1203075023674 : check e1203075023674 [[]] .width = true := by decide
def e1203075023758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203075023758 : Closed e1203075023758 ∧ code e1203075023758 = 5601121534862 := by decide
theorem cert_e1203075023758 : check e1203075023758 [[]] .width = true := by decide
def e1203075023770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203075023770 : Closed e1203075023770 ∧ code e1203075023770 = 5601121534874 := by decide
theorem cert_e1203075023770 : check e1203075023770 [[]] .width = true := by decide
def e1203075025690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203075025690 : Closed e1203075025690 ∧ code e1203075025690 = 5601121536794 := by decide
theorem cert_e1203075025690 : check e1203075025690 [[]] .width = true := by decide
def e1203075025734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203075025734 : Closed e1203075025734 ∧ code e1203075025734 = 5601121536838 := by decide
theorem cert_e1203075025734 : check e1203075025734 [[]] .width = true := by decide
def e1203075025846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203075025846 : Closed e1203075025846 ∧ code e1203075025846 = 5601121536950 := by decide
theorem cert_e1203075025846 : check e1203075025846 [[]] .width = true := by decide
def e1203075025974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203075025974 : Closed e1203075025974 ∧ code e1203075025974 = 5601121537078 := by decide
theorem cert_e1203075025974 : check e1203075025974 [[]] .width = true := by decide
def e1203075025978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203075025978 : Closed e1203075025978 ∧ code e1203075025978 = 5601121537082 := by decide
theorem cert_e1203075025978 : check e1203075025978 [[]] .width = true := by decide
def e1203075026118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203075026118 : Closed e1203075026118 ∧ code e1203075026118 = 5601121537222 := by decide
theorem cert_e1203075026118 : check e1203075026118 [[]] .width = true := by decide
def e1203075026458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203075026458 : Closed e1203075026458 ∧ code e1203075026458 = 5601121537562 := by decide
theorem cert_e1203075026458 : check e1203075026458 [[]] .width = true := by decide
def e1203075026550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203075026550 : Closed e1203075026550 ∧ code e1203075026550 = 5601121537654 := by decide
theorem cert_e1203075026550 : check e1203075026550 [[]] .width = true := by decide
def e1203075034138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203075034138 : Closed e1203075034138 ∧ code e1203075034138 = 5601121545242 := by decide
theorem cert_e1203075034138 : check e1203075034138 [[]] .width = true := by decide
def e1203075034182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203075034182 : Closed e1203075034182 ∧ code e1203075034182 = 5601121545286 := by decide
theorem cert_e1203075034182 : check e1203075034182 [[]] .width = true := by decide
def e1203075034210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203075034210 : Closed e1203075034210 ∧ code e1203075034210 = 5601121545314 := by decide
theorem cert_e1203075034210 : check e1203075034210 [[]] .width = true := by decide
def e1203075034374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203075034374 : Closed e1203075034374 ∧ code e1203075034374 = 5601121545478 := by decide
theorem cert_e1203075034374 : check e1203075034374 [[]] .width = true := by decide
def e1203075035166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203075035166 : Closed e1203075035166 ∧ code e1203075035166 = 5601121546270 := by decide
theorem cert_e1203075035166 : check e1203075035166 [[]] .width = true := by decide
def e1203075035334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203075035334 : Closed e1203075035334 ∧ code e1203075035334 = 5601121546438 := by decide
theorem cert_e1203075035334 : check e1203075035334 [[]] .width = true := by decide
def e1203075035362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203075035362 : Closed e1203075035362 ∧ code e1203075035362 = 5601121546466 := by decide
theorem cert_e1203075035362 : check e1203075035362 [[]] .width = true := by decide
def e1203075035910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203075035910 : Closed e1203075035910 ∧ code e1203075035910 = 5601121547014 := by decide
theorem cert_e1203075035910 : check e1203075035910 [[]] .width = true := by decide
def e1203075735578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203075735578 : Closed e1203075735578 ∧ code e1203075735578 = 5601122246682 := by decide
theorem cert_e1203075735578 : check e1203075735578 [[]] .width = true := by decide
def e1203075735670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203075735670 : Closed e1203075735670 ∧ code e1203075735670 = 5601122246774 := by decide
theorem cert_e1203075735670 : check e1203075735670 [[]] .width = true := by decide
def e1203075735914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203075735914 : Closed e1203075735914 ∧ code e1203075735914 = 5601122247018 := by decide
theorem cert_e1203075735914 : check e1203075735914 [[]] .width = true := by decide
def e1203075735962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203075735962 : Closed e1203075735962 ∧ code e1203075735962 = 5601122247066 := by decide
theorem cert_e1203075735962 : check e1203075735962 [[]] .width = true := by decide
def e1203075784730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203075784730 : Closed e1203075784730 ∧ code e1203075784730 = 5601122295834 := by decide
theorem cert_e1203075784730 : check e1203075784730 [[]] .width = true := by decide
def e1203075784822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203075784822 : Closed e1203075784822 ∧ code e1203075784822 = 5601122295926 := by decide
theorem cert_e1203075784822 : check e1203075784822 [[]] .width = true := by decide
def e1203075785066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203075785066 : Closed e1203075785066 ∧ code e1203075785066 = 5601122296170 := by decide
theorem cert_e1203075785066 : check e1203075785066 [[]] .width = true := by decide
def e1203075785114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203075785114 : Closed e1203075785114 ∧ code e1203075785114 = 5601122296218 := by decide
theorem cert_e1203075785114 : check e1203075785114 [[]] .width = true := by decide
def e1203076362438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203076362438 : Closed e1203076362438 ∧ code e1203076362438 = 5601122873542 := by decide
theorem cert_e1203076362438 : check e1203076362438 [[]] .width = true := by decide
def e1203076388890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203076388890 : Closed e1203076388890 ∧ code e1203076388890 = 5601122899994 := by decide
theorem cert_e1203076388890 : check e1203076388890 [[]] .width = true := by decide
def e1203076392986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203076392986 : Closed e1203076392986 ∧ code e1203076392986 = 5601122904090 := by decide
theorem cert_e1203076392986 : check e1203076392986 [[]] .width = true := by decide
def e1203076431898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203076431898 : Closed e1203076431898 ∧ code e1203076431898 = 5601122943002 := by decide
theorem cert_e1203076431898 : check e1203076431898 [[]] .width = true := by decide
def e1203076431990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203076431990 : Closed e1203076431990 ∧ code e1203076431990 = 5601122943094 := by decide
theorem cert_e1203076431990 : check e1203076431990 [[]] .width = true := by decide
def e1203076432234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203076432234 : Closed e1203076432234 ∧ code e1203076432234 = 5601122943338 := by decide
theorem cert_e1203076432234 : check e1203076432234 [[]] .width = true := by decide
def e1203076432282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203076432282 : Closed e1203076432282 ∧ code e1203076432282 = 5601122943386 := by decide
theorem cert_e1203076432282 : check e1203076432282 [[]] .width = true := by decide
def e1203076433290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203076433290 : Closed e1203076433290 ∧ code e1203076433290 = 5601122944394 := by decide
theorem cert_e1203076433290 : check e1203076433290 [[]] .width = true := by decide
end Blc.Floor42
