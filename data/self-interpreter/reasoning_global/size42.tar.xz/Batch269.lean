import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1402313587974 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313587974 : Closed e1402313587974 ∧ code e1402313587974 = 5800360099078 := by decide
theorem cert_e1402313587974 : check e1402313587974 [[.left],[.left]] .chain = true := by decide
def e1402313588098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313588098 : Closed e1402313588098 ∧ code e1402313588098 = 5800360099202 := by decide
theorem cert_e1402313588098 : check e1402313588098 [[.left],[.left]] .chain = true := by decide
def e1402313601222 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402313601222 : Closed e1402313601222 ∧ code e1402313601222 = 5800360112326 := by decide
theorem cert_e1402313601222 : check e1402313601222 [[.left]] .chain = true := by decide
def e1402313608730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402313608730 : Closed e1402313608730 ∧ code e1402313608730 = 5800360119834 := by decide
theorem cert_e1402313608730 : check e1402313608730 [[.left]] .chain = true := by decide
def e1402313611490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402313611490 : Closed e1402313611490 ∧ code e1402313611490 = 5800360122594 := by decide
theorem cert_e1402313611490 : check e1402313611490 [[.left],[.left]] .chain = true := by decide
def e1402313612038 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313612038 : Closed e1402313612038 ∧ code e1402313612038 = 5800360123142 := by decide
theorem cert_e1402313612038 : check e1402313612038 [[.left],[.left]] .chain = true := by decide
def e1402313612386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402313612386 : Closed e1402313612386 ∧ code e1402313612386 = 5800360123490 := by decide
theorem cert_e1402313612386 : check e1402313612386 [[.left],[.left]] .chain = true := by decide
def e1402313612550 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313612550 : Closed e1402313612550 ∧ code e1402313612550 = 5800360123654 := by decide
theorem cert_e1402313612550 : check e1402313612550 [[.left],[.left]] .chain = true := by decide
def e1402313612674 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313612674 : Closed e1402313612674 ∧ code e1402313612674 = 5800360123778 := by decide
theorem cert_e1402313612674 : check e1402313612674 [[.left],[.left]] .chain = true := by decide
def e1402313617606 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402313617606 : Closed e1402313617606 ∧ code e1402313617606 = 5800360128710 := by decide
theorem cert_e1402313617606 : check e1402313617606 [[.left]] .chain = true := by decide
def e1402314208994 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402314208994 : Closed e1402314208994 ∧ code e1402314208994 = 5800360720098 := by decide
theorem cert_e1402314208994 : check e1402314208994 [[.left],[.left]] .smaller = true := by decide
def e1402314209122 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314209122 : Closed e1402314209122 ∧ code e1402314209122 = 5800360720226 := by decide
theorem cert_e1402314209122 : check e1402314209122 [[.left],[.left]] .smaller = true := by decide
def e1402314210018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402314210018 : Closed e1402314210018 ∧ code e1402314210018 = 5800360721122 := by decide
theorem cert_e1402314210018 : check e1402314210018 [[.left],[.left]] .smaller = true := by decide
def e1402314210210 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402314210210 : Closed e1402314210210 ∧ code e1402314210210 = 5800360721314 := by decide
theorem cert_e1402314210210 : check e1402314210210 [[.left],[.left]] .smaller = true := by decide
def e1402314210658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314210658 : Closed e1402314210658 ∧ code e1402314210658 = 5800360721762 := by decide
theorem cert_e1402314210658 : check e1402314210658 [[.left],[.left]] .smaller = true := by decide
def e1402314210722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402314210722 : Closed e1402314210722 ∧ code e1402314210722 = 5800360721826 := by decide
theorem cert_e1402314210722 : check e1402314210722 [[.left],[.left]] .smaller = true := by decide
def e1402314215138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402314215138 : Closed e1402314215138 ∧ code e1402314215138 = 5800360726242 := by decide
theorem cert_e1402314215138 : check e1402314215138 [[.left],[.left]] .smaller = true := by decide
def e1402314215266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314215266 : Closed e1402314215266 ∧ code e1402314215266 = 5800360726370 := by decide
theorem cert_e1402314215266 : check e1402314215266 [[.left],[.left]] .smaller = true := by decide
def e1402314221282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402314221282 : Closed e1402314221282 ∧ code e1402314221282 = 5800360732386 := by decide
theorem cert_e1402314221282 : check e1402314221282 [[.left],[.left]] .smaller = true := by decide
def e1402314221474 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402314221474 : Closed e1402314221474 ∧ code e1402314221474 = 5800360732578 := by decide
theorem cert_e1402314221474 : check e1402314221474 [[.left],[.left]] .smaller = true := by decide
def e1402314224482 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314224482 : Closed e1402314224482 ∧ code e1402314224482 = 5800360735586 := by decide
theorem cert_e1402314224482 : check e1402314224482 [[.left],[.left]] .smaller = true := by decide
def e1402314224546 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402314224546 : Closed e1402314224546 ∧ code e1402314224546 = 5800360735650 := by decide
theorem cert_e1402314224546 : check e1402314224546 [[.left],[.left]] .smaller = true := by decide
def e1402314344162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402314344162 : Closed e1402314344162 ∧ code e1402314344162 = 5800360855266 := by decide
theorem cert_e1402314344162 : check e1402314344162 [[.left],[.left]] .chain = true := by decide
def e1402314344354 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402314344354 : Closed e1402314344354 ∧ code e1402314344354 = 5800360855458 := by decide
theorem cert_e1402314344354 : check e1402314344354 [[.left],[.left]] .chain = true := by decide
def e1402314346978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402314346978 : Closed e1402314346978 ∧ code e1402314346978 = 5800360858082 := by decide
theorem cert_e1402314346978 : check e1402314346978 [[.left],[.left]] .chain = true := by decide
def e1402314348294 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314348294 : Closed e1402314348294 ∧ code e1402314348294 = 5800360859398 := by decide
theorem cert_e1402314348294 : check e1402314348294 [[.left],[.left]] .chain = true := by decide
def e1402314349442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314349442 : Closed e1402314349442 ∧ code e1402314349442 = 5800360860546 := by decide
theorem cert_e1402314349442 : check e1402314349442 [[.left],[.left]] .chain = true := by decide
def e1402314349666 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314349666 : Closed e1402314349666 ∧ code e1402314349666 = 5800360860770 := by decide
theorem cert_e1402314349666 : check e1402314349666 [[.left],[.left]] .chain = true := by decide
def e1402314349830 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314349830 : Closed e1402314349830 ∧ code e1402314349830 = 5800360860934 := by decide
theorem cert_e1402314349830 : check e1402314349830 [[.left],[.left]] .chain = true := by decide
def e1402314349954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314349954 : Closed e1402314349954 ∧ code e1402314349954 = 5800360861058 := by decide
theorem cert_e1402314349954 : check e1402314349954 [[.left],[.left]] .chain = true := by decide
def e1402314353538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314353538 : Closed e1402314353538 ∧ code e1402314353538 = 5800360864642 := by decide
theorem cert_e1402314353538 : check e1402314353538 [[.left],[.left]] .chain = true := by decide
def e1402314354306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314354306 : Closed e1402314354306 ∧ code e1402314354306 = 5800360865410 := by decide
theorem cert_e1402314354306 : check e1402314354306 [[.left],[.left]] .chain = true := by decide
def e1402314355106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402314355106 : Closed e1402314355106 ∧ code e1402314355106 = 5800360866210 := by decide
theorem cert_e1402314355106 : check e1402314355106 [[.left],[.left]] .chain = true := by decide
def e1402314355810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314355810 : Closed e1402314355810 ∧ code e1402314355810 = 5800360866914 := by decide
theorem cert_e1402314355810 : check e1402314355810 [[.left],[.left]] .chain = true := by decide
def e1402314355974 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314355974 : Closed e1402314355974 ∧ code e1402314355974 = 5800360867078 := by decide
theorem cert_e1402314355974 : check e1402314355974 [[.left],[.left]] .chain = true := by decide
def e1402314356098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314356098 : Closed e1402314356098 ∧ code e1402314356098 = 5800360867202 := by decide
theorem cert_e1402314356098 : check e1402314356098 [[.left],[.left]] .chain = true := by decide
def e1402314356354 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314356354 : Closed e1402314356354 ∧ code e1402314356354 = 5800360867458 := by decide
theorem cert_e1402314356354 : check e1402314356354 [[.left],[.left]] .chain = true := by decide
def e1402314366490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402314366490 : Closed e1402314366490 ∧ code e1402314366490 = 5800360877594 := by decide
theorem cert_e1402314366490 : check e1402314366490 [[.left]] .chain = true := by decide
def e1402314371554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402314371554 : Closed e1402314371554 ∧ code e1402314371554 = 5800360882658 := by decide
theorem cert_e1402314371554 : check e1402314371554 [[.left],[.left]] .chain = true := by decide
def e1402314372870 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314372870 : Closed e1402314372870 ∧ code e1402314372870 = 5800360883974 := by decide
theorem cert_e1402314372870 : check e1402314372870 [[.left],[.left]] .chain = true := by decide
def e1402314374018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314374018 : Closed e1402314374018 ∧ code e1402314374018 = 5800360885122 := by decide
theorem cert_e1402314374018 : check e1402314374018 [[.left],[.left]] .chain = true := by decide
def e1402314374242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314374242 : Closed e1402314374242 ∧ code e1402314374242 = 5800360885346 := by decide
theorem cert_e1402314374242 : check e1402314374242 [[.left],[.left]] .chain = true := by decide
def e1402314374406 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314374406 : Closed e1402314374406 ∧ code e1402314374406 = 5800360885510 := by decide
theorem cert_e1402314374406 : check e1402314374406 [[.left],[.left]] .chain = true := by decide
def e1402314374530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314374530 : Closed e1402314374530 ∧ code e1402314374530 = 5800360885634 := by decide
theorem cert_e1402314374530 : check e1402314374530 [[.left],[.left]] .chain = true := by decide
def e1402314387654 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402314387654 : Closed e1402314387654 ∧ code e1402314387654 = 5800360898758 := by decide
theorem cert_e1402314387654 : check e1402314387654 [[.left]] .chain = true := by decide
def e1402314398594 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314398594 : Closed e1402314398594 ∧ code e1402314398594 = 5800360909698 := by decide
theorem cert_e1402314398594 : check e1402314398594 [[.left],[.left]] .chain = true := by decide
def e1402314399362 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314399362 : Closed e1402314399362 ∧ code e1402314399362 = 5800360910466 := by decide
theorem cert_e1402314399362 : check e1402314399362 [[.left],[.left]] .chain = true := by decide
def e1402314409498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402314409498 : Closed e1402314409498 ∧ code e1402314409498 = 5800360920602 := by decide
theorem cert_e1402314409498 : check e1402314409498 [[.left]] .chain = true := by decide
def e1402314411106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314411106 : Closed e1402314411106 ∧ code e1402314411106 = 5800360922210 := by decide
theorem cert_e1402314411106 : check e1402314411106 [[.left],[.left]] .chain = true := by decide
def e1402314411270 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314411270 : Closed e1402314411270 ∧ code e1402314411270 = 5800360922374 := by decide
theorem cert_e1402314411270 : check e1402314411270 [[.left],[.left]] .chain = true := by decide
def e1402314411394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314411394 : Closed e1402314411394 ∧ code e1402314411394 = 5800360922498 := by decide
theorem cert_e1402314411394 : check e1402314411394 [[.left],[.left]] .chain = true := by decide
def e1402314411650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314411650 : Closed e1402314411650 ∧ code e1402314411650 = 5800360922754 := by decide
theorem cert_e1402314411650 : check e1402314411650 [[.left],[.left]] .chain = true := by decide
def e1402314412230 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402314412230 : Closed e1402314412230 ∧ code e1402314412230 = 5800360923334 := by decide
theorem cert_e1402314412230 : check e1402314412230 [[.left]] .chain = true := by decide
def e1402314777442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402314777442 : Closed e1402314777442 ∧ code e1402314777442 = 5800361288546 := by decide
theorem cert_e1402314777442 : check e1402314777442 [[.left],[.left]] .chain = true := by decide
def e1402314777506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402314777506 : Closed e1402314777506 ∧ code e1402314777506 = 5800361288610 := by decide
theorem cert_e1402314777506 : check e1402314777506 [[.left],[.left]] .chain = true := by decide
def e1402314778850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402314778850 : Closed e1402314778850 ∧ code e1402314778850 = 5800361289954 := by decide
theorem cert_e1402314778850 : check e1402314778850 [[.left],[.left]] .chain = true := by decide
def e1402314779398 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314779398 : Closed e1402314779398 ∧ code e1402314779398 = 5800361290502 := by decide
theorem cert_e1402314779398 : check e1402314779398 [[.left],[.left]] .chain = true := by decide
def e1402314779746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314779746 : Closed e1402314779746 ∧ code e1402314779746 = 5800361290850 := by decide
theorem cert_e1402314779746 : check e1402314779746 [[.left],[.left]] .chain = true := by decide
def e1402314779910 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314779910 : Closed e1402314779910 ∧ code e1402314779910 = 5800361291014 := by decide
theorem cert_e1402314779910 : check e1402314779910 [[.left],[.left]] .chain = true := by decide
def e1402314780034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314780034 : Closed e1402314780034 ∧ code e1402314780034 = 5800361291138 := by decide
theorem cert_e1402314780034 : check e1402314780034 [[.left],[.left]] .chain = true := by decide
def e1402314781090 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402314781090 : Closed e1402314781090 ∧ code e1402314781090 = 5800361292194 := by decide
theorem cert_e1402314781090 : check e1402314781090 [[.left],[.left]] .chain = true := by decide
def e1402314781794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402314781794 : Closed e1402314781794 ∧ code e1402314781794 = 5800361292898 := by decide
theorem cert_e1402314781794 : check e1402314781794 [[.left],[.left]] .chain = true := by decide
def e1402314781958 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314781958 : Closed e1402314781958 ∧ code e1402314781958 = 5800361293062 := by decide
theorem cert_e1402314781958 : check e1402314781958 [[.left],[.left]] .chain = true := by decide
def e1402314782082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314782082 : Closed e1402314782082 ∧ code e1402314782082 = 5800361293186 := by decide
theorem cert_e1402314782082 : check e1402314782082 [[.left],[.left]] .chain = true := by decide
def e1402314782338 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314782338 : Closed e1402314782338 ∧ code e1402314782338 = 5800361293442 := by decide
theorem cert_e1402314782338 : check e1402314782338 [[.left],[.left]] .chain = true := by decide
def e1402314788378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402314788378 : Closed e1402314788378 ∧ code e1402314788378 = 5800361299482 := by decide
theorem cert_e1402314788378 : check e1402314788378 [[.left]] .chain = true := by decide
def e1402314791138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402314791138 : Closed e1402314791138 ∧ code e1402314791138 = 5800361302242 := by decide
theorem cert_e1402314791138 : check e1402314791138 [[.left],[.left]] .chain = true := by decide
def e1402314791686 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314791686 : Closed e1402314791686 ∧ code e1402314791686 = 5800361302790 := by decide
theorem cert_e1402314791686 : check e1402314791686 [[.left],[.left]] .chain = true := by decide
def e1402314792034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314792034 : Closed e1402314792034 ∧ code e1402314792034 = 5800361303138 := by decide
theorem cert_e1402314792034 : check e1402314792034 [[.left],[.left]] .chain = true := by decide
def e1402314792198 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314792198 : Closed e1402314792198 ∧ code e1402314792198 = 5800361303302 := by decide
theorem cert_e1402314792198 : check e1402314792198 [[.left],[.left]] .chain = true := by decide
def e1402314792322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314792322 : Closed e1402314792322 ∧ code e1402314792322 = 5800361303426 := by decide
theorem cert_e1402314792322 : check e1402314792322 [[.left],[.left]] .chain = true := by decide
def e1402314797254 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402314797254 : Closed e1402314797254 ∧ code e1402314797254 = 5800361308358 := by decide
theorem cert_e1402314797254 : check e1402314797254 [[.left]] .chain = true := by decide
def e1402314802714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402314802714 : Closed e1402314802714 ∧ code e1402314802714 = 5800361313818 := by decide
theorem cert_e1402314802714 : check e1402314802714 [[.left]] .chain = true := by decide
def e1402314804322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402314804322 : Closed e1402314804322 ∧ code e1402314804322 = 5800361315426 := by decide
theorem cert_e1402314804322 : check e1402314804322 [[.left],[.left]] .chain = true := by decide
def e1402314804486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402314804486 : Closed e1402314804486 ∧ code e1402314804486 = 5800361315590 := by decide
theorem cert_e1402314804486 : check e1402314804486 [[.left],[.left]] .chain = true := by decide
def e1402314804610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314804610 : Closed e1402314804610 ∧ code e1402314804610 = 5800361315714 := by decide
theorem cert_e1402314804610 : check e1402314804610 [[.left],[.left]] .chain = true := by decide
def e1402314804866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402314804866 : Closed e1402314804866 ∧ code e1402314804866 = 5800361315970 := by decide
theorem cert_e1402314804866 : check e1402314804866 [[.left],[.left]] .chain = true := by decide
def e1402314805446 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402314805446 : Closed e1402314805446 ∧ code e1402314805446 = 5800361316550 := by decide
theorem cert_e1402314805446 : check e1402314805446 [[.left]] .chain = true := by decide
def e1402332352226 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402332352226 : Closed e1402332352226 ∧ code e1402332352226 = 5800378863330 := by decide
theorem cert_e1402332352226 : check e1402332352226 [[.left],[.left]] .chain = true := by decide
def e1402332352354 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402332352354 : Closed e1402332352354 ∧ code e1402332352354 = 5800378863458 := by decide
theorem cert_e1402332352354 : check e1402332352354 [[.left],[.left]] .chain = true := by decide
def e1402332361186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402332361186 : Closed e1402332361186 ∧ code e1402332361186 = 5800378872290 := by decide
theorem cert_e1402332361186 : check e1402332361186 [[.left],[.left]] .chain = true := by decide
def e1402332362502 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332362502 : Closed e1402332362502 ∧ code e1402332362502 = 5800378873606 := by decide
theorem cert_e1402332362502 : check e1402332362502 [[.left],[.left]] .chain = true := by decide
def e1402332362978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402332362978 : Closed e1402332362978 ∧ code e1402332362978 = 5800378874082 := by decide
theorem cert_e1402332362978 : check e1402332362978 [[.left],[.left]] .chain = true := by decide
def e1402332363526 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332363526 : Closed e1402332363526 ∧ code e1402332363526 = 5800378874630 := by decide
theorem cert_e1402332363526 : check e1402332363526 [[.left],[.left]] .chain = true := by decide
def e1402332366562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402332366562 : Closed e1402332366562 ∧ code e1402332366562 = 5800378877666 := by decide
theorem cert_e1402332366562 : check e1402332366562 [[.left],[.left]] .chain = true := by decide
def e1402332366754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402332366754 : Closed e1402332366754 ∧ code e1402332366754 = 5800378877858 := by decide
theorem cert_e1402332366754 : check e1402332366754 [[.left],[.left]] .chain = true := by decide
def e1402332369378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402332369378 : Closed e1402332369378 ∧ code e1402332369378 = 5800378880482 := by decide
theorem cert_e1402332369378 : check e1402332369378 [[.left],[.left]] .chain = true := by decide
def e1402332370694 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332370694 : Closed e1402332370694 ∧ code e1402332370694 = 5800378881798 := by decide
theorem cert_e1402332370694 : check e1402332370694 [[.left],[.left]] .chain = true := by decide
def e1402332372066 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402332372066 : Closed e1402332372066 ∧ code e1402332372066 = 5800378883170 := by decide
theorem cert_e1402332372066 : check e1402332372066 [[.left],[.left]] .chain = true := by decide
def e1402332372230 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332372230 : Closed e1402332372230 ∧ code e1402332372230 = 5800378883334 := by decide
theorem cert_e1402332372230 : check e1402332372230 [[.left],[.left]] .chain = true := by decide
def e1402332373858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402332373858 : Closed e1402332373858 ∧ code e1402332373858 = 5800378884962 := by decide
theorem cert_e1402332373858 : check e1402332373858 [[.left],[.left]] .chain = true := by decide
def e1402332373922 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402332373922 : Closed e1402332373922 ∧ code e1402332373922 = 5800378885026 := by decide
theorem cert_e1402332373922 : check e1402332373922 [[.left],[.left]] .chain = true := by decide
def e1402332375266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402332375266 : Closed e1402332375266 ∧ code e1402332375266 = 5800378886370 := by decide
theorem cert_e1402332375266 : check e1402332375266 [[.left],[.left]] .chain = true := by decide
def e1402332375814 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332375814 : Closed e1402332375814 ∧ code e1402332375814 = 5800378886918 := by decide
theorem cert_e1402332375814 : check e1402332375814 [[.left],[.left]] .chain = true := by decide
def e1402332376162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402332376162 : Closed e1402332376162 ∧ code e1402332376162 = 5800378887266 := by decide
theorem cert_e1402332376162 : check e1402332376162 [[.left],[.left]] .chain = true := by decide
def e1402332376326 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332376326 : Closed e1402332376326 ∧ code e1402332376326 = 5800378887430 := by decide
theorem cert_e1402332376326 : check e1402332376326 [[.left],[.left]] .chain = true := by decide
def e1402332410338 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402332410338 : Closed e1402332410338 ∧ code e1402332410338 = 5800378921442 := by decide
theorem cert_e1402332410338 : check e1402332410338 [[.left],[.left]] .chain = true := by decide
def e1402332411654 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332411654 : Closed e1402332411654 ∧ code e1402332411654 = 5800378922758 := by decide
theorem cert_e1402332411654 : check e1402332411654 [[.left],[.left]] .chain = true := by decide
def e1402332412130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402332412130 : Closed e1402332412130 ∧ code e1402332412130 = 5800378923234 := by decide
theorem cert_e1402332412130 : check e1402332412130 [[.left],[.left]] .chain = true := by decide
def e1402332412678 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332412678 : Closed e1402332412678 ∧ code e1402332412678 = 5800378923782 := by decide
theorem cert_e1402332412678 : check e1402332412678 [[.left],[.left]] .chain = true := by decide
def e1402332459490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402332459490 : Closed e1402332459490 ∧ code e1402332459490 = 5800378970594 := by decide
theorem cert_e1402332459490 : check e1402332459490 [[.left],[.left]] .chain = true := by decide
def e1402332460806 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332460806 : Closed e1402332460806 ∧ code e1402332460806 = 5800378971910 := by decide
theorem cert_e1402332460806 : check e1402332460806 [[.left],[.left]] .chain = true := by decide
def e1402332462178 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402332462178 : Closed e1402332462178 ∧ code e1402332462178 = 5800378973282 := by decide
theorem cert_e1402332462178 : check e1402332462178 [[.left],[.left]] .chain = true := by decide
def e1402332462342 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332462342 : Closed e1402332462342 ∧ code e1402332462342 = 5800378973446 := by decide
theorem cert_e1402332462342 : check e1402332462342 [[.left],[.left]] .chain = true := by decide
def e1402332485858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402332485858 : Closed e1402332485858 ∧ code e1402332485858 = 5800378996962 := by decide
theorem cert_e1402332485858 : check e1402332485858 [[.left],[.left]] .chain = true := by decide
def e1402332486406 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332486406 : Closed e1402332486406 ∧ code e1402332486406 = 5800378997510 := by decide
theorem cert_e1402332486406 : check e1402332486406 [[.left],[.left]] .chain = true := by decide
def e1402332486754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402332486754 : Closed e1402332486754 ∧ code e1402332486754 = 5800378997858 := by decide
theorem cert_e1402332486754 : check e1402332486754 [[.left],[.left]] .chain = true := by decide
def e1402332486918 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402332486918 : Closed e1402332486918 ∧ code e1402332486918 = 5800378998022 := by decide
theorem cert_e1402332486918 : check e1402332486918 [[.left],[.left]] .chain = true := by decide
def e1402336369538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336369538 : Closed e1402336369538 ∧ code e1402336369538 = 5800382880642 := by decide
theorem cert_e1402336369538 : check e1402336369538 [[.left],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1402336370050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336370050 : Closed e1402336370050 ∧ code e1402336370050 = 5800382881154 := by decide
private def t_e1402336370050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem cert_e1402336370050 : ¬ IsSelfInterpreter e1402336370050 :=
  wSource (t := t_e1402336370050) (replay_sound (ps := []) (t := e1402336370050) (by decide)) (by decide)
def e1402336373634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336373634 : Closed e1402336373634 ∧ code e1402336373634 = 5800382884738 := by decide
theorem cert_e1402336373634 : check e1402336373634 [[.left],[.left],[],[],[.under],[.under,.left]] .smaller = true := by decide
def e1402336374402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336374402 : Closed e1402336374402 ∧ code e1402336374402 = 5800382885506 := by decide
theorem cert_e1402336374402 : check e1402336374402 [[.left],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e1402336376194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336376194 : Closed e1402336376194 ∧ code e1402336376194 = 5800382887298 := by decide
private def t_e1402336376194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem cert_e1402336376194 : ¬ IsSelfInterpreter e1402336376194 :=
  wSource (t := t_e1402336376194) (replay_sound (ps := []) (t := e1402336376194) (by decide)) (by decide)
def e1402336376450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336376450 : Closed e1402336376450 ∧ code e1402336376450 = 5800382887554 := by decide
theorem cert_e1402336376450 : check e1402336376450 [[.left],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e1402336394114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336394114 : Closed e1402336394114 ∧ code e1402336394114 = 5800382905218 := by decide
theorem cert_e1402336394114 : check e1402336394114 [[.left],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1402336394626 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336394626 : Closed e1402336394626 ∧ code e1402336394626 = 5800382905730 := by decide
theorem cert_e1402336394626 : check e1402336394626 [[.left],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1402336418690 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336418690 : Closed e1402336418690 ∧ code e1402336418690 = 5800382929794 := by decide
theorem cert_e1402336418690 : check e1402336418690 [[.left],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e1402336419458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336419458 : Closed e1402336419458 ∧ code e1402336419458 = 5800382930562 := by decide
theorem cert_e1402336419458 : check e1402336419458 [[.left],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e1402336431490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336431490 : Closed e1402336431490 ∧ code e1402336431490 = 5800382942594 := by decide
theorem cert_e1402336431490 : check e1402336431490 [[.left],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1402336431746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402336431746 : Closed e1402336431746 ∧ code e1402336431746 = 5800382942850 := by decide
theorem cert_e1402336431746 : check e1402336431746 [[.left],[.left],[],[],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e1402407579106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402407579106 : Closed e1402407579106 ∧ code e1402407579106 = 5800454090210 := by decide
theorem cert_e1402407579106 : check e1402407579106 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407579490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402407579490 : Closed e1402407579490 ∧ code e1402407579490 = 5800454090594 := by decide
theorem cert_e1402407579490 : check e1402407579490 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407581154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402407581154 : Closed e1402407581154 ∧ code e1402407581154 = 5800454092258 := by decide
theorem cert_e1402407581154 : check e1402407581154 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407581602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402407581602 : Closed e1402407581602 ∧ code e1402407581602 = 5800454092706 := by decide
theorem cert_e1402407581602 : check e1402407581602 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407583074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402407583074 : Closed e1402407583074 ∧ code e1402407583074 = 5800454094178 := by decide
theorem cert_e1402407583074 : check e1402407583074 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407583138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402407583138 : Closed e1402407583138 ∧ code e1402407583138 = 5800454094242 := by decide
theorem cert_e1402407583138 : check e1402407583138 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407591394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402407591394 : Closed e1402407591394 ∧ code e1402407591394 = 5800454102498 := by decide
theorem cert_e1402407591394 : check e1402407591394 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407591778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402407591778 : Closed e1402407591778 ∧ code e1402407591778 = 5800454102882 := by decide
theorem cert_e1402407591778 : check e1402407591778 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407603682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402407603682 : Closed e1402407603682 ∧ code e1402407603682 = 5800454114786 := by decide
theorem cert_e1402407603682 : check e1402407603682 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407604130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402407604130 : Closed e1402407604130 ∧ code e1402407604130 = 5800454115234 := by decide
theorem cert_e1402407604130 : check e1402407604130 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407613282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402407613282 : Closed e1402407613282 ∧ code e1402407613282 = 5800454124386 := by decide
theorem cert_e1402407613282 : check e1402407613282 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407613346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402407613346 : Closed e1402407613346 ∧ code e1402407613346 = 5800454124450 := by decide
theorem cert_e1402407613346 : check e1402407613346 [[.left],[.left],[.left],[.left]] .chain = true := by decide
def e1402407849698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402407849698 : Closed e1402407849698 ∧ code e1402407849698 = 5800454360802 := by decide
theorem cert_e1402407849698 : check e1402407849698 [[.left],[.left],[.left],[.left],[],[.left],[]] .chain = true := by decide
def e1402407849826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402407849826 : Closed e1402407849826 ∧ code e1402407849826 = 5800454360930 := by decide
theorem cert_e1402407849826 : check e1402407849826 [[.left],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1402407858658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402407858658 : Closed e1402407858658 ∧ code e1402407858658 = 5800454369762 := by decide
theorem cert_e1402407858658 : check e1402407858658 [[.left],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1402407859974 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407859974 : Closed e1402407859974 ∧ code e1402407859974 = 5800454371078 := by decide
theorem cert_e1402407859974 : check e1402407859974 [[.left],[.left],[.left],[.left],[],[.left],[]] .chain = true := by decide
def e1402407860450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402407860450 : Closed e1402407860450 ∧ code e1402407860450 = 5800454371554 := by decide
theorem cert_e1402407860450 : check e1402407860450 [[.left],[.left],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e1402407860998 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407860998 : Closed e1402407860998 ∧ code e1402407860998 = 5800454372102 := by decide
theorem cert_e1402407860998 : check e1402407860998 [[.left],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1402407864034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402407864034 : Closed e1402407864034 ∧ code e1402407864034 = 5800454375138 := by decide
theorem cert_e1402407864034 : check e1402407864034 [[.left],[.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e1402407864226 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402407864226 : Closed e1402407864226 ∧ code e1402407864226 = 5800454375330 := by decide
theorem cert_e1402407864226 : check e1402407864226 [[.left],[.left],[.left],[.left],[],[.left],[],[.left]] .smaller = true := by decide
def e1402407866850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402407866850 : Closed e1402407866850 ∧ code e1402407866850 = 5800454377954 := by decide
theorem cert_e1402407866850 : check e1402407866850 [[.left],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e1402407868166 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407868166 : Closed e1402407868166 ∧ code e1402407868166 = 5800454379270 := by decide
theorem cert_e1402407868166 : check e1402407868166 [[.left],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e1402407869538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402407869538 : Closed e1402407869538 ∧ code e1402407869538 = 5800454380642 := by decide
private def t_e1402407869538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem cert_e1402407869538 : ¬ IsSelfInterpreter e1402407869538 :=
  wSource (t := t_e1402407869538) (replay_sound (ps := []) (t := e1402407869538) (by decide)) (by decide)
def e1402407869702 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407869702 : Closed e1402407869702 ∧ code e1402407869702 = 5800454380806 := by decide
private def t_e1402407869702 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem cert_e1402407869702 : ¬ IsSelfInterpreter e1402407869702 :=
  wSource (t := t_e1402407869702) (replay_sound (ps := []) (t := e1402407869702) (by decide)) (by decide)
def e1402407871330 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402407871330 : Closed e1402407871330 ∧ code e1402407871330 = 5800454382434 := by decide
theorem cert_e1402407871330 : check e1402407871330 [[.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1402407871394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402407871394 : Closed e1402407871394 ∧ code e1402407871394 = 5800454382498 := by decide
theorem cert_e1402407871394 : check e1402407871394 [[.left],[.left],[.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e1402407872738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402407872738 : Closed e1402407872738 ∧ code e1402407872738 = 5800454383842 := by decide
theorem cert_e1402407872738 : check e1402407872738 [[.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1402407873286 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407873286 : Closed e1402407873286 ∧ code e1402407873286 = 5800454384390 := by decide
theorem cert_e1402407873286 : check e1402407873286 [[.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1402407873634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402407873634 : Closed e1402407873634 ∧ code e1402407873634 = 5800454384738 := by decide
private def t_e1402407873634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem cert_e1402407873634 : ¬ IsSelfInterpreter e1402407873634 :=
  wSource (t := t_e1402407873634) (replay_sound (ps := []) (t := e1402407873634) (by decide)) (by decide)
def e1402407873798 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407873798 : Closed e1402407873798 ∧ code e1402407873798 = 5800454384902 := by decide
private def t_e1402407873798 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem cert_e1402407873798 : ¬ IsSelfInterpreter e1402407873798 :=
  wSource (t := t_e1402407873798) (replay_sound (ps := []) (t := e1402407873798) (by decide)) (by decide)
def e1402407907810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402407907810 : Closed e1402407907810 ∧ code e1402407907810 = 5800454418914 := by decide
theorem cert_e1402407907810 : check e1402407907810 [[.left],[.left],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e1402407909126 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407909126 : Closed e1402407909126 ∧ code e1402407909126 = 5800454420230 := by decide
theorem cert_e1402407909126 : check e1402407909126 [[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1402407909602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402407909602 : Closed e1402407909602 ∧ code e1402407909602 = 5800454420706 := by decide
theorem cert_e1402407909602 : check e1402407909602 [[.left],[.left],[.left],[.left],[],[],[],[]] .chain = true := by decide
def e1402407910150 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407910150 : Closed e1402407910150 ∧ code e1402407910150 = 5800454421254 := by decide
theorem cert_e1402407910150 : check e1402407910150 [[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e1402407956962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402407956962 : Closed e1402407956962 ∧ code e1402407956962 = 5800454468066 := by decide
theorem cert_e1402407956962 : check e1402407956962 [[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .smaller = true := by decide
def e1402407958278 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407958278 : Closed e1402407958278 ∧ code e1402407958278 = 5800454469382 := by decide
theorem cert_e1402407958278 : check e1402407958278 [[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .smaller = true := by decide
def e1402407959650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402407959650 : Closed e1402407959650 ∧ code e1402407959650 = 5800454470754 := by decide
theorem cert_e1402407959650 : check e1402407959650 [[.left],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e1402407959814 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407959814 : Closed e1402407959814 ∧ code e1402407959814 = 5800454470918 := by decide
theorem cert_e1402407959814 : check e1402407959814 [[.left],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e1402407983330 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402407983330 : Closed e1402407983330 ∧ code e1402407983330 = 5800454494434 := by decide
theorem cert_e1402407983330 : check e1402407983330 [[.left],[.left],[.left],[.left],[],[],[.left],[]] .chain = true := by decide
def e1402407983878 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407983878 : Closed e1402407983878 ∧ code e1402407983878 = 5800454494982 := by decide
theorem cert_e1402407983878 : check e1402407983878 [[.left],[.left],[.left],[.left],[],[],[.left],[]] .chain = true := by decide
end Blc.Floor42
