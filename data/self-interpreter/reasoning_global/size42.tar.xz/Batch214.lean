import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207377762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211207377762 : Closed e1211207377762 ∧ code e1211207377762 = 5609253888866 := by decide
theorem cert_e1211207377762 : check e1211207377762 [[],[]] .chain = true := by decide
def e1211207377774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211207377774 : Closed e1211207377774 ∧ code e1211207377774 = 5609253888878 := by decide
theorem cert_e1211207377774 : check e1211207377774 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207377782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211207377782 : Closed e1211207377782 ∧ code e1211207377782 = 5609253888886 := by decide
theorem cert_e1211207377782 : check e1211207377782 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207377802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211207377802 : Closed e1211207377802 ∧ code e1211207377802 = 5609253888906 := by decide
theorem cert_e1211207377802 : check e1211207377802 [[],[]] .chain = true := by decide
def e1211207377826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211207377826 : Closed e1211207377826 ∧ code e1211207377826 = 5609253888930 := by decide
theorem cert_e1211207377826 : check e1211207377826 [[],[]] .chain = true := by decide
def e1211207377838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211207377838 : Closed e1211207377838 ∧ code e1211207377838 = 5609253888942 := by decide
theorem cert_e1211207377838 : check e1211207377838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207377846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211207377846 : Closed e1211207377846 ∧ code e1211207377846 = 5609253888950 := by decide
theorem cert_e1211207377846 : check e1211207377846 [[],[]] .chain = true := by decide
def e1211207377850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211207377850 : Closed e1211207377850 ∧ code e1211207377850 = 5609253888954 := by decide
theorem cert_e1211207377850 : check e1211207377850 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207377878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211207377878 : Closed e1211207377878 ∧ code e1211207377878 = 5609253888982 := by decide
theorem cert_e1211207377878 : check e1211207377878 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207377882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211207377882 : Closed e1211207377882 ∧ code e1211207377882 = 5609253888986 := by decide
theorem cert_e1211207377882 : check e1211207377882 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207378614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211207378614 : Closed e1211207378614 ∧ code e1211207378614 = 5609253889718 := by decide
theorem cert_e1211207378614 : check e1211207378614 [[],[]] .chain = true := by decide
def e1211207378646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211207378646 : Closed e1211207378646 ∧ code e1211207378646 = 5609253889750 := by decide
theorem cert_e1211207378646 : check e1211207378646 [[],[]] .chain = true := by decide
def e1211207378650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211207378650 : Closed e1211207378650 ∧ code e1211207378650 = 5609253889754 := by decide
theorem cert_e1211207378650 : check e1211207378650 [[],[]] .chain = true := by decide
def e1211207378774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211207378774 : Closed e1211207378774 ∧ code e1211207378774 = 5609253889878 := by decide
theorem cert_e1211207378774 : check e1211207378774 [[],[]] .chain = true := by decide
def e1211207378778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211207378778 : Closed e1211207378778 ∧ code e1211207378778 = 5609253889882 := by decide
theorem cert_e1211207378778 : check e1211207378778 [[],[]] .chain = true := by decide
def e1211207378794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211207378794 : Closed e1211207378794 ∧ code e1211207378794 = 5609253889898 := by decide
theorem cert_e1211207378794 : check e1211207378794 [[],[]] .chain = true := by decide
def e1211207378998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211207378998 : Closed e1211207378998 ∧ code e1211207378998 = 5609253890102 := by decide
theorem cert_e1211207378998 : check e1211207378998 [[],[]] .chain = true := by decide
def e1211207379086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211207379086 : Closed e1211207379086 ∧ code e1211207379086 = 5609253890190 := by decide
theorem cert_e1211207379086 : check e1211207379086 [[],[]] .chain = true := by decide
def e1211207379170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211207379170 : Closed e1211207379170 ∧ code e1211207379170 = 5609253890274 := by decide
theorem cert_e1211207379170 : check e1211207379170 [[],[]] .chain = true := by decide
def e1211207379182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211207379182 : Closed e1211207379182 ∧ code e1211207379182 = 5609253890286 := by decide
theorem cert_e1211207379182 : check e1211207379182 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207379190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211207379190 : Closed e1211207379190 ∧ code e1211207379190 = 5609253890294 := by decide
theorem cert_e1211207379190 : check e1211207379190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207379382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211207379382 : Closed e1211207379382 ∧ code e1211207379382 = 5609253890486 := by decide
theorem cert_e1211207379382 : check e1211207379382 [[],[]] .chain = true := by decide
def e1211207379414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211207379414 : Closed e1211207379414 ∧ code e1211207379414 = 5609253890518 := by decide
theorem cert_e1211207379414 : check e1211207379414 [[],[]] .chain = true := by decide
def e1211207379418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211207379418 : Closed e1211207379418 ∧ code e1211207379418 = 5609253890522 := by decide
theorem cert_e1211207379418 : check e1211207379418 [[],[]] .chain = true := by decide
def e1211207379574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207379574 : Closed e1211207379574 ∧ code e1211207379574 = 5609253890678 := by decide
theorem cert_e1211207379574 : check e1211207379574 [[],[]] .chain = true := by decide
def e1211207379718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207379718 : Closed e1211207379718 ∧ code e1211207379718 = 5609253890822 := by decide
theorem cert_e1211207379718 : check e1211207379718 [[],[]] .chain = true := by decide
def e1211207379742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211207379742 : Closed e1211207379742 ∧ code e1211207379742 = 5609253890846 := by decide
theorem cert_e1211207379742 : check e1211207379742 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207379766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207379766 : Closed e1211207379766 ∧ code e1211207379766 = 5609253890870 := by decide
theorem cert_e1211207379766 : check e1211207379766 [[],[]] .chain = true := by decide
def e1211207379770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207379770 : Closed e1211207379770 ∧ code e1211207379770 = 5609253890874 := by decide
theorem cert_e1211207379770 : check e1211207379770 [[],[]] .chain = true := by decide
def e1211207379854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211207379854 : Closed e1211207379854 ∧ code e1211207379854 = 5609253890958 := by decide
theorem cert_e1211207379854 : checkPay e1211207379854 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e1211207379990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211207379990 : Closed e1211207379990 ∧ code e1211207379990 = 5609253891094 := by decide
theorem cert_e1211207379990 : check e1211207379990 [[],[]] .chain = true := by decide
def e1211207379994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211207379994 : Closed e1211207379994 ∧ code e1211207379994 = 5609253891098 := by decide
theorem cert_e1211207379994 : check e1211207379994 [[],[]] .chain = true := by decide
def e1211207380038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211207380038 : Closed e1211207380038 ∧ code e1211207380038 = 5609253891142 := by decide
theorem cert_e1211207380038 : check e1211207380038 [[],[]] .chain = true := by decide
def e1211207380066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211207380066 : Closed e1211207380066 ∧ code e1211207380066 = 5609253891170 := by decide
theorem cert_e1211207380066 : check e1211207380066 [[],[]] .chain = true := by decide
def e1211207380078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211207380078 : Closed e1211207380078 ∧ code e1211207380078 = 5609253891182 := by decide
theorem cert_e1211207380078 : check e1211207380078 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207380086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211207380086 : Closed e1211207380086 ∧ code e1211207380086 = 5609253891190 := by decide
theorem cert_e1211207380086 : check e1211207380086 [[],[]] .chain = true := by decide
def e1211207380090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211207380090 : Closed e1211207380090 ∧ code e1211207380090 = 5609253891194 := by decide
theorem cert_e1211207380090 : check e1211207380090 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207380182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211207380182 : Closed e1211207380182 ∧ code e1211207380182 = 5609253891286 := by decide
theorem cert_e1211207380182 : check e1211207380182 [[],[]] .chain = true := by decide
def e1211207380186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211207380186 : Closed e1211207380186 ∧ code e1211207380186 = 5609253891290 := by decide
theorem cert_e1211207380186 : check e1211207380186 [[],[]] .chain = true := by decide
def e1211207380202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211207380202 : Closed e1211207380202 ∧ code e1211207380202 = 5609253891306 := by decide
theorem cert_e1211207380202 : check e1211207380202 [[],[]] .chain = true := by decide
def e1211207380230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207380230 : Closed e1211207380230 ∧ code e1211207380230 = 5609253891334 := by decide
theorem cert_e1211207380230 : check e1211207380230 [[],[]] .chain = true := by decide
def e1211207380254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211207380254 : Closed e1211207380254 ∧ code e1211207380254 = 5609253891358 := by decide
theorem cert_e1211207380254 : check e1211207380254 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207380278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207380278 : Closed e1211207380278 ∧ code e1211207380278 = 5609253891382 := by decide
theorem cert_e1211207380278 : check e1211207380278 [[],[]] .chain = true := by decide
def e1211207380282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207380282 : Closed e1211207380282 ∧ code e1211207380282 = 5609253891386 := by decide
theorem cert_e1211207380282 : check e1211207380282 [[],[]] .chain = true := by decide
def e1211207380354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207380354 : Closed e1211207380354 ∧ code e1211207380354 = 5609253891458 := by decide
theorem cert_e1211207380354 : check e1211207380354 [[],[]] .chain = true := by decide
def e1211207380366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211207380366 : Closed e1211207380366 ∧ code e1211207380366 = 5609253891470 := by decide
theorem cert_e1211207380366 : check e1211207380366 [[],[]] .chain = true := by decide
def e1211207380378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207380378 : Closed e1211207380378 ∧ code e1211207380378 = 5609253891482 := by decide
theorem cert_e1211207380378 : check e1211207380378 [[],[]] .chain = true := by decide
def e1211207380422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211207380422 : Closed e1211207380422 ∧ code e1211207380422 = 5609253891526 := by decide
theorem cert_e1211207380422 : check e1211207380422 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207380534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211207380534 : Closed e1211207380534 ∧ code e1211207380534 = 5609253891638 := by decide
theorem cert_e1211207380534 : check e1211207380534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207380538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211207380538 : Closed e1211207380538 ∧ code e1211207380538 = 5609253891642 := by decide
def e1211207380622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211207380622 : Closed e1211207380622 ∧ code e1211207380622 = 5609253891726 := by decide
theorem cert_e1211207380622 : checkPay e1211207380622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e1211207380678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211207380678 : Closed e1211207380678 ∧ code e1211207380678 = 5609253891782 := by decide
theorem cert_e1211207380678 : check e1211207380678 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207386094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 2)))))))
theorem wire_e1211207386094 : Closed e1211207386094 ∧ code e1211207386094 = 5609253897198 := by decide
theorem cert_e1211207386094 : check e1211207386094 [[],[]] .chain = true := by decide
def e1211207386102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e1211207386102 : Closed e1211207386102 ∧ code e1211207386102 = 5609253897206 := by decide
theorem cert_e1211207386102 : check e1211207386102 [[],[]] .chain = true := by decide
def e1211207388398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207388398 : Closed e1211207388398 ∧ code e1211207388398 = 5609253899502 := by decide
theorem cert_e1211207388398 : check e1211207388398 [[],[]] .chain = true := by decide
def e1211207388406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207388406 : Closed e1211207388406 ∧ code e1211207388406 = 5609253899510 := by decide
theorem cert_e1211207388406 : check e1211207388406 [[],[]] .chain = true := by decide
def e1211207388958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 3))))))))
theorem wire_e1211207388958 : Closed e1211207388958 ∧ code e1211207388958 = 5609253900062 := by decide
theorem cert_e1211207388958 : check e1211207388958 [[],[]] .chain = true := by decide
def e1211207389070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e1211207389070 : Closed e1211207389070 ∧ code e1211207389070 = 5609253900174 := by decide
theorem cert_e1211207389070 : check e1211207389070 [[],[]] .chain = true := by decide
def e1211207392814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211207392814 : Closed e1211207392814 ∧ code e1211207392814 = 5609253903918 := by decide
theorem cert_e1211207392814 : check e1211207392814 [[],[]] .chain = true := by decide
def e1211207393006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e1211207393006 : Closed e1211207393006 ∧ code e1211207393006 = 5609253904110 := by decide
theorem cert_e1211207393006 : check e1211207393006 [[],[]] .chain = true := by decide
def e1211207393014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e1211207393014 : Closed e1211207393014 ∧ code e1211207393014 = 5609253904118 := by decide
theorem cert_e1211207393014 : check e1211207393014 [[],[]] .chain = true := by decide
def e1211207393046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211207393046 : Closed e1211207393046 ∧ code e1211207393046 = 5609253904150 := by decide
theorem cert_e1211207393046 : check e1211207393046 [[],[]] .chain = true := by decide
def e1211207393142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e1211207393142 : Closed e1211207393142 ∧ code e1211207393142 = 5609253904246 := by decide
theorem cert_e1211207393142 : check e1211207393142 [[],[]] .chain = true := by decide
def e1211207395102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211207395102 : Closed e1211207395102 ∧ code e1211207395102 = 5609253906206 := by decide
theorem cert_e1211207395102 : check e1211207395102 [[],[]] .chain = true := by decide
def e1211207395214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211207395214 : Closed e1211207395214 ∧ code e1211207395214 = 5609253906318 := by decide
theorem cert_e1211207395214 : check e1211207395214 [[],[]] .chain = true := by decide
def e1211207399486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211207399486 : Closed e1211207399486 ∧ code e1211207399486 = 5609253910590 := by decide
theorem cert_e1211207399486 : check e1211207399486 [[],[]] .chain = true := by decide
def e1211207399906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211207399906 : Closed e1211207399906 ∧ code e1211207399906 = 5609253911010 := by decide
theorem cert_e1211207399906 : check e1211207399906 [[],[]] .chain = true := by decide
def e1211207399918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211207399918 : Closed e1211207399918 ∧ code e1211207399918 = 5609253911022 := by decide
theorem cert_e1211207399918 : check e1211207399918 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207400478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211207400478 : Closed e1211207400478 ∧ code e1211207400478 = 5609253911582 := by decide
theorem cert_e1211207400478 : check e1211207400478 [[],[]] .chain = true := by decide
def e1211207400674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211207400674 : Closed e1211207400674 ∧ code e1211207400674 = 5609253911778 := by decide
theorem cert_e1211207400674 : check e1211207400674 [[],[]] .chain = true := by decide
def e1211207400686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207400686 : Closed e1211207400686 ∧ code e1211207400686 = 5609253911790 := by decide
theorem cert_e1211207400686 : check e1211207400686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207400694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207400694 : Closed e1211207400694 ∧ code e1211207400694 = 5609253911798 := by decide
theorem cert_e1211207400694 : check e1211207400694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207408494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e1211207408494 : Closed e1211207408494 ∧ code e1211207408494 = 5609253919598 := by decide
theorem cert_e1211207408494 : check e1211207408494 [[],[]] .chain = true := by decide
def e1211207408502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e1211207408502 : Closed e1211207408502 ∧ code e1211207408502 = 5609253919606 := by decide
theorem cert_e1211207408502 : check e1211207408502 [[],[]] .chain = true := by decide
def e1211207408566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e1211207408566 : Closed e1211207408566 ∧ code e1211207408566 = 5609253919670 := by decide
theorem cert_e1211207408566 : check e1211207408566 [[],[]] .chain = true := by decide
def e1211207409006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211207409006 : Closed e1211207409006 ∧ code e1211207409006 = 5609253920110 := by decide
theorem cert_e1211207409006 : check e1211207409006 [[],[]] .chain = true := by decide
def e1211207409014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211207409014 : Closed e1211207409014 ∧ code e1211207409014 = 5609253920118 := by decide
theorem cert_e1211207409014 : check e1211207409014 [[],[]] .chain = true := by decide
def e1211207409070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211207409070 : Closed e1211207409070 ∧ code e1211207409070 = 5609253920174 := by decide
theorem cert_e1211207409070 : check e1211207409070 [[],[]] .chain = true := by decide
def e1211207409082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211207409082 : Closed e1211207409082 ∧ code e1211207409082 = 5609253920186 := by decide
theorem cert_e1211207409082 : check e1211207409082 [[],[]] .chain = true := by decide
def e1211207409110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211207409110 : Closed e1211207409110 ∧ code e1211207409110 = 5609253920214 := by decide
theorem cert_e1211207409110 : check e1211207409110 [[],[]] .chain = true := by decide
def e1211207409114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211207409114 : Closed e1211207409114 ∧ code e1211207409114 = 5609253920218 := by decide
theorem cert_e1211207409114 : check e1211207409114 [[],[]] .chain = true := by decide
def e1211207409334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211207409334 : Closed e1211207409334 ∧ code e1211207409334 = 5609253920438 := by decide
theorem cert_e1211207409334 : check e1211207409334 [[],[]] .chain = true := by decide
def e1211207409366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211207409366 : Closed e1211207409366 ∧ code e1211207409366 = 5609253920470 := by decide
theorem cert_e1211207409366 : check e1211207409366 [[],[]] .chain = true := by decide
def e1211207409370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211207409370 : Closed e1211207409370 ∧ code e1211207409370 = 5609253920474 := by decide
theorem cert_e1211207409370 : check e1211207409370 [[],[]] .chain = true := by decide
def e1211207411566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211207411566 : Closed e1211207411566 ∧ code e1211207411566 = 5609253922670 := by decide
theorem cert_e1211207411566 : check e1211207411566 [[],[]] .chain = true := by decide
def e1211207411574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211207411574 : Closed e1211207411574 ∧ code e1211207411574 = 5609253922678 := by decide
theorem cert_e1211207411574 : check e1211207411574 [[],[]] .chain = true := by decide
def e1211207411638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211207411638 : Closed e1211207411638 ∧ code e1211207411638 = 5609253922742 := by decide
theorem cert_e1211207411638 : check e1211207411638 [[],[]] .chain = true := by decide
def e1211207412974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207412974 : Closed e1211207412974 ∧ code e1211207412974 = 5609253924078 := by decide
theorem cert_e1211207412974 : check e1211207412974 [[],[]] .chain = true := by decide
def e1211207412982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207412982 : Closed e1211207412982 ∧ code e1211207412982 = 5609253924086 := by decide
theorem cert_e1211207412982 : check e1211207412982 [[],[]] .chain = true := by decide
def e1211207413366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207413366 : Closed e1211207413366 ∧ code e1211207413366 = 5609253924470 := by decide
theorem cert_e1211207413366 : check e1211207413366 [[],[]] .chain = true := by decide
def e1211207413870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211207413870 : Closed e1211207413870 ∧ code e1211207413870 = 5609253924974 := by decide
theorem cert_e1211207413870 : check e1211207413870 [[],[]] .chain = true := by decide
def e1211207414046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211207414046 : Closed e1211207414046 ∧ code e1211207414046 = 5609253925150 := by decide
theorem cert_e1211207414046 : check e1211207414046 [[],[]] .chain = true := by decide
def e1211207414242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211207414242 : Closed e1211207414242 ∧ code e1211207414242 = 5609253925346 := by decide
theorem cert_e1211207414242 : check e1211207414242 [[],[]] .chain = true := by decide
def e1211207414254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211207414254 : Closed e1211207414254 ∧ code e1211207414254 = 5609253925358 := by decide
theorem cert_e1211207414254 : check e1211207414254 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211207414638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211207414638 : Closed e1211207414638 ∧ code e1211207414638 = 5609253925742 := by decide
theorem cert_e1211207414638 : check e1211207414638 [[],[]] .chain = true := by decide
def e1211207414646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211207414646 : Closed e1211207414646 ∧ code e1211207414646 = 5609253925750 := by decide
theorem cert_e1211207414646 : check e1211207414646 [[],[]] .chain = true := by decide
def e1211207414702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211207414702 : Closed e1211207414702 ∧ code e1211207414702 = 5609253925806 := by decide
theorem cert_e1211207414702 : check e1211207414702 [[],[]] .chain = true := by decide
def e1211207414714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211207414714 : Closed e1211207414714 ∧ code e1211207414714 = 5609253925818 := by decide
theorem cert_e1211207414714 : check e1211207414714 [[],[]] .chain = true := by decide
def e1211207414742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211207414742 : Closed e1211207414742 ∧ code e1211207414742 = 5609253925846 := by decide
theorem cert_e1211207414742 : check e1211207414742 [[],[]] .chain = true := by decide
def e1211207414746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211207414746 : Closed e1211207414746 ∧ code e1211207414746 = 5609253925850 := by decide
theorem cert_e1211207414746 : check e1211207414746 [[],[]] .chain = true := by decide
def e1211207415022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207415022 : Closed e1211207415022 ∧ code e1211207415022 = 5609253926126 := by decide
theorem cert_e1211207415022 : check e1211207415022 [[],[]] .chain = true := by decide
def e1211207415030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207415030 : Closed e1211207415030 ∧ code e1211207415030 = 5609253926134 := by decide
theorem cert_e1211207415030 : check e1211207415030 [[],[]] .chain = true := by decide
def e1211207415406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207415406 : Closed e1211207415406 ∧ code e1211207415406 = 5609253926510 := by decide
theorem cert_e1211207415406 : check e1211207415406 [[],[]] .chain = true := by decide
def e1211207415418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207415418 : Closed e1211207415418 ∧ code e1211207415418 = 5609253926522 := by decide
theorem cert_e1211207415418 : check e1211207415418 [[],[]] .chain = true := by decide
def e1211207415558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207415558 : Closed e1211207415558 ∧ code e1211207415558 = 5609253926662 := by decide
theorem cert_e1211207415558 : check e1211207415558 [[],[]] .chain = true := by decide
def e1211207415582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211207415582 : Closed e1211207415582 ∧ code e1211207415582 = 5609253926686 := by decide
theorem cert_e1211207415582 : check e1211207415582 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211207415606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207415606 : Closed e1211207415606 ∧ code e1211207415606 = 5609253926710 := by decide
theorem cert_e1211207415606 : check e1211207415606 [[],[]] .chain = true := by decide
def e1211207415610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207415610 : Closed e1211207415610 ∧ code e1211207415610 = 5609253926714 := by decide
theorem cert_e1211207415610 : check e1211207415610 [[],[]] .chain = true := by decide
def e1211207415862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211207415862 : Closed e1211207415862 ∧ code e1211207415862 = 5609253926966 := by decide
theorem cert_e1211207415862 : check e1211207415862 [[],[]] .chain = true := by decide
def e1211207415950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211207415950 : Closed e1211207415950 ∧ code e1211207415950 = 5609253927054 := by decide
theorem cert_e1211207415950 : check e1211207415950 [[],[]] .chain = true := by decide
def e1211207416034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211207416034 : Closed e1211207416034 ∧ code e1211207416034 = 5609253927138 := by decide
theorem cert_e1211207416034 : check e1211207416034 [[],[]] .chain = true := by decide
def e1211207416046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211207416046 : Closed e1211207416046 ∧ code e1211207416046 = 5609253927150 := by decide
theorem cert_e1211207416046 : check e1211207416046 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207416054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211207416054 : Closed e1211207416054 ∧ code e1211207416054 = 5609253927158 := by decide
theorem cert_e1211207416054 : check e1211207416054 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207416246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211207416246 : Closed e1211207416246 ∧ code e1211207416246 = 5609253927350 := by decide
theorem cert_e1211207416246 : check e1211207416246 [[],[]] .chain = true := by decide
def e1211207416278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211207416278 : Closed e1211207416278 ∧ code e1211207416278 = 5609253927382 := by decide
theorem cert_e1211207416278 : check e1211207416278 [[],[]] .chain = true := by decide
def e1211207416282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211207416282 : Closed e1211207416282 ∧ code e1211207416282 = 5609253927386 := by decide
theorem cert_e1211207416282 : check e1211207416282 [[],[]] .chain = true := by decide
def e1211207416438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207416438 : Closed e1211207416438 ∧ code e1211207416438 = 5609253927542 := by decide
theorem cert_e1211207416438 : check e1211207416438 [[],[]] .chain = true := by decide
def e1211207416582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207416582 : Closed e1211207416582 ∧ code e1211207416582 = 5609253927686 := by decide
theorem cert_e1211207416582 : check e1211207416582 [[],[]] .chain = true := by decide
def e1211207416606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211207416606 : Closed e1211207416606 ∧ code e1211207416606 = 5609253927710 := by decide
theorem cert_e1211207416606 : check e1211207416606 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207416630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207416630 : Closed e1211207416630 ∧ code e1211207416630 = 5609253927734 := by decide
theorem cert_e1211207416630 : check e1211207416630 [[],[]] .chain = true := by decide
def e1211207416634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207416634 : Closed e1211207416634 ∧ code e1211207416634 = 5609253927738 := by decide
theorem cert_e1211207416634 : check e1211207416634 [[],[]] .chain = true := by decide
def e1211207416718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211207416718 : Closed e1211207416718 ∧ code e1211207416718 = 5609253927822 := by decide
theorem cert_e1211207416718 : check e1211207416718 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207423854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211207423854 : Closed e1211207423854 ∧ code e1211207423854 = 5609253934958 := by decide
theorem cert_e1211207423854 : check e1211207423854 [[],[]] .chain = true := by decide
def e1211207423862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211207423862 : Closed e1211207423862 ∧ code e1211207423862 = 5609253934966 := by decide
theorem cert_e1211207423862 : check e1211207423862 [[],[]] .chain = true := by decide
def e1211207423926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211207423926 : Closed e1211207423926 ∧ code e1211207423926 = 5609253935030 := by decide
theorem cert_e1211207423926 : check e1211207423926 [[],[]] .chain = true := by decide
def e1211207425262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207425262 : Closed e1211207425262 ∧ code e1211207425262 = 5609253936366 := by decide
theorem cert_e1211207425262 : check e1211207425262 [[],[]] .chain = true := by decide
def e1211207425270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207425270 : Closed e1211207425270 ∧ code e1211207425270 = 5609253936374 := by decide
theorem cert_e1211207425270 : check e1211207425270 [[],[]] .chain = true := by decide
def e1211207425654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207425654 : Closed e1211207425654 ∧ code e1211207425654 = 5609253936758 := by decide
theorem cert_e1211207425654 : check e1211207425654 [[],[]] .chain = true := by decide
def e1211207434366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211207434366 : Closed e1211207434366 ∧ code e1211207434366 = 5609253945470 := by decide
theorem cert_e1211207434366 : check e1211207434366 [[],[]] .chain = true := by decide
def e1211207435230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211207435230 : Closed e1211207435230 ∧ code e1211207435230 = 5609253946334 := by decide
theorem cert_e1211207435230 : check e1211207435230 [[],[]] .chain = true := by decide
def e1211207435234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211207435234 : Closed e1211207435234 ∧ code e1211207435234 = 5609253946338 := by decide
theorem cert_e1211207435234 : check e1211207435234 [[],[]] .chain = true := by decide
def e1211207435246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211207435246 : Closed e1211207435246 ∧ code e1211207435246 = 5609253946350 := by decide
theorem cert_e1211207435246 : check e1211207435246 [[],[]] .chain = true := by decide
def e1211207437166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211207437166 : Closed e1211207437166 ∧ code e1211207437166 = 5609253948270 := by decide
theorem cert_e1211207437166 : check e1211207437166 [[],[]] .chain = true := by decide
def e1211207437174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211207437174 : Closed e1211207437174 ∧ code e1211207437174 = 5609253948278 := by decide
theorem cert_e1211207437174 : check e1211207437174 [[],[]] .chain = true := by decide
def e1211207437230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211207437230 : Closed e1211207437230 ∧ code e1211207437230 = 5609253948334 := by decide
theorem cert_e1211207437230 : check e1211207437230 [[],[]] .chain = true := by decide
def e1211207437242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211207437242 : Closed e1211207437242 ∧ code e1211207437242 = 5609253948346 := by decide
theorem cert_e1211207437242 : check e1211207437242 [[],[]] .chain = true := by decide
def e1211207437270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211207437270 : Closed e1211207437270 ∧ code e1211207437270 = 5609253948374 := by decide
theorem cert_e1211207437270 : check e1211207437270 [[],[]] .chain = true := by decide
def e1211207437274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211207437274 : Closed e1211207437274 ∧ code e1211207437274 = 5609253948378 := by decide
theorem cert_e1211207437274 : check e1211207437274 [[],[]] .chain = true := by decide
def e1211207437550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207437550 : Closed e1211207437550 ∧ code e1211207437550 = 5609253948654 := by decide
theorem cert_e1211207437550 : check e1211207437550 [[],[]] .chain = true := by decide
def e1211207437558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207437558 : Closed e1211207437558 ∧ code e1211207437558 = 5609253948662 := by decide
theorem cert_e1211207437558 : check e1211207437558 [[],[]] .chain = true := by decide
def e1211207437934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207437934 : Closed e1211207437934 ∧ code e1211207437934 = 5609253949038 := by decide
theorem cert_e1211207437934 : check e1211207437934 [[],[]] .chain = true := by decide
def e1211207437946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207437946 : Closed e1211207437946 ∧ code e1211207437946 = 5609253949050 := by decide
theorem cert_e1211207437946 : check e1211207437946 [[],[]] .chain = true := by decide
def e1211207438086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207438086 : Closed e1211207438086 ∧ code e1211207438086 = 5609253949190 := by decide
theorem cert_e1211207438086 : check e1211207438086 [[],[]] .chain = true := by decide
def e1211207438110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211207438110 : Closed e1211207438110 ∧ code e1211207438110 = 5609253949214 := by decide
theorem cert_e1211207438110 : check e1211207438110 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211207438134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207438134 : Closed e1211207438134 ∧ code e1211207438134 = 5609253949238 := by decide
theorem cert_e1211207438134 : check e1211207438134 [[],[]] .chain = true := by decide
def e1211207438138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207438138 : Closed e1211207438138 ∧ code e1211207438138 = 5609253949242 := by decide
theorem cert_e1211207438138 : check e1211207438138 [[],[]] .chain = true := by decide
def e1211207442494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211207442494 : Closed e1211207442494 ∧ code e1211207442494 = 5609253953598 := by decide
theorem cert_e1211207442494 : check e1211207442494 [[],[]] .chain = true := by decide
def e1211207442914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211207442914 : Closed e1211207442914 ∧ code e1211207442914 = 5609253954018 := by decide
theorem cert_e1211207442914 : check e1211207442914 [[],[]] .chain = true := by decide
def e1211207442926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211207442926 : Closed e1211207442926 ∧ code e1211207442926 = 5609253954030 := by decide
theorem cert_e1211207442926 : check e1211207442926 [[],[]] .chain = true := by decide
def e1211207443894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211207443894 : Closed e1211207443894 ∧ code e1211207443894 = 5609253954998 := by decide
theorem cert_e1211207443894 : check e1211207443894 [[],[]] .chain = true := by decide
def e1211207443926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211207443926 : Closed e1211207443926 ∧ code e1211207443926 = 5609253955030 := by decide
theorem cert_e1211207443926 : check e1211207443926 [[],[]] .chain = true := by decide
def e1211207443930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211207443930 : Closed e1211207443930 ∧ code e1211207443930 = 5609253955034 := by decide
theorem cert_e1211207443930 : check e1211207443930 [[],[]] .chain = true := by decide
def e1211207444086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207444086 : Closed e1211207444086 ∧ code e1211207444086 = 5609253955190 := by decide
theorem cert_e1211207444086 : check e1211207444086 [[],[]] .chain = true := by decide
def e1211207444230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207444230 : Closed e1211207444230 ∧ code e1211207444230 = 5609253955334 := by decide
theorem cert_e1211207444230 : check e1211207444230 [[],[]] .chain = true := by decide
def e1211207444254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211207444254 : Closed e1211207444254 ∧ code e1211207444254 = 5609253955358 := by decide
theorem cert_e1211207444254 : check e1211207444254 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207444278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207444278 : Closed e1211207444278 ∧ code e1211207444278 = 5609253955382 := by decide
theorem cert_e1211207444278 : check e1211207444278 [[],[]] .chain = true := by decide
def e1211207444282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207444282 : Closed e1211207444282 ∧ code e1211207444282 = 5609253955386 := by decide
theorem cert_e1211207444282 : check e1211207444282 [[],[]] .chain = true := by decide
def e1211207444366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211207444366 : Closed e1211207444366 ∧ code e1211207444366 = 5609253955470 := by decide
theorem cert_e1211207444366 : check e1211207444366 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207451118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211207451118 : Closed e1211207451118 ∧ code e1211207451118 = 5609253962222 := by decide
theorem cert_e1211207451118 : check e1211207451118 [[],[]] .chain = true := by decide
def e1211207451130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211207451130 : Closed e1211207451130 ∧ code e1211207451130 = 5609253962234 := by decide
theorem cert_e1211207451130 : check e1211207451130 [[],[]] .chain = true := by decide
end Blc.Floor42
