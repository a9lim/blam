import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196282727262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1196282727262 : Closed e1196282727262 ∧ code e1196282727262 = 5594329238366 := by decide
theorem cert_e1196282727262 : check e1196282727262 [[],[.left]] .chain = true := by decide
def e1196282727278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196282727278 : Closed e1196282727278 ∧ code e1196282727278 = 5594329238382 := by decide
theorem cert_e1196282727278 : check e1196282727278 [[],[.left]] .smaller = true := by decide
def e1196282727286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196282727286 : Closed e1196282727286 ∧ code e1196282727286 = 5594329238390 := by decide
theorem cert_e1196282727286 : check e1196282727286 [[],[.left]] .smaller = true := by decide
def e1196282727290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1196282727290 : Closed e1196282727290 ∧ code e1196282727290 = 5594329238394 := by decide
theorem cert_e1196282727290 : check e1196282727290 [[],[.left]] .chain = true := by decide
def e1196282727342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196282727342 : Closed e1196282727342 ∧ code e1196282727342 = 5594329238446 := by decide
theorem cert_e1196282727342 : check e1196282727342 [[],[.left]] .smaller = true := by decide
def e1196282727354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196282727354 : Closed e1196282727354 ∧ code e1196282727354 = 5594329238458 := by decide
theorem cert_e1196282727354 : check e1196282727354 [[],[.left]] .smaller = true := by decide
def e1196282727382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196282727382 : Closed e1196282727382 ∧ code e1196282727382 = 5594329238486 := by decide
theorem cert_e1196282727382 : check e1196282727382 [[],[.left]] .smaller = true := by decide
def e1196282727386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196282727386 : Closed e1196282727386 ∧ code e1196282727386 = 5594329238490 := by decide
theorem cert_e1196282727386 : check e1196282727386 [[],[.left]] .smaller = true := by decide
def e1196282727402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1196282727402 : Closed e1196282727402 ∧ code e1196282727402 = 5594329238506 := by decide
theorem cert_e1196282727402 : check e1196282727402 [[],[.left]] .chain = true := by decide
def e1196282727646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196282727646 : Closed e1196282727646 ∧ code e1196282727646 = 5594329238750 := by decide
theorem cert_e1196282727646 : check e1196282727646 [[],[.left]] .chain = true := by decide
def e1196282727662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196282727662 : Closed e1196282727662 ∧ code e1196282727662 = 5594329238766 := by decide
theorem cert_e1196282727662 : check e1196282727662 [[],[.left]] .smaller = true := by decide
def e1196282727670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196282727670 : Closed e1196282727670 ∧ code e1196282727670 = 5594329238774 := by decide
theorem cert_e1196282727670 : check e1196282727670 [[],[.left]] .smaller = true := by decide
def e1196282727674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196282727674 : Closed e1196282727674 ∧ code e1196282727674 = 5594329238778 := by decide
theorem cert_e1196282727674 : check e1196282727674 [[],[.left]] .chain = true := by decide
def e1196282728046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196282728046 : Closed e1196282728046 ∧ code e1196282728046 = 5594329239150 := by decide
theorem cert_e1196282728046 : check e1196282728046 [[],[.left]] .smaller = true := by decide
def e1196282728058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196282728058 : Closed e1196282728058 ∧ code e1196282728058 = 5594329239162 := by decide
theorem cert_e1196282728058 : check e1196282728058 [[],[.left]] .smaller = true := by decide
def e1196282728246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196282728246 : Closed e1196282728246 ∧ code e1196282728246 = 5594329239350 := by decide
theorem cert_e1196282728246 : check e1196282728246 [[],[.left]] .smaller = true := by decide
def e1196282728250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196282728250 : Closed e1196282728250 ∧ code e1196282728250 = 5594329239354 := by decide
theorem cert_e1196282728250 : check e1196282728250 [[],[.left]] .smaller = true := by decide
def e1196282728346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196282728346 : Closed e1196282728346 ∧ code e1196282728346 = 5594329239450 := by decide
theorem cert_e1196282728346 : check e1196282728346 [[],[.left]] .chain = true := by decide
def e1196282734006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1196282734006 : Closed e1196282734006 ∧ code e1196282734006 = 5594329245110 := by decide
theorem cert_e1196282734006 : check e1196282734006 [[],[.left]] .smaller = true := by decide
def e1196282734038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1196282734038 : Closed e1196282734038 ∧ code e1196282734038 = 5594329245142 := by decide
theorem cert_e1196282734038 : check e1196282734038 [[],[.left]] .smaller = true := by decide
def e1196282734042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1196282734042 : Closed e1196282734042 ∧ code e1196282734042 = 5594329245146 := by decide
theorem cert_e1196282734042 : check e1196282734042 [[],[.left]] .smaller = true := by decide
def e1196282734198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196282734198 : Closed e1196282734198 ∧ code e1196282734198 = 5594329245302 := by decide
theorem cert_e1196282734198 : check e1196282734198 [[],[.left]] .smaller = true := by decide
def e1196282734390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196282734390 : Closed e1196282734390 ∧ code e1196282734390 = 5594329245494 := by decide
theorem cert_e1196282734390 : check e1196282734390 [[],[.left]] .smaller = true := by decide
def e1196282734394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196282734394 : Closed e1196282734394 ∧ code e1196282734394 = 5594329245498 := by decide
theorem cert_e1196282734394 : check e1196282734394 [[],[.left]] .smaller = true := by decide
def e1196282737366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1196282737366 : Closed e1196282737366 ∧ code e1196282737366 = 5594329248470 := by decide
theorem cert_e1196282737366 : check e1196282737366 [[],[.left]] .chain = true := by decide
def e1196282737370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1196282737370 : Closed e1196282737370 ∧ code e1196282737370 = 5594329248474 := by decide
theorem cert_e1196282737370 : check e1196282737370 [[],[.left]] .chain = true := by decide
def e1196282737386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1196282737386 : Closed e1196282737386 ∧ code e1196282737386 = 5594329248490 := by decide
theorem cert_e1196282737386 : check e1196282737386 [[],[.left]] .chain = true := by decide
def e1196282737462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196282737462 : Closed e1196282737462 ∧ code e1196282737462 = 5594329248566 := by decide
theorem cert_e1196282737462 : check e1196282737462 [[],[.left]] .chain = true := by decide
def e1196282737466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196282737466 : Closed e1196282737466 ∧ code e1196282737466 = 5594329248570 := by decide
theorem cert_e1196282737466 : check e1196282737466 [[],[.left]] .chain = true := by decide
def e1196282737562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1196282737562 : Closed e1196282737562 ∧ code e1196282737562 = 5594329248666 := by decide
theorem cert_e1196282737562 : check e1196282737562 [[],[.left]] .chain = true := by decide
def e1196282962798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1196282962798 : Closed e1196282962798 ∧ code e1196282962798 = 5594329473902 := by decide
theorem cert_e1196282962798 : check e1196282962798 [[],[.left]] .chain = true := by decide
def e1196282962806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1196282962806 : Closed e1196282962806 ∧ code e1196282962806 = 5594329473910 := by decide
theorem cert_e1196282962806 : check e1196282962806 [[],[.left]] .chain = true := by decide
def e1196282962862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1196282962862 : Closed e1196282962862 ∧ code e1196282962862 = 5594329473966 := by decide
theorem cert_e1196282962862 : check e1196282962862 [[],[.left]] .chain = true := by decide
def e1196282962874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1196282962874 : Closed e1196282962874 ∧ code e1196282962874 = 5594329473978 := by decide
theorem cert_e1196282962874 : check e1196282962874 [[],[.left]] .chain = true := by decide
def e1196282962902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1196282962902 : Closed e1196282962902 ∧ code e1196282962902 = 5594329474006 := by decide
theorem cert_e1196282962902 : check e1196282962902 [[],[.left]] .chain = true := by decide
def e1196282962906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1196282962906 : Closed e1196282962906 ∧ code e1196282962906 = 5594329474010 := by decide
theorem cert_e1196282962906 : check e1196282962906 [[],[.left]] .chain = true := by decide
def e1196282964206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1196282964206 : Closed e1196282964206 ∧ code e1196282964206 = 5594329475310 := by decide
theorem cert_e1196282964206 : check e1196282964206 [[],[.left]] .chain = true := by decide
def e1196282964214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1196282964214 : Closed e1196282964214 ∧ code e1196282964214 = 5594329475318 := by decide
theorem cert_e1196282964214 : check e1196282964214 [[],[.left]] .chain = true := by decide
def e1196282964766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1196282964766 : Closed e1196282964766 ∧ code e1196282964766 = 5594329475870 := by decide
theorem cert_e1196282964766 : check e1196282964766 [[],[.left]] .chain = true := by decide
def e1196282964878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1196282964878 : Closed e1196282964878 ∧ code e1196282964878 = 5594329475982 := by decide
theorem cert_e1196282964878 : check e1196282964878 [[],[.left]] .chain = true := by decide
def e1196282965102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1196282965102 : Closed e1196282965102 ∧ code e1196282965102 = 5594329476206 := by decide
theorem cert_e1196282965102 : check e1196282965102 [[],[.left]] .chain = true := by decide
def e1196282965114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1196282965114 : Closed e1196282965114 ∧ code e1196282965114 = 5594329476218 := by decide
theorem cert_e1196282965114 : check e1196282965114 [[],[.left]] .chain = true := by decide
def e1196282965278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1196282965278 : Closed e1196282965278 ∧ code e1196282965278 = 5594329476382 := by decide
theorem cert_e1196282965278 : check e1196282965278 [[],[.left]] .chain = true := by decide
def e1196282965446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1196282965446 : Closed e1196282965446 ∧ code e1196282965446 = 5594329476550 := by decide
theorem cert_e1196282965446 : check e1196282965446 [[],[.left]] .chain = true := by decide
def e1196282965558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1196282965558 : Closed e1196282965558 ∧ code e1196282965558 = 5594329476662 := by decide
theorem cert_e1196282965558 : check e1196282965558 [[],[.left]] .chain = true := by decide
def e1196282965562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1196282965562 : Closed e1196282965562 ∧ code e1196282965562 = 5594329476666 := by decide
theorem cert_e1196282965562 : check e1196282965562 [[],[.left]] .chain = true := by decide
def e1196282965646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1196282965646 : Closed e1196282965646 ∧ code e1196282965646 = 5594329476750 := by decide
theorem cert_e1196282965646 : check e1196282965646 [[],[.left]] .chain = true := by decide
def e1196282965702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1196282965702 : Closed e1196282965702 ∧ code e1196282965702 = 5594329476806 := by decide
theorem cert_e1196282965702 : check e1196282965702 [[],[.left]] .chain = true := by decide
def e1196282966446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1196282966446 : Closed e1196282966446 ∧ code e1196282966446 = 5594329477550 := by decide
theorem cert_e1196282966446 : check e1196282966446 [[],[.left]] .chain = true := by decide
def e1196282966458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1196282966458 : Closed e1196282966458 ∧ code e1196282966458 = 5594329477562 := by decide
theorem cert_e1196282966458 : check e1196282966458 [[],[.left]] .chain = true := by decide
def e1196282966506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1196282966506 : Closed e1196282966506 ∧ code e1196282966506 = 5594329477610 := by decide
theorem cert_e1196282966506 : check e1196282966506 [[],[.left]] .chain = true := by decide
def e1196282967150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1196282967150 : Closed e1196282967150 ∧ code e1196282967150 = 5594329478254 := by decide
theorem cert_e1196282967150 : check e1196282967150 [[],[.left]] .chain = true := by decide
def e1196282967162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1196282967162 : Closed e1196282967162 ∧ code e1196282967162 = 5594329478266 := by decide
theorem cert_e1196282967162 : check e1196282967162 [[],[.left]] .chain = true := by decide
def e1196282967326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1196282967326 : Closed e1196282967326 ∧ code e1196282967326 = 5594329478430 := by decide
theorem cert_e1196282967326 : check e1196282967326 [[],[.left]] .chain = true := by decide
def e1196282967494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1196282967494 : Closed e1196282967494 ∧ code e1196282967494 = 5594329478598 := by decide
theorem cert_e1196282967494 : check e1196282967494 [[],[.left]] .chain = true := by decide
def e1196282967834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1196282967834 : Closed e1196282967834 ∧ code e1196282967834 = 5594329478938 := by decide
theorem cert_e1196282967834 : check e1196282967834 [[],[.left]] .chain = true := by decide
def e1196282967878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1196282967878 : Closed e1196282967878 ∧ code e1196282967878 = 5594329478982 := by decide
theorem cert_e1196282967878 : check e1196282967878 [[],[.left]] .chain = true := by decide
def e1196282968278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1196282968278 : Closed e1196282968278 ∧ code e1196282968278 = 5594329479382 := by decide
theorem cert_e1196282968278 : check e1196282968278 [[],[.left]] .chain = true := by decide
def e1196282968282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1196282968282 : Closed e1196282968282 ∧ code e1196282968282 = 5594329479386 := by decide
theorem cert_e1196282968282 : check e1196282968282 [[],[.left]] .chain = true := by decide
def e1196282968298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1196282968298 : Closed e1196282968298 ∧ code e1196282968298 = 5594329479402 := by decide
theorem cert_e1196282968298 : check e1196282968298 [[],[.left]] .chain = true := by decide
def e1196282968630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1196282968630 : Closed e1196282968630 ∧ code e1196282968630 = 5594329479734 := by decide
theorem cert_e1196282968630 : check e1196282968630 [[],[.left]] .chain = true := by decide
def e1196282968634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1196282968634 : Closed e1196282968634 ∧ code e1196282968634 = 5594329479738 := by decide
theorem cert_e1196282968634 : check e1196282968634 [[],[.left]] .chain = true := by decide
def e1196282968718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1196282968718 : Closed e1196282968718 ∧ code e1196282968718 = 5594329479822 := by decide
theorem cert_e1196282968718 : check e1196282968718 [[],[.left]] .chain = true := by decide
def e1196282968774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1196282968774 : Closed e1196282968774 ∧ code e1196282968774 = 5594329479878 := by decide
theorem cert_e1196282968774 : check e1196282968774 [[],[.left]] .chain = true := by decide
def e1196282968858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1196282968858 : Closed e1196282968858 ∧ code e1196282968858 = 5594329479962 := by decide
theorem cert_e1196282968858 : check e1196282968858 [[],[.left]] .chain = true := by decide
def e1196282968902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1196282968902 : Closed e1196282968902 ∧ code e1196282968902 = 5594329480006 := by decide
theorem cert_e1196282968902 : check e1196282968902 [[],[.left]] .chain = true := by decide
def e1196282973422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196282973422 : Closed e1196282973422 ∧ code e1196282973422 = 5594329484526 := by decide
theorem cert_e1196282973422 : check e1196282973422 [[],[.left]] .chain = true := by decide
def e1196282973430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196282973430 : Closed e1196282973430 ∧ code e1196282973430 = 5594329484534 := by decide
theorem cert_e1196282973430 : check e1196282973430 [[],[.left]] .chain = true := by decide
def e1196282973806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196282973806 : Closed e1196282973806 ∧ code e1196282973806 = 5594329484910 := by decide
theorem cert_e1196282973806 : check e1196282973806 [[],[.left]] .chain = true := by decide
def e1196282973818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196282973818 : Closed e1196282973818 ∧ code e1196282973818 = 5594329484922 := by decide
theorem cert_e1196282973818 : check e1196282973818 [[],[.left]] .chain = true := by decide
def e1196282974006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196282974006 : Closed e1196282974006 ∧ code e1196282974006 = 5594329485110 := by decide
theorem cert_e1196282974006 : check e1196282974006 [[],[.left]] .chain = true := by decide
def e1196282974010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196282974010 : Closed e1196282974010 ∧ code e1196282974010 = 5594329485114 := by decide
theorem cert_e1196282974010 : check e1196282974010 [[],[.left]] .chain = true := by decide
def e1196282976494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1196282976494 : Closed e1196282976494 ∧ code e1196282976494 = 5594329487598 := by decide
theorem cert_e1196282976494 : check e1196282976494 [[],[.left]] .chain = true := by decide
def e1196282976502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1196282976502 : Closed e1196282976502 ∧ code e1196282976502 = 5594329487606 := by decide
theorem cert_e1196282976502 : check e1196282976502 [[],[.left]] .chain = true := by decide
def e1196282977054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1196282977054 : Closed e1196282977054 ∧ code e1196282977054 = 5594329488158 := by decide
theorem cert_e1196282977054 : check e1196282977054 [[],[.left]] .chain = true := by decide
def e1196282977166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1196282977166 : Closed e1196282977166 ∧ code e1196282977166 = 5594329488270 := by decide
theorem cert_e1196282977166 : check e1196282977166 [[],[.left]] .chain = true := by decide
def e1196282977390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1196282977390 : Closed e1196282977390 ∧ code e1196282977390 = 5594329488494 := by decide
theorem cert_e1196282977390 : check e1196282977390 [[],[.left]] .chain = true := by decide
def e1196282977402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1196282977402 : Closed e1196282977402 ∧ code e1196282977402 = 5594329488506 := by decide
theorem cert_e1196282977402 : check e1196282977402 [[],[.left]] .chain = true := by decide
def e1196282977566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1196282977566 : Closed e1196282977566 ∧ code e1196282977566 = 5594329488670 := by decide
theorem cert_e1196282977566 : check e1196282977566 [[],[.left]] .chain = true := by decide
def e1196282977734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1196282977734 : Closed e1196282977734 ∧ code e1196282977734 = 5594329488838 := by decide
theorem cert_e1196282977734 : check e1196282977734 [[],[.left]] .chain = true := by decide
def e1196282977846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1196282977846 : Closed e1196282977846 ∧ code e1196282977846 = 5594329488950 := by decide
theorem cert_e1196282977846 : check e1196282977846 [[],[.left]] .chain = true := by decide
def e1196282977850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1196282977850 : Closed e1196282977850 ∧ code e1196282977850 = 5594329488954 := by decide
theorem cert_e1196282977850 : check e1196282977850 [[],[.left]] .chain = true := by decide
def e1196282977934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1196282977934 : Closed e1196282977934 ∧ code e1196282977934 = 5594329489038 := by decide
theorem cert_e1196282977934 : check e1196282977934 [[],[.left]] .chain = true := by decide
def e1196282977990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1196282977990 : Closed e1196282977990 ∧ code e1196282977990 = 5594329489094 := by decide
theorem cert_e1196282977990 : check e1196282977990 [[],[.left]] .chain = true := by decide
def e1196282980126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1196282980126 : Closed e1196282980126 ∧ code e1196282980126 = 5594329491230 := by decide
theorem cert_e1196282980126 : check e1196282980126 [[],[.left]] .chain = true := by decide
def e1196282980238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1196282980238 : Closed e1196282980238 ∧ code e1196282980238 = 5594329491342 := by decide
theorem cert_e1196282980238 : check e1196282980238 [[],[.left]] .chain = true := by decide
def e1196282983198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1196282983198 : Closed e1196282983198 ∧ code e1196282983198 = 5594329494302 := by decide
theorem cert_e1196282983198 : check e1196282983198 [[],[.left]] .chain = true := by decide
def e1196282983366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1196282983366 : Closed e1196282983366 ∧ code e1196282983366 = 5594329494470 := by decide
theorem cert_e1196282983366 : check e1196282983366 [[],[.left]] .chain = true := by decide
def e1196282984846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1196282984846 : Closed e1196282984846 ∧ code e1196282984846 = 5594329495950 := by decide
theorem cert_e1196282984846 : check e1196282984846 [[],[.left]] .chain = true := by decide
def e1196282984902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1196282984902 : Closed e1196282984902 ∧ code e1196282984902 = 5594329496006 := by decide
theorem cert_e1196282984902 : check e1196282984902 [[],[.left]] .chain = true := by decide
def e1196282988142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196282988142 : Closed e1196282988142 ∧ code e1196282988142 = 5594329499246 := by decide
theorem cert_e1196282988142 : check e1196282988142 [[],[.left]] .chain = true := by decide
def e1196282988154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196282988154 : Closed e1196282988154 ∧ code e1196282988154 = 5594329499258 := by decide
theorem cert_e1196282988154 : check e1196282988154 [[],[.left]] .chain = true := by decide
def e1196282988442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1196282988442 : Closed e1196282988442 ∧ code e1196282988442 = 5594329499546 := by decide
theorem cert_e1196282988442 : check e1196282988442 [[],[.left]] .chain = true := by decide
def e1196282989678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1196282989678 : Closed e1196282989678 ∧ code e1196282989678 = 5594329500782 := by decide
theorem cert_e1196282989678 : check e1196282989678 [[],[.left]] .chain = true := by decide
def e1196282989690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1196282989690 : Closed e1196282989690 ∧ code e1196282989690 = 5594329500794 := by decide
theorem cert_e1196282989690 : check e1196282989690 [[],[.left]] .chain = true := by decide
def e1196282989854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1196282989854 : Closed e1196282989854 ∧ code e1196282989854 = 5594329500958 := by decide
theorem cert_e1196282989854 : check e1196282989854 [[],[.left]] .chain = true := by decide
def e1196282990022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1196282990022 : Closed e1196282990022 ∧ code e1196282990022 = 5594329501126 := by decide
theorem cert_e1196282990022 : check e1196282990022 [[],[.left]] .chain = true := by decide
def e1196282990362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1196282990362 : Closed e1196282990362 ∧ code e1196282990362 = 5594329501466 := by decide
theorem cert_e1196282990362 : check e1196282990362 [[],[.left]] .chain = true := by decide
def e1196282990406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1196282990406 : Closed e1196282990406 ∧ code e1196282990406 = 5594329501510 := by decide
theorem cert_e1196282990406 : check e1196282990406 [[],[.left]] .chain = true := by decide
def e1196282991390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1196282991390 : Closed e1196282991390 ∧ code e1196282991390 = 5594329502494 := by decide
theorem cert_e1196282991390 : check e1196282991390 [[],[.left]] .chain = true := by decide
def e1196282991558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1196282991558 : Closed e1196282991558 ∧ code e1196282991558 = 5594329502662 := by decide
theorem cert_e1196282991558 : check e1196282991558 [[],[.left]] .chain = true := by decide
def e1196282993862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1196282993862 : Closed e1196282993862 ∧ code e1196282993862 = 5594329504966 := by decide
theorem cert_e1196282993862 : check e1196282993862 [[],[.left]] .chain = true := by decide
def e1196282995510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196282995510 : Closed e1196282995510 ∧ code e1196282995510 = 5594329506614 := by decide
theorem cert_e1196282995510 : check e1196282995510 [[],[.left]] .chain = true := by decide
def e1196282995514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196282995514 : Closed e1196282995514 ∧ code e1196282995514 = 5594329506618 := by decide
theorem cert_e1196282995514 : check e1196282995514 [[],[.left]] .chain = true := by decide
def e1196282995610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1196282995610 : Closed e1196282995610 ∧ code e1196282995610 = 5594329506714 := by decide
theorem cert_e1196282995610 : check e1196282995610 [[],[.left]] .chain = true := by decide
def e1196282996278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1196282996278 : Closed e1196282996278 ∧ code e1196282996278 = 5594329507382 := by decide
theorem cert_e1196282996278 : check e1196282996278 [[],[.left]] .chain = true := by decide
def e1196282996282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1196282996282 : Closed e1196282996282 ∧ code e1196282996282 = 5594329507386 := by decide
theorem cert_e1196282996282 : check e1196282996282 [[],[.left]] .chain = true := by decide
def e1196282996366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1196282996366 : Closed e1196282996366 ∧ code e1196282996366 = 5594329507470 := by decide
theorem cert_e1196282996366 : check e1196282996366 [[],[.left]] .chain = true := by decide
def e1196282996422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1196282996422 : Closed e1196282996422 ∧ code e1196282996422 = 5594329507526 := by decide
theorem cert_e1196282996422 : check e1196282996422 [[],[.left]] .chain = true := by decide
def e1196282996506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1196282996506 : Closed e1196282996506 ∧ code e1196282996506 = 5594329507610 := by decide
theorem cert_e1196282996506 : check e1196282996506 [[],[.left]] .chain = true := by decide
def e1196282996550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1196282996550 : Closed e1196282996550 ∧ code e1196282996550 = 5594329507654 := by decide
theorem cert_e1196282996550 : check e1196282996550 [[],[.left]] .chain = true := by decide
def e1196282997134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1196282997134 : Closed e1196282997134 ∧ code e1196282997134 = 5594329508238 := by decide
theorem cert_e1196282997134 : check e1196282997134 [[],[.left]] .chain = true := by decide
def e1196282997190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1196282997190 : Closed e1196282997190 ∧ code e1196282997190 = 5594329508294 := by decide
theorem cert_e1196282997190 : check e1196282997190 [[],[.left]] .chain = true := by decide
def e1196282997958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1196282997958 : Closed e1196282997958 ∧ code e1196282997958 = 5594329509062 := by decide
theorem cert_e1196282997958 : check e1196282997958 [[],[.left]] .chain = true := by decide
def e1196283008734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1196283008734 : Closed e1196283008734 ∧ code e1196283008734 = 5594329519838 := by decide
theorem cert_e1196283008734 : check e1196283008734 [[],[.left]] .chain = true := by decide
def e1196283008758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1196283008758 : Closed e1196283008758 ∧ code e1196283008758 = 5594329519862 := by decide
theorem cert_e1196283008758 : check e1196283008758 [[],[.left]] .chain = true := by decide
def e1196283008862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1196283008862 : Closed e1196283008862 ∧ code e1196283008862 = 5594329519966 := by decide
theorem cert_e1196283008862 : check e1196283008862 [[],[.left]] .chain = true := by decide
def e1196283008890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1196283008890 : Closed e1196283008890 ∧ code e1196283008890 = 5594329519994 := by decide
theorem cert_e1196283008890 : check e1196283008890 [[],[.left]] .chain = true := by decide
def e1196283008982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1196283008982 : Closed e1196283008982 ∧ code e1196283008982 = 5594329520086 := by decide
theorem cert_e1196283008982 : check e1196283008982 [[],[.left]] .chain = true := by decide
def e1196283008986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1196283008986 : Closed e1196283008986 ∧ code e1196283008986 = 5594329520090 := by decide
theorem cert_e1196283008986 : check e1196283008986 [[],[.left]] .chain = true := by decide
def e1196283009502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196283009502 : Closed e1196283009502 ∧ code e1196283009502 = 5594329520606 := by decide
theorem cert_e1196283009502 : check e1196283009502 [[],[.left]] .chain = true := by decide
def e1196283009526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196283009526 : Closed e1196283009526 ∧ code e1196283009526 = 5594329520630 := by decide
theorem cert_e1196283009526 : check e1196283009526 [[],[.left]] .chain = true := by decide
def e1196283010270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196283010270 : Closed e1196283010270 ∧ code e1196283010270 = 5594329521374 := by decide
theorem cert_e1196283010270 : check e1196283010270 [[],[.left]] .chain = true := by decide
def e1196283010298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196283010298 : Closed e1196283010298 ∧ code e1196283010298 = 5594329521402 := by decide
theorem cert_e1196283010298 : check e1196283010298 [[],[.left]] .chain = true := by decide
def e1196283010870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196283010870 : Closed e1196283010870 ∧ code e1196283010870 = 5594329521974 := by decide
theorem cert_e1196283010870 : check e1196283010870 [[],[.left]] .chain = true := by decide
def e1196283010874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196283010874 : Closed e1196283010874 ∧ code e1196283010874 = 5594329521978 := by decide
theorem cert_e1196283010874 : check e1196283010874 [[],[.left]] .chain = true := by decide
def e1196283025646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1196283025646 : Closed e1196283025646 ∧ code e1196283025646 = 5594329536750 := by decide
theorem cert_e1196283025646 : check e1196283025646 [[],[.left]] .chain = true := by decide
def e1196283025654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1196283025654 : Closed e1196283025654 ∧ code e1196283025654 = 5594329536758 := by decide
theorem cert_e1196283025654 : check e1196283025654 [[],[.left]] .chain = true := by decide
def e1196283026206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1196283026206 : Closed e1196283026206 ∧ code e1196283026206 = 5594329537310 := by decide
theorem cert_e1196283026206 : check e1196283026206 [[],[.left]] .chain = true := by decide
def e1196283026318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1196283026318 : Closed e1196283026318 ∧ code e1196283026318 = 5594329537422 := by decide
theorem cert_e1196283026318 : check e1196283026318 [[],[.left]] .chain = true := by decide
def e1196283026542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196283026542 : Closed e1196283026542 ∧ code e1196283026542 = 5594329537646 := by decide
theorem cert_e1196283026542 : check e1196283026542 [[],[.left]] .chain = true := by decide
def e1196283026554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196283026554 : Closed e1196283026554 ∧ code e1196283026554 = 5594329537658 := by decide
theorem cert_e1196283026554 : check e1196283026554 [[],[.left]] .chain = true := by decide
def e1196283026718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196283026718 : Closed e1196283026718 ∧ code e1196283026718 = 5594329537822 := by decide
theorem cert_e1196283026718 : check e1196283026718 [[],[.left]] .chain = true := by decide
def e1196283026886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196283026886 : Closed e1196283026886 ∧ code e1196283026886 = 5594329537990 := by decide
theorem cert_e1196283026886 : check e1196283026886 [[],[.left]] .chain = true := by decide
def e1196283026998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1196283026998 : Closed e1196283026998 ∧ code e1196283026998 = 5594329538102 := by decide
theorem cert_e1196283026998 : check e1196283026998 [[],[.left]] .chain = true := by decide
def e1196283027002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1196283027002 : Closed e1196283027002 ∧ code e1196283027002 = 5594329538106 := by decide
theorem cert_e1196283027002 : check e1196283027002 [[],[.left]] .chain = true := by decide
def e1196283027086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1196283027086 : Closed e1196283027086 ∧ code e1196283027086 = 5594329538190 := by decide
theorem cert_e1196283027086 : check e1196283027086 [[],[.left]] .chain = true := by decide
def e1196283027142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1196283027142 : Closed e1196283027142 ∧ code e1196283027142 = 5594329538246 := by decide
theorem cert_e1196283027142 : check e1196283027142 [[],[.left]] .chain = true := by decide
def e1196283029278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1196283029278 : Closed e1196283029278 ∧ code e1196283029278 = 5594329540382 := by decide
theorem cert_e1196283029278 : check e1196283029278 [[],[.left]] .chain = true := by decide
def e1196283029390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1196283029390 : Closed e1196283029390 ∧ code e1196283029390 = 5594329540494 := by decide
theorem cert_e1196283029390 : check e1196283029390 [[],[.left]] .chain = true := by decide
def e1196283032350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1196283032350 : Closed e1196283032350 ∧ code e1196283032350 = 5594329543454 := by decide
theorem cert_e1196283032350 : check e1196283032350 [[],[.left]] .chain = true := by decide
def e1196283032518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1196283032518 : Closed e1196283032518 ∧ code e1196283032518 = 5594329543622 := by decide
theorem cert_e1196283032518 : check e1196283032518 [[],[.left]] .chain = true := by decide
def e1196283033998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1196283033998 : Closed e1196283033998 ∧ code e1196283033998 = 5594329545102 := by decide
theorem cert_e1196283033998 : check e1196283033998 [[],[.left]] .chain = true := by decide
def e1196283034054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196283034054 : Closed e1196283034054 ∧ code e1196283034054 = 5594329545158 := by decide
theorem cert_e1196283034054 : check e1196283034054 [[],[.left]] .chain = true := by decide
def e1196283071342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196283071342 : Closed e1196283071342 ∧ code e1196283071342 = 5594329582446 := by decide
theorem cert_e1196283071342 : check e1196283071342 [[],[.left]] .smaller = true := by decide
def e1196283071350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196283071350 : Closed e1196283071350 ∧ code e1196283071350 = 5594329582454 := by decide
theorem cert_e1196283071350 : check e1196283071350 [[],[.left]] .smaller = true := by decide
def e1196283071406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196283071406 : Closed e1196283071406 ∧ code e1196283071406 = 5594329582510 := by decide
theorem cert_e1196283071406 : check e1196283071406 [[],[.left]] .smaller = true := by decide
def e1196283071418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196283071418 : Closed e1196283071418 ∧ code e1196283071418 = 5594329582522 := by decide
theorem cert_e1196283071418 : check e1196283071418 [[],[.left]] .smaller = true := by decide
def e1196283071446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196283071446 : Closed e1196283071446 ∧ code e1196283071446 = 5594329582550 := by decide
theorem cert_e1196283071446 : check e1196283071446 [[],[.left]] .smaller = true := by decide
def e1196283071450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196283071450 : Closed e1196283071450 ∧ code e1196283071450 = 5594329582554 := by decide
theorem cert_e1196283071450 : check e1196283071450 [[],[.left]] .smaller = true := by decide
def e1196283071726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196283071726 : Closed e1196283071726 ∧ code e1196283071726 = 5594329582830 := by decide
theorem cert_e1196283071726 : check e1196283071726 [[],[.left]] .smaller = true := by decide
def e1196283071734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196283071734 : Closed e1196283071734 ∧ code e1196283071734 = 5594329582838 := by decide
theorem cert_e1196283071734 : check e1196283071734 [[],[.left]] .smaller = true := by decide
def e1196283072110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196283072110 : Closed e1196283072110 ∧ code e1196283072110 = 5594329583214 := by decide
theorem cert_e1196283072110 : check e1196283072110 [[],[.left]] .smaller = true := by decide
def e1196283072122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196283072122 : Closed e1196283072122 ∧ code e1196283072122 = 5594329583226 := by decide
theorem cert_e1196283072122 : check e1196283072122 [[],[.left]] .smaller = true := by decide
def e1196283072310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196283072310 : Closed e1196283072310 ∧ code e1196283072310 = 5594329583414 := by decide
theorem cert_e1196283072310 : check e1196283072310 [[],[.left]] .smaller = true := by decide
def e1196283072314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196283072314 : Closed e1196283072314 ∧ code e1196283072314 = 5594329583418 := by decide
theorem cert_e1196283072314 : check e1196283072314 [[],[.left]] .smaller = true := by decide
def e1196283079790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1196283079790 : Closed e1196283079790 ∧ code e1196283079790 = 5594329590894 := by decide
theorem cert_e1196283079790 : check e1196283079790 [[],[.left]] .chain = true := by decide
def e1196283079802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1196283079802 : Closed e1196283079802 ∧ code e1196283079802 = 5594329590906 := by decide
theorem cert_e1196283079802 : check e1196283079802 [[],[.left]] .chain = true := by decide
def e1196283079966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1196283079966 : Closed e1196283079966 ∧ code e1196283079966 = 5594329591070 := by decide
theorem cert_e1196283079966 : check e1196283079966 [[],[.left]] .chain = true := by decide
def e1196283080134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1196283080134 : Closed e1196283080134 ∧ code e1196283080134 = 5594329591238 := by decide
theorem cert_e1196283080134 : check e1196283080134 [[],[.left]] .chain = true := by decide
end Blc.Floor42
