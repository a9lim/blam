import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299910303342 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299910303342 : Closed e299910303342 ∧ code e299910303342 = 4697956814446 := by decide
theorem cert_e299910303342 : check e299910303342 [[.under]] .sourceHead = true := by decide
def e299910303354 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299910303354 : Closed e299910303354 ∧ code e299910303354 = 4697956814458 := by decide
theorem cert_e299910303354 : check e299910303354 [[.under]] .sourceHead = true := by decide
def e299910303542 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299910303542 : Closed e299910303542 ∧ code e299910303542 = 4697956814646 := by decide
theorem cert_e299910303542 : check e299910303542 [[.under]] .sourceHead = true := by decide
def e299910303546 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299910303546 : Closed e299910303546 ∧ code e299910303546 = 4697956814650 := by decide
theorem cert_e299910303546 : check e299910303546 [[.under]] .sourceHead = true := by decide
def e300671690266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300671690266 : Closed e300671690266 ∧ code e300671690266 = 4698718201370 := by decide
theorem cert_e300671690266 : check e300671690266 [[.under]] .width = true := by decide
def e300671788570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300671788570 : Closed e300671788570 ∧ code e300671788570 = 4698718299674 := by decide
theorem cert_e300671788570 : check e300671788570 [[.under]] .width = true := by decide
def e300672214554 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672214554 : Closed e300672214554 ∧ code e300672214554 = 4698718725658 := by decide
theorem cert_e300672214554 : check e300672214554 [[.under]] .width = true := by decide
def e300672329242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672329242 : Closed e300672329242 ∧ code e300672329242 = 4698718840346 := by decide
theorem cert_e300672329242 : check e300672329242 [[.under]] .width = true := by decide
def e300672706074 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672706074 : Closed e300672706074 ∧ code e300672706074 = 4698719217178 := by decide
theorem cert_e300672706074 : check e300672706074 [[.under]] .width = true := by decide
def e300672722458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672722458 : Closed e300672722458 ∧ code e300672722458 = 4698719233562 := by decide
theorem cert_e300672722458 : check e300672722458 [[.under]] .width = true := by decide
def e300674835994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300674835994 : Closed e300674835994 ∧ code e300674835994 = 4698721347098 := by decide
theorem cert_e300674835994 : check e300674835994 [[.under]] .width = true := by decide
def e300674934298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300674934298 : Closed e300674934298 ∧ code e300674934298 = 4698721445402 := by decide
theorem cert_e300674934298 : check e300674934298 [[.under]] .width = true := by decide
def e300677981722 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300677981722 : Closed e300677981722 ∧ code e300677981722 = 4698724492826 := by decide
theorem cert_e300677981722 : check e300677981722 [[.under]] .width = true := by decide
def e300678096410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300678096410 : Closed e300678096410 ∧ code e300678096410 = 4698724607514 := by decide
theorem cert_e300678096410 : check e300678096410 [[.under]] .width = true := by decide
def e300680439322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300680439322 : Closed e300680439322 ∧ code e300680439322 = 4698726950426 := by decide
theorem cert_e300680439322 : check e300680439322 [[.under]] .width = true := by decide
def e300680455706 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300680455706 : Closed e300680455706 ∧ code e300680455706 = 4698726966810 := by decide
theorem cert_e300680455706 : check e300680455706 [[.under]] .width = true := by decide
def e300740961818 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300740961818 : Closed e300740961818 ∧ code e300740961818 = 4698787472922 := by decide
theorem cert_e300740961818 : check e300740961818 [[.under]] .width = true := by decide
def e300740994586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300740994586 : Closed e300740994586 ∧ code e300740994586 = 4698787505690 := by decide
theorem cert_e300740994586 : check e300740994586 [[.under]] .width = true := by decide
def e300743255578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300743255578 : Closed e300743255578 ∧ code e300743255578 = 4698789766682 := by decide
theorem cert_e300743255578 : check e300743255578 [[.under]] .width = true := by decide
def e300743593498 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300743593498 : Closed e300743593498 ∧ code e300743593498 = 4698790104602 := by decide
theorem cert_e300743593498 : check e300743593498 [[.under]] .width = true := by decide
def e300743602374 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300743602374 : Closed e300743602374 ∧ code e300743602374 = 4698790113478 := by decide
theorem cert_e300743602374 : check e300743602374 [[.under]] .width = true := by decide
def e300743714330 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300743714330 : Closed e300743714330 ∧ code e300743714330 = 4698790225434 := by decide
theorem cert_e300743714330 : check e300743714330 [[.under]] .width = true := by decide
def e300743855642 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300743855642 : Closed e300743855642 ∧ code e300743855642 = 4698790366746 := by decide
theorem cert_e300743855642 : check e300743855642 [[.under]] .width = true := by decide
def e300743864518 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300743864518 : Closed e300743864518 ∧ code e300743864518 = 4698790375622 := by decide
theorem cert_e300743864518 : check e300743864518 [[.under]] .width = true := by decide
def e300744631834 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300744631834 : Closed e300744631834 ∧ code e300744631834 = 4698791142938 := by decide
theorem cert_e300744631834 : check e300744631834 [[.under]] .width = true := by decide
def e300744680986 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300744680986 : Closed e300744680986 ∧ code e300744680986 = 4698791192090 := by decide
theorem cert_e300744680986 : check e300744680986 [[.under]] .width = true := by decide
def e300745352730 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300745352730 : Closed e300745352730 ∧ code e300745352730 = 4698791863834 := by decide
theorem cert_e300745352730 : check e300745352730 [[.under]] .width = true := by decide
def e300745690650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300745690650 : Closed e300745690650 ∧ code e300745690650 = 4698792201754 := by decide
theorem cert_e300745690650 : check e300745690650 [[.under]] .width = true := by decide
def e300745699526 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300745699526 : Closed e300745699526 ∧ code e300745699526 = 4698792210630 := by decide
theorem cert_e300745699526 : check e300745699526 [[.under]] .width = true := by decide
def e300746040858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746040858 : Closed e300746040858 ∧ code e300746040858 = 4698792551962 := by decide
theorem cert_e300746040858 : check e300746040858 [[.under]] .width = true := by decide
def e300746083866 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300746083866 : Closed e300746083866 ∧ code e300746083866 = 4698792594970 := by decide
theorem cert_e300746083866 : check e300746083866 [[.under]] .width = true := by decide
def e300746092742 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300746092742 : Closed e300746092742 ∧ code e300746092742 = 4698792603846 := by decide
theorem cert_e300746092742 : check e300746092742 [[.under]] .width = true := by decide
def e300746499610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746499610 : Closed e300746499610 ∧ code e300746499610 = 4698793010714 := by decide
theorem cert_e300746499610 : check e300746499610 [[.under]] .width = true := by decide
def e300746515994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746515994 : Closed e300746515994 ∧ code e300746515994 = 4698793027098 := by decide
theorem cert_e300746515994 : check e300746515994 [[.under]] .width = true := by decide
def e300746860058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746860058 : Closed e300746860058 ∧ code e300746860058 = 4698793371162 := by decide
theorem cert_e300746860058 : check e300746860058 [[.under]] .width = true := by decide
def e300747001370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300747001370 : Closed e300747001370 ∧ code e300747001370 = 4698793512474 := by decide
theorem cert_e300747001370 : check e300747001370 [[.under]] .width = true := by decide
def e300747010246 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300747010246 : Closed e300747010246 ∧ code e300747010246 = 4698793521350 := by decide
theorem cert_e300747010246 : check e300747010246 [[.under]] .width = true := by decide
def e300747089434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300747089434 : Closed e300747089434 ∧ code e300747089434 = 4698793600538 := by decide
theorem cert_e300747089434 : check e300747089434 [[.under]] .width = true := by decide
def e300747132442 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300747132442 : Closed e300747132442 ∧ code e300747132442 = 4698793643546 := by decide
theorem cert_e300747132442 : check e300747132442 [[.under]] .width = true := by decide
def e300747141318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300747141318 : Closed e300747141318 ∧ code e300747141318 = 4698793652422 := by decide
theorem cert_e300747141318 : check e300747141318 [[.under]] .width = true := by decide
def e300755838490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300755838490 : Closed e300755838490 ∧ code e300755838490 = 4698802349594 := by decide
theorem cert_e300755838490 : check e300755838490 [[.under]] .width = true := by decide
def e300756176410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300756176410 : Closed e300756176410 ∧ code e300756176410 = 4698802687514 := by decide
theorem cert_e300756176410 : check e300756176410 [[.under]] .width = true := by decide
def e300756185286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300756185286 : Closed e300756185286 ∧ code e300756185286 = 4698802696390 := by decide
theorem cert_e300756185286 : check e300756185286 [[.under]] .width = true := by decide
def e300756297242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300756297242 : Closed e300756297242 ∧ code e300756297242 = 4698802808346 := by decide
theorem cert_e300756297242 : check e300756297242 [[.under]] .width = true := by decide
def e300756438554 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300756438554 : Closed e300756438554 ∧ code e300756438554 = 4698802949658 := by decide
theorem cert_e300756438554 : check e300756438554 [[.under]] .width = true := by decide
def e300756447430 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300756447430 : Closed e300756447430 ∧ code e300756447430 = 4698802958534 := by decide
theorem cert_e300756447430 : check e300756447430 [[.under]] .width = true := by decide
def e300768421402 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300768421402 : Closed e300768421402 ∧ code e300768421402 = 4698814932506 := by decide
theorem cert_e300768421402 : check e300768421402 [[.under]] .width = true := by decide
def e300768759322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300768759322 : Closed e300768759322 ∧ code e300768759322 = 4698815270426 := by decide
theorem cert_e300768759322 : check e300768759322 [[.under]] .width = true := by decide
def e300768768198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300768768198 : Closed e300768768198 ∧ code e300768768198 = 4698815279302 := by decide
theorem cert_e300768768198 : check e300768768198 [[.under]] .width = true := by decide
def e300769109530 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300769109530 : Closed e300769109530 ∧ code e300769109530 = 4698815620634 := by decide
theorem cert_e300769109530 : check e300769109530 [[.under]] .width = true := by decide
def e300769152538 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300769152538 : Closed e300769152538 ∧ code e300769152538 = 4698815663642 := by decide
theorem cert_e300769152538 : check e300769152538 [[.under]] .width = true := by decide
def e300769161414 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300769161414 : Closed e300769161414 ∧ code e300769161414 = 4698815672518 := by decide
theorem cert_e300769161414 : check e300769161414 [[.under]] .width = true := by decide
def e300775171610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300775171610 : Closed e300775171610 ∧ code e300775171610 = 4698821682714 := by decide
theorem cert_e300775171610 : check e300775171610 [[.under]] .width = true := by decide
def e300775312922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300775312922 : Closed e300775312922 ∧ code e300775312922 = 4698821824026 := by decide
theorem cert_e300775312922 : check e300775312922 [[.under]] .width = true := by decide
def e300775321798 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300775321798 : Closed e300775321798 ∧ code e300775321798 = 4698821832902 := by decide
theorem cert_e300775321798 : check e300775321798 [[.under]] .width = true := by decide
def e300775400986 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300775400986 : Closed e300775400986 ∧ code e300775400986 = 4698821912090 := by decide
theorem cert_e300775400986 : check e300775400986 [[.under]] .width = true := by decide
def e300775443994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e300775443994 : Closed e300775443994 ∧ code e300775443994 = 4698821955098 := by decide
theorem cert_e300775443994 : check e300775443994 [[.under]] .width = true := by decide
def e300775452870 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300775452870 : Closed e300775452870 ∧ code e300775452870 = 4698821963974 := by decide
theorem cert_e300775452870 : check e300775452870 [[.under]] .width = true := by decide
def e301503393134 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e301503393134 : Closed e301503393134 ∧ code e301503393134 = 4699549904238 := by decide
theorem cert_e301503393134 : check e301503393134 [[.under]] .sourceHead = true := by decide
def e301503393142 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e301503393142 : Closed e301503393142 ∧ code e301503393142 = 4699549904246 := by decide
theorem cert_e301503393142 : check e301503393142 [[.under]] .sourceHead = true := by decide
def e301503393198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e301503393198 : Closed e301503393198 ∧ code e301503393198 = 4699549904302 := by decide
theorem cert_e301503393198 : check e301503393198 [[.under]] .sourceHead = true := by decide
def e301503393210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e301503393210 : Closed e301503393210 ∧ code e301503393210 = 4699549904314 := by decide
theorem cert_e301503393210 : check e301503393210 [[.under]] .sourceHead = true := by decide
def e301503393238 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e301503393238 : Closed e301503393238 ∧ code e301503393238 = 4699549904342 := by decide
theorem cert_e301503393238 : check e301503393238 [[.under]] .sourceHead = true := by decide
def e301503393242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e301503393242 : Closed e301503393242 ∧ code e301503393242 = 4699549904346 := by decide
theorem cert_e301503393242 : check e301503393242 [[.under]] .sourceHead = true := by decide
def e301503393454 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e301503393454 : Closed e301503393454 ∧ code e301503393454 = 4699549904558 := by decide
theorem cert_e301503393454 : check e301503393454 [[.under]] .sourceHead = true := by decide
def e301503393466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e301503393466 : Closed e301503393466 ∧ code e301503393466 = 4699549904570 := by decide
theorem cert_e301503393466 : check e301503393466 [[.under]] .sourceHead = true := by decide
def e301503393514 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e301503393514 : Closed e301503393514 ∧ code e301503393514 = 4699549904618 := by decide
theorem cert_e301503393514 : check e301503393514 [[.under]] .sourceHead = true := by decide
def e301503393622 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e301503393622 : Closed e301503393622 ∧ code e301503393622 = 4699549904726 := by decide
theorem cert_e301503393622 : check e301503393622 [[.under]] .sourceHead = true := by decide
def e301503393626 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e301503393626 : Closed e301503393626 ∧ code e301503393626 = 4699549904730 := by decide
theorem cert_e301503393626 : check e301503393626 [[.under]] .sourceHead = true := by decide
def e301503393642 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e301503393642 : Closed e301503393642 ∧ code e301503393642 = 4699549904746 := by decide
theorem cert_e301503393642 : check e301503393642 [[.under]] .sourceHead = true := by decide
def e301503394670 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e301503394670 : Closed e301503394670 ∧ code e301503394670 = 4699549905774 := by decide
theorem cert_e301503394670 : check e301503394670 [[.under]] .sourceHead = true := by decide
def e301503394678 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e301503394678 : Closed e301503394678 ∧ code e301503394678 = 4699549905782 := by decide
theorem cert_e301503394678 : check e301503394678 [[.under]] .sourceHead = true := by decide
def e301503394734 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e301503394734 : Closed e301503394734 ∧ code e301503394734 = 4699549905838 := by decide
theorem cert_e301503394734 : check e301503394734 [[.under]] .sourceHead = true := by decide
def e301503394746 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e301503394746 : Closed e301503394746 ∧ code e301503394746 = 4699549905850 := by decide
theorem cert_e301503394746 : check e301503394746 [[.under]] .sourceHead = true := by decide
def e301503394774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e301503394774 : Closed e301503394774 ∧ code e301503394774 = 4699549905878 := by decide
theorem cert_e301503394774 : check e301503394774 [[.under]] .sourceHead = true := by decide
def e301503394778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e301503394778 : Closed e301503394778 ∧ code e301503394778 = 4699549905882 := by decide
theorem cert_e301503394778 : check e301503394778 [[.under]] .sourceHead = true := by decide
def e301503395054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e301503395054 : Closed e301503395054 ∧ code e301503395054 = 4699549906158 := by decide
theorem cert_e301503395054 : check e301503395054 [[.under]] .sourceHead = true := by decide
def e301503395062 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e301503395062 : Closed e301503395062 ∧ code e301503395062 = 4699549906166 := by decide
theorem cert_e301503395062 : check e301503395062 [[.under]] .sourceHead = true := by decide
def e301503395438 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e301503395438 : Closed e301503395438 ∧ code e301503395438 = 4699549906542 := by decide
theorem cert_e301503395438 : check e301503395438 [[.under]] .sourceHead = true := by decide
def e301503395450 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e301503395450 : Closed e301503395450 ∧ code e301503395450 = 4699549906554 := by decide
theorem cert_e301503395450 : check e301503395450 [[.under]] .sourceHead = true := by decide
def e301503395638 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e301503395638 : Closed e301503395638 ∧ code e301503395638 = 4699549906742 := by decide
theorem cert_e301503395638 : check e301503395638 [[.under]] .sourceHead = true := by decide
def e301503395642 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e301503395642 : Closed e301503395642 ∧ code e301503395642 = 4699549906746 := by decide
theorem cert_e301503395642 : check e301503395642 [[.under]] .sourceHead = true := by decide
def e301503396270 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e301503396270 : Closed e301503396270 ∧ code e301503396270 = 4699549907374 := by decide
theorem cert_e301503396270 : check e301503396270 [[.under]] .sourceHead = true := by decide
def e301503396282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e301503396282 : Closed e301503396282 ∧ code e301503396282 = 4699549907386 := by decide
theorem cert_e301503396282 : check e301503396282 [[.under]] .sourceHead = true := by decide
def e301503396330 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e301503396330 : Closed e301503396330 ∧ code e301503396330 = 4699549907434 := by decide
theorem cert_e301503396330 : check e301503396330 [[.under]] .sourceHead = true := by decide
def e301503396462 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e301503396462 : Closed e301503396462 ∧ code e301503396462 = 4699549907566 := by decide
theorem cert_e301503396462 : check e301503396462 [[.under]] .sourceHead = true := by decide
def e301503396474 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e301503396474 : Closed e301503396474 ∧ code e301503396474 = 4699549907578 := by decide
theorem cert_e301503396474 : check e301503396474 [[.under]] .sourceHead = true := by decide
def e301503396762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e301503396762 : Closed e301503396762 ∧ code e301503396762 = 4699549907866 := by decide
theorem cert_e301503396762 : check e301503396762 [[.under]] .sourceHead = true := by decide
def e301503397078 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e301503397078 : Closed e301503397078 ∧ code e301503397078 = 4699549908182 := by decide
theorem cert_e301503397078 : check e301503397078 [[.under]] .sourceHead = true := by decide
def e301503397082 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e301503397082 : Closed e301503397082 ∧ code e301503397082 = 4699549908186 := by decide
theorem cert_e301503397082 : check e301503397082 [[.under]] .sourceHead = true := by decide
def e301503397098 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e301503397098 : Closed e301503397098 ∧ code e301503397098 = 4699549908202 := by decide
theorem cert_e301503397098 : check e301503397098 [[.under]] .sourceHead = true := by decide
def e301503397174 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e301503397174 : Closed e301503397174 ∧ code e301503397174 = 4699549908278 := by decide
theorem cert_e301503397174 : check e301503397174 [[.under]] .sourceHead = true := by decide
def e301503397178 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e301503397178 : Closed e301503397178 ∧ code e301503397178 = 4699549908282 := by decide
theorem cert_e301503397178 : check e301503397178 [[.under]] .sourceHead = true := by decide
def e301503397274 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e301503397274 : Closed e301503397274 ∧ code e301503397274 = 4699549908378 := by decide
theorem cert_e301503397274 : check e301503397274 [[.under]] .sourceHead = true := by decide
def e301503400814 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301503400814 : Closed e301503400814 ∧ code e301503400814 = 4699549911918 := by decide
theorem cert_e301503400814 : check e301503400814 [[.under]] .sourceHead = true := by decide
def e301503400822 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301503400822 : Closed e301503400822 ∧ code e301503400822 = 4699549911926 := by decide
theorem cert_e301503400822 : check e301503400822 [[.under]] .sourceHead = true := by decide
def e301503400878 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301503400878 : Closed e301503400878 ∧ code e301503400878 = 4699549911982 := by decide
theorem cert_e301503400878 : check e301503400878 [[.under]] .sourceHead = true := by decide
def e301503400890 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301503400890 : Closed e301503400890 ∧ code e301503400890 = 4699549911994 := by decide
theorem cert_e301503400890 : check e301503400890 [[.under]] .sourceHead = true := by decide
def e301503400918 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301503400918 : Closed e301503400918 ∧ code e301503400918 = 4699549912022 := by decide
theorem cert_e301503400918 : check e301503400918 [[.under]] .sourceHead = true := by decide
def e301503400922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301503400922 : Closed e301503400922 ∧ code e301503400922 = 4699549912026 := by decide
theorem cert_e301503400922 : check e301503400922 [[.under]] .sourceHead = true := by decide
def e301503401198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301503401198 : Closed e301503401198 ∧ code e301503401198 = 4699549912302 := by decide
theorem cert_e301503401198 : check e301503401198 [[.under]] .sourceHead = true := by decide
def e301503401206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301503401206 : Closed e301503401206 ∧ code e301503401206 = 4699549912310 := by decide
theorem cert_e301503401206 : check e301503401206 [[.under]] .sourceHead = true := by decide
def e301503401582 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301503401582 : Closed e301503401582 ∧ code e301503401582 = 4699549912686 := by decide
theorem cert_e301503401582 : check e301503401582 [[.under]] .sourceHead = true := by decide
def e301503401594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301503401594 : Closed e301503401594 ∧ code e301503401594 = 4699549912698 := by decide
theorem cert_e301503401594 : check e301503401594 [[.under]] .sourceHead = true := by decide
def e301503401782 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301503401782 : Closed e301503401782 ∧ code e301503401782 = 4699549912886 := by decide
theorem cert_e301503401782 : check e301503401782 [[.under]] .sourceHead = true := by decide
def e301503401786 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301503401786 : Closed e301503401786 ∧ code e301503401786 = 4699549912890 := by decide
theorem cert_e301503401786 : check e301503401786 [[.under]] .sourceHead = true := by decide
def e301503407534 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e301503407534 : Closed e301503407534 ∧ code e301503407534 = 4699549918638 := by decide
theorem cert_e301503407534 : check e301503407534 [[.under]] .sourceHead = true := by decide
def e301503407546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e301503407546 : Closed e301503407546 ∧ code e301503407546 = 4699549918650 := by decide
theorem cert_e301503407546 : check e301503407546 [[.under]] .sourceHead = true := by decide
def e301503407594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e301503407594 : Closed e301503407594 ∧ code e301503407594 = 4699549918698 := by decide
theorem cert_e301503407594 : check e301503407594 [[.under]] .sourceHead = true := by decide
def e301503407726 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e301503407726 : Closed e301503407726 ∧ code e301503407726 = 4699549918830 := by decide
theorem cert_e301503407726 : check e301503407726 [[.under]] .sourceHead = true := by decide
def e301503407738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e301503407738 : Closed e301503407738 ∧ code e301503407738 = 4699549918842 := by decide
theorem cert_e301503407738 : check e301503407738 [[.under]] .sourceHead = true := by decide
def e301503408026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e301503408026 : Closed e301503408026 ∧ code e301503408026 = 4699549919130 := by decide
theorem cert_e301503408026 : check e301503408026 [[.under]] .sourceHead = true := by decide
def e301503410902 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e301503410902 : Closed e301503410902 ∧ code e301503410902 = 4699549922006 := by decide
theorem cert_e301503410902 : check e301503410902 [[.under]] .sourceHead = true := by decide
def e301503410906 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e301503410906 : Closed e301503410906 ∧ code e301503410906 = 4699549922010 := by decide
theorem cert_e301503410906 : check e301503410906 [[.under]] .sourceHead = true := by decide
def e301503410922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e301503410922 : Closed e301503410922 ∧ code e301503410922 = 4699549922026 := by decide
theorem cert_e301503410922 : check e301503410922 [[.under]] .sourceHead = true := by decide
def e301503410998 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e301503410998 : Closed e301503410998 ∧ code e301503410998 = 4699549922102 := by decide
theorem cert_e301503410998 : check e301503410998 [[.under]] .sourceHead = true := by decide
def e301503411002 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e301503411002 : Closed e301503411002 ∧ code e301503411002 = 4699549922106 := by decide
theorem cert_e301503411002 : check e301503411002 [[.under]] .sourceHead = true := by decide
def e301503411098 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e301503411098 : Closed e301503411098 ∧ code e301503411098 = 4699549922202 := by decide
theorem cert_e301503411098 : check e301503411098 [[.under]] .sourceHead = true := by decide
def e301503548270 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301503548270 : Closed e301503548270 ∧ code e301503548270 = 4699550059374 := by decide
theorem cert_e301503548270 : check e301503548270 [[.under]] .sourceHead = true := by decide
def e301503548278 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301503548278 : Closed e301503548278 ∧ code e301503548278 = 4699550059382 := by decide
theorem cert_e301503548278 : check e301503548278 [[.under]] .sourceHead = true := by decide
def e301503548334 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301503548334 : Closed e301503548334 ∧ code e301503548334 = 4699550059438 := by decide
theorem cert_e301503548334 : check e301503548334 [[.under]] .sourceHead = true := by decide
def e301503548346 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301503548346 : Closed e301503548346 ∧ code e301503548346 = 4699550059450 := by decide
theorem cert_e301503548346 : check e301503548346 [[.under]] .sourceHead = true := by decide
def e301503548374 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301503548374 : Closed e301503548374 ∧ code e301503548374 = 4699550059478 := by decide
theorem cert_e301503548374 : check e301503548374 [[.under]] .sourceHead = true := by decide
def e301503548378 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301503548378 : Closed e301503548378 ∧ code e301503548378 = 4699550059482 := by decide
theorem cert_e301503548378 : check e301503548378 [[.under]] .sourceHead = true := by decide
def e301503548654 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301503548654 : Closed e301503548654 ∧ code e301503548654 = 4699550059758 := by decide
theorem cert_e301503548654 : check e301503548654 [[.under]] .sourceHead = true := by decide
def e301503548662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301503548662 : Closed e301503548662 ∧ code e301503548662 = 4699550059766 := by decide
theorem cert_e301503548662 : check e301503548662 [[.under]] .sourceHead = true := by decide
def e301503549038 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301503549038 : Closed e301503549038 ∧ code e301503549038 = 4699550060142 := by decide
theorem cert_e301503549038 : check e301503549038 [[.under]] .sourceHead = true := by decide
def e301503549050 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301503549050 : Closed e301503549050 ∧ code e301503549050 = 4699550060154 := by decide
theorem cert_e301503549050 : check e301503549050 [[.under]] .sourceHead = true := by decide
def e301503549238 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301503549238 : Closed e301503549238 ∧ code e301503549238 = 4699550060342 := by decide
theorem cert_e301503549238 : check e301503549238 [[.under]] .sourceHead = true := by decide
def e301503549242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301503549242 : Closed e301503549242 ∧ code e301503549242 = 4699550060346 := by decide
theorem cert_e301503549242 : check e301503549242 [[.under]] .sourceHead = true := by decide
def e301504138094 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301504138094 : Closed e301504138094 ∧ code e301504138094 = 4699550649198 := by decide
theorem cert_e301504138094 : check e301504138094 [[.under]] .sourceHead = true := by decide
def e301504138102 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301504138102 : Closed e301504138102 ∧ code e301504138102 = 4699550649206 := by decide
theorem cert_e301504138102 : check e301504138102 [[.under]] .sourceHead = true := by decide
def e301504138158 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301504138158 : Closed e301504138158 ∧ code e301504138158 = 4699550649262 := by decide
theorem cert_e301504138158 : check e301504138158 [[.under]] .sourceHead = true := by decide
def e301504138170 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301504138170 : Closed e301504138170 ∧ code e301504138170 = 4699550649274 := by decide
theorem cert_e301504138170 : check e301504138170 [[.under]] .sourceHead = true := by decide
def e301504138198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301504138198 : Closed e301504138198 ∧ code e301504138198 = 4699550649302 := by decide
theorem cert_e301504138198 : check e301504138198 [[.under]] .sourceHead = true := by decide
def e301504138202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301504138202 : Closed e301504138202 ∧ code e301504138202 = 4699550649306 := by decide
theorem cert_e301504138202 : check e301504138202 [[.under]] .sourceHead = true := by decide
def e301504138478 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301504138478 : Closed e301504138478 ∧ code e301504138478 = 4699550649582 := by decide
theorem cert_e301504138478 : check e301504138478 [[.under]] .sourceHead = true := by decide
def e301504138486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301504138486 : Closed e301504138486 ∧ code e301504138486 = 4699550649590 := by decide
theorem cert_e301504138486 : check e301504138486 [[.under]] .sourceHead = true := by decide
def e301504138862 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301504138862 : Closed e301504138862 ∧ code e301504138862 = 4699550649966 := by decide
theorem cert_e301504138862 : check e301504138862 [[.under]] .sourceHead = true := by decide
def e301504138874 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301504138874 : Closed e301504138874 ∧ code e301504138874 = 4699550649978 := by decide
theorem cert_e301504138874 : check e301504138874 [[.under]] .sourceHead = true := by decide
def e301504139062 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301504139062 : Closed e301504139062 ∧ code e301504139062 = 4699550650166 := by decide
theorem cert_e301504139062 : check e301504139062 [[.under]] .sourceHead = true := by decide
def e301504139066 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301504139066 : Closed e301504139066 ∧ code e301504139066 = 4699550650170 := by decide
theorem cert_e301504139066 : check e301504139066 [[.under]] .sourceHead = true := by decide
def e302459694446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302459694446 : Closed e302459694446 ∧ code e302459694446 = 4700506205550 := by decide
theorem cert_e302459694446 : check e302459694446 [[.under],[.under]] .smaller = true := by decide
def e302459694454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302459694454 : Closed e302459694454 ∧ code e302459694454 = 4700506205558 := by decide
theorem cert_e302459694454 : check e302459694454 [[.under],[.under]] .smaller = true := by decide
def e302459694510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302459694510 : Closed e302459694510 ∧ code e302459694510 = 4700506205614 := by decide
theorem cert_e302459694510 : check e302459694510 [[.under],[.under]] .smaller = true := by decide
def e302459694522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302459694522 : Closed e302459694522 ∧ code e302459694522 = 4700506205626 := by decide
theorem cert_e302459694522 : check e302459694522 [[.under],[.under]] .smaller = true := by decide
def e302459694550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302459694550 : Closed e302459694550 ∧ code e302459694550 = 4700506205654 := by decide
theorem cert_e302459694550 : check e302459694550 [[.under],[.under]] .smaller = true := by decide
def e302459694554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302459694554 : Closed e302459694554 ∧ code e302459694554 = 4700506205658 := by decide
theorem cert_e302459694554 : check e302459694554 [[.under],[.under]] .smaller = true := by decide
def e302459694766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302459694766 : Closed e302459694766 ∧ code e302459694766 = 4700506205870 := by decide
theorem cert_e302459694766 : check e302459694766 [[.under],[.under]] .smaller = true := by decide
def e302459694778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302459694778 : Closed e302459694778 ∧ code e302459694778 = 4700506205882 := by decide
theorem cert_e302459694778 : check e302459694778 [[.under],[.under]] .smaller = true := by decide
def e302459694826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302459694826 : Closed e302459694826 ∧ code e302459694826 = 4700506205930 := by decide
theorem cert_e302459694826 : check e302459694826 [[.under],[.under]] .smaller = true := by decide
def e302459694934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302459694934 : Closed e302459694934 ∧ code e302459694934 = 4700506206038 := by decide
theorem cert_e302459694934 : check e302459694934 [[.under],[.under]] .smaller = true := by decide
def e302459694938 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302459694938 : Closed e302459694938 ∧ code e302459694938 = 4700506206042 := by decide
theorem cert_e302459694938 : check e302459694938 [[.under],[.under]] .smaller = true := by decide
def e302459694954 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302459694954 : Closed e302459694954 ∧ code e302459694954 = 4700506206058 := by decide
theorem cert_e302459694954 : check e302459694954 [[.under],[.under]] .smaller = true := by decide
def e302459695982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302459695982 : Closed e302459695982 ∧ code e302459695982 = 4700506207086 := by decide
theorem cert_e302459695982 : check e302459695982 [[.under],[.under]] .smaller = true := by decide
def e302459695990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302459695990 : Closed e302459695990 ∧ code e302459695990 = 4700506207094 := by decide
theorem cert_e302459695990 : check e302459695990 [[.under],[.under]] .smaller = true := by decide
def e302459696046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302459696046 : Closed e302459696046 ∧ code e302459696046 = 4700506207150 := by decide
theorem cert_e302459696046 : check e302459696046 [[.under],[.under]] .smaller = true := by decide
def e302459696058 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302459696058 : Closed e302459696058 ∧ code e302459696058 = 4700506207162 := by decide
theorem cert_e302459696058 : check e302459696058 [[.under],[.under]] .smaller = true := by decide
def e302459696086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302459696086 : Closed e302459696086 ∧ code e302459696086 = 4700506207190 := by decide
theorem cert_e302459696086 : check e302459696086 [[.under],[.under]] .smaller = true := by decide
def e302459696090 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302459696090 : Closed e302459696090 ∧ code e302459696090 = 4700506207194 := by decide
theorem cert_e302459696090 : check e302459696090 [[.under],[.under]] .smaller = true := by decide
end Blc.Floor42
