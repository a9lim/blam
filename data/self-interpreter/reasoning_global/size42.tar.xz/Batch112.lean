import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815449530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1205815449530 : Closed e1205815449530 ∧ code e1205815449530 = 5603861960634 := by decide
theorem cert_e1205815449530 : check e1205815449530 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815449662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e1205815449662 : Closed e1205815449662 ∧ code e1205815449662 = 5603861960766 := by decide
theorem cert_e1205815449662 : check e1205815449662 [[],[]] .chain = true := by decide
def e1205815450082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205815450082 : Closed e1205815450082 ∧ code e1205815450082 = 5603861961186 := by decide
theorem cert_e1205815450082 : check e1205815450082 [[],[]] .chain = true := by decide
def e1205815450094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205815450094 : Closed e1205815450094 ∧ code e1205815450094 = 5603861961198 := by decide
theorem cert_e1205815450094 : check e1205815450094 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815450862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815450862 : Closed e1205815450862 ∧ code e1205815450862 = 5603861961966 := by decide
theorem cert_e1205815450862 : check e1205815450862 [[],[]] .chain = true := by decide
def e1205815450870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815450870 : Closed e1205815450870 ∧ code e1205815450870 = 5603861961974 := by decide
theorem cert_e1205815450870 : check e1205815450870 [[],[]] .chain = true := by decide
def e1205815451150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e1205815451150 : Closed e1205815451150 ∧ code e1205815451150 = 5603861962254 := by decide
theorem cert_e1205815451150 : check e1205815451150 [[],[]] .chain = true := by decide
def e1205815451162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815451162 : Closed e1205815451162 ∧ code e1205815451162 = 5603861962266 := by decide
theorem cert_e1205815451162 : check e1205815451162 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815451234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205815451234 : Closed e1205815451234 ∧ code e1205815451234 = 5603861962338 := by decide
theorem cert_e1205815451234 : check e1205815451234 [[],[]] .chain = true := by decide
def e1205815451246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815451246 : Closed e1205815451246 ∧ code e1205815451246 = 5603861962350 := by decide
theorem cert_e1205815451246 : check e1205815451246 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815451254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205815451254 : Closed e1205815451254 ∧ code e1205815451254 = 5603861962358 := by decide
theorem cert_e1205815451254 : check e1205815451254 [[],[]] .chain = true := by decide
def e1205815451258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815451258 : Closed e1205815451258 ∧ code e1205815451258 = 5603861962362 := by decide
theorem cert_e1205815451258 : check e1205815451258 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1205815460830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1205815460830 : Closed e1205815460830 ∧ code e1205815460830 = 5603861971934 := by decide
theorem cert_e1205815460830 : check e1205815460830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815460846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1205815460846 : Closed e1205815460846 ∧ code e1205815460846 = 5603861971950 := by decide
theorem cert_e1205815460846 : check e1205815460846 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205815462678 : Closed e1205815462678 ∧ code e1205815462678 = 5603861973782 := by decide
theorem cert_e1205815462678 : check e1205815462678 [[],[]] .chain = true := by decide
def e1205815462754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205815462754 : Closed e1205815462754 ∧ code e1205815462754 = 5603861973858 := by decide
theorem cert_e1205815462754 : check e1205815462754 [[],[]] .chain = true := by decide
def e1205815462766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205815462766 : Closed e1205815462766 ∧ code e1205815462766 = 5603861973870 := by decide
theorem cert_e1205815462766 : check e1205815462766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205815462774 : Closed e1205815462774 ∧ code e1205815462774 = 5603861973878 := by decide
theorem cert_e1205815462774 : check e1205815462774 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205815462794 : Closed e1205815462794 ∧ code e1205815462794 = 5603861973898 := by decide
theorem cert_e1205815462794 : check e1205815462794 [[],[]] .chain = true := by decide
def e1205815462818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205815462818 : Closed e1205815462818 ∧ code e1205815462818 = 5603861973922 := by decide
theorem cert_e1205815462818 : check e1205815462818 [[],[]] .chain = true := by decide
def e1205815462830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205815462830 : Closed e1205815462830 ∧ code e1205815462830 = 5603861973934 := by decide
theorem cert_e1205815462830 : check e1205815462830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1205815462838 : Closed e1205815462838 ∧ code e1205815462838 = 5603861973942 := by decide
theorem cert_e1205815462838 : check e1205815462838 [[],[]] .chain = true := by decide
def e1205815462842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205815462842 : Closed e1205815462842 ∧ code e1205815462842 = 5603861973946 := by decide
theorem cert_e1205815462842 : check e1205815462842 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205815462870 : Closed e1205815462870 ∧ code e1205815462870 = 5603861973974 := by decide
theorem cert_e1205815462870 : check e1205815462870 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205815462874 : Closed e1205815462874 ∧ code e1205815462874 = 5603861973978 := by decide
theorem cert_e1205815462874 : check e1205815462874 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815462942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1205815462942 : Closed e1205815462942 ∧ code e1205815462942 = 5603861974046 := by decide
theorem cert_e1205815462942 : check e1205815462942 [[],[]] .chain = true := by decide
def e1205815463138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205815463138 : Closed e1205815463138 ∧ code e1205815463138 = 5603861974242 := by decide
theorem cert_e1205815463138 : check e1205815463138 [[],[]] .chain = true := by decide
def e1205815463150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815463150 : Closed e1205815463150 ∧ code e1205815463150 = 5603861974254 := by decide
theorem cert_e1205815463150 : check e1205815463150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815463158 : Closed e1205815463158 ∧ code e1205815463158 = 5603861974262 := by decide
theorem cert_e1205815463158 : check e1205815463158 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1205815463438 : Closed e1205815463438 ∧ code e1205815463438 = 5603861974542 := by decide
theorem cert_e1205815463438 : check e1205815463438 [[],[]] .chain = true := by decide
def e1205815463450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815463450 : Closed e1205815463450 ∧ code e1205815463450 = 5603861974554 := by decide
theorem cert_e1205815463450 : check e1205815463450 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205815463522 : Closed e1205815463522 ∧ code e1205815463522 = 5603861974626 := by decide
theorem cert_e1205815463522 : check e1205815463522 [[],[]] .chain = true := by decide
def e1205815463534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815463534 : Closed e1205815463534 ∧ code e1205815463534 = 5603861974638 := by decide
theorem cert_e1205815463534 : check e1205815463534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205815463542 : Closed e1205815463542 ∧ code e1205815463542 = 5603861974646 := by decide
theorem cert_e1205815463542 : check e1205815463542 [[],[]] .chain = true := by decide
def e1205815463546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815463546 : Closed e1205815463546 ∧ code e1205815463546 = 5603861974650 := by decide
theorem cert_e1205815463546 : check e1205815463546 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815463734 : Closed e1205815463734 ∧ code e1205815463734 = 5603861974838 := by decide
theorem cert_e1205815463734 : check e1205815463734 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815463738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815463738 : Closed e1205815463738 ∧ code e1205815463738 = 5603861974842 := by decide
theorem cert_e1205815463738 : check e1205815463738 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815744222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1205815744222 : Closed e1205815744222 ∧ code e1205815744222 = 5603862255326 := by decide
theorem cert_e1205815744222 : check e1205815744222 [[],[]] .smaller = true := by decide
def e1205815744246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1205815744246 : Closed e1205815744246 ∧ code e1205815744246 = 5603862255350 := by decide
theorem cert_e1205815744246 : check e1205815744246 [[],[]] .smaller = true := by decide
def e1205815744350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1205815744350 : Closed e1205815744350 ∧ code e1205815744350 = 5603862255454 := by decide
theorem cert_e1205815744350 : check e1205815744350 [[],[]] .smaller = true := by decide
def e1205815744378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1205815744378 : Closed e1205815744378 ∧ code e1205815744378 = 5603862255482 := by decide
theorem cert_e1205815744378 : check e1205815744378 [[],[]] .smaller = true := by decide
def e1205815744470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1205815744470 : Closed e1205815744470 ∧ code e1205815744470 = 5603862255574 := by decide
theorem cert_e1205815744470 : check e1205815744470 [[],[]] .smaller = true := by decide
def e1205815744474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1205815744474 : Closed e1205815744474 ∧ code e1205815744474 = 5603862255578 := by decide
theorem cert_e1205815744474 : check e1205815744474 [[],[]] .smaller = true := by decide
def e1205815744990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1205815744990 : Closed e1205815744990 ∧ code e1205815744990 = 5603862256094 := by decide
theorem cert_e1205815744990 : check e1205815744990 [[],[]] .smaller = true := by decide
def e1205815745014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1205815745014 : Closed e1205815745014 ∧ code e1205815745014 = 5603862256118 := by decide
theorem cert_e1205815745014 : check e1205815745014 [[],[]] .smaller = true := by decide
def e1205815745758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205815745758 : Closed e1205815745758 ∧ code e1205815745758 = 5603862256862 := by decide
theorem cert_e1205815745758 : check e1205815745758 [[],[]] .smaller = true := by decide
def e1205815745786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205815745786 : Closed e1205815745786 ∧ code e1205815745786 = 5603862256890 := by decide
theorem cert_e1205815745786 : check e1205815745786 [[],[]] .smaller = true := by decide
def e1205815746358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205815746358 : Closed e1205815746358 ∧ code e1205815746358 = 5603862257462 := by decide
theorem cert_e1205815746358 : check e1205815746358 [[],[]] .smaller = true := by decide
def e1205815746362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205815746362 : Closed e1205815746362 ∧ code e1205815746362 = 5603862257466 := by decide
theorem cert_e1205815746362 : check e1205815746362 [[],[]] .smaller = true := by decide
def e1205815761134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1205815761134 : Closed e1205815761134 ∧ code e1205815761134 = 5603862272238 := by decide
theorem cert_e1205815761134 : check e1205815761134 [[],[]] .smaller = true := by decide
def e1205815761142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1205815761142 : Closed e1205815761142 ∧ code e1205815761142 = 5603862272246 := by decide
theorem cert_e1205815761142 : check e1205815761142 [[],[]] .smaller = true := by decide
def e1205815761694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1205815761694 : Closed e1205815761694 ∧ code e1205815761694 = 5603862272798 := by decide
theorem cert_e1205815761694 : check e1205815761694 [[],[]] .smaller = true := by decide
def e1205815761806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1205815761806 : Closed e1205815761806 ∧ code e1205815761806 = 5603862272910 := by decide
theorem cert_e1205815761806 : check e1205815761806 [[],[]] .smaller = true := by decide
def e1205815762030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1205815762030 : Closed e1205815762030 ∧ code e1205815762030 = 5603862273134 := by decide
theorem cert_e1205815762030 : check e1205815762030 [[],[]] .smaller = true := by decide
def e1205815762042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1205815762042 : Closed e1205815762042 ∧ code e1205815762042 = 5603862273146 := by decide
theorem cert_e1205815762042 : check e1205815762042 [[],[]] .smaller = true := by decide
def e1205815762206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1205815762206 : Closed e1205815762206 ∧ code e1205815762206 = 5603862273310 := by decide
theorem cert_e1205815762206 : check e1205815762206 [[],[]] .smaller = true := by decide
def e1205815762374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1205815762374 : Closed e1205815762374 ∧ code e1205815762374 = 5603862273478 := by decide
theorem cert_e1205815762374 : check e1205815762374 [[],[]] .smaller = true := by decide
def e1205815762398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1205815762398 : Closed e1205815762398 ∧ code e1205815762398 = 5603862273502 := by decide
theorem cert_e1205815762398 : check e1205815762398 [[],[]] .chain = true := by decide
def e1205815762414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1205815762414 : Closed e1205815762414 ∧ code e1205815762414 = 5603862273518 := by decide
theorem cert_e1205815762414 : check e1205815762414 [[],[]] .chain = true := by decide
def e1205815762486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205815762486 : Closed e1205815762486 ∧ code e1205815762486 = 5603862273590 := by decide
theorem cert_e1205815762486 : check e1205815762486 [[],[]] .smaller = true := by decide
def e1205815762490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205815762490 : Closed e1205815762490 ∧ code e1205815762490 = 5603862273594 := by decide
theorem cert_e1205815762490 : check e1205815762490 [[],[]] .smaller = true := by decide
def e1205815762574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205815762574 : Closed e1205815762574 ∧ code e1205815762574 = 5603862273678 := by decide
theorem cert_e1205815762574 : check e1205815762574 [[],[]] .smaller = true := by decide
def e1205815762630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205815762630 : Closed e1205815762630 ∧ code e1205815762630 = 5603862273734 := by decide
theorem cert_e1205815762630 : check e1205815762630 [[],[]] .smaller = true := by decide
def e1205815762654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1205815762654 : Closed e1205815762654 ∧ code e1205815762654 = 5603862273758 := by decide
theorem cert_e1205815762654 : check e1205815762654 [[],[]] .chain = true := by decide
def e1205815762678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1205815762678 : Closed e1205815762678 ∧ code e1205815762678 = 5603862273782 := by decide
theorem cert_e1205815762678 : check e1205815762678 [[],[]] .chain = true := by decide
def e1205815762798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1205815762798 : Closed e1205815762798 ∧ code e1205815762798 = 5603862273902 := by decide
theorem cert_e1205815762798 : check e1205815762798 [[],[]] .chain = true := by decide
def e1205815762806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1205815762806 : Closed e1205815762806 ∧ code e1205815762806 = 5603862273910 := by decide
theorem cert_e1205815762806 : check e1205815762806 [[],[]] .chain = true := by decide
def e1205815764766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1205815764766 : Closed e1205815764766 ∧ code e1205815764766 = 5603862275870 := by decide
theorem cert_e1205815764766 : check e1205815764766 [[],[]] .smaller = true := by decide
def e1205815764878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1205815764878 : Closed e1205815764878 ∧ code e1205815764878 = 5603862275982 := by decide
theorem cert_e1205815764878 : check e1205815764878 [[],[]] .smaller = true := by decide
def e1205815767838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1205815767838 : Closed e1205815767838 ∧ code e1205815767838 = 5603862278942 := by decide
theorem cert_e1205815767838 : check e1205815767838 [[],[]] .smaller = true := by decide
def e1205815768006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1205815768006 : Closed e1205815768006 ∧ code e1205815768006 = 5603862279110 := by decide
theorem cert_e1205815768006 : check e1205815768006 [[],[]] .smaller = true := by decide
def e1205815768030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205815768030 : Closed e1205815768030 ∧ code e1205815768030 = 5603862279134 := by decide
theorem cert_e1205815768030 : check e1205815768030 [[],[]] .chain = true := by decide
def e1205815768046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205815768046 : Closed e1205815768046 ∧ code e1205815768046 = 5603862279150 := by decide
theorem cert_e1205815768046 : check e1205815768046 [[],[]] .chain = true := by decide
def e1205815769486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205815769486 : Closed e1205815769486 ∧ code e1205815769486 = 5603862280590 := by decide
theorem cert_e1205815769486 : check e1205815769486 [[],[]] .smaller = true := by decide
def e1205815769542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205815769542 : Closed e1205815769542 ∧ code e1205815769542 = 5603862280646 := by decide
theorem cert_e1205815769542 : check e1205815769542 [[],[]] .smaller = true := by decide
def e1205815769566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205815769566 : Closed e1205815769566 ∧ code e1205815769566 = 5603862280670 := by decide
theorem cert_e1205815769566 : check e1205815769566 [[],[]] .chain = true := by decide
def e1205815769590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205815769590 : Closed e1205815769590 ∧ code e1205815769590 = 5603862280694 := by decide
theorem cert_e1205815769590 : check e1205815769590 [[],[]] .chain = true := by decide
def e1205815770350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815770350 : Closed e1205815770350 ∧ code e1205815770350 = 5603862281454 := by decide
theorem cert_e1205815770350 : check e1205815770350 [[],[]] .chain = true := by decide
def e1205815770358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815770358 : Closed e1205815770358 ∧ code e1205815770358 = 5603862281462 := by decide
theorem cert_e1205815770358 : check e1205815770358 [[],[]] .chain = true := by decide
def e1205815810670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815810670 : Closed e1205815810670 ∧ code e1205815810670 = 5603862321774 := by decide
theorem cert_e1205815810670 : check e1205815810670 [[],[]] .sourceHead = true := by decide
def e1205815810682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815810682 : Closed e1205815810682 ∧ code e1205815810682 = 5603862321786 := by decide
theorem cert_e1205815810682 : check e1205815810682 [[],[]] .sourceHead = true := by decide
def e1205815826606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205815826606 : Closed e1205815826606 ∧ code e1205815826606 = 5603862337710 := by decide
theorem cert_e1205815826606 : check e1205815826606 [[],[]] .chain = true := by decide
def e1205815826618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205815826618 : Closed e1205815826618 ∧ code e1205815826618 = 5603862337722 := by decide
theorem cert_e1205815826618 : check e1205815826618 [[],[]] .chain = true := by decide
def e1205815826990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815826990 : Closed e1205815826990 ∧ code e1205815826990 = 5603862338094 := by decide
theorem cert_e1205815826990 : check e1205815826990 [[],[]] .chain = true := by decide
def e1205815827170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815827170 : Closed e1205815827170 ∧ code e1205815827170 = 5603862338274 := by decide
theorem cert_e1205815827170 : check e1205815827170 [[],[]] .chain = true := by decide
def e1205815827182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1205815827182 : Closed e1205815827182 ∧ code e1205815827182 = 5603862338286 := by decide
theorem cert_e1205815827182 : check e1205815827182 [[],[]] .sourceHead = true := by decide
def e1205815827310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1205815827310 : Closed e1205815827310 ∧ code e1205815827310 = 5603862338414 := by decide
theorem cert_e1205815827310 : check e1205815827310 [[],[]] .chain = true := by decide
def e1205815827318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1205815827318 : Closed e1205815827318 ∧ code e1205815827318 = 5603862338422 := by decide
theorem cert_e1205815827318 : check e1205815827318 [[],[]] .chain = true := by decide
def e1205815827338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815827338 : Closed e1205815827338 ∧ code e1205815827338 = 5603862338442 := by decide
theorem cert_e1205815827338 : check e1205815827338 [[],[]] .chain = true := by decide
def e1205815827362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815827362 : Closed e1205815827362 ∧ code e1205815827362 = 5603862338466 := by decide
theorem cert_e1205815827362 : check e1205815827362 [[],[]] .chain = true := by decide
def e1205815827374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1205815827374 : Closed e1205815827374 ∧ code e1205815827374 = 5603862338478 := by decide
theorem cert_e1205815827374 : check e1205815827374 [[],[]] .sourceHead = true := by decide
def e1205815827382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1205815827382 : Closed e1205815827382 ∧ code e1205815827382 = 5603862338486 := by decide
theorem cert_e1205815827382 : check e1205815827382 [[],[]] .chain = true := by decide
def e1205815827386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1205815827386 : Closed e1205815827386 ∧ code e1205815827386 = 5603862338490 := by decide
theorem cert_e1205815827386 : check e1205815827386 [[],[]] .sourceHead = true := by decide
def e1205815827822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205815827822 : Closed e1205815827822 ∧ code e1205815827822 = 5603862338926 := by decide
theorem cert_e1205815827822 : check e1205815827822 [[],[]] .chain = true := by decide
def e1205815827830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205815827830 : Closed e1205815827830 ∧ code e1205815827830 = 5603862338934 := by decide
theorem cert_e1205815827830 : check e1205815827830 [[],[]] .chain = true := by decide
def e1205815827886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205815827886 : Closed e1205815827886 ∧ code e1205815827886 = 5603862338990 := by decide
theorem cert_e1205815827886 : check e1205815827886 [[],[]] .chain = true := by decide
def e1205815827898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205815827898 : Closed e1205815827898 ∧ code e1205815827898 = 5603862339002 := by decide
theorem cert_e1205815827898 : check e1205815827898 [[],[]] .chain = true := by decide
def e1205815827926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205815827926 : Closed e1205815827926 ∧ code e1205815827926 = 5603862339030 := by decide
theorem cert_e1205815827926 : check e1205815827926 [[],[]] .chain = true := by decide
def e1205815827930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205815827930 : Closed e1205815827930 ∧ code e1205815827930 = 5603862339034 := by decide
theorem cert_e1205815827930 : check e1205815827930 [[],[]] .chain = true := by decide
def e1205815828010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1205815828010 : Closed e1205815828010 ∧ code e1205815828010 = 5603862339114 := by decide
theorem cert_e1205815828010 : check e1205815828010 [[],[]] .chain = true := by decide
def e1205815828106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815828106 : Closed e1205815828106 ∧ code e1205815828106 = 5603862339210 := by decide
theorem cert_e1205815828106 : check e1205815828106 [[],[]] .chain = true := by decide
def e1205815828130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815828130 : Closed e1205815828130 ∧ code e1205815828130 = 5603862339234 := by decide
theorem cert_e1205815828130 : check e1205815828130 [[],[]] .chain = true := by decide
def e1205815828142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1205815828142 : Closed e1205815828142 ∧ code e1205815828142 = 5603862339246 := by decide
theorem cert_e1205815828142 : check e1205815828142 [[],[]] .sourceHead = true := by decide
def e1205815828150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1205815828150 : Closed e1205815828150 ∧ code e1205815828150 = 5603862339254 := by decide
theorem cert_e1205815828150 : check e1205815828150 [[],[]] .chain = true := by decide
def e1205815828154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1205815828154 : Closed e1205815828154 ∧ code e1205815828154 = 5603862339258 := by decide
theorem cert_e1205815828154 : check e1205815828154 [[],[]] .sourceHead = true := by decide
def e1205815828182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1205815828182 : Closed e1205815828182 ∧ code e1205815828182 = 5603862339286 := by decide
theorem cert_e1205815828182 : check e1205815828182 [[],[]] .chain = true := by decide
def e1205815828186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1205815828186 : Closed e1205815828186 ∧ code e1205815828186 = 5603862339290 := by decide
theorem cert_e1205815828186 : check e1205815828186 [[],[]] .chain = true := by decide
def e1205815828202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1205815828202 : Closed e1205815828202 ∧ code e1205815828202 = 5603862339306 := by decide
theorem cert_e1205815828202 : check e1205815828202 [[],[]] .sourceHead = true := by decide
def e1205815828718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205815828718 : Closed e1205815828718 ∧ code e1205815828718 = 5603862339822 := by decide
theorem cert_e1205815828718 : check e1205815828718 [[],[]] .chain = true := by decide
def e1205815828730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205815828730 : Closed e1205815828730 ∧ code e1205815828730 = 5603862339834 := by decide
theorem cert_e1205815828730 : check e1205815828730 [[],[]] .chain = true := by decide
def e1205815828910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1205815828910 : Closed e1205815828910 ∧ code e1205815828910 = 5603862340014 := by decide
theorem cert_e1205815828910 : check e1205815828910 [[],[]] .sourceHead = true := by decide
def e1205815829102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815829102 : Closed e1205815829102 ∧ code e1205815829102 = 5603862340206 := by decide
theorem cert_e1205815829102 : check e1205815829102 [[],[]] .chain = true := by decide
def e1205815829114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815829114 : Closed e1205815829114 ∧ code e1205815829114 = 5603862340218 := by decide
theorem cert_e1205815829114 : check e1205815829114 [[],[]] .chain = true := by decide
def e1205815829278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205815829278 : Closed e1205815829278 ∧ code e1205815829278 = 5603862340382 := by decide
theorem cert_e1205815829278 : check e1205815829278 [[],[]] .chain = true := by decide
def e1205815829446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205815829446 : Closed e1205815829446 ∧ code e1205815829446 = 5603862340550 := by decide
theorem cert_e1205815829446 : check e1205815829446 [[],[]] .chain = true := by decide
def e1205815830062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205815830062 : Closed e1205815830062 ∧ code e1205815830062 = 5603862341166 := by decide
theorem cert_e1205815830062 : check e1205815830062 [[],[]] .chain = true := by decide
def e1205815830242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205815830242 : Closed e1205815830242 ∧ code e1205815830242 = 5603862341346 := by decide
theorem cert_e1205815830242 : check e1205815830242 [[],[]] .chain = true := by decide
def e1205815830254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1205815830254 : Closed e1205815830254 ∧ code e1205815830254 = 5603862341358 := by decide
theorem cert_e1205815830254 : check e1205815830254 [[],[]] .sourceHead = true := by decide
def e1205815830382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1205815830382 : Closed e1205815830382 ∧ code e1205815830382 = 5603862341486 := by decide
theorem cert_e1205815830382 : check e1205815830382 [[],[]] .chain = true := by decide
def e1205815830390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1205815830390 : Closed e1205815830390 ∧ code e1205815830390 = 5603862341494 := by decide
theorem cert_e1205815830390 : check e1205815830390 [[],[]] .chain = true := by decide
def e1205815830410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205815830410 : Closed e1205815830410 ∧ code e1205815830410 = 5603862341514 := by decide
theorem cert_e1205815830410 : check e1205815830410 [[],[]] .chain = true := by decide
def e1205815830434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205815830434 : Closed e1205815830434 ∧ code e1205815830434 = 5603862341538 := by decide
theorem cert_e1205815830434 : check e1205815830434 [[],[]] .chain = true := by decide
def e1205815830446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1205815830446 : Closed e1205815830446 ∧ code e1205815830446 = 5603862341550 := by decide
theorem cert_e1205815830446 : check e1205815830446 [[],[]] .sourceHead = true := by decide
def e1205815830454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1205815830454 : Closed e1205815830454 ∧ code e1205815830454 = 5603862341558 := by decide
theorem cert_e1205815830454 : check e1205815830454 [[],[]] .chain = true := by decide
def e1205815830458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1205815830458 : Closed e1205815830458 ∧ code e1205815830458 = 5603862341562 := by decide
theorem cert_e1205815830458 : check e1205815830458 [[],[]] .sourceHead = true := by decide
def e1205815830590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815830590 : Closed e1205815830590 ∧ code e1205815830590 = 5603862341694 := by decide
theorem cert_e1205815830590 : check e1205815830590 [[],[]] .chain = true := by decide
def e1205815831010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815831010 : Closed e1205815831010 ∧ code e1205815831010 = 5603862342114 := by decide
theorem cert_e1205815831010 : check e1205815831010 [[],[]] .chain = true := by decide
def e1205815831022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815831022 : Closed e1205815831022 ∧ code e1205815831022 = 5603862342126 := by decide
theorem cert_e1205815831022 : check e1205815831022 [[],[]] .sourceHead = true := by decide
def e1205815831790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815831790 : Closed e1205815831790 ∧ code e1205815831790 = 5603862342894 := by decide
theorem cert_e1205815831790 : check e1205815831790 [[],[]] .chain = true := by decide
def e1205815831798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815831798 : Closed e1205815831798 ∧ code e1205815831798 = 5603862342902 := by decide
theorem cert_e1205815831798 : check e1205815831798 [[],[]] .chain = true := by decide
def e1205815832078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815832078 : Closed e1205815832078 ∧ code e1205815832078 = 5603862343182 := by decide
theorem cert_e1205815832078 : check e1205815832078 [[],[]] .chain = true := by decide
def e1205815832090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815832090 : Closed e1205815832090 ∧ code e1205815832090 = 5603862343194 := by decide
theorem cert_e1205815832090 : check e1205815832090 [[],[]] .sourceHead = true := by decide
def e1205815832162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815832162 : Closed e1205815832162 ∧ code e1205815832162 = 5603862343266 := by decide
theorem cert_e1205815832162 : check e1205815832162 [[],[]] .chain = true := by decide
def e1205815832174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815832174 : Closed e1205815832174 ∧ code e1205815832174 = 5603862343278 := by decide
theorem cert_e1205815832174 : check e1205815832174 [[],[]] .sourceHead = true := by decide
def e1205815832182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815832182 : Closed e1205815832182 ∧ code e1205815832182 = 5603862343286 := by decide
theorem cert_e1205815832182 : check e1205815832182 [[],[]] .chain = true := by decide
def e1205815832186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815832186 : Closed e1205815832186 ∧ code e1205815832186 = 5603862343290 := by decide
theorem cert_e1205815832186 : check e1205815832186 [[],[]] .sourceHead = true := by decide
def e1205815833454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205815833454 : Closed e1205815833454 ∧ code e1205815833454 = 5603862344558 := by decide
theorem cert_e1205815833454 : check e1205815833454 [[],[]] .chain = true := by decide
def e1205815833462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205815833462 : Closed e1205815833462 ∧ code e1205815833462 = 5603862344566 := by decide
theorem cert_e1205815833462 : check e1205815833462 [[],[]] .chain = true := by decide
def e1205815833518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205815833518 : Closed e1205815833518 ∧ code e1205815833518 = 5603862344622 := by decide
theorem cert_e1205815833518 : check e1205815833518 [[],[]] .chain = true := by decide
def e1205815833530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205815833530 : Closed e1205815833530 ∧ code e1205815833530 = 5603862344634 := by decide
theorem cert_e1205815833530 : check e1205815833530 [[],[]] .chain = true := by decide
def e1205815833558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205815833558 : Closed e1205815833558 ∧ code e1205815833558 = 5603862344662 := by decide
theorem cert_e1205815833558 : check e1205815833558 [[],[]] .chain = true := by decide
def e1205815833562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205815833562 : Closed e1205815833562 ∧ code e1205815833562 = 5603862344666 := by decide
theorem cert_e1205815833562 : check e1205815833562 [[],[]] .chain = true := by decide
def e1205815833838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815833838 : Closed e1205815833838 ∧ code e1205815833838 = 5603862344942 := by decide
theorem cert_e1205815833838 : check e1205815833838 [[],[]] .chain = true := by decide
def e1205815833846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815833846 : Closed e1205815833846 ∧ code e1205815833846 = 5603862344950 := by decide
theorem cert_e1205815833846 : check e1205815833846 [[],[]] .chain = true := by decide
def e1205815834222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815834222 : Closed e1205815834222 ∧ code e1205815834222 = 5603862345326 := by decide
theorem cert_e1205815834222 : check e1205815834222 [[],[]] .chain = true := by decide
def e1205815834234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815834234 : Closed e1205815834234 ∧ code e1205815834234 = 5603862345338 := by decide
theorem cert_e1205815834234 : check e1205815834234 [[],[]] .chain = true := by decide
def e1205815834422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815834422 : Closed e1205815834422 ∧ code e1205815834422 = 5603862345526 := by decide
theorem cert_e1205815834422 : check e1205815834422 [[],[]] .chain = true := by decide
def e1205815834426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815834426 : Closed e1205815834426 ∧ code e1205815834426 = 5603862345530 := by decide
theorem cert_e1205815834426 : check e1205815834426 [[],[]] .chain = true := by decide
def e1205815834682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205815834682 : Closed e1205815834682 ∧ code e1205815834682 = 5603862345786 := by decide
theorem cert_e1205815834682 : check e1205815834682 [[],[]] .chain = true := by decide
def e1205815834730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1205815834730 : Closed e1205815834730 ∧ code e1205815834730 = 5603862345834 := by decide
theorem cert_e1205815834730 : check e1205815834730 [[],[]] .sourceHead = true := by decide
def e1205815834778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815834778 : Closed e1205815834778 ∧ code e1205815834778 = 5603862345882 := by decide
theorem cert_e1205815834778 : check e1205815834778 [[],[]] .chain = true := by decide
def e1205815834822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205815834822 : Closed e1205815834822 ∧ code e1205815834822 = 5603862345926 := by decide
theorem cert_e1205815834822 : check e1205815834822 [[],[]] .chain = true := by decide
def e1205815835018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205815835018 : Closed e1205815835018 ∧ code e1205815835018 = 5603862346122 := by decide
theorem cert_e1205815835018 : check e1205815835018 [[],[]] .chain = true := by decide
def e1205815835042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205815835042 : Closed e1205815835042 ∧ code e1205815835042 = 5603862346146 := by decide
theorem cert_e1205815835042 : check e1205815835042 [[],[]] .chain = true := by decide
def e1205815835054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1205815835054 : Closed e1205815835054 ∧ code e1205815835054 = 5603862346158 := by decide
theorem cert_e1205815835054 : check e1205815835054 [[],[]] .sourceHead = true := by decide
def e1205815835062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1205815835062 : Closed e1205815835062 ∧ code e1205815835062 = 5603862346166 := by decide
theorem cert_e1205815835062 : check e1205815835062 [[],[]] .chain = true := by decide
def e1205815835066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1205815835066 : Closed e1205815835066 ∧ code e1205815835066 = 5603862346170 := by decide
theorem cert_e1205815835066 : check e1205815835066 [[],[]] .sourceHead = true := by decide
def e1205815835094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1205815835094 : Closed e1205815835094 ∧ code e1205815835094 = 5603862346198 := by decide
theorem cert_e1205815835094 : check e1205815835094 [[],[]] .chain = true := by decide
def e1205815835098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1205815835098 : Closed e1205815835098 ∧ code e1205815835098 = 5603862346202 := by decide
theorem cert_e1205815835098 : check e1205815835098 [[],[]] .chain = true := by decide
def e1205815835114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1205815835114 : Closed e1205815835114 ∧ code e1205815835114 = 5603862346218 := by decide
theorem cert_e1205815835114 : check e1205815835114 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
