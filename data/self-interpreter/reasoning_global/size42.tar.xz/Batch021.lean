import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e350578248922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e350578248922 : Closed e350578248922 ∧ code e350578248922 = 4748624760026 := by decide
theorem cert_e350578248922 : check e350578248922 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578248938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e350578248938 : Closed e350578248938 ∧ code e350578248938 = 4748624760042 := by decide
theorem cert_e350578248938 : check e350578248938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578249322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e350578249322 : Closed e350578249322 ∧ code e350578249322 = 4748624760426 := by decide
theorem cert_e350578249322 : check e350578249322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578251994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e350578251994 : Closed e350578251994 ∧ code e350578251994 = 4748624763098 := by decide
theorem cert_e350578251994 : check e350578251994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e350578252010 : Closed e350578252010 ∧ code e350578252010 = 4748624763114 := by decide
theorem cert_e350578252010 : check e350578252010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578252346 : Closed e350578252346 ∧ code e350578252346 = 4748624763450 := by decide
theorem cert_e350578252346 : check e350578252346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252486 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578252486 : Closed e350578252486 ∧ code e350578252486 = 4748624763590 := by decide
theorem cert_e350578252486 : check e350578252486 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578252570 : Closed e350578252570 ∧ code e350578252570 = 4748624763674 := by decide
theorem cert_e350578252570 : check e350578252570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252614 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578252614 : Closed e350578252614 ∧ code e350578252614 = 4748624763718 := by decide
theorem cert_e350578252614 : check e350578252614 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578252906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e350578252906 : Closed e350578252906 ∧ code e350578252906 = 4748624764010 := by decide
theorem cert_e350578252906 : check e350578252906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578253082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578253082 : Closed e350578253082 ∧ code e350578253082 = 4748624764186 := by decide
theorem cert_e350578253082 : check e350578253082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578253126 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578253126 : Closed e350578253126 ∧ code e350578253126 = 4748624764230 := by decide
theorem cert_e350578253126 : check e350578253126 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578255418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578255418 : Closed e350578255418 ∧ code e350578255418 = 4748624766522 := by decide
theorem cert_e350578255418 : check e350578255418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578255558 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578255558 : Closed e350578255558 ∧ code e350578255558 = 4748624766662 := by decide
theorem cert_e350578255558 : check e350578255558 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578255642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578255642 : Closed e350578255642 ∧ code e350578255642 = 4748624766746 := by decide
theorem cert_e350578255642 : check e350578255642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578255686 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578255686 : Closed e350578255686 ∧ code e350578255686 = 4748624766790 := by decide
theorem cert_e350578255686 : check e350578255686 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578258714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578258714 : Closed e350578258714 ∧ code e350578258714 = 4748624769818 := by decide
theorem cert_e350578258714 : check e350578258714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578258758 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578258758 : Closed e350578258758 ∧ code e350578258758 = 4748624769862 := by decide
theorem cert_e350578258758 : check e350578258758 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578301818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e350578301818 : Closed e350578301818 ∧ code e350578301818 = 4748624812922 := by decide
theorem cert_e350578301818 : check e350578301818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578301914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e350578301914 : Closed e350578301914 ∧ code e350578301914 = 4748624813018 := by decide
theorem cert_e350578301914 : check e350578301914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578302330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e350578302330 : Closed e350578302330 ∧ code e350578302330 = 4748624813434 := by decide
theorem cert_e350578302330 : check e350578302330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578302442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e350578302442 : Closed e350578302442 ∧ code e350578302442 = 4748624813546 := by decide
theorem cert_e350578302442 : check e350578302442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578302810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350578302810 : Closed e350578302810 ∧ code e350578302810 = 4748624813914 := by decide
theorem cert_e350578302810 : check e350578302810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578302826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350578302826 : Closed e350578302826 ∧ code e350578302826 = 4748624813930 := by decide
theorem cert_e350578302826 : check e350578302826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578304890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e350578304890 : Closed e350578304890 ∧ code e350578304890 = 4748624815994 := by decide
theorem cert_e350578304890 : check e350578304890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578304986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e350578304986 : Closed e350578304986 ∧ code e350578304986 = 4748624816090 := by decide
theorem cert_e350578304986 : check e350578304986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578307962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e350578307962 : Closed e350578307962 ∧ code e350578307962 = 4748624819066 := by decide
theorem cert_e350578307962 : check e350578307962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578308074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e350578308074 : Closed e350578308074 ∧ code e350578308074 = 4748624819178 := by decide
theorem cert_e350578308074 : check e350578308074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578310362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350578310362 : Closed e350578310362 ∧ code e350578310362 = 4748624821466 := by decide
theorem cert_e350578310362 : check e350578310362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578310378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350578310378 : Closed e350578310378 ∧ code e350578310378 = 4748624821482 := by decide
theorem cert_e350578310378 : check e350578310378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578369466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e350578369466 : Closed e350578369466 ∧ code e350578369466 = 4748624880570 := by decide
theorem cert_e350578369466 : check e350578369466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578369498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e350578369498 : Closed e350578369498 ∧ code e350578369498 = 4748624880602 := by decide
theorem cert_e350578369498 : check e350578369498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578371706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578371706 : Closed e350578371706 ∧ code e350578371706 = 4748624882810 := by decide
theorem cert_e350578371706 : check e350578371706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578372038 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578372038 : Closed e350578372038 ∧ code e350578372038 = 4748624883142 := by decide
theorem cert_e350578372038 : check e350578372038 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578372154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578372154 : Closed e350578372154 ∧ code e350578372154 = 4748624883258 := by decide
theorem cert_e350578372154 : check e350578372154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578372294 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578372294 : Closed e350578372294 ∧ code e350578372294 = 4748624883398 := by decide
theorem cert_e350578372294 : check e350578372294 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578373050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350578373050 : Closed e350578373050 ∧ code e350578373050 = 4748624884154 := by decide
theorem cert_e350578373050 : check e350578373050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578373098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350578373098 : Closed e350578373098 ∧ code e350578373098 = 4748624884202 := by decide
theorem cert_e350578373098 : check e350578373098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578373754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578373754 : Closed e350578373754 ∧ code e350578373754 = 4748624884858 := by decide
theorem cert_e350578373754 : check e350578373754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578374086 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578374086 : Closed e350578374086 ∧ code e350578374086 = 4748624885190 := by decide
theorem cert_e350578374086 : check e350578374086 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578374426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578374426 : Closed e350578374426 ∧ code e350578374426 = 4748624885530 := by decide
theorem cert_e350578374426 : check e350578374426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578374470 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578374470 : Closed e350578374470 ∧ code e350578374470 = 4748624885574 := by decide
theorem cert_e350578374470 : check e350578374470 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578374874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350578374874 : Closed e350578374874 ∧ code e350578374874 = 4748624885978 := by decide
theorem cert_e350578374874 : check e350578374874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578374890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e350578374890 : Closed e350578374890 ∧ code e350578374890 = 4748624885994 := by decide
theorem cert_e350578374890 : check e350578374890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578375226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578375226 : Closed e350578375226 ∧ code e350578375226 = 4748624886330 := by decide
theorem cert_e350578375226 : check e350578375226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578375366 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578375366 : Closed e350578375366 ∧ code e350578375366 = 4748624886470 := by decide
theorem cert_e350578375366 : check e350578375366 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578375450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578375450 : Closed e350578375450 ∧ code e350578375450 = 4748624886554 := by decide
theorem cert_e350578375450 : check e350578375450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578375494 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578375494 : Closed e350578375494 ∧ code e350578375494 = 4748624886598 := by decide
theorem cert_e350578375494 : check e350578375494 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578383994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350578383994 : Closed e350578383994 ∧ code e350578383994 = 4748624895098 := by decide
theorem cert_e350578383994 : check e350578383994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578384326 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350578384326 : Closed e350578384326 ∧ code e350578384326 = 4748624895430 := by decide
theorem cert_e350578384326 : check e350578384326 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578384442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350578384442 : Closed e350578384442 ∧ code e350578384442 = 4748624895546 := by decide
theorem cert_e350578384442 : check e350578384442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578384582 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350578384582 : Closed e350578384582 ∧ code e350578384582 = 4748624895686 := by decide
theorem cert_e350578384582 : check e350578384582 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578396282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350578396282 : Closed e350578396282 ∧ code e350578396282 = 4748624907386 := by decide
theorem cert_e350578396282 : check e350578396282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578396614 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350578396614 : Closed e350578396614 ∧ code e350578396614 = 4748624907718 := by decide
theorem cert_e350578396614 : check e350578396614 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578396954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578396954 : Closed e350578396954 ∧ code e350578396954 = 4748624908058 := by decide
theorem cert_e350578396954 : check e350578396954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578396998 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578396998 : Closed e350578396998 ∧ code e350578396998 = 4748624908102 := by decide
theorem cert_e350578396998 : check e350578396998 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578402874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350578402874 : Closed e350578402874 ∧ code e350578402874 = 4748624913978 := by decide
theorem cert_e350578402874 : check e350578402874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578403014 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350578403014 : Closed e350578403014 ∧ code e350578403014 = 4748624914118 := by decide
theorem cert_e350578403014 : check e350578403014 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578403098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578403098 : Closed e350578403098 ∧ code e350578403098 = 4748624914202 := by decide
theorem cert_e350578403098 : check e350578403098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578403142 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578403142 : Closed e350578403142 ∧ code e350578403142 = 4748624914246 := by decide
theorem cert_e350578403142 : check e350578403142 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578552250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e350578552250 : Closed e350578552250 ∧ code e350578552250 = 4748625063354 := by decide
theorem cert_e350578552250 : check e350578552250 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578552282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e350578552282 : Closed e350578552282 ∧ code e350578552282 = 4748625063386 := by decide
theorem cert_e350578552282 : check e350578552282 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578552506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e350578552506 : Closed e350578552506 ∧ code e350578552506 = 4748625063610 := by decide
theorem cert_e350578552506 : check e350578552506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578552554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e350578552554 : Closed e350578552554 ∧ code e350578552554 = 4748625063658 := by decide
theorem cert_e350578552554 : check e350578552554 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578552666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350578552666 : Closed e350578552666 ∧ code e350578552666 = 4748625063770 := by decide
theorem cert_e350578552666 : check e350578552666 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578552682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350578552682 : Closed e350578552682 ∧ code e350578552682 = 4748625063786 := by decide
theorem cert_e350578552682 : check e350578552682 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578553786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e350578553786 : Closed e350578553786 ∧ code e350578553786 = 4748625064890 := by decide
theorem cert_e350578553786 : check e350578553786 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578553818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e350578553818 : Closed e350578553818 ∧ code e350578553818 = 4748625064922 := by decide
theorem cert_e350578553818 : check e350578553818 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578555322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e350578555322 : Closed e350578555322 ∧ code e350578555322 = 4748625066426 := by decide
theorem cert_e350578555322 : check e350578555322 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578555370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e350578555370 : Closed e350578555370 ∧ code e350578555370 = 4748625066474 := by decide
theorem cert_e350578555370 : check e350578555370 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578556122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350578556122 : Closed e350578556122 ∧ code e350578556122 = 4748625067226 := by decide
theorem cert_e350578556122 : check e350578556122 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578556138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350578556138 : Closed e350578556138 ∧ code e350578556138 = 4748625067242 := by decide
theorem cert_e350578556138 : check e350578556138 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350578586042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350578586042 : Closed e350578586042 ∧ code e350578586042 = 4748625097146 := by decide
theorem cert_e350578586042 : check e350578586042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578586090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350578586090 : Closed e350578586090 ∧ code e350578586090 = 4748625097194 := by decide
theorem cert_e350578586090 : check e350578586090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578586746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578586746 : Closed e350578586746 ∧ code e350578586746 = 4748625097850 := by decide
theorem cert_e350578586746 : check e350578586746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578587078 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578587078 : Closed e350578587078 ∧ code e350578587078 = 4748625098182 := by decide
theorem cert_e350578587078 : check e350578587078 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578587418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578587418 : Closed e350578587418 ∧ code e350578587418 = 4748625098522 := by decide
theorem cert_e350578587418 : check e350578587418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578587462 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578587462 : Closed e350578587462 ∧ code e350578587462 = 4748625098566 := by decide
theorem cert_e350578587462 : check e350578587462 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578588778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350578588778 : Closed e350578588778 ∧ code e350578588778 = 4748625099882 := by decide
theorem cert_e350578588778 : check e350578588778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578588954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578588954 : Closed e350578588954 ∧ code e350578588954 = 4748625100058 := by decide
theorem cert_e350578588954 : check e350578588954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578588998 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578588998 : Closed e350578588998 ∧ code e350578588998 = 4748625100102 := by decide
theorem cert_e350578588998 : check e350578588998 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578592890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350578592890 : Closed e350578592890 ∧ code e350578592890 = 4748625103994 := by decide
theorem cert_e350578592890 : check e350578592890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578593222 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350578593222 : Closed e350578593222 ∧ code e350578593222 = 4748625104326 := by decide
theorem cert_e350578593222 : check e350578593222 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578593562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578593562 : Closed e350578593562 ∧ code e350578593562 = 4748625104666 := by decide
theorem cert_e350578593562 : check e350578593562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578593606 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578593606 : Closed e350578593606 ∧ code e350578593606 = 4748625104710 := by decide
theorem cert_e350578593606 : check e350578593606 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578602778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578602778 : Closed e350578602778 ∧ code e350578602778 = 4748625113882 := by decide
theorem cert_e350578602778 : check e350578602778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578602822 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578602822 : Closed e350578602822 ∧ code e350578602822 = 4748625113926 := by decide
theorem cert_e350578602822 : check e350578602822 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350578694362 : Closed e350578694362 ∧ code e350578694362 = 4748625205466 := by decide
theorem cert_e350578694362 : check e350578694362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e350578694378 : Closed e350578694378 ∧ code e350578694378 = 4748625205482 := by decide
theorem cert_e350578694378 : check e350578694378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578694714 : Closed e350578694714 ∧ code e350578694714 = 4748625205818 := by decide
theorem cert_e350578694714 : check e350578694714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694854 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578694854 : Closed e350578694854 ∧ code e350578694854 = 4748625205958 := by decide
theorem cert_e350578694854 : check e350578694854 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578694938 : Closed e350578694938 ∧ code e350578694938 = 4748625206042 := by decide
theorem cert_e350578694938 : check e350578694938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578694982 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578694982 : Closed e350578694982 ∧ code e350578694982 = 4748625206086 := by decide
theorem cert_e350578694982 : check e350578694982 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578695274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350578695274 : Closed e350578695274 ∧ code e350578695274 = 4748625206378 := by decide
theorem cert_e350578695274 : check e350578695274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578695450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578695450 : Closed e350578695450 ∧ code e350578695450 = 4748625206554 := by decide
theorem cert_e350578695450 : check e350578695450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578695494 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578695494 : Closed e350578695494 ∧ code e350578695494 = 4748625206598 := by decide
theorem cert_e350578695494 : check e350578695494 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578697786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350578697786 : Closed e350578697786 ∧ code e350578697786 = 4748625208890 := by decide
theorem cert_e350578697786 : check e350578697786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578697926 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350578697926 : Closed e350578697926 ∧ code e350578697926 = 4748625209030 := by decide
theorem cert_e350578697926 : check e350578697926 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578698010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578698010 : Closed e350578698010 ∧ code e350578698010 = 4748625209114 := by decide
theorem cert_e350578698010 : check e350578698010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578698054 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578698054 : Closed e350578698054 ∧ code e350578698054 = 4748625209158 := by decide
theorem cert_e350578698054 : check e350578698054 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578701082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350578701082 : Closed e350578701082 ∧ code e350578701082 = 4748625212186 := by decide
theorem cert_e350578701082 : check e350578701082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578701126 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350578701126 : Closed e350578701126 ∧ code e350578701126 = 4748625212230 := by decide
theorem cert_e350578701126 : check e350578701126 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583088058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e350583088058 : Closed e350583088058 ∧ code e350583088058 = 4748629599162 := by decide
theorem cert_e350583088058 : check e350583088058 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583088090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e350583088090 : Closed e350583088090 ∧ code e350583088090 = 4748629599194 := by decide
theorem cert_e350583088090 : check e350583088090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583090298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350583090298 : Closed e350583090298 ∧ code e350583090298 = 4748629601402 := by decide
theorem cert_e350583090298 : check e350583090298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583090630 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350583090630 : Closed e350583090630 ∧ code e350583090630 = 4748629601734 := by decide
theorem cert_e350583090630 : check e350583090630 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583090746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350583090746 : Closed e350583090746 ∧ code e350583090746 = 4748629601850 := by decide
theorem cert_e350583090746 : check e350583090746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583090886 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350583090886 : Closed e350583090886 ∧ code e350583090886 = 4748629601990 := by decide
theorem cert_e350583090886 : check e350583090886 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583091642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350583091642 : Closed e350583091642 ∧ code e350583091642 = 4748629602746 := by decide
theorem cert_e350583091642 : check e350583091642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583091690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350583091690 : Closed e350583091690 ∧ code e350583091690 = 4748629602794 := by decide
theorem cert_e350583091690 : check e350583091690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583092346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350583092346 : Closed e350583092346 ∧ code e350583092346 = 4748629603450 := by decide
theorem cert_e350583092346 : check e350583092346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583092678 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350583092678 : Closed e350583092678 ∧ code e350583092678 = 4748629603782 := by decide
theorem cert_e350583092678 : check e350583092678 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350583093018 : Closed e350583093018 ∧ code e350583093018 = 4748629604122 := by decide
theorem cert_e350583093018 : check e350583093018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093062 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350583093062 : Closed e350583093062 ∧ code e350583093062 = 4748629604166 := by decide
theorem cert_e350583093062 : check e350583093062 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350583093466 : Closed e350583093466 ∧ code e350583093466 = 4748629604570 := by decide
theorem cert_e350583093466 : check e350583093466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e350583093482 : Closed e350583093482 ∧ code e350583093482 = 4748629604586 := by decide
theorem cert_e350583093482 : check e350583093482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350583093818 : Closed e350583093818 ∧ code e350583093818 = 4748629604922 := by decide
theorem cert_e350583093818 : check e350583093818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583093958 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350583093958 : Closed e350583093958 ∧ code e350583093958 = 4748629605062 := by decide
theorem cert_e350583093958 : check e350583093958 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583094042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350583094042 : Closed e350583094042 ∧ code e350583094042 = 4748629605146 := by decide
theorem cert_e350583094042 : check e350583094042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583094086 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350583094086 : Closed e350583094086 ∧ code e350583094086 = 4748629605190 := by decide
theorem cert_e350583094086 : check e350583094086 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583102586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350583102586 : Closed e350583102586 ∧ code e350583102586 = 4748629613690 := by decide
theorem cert_e350583102586 : check e350583102586 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583102918 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350583102918 : Closed e350583102918 ∧ code e350583102918 = 4748629614022 := by decide
theorem cert_e350583102918 : check e350583102918 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583103034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350583103034 : Closed e350583103034 ∧ code e350583103034 = 4748629614138 := by decide
theorem cert_e350583103034 : check e350583103034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583103174 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350583103174 : Closed e350583103174 ∧ code e350583103174 = 4748629614278 := by decide
theorem cert_e350583103174 : check e350583103174 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583114874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350583114874 : Closed e350583114874 ∧ code e350583114874 = 4748629625978 := by decide
theorem cert_e350583114874 : check e350583114874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583115206 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350583115206 : Closed e350583115206 ∧ code e350583115206 = 4748629626310 := by decide
theorem cert_e350583115206 : check e350583115206 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583115546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350583115546 : Closed e350583115546 ∧ code e350583115546 = 4748629626650 := by decide
theorem cert_e350583115546 : check e350583115546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583115590 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350583115590 : Closed e350583115590 ∧ code e350583115590 = 4748629626694 := by decide
theorem cert_e350583115590 : check e350583115590 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583121466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350583121466 : Closed e350583121466 ∧ code e350583121466 = 4748629632570 := by decide
theorem cert_e350583121466 : check e350583121466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583121606 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350583121606 : Closed e350583121606 ∧ code e350583121606 = 4748629632710 := by decide
theorem cert_e350583121606 : check e350583121606 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583121690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350583121690 : Closed e350583121690 ∧ code e350583121690 = 4748629632794 := by decide
theorem cert_e350583121690 : check e350583121690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350583121734 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350583121734 : Closed e350583121734 ∧ code e350583121734 = 4748629632838 := by decide
theorem cert_e350583121734 : check e350583121734 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350601894778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e350601894778 : Closed e350601894778 ∧ code e350601894778 = 4748648405882 := by decide
theorem cert_e350601894778 : check e350601894778 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601894874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e350601894874 : Closed e350601894874 ∧ code e350601894874 = 4748648405978 := by decide
theorem cert_e350601894874 : check e350601894874 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601895290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e350601895290 : Closed e350601895290 ∧ code e350601895290 = 4748648406394 := by decide
theorem cert_e350601895290 : check e350601895290 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601895402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e350601895402 : Closed e350601895402 ∧ code e350601895402 = 4748648406506 := by decide
theorem cert_e350601895402 : check e350601895402 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601895770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350601895770 : Closed e350601895770 ∧ code e350601895770 = 4748648406874 := by decide
theorem cert_e350601895770 : check e350601895770 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601895786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350601895786 : Closed e350601895786 ∧ code e350601895786 = 4748648406890 := by decide
theorem cert_e350601895786 : check e350601895786 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601897850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e350601897850 : Closed e350601897850 ∧ code e350601897850 = 4748648408954 := by decide
theorem cert_e350601897850 : check e350601897850 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601897946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e350601897946 : Closed e350601897946 ∧ code e350601897946 = 4748648409050 := by decide
theorem cert_e350601897946 : check e350601897946 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601900922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e350601900922 : Closed e350601900922 ∧ code e350601900922 = 4748648412026 := by decide
theorem cert_e350601900922 : check e350601900922 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601901034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e350601901034 : Closed e350601901034 ∧ code e350601901034 = 4748648412138 := by decide
theorem cert_e350601901034 : check e350601901034 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601903322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350601903322 : Closed e350601903322 ∧ code e350601903322 = 4748648414426 := by decide
theorem cert_e350601903322 : check e350601903322 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601903338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350601903338 : Closed e350601903338 ∧ code e350601903338 = 4748648414442 := by decide
theorem cert_e350601903338 : check e350601903338 [[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601962426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e350601962426 : Closed e350601962426 ∧ code e350601962426 = 4748648473530 := by decide
theorem cert_e350601962426 : check e350601962426 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601962458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e350601962458 : Closed e350601962458 ∧ code e350601962458 = 4748648473562 := by decide
theorem cert_e350601962458 : check e350601962458 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601964666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350601964666 : Closed e350601964666 ∧ code e350601964666 = 4748648475770 := by decide
theorem cert_e350601964666 : check e350601964666 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601964998 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350601964998 : Closed e350601964998 ∧ code e350601964998 = 4748648476102 := by decide
theorem cert_e350601964998 : check e350601964998 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e350601965114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350601965114 : Closed e350601965114 ∧ code e350601965114 = 4748648476218 := by decide
theorem cert_e350601965114 : check e350601965114 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601965254 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350601965254 : Closed e350601965254 ∧ code e350601965254 = 4748648476358 := by decide
theorem cert_e350601965254 : check e350601965254 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e350601966010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350601966010 : Closed e350601966010 ∧ code e350601966010 = 4748648477114 := by decide
theorem cert_e350601966010 : check e350601966010 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e350601966058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350601966058 : Closed e350601966058 ∧ code e350601966058 = 4748648477162 := by decide
theorem cert_e350601966058 : check e350601966058 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e350601966714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350601966714 : Closed e350601966714 ∧ code e350601966714 = 4748648477818 := by decide
theorem cert_e350601966714 : check e350601966714 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601967046 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350601967046 : Closed e350601967046 ∧ code e350601967046 = 4748648478150 := by decide
theorem cert_e350601967046 : check e350601967046 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e350601967386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350601967386 : Closed e350601967386 ∧ code e350601967386 = 4748648478490 := by decide
private def t_e350601967386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem cert_e350601967386 : ¬ IsSelfInterpreter e350601967386 :=
  wSource (t := t_e350601967386) (replay_sound (ps := []) (t := e350601967386) (by decide)) (by decide)
def e350601967430 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350601967430 : Closed e350601967430 ∧ code e350601967430 = 4748648478534 := by decide
private def t_e350601967430 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem cert_e350601967430 : ¬ IsSelfInterpreter e350601967430 :=
  wSource (t := t_e350601967430) (replay_sound (ps := []) (t := e350601967430) (by decide)) (by decide)
def e350601967834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350601967834 : Closed e350601967834 ∧ code e350601967834 = 4748648478938 := by decide
theorem cert_e350601967834 : check e350601967834 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e350601967850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e350601967850 : Closed e350601967850 ∧ code e350601967850 = 4748648478954 := by decide
theorem cert_e350601967850 : check e350601967850 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e350601968186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350601968186 : Closed e350601968186 ∧ code e350601968186 = 4748648479290 := by decide
theorem cert_e350601968186 : check e350601968186 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e350601968326 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350601968326 : Closed e350601968326 ∧ code e350601968326 = 4748648479430 := by decide
theorem cert_e350601968326 : check e350601968326 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor42
