import R1209577550766Data
namespace Certgen.R1209577550766
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl1224 : FloorIndex.rangeOK validState 1224 12 = true := by decide +kernel
theorem bl1236 : FloorIndex.rangeOK validState 1236 12 = true := by decide +kernel
theorem bl1248 : FloorIndex.rangeOK validState 1248 12 = true := by decide +kernel
theorem bl1260 : FloorIndex.rangeOK validState 1260 5 = true := by decide +kernel
end Certgen.R1209577550766
