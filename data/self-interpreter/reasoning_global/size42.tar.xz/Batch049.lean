import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1129774424090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129774424090 : Closed e1129774424090 ∧ code e1129774424090 = 5527820935194 := by decide
theorem cert_e1129774424090 : check e1129774424090 [[]] .width = true := by decide
def e1129774424182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129774424182 : Closed e1129774424182 ∧ code e1129774424182 = 5527820935286 := by decide
theorem cert_e1129774424182 : check e1129774424182 [[]] .width = true := by decide
def e1129774424426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129774424426 : Closed e1129774424426 ∧ code e1129774424426 = 5527820935530 := by decide
theorem cert_e1129774424426 : check e1129774424426 [[]] .width = true := by decide
def e1129774424474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129774424474 : Closed e1129774424474 ∧ code e1129774424474 = 5527820935578 := by decide
theorem cert_e1129774424474 : check e1129774424474 [[]] .width = true := by decide
def e1129774428358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129774428358 : Closed e1129774428358 ∧ code e1129774428358 = 5527820939462 := by decide
theorem cert_e1129774428358 : check e1129774428358 [[]] .width = true := by decide
def e1129774430234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774430234 : Closed e1129774430234 ∧ code e1129774430234 = 5527820941338 := by decide
theorem cert_e1129774430234 : check e1129774430234 [[]] .width = true := by decide
def e1129774438426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774438426 : Closed e1129774438426 ∧ code e1129774438426 = 5527820949530 := by decide
theorem cert_e1129774438426 : check e1129774438426 [[]] .width = true := by decide
def e1129774489626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129774489626 : Closed e1129774489626 ∧ code e1129774489626 = 5527821000730 := by decide
theorem cert_e1129774489626 : check e1129774489626 [[]] .width = true := by decide
def e1129774489718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129774489718 : Closed e1129774489718 ∧ code e1129774489718 = 5527821000822 := by decide
theorem cert_e1129774489718 : check e1129774489718 [[]] .width = true := by decide
def e1129774489962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129774489962 : Closed e1129774489962 ∧ code e1129774489962 = 5527821001066 := by decide
theorem cert_e1129774489962 : check e1129774489962 [[]] .width = true := by decide
def e1129774490010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129774490010 : Closed e1129774490010 ∧ code e1129774490010 = 5527821001114 := by decide
theorem cert_e1129774490010 : check e1129774490010 [[]] .width = true := by decide
def e1129774493894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129774493894 : Closed e1129774493894 ∧ code e1129774493894 = 5527821004998 := by decide
theorem cert_e1129774493894 : check e1129774493894 [[]] .width = true := by decide
def e1129774495770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774495770 : Closed e1129774495770 ∧ code e1129774495770 = 5527821006874 := by decide
theorem cert_e1129774495770 : check e1129774495770 [[]] .width = true := by decide
def e1129774502086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129774502086 : Closed e1129774502086 ∧ code e1129774502086 = 5527821013190 := by decide
theorem cert_e1129774502086 : check e1129774502086 [[]] .width = true := by decide
def e1129774508058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774508058 : Closed e1129774508058 ∧ code e1129774508058 = 5527821019162 := by decide
theorem cert_e1129774508058 : check e1129774508058 [[]] .width = true := by decide
def e1129774536730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774536730 : Closed e1129774536730 ∧ code e1129774536730 = 5527821047834 := by decide
theorem cert_e1129774536730 : check e1129774536730 [[]] .width = true := by decide
def e1129774540826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774540826 : Closed e1129774540826 ∧ code e1129774540826 = 5527821051930 := by decide
theorem cert_e1129774540826 : check e1129774540826 [[]] .width = true := by decide
def e1129774694598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129774694598 : Closed e1129774694598 ∧ code e1129774694598 = 5527821205702 := by decide
theorem cert_e1129774694598 : check e1129774694598 [[]] .width = true := by decide
def e1129774800922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129774800922 : Closed e1129774800922 ∧ code e1129774800922 = 5527821312026 := by decide
theorem cert_e1129774800922 : check e1129774800922 [[]] .width = true := by decide
def e1129774801014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129774801014 : Closed e1129774801014 ∧ code e1129774801014 = 5527821312118 := by decide
private def t_e1129774801014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129774801014 : ¬ IsSelfInterpreter e1129774801014 :=
  wSource (t := t_e1129774801014) (replay_sound (ps := []) (t := e1129774801014) (by decide)) (by decide)
def e1129774801258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129774801258 : Closed e1129774801258 ∧ code e1129774801258 = 5527821312362 := by decide
private def t_e1129774801258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129774801258 : ¬ IsSelfInterpreter e1129774801258 :=
  wSource (t := t_e1129774801258) (replay_sound (ps := []) (t := e1129774801258) (by decide)) (by decide)
def e1129774801306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129774801306 : Closed e1129774801306 ∧ code e1129774801306 = 5527821312410 := by decide
private def t_e1129774801306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129774801306 : ¬ IsSelfInterpreter e1129774801306 :=
  wSource (t := t_e1129774801306) (replay_sound (ps := []) (t := e1129774801306) (by decide)) (by decide)
def e1129774817306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129774817306 : Closed e1129774817306 ∧ code e1129774817306 = 5527821328410 := by decide
theorem cert_e1129774817306 : check e1129774817306 [[]] .width = true := by decide
def e1129774817398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129774817398 : Closed e1129774817398 ∧ code e1129774817398 = 5527821328502 := by decide
private def t_e1129774817398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129774817398 : ¬ IsSelfInterpreter e1129774817398 :=
  wSource (t := t_e1129774817398) (replay_sound (ps := []) (t := e1129774817398) (by decide)) (by decide)
def e1129774817642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129774817642 : Closed e1129774817642 ∧ code e1129774817642 = 5527821328746 := by decide
private def t_e1129774817642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129774817642 : ¬ IsSelfInterpreter e1129774817642 :=
  wSource (t := t_e1129774817642) (replay_sound (ps := []) (t := e1129774817642) (by decide)) (by decide)
def e1129774817690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129774817690 : Closed e1129774817690 ∧ code e1129774817690 = 5527821328794 := by decide
private def t_e1129774817690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129774817690 : ¬ IsSelfInterpreter e1129774817690 :=
  wSource (t := t_e1129774817690) (replay_sound (ps := []) (t := e1129774817690) (by decide)) (by decide)
def e1129774821574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129774821574 : Closed e1129774821574 ∧ code e1129774821574 = 5527821332678 := by decide
theorem cert_e1129774821574 : check e1129774821574 [[]] .width = true := by decide
def e1129774823450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774823450 : Closed e1129774823450 ∧ code e1129774823450 = 5527821334554 := by decide
theorem cert_e1129774823450 : check e1129774823450 [[]] .width = true := by decide
def e1129774831642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129774831642 : Closed e1129774831642 ∧ code e1129774831642 = 5527821342746 := by decide
theorem cert_e1129774831642 : check e1129774831642 [[]] .width = true := by decide
def e1129774972954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129774972954 : Closed e1129774972954 ∧ code e1129774972954 = 5527821484058 := by decide
theorem cert_e1129774972954 : check e1129774972954 [[]] .width = true := by decide
def e1129774973046 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129774973046 : Closed e1129774973046 ∧ code e1129774973046 = 5527821484150 := by decide
theorem cert_e1129774973046 : check e1129774973046 [[]] .width = true := by decide
def e1129774973290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129774973290 : Closed e1129774973290 ∧ code e1129774973290 = 5527821484394 := by decide
theorem cert_e1129774973290 : check e1129774973290 [[]] .width = true := by decide
def e1129774973338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129774973338 : Closed e1129774973338 ∧ code e1129774973338 = 5527821484442 := by decide
theorem cert_e1129774973338 : check e1129774973338 [[]] .width = true := by decide
def e1129774973422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129774973422 : Closed e1129774973422 ∧ code e1129774973422 = 5527821484526 := by decide
private def t_e1129774973422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e1129774973422 : ¬ IsSelfInterpreter e1129774973422 :=
  wSource (t := t_e1129774973422) (replay_sound (ps := []) (t := e1129774973422) (by decide)) (by decide)
def e1129774974346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129774974346 : Closed e1129774974346 ∧ code e1129774974346 = 5527821485450 := by decide
theorem cert_e1129774974346 : check e1129774974346 [[]] .width = true := by decide
def e1129774974370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129774974370 : Closed e1129774974370 ∧ code e1129774974370 = 5527821485474 := by decide
theorem cert_e1129774974370 : check e1129774974370 [[]] .width = true := by decide
def e1129774974390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129774974390 : Closed e1129774974390 ∧ code e1129774974390 = 5527821485494 := by decide
theorem cert_e1129774974390 : check e1129774974390 [[]] .width = true := by decide
def e1129774974422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129774974422 : Closed e1129774974422 ∧ code e1129774974422 = 5527821485526 := by decide
theorem cert_e1129774974422 : check e1129774974422 [[]] .width = true := by decide
def e1129774974426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129774974426 : Closed e1129774974426 ∧ code e1129774974426 = 5527821485530 := by decide
private def t_e1129774974426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e1129774974426 : ¬ IsSelfInterpreter e1129774974426 :=
  wSource (t := t_e1129774974426) (replay_sound (ps := []) (t := e1129774974426) (by decide)) (by decide)
def e1129774974478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129774974478 : Closed e1129774974478 ∧ code e1129774974478 = 5527821485582 := by decide
theorem cert_e1129774974478 : check e1129774974478 [[]] .width = true := by decide
def e1129774974490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129774974490 : Closed e1129774974490 ∧ code e1129774974490 = 5527821485594 := by decide
theorem cert_e1129774974490 : check e1129774974490 [[]] .width = true := by decide
def e1129774974562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129774974562 : Closed e1129774974562 ∧ code e1129774974562 = 5527821485666 := by decide
theorem cert_e1129774974562 : check e1129774974562 [[]] .width = true := by decide
def e1129774974582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129774974582 : Closed e1129774974582 ∧ code e1129774974582 = 5527821485686 := by decide
theorem cert_e1129774974582 : check e1129774974582 [[]] .width = true := by decide
def e1129774974774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129774974774 : Closed e1129774974774 ∧ code e1129774974774 = 5527821485878 := by decide
theorem cert_e1129774974774 : check e1129774974774 [[]] .width = true := by decide
def e1129774974778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129774974778 : Closed e1129774974778 ∧ code e1129774974778 = 5527821485882 := by decide
theorem cert_e1129774974778 : check e1129774974778 [[]] .width = true := by decide
def e1129774978474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129774978474 : Closed e1129774978474 ∧ code e1129774978474 = 5527821489578 := by decide
private def t_e1129774978474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e1129774978474 : ¬ IsSelfInterpreter e1129774978474 :=
  wSource (t := t_e1129774978474) (replay_sound (ps := []) (t := e1129774978474) (by decide)) (by decide)
def e1129774978570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129774978570 : Closed e1129774978570 ∧ code e1129774978570 = 5527821489674 := by decide
theorem cert_e1129774978570 : check e1129774978570 [[]] .width = true := by decide
def e1129774978666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129774978666 : Closed e1129774978666 ∧ code e1129774978666 = 5527821489770 := by decide
private def t_e1129774978666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e1129774978666 : ¬ IsSelfInterpreter e1129774978666 :=
  wSource (t := t_e1129774978666) (replay_sound (ps := []) (t := e1129774978666) (by decide)) (by decide)
def e1129774978690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129774978690 : Closed e1129774978690 ∧ code e1129774978690 = 5527821489794 := by decide
private def t_e1129774978690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e1129774978690 : ¬ IsSelfInterpreter e1129774978690 :=
  wSource (t := t_e1129774978690) (replay_sound (ps := []) (t := e1129774978690) (by decide)) (by decide)
def e1129774978714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129774978714 : Closed e1129774978714 ∧ code e1129774978714 = 5527821489818 := by decide
private def t_e1129774978714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e1129774978714 : ¬ IsSelfInterpreter e1129774978714 :=
  wSource (t := t_e1129774978714) (replay_sound (ps := []) (t := e1129774978714) (by decide)) (by decide)
def e1129774979098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129774979098 : Closed e1129774979098 ∧ code e1129774979098 = 5527821490202 := by decide
theorem cert_e1129774979098 : check e1129774979098 [[]] .width = true := by decide
def e1129774979190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129774979190 : Closed e1129774979190 ∧ code e1129774979190 = 5527821490294 := by decide
private def t_e1129774979190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e1129774979190 : ¬ IsSelfInterpreter e1129774979190 :=
  wSource (t := t_e1129774979190) (replay_sound (ps := []) (t := e1129774979190) (by decide)) (by decide)
def e1129774979434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129774979434 : Closed e1129774979434 ∧ code e1129774979434 = 5527821490538 := by decide
private def t_e1129774979434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e1129774979434 : ¬ IsSelfInterpreter e1129774979434 :=
  wSource (t := t_e1129774979434) (replay_sound (ps := []) (t := e1129774979434) (by decide)) (by decide)
def e1129774979458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129774979458 : Closed e1129774979458 ∧ code e1129774979458 = 5527821490562 := by decide
theorem cert_e1129774979458 : check e1129774979458 [[]] .width = true := by decide
def e1129774979482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129774979482 : Closed e1129774979482 ∧ code e1129774979482 = 5527821490586 := by decide
private def t_e1129774979482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e1129774979482 : ¬ IsSelfInterpreter e1129774979482 :=
  wSource (t := t_e1129774979482) (replay_sound (ps := []) (t := e1129774979482) (by decide)) (by decide)
def e1129775153350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129775153350 : Closed e1129775153350 ∧ code e1129775153350 = 5527821664454 := by decide
theorem cert_e1129775153350 : check e1129775153350 [[]] .width = true := by decide
def e1129775210522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129775210522 : Closed e1129775210522 ∧ code e1129775210522 = 5527821721626 := by decide
theorem cert_e1129775210522 : check e1129775210522 [[]] .width = true := by decide
def e1129775210614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129775210614 : Closed e1129775210614 ∧ code e1129775210614 = 5527821721718 := by decide
theorem cert_e1129775210614 : check e1129775210614 [[]] .width = true := by decide
def e1129775210858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129775210858 : Closed e1129775210858 ∧ code e1129775210858 = 5527821721962 := by decide
theorem cert_e1129775210858 : check e1129775210858 [[]] .width = true := by decide
def e1129775210906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129775210906 : Closed e1129775210906 ∧ code e1129775210906 = 5527821722010 := by decide
theorem cert_e1129775210906 : check e1129775210906 [[]] .width = true := by decide
def e1129775214790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129775214790 : Closed e1129775214790 ∧ code e1129775214790 = 5527821725894 := by decide
theorem cert_e1129775214790 : check e1129775214790 [[]] .width = true := by decide
def e1129775216666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129775216666 : Closed e1129775216666 ∧ code e1129775216666 = 5527821727770 := by decide
theorem cert_e1129775216666 : check e1129775216666 [[]] .width = true := by decide
def e1129775222982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129775222982 : Closed e1129775222982 ∧ code e1129775222982 = 5527821734086 := by decide
theorem cert_e1129775222982 : check e1129775222982 [[]] .width = true := by decide
def e1129775228954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129775228954 : Closed e1129775228954 ∧ code e1129775228954 = 5527821740058 := by decide
theorem cert_e1129775228954 : check e1129775228954 [[]] .width = true := by decide
def e1129775235098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129775235098 : Closed e1129775235098 ∧ code e1129775235098 = 5527821746202 := by decide
theorem cert_e1129775235098 : check e1129775235098 [[]] .width = true := by decide
def e1129775235190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129775235190 : Closed e1129775235190 ∧ code e1129775235190 = 5527821746294 := by decide
theorem cert_e1129775235190 : check e1129775235190 [[]] .width = true := by decide
def e1129775235434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129775235434 : Closed e1129775235434 ∧ code e1129775235434 = 5527821746538 := by decide
theorem cert_e1129775235434 : check e1129775235434 [[]] .width = true := by decide
def e1129775235482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129775235482 : Closed e1129775235482 ∧ code e1129775235482 = 5527821746586 := by decide
theorem cert_e1129775235482 : check e1129775235482 [[]] .width = true := by decide
def e1129775235566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129775235566 : Closed e1129775235566 ∧ code e1129775235566 = 5527821746670 := by decide
theorem cert_e1129775235566 : check e1129775235566 [[]] .width = true := by decide
def e1129775236490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129775236490 : Closed e1129775236490 ∧ code e1129775236490 = 5527821747594 := by decide
theorem cert_e1129775236490 : check e1129775236490 [[]] .width = true := by decide
def e1129775236514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129775236514 : Closed e1129775236514 ∧ code e1129775236514 = 5527821747618 := by decide
theorem cert_e1129775236514 : check e1129775236514 [[]] .width = true := by decide
def e1129775236534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129775236534 : Closed e1129775236534 ∧ code e1129775236534 = 5527821747638 := by decide
theorem cert_e1129775236534 : check e1129775236534 [[]] .width = true := by decide
def e1129775236566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129775236566 : Closed e1129775236566 ∧ code e1129775236566 = 5527821747670 := by decide
theorem cert_e1129775236566 : check e1129775236566 [[]] .width = true := by decide
def e1129775236570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129775236570 : Closed e1129775236570 ∧ code e1129775236570 = 5527821747674 := by decide
theorem cert_e1129775236570 : check e1129775236570 [[]] .width = true := by decide
def e1129775236622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129775236622 : Closed e1129775236622 ∧ code e1129775236622 = 5527821747726 := by decide
theorem cert_e1129775236622 : check e1129775236622 [[]] .width = true := by decide
def e1129775236634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129775236634 : Closed e1129775236634 ∧ code e1129775236634 = 5527821747738 := by decide
theorem cert_e1129775236634 : check e1129775236634 [[]] .width = true := by decide
def e1129775236706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129775236706 : Closed e1129775236706 ∧ code e1129775236706 = 5527821747810 := by decide
theorem cert_e1129775236706 : check e1129775236706 [[]] .width = true := by decide
def e1129775236726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129775236726 : Closed e1129775236726 ∧ code e1129775236726 = 5527821747830 := by decide
theorem cert_e1129775236726 : check e1129775236726 [[]] .width = true := by decide
def e1129775236918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129775236918 : Closed e1129775236918 ∧ code e1129775236918 = 5527821748022 := by decide
theorem cert_e1129775236918 : check e1129775236918 [[]] .width = true := by decide
def e1129775236922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129775236922 : Closed e1129775236922 ∧ code e1129775236922 = 5527821748026 := by decide
theorem cert_e1129775236922 : check e1129775236922 [[]] .width = true := by decide
def e1129775240618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129775240618 : Closed e1129775240618 ∧ code e1129775240618 = 5527821751722 := by decide
theorem cert_e1129775240618 : check e1129775240618 [[]] .width = true := by decide
def e1129775240714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129775240714 : Closed e1129775240714 ∧ code e1129775240714 = 5527821751818 := by decide
theorem cert_e1129775240714 : check e1129775240714 [[]] .width = true := by decide
def e1129775240810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129775240810 : Closed e1129775240810 ∧ code e1129775240810 = 5527821751914 := by decide
theorem cert_e1129775240810 : check e1129775240810 [[]] .width = true := by decide
def e1129775240834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129775240834 : Closed e1129775240834 ∧ code e1129775240834 = 5527821751938 := by decide
theorem cert_e1129775240834 : check e1129775240834 [[]] .width = true := by decide
def e1129775240858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129775240858 : Closed e1129775240858 ∧ code e1129775240858 = 5527821751962 := by decide
theorem cert_e1129775240858 : check e1129775240858 [[]] .width = true := by decide
def e1129775241242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129775241242 : Closed e1129775241242 ∧ code e1129775241242 = 5527821752346 := by decide
theorem cert_e1129775241242 : check e1129775241242 [[]] .width = true := by decide
def e1129775241334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129775241334 : Closed e1129775241334 ∧ code e1129775241334 = 5527821752438 := by decide
theorem cert_e1129775241334 : check e1129775241334 [[]] .width = true := by decide
def e1129775241578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129775241578 : Closed e1129775241578 ∧ code e1129775241578 = 5527821752682 := by decide
theorem cert_e1129775241578 : check e1129775241578 [[]] .width = true := by decide
def e1129775241602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129775241602 : Closed e1129775241602 ∧ code e1129775241602 = 5527821752706 := by decide
theorem cert_e1129775241602 : check e1129775241602 [[]] .width = true := by decide
def e1129775241626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129775241626 : Closed e1129775241626 ∧ code e1129775241626 = 5527821752730 := by decide
theorem cert_e1129775241626 : check e1129775241626 [[]] .width = true := by decide
def e1129775421466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129775421466 : Closed e1129775421466 ∧ code e1129775421466 = 5527821932570 := by decide
theorem cert_e1129775421466 : check e1129775421466 [[]] .width = true := by decide
def e1129775425562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129775425562 : Closed e1129775425562 ∧ code e1129775425562 = 5527821936666 := by decide
theorem cert_e1129775425562 : check e1129775425562 [[]] .width = true := by decide
def e1129781780506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129781780506 : Closed e1129781780506 ∧ code e1129781780506 = 5527828291610 := by decide
theorem cert_e1129781780506 : check e1129781780506 [[]] .width = true := by decide
def e1129781780598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129781780598 : Closed e1129781780598 ∧ code e1129781780598 = 5527828291702 := by decide
theorem cert_e1129781780598 : check e1129781780598 [[]] .width = true := by decide
def e1129781780842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129781780842 : Closed e1129781780842 ∧ code e1129781780842 = 5527828291946 := by decide
theorem cert_e1129781780842 : check e1129781780842 [[]] .width = true := by decide
def e1129781780890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129781780890 : Closed e1129781780890 ∧ code e1129781780890 = 5527828291994 := by decide
theorem cert_e1129781780890 : check e1129781780890 [[]] .width = true := by decide
def e1129781846042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129781846042 : Closed e1129781846042 ∧ code e1129781846042 = 5527828357146 := by decide
theorem cert_e1129781846042 : check e1129781846042 [[]] .width = true := by decide
def e1129781846134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129781846134 : Closed e1129781846134 ∧ code e1129781846134 = 5527828357238 := by decide
theorem cert_e1129781846134 : check e1129781846134 [[]] .width = true := by decide
def e1129781846378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129781846378 : Closed e1129781846378 ∧ code e1129781846378 = 5527828357482 := by decide
theorem cert_e1129781846378 : check e1129781846378 [[]] .width = true := by decide
def e1129781846426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129781846426 : Closed e1129781846426 ∧ code e1129781846426 = 5527828357530 := by decide
theorem cert_e1129781846426 : check e1129781846426 [[]] .width = true := by decide
def e1129789710362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129789710362 : Closed e1129789710362 ∧ code e1129789710362 = 5527836221466 := by decide
theorem cert_e1129789710362 : check e1129789710362 [[]] .width = true := by decide
def e1129789710454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129789710454 : Closed e1129789710454 ∧ code e1129789710454 = 5527836221558 := by decide
theorem cert_e1129789710454 : check e1129789710454 [[]] .width = true := by decide
def e1129789710698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129789710698 : Closed e1129789710698 ∧ code e1129789710698 = 5527836221802 := by decide
theorem cert_e1129789710698 : check e1129789710698 [[]] .width = true := by decide
def e1129789710746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129789710746 : Closed e1129789710746 ∧ code e1129789710746 = 5527836221850 := by decide
theorem cert_e1129789710746 : check e1129789710746 [[]] .width = true := by decide
def e1129789743130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129789743130 : Closed e1129789743130 ∧ code e1129789743130 = 5527836254234 := by decide
theorem cert_e1129789743130 : check e1129789743130 [[]] .width = true := by decide
def e1129789743222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129789743222 : Closed e1129789743222 ∧ code e1129789743222 = 5527836254326 := by decide
private def t_e1129789743222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129789743222 : ¬ IsSelfInterpreter e1129789743222 :=
  wSource (t := t_e1129789743222) (replay_sound (ps := []) (t := e1129789743222) (by decide)) (by decide)
def e1129789743466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129789743466 : Closed e1129789743466 ∧ code e1129789743466 = 5527836254570 := by decide
private def t_e1129789743466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129789743466 : ¬ IsSelfInterpreter e1129789743466 :=
  wSource (t := t_e1129789743466) (replay_sound (ps := []) (t := e1129789743466) (by decide)) (by decide)
def e1129789743514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129789743514 : Closed e1129789743514 ∧ code e1129789743514 = 5527836254618 := by decide
private def t_e1129789743514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129789743514 : ¬ IsSelfInterpreter e1129789743514 :=
  wSource (t := t_e1129789743514) (replay_sound (ps := []) (t := e1129789743514) (by decide)) (by decide)
def e1129789972506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129789972506 : Closed e1129789972506 ∧ code e1129789972506 = 5527836483610 := by decide
theorem cert_e1129789972506 : check e1129789972506 [[]] .width = true := by decide
def e1129789972598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129789972598 : Closed e1129789972598 ∧ code e1129789972598 = 5527836483702 := by decide
theorem cert_e1129789972598 : check e1129789972598 [[]] .width = true := by decide
def e1129789972842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129789972842 : Closed e1129789972842 ∧ code e1129789972842 = 5527836483946 := by decide
theorem cert_e1129789972842 : check e1129789972842 [[]] .width = true := by decide
def e1129789972890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129789972890 : Closed e1129789972890 ∧ code e1129789972890 = 5527836483994 := by decide
theorem cert_e1129789972890 : check e1129789972890 [[]] .width = true := by decide
def e1129790009542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129790009542 : Closed e1129790009542 ∧ code e1129790009542 = 5527836520646 := by decide
theorem cert_e1129790009542 : check e1129790009542 [[]] .width = true := by decide
def e1129790021658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129790021658 : Closed e1129790021658 ∧ code e1129790021658 = 5527836532762 := by decide
theorem cert_e1129790021658 : check e1129790021658 [[]] .width = true := by decide
def e1129790021750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129790021750 : Closed e1129790021750 ∧ code e1129790021750 = 5527836532854 := by decide
theorem cert_e1129790021750 : check e1129790021750 [[]] .width = true := by decide
def e1129790021994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129790021994 : Closed e1129790021994 ∧ code e1129790021994 = 5527836533098 := by decide
theorem cert_e1129790021994 : check e1129790021994 [[]] .width = true := by decide
def e1129790022042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129790022042 : Closed e1129790022042 ∧ code e1129790022042 = 5527836533146 := by decide
theorem cert_e1129790022042 : check e1129790022042 [[]] .width = true := by decide
def e1129790025926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129790025926 : Closed e1129790025926 ∧ code e1129790025926 = 5527836537030 := by decide
theorem cert_e1129790025926 : check e1129790025926 [[]] .width = true := by decide
def e1129790027802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129790027802 : Closed e1129790027802 ∧ code e1129790027802 = 5527836538906 := by decide
theorem cert_e1129790027802 : check e1129790027802 [[]] .width = true := by decide
def e1129790136346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129790136346 : Closed e1129790136346 ∧ code e1129790136346 = 5527836647450 := by decide
theorem cert_e1129790136346 : check e1129790136346 [[]] .width = true := by decide
def e1129790136438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129790136438 : Closed e1129790136438 ∧ code e1129790136438 = 5527836647542 := by decide
private def t_e1129790136438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129790136438 : ¬ IsSelfInterpreter e1129790136438 :=
  wSource (t := t_e1129790136438) (replay_sound (ps := []) (t := e1129790136438) (by decide)) (by decide)
def e1129790136682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129790136682 : Closed e1129790136682 ∧ code e1129790136682 = 5527836647786 := by decide
private def t_e1129790136682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129790136682 : ¬ IsSelfInterpreter e1129790136682 :=
  wSource (t := t_e1129790136682) (replay_sound (ps := []) (t := e1129790136682) (by decide)) (by decide)
def e1129790136730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129790136730 : Closed e1129790136730 ∧ code e1129790136730 = 5527836647834 := by decide
private def t_e1129790136730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129790136730 : ¬ IsSelfInterpreter e1129790136730 :=
  wSource (t := t_e1129790136730) (replay_sound (ps := []) (t := e1129790136730) (by decide)) (by decide)
def e1129790152730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129790152730 : Closed e1129790152730 ∧ code e1129790152730 = 5527836663834 := by decide
theorem cert_e1129790152730 : check e1129790152730 [[]] .width = true := by decide
def e1129790152822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129790152822 : Closed e1129790152822 ∧ code e1129790152822 = 5527836663926 := by decide
theorem cert_e1129790152822 : check e1129790152822 [[]] .width = true := by decide
def e1129790153066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129790153066 : Closed e1129790153066 ∧ code e1129790153066 = 5527836664170 := by decide
theorem cert_e1129790153066 : check e1129790153066 [[]] .width = true := by decide
def e1129790153114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129790153114 : Closed e1129790153114 ∧ code e1129790153114 = 5527836664218 := by decide
theorem cert_e1129790153114 : check e1129790153114 [[]] .width = true := by decide
def e1129790156998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129790156998 : Closed e1129790156998 ∧ code e1129790156998 = 5527836668102 := by decide
theorem cert_e1129790156998 : check e1129790156998 [[]] .width = true := by decide
def e1129790158874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129790158874 : Closed e1129790158874 ∧ code e1129790158874 = 5527836669978 := by decide
theorem cert_e1129790158874 : check e1129790158874 [[]] .width = true := by decide
def e1129790167066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129790167066 : Closed e1129790167066 ∧ code e1129790167066 = 5527836678170 := by decide
theorem cert_e1129790167066 : check e1129790167066 [[]] .width = true := by decide
def e1129791283226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129791283226 : Closed e1129791283226 ∧ code e1129791283226 = 5527837794330 := by decide
theorem cert_e1129791283226 : check e1129791283226 [[]] .width = true := by decide
def e1129791283318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129791283318 : Closed e1129791283318 ∧ code e1129791283318 = 5527837794422 := by decide
theorem cert_e1129791283318 : check e1129791283318 [[]] .width = true := by decide
def e1129791283562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129791283562 : Closed e1129791283562 ∧ code e1129791283562 = 5527837794666 := by decide
theorem cert_e1129791283562 : check e1129791283562 [[]] .width = true := by decide
def e1129791283610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129791283610 : Closed e1129791283610 ∧ code e1129791283610 = 5527837794714 := by decide
theorem cert_e1129791283610 : check e1129791283610 [[]] .width = true := by decide
def e1129791315994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129791315994 : Closed e1129791315994 ∧ code e1129791315994 = 5527837827098 := by decide
theorem cert_e1129791315994 : check e1129791315994 [[]] .width = true := by decide
def e1129791316086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129791316086 : Closed e1129791316086 ∧ code e1129791316086 = 5527837827190 := by decide
theorem cert_e1129791316086 : check e1129791316086 [[]] .width = true := by decide
def e1129791316330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129791316330 : Closed e1129791316330 ∧ code e1129791316330 = 5527837827434 := by decide
theorem cert_e1129791316330 : check e1129791316330 [[]] .width = true := by decide
def e1129791316378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129791316378 : Closed e1129791316378 ∧ code e1129791316378 = 5527837827482 := by decide
theorem cert_e1129791316378 : check e1129791316378 [[]] .width = true := by decide
def e1129792651462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129792651462 : Closed e1129792651462 ∧ code e1129792651462 = 5527839162566 := by decide
theorem cert_e1129792651462 : check e1129792651462 [[]] .width = true := by decide
def e1129792856090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129792856090 : Closed e1129792856090 ∧ code e1129792856090 = 5527839367194 := by decide
theorem cert_e1129792856090 : check e1129792856090 [[]] .width = true := by decide
def e1129792856182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129792856182 : Closed e1129792856182 ∧ code e1129792856182 = 5527839367286 := by decide
theorem cert_e1129792856182 : check e1129792856182 [[]] .width = true := by decide
def e1129792856426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129792856426 : Closed e1129792856426 ∧ code e1129792856426 = 5527839367530 := by decide
theorem cert_e1129792856426 : check e1129792856426 [[]] .width = true := by decide
def e1129792856474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129792856474 : Closed e1129792856474 ∧ code e1129792856474 = 5527839367578 := by decide
theorem cert_e1129792856474 : check e1129792856474 [[]] .width = true := by decide
def e1129792893126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129792893126 : Closed e1129792893126 ∧ code e1129792893126 = 5527839404230 := by decide
theorem cert_e1129792893126 : check e1129792893126 [[]] .width = true := by decide
def e1129792905242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129792905242 : Closed e1129792905242 ∧ code e1129792905242 = 5527839416346 := by decide
theorem cert_e1129792905242 : check e1129792905242 [[]] .width = true := by decide
def e1129792905334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129792905334 : Closed e1129792905334 ∧ code e1129792905334 = 5527839416438 := by decide
theorem cert_e1129792905334 : check e1129792905334 [[]] .width = true := by decide
def e1129792905578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129792905578 : Closed e1129792905578 ∧ code e1129792905578 = 5527839416682 := by decide
theorem cert_e1129792905578 : check e1129792905578 [[]] .width = true := by decide
def e1129792905626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129792905626 : Closed e1129792905626 ∧ code e1129792905626 = 5527839416730 := by decide
theorem cert_e1129792905626 : check e1129792905626 [[]] .width = true := by decide
def e1129792909510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129792909510 : Closed e1129792909510 ∧ code e1129792909510 = 5527839420614 := by decide
theorem cert_e1129792909510 : check e1129792909510 [[]] .width = true := by decide
def e1129792911386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129792911386 : Closed e1129792911386 ∧ code e1129792911386 = 5527839422490 := by decide
theorem cert_e1129792911386 : check e1129792911386 [[]] .width = true := by decide
def e1129793323034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129793323034 : Closed e1129793323034 ∧ code e1129793323034 = 5527839834138 := by decide
theorem cert_e1129793323034 : check e1129793323034 [[]] .width = true := by decide
def e1129793323126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129793323126 : Closed e1129793323126 ∧ code e1129793323126 = 5527839834230 := by decide
theorem cert_e1129793323126 : check e1129793323126 [[]] .width = true := by decide
def e1129793323370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129793323370 : Closed e1129793323370 ∧ code e1129793323370 = 5527839834474 := by decide
theorem cert_e1129793323370 : check e1129793323370 [[]] .width = true := by decide
def e1129793323418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129793323418 : Closed e1129793323418 ∧ code e1129793323418 = 5527839834522 := by decide
theorem cert_e1129793323418 : check e1129793323418 [[]] .width = true := by decide
def e1129793323502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129793323502 : Closed e1129793323502 ∧ code e1129793323502 = 5527839834606 := by decide
theorem cert_e1129793323502 : check e1129793323502 [[]] .width = true := by decide
def e1129793324426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129793324426 : Closed e1129793324426 ∧ code e1129793324426 = 5527839835530 := by decide
theorem cert_e1129793324426 : check e1129793324426 [[]] .width = true := by decide
def e1129793324450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129793324450 : Closed e1129793324450 ∧ code e1129793324450 = 5527839835554 := by decide
theorem cert_e1129793324450 : check e1129793324450 [[]] .width = true := by decide
def e1129793324470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129793324470 : Closed e1129793324470 ∧ code e1129793324470 = 5527839835574 := by decide
theorem cert_e1129793324470 : check e1129793324470 [[]] .width = true := by decide
def e1129793324502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129793324502 : Closed e1129793324502 ∧ code e1129793324502 = 5527839835606 := by decide
theorem cert_e1129793324502 : check e1129793324502 [[]] .width = true := by decide
def e1129793324506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129793324506 : Closed e1129793324506 ∧ code e1129793324506 = 5527839835610 := by decide
theorem cert_e1129793324506 : check e1129793324506 [[]] .width = true := by decide
end Blc.Floor42
