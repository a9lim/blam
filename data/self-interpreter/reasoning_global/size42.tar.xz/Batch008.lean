import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800827822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302800827822 : Closed e302800827822 ∧ code e302800827822 = 4700847338926 := by decide
theorem cert_e302800827822 : check e302800827822 [[.under],[.under]] .three = true := by decide
def e302800827834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302800827834 : Closed e302800827834 ∧ code e302800827834 = 4700847338938 := by decide
theorem cert_e302800827834 : check e302800827834 [[.under],[.under]] .three = true := by decide
def e302800827862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302800827862 : Closed e302800827862 ∧ code e302800827862 = 4700847338966 := by decide
theorem cert_e302800827862 : check e302800827862 [[.under],[.under]] .three = true := by decide
def e302800827866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302800827866 : Closed e302800827866 ∧ code e302800827866 = 4700847338970 := by decide
theorem cert_e302800827866 : check e302800827866 [[.under],[.under]] .three = true := by decide
def e302800828078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e302800828078 : Closed e302800828078 ∧ code e302800828078 = 4700847339182 := by decide
theorem cert_e302800828078 : check e302800828078 [[.under],[.under]] .three = true := by decide
def e302800828090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e302800828090 : Closed e302800828090 ∧ code e302800828090 = 4700847339194 := by decide
theorem cert_e302800828090 : check e302800828090 [[.under],[.under]] .three = true := by decide
def e302800828138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e302800828138 : Closed e302800828138 ∧ code e302800828138 = 4700847339242 := by decide
theorem cert_e302800828138 : check e302800828138 [[.under],[.under]] .three = true := by decide
def e302800828246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302800828246 : Closed e302800828246 ∧ code e302800828246 = 4700847339350 := by decide
theorem cert_e302800828246 : check e302800828246 [[.under],[.under]] .three = true := by decide
def e302800828250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302800828250 : Closed e302800828250 ∧ code e302800828250 = 4700847339354 := by decide
theorem cert_e302800828250 : check e302800828250 [[.under],[.under]] .three = true := by decide
def e302800828266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302800828266 : Closed e302800828266 ∧ code e302800828266 = 4700847339370 := by decide
theorem cert_e302800828266 : check e302800828266 [[.under],[.under]] .three = true := by decide
def e302800858590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e302800858590 : Closed e302800858590 ∧ code e302800858590 = 4700847369694 := by decide
theorem cert_e302800858590 : check e302800858590 [[.under],[.under]] .three = true := by decide
def e302800858606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e302800858606 : Closed e302800858606 ∧ code e302800858606 = 4700847369710 := by decide
theorem cert_e302800858606 : check e302800858606 [[.under],[.under]] .three = true := by decide
def e302800858846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e302800858846 : Closed e302800858846 ∧ code e302800858846 = 4700847369950 := by decide
theorem cert_e302800858846 : check e302800858846 [[.under],[.under]] .three = true := by decide
def e302800858870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e302800858870 : Closed e302800858870 ∧ code e302800858870 = 4700847369974 := by decide
theorem cert_e302800858870 : check e302800858870 [[.under],[.under]] .three = true := by decide
def e302800858990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e302800858990 : Closed e302800858990 ∧ code e302800858990 = 4700847370094 := by decide
theorem cert_e302800858990 : check e302800858990 [[.under],[.under]] .three = true := by decide
def e302800858998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e302800858998 : Closed e302800858998 ∧ code e302800858998 = 4700847370102 := by decide
theorem cert_e302800858998 : check e302800858998 [[.under],[.under]] .three = true := by decide
def e302800860638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e302800860638 : Closed e302800860638 ∧ code e302800860638 = 4700847371742 := by decide
theorem cert_e302800860638 : check e302800860638 [[.under],[.under]] .three = true := by decide
def e302800860654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e302800860654 : Closed e302800860654 ∧ code e302800860654 = 4700847371758 := by decide
theorem cert_e302800860654 : check e302800860654 [[.under],[.under]] .three = true := by decide
def e302800861022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e302800861022 : Closed e302800861022 ∧ code e302800861022 = 4700847372126 := by decide
theorem cert_e302800861022 : check e302800861022 [[.under],[.under]] .three = true := by decide
def e302800861050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e302800861050 : Closed e302800861050 ∧ code e302800861050 = 4700847372154 := by decide
theorem cert_e302800861050 : check e302800861050 [[.under],[.under]] .three = true := by decide
def e302800861102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e302800861102 : Closed e302800861102 ∧ code e302800861102 = 4700847372206 := by decide
theorem cert_e302800861102 : check e302800861102 [[.under],[.under]] .three = true := by decide
def e302800861114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e302800861114 : Closed e302800861114 ∧ code e302800861114 = 4700847372218 := by decide
theorem cert_e302800861114 : check e302800861114 [[.under],[.under]] .three = true := by decide
def e302800861918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e302800861918 : Closed e302800861918 ∧ code e302800861918 = 4700847373022 := by decide
theorem cert_e302800861918 : check e302800861918 [[.under],[.under]] .three = true := by decide
def e302800861942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e302800861942 : Closed e302800861942 ∧ code e302800861942 = 4700847373046 := by decide
theorem cert_e302800861942 : check e302800861942 [[.under],[.under]] .three = true := by decide
def e302800862046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e302800862046 : Closed e302800862046 ∧ code e302800862046 = 4700847373150 := by decide
theorem cert_e302800862046 : check e302800862046 [[.under],[.under]] .three = true := by decide
def e302800862074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e302800862074 : Closed e302800862074 ∧ code e302800862074 = 4700847373178 := by decide
theorem cert_e302800862074 : check e302800862074 [[.under],[.under]] .three = true := by decide
def e302800862166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302800862166 : Closed e302800862166 ∧ code e302800862166 = 4700847373270 := by decide
theorem cert_e302800862166 : check e302800862166 [[.under],[.under]] .three = true := by decide
def e302800862170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302800862170 : Closed e302800862170 ∧ code e302800862170 = 4700847373274 := by decide
theorem cert_e302800862170 : check e302800862170 [[.under],[.under]] .three = true := by decide
def e302800862574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302800862574 : Closed e302800862574 ∧ code e302800862574 = 4700847373678 := by decide
theorem cert_e302800862574 : check e302800862574 [[.under],[.under]] .three = true := by decide
def e302800862582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302800862582 : Closed e302800862582 ∧ code e302800862582 = 4700847373686 := by decide
theorem cert_e302800862582 : check e302800862582 [[.under],[.under]] .three = true := by decide
def e302800862638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302800862638 : Closed e302800862638 ∧ code e302800862638 = 4700847373742 := by decide
theorem cert_e302800862638 : check e302800862638 [[.under],[.under]] .three = true := by decide
def e302800862650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302800862650 : Closed e302800862650 ∧ code e302800862650 = 4700847373754 := by decide
theorem cert_e302800862650 : check e302800862650 [[.under],[.under]] .three = true := by decide
def e302800862678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e302800862678 : Closed e302800862678 ∧ code e302800862678 = 4700847373782 := by decide
theorem cert_e302800862678 : check e302800862678 [[.under],[.under]] .three = true := by decide
def e302800862682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e302800862682 : Closed e302800862682 ∧ code e302800862682 = 4700847373786 := by decide
theorem cert_e302800862682 : check e302800862682 [[.under],[.under]] .three = true := by decide
def e302800870878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e302800870878 : Closed e302800870878 ∧ code e302800870878 = 4700847381982 := by decide
theorem cert_e302800870878 : check e302800870878 [[.under],[.under]] .three = true := by decide
def e302800870894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e302800870894 : Closed e302800870894 ∧ code e302800870894 = 4700847381998 := by decide
theorem cert_e302800870894 : check e302800870894 [[.under],[.under]] .three = true := by decide
def e302800871134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e302800871134 : Closed e302800871134 ∧ code e302800871134 = 4700847382238 := by decide
theorem cert_e302800871134 : check e302800871134 [[.under],[.under]] .three = true := by decide
def e302800871158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e302800871158 : Closed e302800871158 ∧ code e302800871158 = 4700847382262 := by decide
theorem cert_e302800871158 : check e302800871158 [[.under],[.under]] .three = true := by decide
def e302800871278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e302800871278 : Closed e302800871278 ∧ code e302800871278 = 4700847382382 := by decide
theorem cert_e302800871278 : check e302800871278 [[.under],[.under]] .three = true := by decide
def e302800871286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e302800871286 : Closed e302800871286 ∧ code e302800871286 = 4700847382390 := by decide
theorem cert_e302800871286 : check e302800871286 [[.under],[.under]] .three = true := by decide
def e302800876510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e302800876510 : Closed e302800876510 ∧ code e302800876510 = 4700847387614 := by decide
theorem cert_e302800876510 : check e302800876510 [[.under],[.under]] .three = true := by decide
def e302800876526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e302800876526 : Closed e302800876526 ∧ code e302800876526 = 4700847387630 := by decide
theorem cert_e302800876526 : check e302800876526 [[.under],[.under]] .three = true := by decide
def e302800878046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e302800878046 : Closed e302800878046 ∧ code e302800878046 = 4700847389150 := by decide
theorem cert_e302800878046 : check e302800878046 [[.under],[.under]] .three = true := by decide
def e302800878070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e302800878070 : Closed e302800878070 ∧ code e302800878070 = 4700847389174 := by decide
theorem cert_e302800878070 : check e302800878070 [[.under],[.under]] .three = true := by decide
def e302800878830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e302800878830 : Closed e302800878830 ∧ code e302800878830 = 4700847389934 := by decide
theorem cert_e302800878830 : check e302800878830 [[.under],[.under]] .three = true := by decide
def e302800878838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e302800878838 : Closed e302800878838 ∧ code e302800878838 = 4700847389942 := by decide
theorem cert_e302800878838 : check e302800878838 [[.under],[.under]] .three = true := by decide
def e302800883166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e302800883166 : Closed e302800883166 ∧ code e302800883166 = 4700847394270 := by decide
theorem cert_e302800883166 : check e302800883166 [[.under],[.under]] .three = true := by decide
def e302800883182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e302800883182 : Closed e302800883182 ∧ code e302800883182 = 4700847394286 := by decide
theorem cert_e302800883182 : check e302800883182 [[.under],[.under]] .three = true := by decide
def e302800883550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e302800883550 : Closed e302800883550 ∧ code e302800883550 = 4700847394654 := by decide
theorem cert_e302800883550 : check e302800883550 [[.under],[.under]] .three = true := by decide
def e302800883578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e302800883578 : Closed e302800883578 ∧ code e302800883578 = 4700847394682 := by decide
theorem cert_e302800883578 : check e302800883578 [[.under],[.under]] .three = true := by decide
def e302800883630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e302800883630 : Closed e302800883630 ∧ code e302800883630 = 4700847394734 := by decide
theorem cert_e302800883630 : check e302800883630 [[.under],[.under]] .three = true := by decide
def e302800883642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e302800883642 : Closed e302800883642 ∧ code e302800883642 = 4700847394746 := by decide
theorem cert_e302800883642 : check e302800883642 [[.under],[.under]] .three = true := by decide
def e302800884702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e302800884702 : Closed e302800884702 ∧ code e302800884702 = 4700847395806 := by decide
theorem cert_e302800884702 : check e302800884702 [[.under],[.under]] .three = true := by decide
def e302800884718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e302800884718 : Closed e302800884718 ∧ code e302800884718 = 4700847395822 := by decide
theorem cert_e302800884718 : check e302800884718 [[.under],[.under]] .three = true := by decide
def e302800887006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800887006 : Closed e302800887006 ∧ code e302800887006 = 4700847398110 := by decide
theorem cert_e302800887006 : check e302800887006 [[.under],[.under]] .three = true := by decide
def e302800887034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800887034 : Closed e302800887034 ∧ code e302800887034 = 4700847398138 := by decide
theorem cert_e302800887034 : check e302800887034 [[.under],[.under]] .three = true := by decide
def e302800887406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800887406 : Closed e302800887406 ∧ code e302800887406 = 4700847398510 := by decide
theorem cert_e302800887406 : check e302800887406 [[.under],[.under]] .three = true := by decide
def e302800887418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800887418 : Closed e302800887418 ∧ code e302800887418 = 4700847398522 := by decide
theorem cert_e302800887418 : check e302800887418 [[.under],[.under]] .three = true := by decide
def e302800889566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e302800889566 : Closed e302800889566 ∧ code e302800889566 = 4700847400670 := by decide
theorem cert_e302800889566 : check e302800889566 [[.under],[.under]] .three = true := by decide
def e302800889590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e302800889590 : Closed e302800889590 ∧ code e302800889590 = 4700847400694 := by decide
theorem cert_e302800889590 : check e302800889590 [[.under],[.under]] .three = true := by decide
def e302800889694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e302800889694 : Closed e302800889694 ∧ code e302800889694 = 4700847400798 := by decide
theorem cert_e302800889694 : check e302800889694 [[.under],[.under]] .three = true := by decide
def e302800889722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e302800889722 : Closed e302800889722 ∧ code e302800889722 = 4700847400826 := by decide
theorem cert_e302800889722 : check e302800889722 [[.under],[.under]] .three = true := by decide
def e302800889814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e302800889814 : Closed e302800889814 ∧ code e302800889814 = 4700847400918 := by decide
theorem cert_e302800889814 : check e302800889814 [[.under],[.under]] .three = true := by decide
def e302800889818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e302800889818 : Closed e302800889818 ∧ code e302800889818 = 4700847400922 := by decide
theorem cert_e302800889818 : check e302800889818 [[.under],[.under]] .three = true := by decide
def e302800890334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e302800890334 : Closed e302800890334 ∧ code e302800890334 = 4700847401438 := by decide
theorem cert_e302800890334 : check e302800890334 [[.under],[.under]] .three = true := by decide
def e302800890358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e302800890358 : Closed e302800890358 ∧ code e302800890358 = 4700847401462 := by decide
theorem cert_e302800890358 : check e302800890358 [[.under],[.under]] .three = true := by decide
def e302800891102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800891102 : Closed e302800891102 ∧ code e302800891102 = 4700847402206 := by decide
theorem cert_e302800891102 : check e302800891102 [[.under],[.under]] .three = true := by decide
def e302800891130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800891130 : Closed e302800891130 ∧ code e302800891130 = 4700847402234 := by decide
theorem cert_e302800891130 : check e302800891130 [[.under],[.under]] .three = true := by decide
def e302800891702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800891702 : Closed e302800891702 ∧ code e302800891702 = 4700847402806 := by decide
theorem cert_e302800891702 : check e302800891702 [[.under],[.under]] .three = true := by decide
def e302800891706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800891706 : Closed e302800891706 ∧ code e302800891706 = 4700847402810 := by decide
theorem cert_e302800891706 : check e302800891706 [[.under],[.under]] .three = true := by decide
def e302800892782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302800892782 : Closed e302800892782 ∧ code e302800892782 = 4700847403886 := by decide
theorem cert_e302800892782 : check e302800892782 [[.under],[.under]] .three = true := by decide
def e302800892790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302800892790 : Closed e302800892790 ∧ code e302800892790 = 4700847403894 := by decide
theorem cert_e302800892790 : check e302800892790 [[.under],[.under]] .three = true := by decide
def e302800892846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302800892846 : Closed e302800892846 ∧ code e302800892846 = 4700847403950 := by decide
theorem cert_e302800892846 : check e302800892846 [[.under],[.under]] .three = true := by decide
def e302800892858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302800892858 : Closed e302800892858 ∧ code e302800892858 = 4700847403962 := by decide
theorem cert_e302800892858 : check e302800892858 [[.under],[.under]] .three = true := by decide
def e302800892886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302800892886 : Closed e302800892886 ∧ code e302800892886 = 4700847403990 := by decide
theorem cert_e302800892886 : check e302800892886 [[.under],[.under]] .three = true := by decide
def e302800892890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302800892890 : Closed e302800892890 ∧ code e302800892890 = 4700847403994 := by decide
theorem cert_e302800892890 : check e302800892890 [[.under],[.under]] .three = true := by decide
def e302800893166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302800893166 : Closed e302800893166 ∧ code e302800893166 = 4700847404270 := by decide
theorem cert_e302800893166 : check e302800893166 [[.under],[.under]] .three = true := by decide
def e302800893174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302800893174 : Closed e302800893174 ∧ code e302800893174 = 4700847404278 := by decide
theorem cert_e302800893174 : check e302800893174 [[.under],[.under]] .three = true := by decide
def e302800893550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800893550 : Closed e302800893550 ∧ code e302800893550 = 4700847404654 := by decide
theorem cert_e302800893550 : check e302800893550 [[.under],[.under]] .three = true := by decide
def e302800893562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800893562 : Closed e302800893562 ∧ code e302800893562 = 4700847404666 := by decide
theorem cert_e302800893562 : check e302800893562 [[.under],[.under]] .three = true := by decide
def e302800893750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800893750 : Closed e302800893750 ∧ code e302800893750 = 4700847404854 := by decide
theorem cert_e302800893750 : check e302800893750 [[.under],[.under]] .three = true := by decide
def e302800893754 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800893754 : Closed e302800893754 ∧ code e302800893754 = 4700847404858 := by decide
theorem cert_e302800893754 : check e302800893754 [[.under],[.under]] .three = true := by decide
def e302800909790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e302800909790 : Closed e302800909790 ∧ code e302800909790 = 4700847420894 := by decide
theorem cert_e302800909790 : check e302800909790 [[.under],[.under]] .three = true := by decide
def e302800909806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e302800909806 : Closed e302800909806 ∧ code e302800909806 = 4700847420910 := by decide
theorem cert_e302800909806 : check e302800909806 [[.under],[.under]] .three = true := by decide
def e302800910174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e302800910174 : Closed e302800910174 ∧ code e302800910174 = 4700847421278 := by decide
theorem cert_e302800910174 : check e302800910174 [[.under],[.under]] .three = true := by decide
def e302800910202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e302800910202 : Closed e302800910202 ∧ code e302800910202 = 4700847421306 := by decide
theorem cert_e302800910202 : check e302800910202 [[.under],[.under]] .three = true := by decide
def e302800910254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e302800910254 : Closed e302800910254 ∧ code e302800910254 = 4700847421358 := by decide
theorem cert_e302800910254 : check e302800910254 [[.under],[.under]] .three = true := by decide
def e302800910266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e302800910266 : Closed e302800910266 ∧ code e302800910266 = 4700847421370 := by decide
theorem cert_e302800910266 : check e302800910266 [[.under],[.under]] .three = true := by decide
def e302800911710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e302800911710 : Closed e302800911710 ∧ code e302800911710 = 4700847422814 := by decide
theorem cert_e302800911710 : check e302800911710 [[.under],[.under]] .three = true := by decide
def e302800911738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e302800911738 : Closed e302800911738 ∧ code e302800911738 = 4700847422842 := by decide
theorem cert_e302800911738 : check e302800911738 [[.under],[.under]] .three = true := by decide
def e302800911850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302800911850 : Closed e302800911850 ∧ code e302800911850 = 4700847422954 := by decide
theorem cert_e302800911850 : check e302800911850 [[.under],[.under]] .three = true := by decide
def e302800912046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e302800912046 : Closed e302800912046 ∧ code e302800912046 = 4700847423150 := by decide
theorem cert_e302800912046 : check e302800912046 [[.under],[.under]] .three = true := by decide
def e302800912058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e302800912058 : Closed e302800912058 ∧ code e302800912058 = 4700847423162 := by decide
theorem cert_e302800912058 : check e302800912058 [[.under],[.under]] .three = true := by decide
def e302800912106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302800912106 : Closed e302800912106 ∧ code e302800912106 = 4700847423210 := by decide
theorem cert_e302800912106 : check e302800912106 [[.under],[.under]] .three = true := by decide
def e302800915934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e302800915934 : Closed e302800915934 ∧ code e302800915934 = 4700847427038 := by decide
theorem cert_e302800915934 : check e302800915934 [[.under],[.under]] .three = true := by decide
def e302800915950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e302800915950 : Closed e302800915950 ∧ code e302800915950 = 4700847427054 := by decide
theorem cert_e302800915950 : check e302800915950 [[.under],[.under]] .three = true := by decide
def e302800916318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e302800916318 : Closed e302800916318 ∧ code e302800916318 = 4700847427422 := by decide
theorem cert_e302800916318 : check e302800916318 [[.under],[.under]] .three = true := by decide
def e302800916346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e302800916346 : Closed e302800916346 ∧ code e302800916346 = 4700847427450 := by decide
theorem cert_e302800916346 : check e302800916346 [[.under],[.under]] .three = true := by decide
def e302800916398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e302800916398 : Closed e302800916398 ∧ code e302800916398 = 4700847427502 := by decide
theorem cert_e302800916398 : check e302800916398 [[.under],[.under]] .three = true := by decide
def e302800916410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e302800916410 : Closed e302800916410 ∧ code e302800916410 = 4700847427514 := by decide
theorem cert_e302800916410 : check e302800916410 [[.under],[.under]] .three = true := by decide
def e302800917470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e302800917470 : Closed e302800917470 ∧ code e302800917470 = 4700847428574 := by decide
theorem cert_e302800917470 : check e302800917470 [[.under],[.under]] .three = true := by decide
def e302800917486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e302800917486 : Closed e302800917486 ∧ code e302800917486 = 4700847428590 := by decide
theorem cert_e302800917486 : check e302800917486 [[.under],[.under]] .three = true := by decide
def e302800919774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800919774 : Closed e302800919774 ∧ code e302800919774 = 4700847430878 := by decide
theorem cert_e302800919774 : check e302800919774 [[.under],[.under]] .three = true := by decide
def e302800919802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800919802 : Closed e302800919802 ∧ code e302800919802 = 4700847430906 := by decide
theorem cert_e302800919802 : check e302800919802 [[.under],[.under]] .three = true := by decide
def e302800920174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800920174 : Closed e302800920174 ∧ code e302800920174 = 4700847431278 := by decide
theorem cert_e302800920174 : check e302800920174 [[.under],[.under]] .three = true := by decide
def e302800920186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800920186 : Closed e302800920186 ∧ code e302800920186 = 4700847431290 := by decide
theorem cert_e302800920186 : check e302800920186 [[.under],[.under]] .three = true := by decide
def e302800925534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e302800925534 : Closed e302800925534 ∧ code e302800925534 = 4700847436638 := by decide
theorem cert_e302800925534 : check e302800925534 [[.under],[.under]] .three = true := by decide
def e302800925562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e302800925562 : Closed e302800925562 ∧ code e302800925562 = 4700847436666 := by decide
theorem cert_e302800925562 : check e302800925562 [[.under],[.under]] .three = true := by decide
def e302800925674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e302800925674 : Closed e302800925674 ∧ code e302800925674 = 4700847436778 := by decide
theorem cert_e302800925674 : check e302800925674 [[.under],[.under]] .three = true := by decide
def e302800925918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800925918 : Closed e302800925918 ∧ code e302800925918 = 4700847437022 := by decide
theorem cert_e302800925918 : check e302800925918 [[.under],[.under]] .three = true := by decide
def e302800925946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800925946 : Closed e302800925946 ∧ code e302800925946 = 4700847437050 := by decide
theorem cert_e302800925946 : check e302800925946 [[.under],[.under]] .three = true := by decide
def e302800926618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800926618 : Closed e302800926618 ∧ code e302800926618 = 4700847437722 := by decide
theorem cert_e302800926618 : check e302800926618 [[.under],[.under]] .three = true := by decide
def e302800927150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e302800927150 : Closed e302800927150 ∧ code e302800927150 = 4700847438254 := by decide
theorem cert_e302800927150 : check e302800927150 [[.under],[.under]] .three = true := by decide
def e302800927162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e302800927162 : Closed e302800927162 ∧ code e302800927162 = 4700847438266 := by decide
theorem cert_e302800927162 : check e302800927162 [[.under],[.under]] .three = true := by decide
def e302800927210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e302800927210 : Closed e302800927210 ∧ code e302800927210 = 4700847438314 := by decide
theorem cert_e302800927210 : check e302800927210 [[.under],[.under]] .three = true := by decide
def e302800927342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800927342 : Closed e302800927342 ∧ code e302800927342 = 4700847438446 := by decide
theorem cert_e302800927342 : check e302800927342 [[.under],[.under]] .three = true := by decide
def e302800927354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800927354 : Closed e302800927354 ∧ code e302800927354 = 4700847438458 := by decide
theorem cert_e302800927354 : check e302800927354 [[.under],[.under]] .three = true := by decide
def e302800927642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800927642 : Closed e302800927642 ∧ code e302800927642 = 4700847438746 := by decide
theorem cert_e302800927642 : check e302800927642 [[.under],[.under]] .three = true := by decide
def e302800935646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e302800935646 : Closed e302800935646 ∧ code e302800935646 = 4700847446750 := by decide
theorem cert_e302800935646 : check e302800935646 [[.under],[.under]] .three = true := by decide
def e302800935670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e302800935670 : Closed e302800935670 ∧ code e302800935670 = 4700847446774 := by decide
theorem cert_e302800935670 : check e302800935670 [[.under],[.under]] .three = true := by decide
def e302800935774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e302800935774 : Closed e302800935774 ∧ code e302800935774 = 4700847446878 := by decide
theorem cert_e302800935774 : check e302800935774 [[.under],[.under]] .three = true := by decide
def e302800935802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e302800935802 : Closed e302800935802 ∧ code e302800935802 = 4700847446906 := by decide
theorem cert_e302800935802 : check e302800935802 [[.under],[.under]] .three = true := by decide
def e302800935894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302800935894 : Closed e302800935894 ∧ code e302800935894 = 4700847446998 := by decide
theorem cert_e302800935894 : check e302800935894 [[.under],[.under]] .three = true := by decide
def e302800935898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302800935898 : Closed e302800935898 ∧ code e302800935898 = 4700847447002 := by decide
theorem cert_e302800935898 : check e302800935898 [[.under],[.under]] .three = true := by decide
def e302800936286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e302800936286 : Closed e302800936286 ∧ code e302800936286 = 4700847447390 := by decide
theorem cert_e302800936286 : check e302800936286 [[.under],[.under]] .three = true := by decide
def e302800936314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e302800936314 : Closed e302800936314 ∧ code e302800936314 = 4700847447418 := by decide
theorem cert_e302800936314 : check e302800936314 [[.under],[.under]] .three = true := by decide
def e302800936426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302800936426 : Closed e302800936426 ∧ code e302800936426 = 4700847447530 := by decide
theorem cert_e302800936426 : check e302800936426 [[.under],[.under]] .three = true := by decide
def e302800936790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302800936790 : Closed e302800936790 ∧ code e302800936790 = 4700847447894 := by decide
theorem cert_e302800936790 : check e302800936790 [[.under],[.under]] .three = true := by decide
def e302800936794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302800936794 : Closed e302800936794 ∧ code e302800936794 = 4700847447898 := by decide
theorem cert_e302800936794 : check e302800936794 [[.under],[.under]] .three = true := by decide
def e302800936810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302800936810 : Closed e302800936810 ∧ code e302800936810 = 4700847447914 := by decide
theorem cert_e302800936810 : check e302800936810 [[.under],[.under]] .three = true := by decide
def e302800938718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e302800938718 : Closed e302800938718 ∧ code e302800938718 = 4700847449822 := by decide
theorem cert_e302800938718 : check e302800938718 [[.under],[.under]] .three = true := by decide
def e302800938742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e302800938742 : Closed e302800938742 ∧ code e302800938742 = 4700847449846 := by decide
theorem cert_e302800938742 : check e302800938742 [[.under],[.under]] .three = true := by decide
def e302800938846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e302800938846 : Closed e302800938846 ∧ code e302800938846 = 4700847449950 := by decide
theorem cert_e302800938846 : check e302800938846 [[.under],[.under]] .three = true := by decide
def e302800938874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e302800938874 : Closed e302800938874 ∧ code e302800938874 = 4700847449978 := by decide
theorem cert_e302800938874 : check e302800938874 [[.under],[.under]] .three = true := by decide
def e302800938966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e302800938966 : Closed e302800938966 ∧ code e302800938966 = 4700847450070 := by decide
theorem cert_e302800938966 : check e302800938966 [[.under],[.under]] .three = true := by decide
def e302800938970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e302800938970 : Closed e302800938970 ∧ code e302800938970 = 4700847450074 := by decide
theorem cert_e302800938970 : check e302800938970 [[.under],[.under]] .three = true := by decide
def e302800939486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e302800939486 : Closed e302800939486 ∧ code e302800939486 = 4700847450590 := by decide
theorem cert_e302800939486 : check e302800939486 [[.under],[.under]] .three = true := by decide
def e302800939510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e302800939510 : Closed e302800939510 ∧ code e302800939510 = 4700847450614 := by decide
theorem cert_e302800939510 : check e302800939510 [[.under],[.under]] .three = true := by decide
def e302800940254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800940254 : Closed e302800940254 ∧ code e302800940254 = 4700847451358 := by decide
theorem cert_e302800940254 : check e302800940254 [[.under],[.under]] .three = true := by decide
def e302800940282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800940282 : Closed e302800940282 ∧ code e302800940282 = 4700847451386 := by decide
theorem cert_e302800940282 : check e302800940282 [[.under],[.under]] .three = true := by decide
def e302800940854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800940854 : Closed e302800940854 ∧ code e302800940854 = 4700847451958 := by decide
theorem cert_e302800940854 : check e302800940854 [[.under],[.under]] .three = true := by decide
def e302800940858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800940858 : Closed e302800940858 ∧ code e302800940858 = 4700847451962 := by decide
theorem cert_e302800940858 : check e302800940858 [[.under],[.under]] .three = true := by decide
def e302800941918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e302800941918 : Closed e302800941918 ∧ code e302800941918 = 4700847453022 := by decide
theorem cert_e302800941918 : check e302800941918 [[.under],[.under]] .three = true := by decide
def e302800941946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e302800941946 : Closed e302800941946 ∧ code e302800941946 = 4700847453050 := by decide
theorem cert_e302800941946 : check e302800941946 [[.under],[.under]] .three = true := by decide
def e302800942058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e302800942058 : Closed e302800942058 ∧ code e302800942058 = 4700847453162 := by decide
theorem cert_e302800942058 : check e302800942058 [[.under],[.under]] .three = true := by decide
def e302800942302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e302800942302 : Closed e302800942302 ∧ code e302800942302 = 4700847453406 := by decide
theorem cert_e302800942302 : check e302800942302 [[.under],[.under]] .three = true := by decide
def e302800942330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e302800942330 : Closed e302800942330 ∧ code e302800942330 = 4700847453434 := by decide
theorem cert_e302800942330 : check e302800942330 [[.under],[.under]] .three = true := by decide
def e302800943002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800943002 : Closed e302800943002 ∧ code e302800943002 = 4700847454106 := by decide
theorem cert_e302800943002 : check e302800943002 [[.under],[.under]] .three = true := by decide
def e302800944342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302800944342 : Closed e302800944342 ∧ code e302800944342 = 4700847455446 := by decide
theorem cert_e302800944342 : check e302800944342 [[.under],[.under]] .three = true := by decide
def e302800944346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302800944346 : Closed e302800944346 ∧ code e302800944346 = 4700847455450 := by decide
theorem cert_e302800944346 : check e302800944346 [[.under],[.under]] .three = true := by decide
def e302800944362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302800944362 : Closed e302800944362 ∧ code e302800944362 = 4700847455466 := by decide
theorem cert_e302800944362 : check e302800944362 [[.under],[.under]] .three = true := by decide
def e302800944438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800944438 : Closed e302800944438 ∧ code e302800944438 = 4700847455542 := by decide
theorem cert_e302800944438 : check e302800944438 [[.under],[.under]] .three = true := by decide
def e302800944442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800944442 : Closed e302800944442 ∧ code e302800944442 = 4700847455546 := by decide
theorem cert_e302800944442 : check e302800944442 [[.under],[.under]] .three = true := by decide
def e302800944538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800944538 : Closed e302800944538 ∧ code e302800944538 = 4700847455642 := by decide
theorem cert_e302800944538 : check e302800944538 [[.under],[.under]] .three = true := by decide
def e302800948590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302800948590 : Closed e302800948590 ∧ code e302800948590 = 4700847459694 := by decide
theorem cert_e302800948590 : check e302800948590 [[.under],[.under]] .three = true := by decide
def e302800948598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302800948598 : Closed e302800948598 ∧ code e302800948598 = 4700847459702 := by decide
theorem cert_e302800948598 : check e302800948598 [[.under],[.under]] .three = true := by decide
def e302800948654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302800948654 : Closed e302800948654 ∧ code e302800948654 = 4700847459758 := by decide
theorem cert_e302800948654 : check e302800948654 [[.under],[.under]] .three = true := by decide
def e302800948666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302800948666 : Closed e302800948666 ∧ code e302800948666 = 4700847459770 := by decide
theorem cert_e302800948666 : check e302800948666 [[.under],[.under]] .three = true := by decide
def e302800948694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e302800948694 : Closed e302800948694 ∧ code e302800948694 = 4700847459798 := by decide
theorem cert_e302800948694 : check e302800948694 [[.under],[.under]] .three = true := by decide
def e302800948698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e302800948698 : Closed e302800948698 ∧ code e302800948698 = 4700847459802 := by decide
theorem cert_e302800948698 : check e302800948698 [[.under],[.under]] .three = true := by decide
end Blc.Floor42
