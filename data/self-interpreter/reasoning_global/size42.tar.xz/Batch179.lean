import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203286326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203286326 : Closed e1211203286326 ∧ code e1211203286326 = 5609249797430 := by decide
theorem cert_e1211203286326 : check e1211203286326 [[],[]] .chain = true := by decide
def e1211203286330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203286330 : Closed e1211203286330 ∧ code e1211203286330 = 5609249797434 := by decide
theorem cert_e1211203286330 : check e1211203286330 [[],[]] .chain = true := by decide
def e1211203286402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203286402 : Closed e1211203286402 ∧ code e1211203286402 = 5609249797506 := by decide
theorem cert_e1211203286402 : check e1211203286402 [[],[]] .chain = true := by decide
def e1211203286414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203286414 : Closed e1211203286414 ∧ code e1211203286414 = 5609249797518 := by decide
theorem cert_e1211203286414 : check e1211203286414 [[],[]] .chain = true := by decide
def e1211203286426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203286426 : Closed e1211203286426 ∧ code e1211203286426 = 5609249797530 := by decide
theorem cert_e1211203286426 : check e1211203286426 [[],[]] .chain = true := by decide
def e1211203286470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203286470 : Closed e1211203286470 ∧ code e1211203286470 = 5609249797574 := by decide
theorem cert_e1211203286470 : check e1211203286470 [[],[]] .sourceHead = true := by decide
def e1211203286538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203286538 : Closed e1211203286538 ∧ code e1211203286538 = 5609249797642 := by decide
theorem cert_e1211203286538 : check e1211203286538 [[],[]] .chain = true := by decide
def e1211203286582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203286582 : Closed e1211203286582 ∧ code e1211203286582 = 5609249797686 := by decide
theorem cert_e1211203286582 : check e1211203286582 [[],[]] .chain = true := by decide
def e1211203286586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203286586 : Closed e1211203286586 ∧ code e1211203286586 = 5609249797690 := by decide
theorem cert_e1211203286586 : check e1211203286586 [[],[]] .chain = true := by decide
def e1211203286634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203286634 : Closed e1211203286634 ∧ code e1211203286634 = 5609249797738 := by decide
theorem cert_e1211203286634 : check e1211203286634 [[],[]] .chain = true := by decide
def e1211203286658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203286658 : Closed e1211203286658 ∧ code e1211203286658 = 5609249797762 := by decide
theorem cert_e1211203286658 : check e1211203286658 [[],[]] .chain = true := by decide
def e1211203286670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203286670 : Closed e1211203286670 ∧ code e1211203286670 = 5609249797774 := by decide
theorem cert_e1211203286670 : check e1211203286670 [[],[]] .chain = true := by decide
def e1211203286682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203286682 : Closed e1211203286682 ∧ code e1211203286682 = 5609249797786 := by decide
theorem cert_e1211203286682 : check e1211203286682 [[],[]] .chain = true := by decide
def e1211203286726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203286726 : Closed e1211203286726 ∧ code e1211203286726 = 5609249797830 := by decide
theorem cert_e1211203286726 : check e1211203286726 [[],[]] .chain = true := by decide
def e1211203286810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203286810 : Closed e1211203286810 ∧ code e1211203286810 = 5609249797914 := by decide
theorem cert_e1211203286810 : check e1211203286810 [[],[]] .sourceHead = true := by decide
def e1211203286854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203286854 : Closed e1211203286854 ∧ code e1211203286854 = 5609249797958 := by decide
theorem cert_e1211203286854 : check e1211203286854 [[],[]] .sourceHead = true := by decide
def e1211203289782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203289782 : Closed e1211203289782 ∧ code e1211203289782 = 5609249800886 := by decide
theorem cert_e1211203289782 : check e1211203289782 [[],[]] .chain = true := by decide
def e1211203289814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203289814 : Closed e1211203289814 ∧ code e1211203289814 = 5609249800918 := by decide
theorem cert_e1211203289814 : check e1211203289814 [[],[]] .chain = true := by decide
def e1211203289818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203289818 : Closed e1211203289818 ∧ code e1211203289818 = 5609249800922 := by decide
theorem cert_e1211203289818 : check e1211203289818 [[],[]] .chain = true := by decide
def e1211203289942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203289942 : Closed e1211203289942 ∧ code e1211203289942 = 5609249801046 := by decide
theorem cert_e1211203289942 : check e1211203289942 [[],[]] .chain = true := by decide
def e1211203289946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203289946 : Closed e1211203289946 ∧ code e1211203289946 = 5609249801050 := by decide
theorem cert_e1211203289946 : check e1211203289946 [[],[]] .chain = true := by decide
def e1211203289962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203289962 : Closed e1211203289962 ∧ code e1211203289962 = 5609249801066 := by decide
theorem cert_e1211203289962 : check e1211203289962 [[],[]] .chain = true := by decide
def e1211203291350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203291350 : Closed e1211203291350 ∧ code e1211203291350 = 5609249802454 := by decide
theorem cert_e1211203291350 : check e1211203291350 [[],[]] .chain = true := by decide
def e1211203291354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203291354 : Closed e1211203291354 ∧ code e1211203291354 = 5609249802458 := by decide
theorem cert_e1211203291354 : check e1211203291354 [[],[]] .chain = true := by decide
def e1211203291370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203291370 : Closed e1211203291370 ∧ code e1211203291370 = 5609249802474 := by decide
theorem cert_e1211203291370 : check e1211203291370 [[],[]] .chain = true := by decide
def e1211203291702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203291702 : Closed e1211203291702 ∧ code e1211203291702 = 5609249802806 := by decide
theorem cert_e1211203291702 : check e1211203291702 [[],[]] .chain = true := by decide
def e1211203291706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203291706 : Closed e1211203291706 ∧ code e1211203291706 = 5609249802810 := by decide
theorem cert_e1211203291706 : check e1211203291706 [[],[]] .chain = true := by decide
def e1211203291790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203291790 : Closed e1211203291790 ∧ code e1211203291790 = 5609249802894 := by decide
theorem cert_e1211203291790 : check e1211203291790 [[],[]] .chain = true := by decide
def e1211203291846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203291846 : Closed e1211203291846 ∧ code e1211203291846 = 5609249802950 := by decide
theorem cert_e1211203291846 : check e1211203291846 [[],[]] .chain = true := by decide
def e1211203291930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203291930 : Closed e1211203291930 ∧ code e1211203291930 = 5609249803034 := by decide
theorem cert_e1211203291930 : check e1211203291930 [[],[]] .chain = true := by decide
def e1211203291974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203291974 : Closed e1211203291974 ∧ code e1211203291974 = 5609249803078 := by decide
theorem cert_e1211203291974 : check e1211203291974 [[],[]] .chain = true := by decide
def e1211203292246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203292246 : Closed e1211203292246 ∧ code e1211203292246 = 5609249803350 := by decide
theorem cert_e1211203292246 : check e1211203292246 [[],[]] .chain = true := by decide
def e1211203292250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203292250 : Closed e1211203292250 ∧ code e1211203292250 = 5609249803354 := by decide
theorem cert_e1211203292250 : check e1211203292250 [[],[]] .chain = true := by decide
def e1211203292438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203292438 : Closed e1211203292438 ∧ code e1211203292438 = 5609249803542 := by decide
theorem cert_e1211203292438 : check e1211203292438 [[],[]] .chain = true := by decide
def e1211203292514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203292514 : Closed e1211203292514 ∧ code e1211203292514 = 5609249803618 := by decide
theorem cert_e1211203292514 : check e1211203292514 [[],[]] .chain = true := by decide
def e1211203292526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203292526 : Closed e1211203292526 ∧ code e1211203292526 = 5609249803630 := by decide
theorem cert_e1211203292526 : check e1211203292526 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203292534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203292534 : Closed e1211203292534 ∧ code e1211203292534 = 5609249803638 := by decide
theorem cert_e1211203292534 : check e1211203292534 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211203292554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203292554 : Closed e1211203292554 ∧ code e1211203292554 = 5609249803658 := by decide
theorem cert_e1211203292554 : check e1211203292554 [[],[]] .chain = true := by decide
def e1211203292578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203292578 : Closed e1211203292578 ∧ code e1211203292578 = 5609249803682 := by decide
theorem cert_e1211203292578 : check e1211203292578 [[],[]] .chain = true := by decide
def e1211203292590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203292590 : Closed e1211203292590 ∧ code e1211203292590 = 5609249803694 := by decide
theorem cert_e1211203292590 : check e1211203292590 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203292598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e1211203292598 : Closed e1211203292598 ∧ code e1211203292598 = 5609249803702 := by decide
theorem cert_e1211203292598 : check e1211203292598 [[],[]] .chain = true := by decide
def e1211203292602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203292602 : Closed e1211203292602 ∧ code e1211203292602 = 5609249803706 := by decide
theorem cert_e1211203292602 : check e1211203292602 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211203292630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203292630 : Closed e1211203292630 ∧ code e1211203292630 = 5609249803734 := by decide
theorem cert_e1211203292630 : check e1211203292630 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203292634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203292634 : Closed e1211203292634 ∧ code e1211203292634 = 5609249803738 := by decide
theorem cert_e1211203292634 : check e1211203292634 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203292714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203292714 : Closed e1211203292714 ∧ code e1211203292714 = 5609249803818 := by decide
theorem cert_e1211203292714 : check e1211203292714 [[],[]] .chain = true := by decide
def e1211203292810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203292810 : Closed e1211203292810 ∧ code e1211203292810 = 5609249803914 := by decide
theorem cert_e1211203292810 : check e1211203292810 [[],[]] .chain = true := by decide
def e1211203292834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203292834 : Closed e1211203292834 ∧ code e1211203292834 = 5609249803938 := by decide
theorem cert_e1211203292834 : check e1211203292834 [[],[]] .chain = true := by decide
def e1211203292846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203292846 : Closed e1211203292846 ∧ code e1211203292846 = 5609249803950 := by decide
theorem cert_e1211203292846 : check e1211203292846 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203292854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203292854 : Closed e1211203292854 ∧ code e1211203292854 = 5609249803958 := by decide
theorem cert_e1211203292854 : check e1211203292854 [[],[]] .chain = true := by decide
def e1211203292858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203292858 : Closed e1211203292858 ∧ code e1211203292858 = 5609249803962 := by decide
theorem cert_e1211203292858 : check e1211203292858 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211203292886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203292886 : Closed e1211203292886 ∧ code e1211203292886 = 5609249803990 := by decide
theorem cert_e1211203292886 : check e1211203292886 [[],[]] .chain = true := by decide
def e1211203292890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203292890 : Closed e1211203292890 ∧ code e1211203292890 = 5609249803994 := by decide
theorem cert_e1211203292890 : check e1211203292890 [[],[]] .chain = true := by decide
def e1211203292906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203292906 : Closed e1211203292906 ∧ code e1211203292906 = 5609249804010 := by decide
theorem cert_e1211203292906 : check e1211203292906 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203293014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203293014 : Closed e1211203293014 ∧ code e1211203293014 = 5609249804118 := by decide
theorem cert_e1211203293014 : check e1211203293014 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211203293018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203293018 : Closed e1211203293018 ∧ code e1211203293018 = 5609249804122 := by decide
theorem cert_e1211203293018 : check e1211203293018 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211203293034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203293034 : Closed e1211203293034 ∧ code e1211203293034 = 5609249804138 := by decide
theorem cert_e1211203293034 : check e1211203293034 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e1211203295926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203295926 : Closed e1211203295926 ∧ code e1211203295926 = 5609249807030 := by decide
theorem cert_e1211203295926 : check e1211203295926 [[],[]] .chain = true := by decide
def e1211203295958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203295958 : Closed e1211203295958 ∧ code e1211203295958 = 5609249807062 := by decide
theorem cert_e1211203295958 : check e1211203295958 [[],[]] .chain = true := by decide
def e1211203295962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203295962 : Closed e1211203295962 ∧ code e1211203295962 = 5609249807066 := by decide
theorem cert_e1211203295962 : check e1211203295962 [[],[]] .chain = true := by decide
def e1211203296086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203296086 : Closed e1211203296086 ∧ code e1211203296086 = 5609249807190 := by decide
theorem cert_e1211203296086 : check e1211203296086 [[],[]] .chain = true := by decide
def e1211203296090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203296090 : Closed e1211203296090 ∧ code e1211203296090 = 5609249807194 := by decide
theorem cert_e1211203296090 : check e1211203296090 [[],[]] .chain = true := by decide
def e1211203296106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203296106 : Closed e1211203296106 ∧ code e1211203296106 = 5609249807210 := by decide
theorem cert_e1211203296106 : check e1211203296106 [[],[]] .chain = true := by decide
def e1211203296598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203296598 : Closed e1211203296598 ∧ code e1211203296598 = 5609249807702 := by decide
theorem cert_e1211203296598 : check e1211203296598 [[],[]] .chain = true := by decide
def e1211203296602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203296602 : Closed e1211203296602 ∧ code e1211203296602 = 5609249807706 := by decide
theorem cert_e1211203296602 : check e1211203296602 [[],[]] .chain = true := by decide
def e1211203296618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203296618 : Closed e1211203296618 ∧ code e1211203296618 = 5609249807722 := by decide
theorem cert_e1211203296618 : check e1211203296618 [[],[]] .chain = true := by decide
def e1211203296682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203296682 : Closed e1211203296682 ∧ code e1211203296682 = 5609249807786 := by decide
theorem cert_e1211203296682 : check e1211203296682 [[],[]] .chain = true := by decide
def e1211203297462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e1211203297462 : Closed e1211203297462 ∧ code e1211203297462 = 5609249808566 := by decide
theorem cert_e1211203297462 : check e1211203297462 [[],[]] .chain = true := by decide
def e1211203297494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203297494 : Closed e1211203297494 ∧ code e1211203297494 = 5609249808598 := by decide
theorem cert_e1211203297494 : check e1211203297494 [[],[]] .chain = true := by decide
def e1211203297498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203297498 : Closed e1211203297498 ∧ code e1211203297498 = 5609249808602 := by decide
theorem cert_e1211203297498 : check e1211203297498 [[],[]] .chain = true := by decide
def e1211203297846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203297846 : Closed e1211203297846 ∧ code e1211203297846 = 5609249808950 := by decide
theorem cert_e1211203297846 : check e1211203297846 [[],[]] .chain = true := by decide
def e1211203297850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203297850 : Closed e1211203297850 ∧ code e1211203297850 = 5609249808954 := by decide
theorem cert_e1211203297850 : check e1211203297850 [[],[]] .chain = true := by decide
def e1211203297934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203297934 : Closed e1211203297934 ∧ code e1211203297934 = 5609249809038 := by decide
theorem cert_e1211203297934 : check e1211203297934 [[],[]] .chain = true := by decide
def e1211203297990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203297990 : Closed e1211203297990 ∧ code e1211203297990 = 5609249809094 := by decide
theorem cert_e1211203297990 : check e1211203297990 [[],[]] .chain = true := by decide
def e1211203298070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203298070 : Closed e1211203298070 ∧ code e1211203298070 = 5609249809174 := by decide
theorem cert_e1211203298070 : check e1211203298070 [[],[]] .chain = true := by decide
def e1211203298146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203298146 : Closed e1211203298146 ∧ code e1211203298146 = 5609249809250 := by decide
theorem cert_e1211203298146 : check e1211203298146 [[],[]] .chain = true := by decide
def e1211203298158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203298158 : Closed e1211203298158 ∧ code e1211203298158 = 5609249809262 := by decide
theorem cert_e1211203298158 : check e1211203298158 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203298166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203298166 : Closed e1211203298166 ∧ code e1211203298166 = 5609249809270 := by decide
theorem cert_e1211203298166 : checkPay e1211203298166 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211203298186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203298186 : Closed e1211203298186 ∧ code e1211203298186 = 5609249809290 := by decide
theorem cert_e1211203298186 : check e1211203298186 [[],[]] .chain = true := by decide
def e1211203298210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203298210 : Closed e1211203298210 ∧ code e1211203298210 = 5609249809314 := by decide
theorem cert_e1211203298210 : check e1211203298210 [[],[]] .chain = true := by decide
def e1211203298222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1211203298222 : Closed e1211203298222 ∧ code e1211203298222 = 5609249809326 := by decide
theorem cert_e1211203298222 : check e1211203298222 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203298230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1211203298230 : Closed e1211203298230 ∧ code e1211203298230 = 5609249809334 := by decide
theorem cert_e1211203298230 : check e1211203298230 [[],[]] .chain = true := by decide
def e1211203298234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1211203298234 : Closed e1211203298234 ∧ code e1211203298234 = 5609249809338 := by decide
theorem cert_e1211203298234 : check e1211203298234 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203298262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1211203298262 : Closed e1211203298262 ∧ code e1211203298262 = 5609249809366 := by decide
theorem cert_e1211203298262 : check e1211203298262 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203298266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1211203298266 : Closed e1211203298266 ∧ code e1211203298266 = 5609249809370 := by decide
theorem cert_e1211203298266 : check e1211203298266 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203298998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203298998 : Closed e1211203298998 ∧ code e1211203298998 = 5609249810102 := by decide
theorem cert_e1211203298998 : check e1211203298998 [[],[]] .chain = true := by decide
def e1211203299030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203299030 : Closed e1211203299030 ∧ code e1211203299030 = 5609249810134 := by decide
theorem cert_e1211203299030 : check e1211203299030 [[],[]] .chain = true := by decide
def e1211203299034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203299034 : Closed e1211203299034 ∧ code e1211203299034 = 5609249810138 := by decide
theorem cert_e1211203299034 : check e1211203299034 [[],[]] .chain = true := by decide
def e1211203299158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203299158 : Closed e1211203299158 ∧ code e1211203299158 = 5609249810262 := by decide
theorem cert_e1211203299158 : check e1211203299158 [[],[]] .chain = true := by decide
def e1211203299162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203299162 : Closed e1211203299162 ∧ code e1211203299162 = 5609249810266 := by decide
theorem cert_e1211203299162 : check e1211203299162 [[],[]] .chain = true := by decide
def e1211203299178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203299178 : Closed e1211203299178 ∧ code e1211203299178 = 5609249810282 := by decide
theorem cert_e1211203299178 : check e1211203299178 [[],[]] .chain = true := by decide
def e1211203299382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203299382 : Closed e1211203299382 ∧ code e1211203299382 = 5609249810486 := by decide
theorem cert_e1211203299382 : check e1211203299382 [[],[]] .chain = true := by decide
def e1211203299470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203299470 : Closed e1211203299470 ∧ code e1211203299470 = 5609249810574 := by decide
theorem cert_e1211203299470 : check e1211203299470 [[],[]] .chain = true := by decide
def e1211203299554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203299554 : Closed e1211203299554 ∧ code e1211203299554 = 5609249810658 := by decide
theorem cert_e1211203299554 : check e1211203299554 [[],[]] .chain = true := by decide
def e1211203299566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203299566 : Closed e1211203299566 ∧ code e1211203299566 = 5609249810670 := by decide
theorem cert_e1211203299566 : check e1211203299566 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203299574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203299574 : Closed e1211203299574 ∧ code e1211203299574 = 5609249810678 := by decide
theorem cert_e1211203299574 : check e1211203299574 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203299766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203299766 : Closed e1211203299766 ∧ code e1211203299766 = 5609249810870 := by decide
theorem cert_e1211203299766 : check e1211203299766 [[],[]] .chain = true := by decide
def e1211203299798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203299798 : Closed e1211203299798 ∧ code e1211203299798 = 5609249810902 := by decide
theorem cert_e1211203299798 : check e1211203299798 [[],[]] .chain = true := by decide
def e1211203299802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203299802 : Closed e1211203299802 ∧ code e1211203299802 = 5609249810906 := by decide
theorem cert_e1211203299802 : check e1211203299802 [[],[]] .chain = true := by decide
def e1211203299958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203299958 : Closed e1211203299958 ∧ code e1211203299958 = 5609249811062 := by decide
theorem cert_e1211203299958 : check e1211203299958 [[],[]] .chain = true := by decide
def e1211203300102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203300102 : Closed e1211203300102 ∧ code e1211203300102 = 5609249811206 := by decide
theorem cert_e1211203300102 : check e1211203300102 [[],[]] .chain = true := by decide
def e1211203300126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203300126 : Closed e1211203300126 ∧ code e1211203300126 = 5609249811230 := by decide
theorem cert_e1211203300126 : check e1211203300126 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203300150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203300150 : Closed e1211203300150 ∧ code e1211203300150 = 5609249811254 := by decide
theorem cert_e1211203300150 : check e1211203300150 [[],[]] .chain = true := by decide
def e1211203300154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203300154 : Closed e1211203300154 ∧ code e1211203300154 = 5609249811258 := by decide
theorem cert_e1211203300154 : check e1211203300154 [[],[]] .chain = true := by decide
def e1211203300238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203300238 : Closed e1211203300238 ∧ code e1211203300238 = 5609249811342 := by decide
theorem cert_e1211203300238 : check e1211203300238 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203300374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203300374 : Closed e1211203300374 ∧ code e1211203300374 = 5609249811478 := by decide
theorem cert_e1211203300374 : check e1211203300374 [[],[]] .chain = true := by decide
def e1211203300378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203300378 : Closed e1211203300378 ∧ code e1211203300378 = 5609249811482 := by decide
theorem cert_e1211203300378 : check e1211203300378 [[],[]] .chain = true := by decide
def e1211203300422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203300422 : Closed e1211203300422 ∧ code e1211203300422 = 5609249811526 := by decide
theorem cert_e1211203300422 : check e1211203300422 [[],[]] .chain = true := by decide
def e1211203300450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203300450 : Closed e1211203300450 ∧ code e1211203300450 = 5609249811554 := by decide
theorem cert_e1211203300450 : check e1211203300450 [[],[]] .chain = true := by decide
def e1211203300462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203300462 : Closed e1211203300462 ∧ code e1211203300462 = 5609249811566 := by decide
theorem cert_e1211203300462 : check e1211203300462 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203300470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203300470 : Closed e1211203300470 ∧ code e1211203300470 = 5609249811574 := by decide
theorem cert_e1211203300470 : check e1211203300470 [[],[]] .chain = true := by decide
def e1211203300474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203300474 : Closed e1211203300474 ∧ code e1211203300474 = 5609249811578 := by decide
theorem cert_e1211203300474 : check e1211203300474 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203300566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203300566 : Closed e1211203300566 ∧ code e1211203300566 = 5609249811670 := by decide
theorem cert_e1211203300566 : check e1211203300566 [[],[]] .chain = true := by decide
def e1211203300570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203300570 : Closed e1211203300570 ∧ code e1211203300570 = 5609249811674 := by decide
theorem cert_e1211203300570 : check e1211203300570 [[],[]] .chain = true := by decide
def e1211203300586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203300586 : Closed e1211203300586 ∧ code e1211203300586 = 5609249811690 := by decide
theorem cert_e1211203300586 : check e1211203300586 [[],[]] .chain = true := by decide
def e1211203300614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203300614 : Closed e1211203300614 ∧ code e1211203300614 = 5609249811718 := by decide
theorem cert_e1211203300614 : check e1211203300614 [[],[]] .chain = true := by decide
def e1211203300638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203300638 : Closed e1211203300638 ∧ code e1211203300638 = 5609249811742 := by decide
theorem cert_e1211203300638 : check e1211203300638 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203300662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203300662 : Closed e1211203300662 ∧ code e1211203300662 = 5609249811766 := by decide
theorem cert_e1211203300662 : check e1211203300662 [[],[]] .chain = true := by decide
def e1211203300666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203300666 : Closed e1211203300666 ∧ code e1211203300666 = 5609249811770 := by decide
theorem cert_e1211203300666 : check e1211203300666 [[],[]] .chain = true := by decide
def e1211203300738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203300738 : Closed e1211203300738 ∧ code e1211203300738 = 5609249811842 := by decide
theorem cert_e1211203300738 : check e1211203300738 [[],[]] .chain = true := by decide
def e1211203300750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203300750 : Closed e1211203300750 ∧ code e1211203300750 = 5609249811854 := by decide
theorem cert_e1211203300750 : check e1211203300750 [[],[]] .chain = true := by decide
def e1211203300762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203300762 : Closed e1211203300762 ∧ code e1211203300762 = 5609249811866 := by decide
theorem cert_e1211203300762 : check e1211203300762 [[],[]] .chain = true := by decide
def e1211203300806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203300806 : Closed e1211203300806 ∧ code e1211203300806 = 5609249811910 := by decide
theorem cert_e1211203300806 : check e1211203300806 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203300918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203300918 : Closed e1211203300918 ∧ code e1211203300918 = 5609249812022 := by decide
theorem cert_e1211203300918 : check e1211203300918 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203300922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203300922 : Closed e1211203300922 ∧ code e1211203300922 = 5609249812026 := by decide
theorem cert_e1211203300922 : check e1211203300922 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203301006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203301006 : Closed e1211203301006 ∧ code e1211203301006 = 5609249812110 := by decide
theorem cert_e1211203301006 : check e1211203301006 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203301062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203301062 : Closed e1211203301062 ∧ code e1211203301062 = 5609249812166 := by decide
theorem cert_e1211203301062 : check e1211203301062 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203301462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203301462 : Closed e1211203301462 ∧ code e1211203301462 = 5609249812566 := by decide
theorem cert_e1211203301462 : check e1211203301462 [[],[]] .chain = true := by decide
def e1211203301466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203301466 : Closed e1211203301466 ∧ code e1211203301466 = 5609249812570 := by decide
theorem cert_e1211203301466 : check e1211203301466 [[],[]] .chain = true := by decide
def e1211203301482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203301482 : Closed e1211203301482 ∧ code e1211203301482 = 5609249812586 := by decide
theorem cert_e1211203301482 : check e1211203301482 [[],[]] .chain = true := by decide
def e1211203301658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203301658 : Closed e1211203301658 ∧ code e1211203301658 = 5609249812762 := by decide
theorem cert_e1211203301658 : check e1211203301658 [[],[]] .chain = true := by decide
def e1211203301702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203301702 : Closed e1211203301702 ∧ code e1211203301702 = 5609249812806 := by decide
theorem cert_e1211203301702 : check e1211203301702 [[],[]] .chain = true := by decide
def e1211203301770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203301770 : Closed e1211203301770 ∧ code e1211203301770 = 5609249812874 := by decide
theorem cert_e1211203301770 : check e1211203301770 [[],[]] .chain = true := by decide
def e1211203301794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203301794 : Closed e1211203301794 ∧ code e1211203301794 = 5609249812898 := by decide
theorem cert_e1211203301794 : check e1211203301794 [[],[]] .chain = true := by decide
def e1211203301806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203301806 : Closed e1211203301806 ∧ code e1211203301806 = 5609249812910 := by decide
theorem cert_e1211203301806 : check e1211203301806 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203301814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e1211203301814 : Closed e1211203301814 ∧ code e1211203301814 = 5609249812918 := by decide
theorem cert_e1211203301814 : check e1211203301814 [[],[]] .chain = true := by decide
def e1211203301818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203301818 : Closed e1211203301818 ∧ code e1211203301818 = 5609249812922 := by decide
theorem cert_e1211203301818 : check e1211203301818 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211203301846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203301846 : Closed e1211203301846 ∧ code e1211203301846 = 5609249812950 := by decide
theorem cert_e1211203301846 : check e1211203301846 [[],[]] .chain = true := by decide
def e1211203301850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203301850 : Closed e1211203301850 ∧ code e1211203301850 = 5609249812954 := by decide
theorem cert_e1211203301850 : check e1211203301850 [[],[]] .chain = true := by decide
def e1211203301866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1211203301866 : Closed e1211203301866 ∧ code e1211203301866 = 5609249812970 := by decide
theorem cert_e1211203301866 : check e1211203301866 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203302230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203302230 : Closed e1211203302230 ∧ code e1211203302230 = 5609249813334 := by decide
theorem cert_e1211203302230 : check e1211203302230 [[],[]] .chain = true := by decide
def e1211203302234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203302234 : Closed e1211203302234 ∧ code e1211203302234 = 5609249813338 := by decide
theorem cert_e1211203302234 : check e1211203302234 [[],[]] .chain = true := by decide
def e1211203302250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203302250 : Closed e1211203302250 ∧ code e1211203302250 = 5609249813354 := by decide
theorem cert_e1211203302250 : check e1211203302250 [[],[]] .chain = true := by decide
def e1211203302314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203302314 : Closed e1211203302314 ∧ code e1211203302314 = 5609249813418 := by decide
theorem cert_e1211203302314 : check e1211203302314 [[],[]] .chain = true := by decide
def e1211203302422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203302422 : Closed e1211203302422 ∧ code e1211203302422 = 5609249813526 := by decide
theorem cert_e1211203302422 : check e1211203302422 [[],[]] .chain = true := by decide
def e1211203302426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203302426 : Closed e1211203302426 ∧ code e1211203302426 = 5609249813530 := by decide
theorem cert_e1211203302426 : check e1211203302426 [[],[]] .chain = true := by decide
def e1211203302470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203302470 : Closed e1211203302470 ∧ code e1211203302470 = 5609249813574 := by decide
theorem cert_e1211203302470 : check e1211203302470 [[],[]] .chain = true := by decide
def e1211203302498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203302498 : Closed e1211203302498 ∧ code e1211203302498 = 5609249813602 := by decide
theorem cert_e1211203302498 : check e1211203302498 [[],[]] .chain = true := by decide
def e1211203302510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203302510 : Closed e1211203302510 ∧ code e1211203302510 = 5609249813614 := by decide
theorem cert_e1211203302510 : check e1211203302510 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203302518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203302518 : Closed e1211203302518 ∧ code e1211203302518 = 5609249813622 := by decide
theorem cert_e1211203302518 : check e1211203302518 [[],[]] .chain = true := by decide
def e1211203302522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203302522 : Closed e1211203302522 ∧ code e1211203302522 = 5609249813626 := by decide
theorem cert_e1211203302522 : check e1211203302522 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211203302614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203302614 : Closed e1211203302614 ∧ code e1211203302614 = 5609249813718 := by decide
theorem cert_e1211203302614 : check e1211203302614 [[],[]] .chain = true := by decide
def e1211203302618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203302618 : Closed e1211203302618 ∧ code e1211203302618 = 5609249813722 := by decide
theorem cert_e1211203302618 : check e1211203302618 [[],[]] .chain = true := by decide
def e1211203302634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203302634 : Closed e1211203302634 ∧ code e1211203302634 = 5609249813738 := by decide
theorem cert_e1211203302634 : check e1211203302634 [[],[]] .chain = true := by decide
def e1211203302662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203302662 : Closed e1211203302662 ∧ code e1211203302662 = 5609249813766 := by decide
theorem cert_e1211203302662 : check e1211203302662 [[],[]] .chain = true := by decide
def e1211203302686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203302686 : Closed e1211203302686 ∧ code e1211203302686 = 5609249813790 := by decide
theorem cert_e1211203302686 : check e1211203302686 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203302710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203302710 : Closed e1211203302710 ∧ code e1211203302710 = 5609249813814 := by decide
theorem cert_e1211203302710 : check e1211203302710 [[],[]] .chain = true := by decide
def e1211203302714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203302714 : Closed e1211203302714 ∧ code e1211203302714 = 5609249813818 := by decide
theorem cert_e1211203302714 : check e1211203302714 [[],[]] .chain = true := by decide
def e1211203302786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203302786 : Closed e1211203302786 ∧ code e1211203302786 = 5609249813890 := by decide
theorem cert_e1211203302786 : check e1211203302786 [[],[]] .chain = true := by decide
def e1211203302798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203302798 : Closed e1211203302798 ∧ code e1211203302798 = 5609249813902 := by decide
theorem cert_e1211203302798 : check e1211203302798 [[],[]] .chain = true := by decide
def e1211203302810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203302810 : Closed e1211203302810 ∧ code e1211203302810 = 5609249813914 := by decide
theorem cert_e1211203302810 : check e1211203302810 [[],[]] .chain = true := by decide
end Blc.Floor42
