import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203544554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211203544554 : Closed e1211203544554 ∧ code e1211203544554 = 5609250055658 := by decide
theorem cert_e1211203544554 : check e1211203544554 [[],[]] .chain = true := by decide
def e1211203544686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203544686 : Closed e1211203544686 ∧ code e1211203544686 = 5609250055790 := by decide
theorem cert_e1211203544686 : check e1211203544686 [[],[]] .chain = true := by decide
def e1211203544698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203544698 : Closed e1211203544698 ∧ code e1211203544698 = 5609250055802 := by decide
theorem cert_e1211203544698 : check e1211203544698 [[],[]] .chain = true := by decide
def e1211203544862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203544862 : Closed e1211203544862 ∧ code e1211203544862 = 5609250055966 := by decide
theorem cert_e1211203544862 : check e1211203544862 [[],[]] .chain = true := by decide
def e1211203544962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203544962 : Closed e1211203544962 ∧ code e1211203544962 = 5609250056066 := by decide
theorem cert_e1211203544962 : check e1211203544962 [[],[]] .chain = true := by decide
def e1211203544974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203544974 : Closed e1211203544974 ∧ code e1211203544974 = 5609250056078 := by decide
theorem cert_e1211203544974 : check e1211203544974 [[],[]] .chain = true := by decide
def e1211203544986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203544986 : Closed e1211203544986 ∧ code e1211203544986 = 5609250056090 := by decide
theorem cert_e1211203544986 : check e1211203544986 [[],[]] .chain = true := by decide
def e1211203547166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203547166 : Closed e1211203547166 ∧ code e1211203547166 = 5609250058270 := by decide
theorem cert_e1211203547166 : check e1211203547166 [[],[]] .chain = true := by decide
def e1211203547334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203547334 : Closed e1211203547334 ∧ code e1211203547334 = 5609250058438 := by decide
theorem cert_e1211203547334 : check e1211203547334 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203547358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203547358 : Closed e1211203547358 ∧ code e1211203547358 = 5609250058462 := by decide
theorem cert_e1211203547358 : check e1211203547358 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203547362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203547362 : Closed e1211203547362 ∧ code e1211203547362 = 5609250058466 := by decide
theorem cert_e1211203547362 : check e1211203547362 [[],[]] .chain = true := by decide
def e1211203547374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203547374 : Closed e1211203547374 ∧ code e1211203547374 = 5609250058478 := by decide
theorem cert_e1211203547374 : check e1211203547374 [[],[]] .chain = true := by decide
def e1211203547382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203547382 : Closed e1211203547382 ∧ code e1211203547382 = 5609250058486 := by decide
theorem cert_e1211203547382 : check e1211203547382 [[],[]] .chain = true := by decide
def e1211203547386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203547386 : Closed e1211203547386 ∧ code e1211203547386 = 5609250058490 := by decide
theorem cert_e1211203547386 : check e1211203547386 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203547862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203547862 : Closed e1211203547862 ∧ code e1211203547862 = 5609250058966 := by decide
theorem cert_e1211203547862 : check e1211203547862 [[],[]] .chain = true := by decide
def e1211203547866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203547866 : Closed e1211203547866 ∧ code e1211203547866 = 5609250058970 := by decide
theorem cert_e1211203547866 : check e1211203547866 [[],[]] .chain = true := by decide
def e1211203547882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203547882 : Closed e1211203547882 ∧ code e1211203547882 = 5609250058986 := by decide
theorem cert_e1211203547882 : check e1211203547882 [[],[]] .chain = true := by decide
def e1211203547910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203547910 : Closed e1211203547910 ∧ code e1211203547910 = 5609250059014 := by decide
theorem cert_e1211203547910 : check e1211203547910 [[],[]] .chain = true := by decide
def e1211203547934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203547934 : Closed e1211203547934 ∧ code e1211203547934 = 5609250059038 := by decide
theorem cert_e1211203547934 : check e1211203547934 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203547958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203547958 : Closed e1211203547958 ∧ code e1211203547958 = 5609250059062 := by decide
theorem cert_e1211203547958 : check e1211203547958 [[],[]] .chain = true := by decide
def e1211203547962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203547962 : Closed e1211203547962 ∧ code e1211203547962 = 5609250059066 := by decide
theorem cert_e1211203547962 : check e1211203547962 [[],[]] .chain = true := by decide
def e1211203548034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203548034 : Closed e1211203548034 ∧ code e1211203548034 = 5609250059138 := by decide
theorem cert_e1211203548034 : check e1211203548034 [[],[]] .chain = true := by decide
def e1211203548046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203548046 : Closed e1211203548046 ∧ code e1211203548046 = 5609250059150 := by decide
theorem cert_e1211203548046 : check e1211203548046 [[],[]] .chain = true := by decide
def e1211203548058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203548058 : Closed e1211203548058 ∧ code e1211203548058 = 5609250059162 := by decide
theorem cert_e1211203548058 : check e1211203548058 [[],[]] .chain = true := by decide
def e1211203548102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203548102 : Closed e1211203548102 ∧ code e1211203548102 = 5609250059206 := by decide
theorem cert_e1211203548102 : check e1211203548102 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203551478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211203551478 : Closed e1211203551478 ∧ code e1211203551478 = 5609250062582 := by decide
theorem cert_e1211203551478 : check e1211203551478 [[],[]] .chain = true := by decide
def e1211203551482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e1211203551482 : Closed e1211203551482 ∧ code e1211203551482 = 5609250062586 := by decide
theorem cert_e1211203551482 : check e1211203551482 [[],[]] .chain = true := by decide
def e1211203551862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203551862 : Closed e1211203551862 ∧ code e1211203551862 = 5609250062966 := by decide
theorem cert_e1211203551862 : check e1211203551862 [[],[]] .chain = true := by decide
def e1211203552054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203552054 : Closed e1211203552054 ∧ code e1211203552054 = 5609250063158 := by decide
theorem cert_e1211203552054 : check e1211203552054 [[],[]] .chain = true := by decide
def e1211203552058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203552058 : Closed e1211203552058 ∧ code e1211203552058 = 5609250063162 := by decide
theorem cert_e1211203552058 : check e1211203552058 [[],[]] .chain = true := by decide
def e1211203552142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211203552142 : Closed e1211203552142 ∧ code e1211203552142 = 5609250063246 := by decide
theorem cert_e1211203552142 : check e1211203552142 [[],[]] .chain = true := by decide
def e1211203552198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1211203552198 : Closed e1211203552198 ∧ code e1211203552198 = 5609250063302 := by decide
theorem cert_e1211203552198 : check e1211203552198 [[],[]] .chain = true := by decide
def e1211203552822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211203552822 : Closed e1211203552822 ∧ code e1211203552822 = 5609250063926 := by decide
theorem cert_e1211203552822 : check e1211203552822 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203552910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211203552910 : Closed e1211203552910 ∧ code e1211203552910 = 5609250064014 := by decide
theorem cert_e1211203552910 : check e1211203552910 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203553006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e1211203553006 : Closed e1211203553006 ∧ code e1211203553006 = 5609250064110 := by decide
theorem cert_e1211203553006 : checkPay e1211203553006 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e1211203553014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e1211203553014 : Closed e1211203553014 ∧ code e1211203553014 = 5609250064118 := by decide
theorem cert_e1211203553014 : check e1211203553014 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203553046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203553046 : Closed e1211203553046 ∧ code e1211203553046 = 5609250064150 := by decide
theorem cert_e1211203553046 : check e1211203553046 [[],[]] .chain = true := by decide
def e1211203553142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1211203553142 : Closed e1211203553142 ∧ code e1211203553142 = 5609250064246 := by decide
theorem cert_e1211203553142 : check e1211203553142 [[],[]] .chain = true := by decide
def e1211203553162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203553162 : Closed e1211203553162 ∧ code e1211203553162 = 5609250064266 := by decide
theorem cert_e1211203553162 : check e1211203553162 [[],[]] .chain = true := by decide
def e1211203553198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e1211203553198 : Closed e1211203553198 ∧ code e1211203553198 = 5609250064302 := by decide
theorem cert_e1211203553198 : check e1211203553198 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203553206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1211203553206 : Closed e1211203553206 ∧ code e1211203553206 = 5609250064310 := by decide
theorem cert_e1211203553206 : check e1211203553206 [[],[]] .chain = true := by decide
def e1211203553210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1211203553210 : Closed e1211203553210 ∧ code e1211203553210 = 5609250064314 := by decide
theorem cert_e1211203553210 : check e1211203553210 [[],[]] .chain = true := by decide
def e1211203553238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e1211203553238 : Closed e1211203553238 ∧ code e1211203553238 = 5609250064342 := by decide
theorem cert_e1211203553238 : check e1211203553238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211203553678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203553678 : Closed e1211203553678 ∧ code e1211203553678 = 5609250064782 := by decide
theorem cert_e1211203553678 : check e1211203553678 [[],[]] .chain = true := by decide
def e1211203553734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203553734 : Closed e1211203553734 ∧ code e1211203553734 = 5609250064838 := by decide
theorem cert_e1211203553734 : check e1211203553734 [[],[]] .chain = true := by decide
def e1211203554334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e1211203554334 : Closed e1211203554334 ∧ code e1211203554334 = 5609250065438 := by decide
theorem cert_e1211203554334 : check e1211203554334 [[],[]] .chain = true := by decide
def e1211203554530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203554530 : Closed e1211203554530 ∧ code e1211203554530 = 5609250065634 := by decide
theorem cert_e1211203554530 : check e1211203554530 [[],[]] .chain = true := by decide
def e1211203554542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203554542 : Closed e1211203554542 ∧ code e1211203554542 = 5609250065646 := by decide
theorem cert_e1211203554542 : check e1211203554542 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203554550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203554550 : Closed e1211203554550 ∧ code e1211203554550 = 5609250065654 := by decide
theorem cert_e1211203554550 : check e1211203554550 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203554830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203554830 : Closed e1211203554830 ∧ code e1211203554830 = 5609250065934 := by decide
theorem cert_e1211203554830 : check e1211203554830 [[],[]] .chain = true := by decide
def e1211203554842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203554842 : Closed e1211203554842 ∧ code e1211203554842 = 5609250065946 := by decide
theorem cert_e1211203554842 : check e1211203554842 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203554914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203554914 : Closed e1211203554914 ∧ code e1211203554914 = 5609250066018 := by decide
theorem cert_e1211203554914 : check e1211203554914 [[],[]] .chain = true := by decide
def e1211203554926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203554926 : Closed e1211203554926 ∧ code e1211203554926 = 5609250066030 := by decide
theorem cert_e1211203554926 : check e1211203554926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203554934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203554934 : Closed e1211203554934 ∧ code e1211203554934 = 5609250066038 := by decide
theorem cert_e1211203554934 : check e1211203554934 [[],[]] .chain = true := by decide
def e1211203554938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203554938 : Closed e1211203554938 ∧ code e1211203554938 = 5609250066042 := by decide
theorem cert_e1211203554938 : check e1211203554938 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203555126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203555126 : Closed e1211203555126 ∧ code e1211203555126 = 5609250066230 := by decide
theorem cert_e1211203555126 : check e1211203555126 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203555130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203555130 : Closed e1211203555130 ∧ code e1211203555130 = 5609250066234 := by decide
theorem cert_e1211203555130 : check e1211203555130 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203557046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211203557046 : Closed e1211203557046 ∧ code e1211203557046 = 5609250068150 := by decide
theorem cert_e1211203557046 : check e1211203557046 [[],[]] .chain = true := by decide
def e1211203557078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211203557078 : Closed e1211203557078 ∧ code e1211203557078 = 5609250068182 := by decide
theorem cert_e1211203557078 : check e1211203557078 [[],[]] .chain = true := by decide
def e1211203557082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211203557082 : Closed e1211203557082 ∧ code e1211203557082 = 5609250068186 := by decide
theorem cert_e1211203557082 : check e1211203557082 [[],[]] .chain = true := by decide
def e1211203557206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203557206 : Closed e1211203557206 ∧ code e1211203557206 = 5609250068310 := by decide
theorem cert_e1211203557206 : check e1211203557206 [[],[]] .chain = true := by decide
def e1211203557210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203557210 : Closed e1211203557210 ∧ code e1211203557210 = 5609250068314 := by decide
theorem cert_e1211203557210 : check e1211203557210 [[],[]] .chain = true := by decide
def e1211203557226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203557226 : Closed e1211203557226 ∧ code e1211203557226 = 5609250068330 := by decide
theorem cert_e1211203557226 : check e1211203557226 [[],[]] .chain = true := by decide
def e1211203557430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211203557430 : Closed e1211203557430 ∧ code e1211203557430 = 5609250068534 := by decide
theorem cert_e1211203557430 : check e1211203557430 [[],[]] .chain = true := by decide
def e1211203557518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211203557518 : Closed e1211203557518 ∧ code e1211203557518 = 5609250068622 := by decide
theorem cert_e1211203557518 : check e1211203557518 [[],[]] .chain = true := by decide
def e1211203557602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211203557602 : Closed e1211203557602 ∧ code e1211203557602 = 5609250068706 := by decide
theorem cert_e1211203557602 : check e1211203557602 [[],[]] .chain = true := by decide
def e1211203557614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203557614 : Closed e1211203557614 ∧ code e1211203557614 = 5609250068718 := by decide
theorem cert_e1211203557614 : check e1211203557614 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203557622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203557622 : Closed e1211203557622 ∧ code e1211203557622 = 5609250068726 := by decide
theorem cert_e1211203557622 : check e1211203557622 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203557814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211203557814 : Closed e1211203557814 ∧ code e1211203557814 = 5609250068918 := by decide
theorem cert_e1211203557814 : check e1211203557814 [[],[]] .chain = true := by decide
def e1211203557846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211203557846 : Closed e1211203557846 ∧ code e1211203557846 = 5609250068950 := by decide
theorem cert_e1211203557846 : check e1211203557846 [[],[]] .chain = true := by decide
def e1211203557850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211203557850 : Closed e1211203557850 ∧ code e1211203557850 = 5609250068954 := by decide
theorem cert_e1211203557850 : check e1211203557850 [[],[]] .chain = true := by decide
def e1211203558006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203558006 : Closed e1211203558006 ∧ code e1211203558006 = 5609250069110 := by decide
theorem cert_e1211203558006 : check e1211203558006 [[],[]] .chain = true := by decide
def e1211203558150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203558150 : Closed e1211203558150 ∧ code e1211203558150 = 5609250069254 := by decide
theorem cert_e1211203558150 : check e1211203558150 [[],[]] .chain = true := by decide
def e1211203558174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203558174 : Closed e1211203558174 ∧ code e1211203558174 = 5609250069278 := by decide
theorem cert_e1211203558174 : check e1211203558174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203558198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203558198 : Closed e1211203558198 ∧ code e1211203558198 = 5609250069302 := by decide
theorem cert_e1211203558198 : check e1211203558198 [[],[]] .chain = true := by decide
def e1211203558202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203558202 : Closed e1211203558202 ∧ code e1211203558202 = 5609250069306 := by decide
theorem cert_e1211203558202 : check e1211203558202 [[],[]] .chain = true := by decide
def e1211203558286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203558286 : Closed e1211203558286 ∧ code e1211203558286 = 5609250069390 := by decide
theorem cert_e1211203558286 : check e1211203558286 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203558422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203558422 : Closed e1211203558422 ∧ code e1211203558422 = 5609250069526 := by decide
theorem cert_e1211203558422 : check e1211203558422 [[],[]] .chain = true := by decide
def e1211203558426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203558426 : Closed e1211203558426 ∧ code e1211203558426 = 5609250069530 := by decide
theorem cert_e1211203558426 : check e1211203558426 [[],[]] .chain = true := by decide
def e1211203558470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203558470 : Closed e1211203558470 ∧ code e1211203558470 = 5609250069574 := by decide
theorem cert_e1211203558470 : check e1211203558470 [[],[]] .chain = true := by decide
def e1211203558498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203558498 : Closed e1211203558498 ∧ code e1211203558498 = 5609250069602 := by decide
theorem cert_e1211203558498 : check e1211203558498 [[],[]] .chain = true := by decide
def e1211203558510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203558510 : Closed e1211203558510 ∧ code e1211203558510 = 5609250069614 := by decide
theorem cert_e1211203558510 : check e1211203558510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203558518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203558518 : Closed e1211203558518 ∧ code e1211203558518 = 5609250069622 := by decide
theorem cert_e1211203558518 : check e1211203558518 [[],[]] .chain = true := by decide
def e1211203558522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203558522 : Closed e1211203558522 ∧ code e1211203558522 = 5609250069626 := by decide
theorem cert_e1211203558522 : check e1211203558522 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203558614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203558614 : Closed e1211203558614 ∧ code e1211203558614 = 5609250069718 := by decide
theorem cert_e1211203558614 : check e1211203558614 [[],[]] .chain = true := by decide
def e1211203558618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203558618 : Closed e1211203558618 ∧ code e1211203558618 = 5609250069722 := by decide
theorem cert_e1211203558618 : check e1211203558618 [[],[]] .chain = true := by decide
def e1211203558634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203558634 : Closed e1211203558634 ∧ code e1211203558634 = 5609250069738 := by decide
theorem cert_e1211203558634 : check e1211203558634 [[],[]] .chain = true := by decide
def e1211203558662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203558662 : Closed e1211203558662 ∧ code e1211203558662 = 5609250069766 := by decide
theorem cert_e1211203558662 : check e1211203558662 [[],[]] .chain = true := by decide
def e1211203558686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203558686 : Closed e1211203558686 ∧ code e1211203558686 = 5609250069790 := by decide
theorem cert_e1211203558686 : check e1211203558686 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203558710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203558710 : Closed e1211203558710 ∧ code e1211203558710 = 5609250069814 := by decide
theorem cert_e1211203558710 : check e1211203558710 [[],[]] .chain = true := by decide
def e1211203558714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203558714 : Closed e1211203558714 ∧ code e1211203558714 = 5609250069818 := by decide
theorem cert_e1211203558714 : check e1211203558714 [[],[]] .chain = true := by decide
def e1211203558786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203558786 : Closed e1211203558786 ∧ code e1211203558786 = 5609250069890 := by decide
theorem cert_e1211203558786 : check e1211203558786 [[],[]] .chain = true := by decide
def e1211203558798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203558798 : Closed e1211203558798 ∧ code e1211203558798 = 5609250069902 := by decide
theorem cert_e1211203558798 : check e1211203558798 [[],[]] .chain = true := by decide
def e1211203558810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203558810 : Closed e1211203558810 ∧ code e1211203558810 = 5609250069914 := by decide
theorem cert_e1211203558810 : check e1211203558810 [[],[]] .chain = true := by decide
def e1211203558854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203558854 : Closed e1211203558854 ∧ code e1211203558854 = 5609250069958 := by decide
theorem cert_e1211203558854 : check e1211203558854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203558966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203558966 : Closed e1211203558966 ∧ code e1211203558966 = 5609250070070 := by decide
theorem cert_e1211203558966 : check e1211203558966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203558970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203558970 : Closed e1211203558970 ∧ code e1211203558970 = 5609250070074 := by decide
theorem cert_e1211203558970 : check e1211203558970 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203559054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203559054 : Closed e1211203559054 ∧ code e1211203559054 = 5609250070158 := by decide
theorem cert_e1211203559054 : check e1211203559054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203559110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203559110 : Closed e1211203559110 ∧ code e1211203559110 = 5609250070214 := by decide
theorem cert_e1211203559110 : check e1211203559110 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203559486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211203559486 : Closed e1211203559486 ∧ code e1211203559486 = 5609250070590 := by decide
theorem cert_e1211203559486 : check e1211203559486 [[],[]] .chain = true := by decide
def e1211203559906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211203559906 : Closed e1211203559906 ∧ code e1211203559906 = 5609250071010 := by decide
theorem cert_e1211203559906 : check e1211203559906 [[],[]] .chain = true := by decide
def e1211203559918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211203559918 : Closed e1211203559918 ∧ code e1211203559918 = 5609250071022 := by decide
theorem cert_e1211203559918 : check e1211203559918 [[],[]] .chain = true := by decide
def e1211203560886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211203560886 : Closed e1211203560886 ∧ code e1211203560886 = 5609250071990 := by decide
theorem cert_e1211203560886 : check e1211203560886 [[],[]] .chain = true := by decide
def e1211203560918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211203560918 : Closed e1211203560918 ∧ code e1211203560918 = 5609250072022 := by decide
theorem cert_e1211203560918 : check e1211203560918 [[],[]] .chain = true := by decide
def e1211203560922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211203560922 : Closed e1211203560922 ∧ code e1211203560922 = 5609250072026 := by decide
theorem cert_e1211203560922 : check e1211203560922 [[],[]] .chain = true := by decide
def e1211203561078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211203561078 : Closed e1211203561078 ∧ code e1211203561078 = 5609250072182 := by decide
theorem cert_e1211203561078 : check e1211203561078 [[],[]] .chain = true := by decide
def e1211203561222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203561222 : Closed e1211203561222 ∧ code e1211203561222 = 5609250072326 := by decide
theorem cert_e1211203561222 : check e1211203561222 [[],[]] .chain = true := by decide
def e1211203561246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203561246 : Closed e1211203561246 ∧ code e1211203561246 = 5609250072350 := by decide
theorem cert_e1211203561246 : check e1211203561246 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203561270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203561270 : Closed e1211203561270 ∧ code e1211203561270 = 5609250072374 := by decide
theorem cert_e1211203561270 : check e1211203561270 [[],[]] .chain = true := by decide
def e1211203561274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203561274 : Closed e1211203561274 ∧ code e1211203561274 = 5609250072378 := by decide
theorem cert_e1211203561274 : check e1211203561274 [[],[]] .chain = true := by decide
def e1211203561358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203561358 : Closed e1211203561358 ∧ code e1211203561358 = 5609250072462 := by decide
theorem cert_e1211203561358 : check e1211203561358 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203563550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203563550 : Closed e1211203563550 ∧ code e1211203563550 = 5609250074654 := by decide
theorem cert_e1211203563550 : check e1211203563550 [[],[]] .chain = true := by decide
def e1211203563718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203563718 : Closed e1211203563718 ∧ code e1211203563718 = 5609250074822 := by decide
theorem cert_e1211203563718 : check e1211203563718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203563742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203563742 : Closed e1211203563742 ∧ code e1211203563742 = 5609250074846 := by decide
theorem cert_e1211203563742 : check e1211203563742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203563746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203563746 : Closed e1211203563746 ∧ code e1211203563746 = 5609250074850 := by decide
theorem cert_e1211203563746 : check e1211203563746 [[],[]] .chain = true := by decide
def e1211203563758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203563758 : Closed e1211203563758 ∧ code e1211203563758 = 5609250074862 := by decide
theorem cert_e1211203563758 : check e1211203563758 [[],[]] .chain = true := by decide
def e1211203563766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203563766 : Closed e1211203563766 ∧ code e1211203563766 = 5609250074870 := by decide
theorem cert_e1211203563766 : check e1211203563766 [[],[]] .chain = true := by decide
def e1211203563770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203563770 : Closed e1211203563770 ∧ code e1211203563770 = 5609250074874 := by decide
theorem cert_e1211203563770 : check e1211203563770 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203564246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203564246 : Closed e1211203564246 ∧ code e1211203564246 = 5609250075350 := by decide
theorem cert_e1211203564246 : check e1211203564246 [[],[]] .chain = true := by decide
def e1211203564250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203564250 : Closed e1211203564250 ∧ code e1211203564250 = 5609250075354 := by decide
theorem cert_e1211203564250 : check e1211203564250 [[],[]] .chain = true := by decide
def e1211203564266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203564266 : Closed e1211203564266 ∧ code e1211203564266 = 5609250075370 := by decide
theorem cert_e1211203564266 : check e1211203564266 [[],[]] .chain = true := by decide
def e1211203564294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203564294 : Closed e1211203564294 ∧ code e1211203564294 = 5609250075398 := by decide
theorem cert_e1211203564294 : check e1211203564294 [[],[]] .chain = true := by decide
def e1211203564318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203564318 : Closed e1211203564318 ∧ code e1211203564318 = 5609250075422 := by decide
theorem cert_e1211203564318 : check e1211203564318 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203564342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203564342 : Closed e1211203564342 ∧ code e1211203564342 = 5609250075446 := by decide
theorem cert_e1211203564342 : check e1211203564342 [[],[]] .chain = true := by decide
def e1211203564346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203564346 : Closed e1211203564346 ∧ code e1211203564346 = 5609250075450 := by decide
theorem cert_e1211203564346 : check e1211203564346 [[],[]] .chain = true := by decide
def e1211203564418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203564418 : Closed e1211203564418 ∧ code e1211203564418 = 5609250075522 := by decide
theorem cert_e1211203564418 : check e1211203564418 [[],[]] .chain = true := by decide
def e1211203564430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203564430 : Closed e1211203564430 ∧ code e1211203564430 = 5609250075534 := by decide
theorem cert_e1211203564430 : check e1211203564430 [[],[]] .chain = true := by decide
def e1211203564442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203564442 : Closed e1211203564442 ∧ code e1211203564442 = 5609250075546 := by decide
theorem cert_e1211203564442 : check e1211203564442 [[],[]] .chain = true := by decide
def e1211203564486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203564486 : Closed e1211203564486 ∧ code e1211203564486 = 5609250075590 := by decide
theorem cert_e1211203564486 : check e1211203564486 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203565678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211203565678 : Closed e1211203565678 ∧ code e1211203565678 = 5609250076782 := by decide
theorem cert_e1211203565678 : check e1211203565678 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203565690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211203565690 : Closed e1211203565690 ∧ code e1211203565690 = 5609250076794 := by decide
theorem cert_e1211203565690 : check e1211203565690 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203565966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203565966 : Closed e1211203565966 ∧ code e1211203565966 = 5609250077070 := by decide
theorem cert_e1211203565966 : check e1211203565966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1211203566022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203566022 : Closed e1211203566022 ∧ code e1211203566022 = 5609250077126 := by decide
theorem cert_e1211203566022 : check e1211203566022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1211203585966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.var 2))))))
theorem wire_e1211203585966 : Closed e1211203585966 ∧ code e1211203585966 = 5609250097070 := by decide
theorem cert_e1211203585966 : check e1211203585966 [[],[]] .chain = true := by decide
def e1211203585978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 2)) (.var 0))))))
theorem wire_e1211203585978 : Closed e1211203585978 ∧ code e1211203585978 = 5609250097082 := by decide
theorem cert_e1211203585978 : check e1211203585978 [[],[]] .chain = true := by decide
def e1211203586026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 0)) (.var 0))))))
theorem wire_e1211203586026 : Closed e1211203586026 ∧ code e1211203586026 = 5609250097130 := by decide
theorem cert_e1211203586026 : check e1211203586026 [[],[]] .chain = true := by decide
def e1211203588974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203588974 : Closed e1211203588974 ∧ code e1211203588974 = 5609250100078 := by decide
theorem cert_e1211203588974 : check e1211203588974 [[],[]] .chain = true := by decide
def e1211203588982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203588982 : Closed e1211203588982 ∧ code e1211203588982 = 5609250100086 := by decide
theorem cert_e1211203588982 : check e1211203588982 [[],[]] .chain = true := by decide
def e1211203589038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203589038 : Closed e1211203589038 ∧ code e1211203589038 = 5609250100142 := by decide
theorem cert_e1211203589038 : check e1211203589038 [[],[]] .chain = true := by decide
def e1211203589050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203589050 : Closed e1211203589050 ∧ code e1211203589050 = 5609250100154 := by decide
theorem cert_e1211203589050 : check e1211203589050 [[],[]] .chain = true := by decide
def e1211203589078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203589078 : Closed e1211203589078 ∧ code e1211203589078 = 5609250100182 := by decide
theorem cert_e1211203589078 : check e1211203589078 [[],[]] .chain = true := by decide
def e1211203589082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203589082 : Closed e1211203589082 ∧ code e1211203589082 = 5609250100186 := by decide
theorem cert_e1211203589082 : check e1211203589082 [[],[]] .chain = true := by decide
def e1211203589358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203589358 : Closed e1211203589358 ∧ code e1211203589358 = 5609250100462 := by decide
theorem cert_e1211203589358 : check e1211203589358 [[],[]] .chain = true := by decide
def e1211203589366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203589366 : Closed e1211203589366 ∧ code e1211203589366 = 5609250100470 := by decide
theorem cert_e1211203589366 : check e1211203589366 [[],[]] .chain = true := by decide
def e1211203589742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203589742 : Closed e1211203589742 ∧ code e1211203589742 = 5609250100846 := by decide
theorem cert_e1211203589742 : check e1211203589742 [[],[]] .chain = true := by decide
def e1211203589754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203589754 : Closed e1211203589754 ∧ code e1211203589754 = 5609250100858 := by decide
theorem cert_e1211203589754 : check e1211203589754 [[],[]] .chain = true := by decide
def e1211203589942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203589942 : Closed e1211203589942 ∧ code e1211203589942 = 5609250101046 := by decide
theorem cert_e1211203589942 : check e1211203589942 [[],[]] .chain = true := by decide
def e1211203589946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203589946 : Closed e1211203589946 ∧ code e1211203589946 = 5609250101050 := by decide
theorem cert_e1211203589946 : check e1211203589946 [[],[]] .chain = true := by decide
def e1211203590574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203590574 : Closed e1211203590574 ∧ code e1211203590574 = 5609250101678 := by decide
theorem cert_e1211203590574 : check e1211203590574 [[],[]] .chain = true := by decide
def e1211203590586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203590586 : Closed e1211203590586 ∧ code e1211203590586 = 5609250101690 := by decide
theorem cert_e1211203590586 : check e1211203590586 [[],[]] .chain = true := by decide
def e1211203590634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203590634 : Closed e1211203590634 ∧ code e1211203590634 = 5609250101738 := by decide
theorem cert_e1211203590634 : check e1211203590634 [[],[]] .chain = true := by decide
def e1211203590766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203590766 : Closed e1211203590766 ∧ code e1211203590766 = 5609250101870 := by decide
theorem cert_e1211203590766 : check e1211203590766 [[],[]] .chain = true := by decide
def e1211203590778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203590778 : Closed e1211203590778 ∧ code e1211203590778 = 5609250101882 := by decide
theorem cert_e1211203590778 : check e1211203590778 [[],[]] .chain = true := by decide
def e1211203591066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203591066 : Closed e1211203591066 ∧ code e1211203591066 = 5609250102170 := by decide
theorem cert_e1211203591066 : check e1211203591066 [[],[]] .chain = true := by decide
def e1211203591278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203591278 : Closed e1211203591278 ∧ code e1211203591278 = 5609250102382 := by decide
theorem cert_e1211203591278 : check e1211203591278 [[],[]] .chain = true := by decide
def e1211203591290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203591290 : Closed e1211203591290 ∧ code e1211203591290 = 5609250102394 := by decide
theorem cert_e1211203591290 : check e1211203591290 [[],[]] .chain = true := by decide
def e1211203591454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203591454 : Closed e1211203591454 ∧ code e1211203591454 = 5609250102558 := by decide
theorem cert_e1211203591454 : check e1211203591454 [[],[]] .chain = true := by decide
def e1211203591622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203591622 : Closed e1211203591622 ∧ code e1211203591622 = 5609250102726 := by decide
theorem cert_e1211203591622 : check e1211203591622 [[],[]] .chain = true := by decide
def e1211203591962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203591962 : Closed e1211203591962 ∧ code e1211203591962 = 5609250103066 := by decide
theorem cert_e1211203591962 : check e1211203591962 [[],[]] .chain = true := by decide
def e1211203592006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203592006 : Closed e1211203592006 ∧ code e1211203592006 = 5609250103110 := by decide
theorem cert_e1211203592006 : check e1211203592006 [[],[]] .chain = true := by decide
end Blc.Floor42
