import Tables
import Batch078
namespace Blc.Floor42.Grades078
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196686796698 : ¬ IsSelfInterpreter e1196686796698 := cutM4_1 (by decide)
#print axioms ex_e1196686796698
end Blc.Floor42.Grades078
