import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299372891094 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e299372891094 : Closed e299372891094 ∧ code e299372891094 = 4697419402198 := by decide
theorem cert_e299372891094 : check e299372891094 [[.under],[.under,.left]] .chain = true := by decide
def e299372891098 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e299372891098 : Closed e299372891098 ∧ code e299372891098 = 4697419402202 := by decide
theorem cert_e299372891098 : check e299372891098 [[.under],[.under,.left]] .chain = true := by decide
def e299372891374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e299372891374 : Closed e299372891374 ∧ code e299372891374 = 4697419402478 := by decide
theorem cert_e299372891374 : check e299372891374 [[.under],[.under,.left]] .chain = true := by decide
def e299372891382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e299372891382 : Closed e299372891382 ∧ code e299372891382 = 4697419402486 := by decide
theorem cert_e299372891382 : check e299372891382 [[.under],[.under,.left]] .chain = true := by decide
def e299372891758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e299372891758 : Closed e299372891758 ∧ code e299372891758 = 4697419402862 := by decide
theorem cert_e299372891758 : check e299372891758 [[.under],[.under,.left]] .chain = true := by decide
def e299372891770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e299372891770 : Closed e299372891770 ∧ code e299372891770 = 4697419402874 := by decide
theorem cert_e299372891770 : check e299372891770 [[.under],[.under,.left]] .chain = true := by decide
def e299372891958 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e299372891958 : Closed e299372891958 ∧ code e299372891958 = 4697419403062 := by decide
theorem cert_e299372891958 : check e299372891958 [[.under],[.under,.left]] .chain = true := by decide
def e299372891962 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e299372891962 : Closed e299372891962 ∧ code e299372891962 = 4697419403066 := by decide
theorem cert_e299372891962 : check e299372891962 [[.under],[.under,.left]] .chain = true := by decide
def e299373431662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299373431662 : Closed e299373431662 ∧ code e299373431662 = 4697419942766 := by decide
theorem cert_e299373431662 : check e299373431662 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373431670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299373431670 : Closed e299373431670 ∧ code e299373431670 = 4697419942774 := by decide
theorem cert_e299373431670 : check e299373431670 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373431726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299373431726 : Closed e299373431726 ∧ code e299373431726 = 4697419942830 := by decide
theorem cert_e299373431726 : check e299373431726 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373431738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299373431738 : Closed e299373431738 ∧ code e299373431738 = 4697419942842 := by decide
theorem cert_e299373431738 : check e299373431738 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373431766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299373431766 : Closed e299373431766 ∧ code e299373431766 = 4697419942870 := by decide
theorem cert_e299373431766 : check e299373431766 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373431770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299373431770 : Closed e299373431770 ∧ code e299373431770 = 4697419942874 := by decide
theorem cert_e299373431770 : check e299373431770 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299373432046 : Closed e299373432046 ∧ code e299373432046 = 4697419943150 := by decide
theorem cert_e299373432046 : check e299373432046 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299373432054 : Closed e299373432054 ∧ code e299373432054 = 4697419943158 := by decide
theorem cert_e299373432054 : check e299373432054 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432430 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299373432430 : Closed e299373432430 ∧ code e299373432430 = 4697419943534 := by decide
theorem cert_e299373432430 : check e299373432430 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432442 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299373432442 : Closed e299373432442 ∧ code e299373432442 = 4697419943546 := by decide
theorem cert_e299373432442 : check e299373432442 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299373432630 : Closed e299373432630 ∧ code e299373432630 = 4697419943734 := by decide
theorem cert_e299373432630 : check e299373432630 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299373432634 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299373432634 : Closed e299373432634 ∧ code e299373432634 = 4697419943738 := by decide
theorem cert_e299373432634 : check e299373432634 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299909557614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e299909557614 : Closed e299909557614 ∧ code e299909557614 = 4697956068718 := by decide
theorem cert_e299909557614 : check e299909557614 [[.under]] .sourceHead = true := by decide
def e299909557622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e299909557622 : Closed e299909557622 ∧ code e299909557622 = 4697956068726 := by decide
theorem cert_e299909557622 : check e299909557622 [[.under]] .sourceHead = true := by decide
def e299909557678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e299909557678 : Closed e299909557678 ∧ code e299909557678 = 4697956068782 := by decide
theorem cert_e299909557678 : check e299909557678 [[.under]] .sourceHead = true := by decide
def e299909557690 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e299909557690 : Closed e299909557690 ∧ code e299909557690 = 4697956068794 := by decide
theorem cert_e299909557690 : check e299909557690 [[.under]] .sourceHead = true := by decide
def e299909557718 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e299909557718 : Closed e299909557718 ∧ code e299909557718 = 4697956068822 := by decide
theorem cert_e299909557718 : check e299909557718 [[.under]] .sourceHead = true := by decide
def e299909557722 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e299909557722 : Closed e299909557722 ∧ code e299909557722 = 4697956068826 := by decide
theorem cert_e299909557722 : check e299909557722 [[.under]] .sourceHead = true := by decide
def e299909557934 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e299909557934 : Closed e299909557934 ∧ code e299909557934 = 4697956069038 := by decide
theorem cert_e299909557934 : check e299909557934 [[.under]] .sourceHead = true := by decide
def e299909557946 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e299909557946 : Closed e299909557946 ∧ code e299909557946 = 4697956069050 := by decide
theorem cert_e299909557946 : check e299909557946 [[.under]] .sourceHead = true := by decide
def e299909557994 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e299909557994 : Closed e299909557994 ∧ code e299909557994 = 4697956069098 := by decide
theorem cert_e299909557994 : check e299909557994 [[.under]] .sourceHead = true := by decide
def e299909558102 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e299909558102 : Closed e299909558102 ∧ code e299909558102 = 4697956069206 := by decide
theorem cert_e299909558102 : check e299909558102 [[.under]] .sourceHead = true := by decide
def e299909558106 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e299909558106 : Closed e299909558106 ∧ code e299909558106 = 4697956069210 := by decide
theorem cert_e299909558106 : check e299909558106 [[.under]] .sourceHead = true := by decide
def e299909558122 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e299909558122 : Closed e299909558122 ∧ code e299909558122 = 4697956069226 := by decide
theorem cert_e299909558122 : check e299909558122 [[.under]] .sourceHead = true := by decide
def e299909559150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e299909559150 : Closed e299909559150 ∧ code e299909559150 = 4697956070254 := by decide
theorem cert_e299909559150 : check e299909559150 [[.under]] .sourceHead = true := by decide
def e299909559158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e299909559158 : Closed e299909559158 ∧ code e299909559158 = 4697956070262 := by decide
theorem cert_e299909559158 : check e299909559158 [[.under]] .sourceHead = true := by decide
def e299909559214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e299909559214 : Closed e299909559214 ∧ code e299909559214 = 4697956070318 := by decide
theorem cert_e299909559214 : check e299909559214 [[.under]] .sourceHead = true := by decide
def e299909559226 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e299909559226 : Closed e299909559226 ∧ code e299909559226 = 4697956070330 := by decide
theorem cert_e299909559226 : check e299909559226 [[.under]] .sourceHead = true := by decide
def e299909559254 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e299909559254 : Closed e299909559254 ∧ code e299909559254 = 4697956070358 := by decide
theorem cert_e299909559254 : check e299909559254 [[.under]] .sourceHead = true := by decide
def e299909559258 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e299909559258 : Closed e299909559258 ∧ code e299909559258 = 4697956070362 := by decide
theorem cert_e299909559258 : check e299909559258 [[.under]] .sourceHead = true := by decide
def e299909559534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e299909559534 : Closed e299909559534 ∧ code e299909559534 = 4697956070638 := by decide
theorem cert_e299909559534 : check e299909559534 [[.under]] .sourceHead = true := by decide
def e299909559542 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e299909559542 : Closed e299909559542 ∧ code e299909559542 = 4697956070646 := by decide
theorem cert_e299909559542 : check e299909559542 [[.under]] .sourceHead = true := by decide
def e299909559918 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299909559918 : Closed e299909559918 ∧ code e299909559918 = 4697956071022 := by decide
theorem cert_e299909559918 : check e299909559918 [[.under]] .sourceHead = true := by decide
def e299909559930 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299909559930 : Closed e299909559930 ∧ code e299909559930 = 4697956071034 := by decide
theorem cert_e299909559930 : check e299909559930 [[.under]] .sourceHead = true := by decide
def e299909560118 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299909560118 : Closed e299909560118 ∧ code e299909560118 = 4697956071222 := by decide
theorem cert_e299909560118 : check e299909560118 [[.under]] .sourceHead = true := by decide
def e299909560122 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299909560122 : Closed e299909560122 ∧ code e299909560122 = 4697956071226 := by decide
theorem cert_e299909560122 : check e299909560122 [[.under]] .sourceHead = true := by decide
def e299909560750 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e299909560750 : Closed e299909560750 ∧ code e299909560750 = 4697956071854 := by decide
theorem cert_e299909560750 : check e299909560750 [[.under]] .sourceHead = true := by decide
def e299909560762 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e299909560762 : Closed e299909560762 ∧ code e299909560762 = 4697956071866 := by decide
theorem cert_e299909560762 : check e299909560762 [[.under]] .sourceHead = true := by decide
def e299909560810 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e299909560810 : Closed e299909560810 ∧ code e299909560810 = 4697956071914 := by decide
theorem cert_e299909560810 : check e299909560810 [[.under]] .sourceHead = true := by decide
def e299909560942 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299909560942 : Closed e299909560942 ∧ code e299909560942 = 4697956072046 := by decide
theorem cert_e299909560942 : check e299909560942 [[.under]] .sourceHead = true := by decide
def e299909560954 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299909560954 : Closed e299909560954 ∧ code e299909560954 = 4697956072058 := by decide
theorem cert_e299909560954 : check e299909560954 [[.under]] .sourceHead = true := by decide
def e299909561242 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299909561242 : Closed e299909561242 ∧ code e299909561242 = 4697956072346 := by decide
theorem cert_e299909561242 : check e299909561242 [[.under]] .sourceHead = true := by decide
def e299909561558 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e299909561558 : Closed e299909561558 ∧ code e299909561558 = 4697956072662 := by decide
theorem cert_e299909561558 : check e299909561558 [[.under]] .sourceHead = true := by decide
def e299909561562 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e299909561562 : Closed e299909561562 ∧ code e299909561562 = 4697956072666 := by decide
theorem cert_e299909561562 : check e299909561562 [[.under]] .sourceHead = true := by decide
def e299909561578 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e299909561578 : Closed e299909561578 ∧ code e299909561578 = 4697956072682 := by decide
theorem cert_e299909561578 : check e299909561578 [[.under]] .sourceHead = true := by decide
def e299909561654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299909561654 : Closed e299909561654 ∧ code e299909561654 = 4697956072758 := by decide
theorem cert_e299909561654 : check e299909561654 [[.under]] .sourceHead = true := by decide
def e299909561658 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299909561658 : Closed e299909561658 ∧ code e299909561658 = 4697956072762 := by decide
theorem cert_e299909561658 : check e299909561658 [[.under]] .sourceHead = true := by decide
def e299909561754 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299909561754 : Closed e299909561754 ∧ code e299909561754 = 4697956072858 := by decide
theorem cert_e299909561754 : check e299909561754 [[.under]] .sourceHead = true := by decide
def e299909565294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299909565294 : Closed e299909565294 ∧ code e299909565294 = 4697956076398 := by decide
theorem cert_e299909565294 : check e299909565294 [[.under]] .sourceHead = true := by decide
def e299909565302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299909565302 : Closed e299909565302 ∧ code e299909565302 = 4697956076406 := by decide
theorem cert_e299909565302 : check e299909565302 [[.under]] .sourceHead = true := by decide
def e299909565358 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299909565358 : Closed e299909565358 ∧ code e299909565358 = 4697956076462 := by decide
theorem cert_e299909565358 : check e299909565358 [[.under]] .sourceHead = true := by decide
def e299909565370 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299909565370 : Closed e299909565370 ∧ code e299909565370 = 4697956076474 := by decide
theorem cert_e299909565370 : check e299909565370 [[.under]] .sourceHead = true := by decide
def e299909565398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299909565398 : Closed e299909565398 ∧ code e299909565398 = 4697956076502 := by decide
theorem cert_e299909565398 : check e299909565398 [[.under]] .sourceHead = true := by decide
def e299909565402 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299909565402 : Closed e299909565402 ∧ code e299909565402 = 4697956076506 := by decide
theorem cert_e299909565402 : check e299909565402 [[.under]] .sourceHead = true := by decide
def e299909565678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299909565678 : Closed e299909565678 ∧ code e299909565678 = 4697956076782 := by decide
theorem cert_e299909565678 : check e299909565678 [[.under]] .sourceHead = true := by decide
def e299909565686 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299909565686 : Closed e299909565686 ∧ code e299909565686 = 4697956076790 := by decide
theorem cert_e299909565686 : check e299909565686 [[.under]] .sourceHead = true := by decide
def e299909566062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299909566062 : Closed e299909566062 ∧ code e299909566062 = 4697956077166 := by decide
theorem cert_e299909566062 : check e299909566062 [[.under]] .sourceHead = true := by decide
def e299909566074 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299909566074 : Closed e299909566074 ∧ code e299909566074 = 4697956077178 := by decide
theorem cert_e299909566074 : check e299909566074 [[.under]] .sourceHead = true := by decide
def e299909566262 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299909566262 : Closed e299909566262 ∧ code e299909566262 = 4697956077366 := by decide
theorem cert_e299909566262 : check e299909566262 [[.under]] .sourceHead = true := by decide
def e299909566266 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299909566266 : Closed e299909566266 ∧ code e299909566266 = 4697956077370 := by decide
theorem cert_e299909566266 : check e299909566266 [[.under]] .sourceHead = true := by decide
def e299909572014 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e299909572014 : Closed e299909572014 ∧ code e299909572014 = 4697956083118 := by decide
theorem cert_e299909572014 : check e299909572014 [[.under]] .sourceHead = true := by decide
def e299909572026 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e299909572026 : Closed e299909572026 ∧ code e299909572026 = 4697956083130 := by decide
theorem cert_e299909572026 : check e299909572026 [[.under]] .sourceHead = true := by decide
def e299909572074 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e299909572074 : Closed e299909572074 ∧ code e299909572074 = 4697956083178 := by decide
theorem cert_e299909572074 : check e299909572074 [[.under]] .sourceHead = true := by decide
def e299909572206 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e299909572206 : Closed e299909572206 ∧ code e299909572206 = 4697956083310 := by decide
theorem cert_e299909572206 : check e299909572206 [[.under]] .sourceHead = true := by decide
def e299909572218 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e299909572218 : Closed e299909572218 ∧ code e299909572218 = 4697956083322 := by decide
theorem cert_e299909572218 : check e299909572218 [[.under]] .sourceHead = true := by decide
def e299909572506 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e299909572506 : Closed e299909572506 ∧ code e299909572506 = 4697956083610 := by decide
theorem cert_e299909572506 : check e299909572506 [[.under]] .sourceHead = true := by decide
def e299909575382 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e299909575382 : Closed e299909575382 ∧ code e299909575382 = 4697956086486 := by decide
theorem cert_e299909575382 : check e299909575382 [[.under]] .sourceHead = true := by decide
def e299909575386 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e299909575386 : Closed e299909575386 ∧ code e299909575386 = 4697956086490 := by decide
theorem cert_e299909575386 : check e299909575386 [[.under]] .sourceHead = true := by decide
def e299909575402 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e299909575402 : Closed e299909575402 ∧ code e299909575402 = 4697956086506 := by decide
theorem cert_e299909575402 : check e299909575402 [[.under]] .sourceHead = true := by decide
def e299909575478 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e299909575478 : Closed e299909575478 ∧ code e299909575478 = 4697956086582 := by decide
theorem cert_e299909575478 : check e299909575478 [[.under]] .sourceHead = true := by decide
def e299909575482 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e299909575482 : Closed e299909575482 ∧ code e299909575482 = 4697956086586 := by decide
theorem cert_e299909575482 : check e299909575482 [[.under]] .sourceHead = true := by decide
def e299909575578 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e299909575578 : Closed e299909575578 ∧ code e299909575578 = 4697956086682 := by decide
theorem cert_e299909575578 : check e299909575578 [[.under]] .sourceHead = true := by decide
def e299909691118 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e299909691118 : Closed e299909691118 ∧ code e299909691118 = 4697956202222 := by decide
theorem cert_e299909691118 : check e299909691118 [[.under]] .sourceHead = true := by decide
def e299909691246 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e299909691246 : Closed e299909691246 ∧ code e299909691246 = 4697956202350 := by decide
theorem cert_e299909691246 : check e299909691246 [[.under]] .sourceHead = true := by decide
def e299909691254 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e299909691254 : Closed e299909691254 ∧ code e299909691254 = 4697956202358 := by decide
theorem cert_e299909691254 : check e299909691254 [[.under]] .sourceHead = true := by decide
def e299909692142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e299909692142 : Closed e299909692142 ∧ code e299909692142 = 4697956203246 := by decide
theorem cert_e299909692142 : check e299909692142 [[.under]] .sourceHead = true := by decide
def e299909692334 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e299909692334 : Closed e299909692334 ∧ code e299909692334 = 4697956203438 := by decide
theorem cert_e299909692334 : check e299909692334 [[.under]] .sourceHead = true := by decide
def e299909692346 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e299909692346 : Closed e299909692346 ∧ code e299909692346 = 4697956203450 := by decide
theorem cert_e299909692346 : check e299909692346 [[.under]] .sourceHead = true := by decide
def e299909692782 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e299909692782 : Closed e299909692782 ∧ code e299909692782 = 4697956203886 := by decide
theorem cert_e299909692782 : check e299909692782 [[.under]] .sourceHead = true := by decide
def e299909692790 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e299909692790 : Closed e299909692790 ∧ code e299909692790 = 4697956203894 := by decide
theorem cert_e299909692790 : check e299909692790 [[.under]] .sourceHead = true := by decide
def e299909692846 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e299909692846 : Closed e299909692846 ∧ code e299909692846 = 4697956203950 := by decide
theorem cert_e299909692846 : check e299909692846 [[.under]] .sourceHead = true := by decide
def e299909692858 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e299909692858 : Closed e299909692858 ∧ code e299909692858 = 4697956203962 := by decide
theorem cert_e299909692858 : check e299909692858 [[.under]] .sourceHead = true := by decide
def e299909692886 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e299909692886 : Closed e299909692886 ∧ code e299909692886 = 4697956203990 := by decide
theorem cert_e299909692886 : check e299909692886 [[.under]] .sourceHead = true := by decide
def e299909692890 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e299909692890 : Closed e299909692890 ∧ code e299909692890 = 4697956203994 := by decide
theorem cert_e299909692890 : check e299909692890 [[.under]] .sourceHead = true := by decide
def e299909697262 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e299909697262 : Closed e299909697262 ∧ code e299909697262 = 4697956208366 := by decide
theorem cert_e299909697262 : check e299909697262 [[.under]] .sourceHead = true := by decide
def e299909697390 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e299909697390 : Closed e299909697390 ∧ code e299909697390 = 4697956208494 := by decide
theorem cert_e299909697390 : check e299909697390 [[.under]] .sourceHead = true := by decide
def e299909697398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e299909697398 : Closed e299909697398 ∧ code e299909697398 = 4697956208502 := by decide
theorem cert_e299909697398 : check e299909697398 [[.under]] .sourceHead = true := by decide
def e299909700078 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e299909700078 : Closed e299909700078 ∧ code e299909700078 = 4697956211182 := by decide
theorem cert_e299909700078 : check e299909700078 [[.under]] .sourceHead = true := by decide
def e299909700846 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e299909700846 : Closed e299909700846 ∧ code e299909700846 = 4697956211950 := by decide
theorem cert_e299909700846 : check e299909700846 [[.under]] .sourceHead = true := by decide
def e299909700854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e299909700854 : Closed e299909700854 ∧ code e299909700854 = 4697956211958 := by decide
theorem cert_e299909700854 : check e299909700854 [[.under]] .sourceHead = true := by decide
def e299909703406 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e299909703406 : Closed e299909703406 ∧ code e299909703406 = 4697956214510 := by decide
theorem cert_e299909703406 : check e299909703406 [[.under]] .sourceHead = true := by decide
def e299909703598 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e299909703598 : Closed e299909703598 ∧ code e299909703598 = 4697956214702 := by decide
theorem cert_e299909703598 : check e299909703598 [[.under]] .sourceHead = true := by decide
def e299909703610 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e299909703610 : Closed e299909703610 ∧ code e299909703610 = 4697956214714 := by decide
theorem cert_e299909703610 : check e299909703610 [[.under]] .sourceHead = true := by decide
def e299909704174 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e299909704174 : Closed e299909704174 ∧ code e299909704174 = 4697956215278 := by decide
theorem cert_e299909704174 : check e299909704174 [[.under]] .sourceHead = true := by decide
def e299909705326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e299909705326 : Closed e299909705326 ∧ code e299909705326 = 4697956216430 := by decide
theorem cert_e299909705326 : check e299909705326 [[.under]] .sourceHead = true := by decide
def e299909705338 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e299909705338 : Closed e299909705338 ∧ code e299909705338 = 4697956216442 := by decide
theorem cert_e299909705338 : check e299909705338 [[.under]] .sourceHead = true := by decide
def e299909706606 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e299909706606 : Closed e299909706606 ∧ code e299909706606 = 4697956217710 := by decide
theorem cert_e299909706606 : check e299909706606 [[.under]] .sourceHead = true := by decide
def e299909706614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e299909706614 : Closed e299909706614 ∧ code e299909706614 = 4697956217718 := by decide
theorem cert_e299909706614 : check e299909706614 [[.under]] .sourceHead = true := by decide
def e299909706670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e299909706670 : Closed e299909706670 ∧ code e299909706670 = 4697956217774 := by decide
theorem cert_e299909706670 : check e299909706670 [[.under]] .sourceHead = true := by decide
def e299909706682 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e299909706682 : Closed e299909706682 ∧ code e299909706682 = 4697956217786 := by decide
theorem cert_e299909706682 : check e299909706682 [[.under]] .sourceHead = true := by decide
def e299909706710 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e299909706710 : Closed e299909706710 ∧ code e299909706710 = 4697956217814 := by decide
theorem cert_e299909706710 : check e299909706710 [[.under]] .sourceHead = true := by decide
def e299909706714 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e299909706714 : Closed e299909706714 ∧ code e299909706714 = 4697956217818 := by decide
theorem cert_e299909706714 : check e299909706714 [[.under]] .sourceHead = true := by decide
def e299909706990 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e299909706990 : Closed e299909706990 ∧ code e299909706990 = 4697956218094 := by decide
theorem cert_e299909706990 : check e299909706990 [[.under]] .sourceHead = true := by decide
def e299909706998 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e299909706998 : Closed e299909706998 ∧ code e299909706998 = 4697956218102 := by decide
theorem cert_e299909706998 : check e299909706998 [[.under]] .sourceHead = true := by decide
def e299909707374 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e299909707374 : Closed e299909707374 ∧ code e299909707374 = 4697956218478 := by decide
theorem cert_e299909707374 : check e299909707374 [[.under]] .sourceHead = true := by decide
def e299909707386 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e299909707386 : Closed e299909707386 ∧ code e299909707386 = 4697956218490 := by decide
theorem cert_e299909707386 : check e299909707386 [[.under]] .sourceHead = true := by decide
def e299909707574 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e299909707574 : Closed e299909707574 ∧ code e299909707574 = 4697956218678 := by decide
theorem cert_e299909707574 : check e299909707574 [[.under]] .sourceHead = true := by decide
def e299909707578 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e299909707578 : Closed e299909707578 ∧ code e299909707578 = 4697956218682 := by decide
theorem cert_e299909707578 : check e299909707578 [[.under]] .sourceHead = true := by decide
def e299909712750 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299909712750 : Closed e299909712750 ∧ code e299909712750 = 4697956223854 := by decide
theorem cert_e299909712750 : check e299909712750 [[.under]] .sourceHead = true := by decide
def e299909712758 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299909712758 : Closed e299909712758 ∧ code e299909712758 = 4697956223862 := by decide
theorem cert_e299909712758 : check e299909712758 [[.under]] .sourceHead = true := by decide
def e299909712814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299909712814 : Closed e299909712814 ∧ code e299909712814 = 4697956223918 := by decide
theorem cert_e299909712814 : check e299909712814 [[.under]] .sourceHead = true := by decide
def e299909712826 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299909712826 : Closed e299909712826 ∧ code e299909712826 = 4697956223930 := by decide
theorem cert_e299909712826 : check e299909712826 [[.under]] .sourceHead = true := by decide
def e299909712854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299909712854 : Closed e299909712854 ∧ code e299909712854 = 4697956223958 := by decide
theorem cert_e299909712854 : check e299909712854 [[.under]] .sourceHead = true := by decide
def e299909712858 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299909712858 : Closed e299909712858 ∧ code e299909712858 = 4697956223962 := by decide
theorem cert_e299909712858 : check e299909712858 [[.under]] .sourceHead = true := by decide
def e299909713134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299909713134 : Closed e299909713134 ∧ code e299909713134 = 4697956224238 := by decide
theorem cert_e299909713134 : check e299909713134 [[.under]] .sourceHead = true := by decide
def e299909713142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299909713142 : Closed e299909713142 ∧ code e299909713142 = 4697956224246 := by decide
theorem cert_e299909713142 : check e299909713142 [[.under]] .sourceHead = true := by decide
def e299909713518 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299909713518 : Closed e299909713518 ∧ code e299909713518 = 4697956224622 := by decide
theorem cert_e299909713518 : check e299909713518 [[.under]] .sourceHead = true := by decide
def e299909713530 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299909713530 : Closed e299909713530 ∧ code e299909713530 = 4697956224634 := by decide
theorem cert_e299909713530 : check e299909713530 [[.under]] .sourceHead = true := by decide
def e299909713718 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299909713718 : Closed e299909713718 ∧ code e299909713718 = 4697956224822 := by decide
theorem cert_e299909713718 : check e299909713718 [[.under]] .sourceHead = true := by decide
def e299909713722 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299909713722 : Closed e299909713722 ∧ code e299909713722 = 4697956224826 := by decide
theorem cert_e299909713722 : check e299909713722 [[.under]] .sourceHead = true := by decide
def e299909721838 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e299909721838 : Closed e299909721838 ∧ code e299909721838 = 4697956232942 := by decide
theorem cert_e299909721838 : check e299909721838 [[.under]] .sourceHead = true := by decide
def e299909721966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e299909721966 : Closed e299909721966 ∧ code e299909721966 = 4697956233070 := by decide
theorem cert_e299909721966 : check e299909721966 [[.under]] .sourceHead = true := by decide
def e299909721974 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e299909721974 : Closed e299909721974 ∧ code e299909721974 = 4697956233078 := by decide
theorem cert_e299909721974 : check e299909721974 [[.under]] .sourceHead = true := by decide
def e299909724654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e299909724654 : Closed e299909724654 ∧ code e299909724654 = 4697956235758 := by decide
theorem cert_e299909724654 : check e299909724654 [[.under]] .sourceHead = true := by decide
def e299909725422 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e299909725422 : Closed e299909725422 ∧ code e299909725422 = 4697956236526 := by decide
theorem cert_e299909725422 : check e299909725422 [[.under]] .sourceHead = true := by decide
def e299909725430 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e299909725430 : Closed e299909725430 ∧ code e299909725430 = 4697956236534 := by decide
theorem cert_e299909725430 : check e299909725430 [[.under]] .sourceHead = true := by decide
def e299909748462 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e299909748462 : Closed e299909748462 ∧ code e299909748462 = 4697956259566 := by decide
theorem cert_e299909748462 : check e299909748462 [[.under]] .sourceHead = true := by decide
def e299909748654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e299909748654 : Closed e299909748654 ∧ code e299909748654 = 4697956259758 := by decide
theorem cert_e299909748654 : check e299909748654 [[.under]] .sourceHead = true := by decide
def e299909748666 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e299909748666 : Closed e299909748666 ∧ code e299909748666 = 4697956259770 := by decide
theorem cert_e299909748666 : check e299909748666 [[.under]] .sourceHead = true := by decide
def e299909749230 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e299909749230 : Closed e299909749230 ∧ code e299909749230 = 4697956260334 := by decide
theorem cert_e299909749230 : check e299909749230 [[.under]] .sourceHead = true := by decide
def e299909750382 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e299909750382 : Closed e299909750382 ∧ code e299909750382 = 4697956261486 := by decide
theorem cert_e299909750382 : check e299909750382 [[.under]] .sourceHead = true := by decide
def e299909750394 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e299909750394 : Closed e299909750394 ∧ code e299909750394 = 4697956261498 := by decide
theorem cert_e299909750394 : check e299909750394 [[.under]] .sourceHead = true := by decide
def e299909761902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e299909761902 : Closed e299909761902 ∧ code e299909761902 = 4697956273006 := by decide
theorem cert_e299909761902 : check e299909761902 [[.under]] .sourceHead = true := by decide
def e299909761910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e299909761910 : Closed e299909761910 ∧ code e299909761910 = 4697956273014 := by decide
theorem cert_e299909761910 : check e299909761910 [[.under]] .sourceHead = true := by decide
def e299909761966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e299909761966 : Closed e299909761966 ∧ code e299909761966 = 4697956273070 := by decide
theorem cert_e299909761966 : check e299909761966 [[.under]] .sourceHead = true := by decide
def e299909761978 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e299909761978 : Closed e299909761978 ∧ code e299909761978 = 4697956273082 := by decide
theorem cert_e299909761978 : check e299909761978 [[.under]] .sourceHead = true := by decide
def e299909762006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e299909762006 : Closed e299909762006 ∧ code e299909762006 = 4697956273110 := by decide
theorem cert_e299909762006 : check e299909762006 [[.under]] .sourceHead = true := by decide
def e299909762010 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e299909762010 : Closed e299909762010 ∧ code e299909762010 = 4697956273114 := by decide
theorem cert_e299909762010 : check e299909762010 [[.under]] .sourceHead = true := by decide
def e299909762286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e299909762286 : Closed e299909762286 ∧ code e299909762286 = 4697956273390 := by decide
theorem cert_e299909762286 : check e299909762286 [[.under]] .sourceHead = true := by decide
def e299909762294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e299909762294 : Closed e299909762294 ∧ code e299909762294 = 4697956273398 := by decide
theorem cert_e299909762294 : check e299909762294 [[.under]] .sourceHead = true := by decide
def e299909762670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e299909762670 : Closed e299909762670 ∧ code e299909762670 = 4697956273774 := by decide
theorem cert_e299909762670 : check e299909762670 [[.under]] .sourceHead = true := by decide
def e299909762682 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e299909762682 : Closed e299909762682 ∧ code e299909762682 = 4697956273786 := by decide
theorem cert_e299909762682 : check e299909762682 [[.under]] .sourceHead = true := by decide
def e299909762870 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e299909762870 : Closed e299909762870 ∧ code e299909762870 = 4697956273974 := by decide
theorem cert_e299909762870 : check e299909762870 [[.under]] .sourceHead = true := by decide
def e299909762874 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e299909762874 : Closed e299909762874 ∧ code e299909762874 = 4697956273978 := by decide
theorem cert_e299909762874 : check e299909762874 [[.under]] .sourceHead = true := by decide
def e299910302574 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299910302574 : Closed e299910302574 ∧ code e299910302574 = 4697956813678 := by decide
theorem cert_e299910302574 : check e299910302574 [[.under]] .sourceHead = true := by decide
def e299910302582 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299910302582 : Closed e299910302582 ∧ code e299910302582 = 4697956813686 := by decide
theorem cert_e299910302582 : check e299910302582 [[.under]] .sourceHead = true := by decide
def e299910302638 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299910302638 : Closed e299910302638 ∧ code e299910302638 = 4697956813742 := by decide
theorem cert_e299910302638 : check e299910302638 [[.under]] .sourceHead = true := by decide
def e299910302650 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299910302650 : Closed e299910302650 ∧ code e299910302650 = 4697956813754 := by decide
theorem cert_e299910302650 : check e299910302650 [[.under]] .sourceHead = true := by decide
def e299910302678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299910302678 : Closed e299910302678 ∧ code e299910302678 = 4697956813782 := by decide
theorem cert_e299910302678 : check e299910302678 [[.under]] .sourceHead = true := by decide
def e299910302682 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299910302682 : Closed e299910302682 ∧ code e299910302682 = 4697956813786 := by decide
theorem cert_e299910302682 : check e299910302682 [[.under]] .sourceHead = true := by decide
def e299910302958 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299910302958 : Closed e299910302958 ∧ code e299910302958 = 4697956814062 := by decide
theorem cert_e299910302958 : check e299910302958 [[.under]] .sourceHead = true := by decide
def e299910302966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299910302966 : Closed e299910302966 ∧ code e299910302966 = 4697956814070 := by decide
theorem cert_e299910302966 : check e299910302966 [[.under]] .sourceHead = true := by decide
end Blc.Floor42
