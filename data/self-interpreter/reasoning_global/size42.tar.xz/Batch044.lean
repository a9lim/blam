import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1124325895706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325895706 : Closed e1124325895706 ∧ code e1124325895706 = 5522372406810 := by decide
theorem cert_e1124325895706 : check e1124325895706 [[]] .width = true := by decide
def e1124325898778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325898778 : Closed e1124325898778 ∧ code e1124325898778 = 5522372409882 := by decide
theorem cert_e1124325898778 : check e1124325898778 [[]] .width = true := by decide
def e1124325905946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325905946 : Closed e1124325905946 ∧ code e1124325905946 = 5522372417050 := by decide
theorem cert_e1124325905946 : check e1124325905946 [[]] .width = true := by decide
def e1124325906970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325906970 : Closed e1124325906970 ∧ code e1124325906970 = 5522372418074 := by decide
theorem cert_e1124325906970 : check e1124325906970 [[]] .width = true := by decide
def e1124325977626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325977626 : Closed e1124325977626 ∧ code e1124325977626 = 5522372488730 := by decide
theorem cert_e1124325977626 : check e1124325977626 [[]] .width = true := by decide
def e1124325979674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124325979674 : Closed e1124325979674 ∧ code e1124325979674 = 5522372490778 := by decide
theorem cert_e1124325979674 : check e1124325979674 [[]] .width = true := by decide
def e1124326075930 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124326075930 : Closed e1124326075930 ∧ code e1124326075930 = 5522372587034 := by decide
theorem cert_e1124326075930 : check e1124326075930 [[]] .width = true := by decide
def e1124326079002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124326079002 : Closed e1124326079002 ∧ code e1124326079002 = 5522372590106 := by decide
theorem cert_e1124326079002 : check e1124326079002 [[]] .width = true := by decide
def e1124326127130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124326127130 : Closed e1124326127130 ∧ code e1124326127130 = 5522372638234 := by decide
theorem cert_e1124326127130 : check e1124326127130 [[]] .width = true := by decide
def e1124326128154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124326128154 : Closed e1124326128154 ∧ code e1124326128154 = 5522372639258 := by decide
theorem cert_e1124326128154 : check e1124326128154 [[]] .width = true := by decide
def e1124488110106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488110106 : Closed e1124488110106 ∧ code e1124488110106 = 5522534621210 := by decide
theorem cert_e1124488110106 : check e1124488110106 [[]] .width = true := by decide
def e1124488110198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488110198 : Closed e1124488110198 ∧ code e1124488110198 = 5522534621302 := by decide
theorem cert_e1124488110198 : check e1124488110198 [[]] .width = true := by decide
def e1124488110442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488110442 : Closed e1124488110442 ∧ code e1124488110442 = 5522534621546 := by decide
theorem cert_e1124488110442 : check e1124488110442 [[]] .width = true := by decide
def e1124488110490 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488110490 : Closed e1124488110490 ∧ code e1124488110490 = 5522534621594 := by decide
theorem cert_e1124488110490 : check e1124488110490 [[]] .width = true := by decide
def e1124488142874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488142874 : Closed e1124488142874 ∧ code e1124488142874 = 5522534653978 := by decide
theorem cert_e1124488142874 : check e1124488142874 [[]] .width = true := by decide
def e1124488142966 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488142966 : Closed e1124488142966 ∧ code e1124488142966 = 5522534654070 := by decide
theorem cert_e1124488142966 : check e1124488142966 [[]] .width = true := by decide
def e1124488143210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488143210 : Closed e1124488143210 ∧ code e1124488143210 = 5522534654314 := by decide
theorem cert_e1124488143210 : check e1124488143210 [[]] .width = true := by decide
def e1124488143258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488143258 : Closed e1124488143258 ∧ code e1124488143258 = 5522534654362 := by decide
theorem cert_e1124488143258 : check e1124488143258 [[]] .width = true := by decide
def e1124488372250 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488372250 : Closed e1124488372250 ∧ code e1124488372250 = 5522534883354 := by decide
theorem cert_e1124488372250 : check e1124488372250 [[]] .width = true := by decide
def e1124488372342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488372342 : Closed e1124488372342 ∧ code e1124488372342 = 5522534883446 := by decide
theorem cert_e1124488372342 : check e1124488372342 [[]] .width = true := by decide
def e1124488372586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488372586 : Closed e1124488372586 ∧ code e1124488372586 = 5522534883690 := by decide
theorem cert_e1124488372586 : check e1124488372586 [[]] .width = true := by decide
def e1124488372634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488372634 : Closed e1124488372634 ∧ code e1124488372634 = 5522534883738 := by decide
theorem cert_e1124488372634 : check e1124488372634 [[]] .width = true := by decide
def e1124488421402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488421402 : Closed e1124488421402 ∧ code e1124488421402 = 5522534932506 := by decide
theorem cert_e1124488421402 : check e1124488421402 [[]] .width = true := by decide
def e1124488421494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488421494 : Closed e1124488421494 ∧ code e1124488421494 = 5522534932598 := by decide
theorem cert_e1124488421494 : check e1124488421494 [[]] .width = true := by decide
def e1124488421738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488421738 : Closed e1124488421738 ∧ code e1124488421738 = 5522534932842 := by decide
theorem cert_e1124488421738 : check e1124488421738 [[]] .width = true := by decide
def e1124488421786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488421786 : Closed e1124488421786 ∧ code e1124488421786 = 5522534932890 := by decide
theorem cert_e1124488421786 : check e1124488421786 [[]] .width = true := by decide
def e1124488536090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488536090 : Closed e1124488536090 ∧ code e1124488536090 = 5522535047194 := by decide
theorem cert_e1124488536090 : check e1124488536090 [[]] .width = true := by decide
def e1124488536182 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488536182 : Closed e1124488536182 ∧ code e1124488536182 = 5522535047286 := by decide
theorem cert_e1124488536182 : check e1124488536182 [[]] .width = true := by decide
def e1124488536426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488536426 : Closed e1124488536426 ∧ code e1124488536426 = 5522535047530 := by decide
theorem cert_e1124488536426 : check e1124488536426 [[]] .width = true := by decide
def e1124488536474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488536474 : Closed e1124488536474 ∧ code e1124488536474 = 5522535047578 := by decide
theorem cert_e1124488536474 : check e1124488536474 [[]] .width = true := by decide
def e1124488552474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124488552474 : Closed e1124488552474 ∧ code e1124488552474 = 5522535063578 := by decide
theorem cert_e1124488552474 : check e1124488552474 [[]] .width = true := by decide
def e1124488552566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124488552566 : Closed e1124488552566 ∧ code e1124488552566 = 5522535063670 := by decide
theorem cert_e1124488552566 : check e1124488552566 [[]] .width = true := by decide
def e1124488552810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124488552810 : Closed e1124488552810 ∧ code e1124488552810 = 5522535063914 := by decide
theorem cert_e1124488552810 : check e1124488552810 [[]] .width = true := by decide
def e1124488552858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124488552858 : Closed e1124488552858 ∧ code e1124488552858 = 5522535063962 := by decide
theorem cert_e1124488552858 : check e1124488552858 [[]] .width = true := by decide
def e1124489682970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124489682970 : Closed e1124489682970 ∧ code e1124489682970 = 5522536194074 := by decide
theorem cert_e1124489682970 : check e1124489682970 [[]] .width = true := by decide
def e1124489683062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124489683062 : Closed e1124489683062 ∧ code e1124489683062 = 5522536194166 := by decide
theorem cert_e1124489683062 : check e1124489683062 [[]] .width = true := by decide
def e1124489683306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124489683306 : Closed e1124489683306 ∧ code e1124489683306 = 5522536194410 := by decide
theorem cert_e1124489683306 : check e1124489683306 [[]] .width = true := by decide
def e1124489683354 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124489683354 : Closed e1124489683354 ∧ code e1124489683354 = 5522536194458 := by decide
theorem cert_e1124489683354 : check e1124489683354 [[]] .width = true := by decide
def e1124489715738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124489715738 : Closed e1124489715738 ∧ code e1124489715738 = 5522536226842 := by decide
theorem cert_e1124489715738 : check e1124489715738 [[]] .width = true := by decide
def e1124489715830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124489715830 : Closed e1124489715830 ∧ code e1124489715830 = 5522536226934 := by decide
theorem cert_e1124489715830 : check e1124489715830 [[]] .width = true := by decide
def e1124489716074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124489716074 : Closed e1124489716074 ∧ code e1124489716074 = 5522536227178 := by decide
theorem cert_e1124489716074 : check e1124489716074 [[]] .width = true := by decide
def e1124489716122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124489716122 : Closed e1124489716122 ∧ code e1124489716122 = 5522536227226 := by decide
theorem cert_e1124489716122 : check e1124489716122 [[]] .width = true := by decide
def e1124491255834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124491255834 : Closed e1124491255834 ∧ code e1124491255834 = 5522537766938 := by decide
theorem cert_e1124491255834 : check e1124491255834 [[]] .width = true := by decide
def e1124491255926 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124491255926 : Closed e1124491255926 ∧ code e1124491255926 = 5522537767030 := by decide
theorem cert_e1124491255926 : check e1124491255926 [[]] .width = true := by decide
def e1124491256170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124491256170 : Closed e1124491256170 ∧ code e1124491256170 = 5522537767274 := by decide
theorem cert_e1124491256170 : check e1124491256170 [[]] .width = true := by decide
def e1124491256218 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124491256218 : Closed e1124491256218 ∧ code e1124491256218 = 5522537767322 := by decide
theorem cert_e1124491256218 : check e1124491256218 [[]] .width = true := by decide
def e1124491304986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124491304986 : Closed e1124491304986 ∧ code e1124491304986 = 5522537816090 := by decide
theorem cert_e1124491304986 : check e1124491304986 [[]] .width = true := by decide
def e1124491305078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124491305078 : Closed e1124491305078 ∧ code e1124491305078 = 5522537816182 := by decide
theorem cert_e1124491305078 : check e1124491305078 [[]] .width = true := by decide
def e1124491305322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124491305322 : Closed e1124491305322 ∧ code e1124491305322 = 5522537816426 := by decide
theorem cert_e1124491305322 : check e1124491305322 [[]] .width = true := by decide
def e1124491305370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124491305370 : Closed e1124491305370 ∧ code e1124491305370 = 5522537816474 := by decide
theorem cert_e1124491305370 : check e1124491305370 [[]] .width = true := by decide
def e1124492075034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124492075034 : Closed e1124492075034 ∧ code e1124492075034 = 5522538586138 := by decide
theorem cert_e1124492075034 : check e1124492075034 [[]] .width = true := by decide
def e1124492075126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124492075126 : Closed e1124492075126 ∧ code e1124492075126 = 5522538586230 := by decide
theorem cert_e1124492075126 : check e1124492075126 [[]] .width = true := by decide
def e1124492075370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124492075370 : Closed e1124492075370 ∧ code e1124492075370 = 5522538586474 := by decide
theorem cert_e1124492075370 : check e1124492075370 [[]] .width = true := by decide
def e1124492075418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124492075418 : Closed e1124492075418 ∧ code e1124492075418 = 5522538586522 := by decide
theorem cert_e1124492075418 : check e1124492075418 [[]] .width = true := by decide
def e1124492091418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1124492091418 : Closed e1124492091418 ∧ code e1124492091418 = 5522538602522 := by decide
theorem cert_e1124492091418 : check e1124492091418 [[]] .width = true := by decide
def e1124492091510 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1124492091510 : Closed e1124492091510 ∧ code e1124492091510 = 5522538602614 := by decide
theorem cert_e1124492091510 : check e1124492091510 [[]] .width = true := by decide
def e1124492091754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1124492091754 : Closed e1124492091754 ∧ code e1124492091754 = 5522538602858 := by decide
theorem cert_e1124492091754 : check e1124492091754 [[]] .width = true := by decide
def e1124492091802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1124492091802 : Closed e1124492091802 ∧ code e1124492091802 = 5522538602906 := by decide
theorem cert_e1124492091802 : check e1124492091802 [[]] .width = true := by decide
def e1124576877422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1124576877422 : Closed e1124576877422 ∧ code e1124576877422 = 5522623388526 := by decide
theorem cert_e1124576877422 : check e1124576877422 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124576877430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1124576877430 : Closed e1124576877430 ∧ code e1124576877430 = 5522623388534 := by decide
theorem cert_e1124576877430 : check e1124576877430 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1124576877494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1124576877494 : Closed e1124576877494 ∧ code e1124576877494 = 5522623388598 := by decide
theorem cert_e1124576877494 : check e1124576877494 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1124576877934 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1124576877934 : Closed e1124576877934 ∧ code e1124576877934 = 5522623389038 := by decide
def e1124576877942 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1124576877942 : Closed e1124576877942 ∧ code e1124576877942 = 5522623389046 := by decide
theorem cert_e1124576877942 : check e1124576877942 [[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1124576877998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1124576877998 : Closed e1124576877998 ∧ code e1124576877998 = 5522623389102 := by decide
theorem cert_e1124576877998 : check e1124576877998 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1124576878010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1124576878010 : Closed e1124576878010 ∧ code e1124576878010 = 5522623389114 := by decide
theorem cert_e1124576878010 : check e1124576878010 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1124576878038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1124576878038 : Closed e1124576878038 ∧ code e1124576878038 = 5522623389142 := by decide
theorem cert_e1124576878038 : check e1124576878038 [[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1124576878042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1124576878042 : Closed e1124576878042 ∧ code e1124576878042 = 5522623389146 := by decide
def e1124576878262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1124576878262 : Closed e1124576878262 ∧ code e1124576878262 = 5522623389366 := by decide
theorem cert_e1124576878262 : check e1124576878262 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576878294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1124576878294 : Closed e1124576878294 ∧ code e1124576878294 = 5522623389398 := by decide
theorem cert_e1124576878294 : check e1124576878294 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576878298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1124576878298 : Closed e1124576878298 ∧ code e1124576878298 = 5522623389402 := by decide
theorem cert_e1124576878298 : check e1124576878298 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576880494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1124576880494 : Closed e1124576880494 ∧ code e1124576880494 = 5522623391598 := by decide
theorem cert_e1124576880494 : checkPay e1124576880494 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1124576880502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1124576880502 : Closed e1124576880502 ∧ code e1124576880502 = 5522623391606 := by decide
theorem cert_e1124576880502 : check e1124576880502 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1124576880566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1124576880566 : Closed e1124576880566 ∧ code e1124576880566 = 5522623391670 := by decide
theorem cert_e1124576880566 : check e1124576880566 [[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1124576881902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124576881902 : Closed e1124576881902 ∧ code e1124576881902 = 5522623393006 := by decide
theorem cert_e1124576881902 : check e1124576881902 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124576881910 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124576881910 : Closed e1124576881910 ∧ code e1124576881910 = 5522623393014 := by decide
theorem cert_e1124576881910 : check e1124576881910 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124576882294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124576882294 : Closed e1124576882294 ∧ code e1124576882294 = 5522623393398 := by decide
theorem cert_e1124576882294 : check e1124576882294 [[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1124576883566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1124576883566 : Closed e1124576883566 ∧ code e1124576883566 = 5522623394670 := by decide
theorem cert_e1124576883566 : check e1124576883566 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576883574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1124576883574 : Closed e1124576883574 ∧ code e1124576883574 = 5522623394678 := by decide
theorem cert_e1124576883574 : check e1124576883574 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576883630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1124576883630 : Closed e1124576883630 ∧ code e1124576883630 = 5522623394734 := by decide
theorem cert_e1124576883630 : check e1124576883630 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576883642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1124576883642 : Closed e1124576883642 ∧ code e1124576883642 = 5522623394746 := by decide
theorem cert_e1124576883642 : check e1124576883642 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576883670 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1124576883670 : Closed e1124576883670 ∧ code e1124576883670 = 5522623394774 := by decide
theorem cert_e1124576883670 : check e1124576883670 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576883674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1124576883674 : Closed e1124576883674 ∧ code e1124576883674 = 5522623394778 := by decide
theorem cert_e1124576883674 : check e1124576883674 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576883950 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124576883950 : Closed e1124576883950 ∧ code e1124576883950 = 5522623395054 := by decide
theorem cert_e1124576883950 : check e1124576883950 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576883958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124576883958 : Closed e1124576883958 ∧ code e1124576883958 = 5522623395062 := by decide
theorem cert_e1124576883958 : check e1124576883958 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576884334 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1124576884334 : Closed e1124576884334 ∧ code e1124576884334 = 5522623395438 := by decide
theorem cert_e1124576884334 : check e1124576884334 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576884346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1124576884346 : Closed e1124576884346 ∧ code e1124576884346 = 5522623395450 := by decide
theorem cert_e1124576884346 : check e1124576884346 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124576884534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124576884534 : Closed e1124576884534 ∧ code e1124576884534 = 5522623395638 := by decide
theorem cert_e1124576884534 : check e1124576884534 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576884538 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124576884538 : Closed e1124576884538 ∧ code e1124576884538 = 5522623395642 := by decide
theorem cert_e1124576884538 : check e1124576884538 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124576885174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1124576885174 : Closed e1124576885174 ∧ code e1124576885174 = 5522623396278 := by decide
theorem cert_e1124576885174 : checkPay e1124576885174 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under]] = true := by decide
def e1124576885206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1124576885206 : Closed e1124576885206 ∧ code e1124576885206 = 5522623396310 := by decide
theorem cert_e1124576885206 : checkPay e1124576885206 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left]] = true := by decide
def e1124576885210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1124576885210 : Closed e1124576885210 ∧ code e1124576885210 = 5522623396314 := by decide
theorem cert_e1124576885210 : checkPay e1124576885210 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left],[.under,.under]] = true := by decide
def e1124576885366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124576885366 : Closed e1124576885366 ∧ code e1124576885366 = 5522623396470 := by decide
theorem cert_e1124576885366 : checkPay e1124576885366 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1124576885558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124576885558 : Closed e1124576885558 ∧ code e1124576885558 = 5522623396662 := by decide
theorem cert_e1124576885558 : checkPay e1124576885558 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1124576885562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124576885562 : Closed e1124576885562 ∧ code e1124576885562 = 5522623396666 := by decide
theorem cert_e1124576885562 : checkPay e1124576885562 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1124576892782 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1124576892782 : Closed e1124576892782 ∧ code e1124576892782 = 5522623403886 := by decide
theorem cert_e1124576892782 : checkPay e1124576892782 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1124576892790 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1124576892790 : Closed e1124576892790 ∧ code e1124576892790 = 5522623403894 := by decide
theorem cert_e1124576892790 : check e1124576892790 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124576892854 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1124576892854 : Closed e1124576892854 ∧ code e1124576892854 = 5522623403958 := by decide
theorem cert_e1124576892854 : check e1124576892854 [[.left,.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1124576894190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1124576894190 : Closed e1124576894190 ∧ code e1124576894190 = 5522623405294 := by decide
theorem cert_e1124576894190 : check e1124576894190 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1124576894198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1124576894198 : Closed e1124576894198 ∧ code e1124576894198 = 5522623405302 := by decide
theorem cert_e1124576894198 : check e1124576894198 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left]] .identityHead = true := by decide
def e1124576894582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1124576894582 : Closed e1124576894582 ∧ code e1124576894582 = 5522623405686 := by decide
theorem cert_e1124576894582 : check e1124576894582 [[.left,.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1124576906094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124576906094 : Closed e1124576906094 ∧ code e1124576906094 = 5522623417198 := by decide
theorem cert_e1124576906094 : check e1124576906094 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906102 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124576906102 : Closed e1124576906102 ∧ code e1124576906102 = 5522623417206 := by decide
theorem cert_e1124576906102 : check e1124576906102 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124576906158 : Closed e1124576906158 ∧ code e1124576906158 = 5522623417262 := by decide
theorem cert_e1124576906158 : check e1124576906158 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124576906170 : Closed e1124576906170 ∧ code e1124576906170 = 5522623417274 := by decide
theorem cert_e1124576906170 : check e1124576906170 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124576906198 : Closed e1124576906198 ∧ code e1124576906198 = 5522623417302 := by decide
theorem cert_e1124576906198 : check e1124576906198 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124576906202 : Closed e1124576906202 ∧ code e1124576906202 = 5522623417306 := by decide
theorem cert_e1124576906202 : check e1124576906202 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906478 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124576906478 : Closed e1124576906478 ∧ code e1124576906478 = 5522623417582 := by decide
theorem cert_e1124576906478 : check e1124576906478 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906486 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124576906486 : Closed e1124576906486 ∧ code e1124576906486 = 5522623417590 := by decide
theorem cert_e1124576906486 : check e1124576906486 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124576906862 : Closed e1124576906862 ∧ code e1124576906862 = 5522623417966 := by decide
theorem cert_e1124576906862 : check e1124576906862 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576906874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124576906874 : Closed e1124576906874 ∧ code e1124576906874 = 5522623417978 := by decide
theorem cert_e1124576906874 : check e1124576906874 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576907062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124576907062 : Closed e1124576907062 ∧ code e1124576907062 = 5522623418166 := by decide
theorem cert_e1124576907062 : check e1124576907062 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576907066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124576907066 : Closed e1124576907066 ∧ code e1124576907066 = 5522623418170 := by decide
theorem cert_e1124576907066 : check e1124576907066 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124576912822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1124576912822 : Closed e1124576912822 ∧ code e1124576912822 = 5522623423926 := by decide
theorem cert_e1124576912822 : check e1124576912822 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576912854 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1124576912854 : Closed e1124576912854 ∧ code e1124576912854 = 5522623423958 := by decide
theorem cert_e1124576912854 : check e1124576912854 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576912858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1124576912858 : Closed e1124576912858 ∧ code e1124576912858 = 5522623423962 := by decide
theorem cert_e1124576912858 : check e1124576912858 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576913014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1124576913014 : Closed e1124576913014 ∧ code e1124576913014 = 5522623424118 := by decide
theorem cert_e1124576913014 : check e1124576913014 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576913206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1124576913206 : Closed e1124576913206 ∧ code e1124576913206 = 5522623424310 := by decide
theorem cert_e1124576913206 : check e1124576913206 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124576913210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1124576913210 : Closed e1124576913210 ∧ code e1124576913210 = 5522623424314 := by decide
theorem cert_e1124576913210 : check e1124576913210 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1124577250158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124577250158 : Closed e1124577250158 ∧ code e1124577250158 = 5522623761262 := by decide
theorem cert_e1124577250158 : check e1124577250158 [[],[.under,.left]] .chain = true := by decide
def e1124577250166 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124577250166 : Closed e1124577250166 ∧ code e1124577250166 = 5522623761270 := by decide
theorem cert_e1124577250166 : check e1124577250166 [[],[.under,.left]] .chain = true := by decide
def e1124577250222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124577250222 : Closed e1124577250222 ∧ code e1124577250222 = 5522623761326 := by decide
theorem cert_e1124577250222 : check e1124577250222 [[],[.under,.left]] .chain = true := by decide
def e1124577250234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124577250234 : Closed e1124577250234 ∧ code e1124577250234 = 5522623761338 := by decide
theorem cert_e1124577250234 : check e1124577250234 [[],[.under,.left]] .chain = true := by decide
def e1124577250262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124577250262 : Closed e1124577250262 ∧ code e1124577250262 = 5522623761366 := by decide
theorem cert_e1124577250262 : check e1124577250262 [[],[.under,.left]] .chain = true := by decide
def e1124577250266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124577250266 : Closed e1124577250266 ∧ code e1124577250266 = 5522623761370 := by decide
theorem cert_e1124577250266 : check e1124577250266 [[],[.under,.left]] .chain = true := by decide
def e1124577250542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124577250542 : Closed e1124577250542 ∧ code e1124577250542 = 5522623761646 := by decide
theorem cert_e1124577250542 : check e1124577250542 [[],[.under,.left]] .chain = true := by decide
def e1124577250550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124577250550 : Closed e1124577250550 ∧ code e1124577250550 = 5522623761654 := by decide
theorem cert_e1124577250550 : check e1124577250550 [[],[.under,.left]] .chain = true := by decide
def e1124577250926 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124577250926 : Closed e1124577250926 ∧ code e1124577250926 = 5522623762030 := by decide
theorem cert_e1124577250926 : check e1124577250926 [[],[.under,.left]] .chain = true := by decide
def e1124577250938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124577250938 : Closed e1124577250938 ∧ code e1124577250938 = 5522623762042 := by decide
theorem cert_e1124577250938 : check e1124577250938 [[],[.under,.left]] .chain = true := by decide
def e1124577251126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124577251126 : Closed e1124577251126 ∧ code e1124577251126 = 5522623762230 := by decide
theorem cert_e1124577251126 : check e1124577251126 [[],[.under,.left]] .chain = true := by decide
def e1124577251130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124577251130 : Closed e1124577251130 ∧ code e1124577251130 = 5522623762234 := by decide
theorem cert_e1124577251130 : check e1124577251130 [[],[.under,.left]] .chain = true := by decide
def e1124611841562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611841562 : Closed e1124611841562 ∧ code e1124611841562 = 5522658352666 := by decide
private def t_e1124611841562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611841562 : ¬ IsSelfInterpreter e1124611841562 :=
  wSource (t := t_e1124611841562) (replay_sound (ps := []) (t := e1124611841562) (by decide)) (by decide)
def e1124611847706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611847706 : Closed e1124611847706 ∧ code e1124611847706 = 5522658358810 := by decide
private def t_e1124611847706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611847706 : ¬ IsSelfInterpreter e1124611847706 :=
  wSource (t := t_e1124611847706) (replay_sound (ps := []) (t := e1124611847706) (by decide)) (by decide)
def e1124611874330 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611874330 : Closed e1124611874330 ∧ code e1124611874330 = 5522658385434 := by decide
private def t_e1124611874330 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611874330 : ¬ IsSelfInterpreter e1124611874330 :=
  wSource (t := t_e1124611874330) (replay_sound (ps := []) (t := e1124611874330) (by decide)) (by decide)
def e1124611881498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611881498 : Closed e1124611881498 ∧ code e1124611881498 = 5522658392602 := by decide
private def t_e1124611881498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611881498 : ¬ IsSelfInterpreter e1124611881498 :=
  wSource (t := t_e1124611881498) (replay_sound (ps := []) (t := e1124611881498) (by decide)) (by decide)
def e1124611905050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611905050 : Closed e1124611905050 ∧ code e1124611905050 = 5522658416154 := by decide
private def t_e1124611905050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611905050 : ¬ IsSelfInterpreter e1124611905050 :=
  wSource (t := t_e1124611905050) (replay_sound (ps := []) (t := e1124611905050) (by decide)) (by decide)
def e1124611906074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124611906074 : Closed e1124611906074 ∧ code e1124611906074 = 5522658417178 := by decide
private def t_e1124611906074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124611906074 : ¬ IsSelfInterpreter e1124611906074 :=
  wSource (t := t_e1124611906074) (replay_sound (ps := []) (t := e1124611906074) (by decide)) (by decide)
def e1124612038170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612038170 : Closed e1124612038170 ∧ code e1124612038170 = 5522658549274 := by decide
private def t_e1124612038170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612038170 : ¬ IsSelfInterpreter e1124612038170 :=
  wSource (t := t_e1124612038170) (replay_sound (ps := []) (t := e1124612038170) (by decide)) (by decide)
def e1124612044314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612044314 : Closed e1124612044314 ∧ code e1124612044314 = 5522658555418 := by decide
private def t_e1124612044314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612044314 : ¬ IsSelfInterpreter e1124612044314 :=
  wSource (t := t_e1124612044314) (replay_sound (ps := []) (t := e1124612044314) (by decide)) (by decide)
def e1124612234778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612234778 : Closed e1124612234778 ∧ code e1124612234778 = 5522658745882 := by decide
private def t_e1124612234778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612234778 : ¬ IsSelfInterpreter e1124612234778 :=
  wSource (t := t_e1124612234778) (replay_sound (ps := []) (t := e1124612234778) (by decide)) (by decide)
def e1124612241946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612241946 : Closed e1124612241946 ∧ code e1124612241946 = 5522658753050 := by decide
private def t_e1124612241946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612241946 : ¬ IsSelfInterpreter e1124612241946 :=
  wSource (t := t_e1124612241946) (replay_sound (ps := []) (t := e1124612241946) (by decide)) (by decide)
def e1124612388378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612388378 : Closed e1124612388378 ∧ code e1124612388378 = 5522658899482 := by decide
private def t_e1124612388378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612388378 : ¬ IsSelfInterpreter e1124612388378 :=
  wSource (t := t_e1124612388378) (replay_sound (ps := []) (t := e1124612388378) (by decide)) (by decide)
def e1124612389402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124612389402 : Closed e1124612389402 ∧ code e1124612389402 = 5522658900506 := by decide
private def t_e1124612389402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124612389402 : ¬ IsSelfInterpreter e1124612389402 :=
  wSource (t := t_e1124612389402) (replay_sound (ps := []) (t := e1124612389402) (by decide)) (by decide)
def e1124616171034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616171034 : Closed e1124616171034 ∧ code e1124616171034 = 5522662682138 := by decide
private def t_e1124616171034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616171034 : ¬ IsSelfInterpreter e1124616171034 :=
  wSource (t := t_e1124616171034) (replay_sound (ps := []) (t := e1124616171034) (by decide)) (by decide)
def e1124616173082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616173082 : Closed e1124616173082 ∧ code e1124616173082 = 5522662684186 := by decide
private def t_e1124616173082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616173082 : ¬ IsSelfInterpreter e1124616173082 :=
  wSource (t := t_e1124616173082) (replay_sound (ps := []) (t := e1124616173082) (by decide)) (by decide)
def e1124616314394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616314394 : Closed e1124616314394 ∧ code e1124616314394 = 5522662825498 := by decide
private def t_e1124616314394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616314394 : ¬ IsSelfInterpreter e1124616314394 :=
  wSource (t := t_e1124616314394) (replay_sound (ps := []) (t := e1124616314394) (by decide)) (by decide)
def e1124616335558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616335558 : Closed e1124616335558 ∧ code e1124616335558 = 5522662846662 := by decide
theorem cert_e1124616335558 : check e1124616335558 [[]] .width = true := by decide
def e1124616343066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616343066 : Closed e1124616343066 ∧ code e1124616343066 = 5522662854170 := by decide
private def t_e1124616343066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616343066 : ¬ IsSelfInterpreter e1124616343066 :=
  wSource (t := t_e1124616343066) (replay_sound (ps := []) (t := e1124616343066) (by decide)) (by decide)
def e1124616351942 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616351942 : Closed e1124616351942 ∧ code e1124616351942 = 5522662863046 := by decide
theorem cert_e1124616351942 : check e1124616351942 [[]] .width = true := by decide
def e1124616400410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616400410 : Closed e1124616400410 ∧ code e1124616400410 = 5522662911514 := by decide
private def t_e1124616400410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616400410 : ¬ IsSelfInterpreter e1124616400410 :=
  wSource (t := t_e1124616400410) (replay_sound (ps := []) (t := e1124616400410) (by decide)) (by decide)
def e1124616403482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616403482 : Closed e1124616403482 ∧ code e1124616403482 = 5522662914586 := by decide
private def t_e1124616403482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616403482 : ¬ IsSelfInterpreter e1124616403482 :=
  wSource (t := t_e1124616403482) (replay_sound (ps := []) (t := e1124616403482) (by decide)) (by decide)
def e1124616445466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616445466 : Closed e1124616445466 ∧ code e1124616445466 = 5522662956570 := by decide
private def t_e1124616445466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616445466 : ¬ IsSelfInterpreter e1124616445466 :=
  wSource (t := t_e1124616445466) (replay_sound (ps := []) (t := e1124616445466) (by decide)) (by decide)
def e1124616466630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616466630 : Closed e1124616466630 ∧ code e1124616466630 = 5522662977734 := by decide
theorem cert_e1124616466630 : check e1124616466630 [[]] .width = true := by decide
def e1124616488474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616488474 : Closed e1124616488474 ∧ code e1124616488474 = 5522662999578 := by decide
private def t_e1124616488474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616488474 : ¬ IsSelfInterpreter e1124616488474 :=
  wSource (t := t_e1124616488474) (replay_sound (ps := []) (t := e1124616488474) (by decide)) (by decide)
def e1124616491206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616491206 : Closed e1124616491206 ∧ code e1124616491206 = 5522663002310 := by decide
theorem cert_e1124616491206 : check e1124616491206 [[]] .width = true := by decide
def e1124616517146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616517146 : Closed e1124616517146 ∧ code e1124616517146 = 5522663028250 := by decide
private def t_e1124616517146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616517146 : ¬ IsSelfInterpreter e1124616517146 :=
  wSource (t := t_e1124616517146) (replay_sound (ps := []) (t := e1124616517146) (by decide)) (by decide)
def e1124616518170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616518170 : Closed e1124616518170 ∧ code e1124616518170 = 5522663029274 := by decide
private def t_e1124616518170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616518170 : ¬ IsSelfInterpreter e1124616518170 :=
  wSource (t := t_e1124616518170) (replay_sound (ps := []) (t := e1124616518170) (by decide)) (by decide)
def e1124616539674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616539674 : Closed e1124616539674 ∧ code e1124616539674 = 5522663050778 := by decide
private def t_e1124616539674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616539674 : ¬ IsSelfInterpreter e1124616539674 :=
  wSource (t := t_e1124616539674) (replay_sound (ps := []) (t := e1124616539674) (by decide)) (by decide)
def e1124616548550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616548550 : Closed e1124616548550 ∧ code e1124616548550 = 5522663059654 := by decide
theorem cert_e1124616548550 : check e1124616548550 [[]] .width = true := by decide
def e1124616554010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124616554010 : Closed e1124616554010 ∧ code e1124616554010 = 5522663065114 := by decide
private def t_e1124616554010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124616554010 : ¬ IsSelfInterpreter e1124616554010 :=
  wSource (t := t_e1124616554010) (replay_sound (ps := []) (t := e1124616554010) (by decide)) (by decide)
def e1124616556742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124616556742 : Closed e1124616556742 ∧ code e1124616556742 = 5522663067846 := by decide
theorem cert_e1124616556742 : check e1124616556742 [[]] .width = true := by decide
end Blc.Floor42
