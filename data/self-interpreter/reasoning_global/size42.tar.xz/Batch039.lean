import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1105861477178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105861477178 : Closed e1105861477178 ∧ code e1105861477178 = 5503907988282 := by decide
theorem cert_e1105861477178 : check e1105861477178 [[]] .width = true := by decide
def e1105861477262 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105861477262 : Closed e1105861477262 ∧ code e1105861477262 = 5503907988366 := by decide
theorem cert_e1105861477262 : check e1105861477262 [[]] .width = true := by decide
def e1105861477274 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105861477274 : Closed e1105861477274 ∧ code e1105861477274 = 5503907988378 := by decide
theorem cert_e1105861477274 : check e1105861477274 [[]] .width = true := by decide
def e1105861479194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105861479194 : Closed e1105861479194 ∧ code e1105861479194 = 5503907990298 := by decide
theorem cert_e1105861479194 : check e1105861479194 [[]] .width = true := by decide
def e1105861479238 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105861479238 : Closed e1105861479238 ∧ code e1105861479238 = 5503907990342 := by decide
theorem cert_e1105861479238 : check e1105861479238 [[]] .width = true := by decide
def e1105861479478 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105861479478 : Closed e1105861479478 ∧ code e1105861479478 = 5503907990582 := by decide
theorem cert_e1105861479478 : check e1105861479478 [[]] .width = true := by decide
def e1105861479482 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105861479482 : Closed e1105861479482 ∧ code e1105861479482 = 5503907990586 := by decide
theorem cert_e1105861479482 : check e1105861479482 [[]] .width = true := by decide
def e1105861479622 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105861479622 : Closed e1105861479622 ∧ code e1105861479622 = 5503907990726 := by decide
theorem cert_e1105861479622 : check e1105861479622 [[]] .width = true := by decide
def e1105873797318 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105873797318 : Closed e1105873797318 ∧ code e1105873797318 = 5503920308422 := by decide
theorem cert_e1105873797318 : check e1105873797318 [[]] .width = true := by decide
def e1105873797846 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105873797846 : Closed e1105873797846 ∧ code e1105873797846 = 5503920308950 := by decide
theorem cert_e1105873797846 : check e1105873797846 [[]] .width = true := by decide
def e1105873797850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105873797850 : Closed e1105873797850 ∧ code e1105873797850 = 5503920308954 := by decide
theorem cert_e1105873797850 : check e1105873797850 [[]] .width = true := by decide
def e1105873797866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105873797866 : Closed e1105873797866 ∧ code e1105873797866 = 5503920308970 := by decide
theorem cert_e1105873797866 : check e1105873797866 [[]] .width = true := by decide
def e1105873797942 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105873797942 : Closed e1105873797942 ∧ code e1105873797942 = 5503920309046 := by decide
theorem cert_e1105873797942 : check e1105873797942 [[]] .width = true := by decide
def e1105873797946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105873797946 : Closed e1105873797946 ∧ code e1105873797946 = 5503920309050 := by decide
theorem cert_e1105873797946 : check e1105873797946 [[]] .width = true := by decide
def e1105873798030 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105873798030 : Closed e1105873798030 ∧ code e1105873798030 = 5503920309134 := by decide
theorem cert_e1105873798030 : check e1105873798030 [[]] .width = true := by decide
def e1105873798042 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105873798042 : Closed e1105873798042 ∧ code e1105873798042 = 5503920309146 := by decide
theorem cert_e1105873798042 : check e1105873798042 [[]] .width = true := by decide
def e1105873799962 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105873799962 : Closed e1105873799962 ∧ code e1105873799962 = 5503920311066 := by decide
theorem cert_e1105873799962 : check e1105873799962 [[]] .width = true := by decide
def e1105873800006 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105873800006 : Closed e1105873800006 ∧ code e1105873800006 = 5503920311110 := by decide
theorem cert_e1105873800006 : check e1105873800006 [[]] .width = true := by decide
def e1105873800246 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105873800246 : Closed e1105873800246 ∧ code e1105873800246 = 5503920311350 := by decide
theorem cert_e1105873800246 : check e1105873800246 [[]] .width = true := by decide
def e1105873800250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105873800250 : Closed e1105873800250 ∧ code e1105873800250 = 5503920311354 := by decide
theorem cert_e1105873800250 : check e1105873800250 [[]] .width = true := by decide
def e1105873800390 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105873800390 : Closed e1105873800390 ∧ code e1105873800390 = 5503920311494 := by decide
theorem cert_e1105873800390 : check e1105873800390 [[]] .width = true := by decide
def e1105874149402 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105874149402 : Closed e1105874149402 ∧ code e1105874149402 = 5503920660506 := by decide
theorem cert_e1105874149402 : check e1105874149402 [[]] .width = true := by decide
def e1105874149494 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105874149494 : Closed e1105874149494 ∧ code e1105874149494 = 5503920660598 := by decide
theorem cert_e1105874149494 : check e1105874149494 [[]] .width = true := by decide
def e1105874149738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105874149738 : Closed e1105874149738 ∧ code e1105874149738 = 5503920660842 := by decide
theorem cert_e1105874149738 : check e1105874149738 [[]] .width = true := by decide
def e1105874149786 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105874149786 : Closed e1105874149786 ∧ code e1105874149786 = 5503920660890 := by decide
theorem cert_e1105874149786 : check e1105874149786 [[]] .width = true := by decide
def e1105874190534 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105874190534 : Closed e1105874190534 ∧ code e1105874190534 = 5503920701638 := by decide
theorem cert_e1105874190534 : check e1105874190534 [[]] .width = true := by decide
def e1105874191062 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105874191062 : Closed e1105874191062 ∧ code e1105874191062 = 5503920702166 := by decide
theorem cert_e1105874191062 : check e1105874191062 [[]] .width = true := by decide
def e1105874191066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105874191066 : Closed e1105874191066 ∧ code e1105874191066 = 5503920702170 := by decide
theorem cert_e1105874191066 : check e1105874191066 [[]] .width = true := by decide
def e1105874191082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105874191082 : Closed e1105874191082 ∧ code e1105874191082 = 5503920702186 := by decide
theorem cert_e1105874191082 : check e1105874191082 [[]] .width = true := by decide
def e1105874191158 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105874191158 : Closed e1105874191158 ∧ code e1105874191158 = 5503920702262 := by decide
theorem cert_e1105874191158 : check e1105874191158 [[]] .width = true := by decide
def e1105874191162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105874191162 : Closed e1105874191162 ∧ code e1105874191162 = 5503920702266 := by decide
theorem cert_e1105874191162 : check e1105874191162 [[]] .width = true := by decide
def e1105874191246 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105874191246 : Closed e1105874191246 ∧ code e1105874191246 = 5503920702350 := by decide
theorem cert_e1105874191246 : check e1105874191246 [[]] .width = true := by decide
def e1105874191258 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105874191258 : Closed e1105874191258 ∧ code e1105874191258 = 5503920702362 := by decide
theorem cert_e1105874191258 : check e1105874191258 [[]] .width = true := by decide
def e1105874193178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105874193178 : Closed e1105874193178 ∧ code e1105874193178 = 5503920704282 := by decide
theorem cert_e1105874193178 : check e1105874193178 [[]] .width = true := by decide
def e1105874193222 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105874193222 : Closed e1105874193222 ∧ code e1105874193222 = 5503920704326 := by decide
theorem cert_e1105874193222 : check e1105874193222 [[]] .width = true := by decide
def e1105874193462 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105874193462 : Closed e1105874193462 ∧ code e1105874193462 = 5503920704566 := by decide
theorem cert_e1105874193462 : check e1105874193462 [[]] .width = true := by decide
def e1105874193466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105874193466 : Closed e1105874193466 ∧ code e1105874193466 = 5503920704570 := by decide
theorem cert_e1105874193466 : check e1105874193466 [[]] .width = true := by decide
def e1105874193606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105874193606 : Closed e1105874193606 ∧ code e1105874193606 = 5503920704710 := by decide
theorem cert_e1105874193606 : check e1105874193606 [[]] .width = true := by decide
def e1105880211482 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105880211482 : Closed e1105880211482 ∧ code e1105880211482 = 5503926722586 := by decide
theorem cert_e1105880211482 : check e1105880211482 [[]] .width = true := by decide
def e1105880211574 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105880211574 : Closed e1105880211574 ∧ code e1105880211574 = 5503926722678 := by decide
private def t_e1105880211574 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105880211574 : ¬ IsSelfInterpreter e1105880211574 :=
  wSource (t := t_e1105880211574) (replay_sound (ps := []) (t := e1105880211574) (by decide)) (by decide)
def e1105880211818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105880211818 : Closed e1105880211818 ∧ code e1105880211818 = 5503926722922 := by decide
private def t_e1105880211818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105880211818 : ¬ IsSelfInterpreter e1105880211818 :=
  wSource (t := t_e1105880211818) (replay_sound (ps := []) (t := e1105880211818) (by decide)) (by decide)
def e1105880211866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105880211866 : Closed e1105880211866 ∧ code e1105880211866 = 5503926722970 := by decide
private def t_e1105880211866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105880211866 : ¬ IsSelfInterpreter e1105880211866 :=
  wSource (t := t_e1105880211866) (replay_sound (ps := []) (t := e1105880211866) (by decide)) (by decide)
def e1105880350918 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105880350918 : Closed e1105880350918 ∧ code e1105880350918 = 5503926862022 := by decide
theorem cert_e1105880350918 : check e1105880350918 [[]] .width = true := by decide
def e1105880351446 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105880351446 : Closed e1105880351446 ∧ code e1105880351446 = 5503926862550 := by decide
theorem cert_e1105880351446 : check e1105880351446 [[]] .width = true := by decide
def e1105880351450 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105880351450 : Closed e1105880351450 ∧ code e1105880351450 = 5503926862554 := by decide
theorem cert_e1105880351450 : check e1105880351450 [[]] .width = true := by decide
def e1105880351466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105880351466 : Closed e1105880351466 ∧ code e1105880351466 = 5503926862570 := by decide
theorem cert_e1105880351466 : check e1105880351466 [[]] .width = true := by decide
def e1105880351542 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105880351542 : Closed e1105880351542 ∧ code e1105880351542 = 5503926862646 := by decide
theorem cert_e1105880351542 : check e1105880351542 [[]] .width = true := by decide
def e1105880351546 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105880351546 : Closed e1105880351546 ∧ code e1105880351546 = 5503926862650 := by decide
theorem cert_e1105880351546 : check e1105880351546 [[]] .width = true := by decide
def e1105880351630 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105880351630 : Closed e1105880351630 ∧ code e1105880351630 = 5503926862734 := by decide
theorem cert_e1105880351630 : check e1105880351630 [[]] .width = true := by decide
def e1105880351642 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105880351642 : Closed e1105880351642 ∧ code e1105880351642 = 5503926862746 := by decide
theorem cert_e1105880351642 : check e1105880351642 [[]] .width = true := by decide
def e1105880353562 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105880353562 : Closed e1105880353562 ∧ code e1105880353562 = 5503926864666 := by decide
theorem cert_e1105880353562 : check e1105880353562 [[]] .width = true := by decide
def e1105880353606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105880353606 : Closed e1105880353606 ∧ code e1105880353606 = 5503926864710 := by decide
private def t_e1105880353606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e1105880353606 : ¬ IsSelfInterpreter e1105880353606 :=
  wSource (t := t_e1105880353606) (replay_sound (ps := []) (t := e1105880353606) (by decide)) (by decide)
def e1105880353846 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105880353846 : Closed e1105880353846 ∧ code e1105880353846 = 5503926864950 := by decide
private def t_e1105880353846 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e1105880353846 : ¬ IsSelfInterpreter e1105880353846 :=
  wSource (t := t_e1105880353846) (replay_sound (ps := []) (t := e1105880353846) (by decide)) (by decide)
def e1105880353850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105880353850 : Closed e1105880353850 ∧ code e1105880353850 = 5503926864954 := by decide
private def t_e1105880353850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e1105880353850 : ¬ IsSelfInterpreter e1105880353850 :=
  wSource (t := t_e1105880353850) (replay_sound (ps := []) (t := e1105880353850) (by decide)) (by decide)
def e1105880353990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105880353990 : Closed e1105880353990 ∧ code e1105880353990 = 5503926865094 := by decide
theorem cert_e1105880353990 : check e1105880353990 [[]] .width = true := by decide
def e1105880440858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105880440858 : Closed e1105880440858 ∧ code e1105880440858 = 5503926951962 := by decide
theorem cert_e1105880440858 : check e1105880440858 [[]] .width = true := by decide
def e1105880440950 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105880440950 : Closed e1105880440950 ∧ code e1105880440950 = 5503926952054 := by decide
private def t_e1105880440950 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105880440950 : ¬ IsSelfInterpreter e1105880440950 :=
  wSource (t := t_e1105880440950) (replay_sound (ps := []) (t := e1105880440950) (by decide)) (by decide)
def e1105880441194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105880441194 : Closed e1105880441194 ∧ code e1105880441194 = 5503926952298 := by decide
private def t_e1105880441194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105880441194 : ¬ IsSelfInterpreter e1105880441194 :=
  wSource (t := t_e1105880441194) (replay_sound (ps := []) (t := e1105880441194) (by decide)) (by decide)
def e1105880441242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105880441242 : Closed e1105880441242 ∧ code e1105880441242 = 5503926952346 := by decide
private def t_e1105880441242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105880441242 : ¬ IsSelfInterpreter e1105880441242 :=
  wSource (t := t_e1105880441242) (replay_sound (ps := []) (t := e1105880441242) (by decide)) (by decide)
def e1105880481990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105880481990 : Closed e1105880481990 ∧ code e1105880481990 = 5503926993094 := by decide
theorem cert_e1105880481990 : check e1105880481990 [[]] .width = true := by decide
def e1105880482518 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105880482518 : Closed e1105880482518 ∧ code e1105880482518 = 5503926993622 := by decide
theorem cert_e1105880482518 : check e1105880482518 [[]] .width = true := by decide
def e1105880482522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105880482522 : Closed e1105880482522 ∧ code e1105880482522 = 5503926993626 := by decide
theorem cert_e1105880482522 : check e1105880482522 [[]] .width = true := by decide
def e1105880482538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105880482538 : Closed e1105880482538 ∧ code e1105880482538 = 5503926993642 := by decide
theorem cert_e1105880482538 : check e1105880482538 [[]] .width = true := by decide
def e1105880482614 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105880482614 : Closed e1105880482614 ∧ code e1105880482614 = 5503926993718 := by decide
theorem cert_e1105880482614 : check e1105880482614 [[]] .width = true := by decide
def e1105880482618 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105880482618 : Closed e1105880482618 ∧ code e1105880482618 = 5503926993722 := by decide
theorem cert_e1105880482618 : check e1105880482618 [[]] .width = true := by decide
def e1105880482702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105880482702 : Closed e1105880482702 ∧ code e1105880482702 = 5503926993806 := by decide
theorem cert_e1105880482702 : check e1105880482702 [[]] .width = true := by decide
def e1105880482714 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105880482714 : Closed e1105880482714 ∧ code e1105880482714 = 5503926993818 := by decide
theorem cert_e1105880482714 : check e1105880482714 [[]] .width = true := by decide
def e1105880484634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105880484634 : Closed e1105880484634 ∧ code e1105880484634 = 5503926995738 := by decide
theorem cert_e1105880484634 : check e1105880484634 [[]] .width = true := by decide
def e1105880484678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105880484678 : Closed e1105880484678 ∧ code e1105880484678 = 5503926995782 := by decide
private def t_e1105880484678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e1105880484678 : ¬ IsSelfInterpreter e1105880484678 :=
  wSource (t := t_e1105880484678) (replay_sound (ps := []) (t := e1105880484678) (by decide)) (by decide)
def e1105880484918 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105880484918 : Closed e1105880484918 ∧ code e1105880484918 = 5503926996022 := by decide
private def t_e1105880484918 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e1105880484918 : ¬ IsSelfInterpreter e1105880484918 :=
  wSource (t := t_e1105880484918) (replay_sound (ps := []) (t := e1105880484918) (by decide)) (by decide)
def e1105880484922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105880484922 : Closed e1105880484922 ∧ code e1105880484922 = 5503926996026 := by decide
private def t_e1105880484922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e1105880484922 : ¬ IsSelfInterpreter e1105880484922 :=
  wSource (t := t_e1105880484922) (replay_sound (ps := []) (t := e1105880484922) (by decide)) (by decide)
def e1105880485062 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105880485062 : Closed e1105880485062 ∧ code e1105880485062 = 5503926996166 := by decide
theorem cert_e1105880485062 : check e1105880485062 [[]] .width = true := by decide
def e1106347753670 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106347753670 : Closed e1106347753670 ∧ code e1106347753670 = 5504394264774 := by decide
theorem cert_e1106347753670 : check e1106347753670 [[]] .width = true := by decide
def e1106347754198 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106347754198 : Closed e1106347754198 ∧ code e1106347754198 = 5504394265302 := by decide
theorem cert_e1106347754198 : check e1106347754198 [[]] .width = true := by decide
def e1106347754202 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106347754202 : Closed e1106347754202 ∧ code e1106347754202 = 5504394265306 := by decide
theorem cert_e1106347754202 : check e1106347754202 [[]] .width = true := by decide
def e1106347754218 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106347754218 : Closed e1106347754218 ∧ code e1106347754218 = 5504394265322 := by decide
theorem cert_e1106347754218 : check e1106347754218 [[]] .width = true := by decide
def e1106347754294 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106347754294 : Closed e1106347754294 ∧ code e1106347754294 = 5504394265398 := by decide
theorem cert_e1106347754294 : check e1106347754294 [[]] .width = true := by decide
def e1106347754298 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106347754298 : Closed e1106347754298 ∧ code e1106347754298 = 5504394265402 := by decide
theorem cert_e1106347754298 : check e1106347754298 [[]] .width = true := by decide
def e1106347754382 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106347754382 : Closed e1106347754382 ∧ code e1106347754382 = 5504394265486 := by decide
theorem cert_e1106347754382 : check e1106347754382 [[]] .width = true := by decide
def e1106347754394 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106347754394 : Closed e1106347754394 ∧ code e1106347754394 = 5504394265498 := by decide
theorem cert_e1106347754394 : check e1106347754394 [[]] .width = true := by decide
def e1106347756314 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106347756314 : Closed e1106347756314 ∧ code e1106347756314 = 5504394267418 := by decide
theorem cert_e1106347756314 : check e1106347756314 [[]] .width = true := by decide
def e1106347756358 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106347756358 : Closed e1106347756358 ∧ code e1106347756358 = 5504394267462 := by decide
theorem cert_e1106347756358 : check e1106347756358 [[]] .width = true := by decide
def e1106347756598 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106347756598 : Closed e1106347756598 ∧ code e1106347756598 = 5504394267702 := by decide
theorem cert_e1106347756598 : check e1106347756598 [[]] .width = true := by decide
def e1106347756602 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106347756602 : Closed e1106347756602 ∧ code e1106347756602 = 5504394267706 := by decide
theorem cert_e1106347756602 : check e1106347756602 [[]] .width = true := by decide
def e1106347756742 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106347756742 : Closed e1106347756742 ∧ code e1106347756742 = 5504394267846 := by decide
theorem cert_e1106347756742 : check e1106347756742 [[]] .width = true := by decide
def e1106349318170 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1106349318170 : Closed e1106349318170 ∧ code e1106349318170 = 5504395829274 := by decide
theorem cert_e1106349318170 : check e1106349318170 [[]] .width = true := by decide
def e1106349318262 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1106349318262 : Closed e1106349318262 ∧ code e1106349318262 = 5504395829366 := by decide
theorem cert_e1106349318262 : check e1106349318262 [[]] .width = true := by decide
def e1106349318506 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1106349318506 : Closed e1106349318506 ∧ code e1106349318506 = 5504395829610 := by decide
theorem cert_e1106349318506 : check e1106349318506 [[]] .width = true := by decide
def e1106349318554 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1106349318554 : Closed e1106349318554 ∧ code e1106349318554 = 5504395829658 := by decide
theorem cert_e1106349318554 : check e1106349318554 [[]] .width = true := by decide
def e1106351947974 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106351947974 : Closed e1106351947974 ∧ code e1106351947974 = 5504398459078 := by decide
theorem cert_e1106351947974 : check e1106351947974 [[]] .width = true := by decide
def e1106351948502 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106351948502 : Closed e1106351948502 ∧ code e1106351948502 = 5504398459606 := by decide
theorem cert_e1106351948502 : check e1106351948502 [[]] .width = true := by decide
def e1106351948506 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106351948506 : Closed e1106351948506 ∧ code e1106351948506 = 5504398459610 := by decide
theorem cert_e1106351948506 : check e1106351948506 [[]] .width = true := by decide
def e1106351948522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106351948522 : Closed e1106351948522 ∧ code e1106351948522 = 5504398459626 := by decide
theorem cert_e1106351948522 : check e1106351948522 [[]] .width = true := by decide
def e1106351948598 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106351948598 : Closed e1106351948598 ∧ code e1106351948598 = 5504398459702 := by decide
theorem cert_e1106351948598 : check e1106351948598 [[]] .width = true := by decide
def e1106351948602 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106351948602 : Closed e1106351948602 ∧ code e1106351948602 = 5504398459706 := by decide
theorem cert_e1106351948602 : check e1106351948602 [[]] .width = true := by decide
def e1106351948686 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106351948686 : Closed e1106351948686 ∧ code e1106351948686 = 5504398459790 := by decide
theorem cert_e1106351948686 : check e1106351948686 [[]] .width = true := by decide
def e1106351948698 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106351948698 : Closed e1106351948698 ∧ code e1106351948698 = 5504398459802 := by decide
theorem cert_e1106351948698 : check e1106351948698 [[]] .width = true := by decide
def e1106351950618 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106351950618 : Closed e1106351950618 ∧ code e1106351950618 = 5504398461722 := by decide
theorem cert_e1106351950618 : check e1106351950618 [[]] .width = true := by decide
def e1106351950662 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106351950662 : Closed e1106351950662 ∧ code e1106351950662 = 5504398461766 := by decide
theorem cert_e1106351950662 : check e1106351950662 [[]] .width = true := by decide
def e1106351950902 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106351950902 : Closed e1106351950902 ∧ code e1106351950902 = 5504398462006 := by decide
theorem cert_e1106351950902 : check e1106351950902 [[]] .width = true := by decide
def e1106351950906 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106351950906 : Closed e1106351950906 ∧ code e1106351950906 = 5504398462010 := by decide
theorem cert_e1106351950906 : check e1106351950906 [[]] .width = true := by decide
def e1106351951046 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106351951046 : Closed e1106351951046 ∧ code e1106351951046 = 5504398462150 := by decide
theorem cert_e1106351951046 : check e1106351951046 [[]] .width = true := by decide
def e1106352070682 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1106352070682 : Closed e1106352070682 ∧ code e1106352070682 = 5504398581786 := by decide
theorem cert_e1106352070682 : check e1106352070682 [[]] .width = true := by decide
def e1106352070774 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1106352070774 : Closed e1106352070774 ∧ code e1106352070774 = 5504398581878 := by decide
theorem cert_e1106352070774 : check e1106352070774 [[]] .width = true := by decide
def e1106352071018 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1106352071018 : Closed e1106352071018 ∧ code e1106352071018 = 5504398582122 := by decide
theorem cert_e1106352071018 : check e1106352071018 [[]] .width = true := by decide
def e1106352071066 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1106352071066 : Closed e1106352071066 ∧ code e1106352071066 = 5504398582170 := by decide
theorem cert_e1106352071066 : check e1106352071066 [[]] .width = true := by decide
def e1106352210118 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106352210118 : Closed e1106352210118 ∧ code e1106352210118 = 5504398721222 := by decide
theorem cert_e1106352210118 : check e1106352210118 [[]] .width = true := by decide
def e1106352210646 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106352210646 : Closed e1106352210646 ∧ code e1106352210646 = 5504398721750 := by decide
theorem cert_e1106352210646 : check e1106352210646 [[]] .width = true := by decide
def e1106352210650 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106352210650 : Closed e1106352210650 ∧ code e1106352210650 = 5504398721754 := by decide
theorem cert_e1106352210650 : check e1106352210650 [[]] .width = true := by decide
def e1106352210666 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106352210666 : Closed e1106352210666 ∧ code e1106352210666 = 5504398721770 := by decide
theorem cert_e1106352210666 : check e1106352210666 [[]] .width = true := by decide
def e1106352210742 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106352210742 : Closed e1106352210742 ∧ code e1106352210742 = 5504398721846 := by decide
theorem cert_e1106352210742 : check e1106352210742 [[]] .width = true := by decide
def e1106352210746 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106352210746 : Closed e1106352210746 ∧ code e1106352210746 = 5504398721850 := by decide
theorem cert_e1106352210746 : check e1106352210746 [[]] .width = true := by decide
def e1106352210830 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106352210830 : Closed e1106352210830 ∧ code e1106352210830 = 5504398721934 := by decide
theorem cert_e1106352210830 : check e1106352210830 [[]] .width = true := by decide
def e1106352210842 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106352210842 : Closed e1106352210842 ∧ code e1106352210842 = 5504398721946 := by decide
theorem cert_e1106352210842 : check e1106352210842 [[]] .width = true := by decide
def e1106352212762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106352212762 : Closed e1106352212762 ∧ code e1106352212762 = 5504398723866 := by decide
theorem cert_e1106352212762 : check e1106352212762 [[]] .width = true := by decide
def e1106352212806 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106352212806 : Closed e1106352212806 ∧ code e1106352212806 = 5504398723910 := by decide
theorem cert_e1106352212806 : check e1106352212806 [[]] .width = true := by decide
def e1106352213046 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106352213046 : Closed e1106352213046 ∧ code e1106352213046 = 5504398724150 := by decide
theorem cert_e1106352213046 : check e1106352213046 [[]] .width = true := by decide
def e1106352213050 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106352213050 : Closed e1106352213050 ∧ code e1106352213050 = 5504398724154 := by decide
theorem cert_e1106352213050 : check e1106352213050 [[]] .width = true := by decide
def e1106352213190 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106352213190 : Closed e1106352213190 ∧ code e1106352213190 = 5504398724294 := by decide
theorem cert_e1106352213190 : check e1106352213190 [[]] .width = true := by decide
def e1106440028358 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106440028358 : Closed e1106440028358 ∧ code e1106440028358 = 5504486539462 := by decide
theorem cert_e1106440028358 : check e1106440028358 [[]] .width = true := by decide
def e1106440028886 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106440028886 : Closed e1106440028886 ∧ code e1106440028886 = 5504486539990 := by decide
theorem cert_e1106440028886 : check e1106440028886 [[]] .width = true := by decide
def e1106440028890 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106440028890 : Closed e1106440028890 ∧ code e1106440028890 = 5504486539994 := by decide
theorem cert_e1106440028890 : check e1106440028890 [[]] .width = true := by decide
def e1106440028906 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106440028906 : Closed e1106440028906 ∧ code e1106440028906 = 5504486540010 := by decide
theorem cert_e1106440028906 : check e1106440028906 [[]] .width = true := by decide
def e1106440028982 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106440028982 : Closed e1106440028982 ∧ code e1106440028982 = 5504486540086 := by decide
theorem cert_e1106440028982 : check e1106440028982 [[]] .width = true := by decide
def e1106440028986 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106440028986 : Closed e1106440028986 ∧ code e1106440028986 = 5504486540090 := by decide
theorem cert_e1106440028986 : check e1106440028986 [[]] .width = true := by decide
def e1106440029070 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106440029070 : Closed e1106440029070 ∧ code e1106440029070 = 5504486540174 := by decide
theorem cert_e1106440029070 : check e1106440029070 [[]] .width = true := by decide
def e1106440029082 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106440029082 : Closed e1106440029082 ∧ code e1106440029082 = 5504486540186 := by decide
theorem cert_e1106440029082 : check e1106440029082 [[]] .width = true := by decide
def e1106440031002 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106440031002 : Closed e1106440031002 ∧ code e1106440031002 = 5504486542106 := by decide
theorem cert_e1106440031002 : check e1106440031002 [[]] .width = true := by decide
def e1106440031046 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106440031046 : Closed e1106440031046 ∧ code e1106440031046 = 5504486542150 := by decide
theorem cert_e1106440031046 : check e1106440031046 [[]] .width = true := by decide
def e1106440031286 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106440031286 : Closed e1106440031286 ∧ code e1106440031286 = 5504486542390 := by decide
theorem cert_e1106440031286 : check e1106440031286 [[]] .width = true := by decide
def e1106440031290 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106440031290 : Closed e1106440031290 ∧ code e1106440031290 = 5504486542394 := by decide
theorem cert_e1106440031290 : check e1106440031290 [[]] .width = true := by decide
def e1106440031430 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106440031430 : Closed e1106440031430 ∧ code e1106440031430 = 5504486542534 := by decide
theorem cert_e1106440031430 : check e1106440031430 [[]] .width = true := by decide
def e1106465194182 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106465194182 : Closed e1106465194182 ∧ code e1106465194182 = 5504511705286 := by decide
theorem cert_e1106465194182 : check e1106465194182 [[]] .width = true := by decide
def e1106465194710 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106465194710 : Closed e1106465194710 ∧ code e1106465194710 = 5504511705814 := by decide
theorem cert_e1106465194710 : check e1106465194710 [[]] .width = true := by decide
def e1106465194714 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106465194714 : Closed e1106465194714 ∧ code e1106465194714 = 5504511705818 := by decide
theorem cert_e1106465194714 : check e1106465194714 [[]] .width = true := by decide
def e1106465194730 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106465194730 : Closed e1106465194730 ∧ code e1106465194730 = 5504511705834 := by decide
theorem cert_e1106465194730 : check e1106465194730 [[]] .width = true := by decide
def e1106465194806 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106465194806 : Closed e1106465194806 ∧ code e1106465194806 = 5504511705910 := by decide
theorem cert_e1106465194806 : check e1106465194806 [[]] .width = true := by decide
def e1106465194810 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106465194810 : Closed e1106465194810 ∧ code e1106465194810 = 5504511705914 := by decide
theorem cert_e1106465194810 : check e1106465194810 [[]] .width = true := by decide
def e1106465194894 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106465194894 : Closed e1106465194894 ∧ code e1106465194894 = 5504511705998 := by decide
theorem cert_e1106465194894 : check e1106465194894 [[]] .width = true := by decide
def e1106465194906 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106465194906 : Closed e1106465194906 ∧ code e1106465194906 = 5504511706010 := by decide
theorem cert_e1106465194906 : check e1106465194906 [[]] .width = true := by decide
def e1106465196826 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106465196826 : Closed e1106465196826 ∧ code e1106465196826 = 5504511707930 := by decide
theorem cert_e1106465196826 : check e1106465196826 [[]] .width = true := by decide
def e1106465196870 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106465196870 : Closed e1106465196870 ∧ code e1106465196870 = 5504511707974 := by decide
theorem cert_e1106465196870 : check e1106465196870 [[]] .width = true := by decide
def e1106465197110 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106465197110 : Closed e1106465197110 ∧ code e1106465197110 = 5504511708214 := by decide
theorem cert_e1106465197110 : check e1106465197110 [[]] .width = true := by decide
def e1106465197114 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1106465197114 : Closed e1106465197114 ∧ code e1106465197114 = 5504511708218 := by decide
theorem cert_e1106465197114 : check e1106465197114 [[]] .width = true := by decide
def e1106465197254 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1106465197254 : Closed e1106465197254 ∧ code e1106465197254 = 5504511708358 := by decide
theorem cert_e1106465197254 : check e1106465197254 [[]] .width = true := by decide
def e1106465316890 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1106465316890 : Closed e1106465316890 ∧ code e1106465316890 = 5504511827994 := by decide
theorem cert_e1106465316890 : check e1106465316890 [[]] .width = true := by decide
def e1106465316982 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1106465316982 : Closed e1106465316982 ∧ code e1106465316982 = 5504511828086 := by decide
theorem cert_e1106465316982 : check e1106465316982 [[]] .width = true := by decide
def e1106465317226 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1106465317226 : Closed e1106465317226 ∧ code e1106465317226 = 5504511828330 := by decide
theorem cert_e1106465317226 : check e1106465317226 [[]] .width = true := by decide
def e1106465317274 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1106465317274 : Closed e1106465317274 ∧ code e1106465317274 = 5504511828378 := by decide
theorem cert_e1106465317274 : check e1106465317274 [[]] .width = true := by decide
def e1106465456326 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1106465456326 : Closed e1106465456326 ∧ code e1106465456326 = 5504511967430 := by decide
theorem cert_e1106465456326 : check e1106465456326 [[]] .width = true := by decide
def e1106465456854 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1106465456854 : Closed e1106465456854 ∧ code e1106465456854 = 5504511967958 := by decide
theorem cert_e1106465456854 : check e1106465456854 [[]] .width = true := by decide
def e1106465456858 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1106465456858 : Closed e1106465456858 ∧ code e1106465456858 = 5504511967962 := by decide
theorem cert_e1106465456858 : check e1106465456858 [[]] .width = true := by decide
def e1106465456874 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1106465456874 : Closed e1106465456874 ∧ code e1106465456874 = 5504511967978 := by decide
theorem cert_e1106465456874 : check e1106465456874 [[]] .width = true := by decide
def e1106465456950 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1106465456950 : Closed e1106465456950 ∧ code e1106465456950 = 5504511968054 := by decide
theorem cert_e1106465456950 : check e1106465456950 [[]] .width = true := by decide
def e1106465456954 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1106465456954 : Closed e1106465456954 ∧ code e1106465456954 = 5504511968058 := by decide
theorem cert_e1106465456954 : check e1106465456954 [[]] .width = true := by decide
def e1106465457038 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1106465457038 : Closed e1106465457038 ∧ code e1106465457038 = 5504511968142 := by decide
theorem cert_e1106465457038 : check e1106465457038 [[]] .width = true := by decide
def e1106465457050 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1106465457050 : Closed e1106465457050 ∧ code e1106465457050 = 5504511968154 := by decide
theorem cert_e1106465457050 : check e1106465457050 [[]] .width = true := by decide
def e1106465458970 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1106465458970 : Closed e1106465458970 ∧ code e1106465458970 = 5504511970074 := by decide
theorem cert_e1106465458970 : check e1106465458970 [[]] .width = true := by decide
def e1106465459014 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1106465459014 : Closed e1106465459014 ∧ code e1106465459014 = 5504511970118 := by decide
theorem cert_e1106465459014 : check e1106465459014 [[]] .width = true := by decide
def e1106465459254 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1106465459254 : Closed e1106465459254 ∧ code e1106465459254 = 5504511970358 := by decide
theorem cert_e1106465459254 : check e1106465459254 [[]] .width = true := by decide
end Blc.Floor42
