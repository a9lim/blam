import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211187450822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211187450822 : Closed e1211187450822 ∧ code e1211187450822 = 5609233961926 := by decide
theorem cert_e1211187450822 : check e1211187450822 [[],[]] .smaller = true := by decide
def e1211187450846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211187450846 : Closed e1211187450846 ∧ code e1211187450846 = 5609233961950 := by decide
theorem cert_e1211187450846 : check e1211187450846 [[],[]] .three = true := by decide
def e1211187450850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211187450850 : Closed e1211187450850 ∧ code e1211187450850 = 5609233961954 := by decide
theorem cert_e1211187450850 : check e1211187450850 [[],[]] .three = true := by decide
def e1211187450862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211187450862 : Closed e1211187450862 ∧ code e1211187450862 = 5609233961966 := by decide
theorem cert_e1211187450862 : check e1211187450862 [[],[]] .three = true := by decide
def e1211187451966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e1211187451966 : Closed e1211187451966 ∧ code e1211187451966 = 5609233963070 := by decide
theorem cert_e1211187451966 : check e1211187451966 [[],[]] .smaller = true := by decide
def e1211187452382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211187452382 : Closed e1211187452382 ∧ code e1211187452382 = 5609233963486 := by decide
theorem cert_e1211187452382 : check e1211187452382 [[],[]] .three = true := by decide
def e1211187452386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211187452386 : Closed e1211187452386 ∧ code e1211187452386 = 5609233963490 := by decide
theorem cert_e1211187452386 : check e1211187452386 [[],[]] .smaller = true := by decide
def e1211187452398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211187452398 : Closed e1211187452398 ∧ code e1211187452398 = 5609233963502 := by decide
theorem cert_e1211187452398 : check e1211187452398 [[],[]] .smaller = true := by decide
def e1211187452406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211187452406 : Closed e1211187452406 ∧ code e1211187452406 = 5609233963510 := by decide
theorem cert_e1211187452406 : check e1211187452406 [[],[]] .three = true := by decide
def e1211187452958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211187452958 : Closed e1211187452958 ∧ code e1211187452958 = 5609233964062 := by decide
theorem cert_e1211187452958 : check e1211187452958 [[],[]] .smaller = true := by decide
def e1211187452982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187452982 : Closed e1211187452982 ∧ code e1211187452982 = 5609233964086 := by decide
theorem cert_e1211187452982 : check e1211187452982 [[],[]] .smaller = true := by decide
def e1211187452986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187452986 : Closed e1211187452986 ∧ code e1211187452986 = 5609233964090 := by decide
theorem cert_e1211187452986 : check e1211187452986 [[],[]] .smaller = true := by decide
def e1211187453126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211187453126 : Closed e1211187453126 ∧ code e1211187453126 = 5609233964230 := by decide
theorem cert_e1211187453126 : check e1211187453126 [[],[]] .smaller = true := by decide
def e1211187453150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211187453150 : Closed e1211187453150 ∧ code e1211187453150 = 5609233964254 := by decide
theorem cert_e1211187453150 : check e1211187453150 [[],[]] .three = true := by decide
def e1211187453154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211187453154 : Closed e1211187453154 ∧ code e1211187453154 = 5609233964258 := by decide
theorem cert_e1211187453154 : check e1211187453154 [[],[]] .smaller = true := by decide
def e1211187453166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187453166 : Closed e1211187453166 ∧ code e1211187453166 = 5609233964270 := by decide
theorem cert_e1211187453166 : check e1211187453166 [[],[]] .smaller = true := by decide
def e1211187453174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187453174 : Closed e1211187453174 ∧ code e1211187453174 = 5609233964278 := by decide
theorem cert_e1211187453174 : check e1211187453174 [[],[]] .smaller = true := by decide
def e1211187453178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211187453178 : Closed e1211187453178 ∧ code e1211187453178 = 5609233964282 := by decide
theorem cert_e1211187453178 : check e1211187453178 [[],[]] .three = true := by decide
def e1211187453454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211187453454 : Closed e1211187453454 ∧ code e1211187453454 = 5609233964558 := by decide
theorem cert_e1211187453454 : check e1211187453454 [[],[]] .three = true := by decide
def e1211187453466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187453466 : Closed e1211187453466 ∧ code e1211187453466 = 5609233964570 := by decide
theorem cert_e1211187453466 : check e1211187453466 [[],[]] .three = true := by decide
def e1211187453502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 4)))))))))
theorem wire_e1211187453502 : Closed e1211187453502 ∧ code e1211187453502 = 5609233964606 := by decide
theorem cert_e1211187453502 : check e1211187453502 [[],[]] .three = true := by decide
def e1211187453538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211187453538 : Closed e1211187453538 ∧ code e1211187453538 = 5609233964642 := by decide
theorem cert_e1211187453538 : check e1211187453538 [[],[]] .three = true := by decide
def e1211187453550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187453550 : Closed e1211187453550 ∧ code e1211187453550 = 5609233964654 := by decide
theorem cert_e1211187453550 : check e1211187453550 [[],[]] .three = true := by decide
def e1211187453558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187453558 : Closed e1211187453558 ∧ code e1211187453558 = 5609233964662 := by decide
theorem cert_e1211187453558 : check e1211187453558 [[],[]] .three = true := by decide
def e1211187453562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187453562 : Closed e1211187453562 ∧ code e1211187453562 = 5609233964666 := by decide
theorem cert_e1211187453562 : check e1211187453562 [[],[]] .three = true := by decide
def e1211187454198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211187454198 : Closed e1211187454198 ∧ code e1211187454198 = 5609233965302 := by decide
theorem cert_e1211187454198 : check e1211187454198 [[],[]] .smaller = true := by decide
def e1211187454390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211187454390 : Closed e1211187454390 ∧ code e1211187454390 = 5609233965494 := by decide
theorem cert_e1211187454390 : check e1211187454390 [[],[]] .smaller = true := by decide
def e1211187454394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e1211187454394 : Closed e1211187454394 ∧ code e1211187454394 = 5609233965498 := by decide
theorem cert_e1211187454394 : check e1211187454394 [[],[]] .smaller = true := by decide
def e1211187454422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211187454422 : Closed e1211187454422 ∧ code e1211187454422 = 5609233965526 := by decide
theorem cert_e1211187454422 : check e1211187454422 [[],[]] .smaller = true := by decide
def e1211187454442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e1211187454442 : Closed e1211187454442 ∧ code e1211187454442 = 5609233965546 := by decide
theorem cert_e1211187454442 : check e1211187454442 [[],[]] .smaller = true := by decide
def e1211187454582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187454582 : Closed e1211187454582 ∧ code e1211187454582 = 5609233965686 := by decide
theorem cert_e1211187454582 : check e1211187454582 [[],[]] .smaller = true := by decide
def e1211187454774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187454774 : Closed e1211187454774 ∧ code e1211187454774 = 5609233965878 := by decide
theorem cert_e1211187454774 : check e1211187454774 [[],[]] .smaller = true := by decide
def e1211187454778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187454778 : Closed e1211187454778 ∧ code e1211187454778 = 5609233965882 := by decide
theorem cert_e1211187454778 : check e1211187454778 [[],[]] .smaller = true := by decide
def e1211187454862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211187454862 : Closed e1211187454862 ∧ code e1211187454862 = 5609233965966 := by decide
theorem cert_e1211187454862 : check e1211187454862 [[],[]] .smaller = true := by decide
def e1211187454874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187454874 : Closed e1211187454874 ∧ code e1211187454874 = 5609233965978 := by decide
theorem cert_e1211187454874 : check e1211187454874 [[],[]] .smaller = true := by decide
def e1211187454942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211187454942 : Closed e1211187454942 ∧ code e1211187454942 = 5609233966046 := by decide
theorem cert_e1211187454942 : check e1211187454942 [[],[]] .three = true := by decide
def e1211187454958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211187454958 : Closed e1211187454958 ∧ code e1211187454958 = 5609233966062 := by decide
theorem cert_e1211187454958 : check e1211187454958 [[],[]] .three = true := by decide
def e1211187455542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211187455542 : Closed e1211187455542 ∧ code e1211187455542 = 5609233966646 := by decide
theorem cert_e1211187455542 : check e1211187455542 [[],[]] .smaller = true := by decide
def e1211187455546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211187455546 : Closed e1211187455546 ∧ code e1211187455546 = 5609233966650 := by decide
theorem cert_e1211187455546 : check e1211187455546 [[],[]] .smaller = true := by decide
def e1211187455630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211187455630 : Closed e1211187455630 ∧ code e1211187455630 = 5609233966734 := by decide
theorem cert_e1211187455630 : check e1211187455630 [[],[]] .smaller = true := by decide
def e1211187455686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211187455686 : Closed e1211187455686 ∧ code e1211187455686 = 5609233966790 := by decide
theorem cert_e1211187455686 : check e1211187455686 [[],[]] .smaller = true := by decide
def e1211187455710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211187455710 : Closed e1211187455710 ∧ code e1211187455710 = 5609233966814 := by decide
theorem cert_e1211187455710 : check e1211187455710 [[],[]] .three = true := by decide
def e1211187455734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211187455734 : Closed e1211187455734 ∧ code e1211187455734 = 5609233966838 := by decide
theorem cert_e1211187455734 : check e1211187455734 [[],[]] .three = true := by decide
def e1211187455766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211187455766 : Closed e1211187455766 ∧ code e1211187455766 = 5609233966870 := by decide
theorem cert_e1211187455766 : check e1211187455766 [[],[]] .smaller = true := by decide
def e1211187455770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211187455770 : Closed e1211187455770 ∧ code e1211187455770 = 5609233966874 := by decide
theorem cert_e1211187455770 : check e1211187455770 [[],[]] .smaller = true := by decide
def e1211187455814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211187455814 : Closed e1211187455814 ∧ code e1211187455814 = 5609233966918 := by decide
theorem cert_e1211187455814 : check e1211187455814 [[],[]] .smaller = true := by decide
def e1211187455838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211187455838 : Closed e1211187455838 ∧ code e1211187455838 = 5609233966942 := by decide
theorem cert_e1211187455838 : check e1211187455838 [[],[]] .three = true := by decide
def e1211187455842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211187455842 : Closed e1211187455842 ∧ code e1211187455842 = 5609233966946 := by decide
theorem cert_e1211187455842 : check e1211187455842 [[],[]] .smaller = true := by decide
def e1211187455854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211187455854 : Closed e1211187455854 ∧ code e1211187455854 = 5609233966958 := by decide
theorem cert_e1211187455854 : check e1211187455854 [[],[]] .smaller = true := by decide
def e1211187455862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211187455862 : Closed e1211187455862 ∧ code e1211187455862 = 5609233966966 := by decide
theorem cert_e1211187455862 : check e1211187455862 [[],[]] .smaller = true := by decide
def e1211187455866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211187455866 : Closed e1211187455866 ∧ code e1211187455866 = 5609233966970 := by decide
theorem cert_e1211187455866 : check e1211187455866 [[],[]] .three = true := by decide
def e1211187455926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211187455926 : Closed e1211187455926 ∧ code e1211187455926 = 5609233967030 := by decide
theorem cert_e1211187455926 : check e1211187455926 [[],[]] .smaller = true := by decide
def e1211187455958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211187455958 : Closed e1211187455958 ∧ code e1211187455958 = 5609233967062 := by decide
theorem cert_e1211187455958 : check e1211187455958 [[],[]] .three = true := by decide
def e1211187455962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211187455962 : Closed e1211187455962 ∧ code e1211187455962 = 5609233967066 := by decide
theorem cert_e1211187455962 : check e1211187455962 [[],[]] .three = true := by decide
def e1211187456110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211187456110 : Closed e1211187456110 ∧ code e1211187456110 = 5609233967214 := by decide
theorem cert_e1211187456110 : check e1211187456110 [[],[]] .smaller = true := by decide
def e1211187456122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211187456122 : Closed e1211187456122 ∧ code e1211187456122 = 5609233967226 := by decide
theorem cert_e1211187456122 : check e1211187456122 [[],[]] .smaller = true := by decide
def e1211187456398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211187456398 : Closed e1211187456398 ∧ code e1211187456398 = 5609233967502 := by decide
theorem cert_e1211187456398 : check e1211187456398 [[],[]] .smaller = true := by decide
def e1211187456454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211187456454 : Closed e1211187456454 ∧ code e1211187456454 = 5609233967558 := by decide
theorem cert_e1211187456454 : check e1211187456454 [[],[]] .smaller = true := by decide
def e1211187456478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211187456478 : Closed e1211187456478 ∧ code e1211187456478 = 5609233967582 := by decide
theorem cert_e1211187456478 : check e1211187456478 [[],[]] .three = true := by decide
def e1211187456502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211187456502 : Closed e1211187456502 ∧ code e1211187456502 = 5609233967606 := by decide
theorem cert_e1211187456502 : check e1211187456502 [[],[]] .three = true := by decide
def e1211187457054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211187457054 : Closed e1211187457054 ∧ code e1211187457054 = 5609233968158 := by decide
theorem cert_e1211187457054 : check e1211187457054 [[],[]] .smaller = true := by decide
def e1211187457078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187457078 : Closed e1211187457078 ∧ code e1211187457078 = 5609233968182 := by decide
theorem cert_e1211187457078 : check e1211187457078 [[],[]] .smaller = true := by decide
def e1211187457082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187457082 : Closed e1211187457082 ∧ code e1211187457082 = 5609233968186 := by decide
theorem cert_e1211187457082 : check e1211187457082 [[],[]] .smaller = true := by decide
def e1211187457222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211187457222 : Closed e1211187457222 ∧ code e1211187457222 = 5609233968326 := by decide
theorem cert_e1211187457222 : check e1211187457222 [[],[]] .smaller = true := by decide
def e1211187457246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211187457246 : Closed e1211187457246 ∧ code e1211187457246 = 5609233968350 := by decide
theorem cert_e1211187457246 : check e1211187457246 [[],[]] .three = true := by decide
def e1211187457250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211187457250 : Closed e1211187457250 ∧ code e1211187457250 = 5609233968354 := by decide
theorem cert_e1211187457250 : check e1211187457250 [[],[]] .smaller = true := by decide
def e1211187457262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187457262 : Closed e1211187457262 ∧ code e1211187457262 = 5609233968366 := by decide
theorem cert_e1211187457262 : check e1211187457262 [[],[]] .smaller = true := by decide
def e1211187457270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187457270 : Closed e1211187457270 ∧ code e1211187457270 = 5609233968374 := by decide
theorem cert_e1211187457270 : check e1211187457270 [[],[]] .smaller = true := by decide
def e1211187457274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211187457274 : Closed e1211187457274 ∧ code e1211187457274 = 5609233968378 := by decide
theorem cert_e1211187457274 : check e1211187457274 [[],[]] .three = true := by decide
def e1211187457598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211187457598 : Closed e1211187457598 ∧ code e1211187457598 = 5609233968702 := by decide
theorem cert_e1211187457598 : check e1211187457598 [[],[]] .three = true := by decide
def e1211187457654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187457654 : Closed e1211187457654 ∧ code e1211187457654 = 5609233968758 := by decide
theorem cert_e1211187457654 : check e1211187457654 [[],[]] .smaller = true := by decide
def e1211187457822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211187457822 : Closed e1211187457822 ∧ code e1211187457822 = 5609233968926 := by decide
theorem cert_e1211187457822 : check e1211187457822 [[],[]] .three = true := by decide
def e1211187457846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187457846 : Closed e1211187457846 ∧ code e1211187457846 = 5609233968950 := by decide
theorem cert_e1211187457846 : check e1211187457846 [[],[]] .three = true := by decide
def e1211187457850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187457850 : Closed e1211187457850 ∧ code e1211187457850 = 5609233968954 := by decide
theorem cert_e1211187457850 : check e1211187457850 [[],[]] .three = true := by decide
def e1211187458166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211187458166 : Closed e1211187458166 ∧ code e1211187458166 = 5609233969270 := by decide
theorem cert_e1211187458166 : check e1211187458166 [[],[]] .three = true := by decide
def e1211187458170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211187458170 : Closed e1211187458170 ∧ code e1211187458170 = 5609233969274 := by decide
theorem cert_e1211187458170 : check e1211187458170 [[],[]] .three = true := by decide
def e1211187458262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211187458262 : Closed e1211187458262 ∧ code e1211187458262 = 5609233969366 := by decide
theorem cert_e1211187458262 : check e1211187458262 [[],[]] .three = true := by decide
def e1211187458358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187458358 : Closed e1211187458358 ∧ code e1211187458358 = 5609233969462 := by decide
theorem cert_e1211187458358 : check e1211187458358 [[],[]] .three = true := by decide
def e1211187458362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187458362 : Closed e1211187458362 ∧ code e1211187458362 = 5609233969466 := by decide
theorem cert_e1211187458362 : check e1211187458362 [[],[]] .three = true := by decide
def e1211187458446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211187458446 : Closed e1211187458446 ∧ code e1211187458446 = 5609233969550 := by decide
theorem cert_e1211187458446 : check e1211187458446 [[],[]] .three = true := by decide
def e1211187458502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211187458502 : Closed e1211187458502 ∧ code e1211187458502 = 5609233969606 := by decide
theorem cert_e1211187458502 : check e1211187458502 [[],[]] .three = true := by decide
def e1211187458526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211187458526 : Closed e1211187458526 ∧ code e1211187458526 = 5609233969630 := by decide
theorem cert_e1211187458526 : check e1211187458526 [[],[]] .three = true := by decide
def e1211187458542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211187458542 : Closed e1211187458542 ∧ code e1211187458542 = 5609233969646 := by decide
theorem cert_e1211187458542 : check e1211187458542 [[],[]] .three = true := by decide
def e1211187458550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211187458550 : Closed e1211187458550 ∧ code e1211187458550 = 5609233969654 := by decide
theorem cert_e1211187458550 : check e1211187458550 [[],[]] .three = true := by decide
def e1211187458838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211187458838 : Closed e1211187458838 ∧ code e1211187458838 = 5609233969942 := by decide
theorem cert_e1211187458838 : check e1211187458838 [[],[]] .three = true := by decide
def e1211187458914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211187458914 : Closed e1211187458914 ∧ code e1211187458914 = 5609233970018 := by decide
theorem cert_e1211187458914 : check e1211187458914 [[],[]] .three = true := by decide
def e1211187458926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211187458926 : Closed e1211187458926 ∧ code e1211187458926 = 5609233970030 := by decide
theorem cert_e1211187458926 : check e1211187458926 [[],[]] .three = true := by decide
def e1211187458934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211187458934 : Closed e1211187458934 ∧ code e1211187458934 = 5609233970038 := by decide
theorem cert_e1211187458934 : check e1211187458934 [[],[]] .three = true := by decide
def e1211187458954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211187458954 : Closed e1211187458954 ∧ code e1211187458954 = 5609233970058 := by decide
theorem cert_e1211187458954 : check e1211187458954 [[],[]] .three = true := by decide
def e1211187458978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211187458978 : Closed e1211187458978 ∧ code e1211187458978 = 5609233970082 := by decide
theorem cert_e1211187458978 : check e1211187458978 [[],[]] .three = true := by decide
def e1211187458990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211187458990 : Closed e1211187458990 ∧ code e1211187458990 = 5609233970094 := by decide
theorem cert_e1211187458990 : check e1211187458990 [[],[]] .three = true := by decide
def e1211187458998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e1211187458998 : Closed e1211187458998 ∧ code e1211187458998 = 5609233970102 := by decide
theorem cert_e1211187458998 : check e1211187458998 [[],[]] .three = true := by decide
def e1211187459002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211187459002 : Closed e1211187459002 ∧ code e1211187459002 = 5609233970106 := by decide
theorem cert_e1211187459002 : check e1211187459002 [[],[]] .three = true := by decide
def e1211187459030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211187459030 : Closed e1211187459030 ∧ code e1211187459030 = 5609233970134 := by decide
theorem cert_e1211187459030 : check e1211187459030 [[],[]] .three = true := by decide
def e1211187459034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211187459034 : Closed e1211187459034 ∧ code e1211187459034 = 5609233970138 := by decide
theorem cert_e1211187459034 : check e1211187459034 [[],[]] .three = true := by decide
def e1211187459102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211187459102 : Closed e1211187459102 ∧ code e1211187459102 = 5609233970206 := by decide
theorem cert_e1211187459102 : check e1211187459102 [[],[]] .three = true := by decide
def e1211187459298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211187459298 : Closed e1211187459298 ∧ code e1211187459298 = 5609233970402 := by decide
theorem cert_e1211187459298 : check e1211187459298 [[],[]] .three = true := by decide
def e1211187459310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187459310 : Closed e1211187459310 ∧ code e1211187459310 = 5609233970414 := by decide
theorem cert_e1211187459310 : check e1211187459310 [[],[]] .three = true := by decide
def e1211187459318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187459318 : Closed e1211187459318 ∧ code e1211187459318 = 5609233970422 := by decide
theorem cert_e1211187459318 : check e1211187459318 [[],[]] .three = true := by decide
def e1211187459598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211187459598 : Closed e1211187459598 ∧ code e1211187459598 = 5609233970702 := by decide
theorem cert_e1211187459598 : check e1211187459598 [[],[]] .three = true := by decide
def e1211187459610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187459610 : Closed e1211187459610 ∧ code e1211187459610 = 5609233970714 := by decide
theorem cert_e1211187459610 : check e1211187459610 [[],[]] .three = true := by decide
def e1211187459646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211187459646 : Closed e1211187459646 ∧ code e1211187459646 = 5609233970750 := by decide
theorem cert_e1211187459646 : check e1211187459646 [[],[]] .three = true := by decide
def e1211187459682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211187459682 : Closed e1211187459682 ∧ code e1211187459682 = 5609233970786 := by decide
theorem cert_e1211187459682 : check e1211187459682 [[],[]] .three = true := by decide
def e1211187459694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187459694 : Closed e1211187459694 ∧ code e1211187459694 = 5609233970798 := by decide
theorem cert_e1211187459694 : check e1211187459694 [[],[]] .three = true := by decide
def e1211187459702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187459702 : Closed e1211187459702 ∧ code e1211187459702 = 5609233970806 := by decide
theorem cert_e1211187459702 : check e1211187459702 [[],[]] .three = true := by decide
def e1211187459706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187459706 : Closed e1211187459706 ∧ code e1211187459706 = 5609233970810 := by decide
theorem cert_e1211187459706 : check e1211187459706 [[],[]] .three = true := by decide
def e1211187459870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211187459870 : Closed e1211187459870 ∧ code e1211187459870 = 5609233970974 := by decide
theorem cert_e1211187459870 : check e1211187459870 [[],[]] .three = true := by decide
def e1211187459894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187459894 : Closed e1211187459894 ∧ code e1211187459894 = 5609233970998 := by decide
theorem cert_e1211187459894 : check e1211187459894 [[],[]] .three = true := by decide
def e1211187459898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187459898 : Closed e1211187459898 ∧ code e1211187459898 = 5609233971002 := by decide
theorem cert_e1211187459898 : check e1211187459898 [[],[]] .three = true := by decide
def e1211187459982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211187459982 : Closed e1211187459982 ∧ code e1211187459982 = 5609233971086 := by decide
theorem cert_e1211187459982 : check e1211187459982 [[],[]] .three = true := by decide
def e1211187467998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211187467998 : Closed e1211187467998 ∧ code e1211187467998 = 5609233979102 := by decide
theorem cert_e1211187467998 : check e1211187467998 [[],[]] .smaller = true := by decide
def e1211187468022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211187468022 : Closed e1211187468022 ∧ code e1211187468022 = 5609233979126 := by decide
theorem cert_e1211187468022 : check e1211187468022 [[],[]] .smaller = true := by decide
def e1211187468126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211187468126 : Closed e1211187468126 ∧ code e1211187468126 = 5609233979230 := by decide
theorem cert_e1211187468126 : check e1211187468126 [[],[]] .smaller = true := by decide
def e1211187468154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211187468154 : Closed e1211187468154 ∧ code e1211187468154 = 5609233979258 := by decide
theorem cert_e1211187468154 : check e1211187468154 [[],[]] .smaller = true := by decide
def e1211187468246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211187468246 : Closed e1211187468246 ∧ code e1211187468246 = 5609233979350 := by decide
theorem cert_e1211187468246 : check e1211187468246 [[],[]] .smaller = true := by decide
def e1211187468250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211187468250 : Closed e1211187468250 ∧ code e1211187468250 = 5609233979354 := by decide
theorem cert_e1211187468250 : check e1211187468250 [[],[]] .smaller = true := by decide
def e1211187468766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211187468766 : Closed e1211187468766 ∧ code e1211187468766 = 5609233979870 := by decide
theorem cert_e1211187468766 : check e1211187468766 [[],[]] .smaller = true := by decide
def e1211187468790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211187468790 : Closed e1211187468790 ∧ code e1211187468790 = 5609233979894 := by decide
theorem cert_e1211187468790 : check e1211187468790 [[],[]] .smaller = true := by decide
def e1211187469534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187469534 : Closed e1211187469534 ∧ code e1211187469534 = 5609233980638 := by decide
theorem cert_e1211187469534 : check e1211187469534 [[],[]] .smaller = true := by decide
def e1211187469562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187469562 : Closed e1211187469562 ∧ code e1211187469562 = 5609233980666 := by decide
theorem cert_e1211187469562 : check e1211187469562 [[],[]] .smaller = true := by decide
def e1211187469886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211187469886 : Closed e1211187469886 ∧ code e1211187469886 = 5609233980990 := by decide
theorem cert_e1211187469886 : check e1211187469886 [[],[]] .smaller = true := by decide
def e1211187470110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211187470110 : Closed e1211187470110 ∧ code e1211187470110 = 5609233981214 := by decide
theorem cert_e1211187470110 : check e1211187470110 [[],[]] .smaller = true := by decide
def e1211187470134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211187470134 : Closed e1211187470134 ∧ code e1211187470134 = 5609233981238 := by decide
theorem cert_e1211187470134 : check e1211187470134 [[],[]] .smaller = true := by decide
def e1211187470138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211187470138 : Closed e1211187470138 ∧ code e1211187470138 = 5609233981242 := by decide
theorem cert_e1211187470138 : check e1211187470138 [[],[]] .smaller = true := by decide
def e1211187484910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211187484910 : Closed e1211187484910 ∧ code e1211187484910 = 5609233996014 := by decide
theorem cert_e1211187484910 : check e1211187484910 [[],[]] .smaller = true := by decide
def e1211187484918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211187484918 : Closed e1211187484918 ∧ code e1211187484918 = 5609233996022 := by decide
theorem cert_e1211187484918 : check e1211187484918 [[],[]] .smaller = true := by decide
def e1211187485470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211187485470 : Closed e1211187485470 ∧ code e1211187485470 = 5609233996574 := by decide
theorem cert_e1211187485470 : check e1211187485470 [[],[]] .smaller = true := by decide
def e1211187485582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211187485582 : Closed e1211187485582 ∧ code e1211187485582 = 5609233996686 := by decide
theorem cert_e1211187485582 : check e1211187485582 [[],[]] .smaller = true := by decide
def e1211187485790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211187485790 : Closed e1211187485790 ∧ code e1211187485790 = 5609233996894 := by decide
theorem cert_e1211187485790 : check e1211187485790 [[],[]] .three = true := by decide
def e1211187485806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211187485806 : Closed e1211187485806 ∧ code e1211187485806 = 5609233996910 := by decide
theorem cert_e1211187485806 : check e1211187485806 [[],[]] .smaller = true := by decide
def e1211187485818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211187485818 : Closed e1211187485818 ∧ code e1211187485818 = 5609233996922 := by decide
theorem cert_e1211187485818 : check e1211187485818 [[],[]] .smaller = true := by decide
def e1211187485982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211187485982 : Closed e1211187485982 ∧ code e1211187485982 = 5609233997086 := by decide
theorem cert_e1211187485982 : check e1211187485982 [[],[]] .smaller = true := by decide
def e1211187486150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211187486150 : Closed e1211187486150 ∧ code e1211187486150 = 5609233997254 := by decide
theorem cert_e1211187486150 : check e1211187486150 [[],[]] .smaller = true := by decide
def e1211187486174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211187486174 : Closed e1211187486174 ∧ code e1211187486174 = 5609233997278 := by decide
theorem cert_e1211187486174 : check e1211187486174 [[],[]] .three = true := by decide
def e1211187486178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211187486178 : Closed e1211187486178 ∧ code e1211187486178 = 5609233997282 := by decide
theorem cert_e1211187486178 : check e1211187486178 [[],[]] .three = true := by decide
def e1211187486190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211187486190 : Closed e1211187486190 ∧ code e1211187486190 = 5609233997294 := by decide
theorem cert_e1211187486190 : check e1211187486190 [[],[]] .three = true := by decide
def e1211187486262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211187486262 : Closed e1211187486262 ∧ code e1211187486262 = 5609233997366 := by decide
theorem cert_e1211187486262 : check e1211187486262 [[],[]] .smaller = true := by decide
def e1211187486266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211187486266 : Closed e1211187486266 ∧ code e1211187486266 = 5609233997370 := by decide
theorem cert_e1211187486266 : check e1211187486266 [[],[]] .smaller = true := by decide
def e1211187486350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211187486350 : Closed e1211187486350 ∧ code e1211187486350 = 5609233997454 := by decide
theorem cert_e1211187486350 : check e1211187486350 [[],[]] .smaller = true := by decide
def e1211187486406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211187486406 : Closed e1211187486406 ∧ code e1211187486406 = 5609233997510 := by decide
theorem cert_e1211187486406 : check e1211187486406 [[],[]] .smaller = true := by decide
def e1211187486430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211187486430 : Closed e1211187486430 ∧ code e1211187486430 = 5609233997534 := by decide
theorem cert_e1211187486430 : check e1211187486430 [[],[]] .three = true := by decide
def e1211187486454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211187486454 : Closed e1211187486454 ∧ code e1211187486454 = 5609233997558 := by decide
theorem cert_e1211187486454 : check e1211187486454 [[],[]] .three = true := by decide
def e1211187486486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211187486486 : Closed e1211187486486 ∧ code e1211187486486 = 5609233997590 := by decide
theorem cert_e1211187486486 : check e1211187486486 [[],[]] .three = true := by decide
def e1211187486562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211187486562 : Closed e1211187486562 ∧ code e1211187486562 = 5609233997666 := by decide
theorem cert_e1211187486562 : check e1211187486562 [[],[]] .three = true := by decide
def e1211187486574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211187486574 : Closed e1211187486574 ∧ code e1211187486574 = 5609233997678 := by decide
theorem cert_e1211187486574 : check e1211187486574 [[],[]] .three = true := by decide
def e1211187486582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211187486582 : Closed e1211187486582 ∧ code e1211187486582 = 5609233997686 := by decide
theorem cert_e1211187486582 : check e1211187486582 [[],[]] .three = true := by decide
def e1211187488542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211187488542 : Closed e1211187488542 ∧ code e1211187488542 = 5609233999646 := by decide
theorem cert_e1211187488542 : check e1211187488542 [[],[]] .smaller = true := by decide
def e1211187488654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211187488654 : Closed e1211187488654 ∧ code e1211187488654 = 5609233999758 := by decide
theorem cert_e1211187488654 : check e1211187488654 [[],[]] .smaller = true := by decide
def e1211187490942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211187490942 : Closed e1211187490942 ∧ code e1211187490942 = 5609234002046 := by decide
theorem cert_e1211187490942 : check e1211187490942 [[],[]] .three = true := by decide
def e1211187491038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211187491038 : Closed e1211187491038 ∧ code e1211187491038 = 5609234002142 := by decide
theorem cert_e1211187491038 : check e1211187491038 [[],[]] .smaller = true := by decide
def e1211187491066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211187491066 : Closed e1211187491066 ∧ code e1211187491066 = 5609234002170 := by decide
theorem cert_e1211187491066 : check e1211187491066 [[],[]] .smaller = true := by decide
def e1211187491614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211187491614 : Closed e1211187491614 ∧ code e1211187491614 = 5609234002718 := by decide
theorem cert_e1211187491614 : check e1211187491614 [[],[]] .smaller = true := by decide
def e1211187491782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211187491782 : Closed e1211187491782 ∧ code e1211187491782 = 5609234002886 := by decide
theorem cert_e1211187491782 : check e1211187491782 [[],[]] .smaller = true := by decide
def e1211187491806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211187491806 : Closed e1211187491806 ∧ code e1211187491806 = 5609234002910 := by decide
theorem cert_e1211187491806 : check e1211187491806 [[],[]] .three = true := by decide
def e1211187491810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211187491810 : Closed e1211187491810 ∧ code e1211187491810 = 5609234002914 := by decide
theorem cert_e1211187491810 : check e1211187491810 [[],[]] .three = true := by decide
def e1211187491822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211187491822 : Closed e1211187491822 ∧ code e1211187491822 = 5609234002926 := by decide
theorem cert_e1211187491822 : check e1211187491822 [[],[]] .three = true := by decide
def e1211187492974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187492974 : Closed e1211187492974 ∧ code e1211187492974 = 5609234004078 := by decide
theorem cert_e1211187492974 : check e1211187492974 [[],[]] .smaller = true := by decide
def e1211187492986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187492986 : Closed e1211187492986 ∧ code e1211187492986 = 5609234004090 := by decide
theorem cert_e1211187492986 : check e1211187492986 [[],[]] .smaller = true := by decide
def e1211187493262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211187493262 : Closed e1211187493262 ∧ code e1211187493262 = 5609234004366 := by decide
theorem cert_e1211187493262 : check e1211187493262 [[],[]] .smaller = true := by decide
def e1211187493318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211187493318 : Closed e1211187493318 ∧ code e1211187493318 = 5609234004422 := by decide
theorem cert_e1211187493318 : check e1211187493318 [[],[]] .smaller = true := by decide
end Blc.Floor42
