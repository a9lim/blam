import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211181247598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e1211181247598 : Closed e1211181247598 ∧ code e1211181247598 = 5609227758702 := by decide
theorem cert_e1211181247598 : check e1211181247598 [[],[]] .smaller = true := by decide
def e1211181247610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e1211181247610 : Closed e1211181247610 ∧ code e1211181247610 = 5609227758714 := by decide
theorem cert_e1211181247610 : check e1211181247610 [[],[]] .smaller = true := by decide
def e1211181247774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e1211181247774 : Closed e1211181247774 ∧ code e1211181247774 = 5609227758878 := by decide
theorem cert_e1211181247774 : check e1211181247774 [[],[]] .smaller = true := by decide
def e1211181247870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 5))))))))))
theorem wire_e1211181247870 : Closed e1211181247870 ∧ code e1211181247870 = 5609227758974 := by decide
theorem cert_e1211181247870 : check e1211181247870 [[],[]] .three = true := by decide
def e1211181247934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e1211181247934 : Closed e1211181247934 ∧ code e1211181247934 = 5609227759038 := by decide
theorem cert_e1211181247934 : check e1211181247934 [[],[]] .smaller = true := by decide
def e1211181247942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e1211181247942 : Closed e1211181247942 ∧ code e1211181247942 = 5609227759046 := by decide
theorem cert_e1211181247942 : check e1211181247942 [[],[]] .smaller = true := by decide
def e1211181247990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e1211181247990 : Closed e1211181247990 ∧ code e1211181247990 = 5609227759094 := by decide
theorem cert_e1211181247990 : check e1211181247990 [[],[]] .smaller = true := by decide
def e1211181247994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 5)) (.var 0))))))))))
theorem wire_e1211181247994 : Closed e1211181247994 ∧ code e1211181247994 = 5609227759098 := by decide
theorem cert_e1211181247994 : check e1211181247994 [[],[]] .three = true := by decide
def e1211181248190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e1211181248190 : Closed e1211181248190 ∧ code e1211181248190 = 5609227759294 := by decide
theorem cert_e1211181248190 : check e1211181248190 [[],[]] .smaller = true := by decide
def e1211181248250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e1211181248250 : Closed e1211181248250 ∧ code e1211181248250 = 5609227759354 := by decide
theorem cert_e1211181248250 : check e1211181248250 [[],[]] .smaller = true := by decide
def e1211181248282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))))
theorem wire_e1211181248282 : Closed e1211181248282 ∧ code e1211181248282 = 5609227759386 := by decide
theorem cert_e1211181248282 : check e1211181248282 [[],[]] .smaller = true := by decide
def e1211181248326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))))
theorem wire_e1211181248326 : Closed e1211181248326 ∧ code e1211181248326 = 5609227759430 := by decide
theorem cert_e1211181248326 : check e1211181248326 [[],[]] .smaller = true := by decide
def e1211181248470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e1211181248470 : Closed e1211181248470 ∧ code e1211181248470 = 5609227759574 := by decide
theorem cert_e1211181248470 : check e1211181248470 [[],[]] .smaller = true := by decide
def e1211181248474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e1211181248474 : Closed e1211181248474 ∧ code e1211181248474 = 5609227759578 := by decide
theorem cert_e1211181248474 : check e1211181248474 [[],[]] .smaller = true := by decide
def e1211181248490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 5) (.var 0)) (.var 0))))))))))
theorem wire_e1211181248490 : Closed e1211181248490 ∧ code e1211181248490 = 5609227759594 := by decide
theorem cert_e1211181248490 : check e1211181248490 [[],[]] .three = true := by decide
def e1211181249310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e1211181249310 : Closed e1211181249310 ∧ code e1211181249310 = 5609227760414 := by decide
theorem cert_e1211181249310 : check e1211181249310 [[],[]] .smaller = true := by decide
def e1211181249406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 5)))))))))))
theorem wire_e1211181249406 : Closed e1211181249406 ∧ code e1211181249406 = 5609227760510 := by decide
theorem cert_e1211181249406 : check e1211181249406 [[],[]] .three = true := by decide
def e1211181249470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211181249470 : Closed e1211181249470 ∧ code e1211181249470 = 5609227760574 := by decide
theorem cert_e1211181249470 : check e1211181249470 [[],[]] .smaller = true := by decide
def e1211181249478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e1211181249478 : Closed e1211181249478 ∧ code e1211181249478 = 5609227760582 := by decide
theorem cert_e1211181249478 : check e1211181249478 [[],[]] .smaller = true := by decide
def e1211181249526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211181249526 : Closed e1211181249526 ∧ code e1211181249526 = 5609227760630 := by decide
theorem cert_e1211181249526 : check e1211181249526 [[],[]] .smaller = true := by decide
def e1211181249530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 5) (.var 0)))))))))))
theorem wire_e1211181249530 : Closed e1211181249530 ∧ code e1211181249530 = 5609227760634 := by decide
theorem cert_e1211181249530 : check e1211181249530 [[],[]] .three = true := by decide
def e1211181251006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211181251006 : Closed e1211181251006 ∧ code e1211181251006 = 5609227762110 := by decide
theorem cert_e1211181251006 : check e1211181251006 [[],[]] .smaller = true := by decide
def e1211181251066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211181251066 : Closed e1211181251066 ∧ code e1211181251066 = 5609227762170 := by decide
theorem cert_e1211181251066 : check e1211181251066 [[],[]] .smaller = true := by decide
def e1211181251782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))))
theorem wire_e1211181251782 : Closed e1211181251782 ∧ code e1211181251782 = 5609227762886 := by decide
theorem cert_e1211181251782 : check e1211181251782 [[],[]] .smaller = true := by decide
def e1211181252406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211181252406 : Closed e1211181252406 ∧ code e1211181252406 = 5609227763510 := by decide
theorem cert_e1211181252406 : check e1211181252406 [[],[]] .smaller = true := by decide
def e1211181252410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211181252410 : Closed e1211181252410 ∧ code e1211181252410 = 5609227763514 := by decide
theorem cert_e1211181252410 : check e1211181252410 [[],[]] .smaller = true := by decide
def e1211181252506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 5) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211181252506 : Closed e1211181252506 ∧ code e1211181252506 = 5609227763610 := by decide
theorem cert_e1211181252506 : check e1211181252506 [[],[]] .three = true := by decide
def e1211181274678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e1211181274678 : Closed e1211181274678 ∧ code e1211181274678 = 5609227785782 := by decide
theorem cert_e1211181274678 : check e1211181274678 [[],[]] .smaller = true := by decide
def e1211181274682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e1211181274682 : Closed e1211181274682 ∧ code e1211181274682 = 5609227785786 := by decide
theorem cert_e1211181274682 : check e1211181274682 [[],[]] .smaller = true := by decide
def e1211181274766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e1211181274766 : Closed e1211181274766 ∧ code e1211181274766 = 5609227785870 := by decide
theorem cert_e1211181274766 : check e1211181274766 [[],[]] .smaller = true := by decide
def e1211181274814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e1211181274814 : Closed e1211181274814 ∧ code e1211181274814 = 5609227785918 := by decide
theorem cert_e1211181274814 : check e1211181274814 [[],[]] .smaller = true := by decide
def e1211181274822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e1211181274822 : Closed e1211181274822 ∧ code e1211181274822 = 5609227785926 := by decide
theorem cert_e1211181274822 : check e1211181274822 [[],[]] .smaller = true := by decide
def e1211181274874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e1211181274874 : Closed e1211181274874 ∧ code e1211181274874 = 5609227785978 := by decide
theorem cert_e1211181274874 : check e1211181274874 [[],[]] .smaller = true := by decide
def e1211181274906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))))
theorem wire_e1211181274906 : Closed e1211181274906 ∧ code e1211181274906 = 5609227786010 := by decide
theorem cert_e1211181274906 : check e1211181274906 [[],[]] .smaller = true := by decide
def e1211181274950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))))
theorem wire_e1211181274950 : Closed e1211181274950 ∧ code e1211181274950 = 5609227786054 := by decide
theorem cert_e1211181274950 : check e1211181274950 [[],[]] .smaller = true := by decide
def e1211181275114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e1211181275114 : Closed e1211181275114 ∧ code e1211181275114 = 5609227786218 := by decide
theorem cert_e1211181275114 : check e1211181275114 [[],[]] .smaller = true := by decide
def e1211181275534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e1211181275534 : Closed e1211181275534 ∧ code e1211181275534 = 5609227786638 := by decide
theorem cert_e1211181275534 : check e1211181275534 [[],[]] .smaller = true := by decide
def e1211181275582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211181275582 : Closed e1211181275582 ∧ code e1211181275582 = 5609227786686 := by decide
theorem cert_e1211181275582 : check e1211181275582 [[],[]] .smaller = true := by decide
def e1211181275590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e1211181275590 : Closed e1211181275590 ∧ code e1211181275590 = 5609227786694 := by decide
theorem cert_e1211181275590 : check e1211181275590 [[],[]] .smaller = true := by decide
def e1211181275642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211181275642 : Closed e1211181275642 ∧ code e1211181275642 = 5609227786746 := by decide
theorem cert_e1211181275642 : check e1211181275642 [[],[]] .smaller = true := by decide
def e1211181276358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))))
theorem wire_e1211181276358 : Closed e1211181276358 ∧ code e1211181276358 = 5609227787462 := by decide
theorem cert_e1211181276358 : check e1211181276358 [[],[]] .smaller = true := by decide
def e1211181277082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211181277082 : Closed e1211181277082 ∧ code e1211181277082 = 5609227788186 := by decide
theorem cert_e1211181277082 : check e1211181277082 [[],[]] .smaller = true := by decide
def e1211181295022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211181295022 : Closed e1211181295022 ∧ code e1211181295022 = 5609227806126 := by decide
theorem cert_e1211181295022 : check e1211181295022 [[],[]] .smaller = true := by decide
def e1211181295030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211181295030 : Closed e1211181295030 ∧ code e1211181295030 = 5609227806134 := by decide
theorem cert_e1211181295030 : check e1211181295030 [[],[]] .smaller = true := by decide
def e1211181295034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211181295034 : Closed e1211181295034 ∧ code e1211181295034 = 5609227806138 := by decide
theorem cert_e1211181295034 : check e1211181295034 [[],[]] .smaller = true := by decide
def e1211181295062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211181295062 : Closed e1211181295062 ∧ code e1211181295062 = 5609227806166 := by decide
theorem cert_e1211181295062 : check e1211181295062 [[],[]] .smaller = true := by decide
def e1211181295066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211181295066 : Closed e1211181295066 ∧ code e1211181295066 = 5609227806170 := by decide
theorem cert_e1211181295066 : check e1211181295066 [[],[]] .smaller = true := by decide
def e1211181295082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211181295082 : Closed e1211181295082 ∧ code e1211181295082 = 5609227806186 := by decide
theorem cert_e1211181295082 : check e1211181295082 [[],[]] .smaller = true := by decide
def e1211181295214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211181295214 : Closed e1211181295214 ∧ code e1211181295214 = 5609227806318 := by decide
theorem cert_e1211181295214 : check e1211181295214 [[],[]] .smaller = true := by decide
def e1211181295222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211181295222 : Closed e1211181295222 ∧ code e1211181295222 = 5609227806326 := by decide
theorem cert_e1211181295222 : check e1211181295222 [[],[]] .smaller = true := by decide
def e1211181295226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211181295226 : Closed e1211181295226 ∧ code e1211181295226 = 5609227806330 := by decide
theorem cert_e1211181295226 : check e1211181295226 [[],[]] .smaller = true := by decide
def e1211181295414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211181295414 : Closed e1211181295414 ∧ code e1211181295414 = 5609227806518 := by decide
theorem cert_e1211181295414 : check e1211181295414 [[],[]] .smaller = true := by decide
def e1211181295418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211181295418 : Closed e1211181295418 ∧ code e1211181295418 = 5609227806522 := by decide
theorem cert_e1211181295418 : check e1211181295418 [[],[]] .smaller = true := by decide
def e1211181295514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211181295514 : Closed e1211181295514 ∧ code e1211181295514 = 5609227806618 := by decide
theorem cert_e1211181295514 : check e1211181295514 [[],[]] .smaller = true := by decide
def e1211181298390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211181298390 : Closed e1211181298390 ∧ code e1211181298390 = 5609227809494 := by decide
theorem cert_e1211181298390 : check e1211181298390 [[],[]] .three = true := by decide
def e1211181298394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211181298394 : Closed e1211181298394 ∧ code e1211181298394 = 5609227809498 := by decide
theorem cert_e1211181298394 : check e1211181298394 [[],[]] .three = true := by decide
def e1211181298410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211181298410 : Closed e1211181298410 ∧ code e1211181298410 = 5609227809514 := by decide
theorem cert_e1211181298410 : check e1211181298410 [[],[]] .three = true := by decide
def e1211181298486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211181298486 : Closed e1211181298486 ∧ code e1211181298486 = 5609227809590 := by decide
theorem cert_e1211181298486 : check e1211181298486 [[],[]] .three = true := by decide
def e1211181298490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211181298490 : Closed e1211181298490 ∧ code e1211181298490 = 5609227809594 := by decide
theorem cert_e1211181298490 : check e1211181298490 [[],[]] .three = true := by decide
def e1211181298586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211181298586 : Closed e1211181298586 ∧ code e1211181298586 = 5609227809690 := by decide
theorem cert_e1211181298586 : check e1211181298586 [[],[]] .three = true := by decide
def e1211182181086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211182181086 : Closed e1211182181086 ∧ code e1211182181086 = 5609228692190 := by decide
theorem cert_e1211182181086 : check e1211182181086 [[],[]] .smaller = true := by decide
def e1211182181110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211182181110 : Closed e1211182181110 ∧ code e1211182181110 = 5609228692214 := by decide
theorem cert_e1211182181110 : check e1211182181110 [[],[]] .smaller = true := by decide
def e1211182181214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211182181214 : Closed e1211182181214 ∧ code e1211182181214 = 5609228692318 := by decide
theorem cert_e1211182181214 : check e1211182181214 [[],[]] .smaller = true := by decide
def e1211182181230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211182181230 : Closed e1211182181230 ∧ code e1211182181230 = 5609228692334 := by decide
theorem cert_e1211182181230 : check e1211182181230 [[],[]] .smaller = true := by decide
def e1211182181238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211182181238 : Closed e1211182181238 ∧ code e1211182181238 = 5609228692342 := by decide
theorem cert_e1211182181238 : check e1211182181238 [[],[]] .smaller = true := by decide
def e1211182181242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211182181242 : Closed e1211182181242 ∧ code e1211182181242 = 5609228692346 := by decide
theorem cert_e1211182181242 : check e1211182181242 [[],[]] .smaller = true := by decide
def e1211182181302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211182181302 : Closed e1211182181302 ∧ code e1211182181302 = 5609228692406 := by decide
theorem cert_e1211182181302 : check e1211182181302 [[],[]] .smaller = true := by decide
def e1211182181334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211182181334 : Closed e1211182181334 ∧ code e1211182181334 = 5609228692438 := by decide
theorem cert_e1211182181334 : check e1211182181334 [[],[]] .smaller = true := by decide
def e1211182181338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211182181338 : Closed e1211182181338 ∧ code e1211182181338 = 5609228692442 := by decide
theorem cert_e1211182181338 : check e1211182181338 [[],[]] .smaller = true := by decide
def e1211182181726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211182181726 : Closed e1211182181726 ∧ code e1211182181726 = 5609228692830 := by decide
theorem cert_e1211182181726 : check e1211182181726 [[],[]] .smaller = true := by decide
def e1211182181742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211182181742 : Closed e1211182181742 ∧ code e1211182181742 = 5609228692846 := by decide
theorem cert_e1211182181742 : check e1211182181742 [[],[]] .smaller = true := by decide
def e1211182181750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211182181750 : Closed e1211182181750 ∧ code e1211182181750 = 5609228692854 := by decide
theorem cert_e1211182181750 : check e1211182181750 [[],[]] .smaller = true := by decide
def e1211182181754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211182181754 : Closed e1211182181754 ∧ code e1211182181754 = 5609228692858 := by decide
theorem cert_e1211182181754 : check e1211182181754 [[],[]] .smaller = true := by decide
def e1211182181806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211182181806 : Closed e1211182181806 ∧ code e1211182181806 = 5609228692910 := by decide
theorem cert_e1211182181806 : check e1211182181806 [[],[]] .smaller = true := by decide
def e1211182181818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211182181818 : Closed e1211182181818 ∧ code e1211182181818 = 5609228692922 := by decide
theorem cert_e1211182181818 : check e1211182181818 [[],[]] .smaller = true := by decide
def e1211182181846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211182181846 : Closed e1211182181846 ∧ code e1211182181846 = 5609228692950 := by decide
theorem cert_e1211182181846 : check e1211182181846 [[],[]] .smaller = true := by decide
def e1211182181850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211182181850 : Closed e1211182181850 ∧ code e1211182181850 = 5609228692954 := by decide
theorem cert_e1211182181850 : check e1211182181850 [[],[]] .smaller = true := by decide
def e1211182181866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211182181866 : Closed e1211182181866 ∧ code e1211182181866 = 5609228692970 := by decide
theorem cert_e1211182181866 : check e1211182181866 [[],[]] .smaller = true := by decide
def e1211182182070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211182182070 : Closed e1211182182070 ∧ code e1211182182070 = 5609228693174 := by decide
theorem cert_e1211182182070 : check e1211182182070 [[],[]] .smaller = true := by decide
def e1211182182102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211182182102 : Closed e1211182182102 ∧ code e1211182182102 = 5609228693206 := by decide
theorem cert_e1211182182102 : check e1211182182102 [[],[]] .smaller = true := by decide
def e1211182182106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211182182106 : Closed e1211182182106 ∧ code e1211182182106 = 5609228693210 := by decide
theorem cert_e1211182182106 : check e1211182182106 [[],[]] .smaller = true := by decide
def e1211182182230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211182182230 : Closed e1211182182230 ∧ code e1211182182230 = 5609228693334 := by decide
theorem cert_e1211182182230 : check e1211182182230 [[],[]] .smaller = true := by decide
def e1211182182234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211182182234 : Closed e1211182182234 ∧ code e1211182182234 = 5609228693338 := by decide
theorem cert_e1211182182234 : check e1211182182234 [[],[]] .smaller = true := by decide
def e1211182182250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211182182250 : Closed e1211182182250 ∧ code e1211182182250 = 5609228693354 := by decide
theorem cert_e1211182182250 : check e1211182182250 [[],[]] .smaller = true := by decide
def e1211182183774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211182183774 : Closed e1211182183774 ∧ code e1211182183774 = 5609228694878 := by decide
theorem cert_e1211182183774 : check e1211182183774 [[],[]] .smaller = true := by decide
def e1211182183790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211182183790 : Closed e1211182183790 ∧ code e1211182183790 = 5609228694894 := by decide
theorem cert_e1211182183790 : check e1211182183790 [[],[]] .smaller = true := by decide
def e1211182183798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211182183798 : Closed e1211182183798 ∧ code e1211182183798 = 5609228694902 := by decide
theorem cert_e1211182183798 : check e1211182183798 [[],[]] .smaller = true := by decide
def e1211182183802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211182183802 : Closed e1211182183802 ∧ code e1211182183802 = 5609228694906 := by decide
theorem cert_e1211182183802 : check e1211182183802 [[],[]] .smaller = true := by decide
def e1211182183854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211182183854 : Closed e1211182183854 ∧ code e1211182183854 = 5609228694958 := by decide
theorem cert_e1211182183854 : check e1211182183854 [[],[]] .smaller = true := by decide
def e1211182183866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211182183866 : Closed e1211182183866 ∧ code e1211182183866 = 5609228694970 := by decide
theorem cert_e1211182183866 : check e1211182183866 [[],[]] .smaller = true := by decide
def e1211182183894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211182183894 : Closed e1211182183894 ∧ code e1211182183894 = 5609228694998 := by decide
theorem cert_e1211182183894 : check e1211182183894 [[],[]] .smaller = true := by decide
def e1211182183898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211182183898 : Closed e1211182183898 ∧ code e1211182183898 = 5609228695002 := by decide
theorem cert_e1211182183898 : check e1211182183898 [[],[]] .smaller = true := by decide
def e1211182183914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211182183914 : Closed e1211182183914 ∧ code e1211182183914 = 5609228695018 := by decide
theorem cert_e1211182183914 : check e1211182183914 [[],[]] .smaller = true := by decide
def e1211182184110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211182184110 : Closed e1211182184110 ∧ code e1211182184110 = 5609228695214 := by decide
theorem cert_e1211182184110 : check e1211182184110 [[],[]] .smaller = true := by decide
def e1211182184122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211182184122 : Closed e1211182184122 ∧ code e1211182184122 = 5609228695226 := by decide
theorem cert_e1211182184122 : check e1211182184122 [[],[]] .smaller = true := by decide
def e1211182184170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211182184170 : Closed e1211182184170 ∧ code e1211182184170 = 5609228695274 := by decide
theorem cert_e1211182184170 : check e1211182184170 [[],[]] .smaller = true := by decide
def e1211182184278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211182184278 : Closed e1211182184278 ∧ code e1211182184278 = 5609228695382 := by decide
theorem cert_e1211182184278 : check e1211182184278 [[],[]] .smaller = true := by decide
def e1211182184282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211182184282 : Closed e1211182184282 ∧ code e1211182184282 = 5609228695386 := by decide
theorem cert_e1211182184282 : check e1211182184282 [[],[]] .smaller = true := by decide
def e1211182184298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211182184298 : Closed e1211182184298 ∧ code e1211182184298 = 5609228695402 := by decide
theorem cert_e1211182184298 : check e1211182184298 [[],[]] .smaller = true := by decide
def e1211182184362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211182184362 : Closed e1211182184362 ∧ code e1211182184362 = 5609228695466 := by decide
theorem cert_e1211182184362 : check e1211182184362 [[],[]] .smaller = true := by decide
def e1211182185142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211182185142 : Closed e1211182185142 ∧ code e1211182185142 = 5609228696246 := by decide
theorem cert_e1211182185142 : check e1211182185142 [[],[]] .smaller = true := by decide
def e1211182185174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211182185174 : Closed e1211182185174 ∧ code e1211182185174 = 5609228696278 := by decide
theorem cert_e1211182185174 : check e1211182185174 [[],[]] .smaller = true := by decide
def e1211182185178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211182185178 : Closed e1211182185178 ∧ code e1211182185178 = 5609228696282 := by decide
theorem cert_e1211182185178 : check e1211182185178 [[],[]] .smaller = true := by decide
def e1211182185302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211182185302 : Closed e1211182185302 ∧ code e1211182185302 = 5609228696406 := by decide
theorem cert_e1211182185302 : check e1211182185302 [[],[]] .smaller = true := by decide
def e1211182185306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211182185306 : Closed e1211182185306 ∧ code e1211182185306 = 5609228696410 := by decide
theorem cert_e1211182185306 : check e1211182185306 [[],[]] .smaller = true := by decide
def e1211182185322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211182185322 : Closed e1211182185322 ∧ code e1211182185322 = 5609228696426 := by decide
theorem cert_e1211182185322 : check e1211182185322 [[],[]] .smaller = true := by decide
def e1211182185814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211182185814 : Closed e1211182185814 ∧ code e1211182185814 = 5609228696918 := by decide
theorem cert_e1211182185814 : check e1211182185814 [[],[]] .smaller = true := by decide
def e1211182185818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211182185818 : Closed e1211182185818 ∧ code e1211182185818 = 5609228696922 := by decide
theorem cert_e1211182185818 : check e1211182185818 [[],[]] .smaller = true := by decide
def e1211182185834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211182185834 : Closed e1211182185834 ∧ code e1211182185834 = 5609228696938 := by decide
theorem cert_e1211182185834 : check e1211182185834 [[],[]] .smaller = true := by decide
def e1211182185898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211182185898 : Closed e1211182185898 ∧ code e1211182185898 = 5609228697002 := by decide
theorem cert_e1211182185898 : check e1211182185898 [[],[]] .smaller = true := by decide
def e1211182190014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 4))))))))
theorem wire_e1211182190014 : Closed e1211182190014 ∧ code e1211182190014 = 5609228701118 := by decide
theorem cert_e1211182190014 : check e1211182190014 [[],[]] .three = true := by decide
def e1211182190046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 3))))))))
theorem wire_e1211182190046 : Closed e1211182190046 ∧ code e1211182190046 = 5609228701150 := by decide
theorem cert_e1211182190046 : check e1211182190046 [[],[]] .smaller = true := by decide
def e1211182190062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 2))))))))
theorem wire_e1211182190062 : Closed e1211182190062 ∧ code e1211182190062 = 5609228701166 := by decide
theorem cert_e1211182190062 : check e1211182190062 [[],[]] .smaller = true := by decide
def e1211182190070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 4)) (.var 1))))))))
theorem wire_e1211182190070 : Closed e1211182190070 ∧ code e1211182190070 = 5609228701174 := by decide
theorem cert_e1211182190070 : check e1211182190070 [[],[]] .three = true := by decide
def e1211182190270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 4))))))))
theorem wire_e1211182190270 : Closed e1211182190270 ∧ code e1211182190270 = 5609228701374 := by decide
theorem cert_e1211182190270 : check e1211182190270 [[],[]] .three = true := by decide
def e1211182190302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 3))))))))
theorem wire_e1211182190302 : Closed e1211182190302 ∧ code e1211182190302 = 5609228701406 := by decide
theorem cert_e1211182190302 : check e1211182190302 [[],[]] .smaller = true := by decide
def e1211182190318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))))))
theorem wire_e1211182190318 : Closed e1211182190318 ∧ code e1211182190318 = 5609228701422 := by decide
theorem cert_e1211182190318 : check e1211182190318 [[],[]] .smaller = true := by decide
def e1211182190326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 1))))))))
theorem wire_e1211182190326 : Closed e1211182190326 ∧ code e1211182190326 = 5609228701430 := by decide
theorem cert_e1211182190326 : check e1211182190326 [[],[]] .smaller = true := by decide
def e1211182190330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 4)) (.var 0))))))))
theorem wire_e1211182190330 : Closed e1211182190330 ∧ code e1211182190330 = 5609228701434 := by decide
theorem cert_e1211182190330 : check e1211182190330 [[],[]] .three = true := by decide
def e1211182190430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 3))))))))
theorem wire_e1211182190430 : Closed e1211182190430 ∧ code e1211182190430 = 5609228701534 := by decide
theorem cert_e1211182190430 : check e1211182190430 [[],[]] .smaller = true := by decide
def e1211182190446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))))))
theorem wire_e1211182190446 : Closed e1211182190446 ∧ code e1211182190446 = 5609228701550 := by decide
theorem cert_e1211182190446 : check e1211182190446 [[],[]] .smaller = true := by decide
def e1211182190454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))))))
theorem wire_e1211182190454 : Closed e1211182190454 ∧ code e1211182190454 = 5609228701558 := by decide
theorem cert_e1211182190454 : check e1211182190454 [[],[]] .smaller = true := by decide
def e1211182190458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.var 0))))))))
theorem wire_e1211182190458 : Closed e1211182190458 ∧ code e1211182190458 = 5609228701562 := by decide
theorem cert_e1211182190458 : check e1211182190458 [[],[]] .smaller = true := by decide
def e1211182190510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 2))))))))
theorem wire_e1211182190510 : Closed e1211182190510 ∧ code e1211182190510 = 5609228701614 := by decide
theorem cert_e1211182190510 : check e1211182190510 [[],[]] .smaller = true := by decide
def e1211182190518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 1))))))))
theorem wire_e1211182190518 : Closed e1211182190518 ∧ code e1211182190518 = 5609228701622 := by decide
theorem cert_e1211182190518 : check e1211182190518 [[],[]] .smaller = true := by decide
def e1211182190522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.var 0))))))))
theorem wire_e1211182190522 : Closed e1211182190522 ∧ code e1211182190522 = 5609228701626 := by decide
theorem cert_e1211182190522 : check e1211182190522 [[],[]] .smaller = true := by decide
def e1211182190550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 5))) (.var 0)) (.var 1))))))))
theorem wire_e1211182190550 : Closed e1211182190550 ∧ code e1211182190550 = 5609228701654 := by decide
theorem cert_e1211182190550 : check e1211182190550 [[],[]] .three = true := by decide
def e1211182190554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 5))) (.var 1)) (.var 0))))))))
theorem wire_e1211182190554 : Closed e1211182190554 ∧ code e1211182190554 = 5609228701658 := by decide
theorem cert_e1211182190554 : check e1211182190554 [[],[]] .three = true := by decide
def e1211182193374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e1211182193374 : Closed e1211182193374 ∧ code e1211182193374 = 5609228704478 := by decide
theorem cert_e1211182193374 : check e1211182193374 [[],[]] .smaller = true := by decide
def e1211182193398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e1211182193398 : Closed e1211182193398 ∧ code e1211182193398 = 5609228704502 := by decide
theorem cert_e1211182193398 : check e1211182193398 [[],[]] .smaller = true := by decide
def e1211182193502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e1211182193502 : Closed e1211182193502 ∧ code e1211182193502 = 5609228704606 := by decide
theorem cert_e1211182193502 : check e1211182193502 [[],[]] .smaller = true := by decide
def e1211182193518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211182193518 : Closed e1211182193518 ∧ code e1211182193518 = 5609228704622 := by decide
theorem cert_e1211182193518 : check e1211182193518 [[],[]] .smaller = true := by decide
def e1211182193526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211182193526 : Closed e1211182193526 ∧ code e1211182193526 = 5609228704630 := by decide
theorem cert_e1211182193526 : check e1211182193526 [[],[]] .smaller = true := by decide
def e1211182193530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e1211182193530 : Closed e1211182193530 ∧ code e1211182193530 = 5609228704634 := by decide
theorem cert_e1211182193530 : check e1211182193530 [[],[]] .smaller = true := by decide
def e1211182193590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))))
theorem wire_e1211182193590 : Closed e1211182193590 ∧ code e1211182193590 = 5609228704694 := by decide
theorem cert_e1211182193590 : check e1211182193590 [[],[]] .smaller = true := by decide
def e1211182193622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211182193622 : Closed e1211182193622 ∧ code e1211182193622 = 5609228704726 := by decide
theorem cert_e1211182193622 : check e1211182193622 [[],[]] .smaller = true := by decide
def e1211182193626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211182193626 : Closed e1211182193626 ∧ code e1211182193626 = 5609228704730 := by decide
theorem cert_e1211182193626 : check e1211182193626 [[],[]] .smaller = true := by decide
def e1211182194014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211182194014 : Closed e1211182194014 ∧ code e1211182194014 = 5609228705118 := by decide
theorem cert_e1211182194014 : check e1211182194014 [[],[]] .smaller = true := by decide
def e1211182194030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e1211182194030 : Closed e1211182194030 ∧ code e1211182194030 = 5609228705134 := by decide
theorem cert_e1211182194030 : check e1211182194030 [[],[]] .smaller = true := by decide
def e1211182194038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e1211182194038 : Closed e1211182194038 ∧ code e1211182194038 = 5609228705142 := by decide
theorem cert_e1211182194038 : check e1211182194038 [[],[]] .smaller = true := by decide
def e1211182194042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211182194042 : Closed e1211182194042 ∧ code e1211182194042 = 5609228705146 := by decide
theorem cert_e1211182194042 : check e1211182194042 [[],[]] .smaller = true := by decide
def e1211182194094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211182194094 : Closed e1211182194094 ∧ code e1211182194094 = 5609228705198 := by decide
theorem cert_e1211182194094 : check e1211182194094 [[],[]] .smaller = true := by decide
def e1211182194106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211182194106 : Closed e1211182194106 ∧ code e1211182194106 = 5609228705210 := by decide
theorem cert_e1211182194106 : check e1211182194106 [[],[]] .smaller = true := by decide
def e1211182194134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e1211182194134 : Closed e1211182194134 ∧ code e1211182194134 = 5609228705238 := by decide
theorem cert_e1211182194134 : check e1211182194134 [[],[]] .smaller = true := by decide
def e1211182194138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e1211182194138 : Closed e1211182194138 ∧ code e1211182194138 = 5609228705242 := by decide
theorem cert_e1211182194138 : check e1211182194138 [[],[]] .smaller = true := by decide
def e1211182194154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211182194154 : Closed e1211182194154 ∧ code e1211182194154 = 5609228705258 := by decide
theorem cert_e1211182194154 : check e1211182194154 [[],[]] .smaller = true := by decide
def e1211182194358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e1211182194358 : Closed e1211182194358 ∧ code e1211182194358 = 5609228705462 := by decide
theorem cert_e1211182194358 : check e1211182194358 [[],[]] .smaller = true := by decide
def e1211182194390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211182194390 : Closed e1211182194390 ∧ code e1211182194390 = 5609228705494 := by decide
theorem cert_e1211182194390 : check e1211182194390 [[],[]] .smaller = true := by decide
def e1211182194394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211182194394 : Closed e1211182194394 ∧ code e1211182194394 = 5609228705498 := by decide
theorem cert_e1211182194394 : check e1211182194394 [[],[]] .smaller = true := by decide
def e1211182194518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211182194518 : Closed e1211182194518 ∧ code e1211182194518 = 5609228705622 := by decide
theorem cert_e1211182194518 : check e1211182194518 [[],[]] .smaller = true := by decide
def e1211182194522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211182194522 : Closed e1211182194522 ∧ code e1211182194522 = 5609228705626 := by decide
theorem cert_e1211182194522 : check e1211182194522 [[],[]] .smaller = true := by decide
def e1211182194538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211182194538 : Closed e1211182194538 ∧ code e1211182194538 = 5609228705642 := by decide
theorem cert_e1211182194538 : check e1211182194538 [[],[]] .smaller = true := by decide
def e1211182195646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 4))))))))
theorem wire_e1211182195646 : Closed e1211182195646 ∧ code e1211182195646 = 5609228706750 := by decide
theorem cert_e1211182195646 : check e1211182195646 [[],[]] .three = true := by decide
def e1211182195678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211182195678 : Closed e1211182195678 ∧ code e1211182195678 = 5609228706782 := by decide
theorem cert_e1211182195678 : check e1211182195678 [[],[]] .smaller = true := by decide
def e1211182195694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211182195694 : Closed e1211182195694 ∧ code e1211182195694 = 5609228706798 := by decide
theorem cert_e1211182195694 : check e1211182195694 [[],[]] .smaller = true := by decide
def e1211182195702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 5))) (.var 1))))))))
theorem wire_e1211182195702 : Closed e1211182195702 ∧ code e1211182195702 = 5609228706806 := by decide
theorem cert_e1211182195702 : check e1211182195702 [[],[]] .three = true := by decide
def e1211182196446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211182196446 : Closed e1211182196446 ∧ code e1211182196446 = 5609228707550 := by decide
theorem cert_e1211182196446 : check e1211182196446 [[],[]] .smaller = true := by decide
def e1211182196470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211182196470 : Closed e1211182196470 ∧ code e1211182196470 = 5609228707574 := by decide
theorem cert_e1211182196470 : check e1211182196470 [[],[]] .smaller = true := by decide
def e1211182196574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211182196574 : Closed e1211182196574 ∧ code e1211182196574 = 5609228707678 := by decide
theorem cert_e1211182196574 : check e1211182196574 [[],[]] .smaller = true := by decide
def e1211182196590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211182196590 : Closed e1211182196590 ∧ code e1211182196590 = 5609228707694 := by decide
theorem cert_e1211182196590 : check e1211182196590 [[],[]] .smaller = true := by decide
end Blc.Floor42
