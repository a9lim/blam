import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186518250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186518250 : Closed e1211186518250 ∧ code e1211186518250 = 5609233029354 := by decide
theorem cert_e1211186518250 : check e1211186518250 [[],[]] .smaller = true := by decide
def e1211186518582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186518582 : Closed e1211186518582 ∧ code e1211186518582 = 5609233029686 := by decide
theorem cert_e1211186518582 : check e1211186518582 [[],[]] .smaller = true := by decide
def e1211186518586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186518586 : Closed e1211186518586 ∧ code e1211186518586 = 5609233029690 := by decide
theorem cert_e1211186518586 : check e1211186518586 [[],[]] .smaller = true := by decide
def e1211186518670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186518670 : Closed e1211186518670 ∧ code e1211186518670 = 5609233029774 := by decide
theorem cert_e1211186518670 : check e1211186518670 [[],[]] .smaller = true := by decide
def e1211186518726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186518726 : Closed e1211186518726 ∧ code e1211186518726 = 5609233029830 := by decide
theorem cert_e1211186518726 : check e1211186518726 [[],[]] .smaller = true := by decide
def e1211186518750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e1211186518750 : Closed e1211186518750 ∧ code e1211186518750 = 5609233029854 := by decide
theorem cert_e1211186518750 : check e1211186518750 [[],[]] .three = true := by decide
def e1211186518774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e1211186518774 : Closed e1211186518774 ∧ code e1211186518774 = 5609233029878 := by decide
theorem cert_e1211186518774 : check e1211186518774 [[],[]] .three = true := by decide
def e1211186518806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186518806 : Closed e1211186518806 ∧ code e1211186518806 = 5609233029910 := by decide
theorem cert_e1211186518806 : check e1211186518806 [[],[]] .smaller = true := by decide
def e1211186518810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186518810 : Closed e1211186518810 ∧ code e1211186518810 = 5609233029914 := by decide
theorem cert_e1211186518810 : check e1211186518810 [[],[]] .smaller = true := by decide
def e1211186518854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186518854 : Closed e1211186518854 ∧ code e1211186518854 = 5609233029958 := by decide
theorem cert_e1211186518854 : check e1211186518854 [[],[]] .smaller = true := by decide
def e1211186518878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e1211186518878 : Closed e1211186518878 ∧ code e1211186518878 = 5609233029982 := by decide
theorem cert_e1211186518878 : check e1211186518878 [[],[]] .three = true := by decide
def e1211186518882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186518882 : Closed e1211186518882 ∧ code e1211186518882 = 5609233029986 := by decide
theorem cert_e1211186518882 : check e1211186518882 [[],[]] .smaller = true := by decide
def e1211186518894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211186518894 : Closed e1211186518894 ∧ code e1211186518894 = 5609233029998 := by decide
theorem cert_e1211186518894 : check e1211186518894 [[],[]] .smaller = true := by decide
def e1211186518902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211186518902 : Closed e1211186518902 ∧ code e1211186518902 = 5609233030006 := by decide
theorem cert_e1211186518902 : check e1211186518902 [[],[]] .smaller = true := by decide
def e1211186518906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e1211186518906 : Closed e1211186518906 ∧ code e1211186518906 = 5609233030010 := by decide
theorem cert_e1211186518906 : check e1211186518906 [[],[]] .three = true := by decide
def e1211186518966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211186518966 : Closed e1211186518966 ∧ code e1211186518966 = 5609233030070 := by decide
theorem cert_e1211186518966 : check e1211186518966 [[],[]] .smaller = true := by decide
def e1211186518998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211186518998 : Closed e1211186518998 ∧ code e1211186518998 = 5609233030102 := by decide
theorem cert_e1211186518998 : check e1211186518998 [[],[]] .three = true := by decide
def e1211186519002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211186519002 : Closed e1211186519002 ∧ code e1211186519002 = 5609233030106 := by decide
theorem cert_e1211186519002 : check e1211186519002 [[],[]] .three = true := by decide
def e1211186519126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186519126 : Closed e1211186519126 ∧ code e1211186519126 = 5609233030230 := by decide
theorem cert_e1211186519126 : check e1211186519126 [[],[]] .smaller = true := by decide
def e1211186519130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186519130 : Closed e1211186519130 ∧ code e1211186519130 = 5609233030234 := by decide
theorem cert_e1211186519130 : check e1211186519130 [[],[]] .smaller = true := by decide
def e1211186519146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186519146 : Closed e1211186519146 ∧ code e1211186519146 = 5609233030250 := by decide
theorem cert_e1211186519146 : check e1211186519146 [[],[]] .smaller = true := by decide
def e1211186519318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186519318 : Closed e1211186519318 ∧ code e1211186519318 = 5609233030422 := by decide
theorem cert_e1211186519318 : check e1211186519318 [[],[]] .smaller = true := by decide
def e1211186519322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186519322 : Closed e1211186519322 ∧ code e1211186519322 = 5609233030426 := by decide
theorem cert_e1211186519322 : check e1211186519322 [[],[]] .smaller = true := by decide
def e1211186519366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186519366 : Closed e1211186519366 ∧ code e1211186519366 = 5609233030470 := by decide
theorem cert_e1211186519366 : check e1211186519366 [[],[]] .smaller = true := by decide
def e1211186519390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e1211186519390 : Closed e1211186519390 ∧ code e1211186519390 = 5609233030494 := by decide
theorem cert_e1211186519390 : check e1211186519390 [[],[]] .three = true := by decide
def e1211186519394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186519394 : Closed e1211186519394 ∧ code e1211186519394 = 5609233030498 := by decide
theorem cert_e1211186519394 : check e1211186519394 [[],[]] .smaller = true := by decide
def e1211186519406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186519406 : Closed e1211186519406 ∧ code e1211186519406 = 5609233030510 := by decide
theorem cert_e1211186519406 : check e1211186519406 [[],[]] .smaller = true := by decide
def e1211186519414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186519414 : Closed e1211186519414 ∧ code e1211186519414 = 5609233030518 := by decide
theorem cert_e1211186519414 : check e1211186519414 [[],[]] .smaller = true := by decide
def e1211186519418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e1211186519418 : Closed e1211186519418 ∧ code e1211186519418 = 5609233030522 := by decide
theorem cert_e1211186519418 : check e1211186519418 [[],[]] .three = true := by decide
def e1211186519434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186519434 : Closed e1211186519434 ∧ code e1211186519434 = 5609233030538 := by decide
theorem cert_e1211186519434 : check e1211186519434 [[],[]] .smaller = true := by decide
def e1211186519458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186519458 : Closed e1211186519458 ∧ code e1211186519458 = 5609233030562 := by decide
theorem cert_e1211186519458 : check e1211186519458 [[],[]] .smaller = true := by decide
def e1211186519470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186519470 : Closed e1211186519470 ∧ code e1211186519470 = 5609233030574 := by decide
theorem cert_e1211186519470 : check e1211186519470 [[],[]] .smaller = true := by decide
def e1211186519482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186519482 : Closed e1211186519482 ∧ code e1211186519482 = 5609233030586 := by decide
theorem cert_e1211186519482 : check e1211186519482 [[],[]] .smaller = true := by decide
def e1211186519510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211186519510 : Closed e1211186519510 ∧ code e1211186519510 = 5609233030614 := by decide
theorem cert_e1211186519510 : check e1211186519510 [[],[]] .smaller = true := by decide
def e1211186519514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211186519514 : Closed e1211186519514 ∧ code e1211186519514 = 5609233030618 := by decide
theorem cert_e1211186519514 : check e1211186519514 [[],[]] .smaller = true := by decide
def e1211186519530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211186519530 : Closed e1211186519530 ∧ code e1211186519530 = 5609233030634 := by decide
theorem cert_e1211186519530 : check e1211186519530 [[],[]] .three = true := by decide
def e1211186519734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211186519734 : Closed e1211186519734 ∧ code e1211186519734 = 5609233030838 := by decide
theorem cert_e1211186519734 : check e1211186519734 [[],[]] .smaller = true := by decide
def e1211186519766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211186519766 : Closed e1211186519766 ∧ code e1211186519766 = 5609233030870 := by decide
theorem cert_e1211186519766 : check e1211186519766 [[],[]] .smaller = true := by decide
def e1211186519770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211186519770 : Closed e1211186519770 ∧ code e1211186519770 = 5609233030874 := by decide
theorem cert_e1211186519770 : check e1211186519770 [[],[]] .smaller = true := by decide
def e1211186519894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186519894 : Closed e1211186519894 ∧ code e1211186519894 = 5609233030998 := by decide
theorem cert_e1211186519894 : check e1211186519894 [[],[]] .three = true := by decide
def e1211186519898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186519898 : Closed e1211186519898 ∧ code e1211186519898 = 5609233031002 := by decide
theorem cert_e1211186519898 : check e1211186519898 [[],[]] .three = true := by decide
def e1211186519914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211186519914 : Closed e1211186519914 ∧ code e1211186519914 = 5609233031018 := by decide
theorem cert_e1211186519914 : check e1211186519914 [[],[]] .three = true := by decide
def e1211186520310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211186520310 : Closed e1211186520310 ∧ code e1211186520310 = 5609233031414 := by decide
theorem cert_e1211186520310 : check e1211186520310 [[],[]] .smaller = true := by decide
def e1211186520502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211186520502 : Closed e1211186520502 ∧ code e1211186520502 = 5609233031606 := by decide
theorem cert_e1211186520502 : check e1211186520502 [[],[]] .smaller = true := by decide
def e1211186520506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211186520506 : Closed e1211186520506 ∧ code e1211186520506 = 5609233031610 := by decide
theorem cert_e1211186520506 : check e1211186520506 [[],[]] .smaller = true := by decide
def e1211186520534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211186520534 : Closed e1211186520534 ∧ code e1211186520534 = 5609233031638 := by decide
theorem cert_e1211186520534 : check e1211186520534 [[],[]] .smaller = true := by decide
def e1211186520554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211186520554 : Closed e1211186520554 ∧ code e1211186520554 = 5609233031658 := by decide
theorem cert_e1211186520554 : check e1211186520554 [[],[]] .smaller = true := by decide
def e1211186520694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186520694 : Closed e1211186520694 ∧ code e1211186520694 = 5609233031798 := by decide
theorem cert_e1211186520694 : check e1211186520694 [[],[]] .smaller = true := by decide
def e1211186520886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186520886 : Closed e1211186520886 ∧ code e1211186520886 = 5609233031990 := by decide
theorem cert_e1211186520886 : check e1211186520886 [[],[]] .smaller = true := by decide
def e1211186520890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186520890 : Closed e1211186520890 ∧ code e1211186520890 = 5609233031994 := by decide
theorem cert_e1211186520890 : check e1211186520890 [[],[]] .smaller = true := by decide
def e1211186520974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211186520974 : Closed e1211186520974 ∧ code e1211186520974 = 5609233032078 := by decide
theorem cert_e1211186520974 : check e1211186520974 [[],[]] .smaller = true := by decide
def e1211186520986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186520986 : Closed e1211186520986 ∧ code e1211186520986 = 5609233032090 := by decide
theorem cert_e1211186520986 : check e1211186520986 [[],[]] .smaller = true := by decide
def e1211186521054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e1211186521054 : Closed e1211186521054 ∧ code e1211186521054 = 5609233032158 := by decide
theorem cert_e1211186521054 : check e1211186521054 [[],[]] .three = true := by decide
def e1211186521070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e1211186521070 : Closed e1211186521070 ∧ code e1211186521070 = 5609233032174 := by decide
theorem cert_e1211186521070 : check e1211186521070 [[],[]] .three = true := by decide
def e1211186521654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186521654 : Closed e1211186521654 ∧ code e1211186521654 = 5609233032758 := by decide
theorem cert_e1211186521654 : check e1211186521654 [[],[]] .smaller = true := by decide
def e1211186521658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186521658 : Closed e1211186521658 ∧ code e1211186521658 = 5609233032762 := by decide
theorem cert_e1211186521658 : check e1211186521658 [[],[]] .smaller = true := by decide
def e1211186521742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186521742 : Closed e1211186521742 ∧ code e1211186521742 = 5609233032846 := by decide
theorem cert_e1211186521742 : check e1211186521742 [[],[]] .smaller = true := by decide
def e1211186521798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186521798 : Closed e1211186521798 ∧ code e1211186521798 = 5609233032902 := by decide
theorem cert_e1211186521798 : check e1211186521798 [[],[]] .smaller = true := by decide
def e1211186521822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1211186521822 : Closed e1211186521822 ∧ code e1211186521822 = 5609233032926 := by decide
theorem cert_e1211186521822 : check e1211186521822 [[],[]] .three = true := by decide
def e1211186521846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1211186521846 : Closed e1211186521846 ∧ code e1211186521846 = 5609233032950 := by decide
theorem cert_e1211186521846 : check e1211186521846 [[],[]] .three = true := by decide
def e1211186521878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186521878 : Closed e1211186521878 ∧ code e1211186521878 = 5609233032982 := by decide
theorem cert_e1211186521878 : check e1211186521878 [[],[]] .smaller = true := by decide
def e1211186521882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186521882 : Closed e1211186521882 ∧ code e1211186521882 = 5609233032986 := by decide
theorem cert_e1211186521882 : check e1211186521882 [[],[]] .smaller = true := by decide
def e1211186521926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186521926 : Closed e1211186521926 ∧ code e1211186521926 = 5609233033030 := by decide
theorem cert_e1211186521926 : check e1211186521926 [[],[]] .smaller = true := by decide
def e1211186521950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1211186521950 : Closed e1211186521950 ∧ code e1211186521950 = 5609233033054 := by decide
theorem cert_e1211186521950 : check e1211186521950 [[],[]] .three = true := by decide
def e1211186521954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186521954 : Closed e1211186521954 ∧ code e1211186521954 = 5609233033058 := by decide
theorem cert_e1211186521954 : check e1211186521954 [[],[]] .smaller = true := by decide
def e1211186521966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211186521966 : Closed e1211186521966 ∧ code e1211186521966 = 5609233033070 := by decide
theorem cert_e1211186521966 : check e1211186521966 [[],[]] .smaller = true := by decide
def e1211186521974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211186521974 : Closed e1211186521974 ∧ code e1211186521974 = 5609233033078 := by decide
theorem cert_e1211186521974 : check e1211186521974 [[],[]] .smaller = true := by decide
def e1211186521978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1211186521978 : Closed e1211186521978 ∧ code e1211186521978 = 5609233033082 := by decide
theorem cert_e1211186521978 : check e1211186521978 [[],[]] .three = true := by decide
def e1211186522038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211186522038 : Closed e1211186522038 ∧ code e1211186522038 = 5609233033142 := by decide
theorem cert_e1211186522038 : check e1211186522038 [[],[]] .smaller = true := by decide
def e1211186522070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1211186522070 : Closed e1211186522070 ∧ code e1211186522070 = 5609233033174 := by decide
theorem cert_e1211186522070 : check e1211186522070 [[],[]] .three = true := by decide
def e1211186522074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1211186522074 : Closed e1211186522074 ∧ code e1211186522074 = 5609233033178 := by decide
theorem cert_e1211186522074 : check e1211186522074 [[],[]] .three = true := by decide
def e1211186522222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186522222 : Closed e1211186522222 ∧ code e1211186522222 = 5609233033326 := by decide
theorem cert_e1211186522222 : check e1211186522222 [[],[]] .smaller = true := by decide
def e1211186522234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186522234 : Closed e1211186522234 ∧ code e1211186522234 = 5609233033338 := by decide
theorem cert_e1211186522234 : check e1211186522234 [[],[]] .smaller = true := by decide
def e1211186522510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186522510 : Closed e1211186522510 ∧ code e1211186522510 = 5609233033614 := by decide
theorem cert_e1211186522510 : check e1211186522510 [[],[]] .smaller = true := by decide
def e1211186522566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186522566 : Closed e1211186522566 ∧ code e1211186522566 = 5609233033670 := by decide
theorem cert_e1211186522566 : check e1211186522566 [[],[]] .smaller = true := by decide
def e1211186522590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186522590 : Closed e1211186522590 ∧ code e1211186522590 = 5609233033694 := by decide
theorem cert_e1211186522590 : check e1211186522590 [[],[]] .three = true := by decide
def e1211186522614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186522614 : Closed e1211186522614 ∧ code e1211186522614 = 5609233033718 := by decide
theorem cert_e1211186522614 : check e1211186522614 [[],[]] .three = true := by decide
def e1211186523166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186523166 : Closed e1211186523166 ∧ code e1211186523166 = 5609233034270 := by decide
theorem cert_e1211186523166 : check e1211186523166 [[],[]] .smaller = true := by decide
def e1211186523190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186523190 : Closed e1211186523190 ∧ code e1211186523190 = 5609233034294 := by decide
theorem cert_e1211186523190 : check e1211186523190 [[],[]] .smaller = true := by decide
def e1211186523194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186523194 : Closed e1211186523194 ∧ code e1211186523194 = 5609233034298 := by decide
theorem cert_e1211186523194 : check e1211186523194 [[],[]] .smaller = true := by decide
def e1211186523334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186523334 : Closed e1211186523334 ∧ code e1211186523334 = 5609233034438 := by decide
theorem cert_e1211186523334 : check e1211186523334 [[],[]] .smaller = true := by decide
def e1211186523358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186523358 : Closed e1211186523358 ∧ code e1211186523358 = 5609233034462 := by decide
theorem cert_e1211186523358 : check e1211186523358 [[],[]] .three = true := by decide
def e1211186523362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186523362 : Closed e1211186523362 ∧ code e1211186523362 = 5609233034466 := by decide
theorem cert_e1211186523362 : check e1211186523362 [[],[]] .smaller = true := by decide
def e1211186523374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186523374 : Closed e1211186523374 ∧ code e1211186523374 = 5609233034478 := by decide
theorem cert_e1211186523374 : check e1211186523374 [[],[]] .smaller = true := by decide
def e1211186523382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186523382 : Closed e1211186523382 ∧ code e1211186523382 = 5609233034486 := by decide
theorem cert_e1211186523382 : check e1211186523382 [[],[]] .smaller = true := by decide
def e1211186523386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186523386 : Closed e1211186523386 ∧ code e1211186523386 = 5609233034490 := by decide
theorem cert_e1211186523386 : check e1211186523386 [[],[]] .three = true := by decide
def e1211186523710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e1211186523710 : Closed e1211186523710 ∧ code e1211186523710 = 5609233034814 := by decide
theorem cert_e1211186523710 : check e1211186523710 [[],[]] .three = true := by decide
def e1211186523766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186523766 : Closed e1211186523766 ∧ code e1211186523766 = 5609233034870 := by decide
theorem cert_e1211186523766 : check e1211186523766 [[],[]] .smaller = true := by decide
def e1211186523934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e1211186523934 : Closed e1211186523934 ∧ code e1211186523934 = 5609233035038 := by decide
theorem cert_e1211186523934 : check e1211186523934 [[],[]] .three = true := by decide
def e1211186523958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186523958 : Closed e1211186523958 ∧ code e1211186523958 = 5609233035062 := by decide
theorem cert_e1211186523958 : check e1211186523958 [[],[]] .three = true := by decide
def e1211186523962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186523962 : Closed e1211186523962 ∧ code e1211186523962 = 5609233035066 := by decide
theorem cert_e1211186523962 : check e1211186523962 [[],[]] .three = true := by decide
def e1211186524278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211186524278 : Closed e1211186524278 ∧ code e1211186524278 = 5609233035382 := by decide
theorem cert_e1211186524278 : check e1211186524278 [[],[]] .smaller = true := by decide
def e1211186524282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186524282 : Closed e1211186524282 ∧ code e1211186524282 = 5609233035386 := by decide
theorem cert_e1211186524282 : check e1211186524282 [[],[]] .smaller = true := by decide
def e1211186524378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211186524378 : Closed e1211186524378 ∧ code e1211186524378 = 5609233035482 := by decide
theorem cert_e1211186524378 : check e1211186524378 [[],[]] .smaller = true := by decide
def e1211186524394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211186524394 : Closed e1211186524394 ∧ code e1211186524394 = 5609233035498 := by decide
theorem cert_e1211186524394 : check e1211186524394 [[],[]] .smaller = true := by decide
def e1211186524470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186524470 : Closed e1211186524470 ∧ code e1211186524470 = 5609233035574 := by decide
theorem cert_e1211186524470 : check e1211186524470 [[],[]] .smaller = true := by decide
def e1211186524474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186524474 : Closed e1211186524474 ∧ code e1211186524474 = 5609233035578 := by decide
theorem cert_e1211186524474 : check e1211186524474 [[],[]] .smaller = true := by decide
def e1211186524558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211186524558 : Closed e1211186524558 ∧ code e1211186524558 = 5609233035662 := by decide
theorem cert_e1211186524558 : check e1211186524558 [[],[]] .smaller = true := by decide
def e1211186524570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186524570 : Closed e1211186524570 ∧ code e1211186524570 = 5609233035674 := by decide
theorem cert_e1211186524570 : check e1211186524570 [[],[]] .smaller = true := by decide
def e1211186524614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186524614 : Closed e1211186524614 ∧ code e1211186524614 = 5609233035718 := by decide
theorem cert_e1211186524614 : check e1211186524614 [[],[]] .smaller = true := by decide
def e1211186524638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1211186524638 : Closed e1211186524638 ∧ code e1211186524638 = 5609233035742 := by decide
theorem cert_e1211186524638 : check e1211186524638 [[],[]] .three = true := by decide
def e1211186524662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1211186524662 : Closed e1211186524662 ∧ code e1211186524662 = 5609233035766 := by decide
theorem cert_e1211186524662 : check e1211186524662 [[],[]] .three = true := by decide
def e1211186524950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186524950 : Closed e1211186524950 ∧ code e1211186524950 = 5609233036054 := by decide
theorem cert_e1211186524950 : check e1211186524950 [[],[]] .smaller = true := by decide
def e1211186524954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186524954 : Closed e1211186524954 ∧ code e1211186524954 = 5609233036058 := by decide
theorem cert_e1211186524954 : check e1211186524954 [[],[]] .smaller = true := by decide
def e1211186524998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186524998 : Closed e1211186524998 ∧ code e1211186524998 = 5609233036102 := by decide
theorem cert_e1211186524998 : check e1211186524998 [[],[]] .smaller = true := by decide
def e1211186525022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1211186525022 : Closed e1211186525022 ∧ code e1211186525022 = 5609233036126 := by decide
theorem cert_e1211186525022 : check e1211186525022 [[],[]] .three = true := by decide
def e1211186525026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186525026 : Closed e1211186525026 ∧ code e1211186525026 = 5609233036130 := by decide
theorem cert_e1211186525026 : check e1211186525026 [[],[]] .smaller = true := by decide
def e1211186525038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186525038 : Closed e1211186525038 ∧ code e1211186525038 = 5609233036142 := by decide
theorem cert_e1211186525038 : check e1211186525038 [[],[]] .smaller = true := by decide
def e1211186525046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186525046 : Closed e1211186525046 ∧ code e1211186525046 = 5609233036150 := by decide
theorem cert_e1211186525046 : check e1211186525046 [[],[]] .smaller = true := by decide
def e1211186525050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1211186525050 : Closed e1211186525050 ∧ code e1211186525050 = 5609233036154 := by decide
theorem cert_e1211186525050 : check e1211186525050 [[],[]] .three = true := by decide
def e1211186525066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186525066 : Closed e1211186525066 ∧ code e1211186525066 = 5609233036170 := by decide
theorem cert_e1211186525066 : check e1211186525066 [[],[]] .smaller = true := by decide
def e1211186525090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186525090 : Closed e1211186525090 ∧ code e1211186525090 = 5609233036194 := by decide
theorem cert_e1211186525090 : check e1211186525090 [[],[]] .smaller = true := by decide
def e1211186525102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186525102 : Closed e1211186525102 ∧ code e1211186525102 = 5609233036206 := by decide
theorem cert_e1211186525102 : check e1211186525102 [[],[]] .smaller = true := by decide
def e1211186525114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186525114 : Closed e1211186525114 ∧ code e1211186525114 = 5609233036218 := by decide
theorem cert_e1211186525114 : check e1211186525114 [[],[]] .smaller = true := by decide
def e1211186525142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186525142 : Closed e1211186525142 ∧ code e1211186525142 = 5609233036246 := by decide
theorem cert_e1211186525142 : check e1211186525142 [[],[]] .smaller = true := by decide
def e1211186525146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186525146 : Closed e1211186525146 ∧ code e1211186525146 = 5609233036250 := by decide
theorem cert_e1211186525146 : check e1211186525146 [[],[]] .smaller = true := by decide
def e1211186525162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1211186525162 : Closed e1211186525162 ∧ code e1211186525162 = 5609233036266 := by decide
theorem cert_e1211186525162 : check e1211186525162 [[],[]] .three = true := by decide
def e1211186525214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186525214 : Closed e1211186525214 ∧ code e1211186525214 = 5609233036318 := by decide
theorem cert_e1211186525214 : check e1211186525214 [[],[]] .smaller = true := by decide
def e1211186525238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186525238 : Closed e1211186525238 ∧ code e1211186525238 = 5609233036342 := by decide
theorem cert_e1211186525238 : check e1211186525238 [[],[]] .smaller = true := by decide
def e1211186525242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186525242 : Closed e1211186525242 ∧ code e1211186525242 = 5609233036346 := by decide
theorem cert_e1211186525242 : check e1211186525242 [[],[]] .smaller = true := by decide
def e1211186525382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186525382 : Closed e1211186525382 ∧ code e1211186525382 = 5609233036486 := by decide
theorem cert_e1211186525382 : check e1211186525382 [[],[]] .smaller = true := by decide
def e1211186525406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186525406 : Closed e1211186525406 ∧ code e1211186525406 = 5609233036510 := by decide
theorem cert_e1211186525406 : check e1211186525406 [[],[]] .three = true := by decide
def e1211186525410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186525410 : Closed e1211186525410 ∧ code e1211186525410 = 5609233036514 := by decide
theorem cert_e1211186525410 : check e1211186525410 [[],[]] .smaller = true := by decide
def e1211186525422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186525422 : Closed e1211186525422 ∧ code e1211186525422 = 5609233036526 := by decide
theorem cert_e1211186525422 : check e1211186525422 [[],[]] .smaller = true := by decide
def e1211186525430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186525430 : Closed e1211186525430 ∧ code e1211186525430 = 5609233036534 := by decide
theorem cert_e1211186525430 : check e1211186525430 [[],[]] .smaller = true := by decide
def e1211186525434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186525434 : Closed e1211186525434 ∧ code e1211186525434 = 5609233036538 := by decide
theorem cert_e1211186525434 : check e1211186525434 [[],[]] .three = true := by decide
def e1211186525710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186525710 : Closed e1211186525710 ∧ code e1211186525710 = 5609233036814 := by decide
theorem cert_e1211186525710 : check e1211186525710 [[],[]] .smaller = true := by decide
def e1211186525758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1211186525758 : Closed e1211186525758 ∧ code e1211186525758 = 5609233036862 := by decide
theorem cert_e1211186525758 : check e1211186525758 [[],[]] .three = true := by decide
def e1211186525794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186525794 : Closed e1211186525794 ∧ code e1211186525794 = 5609233036898 := by decide
theorem cert_e1211186525794 : check e1211186525794 [[],[]] .smaller = true := by decide
def e1211186525806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186525806 : Closed e1211186525806 ∧ code e1211186525806 = 5609233036910 := by decide
theorem cert_e1211186525806 : check e1211186525806 [[],[]] .smaller = true := by decide
def e1211186525818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186525818 : Closed e1211186525818 ∧ code e1211186525818 = 5609233036922 := by decide
theorem cert_e1211186525818 : check e1211186525818 [[],[]] .smaller = true := by decide
def e1211186526006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186526006 : Closed e1211186526006 ∧ code e1211186526006 = 5609233037110 := by decide
theorem cert_e1211186526006 : check e1211186526006 [[],[]] .smaller = true := by decide
def e1211186526010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186526010 : Closed e1211186526010 ∧ code e1211186526010 = 5609233037114 := by decide
theorem cert_e1211186526010 : check e1211186526010 [[],[]] .smaller = true := by decide
def e1211186526094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1211186526094 : Closed e1211186526094 ∧ code e1211186526094 = 5609233037198 := by decide
theorem cert_e1211186526094 : check e1211186526094 [[],[]] .three = true := by decide
def e1211186526106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186526106 : Closed e1211186526106 ∧ code e1211186526106 = 5609233037210 := by decide
theorem cert_e1211186526106 : check e1211186526106 [[],[]] .three = true := by decide
def e1211186526430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1211186526430 : Closed e1211186526430 ∧ code e1211186526430 = 5609233037534 := by decide
theorem cert_e1211186526430 : check e1211186526430 [[],[]] .three = true := by decide
def e1211186526458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1211186526458 : Closed e1211186526458 ∧ code e1211186526458 = 5609233037562 := by decide
theorem cert_e1211186526458 : check e1211186526458 [[],[]] .three = true := by decide
def e1211186526646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211186526646 : Closed e1211186526646 ∧ code e1211186526646 = 5609233037750 := by decide
theorem cert_e1211186526646 : check e1211186526646 [[],[]] .smaller = true := by decide
def e1211186526678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211186526678 : Closed e1211186526678 ∧ code e1211186526678 = 5609233037782 := by decide
theorem cert_e1211186526678 : check e1211186526678 [[],[]] .smaller = true := by decide
def e1211186526682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211186526682 : Closed e1211186526682 ∧ code e1211186526682 = 5609233037786 := by decide
theorem cert_e1211186526682 : check e1211186526682 [[],[]] .smaller = true := by decide
def e1211186526782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1211186526782 : Closed e1211186526782 ∧ code e1211186526782 = 5609233037886 := by decide
theorem cert_e1211186526782 : check e1211186526782 [[],[]] .three = true := by decide
def e1211186526838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186526838 : Closed e1211186526838 ∧ code e1211186526838 = 5609233037942 := by decide
theorem cert_e1211186526838 : check e1211186526838 [[],[]] .smaller = true := by decide
def e1211186527030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186527030 : Closed e1211186527030 ∧ code e1211186527030 = 5609233038134 := by decide
theorem cert_e1211186527030 : check e1211186527030 [[],[]] .smaller = true := by decide
def e1211186527034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186527034 : Closed e1211186527034 ∧ code e1211186527034 = 5609233038138 := by decide
theorem cert_e1211186527034 : check e1211186527034 [[],[]] .smaller = true := by decide
def e1211186527174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1211186527174 : Closed e1211186527174 ∧ code e1211186527174 = 5609233038278 := by decide
theorem cert_e1211186527174 : check e1211186527174 [[],[]] .three = true := by decide
def e1211186527342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186527342 : Closed e1211186527342 ∧ code e1211186527342 = 5609233038446 := by decide
theorem cert_e1211186527342 : check e1211186527342 [[],[]] .three = true := by decide
def e1211186527350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211186527350 : Closed e1211186527350 ∧ code e1211186527350 = 5609233038454 := by decide
theorem cert_e1211186527350 : check e1211186527350 [[],[]] .three = true := by decide
def e1211186527354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186527354 : Closed e1211186527354 ∧ code e1211186527354 = 5609233038458 := by decide
theorem cert_e1211186527354 : check e1211186527354 [[],[]] .three = true := by decide
def e1211186527446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211186527446 : Closed e1211186527446 ∧ code e1211186527446 = 5609233038550 := by decide
theorem cert_e1211186527446 : check e1211186527446 [[],[]] .three = true := by decide
def e1211186527450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211186527450 : Closed e1211186527450 ∧ code e1211186527450 = 5609233038554 := by decide
theorem cert_e1211186527450 : check e1211186527450 [[],[]] .three = true := by decide
def e1211186527466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211186527466 : Closed e1211186527466 ∧ code e1211186527466 = 5609233038570 := by decide
theorem cert_e1211186527466 : check e1211186527466 [[],[]] .three = true := by decide
def e1211186527518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186527518 : Closed e1211186527518 ∧ code e1211186527518 = 5609233038622 := by decide
theorem cert_e1211186527518 : check e1211186527518 [[],[]] .three = true := by decide
def e1211186527542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186527542 : Closed e1211186527542 ∧ code e1211186527542 = 5609233038646 := by decide
theorem cert_e1211186527542 : check e1211186527542 [[],[]] .three = true := by decide
def e1211186527546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186527546 : Closed e1211186527546 ∧ code e1211186527546 = 5609233038650 := by decide
theorem cert_e1211186527546 : check e1211186527546 [[],[]] .three = true := by decide
def e1211186527630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211186527630 : Closed e1211186527630 ∧ code e1211186527630 = 5609233038734 := by decide
theorem cert_e1211186527630 : check e1211186527630 [[],[]] .three = true := by decide
def e1211186527642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186527642 : Closed e1211186527642 ∧ code e1211186527642 = 5609233038746 := by decide
theorem cert_e1211186527642 : check e1211186527642 [[],[]] .three = true := by decide
def e1211186527686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186527686 : Closed e1211186527686 ∧ code e1211186527686 = 5609233038790 := by decide
theorem cert_e1211186527686 : check e1211186527686 [[],[]] .three = true := by decide
def e1211186528726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186528726 : Closed e1211186528726 ∧ code e1211186528726 = 5609233039830 := by decide
theorem cert_e1211186528726 : check e1211186528726 [[],[]] .three = true := by decide
def e1211186528730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186528730 : Closed e1211186528730 ∧ code e1211186528730 = 5609233039834 := by decide
theorem cert_e1211186528730 : check e1211186528730 [[],[]] .three = true := by decide
def e1211186528746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186528746 : Closed e1211186528746 ∧ code e1211186528746 = 5609233039850 := by decide
theorem cert_e1211186528746 : check e1211186528746 [[],[]] .three = true := by decide
end Blc.Floor42
