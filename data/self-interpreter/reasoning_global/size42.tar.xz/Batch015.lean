import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302896280542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302896280542 : Closed e302896280542 ∧ code e302896280542 = 4700942791646 := by decide
theorem cert_e302896280542 : checkPay e302896280542 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[.left]] 0 [] = true := by decide
def e302896280558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302896280558 : Closed e302896280558 ∧ code e302896280558 = 4700942791662 := by decide
theorem cert_e302896280558 : checkPay e302896280558 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896282078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302896282078 : Closed e302896282078 ∧ code e302896282078 = 4700942793182 := by decide
theorem cert_e302896282078 : checkPay e302896282078 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left]] 0 [[]] = true := by decide
def e302896282102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302896282102 : Closed e302896282102 ∧ code e302896282102 = 4700942793206 := by decide
theorem cert_e302896282102 : check e302896282102 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302896282862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302896282862 : Closed e302896282862 ∧ code e302896282862 = 4700942793966 := by decide
theorem cert_e302896282862 : check e302896282862 [[.left],[.left],[.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302896282870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302896282870 : Closed e302896282870 ∧ code e302896282870 = 4700942793974 := by decide
theorem cert_e302896282870 : check e302896282870 [[.left],[.left],[.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302896328158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302896328158 : Closed e302896328158 ∧ code e302896328158 = 4700942839262 := by decide
theorem cert_e302896328158 : check e302896328158 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896328174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302896328174 : Closed e302896328174 ∧ code e302896328174 = 4700942839278 := by decide
theorem cert_e302896328174 : check e302896328174 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896328542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302896328542 : Closed e302896328542 ∧ code e302896328542 = 4700942839646 := by decide
theorem cert_e302896328542 : check e302896328542 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896328570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302896328570 : Closed e302896328570 ∧ code e302896328570 = 4700942839674 := by decide
theorem cert_e302896328570 : check e302896328570 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896328622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302896328622 : Closed e302896328622 ∧ code e302896328622 = 4700942839726 := by decide
theorem cert_e302896328622 : check e302896328622 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896328634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302896328634 : Closed e302896328634 ∧ code e302896328634 = 4700942839738 := by decide
theorem cert_e302896328634 : check e302896328634 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896329694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302896329694 : Closed e302896329694 ∧ code e302896329694 = 4700942840798 := by decide
theorem cert_e302896329694 : check e302896329694 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896329710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302896329710 : Closed e302896329710 ∧ code e302896329710 = 4700942840814 := by decide
theorem cert_e302896329710 : check e302896329710 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896331998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302896331998 : Closed e302896331998 ∧ code e302896331998 = 4700942843102 := by decide
theorem cert_e302896331998 : check e302896331998 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896332026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302896332026 : Closed e302896332026 ∧ code e302896332026 = 4700942843130 := by decide
theorem cert_e302896332026 : check e302896332026 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896332398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302896332398 : Closed e302896332398 ∧ code e302896332398 = 4700942843502 := by decide
theorem cert_e302896332398 : check e302896332398 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896332410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302896332410 : Closed e302896332410 ∧ code e302896332410 = 4700942843514 := by decide
theorem cert_e302896332410 : check e302896332410 [[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302896355038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302896355038 : Closed e302896355038 ∧ code e302896355038 = 4700942866142 := by decide
theorem cert_e302896355038 : check e302896355038 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e302896355062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302896355062 : Closed e302896355062 ∧ code e302896355062 = 4700942866166 := by decide
theorem cert_e302896355062 : check e302896355062 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302896355166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302896355166 : Closed e302896355166 ∧ code e302896355166 = 4700942866270 := by decide
theorem cert_e302896355166 : check e302896355166 [[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302896355194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302896355194 : Closed e302896355194 ∧ code e302896355194 = 4700942866298 := by decide
theorem cert_e302896355194 : check e302896355194 [[.under],[.under],[.under],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e302896355286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302896355286 : Closed e302896355286 ∧ code e302896355286 = 4700942866390 := by decide
theorem cert_e302896355286 : check e302896355286 [[.under],[.under],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e302896355290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302896355290 : Closed e302896355290 ∧ code e302896355290 = 4700942866394 := by decide
theorem cert_e302896355290 : check e302896355290 [[.under],[.under],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e302896355806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302896355806 : Closed e302896355806 ∧ code e302896355806 = 4700942866910 := by decide
theorem cert_e302896355806 : check e302896355806 [[.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302896355830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302896355830 : Closed e302896355830 ∧ code e302896355830 = 4700942866934 := by decide
theorem cert_e302896355830 : check e302896355830 [[.left],[.left],[.left],[.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e302896356574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302896356574 : Closed e302896356574 ∧ code e302896356574 = 4700942867678 := by decide
theorem cert_e302896356574 : check e302896356574 [[.under],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e302896356602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302896356602 : Closed e302896356602 ∧ code e302896356602 = 4700942867706 := by decide
theorem cert_e302896356602 : check e302896356602 [[.under],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e302896357174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302896357174 : Closed e302896357174 ∧ code e302896357174 = 4700942868278 := by decide
theorem cert_e302896357174 : checkPay e302896357174 [[.left],[.left],[.left],[.left],[.left],[],[]] 0 [[],[.left],[],[],[.under],[.under,.left,.right,.right,.right],[.under,.left,.right,.right,.right,.left],[.under,.left,.right,.right,.right],[.under,.right,.under,.under,.left,.right,.right,.right],[.under,.right,.under,.under,.left,.right,.right,.right,.left],[.under,.right,.under,.under,.left,.right,.right,.right]] = true := by decide
def e302896357178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302896357178 : Closed e302896357178 ∧ code e302896357178 = 4700942868282 := by decide
theorem cert_e302896357178 : checkPay e302896357178 [[.left],[.left],[.left],[.left],[.left],[],[]] 0 [[],[.under],[.under,.under],[.under,.under,.left,.right,.left,.right],[.under,.under,.right,.under,.under,.left,.right,.left,.right]] = true := by decide
def e302896368494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302896368494 : Closed e302896368494 ∧ code e302896368494 = 4700942879598 := by decide
theorem cert_e302896368494 : check e302896368494 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302896368502 : Closed e302896368502 ∧ code e302896368502 = 4700942879606 := by decide
theorem cert_e302896368502 : check e302896368502 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302896368558 : Closed e302896368558 ∧ code e302896368558 = 4700942879662 := by decide
theorem cert_e302896368558 : check e302896368558 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302896368570 : Closed e302896368570 ∧ code e302896368570 = 4700942879674 := by decide
theorem cert_e302896368570 : check e302896368570 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302896368598 : Closed e302896368598 ∧ code e302896368598 = 4700942879702 := by decide
theorem cert_e302896368598 : check e302896368598 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302896368602 : Closed e302896368602 ∧ code e302896368602 = 4700942879706 := by decide
theorem cert_e302896368602 : check e302896368602 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302896368878 : Closed e302896368878 ∧ code e302896368878 = 4700942879982 := by decide
theorem cert_e302896368878 : check e302896368878 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896368886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302896368886 : Closed e302896368886 ∧ code e302896368886 = 4700942879990 := by decide
theorem cert_e302896368886 : check e302896368886 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896369262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302896369262 : Closed e302896369262 ∧ code e302896369262 = 4700942880366 := by decide
theorem cert_e302896369262 : check e302896369262 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896369274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302896369274 : Closed e302896369274 ∧ code e302896369274 = 4700942880378 := by decide
theorem cert_e302896369274 : check e302896369274 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896369462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302896369462 : Closed e302896369462 ∧ code e302896369462 = 4700942880566 := by decide
theorem cert_e302896369462 : check e302896369462 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302896369466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302896369466 : Closed e302896369466 ∧ code e302896369466 = 4700942880570 := by decide
theorem cert_e302896369466 : check e302896369466 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e302912679278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e302912679278 : Closed e302912679278 ∧ code e302912679278 = 4700959190382 := by decide
theorem cert_e302912679278 : check e302912679278 [[.under],[.under]] .smaller = true := by decide
def e302912679286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e302912679286 : Closed e302912679286 ∧ code e302912679286 = 4700959190390 := by decide
theorem cert_e302912679286 : check e302912679286 [[.under],[.under]] .smaller = true := by decide
def e302912679342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e302912679342 : Closed e302912679342 ∧ code e302912679342 = 4700959190446 := by decide
theorem cert_e302912679342 : check e302912679342 [[.under],[.under]] .smaller = true := by decide
def e302912679354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e302912679354 : Closed e302912679354 ∧ code e302912679354 = 4700959190458 := by decide
theorem cert_e302912679354 : check e302912679354 [[.under],[.under]] .smaller = true := by decide
def e302912679382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e302912679382 : Closed e302912679382 ∧ code e302912679382 = 4700959190486 := by decide
theorem cert_e302912679382 : check e302912679382 [[.under],[.under]] .smaller = true := by decide
def e302912679386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e302912679386 : Closed e302912679386 ∧ code e302912679386 = 4700959190490 := by decide
theorem cert_e302912679386 : check e302912679386 [[.under],[.under]] .smaller = true := by decide
def e302912679598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e302912679598 : Closed e302912679598 ∧ code e302912679598 = 4700959190702 := by decide
theorem cert_e302912679598 : check e302912679598 [[.under],[.under]] .smaller = true := by decide
def e302912679610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e302912679610 : Closed e302912679610 ∧ code e302912679610 = 4700959190714 := by decide
theorem cert_e302912679610 : check e302912679610 [[.under],[.under]] .smaller = true := by decide
def e302912679658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e302912679658 : Closed e302912679658 ∧ code e302912679658 = 4700959190762 := by decide
theorem cert_e302912679658 : check e302912679658 [[.under],[.under]] .smaller = true := by decide
def e302912679766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e302912679766 : Closed e302912679766 ∧ code e302912679766 = 4700959190870 := by decide
theorem cert_e302912679766 : check e302912679766 [[.under],[.under]] .smaller = true := by decide
def e302912679770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e302912679770 : Closed e302912679770 ∧ code e302912679770 = 4700959190874 := by decide
theorem cert_e302912679770 : check e302912679770 [[.under],[.under]] .smaller = true := by decide
def e302912679786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e302912679786 : Closed e302912679786 ∧ code e302912679786 = 4700959190890 := by decide
theorem cert_e302912679786 : check e302912679786 [[.under],[.under]] .smaller = true := by decide
def e302912680814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e302912680814 : Closed e302912680814 ∧ code e302912680814 = 4700959191918 := by decide
theorem cert_e302912680814 : check e302912680814 [[.under],[.under]] .smaller = true := by decide
def e302912680822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e302912680822 : Closed e302912680822 ∧ code e302912680822 = 4700959191926 := by decide
theorem cert_e302912680822 : check e302912680822 [[.under],[.under]] .smaller = true := by decide
def e302912680878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e302912680878 : Closed e302912680878 ∧ code e302912680878 = 4700959191982 := by decide
theorem cert_e302912680878 : check e302912680878 [[.under],[.under]] .smaller = true := by decide
def e302912680890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e302912680890 : Closed e302912680890 ∧ code e302912680890 = 4700959191994 := by decide
theorem cert_e302912680890 : check e302912680890 [[.under],[.under]] .smaller = true := by decide
def e302912680918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e302912680918 : Closed e302912680918 ∧ code e302912680918 = 4700959192022 := by decide
theorem cert_e302912680918 : check e302912680918 [[.under],[.under]] .smaller = true := by decide
def e302912680922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e302912680922 : Closed e302912680922 ∧ code e302912680922 = 4700959192026 := by decide
theorem cert_e302912680922 : check e302912680922 [[.under],[.under]] .smaller = true := by decide
def e302912681198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e302912681198 : Closed e302912681198 ∧ code e302912681198 = 4700959192302 := by decide
theorem cert_e302912681198 : check e302912681198 [[.under],[.under]] .smaller = true := by decide
def e302912681206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e302912681206 : Closed e302912681206 ∧ code e302912681206 = 4700959192310 := by decide
theorem cert_e302912681206 : check e302912681206 [[.under],[.under]] .smaller = true := by decide
def e302912681582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e302912681582 : Closed e302912681582 ∧ code e302912681582 = 4700959192686 := by decide
theorem cert_e302912681582 : check e302912681582 [[.under],[.under]] .smaller = true := by decide
def e302912681594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e302912681594 : Closed e302912681594 ∧ code e302912681594 = 4700959192698 := by decide
theorem cert_e302912681594 : check e302912681594 [[.under],[.under]] .smaller = true := by decide
def e302912681782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302912681782 : Closed e302912681782 ∧ code e302912681782 = 4700959192886 := by decide
theorem cert_e302912681782 : check e302912681782 [[.under],[.under]] .smaller = true := by decide
def e302912681786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302912681786 : Closed e302912681786 ∧ code e302912681786 = 4700959192890 := by decide
theorem cert_e302912681786 : check e302912681786 [[.under],[.under]] .smaller = true := by decide
def e302912682414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e302912682414 : Closed e302912682414 ∧ code e302912682414 = 4700959193518 := by decide
theorem cert_e302912682414 : check e302912682414 [[.under],[.under]] .smaller = true := by decide
def e302912682426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e302912682426 : Closed e302912682426 ∧ code e302912682426 = 4700959193530 := by decide
theorem cert_e302912682426 : check e302912682426 [[.under],[.under]] .smaller = true := by decide
def e302912682474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e302912682474 : Closed e302912682474 ∧ code e302912682474 = 4700959193578 := by decide
theorem cert_e302912682474 : check e302912682474 [[.under],[.under]] .smaller = true := by decide
def e302912682606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e302912682606 : Closed e302912682606 ∧ code e302912682606 = 4700959193710 := by decide
theorem cert_e302912682606 : check e302912682606 [[.under],[.under]] .smaller = true := by decide
def e302912682618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e302912682618 : Closed e302912682618 ∧ code e302912682618 = 4700959193722 := by decide
theorem cert_e302912682618 : check e302912682618 [[.under],[.under]] .smaller = true := by decide
def e302912682906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e302912682906 : Closed e302912682906 ∧ code e302912682906 = 4700959194010 := by decide
theorem cert_e302912682906 : check e302912682906 [[.under],[.under]] .smaller = true := by decide
def e302912683222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e302912683222 : Closed e302912683222 ∧ code e302912683222 = 4700959194326 := by decide
theorem cert_e302912683222 : check e302912683222 [[.under],[.under]] .smaller = true := by decide
def e302912683226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e302912683226 : Closed e302912683226 ∧ code e302912683226 = 4700959194330 := by decide
theorem cert_e302912683226 : check e302912683226 [[.under],[.under]] .smaller = true := by decide
def e302912683242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e302912683242 : Closed e302912683242 ∧ code e302912683242 = 4700959194346 := by decide
theorem cert_e302912683242 : check e302912683242 [[.under],[.under]] .smaller = true := by decide
def e302912683318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302912683318 : Closed e302912683318 ∧ code e302912683318 = 4700959194422 := by decide
theorem cert_e302912683318 : check e302912683318 [[.under],[.under]] .smaller = true := by decide
def e302912683322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302912683322 : Closed e302912683322 ∧ code e302912683322 = 4700959194426 := by decide
theorem cert_e302912683322 : check e302912683322 [[.under],[.under]] .smaller = true := by decide
def e302912683418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e302912683418 : Closed e302912683418 ∧ code e302912683418 = 4700959194522 := by decide
theorem cert_e302912683418 : check e302912683418 [[.under],[.under]] .smaller = true := by decide
def e302912686958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e302912686958 : Closed e302912686958 ∧ code e302912686958 = 4700959198062 := by decide
theorem cert_e302912686958 : check e302912686958 [[.under],[.under]] .smaller = true := by decide
def e302912686966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e302912686966 : Closed e302912686966 ∧ code e302912686966 = 4700959198070 := by decide
theorem cert_e302912686966 : check e302912686966 [[.under],[.under]] .smaller = true := by decide
def e302912687022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e302912687022 : Closed e302912687022 ∧ code e302912687022 = 4700959198126 := by decide
theorem cert_e302912687022 : check e302912687022 [[.under],[.under]] .smaller = true := by decide
def e302912687034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e302912687034 : Closed e302912687034 ∧ code e302912687034 = 4700959198138 := by decide
theorem cert_e302912687034 : check e302912687034 [[.under],[.under]] .smaller = true := by decide
def e302912687062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e302912687062 : Closed e302912687062 ∧ code e302912687062 = 4700959198166 := by decide
theorem cert_e302912687062 : check e302912687062 [[.under],[.under]] .smaller = true := by decide
def e302912687066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e302912687066 : Closed e302912687066 ∧ code e302912687066 = 4700959198170 := by decide
theorem cert_e302912687066 : check e302912687066 [[.under],[.under]] .smaller = true := by decide
def e302912687342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302912687342 : Closed e302912687342 ∧ code e302912687342 = 4700959198446 := by decide
theorem cert_e302912687342 : check e302912687342 [[.under],[.under]] .smaller = true := by decide
def e302912687350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302912687350 : Closed e302912687350 ∧ code e302912687350 = 4700959198454 := by decide
theorem cert_e302912687350 : check e302912687350 [[.under],[.under]] .smaller = true := by decide
def e302912687726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302912687726 : Closed e302912687726 ∧ code e302912687726 = 4700959198830 := by decide
theorem cert_e302912687726 : check e302912687726 [[.under],[.under]] .smaller = true := by decide
def e302912687738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302912687738 : Closed e302912687738 ∧ code e302912687738 = 4700959198842 := by decide
theorem cert_e302912687738 : check e302912687738 [[.under],[.under]] .smaller = true := by decide
def e302912687926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302912687926 : Closed e302912687926 ∧ code e302912687926 = 4700959199030 := by decide
theorem cert_e302912687926 : check e302912687926 [[.under],[.under]] .smaller = true := by decide
def e302912687930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302912687930 : Closed e302912687930 ∧ code e302912687930 = 4700959199034 := by decide
theorem cert_e302912687930 : check e302912687930 [[.under],[.under]] .smaller = true := by decide
def e302912693678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e302912693678 : Closed e302912693678 ∧ code e302912693678 = 4700959204782 := by decide
theorem cert_e302912693678 : check e302912693678 [[.under],[.under]] .smaller = true := by decide
def e302912693690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e302912693690 : Closed e302912693690 ∧ code e302912693690 = 4700959204794 := by decide
theorem cert_e302912693690 : check e302912693690 [[.under],[.under]] .smaller = true := by decide
def e302912693738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e302912693738 : Closed e302912693738 ∧ code e302912693738 = 4700959204842 := by decide
theorem cert_e302912693738 : check e302912693738 [[.under],[.under]] .smaller = true := by decide
def e302912693870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302912693870 : Closed e302912693870 ∧ code e302912693870 = 4700959204974 := by decide
theorem cert_e302912693870 : check e302912693870 [[.under],[.under]] .smaller = true := by decide
def e302912693882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302912693882 : Closed e302912693882 ∧ code e302912693882 = 4700959204986 := by decide
theorem cert_e302912693882 : check e302912693882 [[.under],[.under]] .smaller = true := by decide
def e302912694170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e302912694170 : Closed e302912694170 ∧ code e302912694170 = 4700959205274 := by decide
theorem cert_e302912694170 : check e302912694170 [[.under],[.under]] .smaller = true := by decide
def e302912697046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e302912697046 : Closed e302912697046 ∧ code e302912697046 = 4700959208150 := by decide
theorem cert_e302912697046 : check e302912697046 [[.under],[.under]] .smaller = true := by decide
def e302912697050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e302912697050 : Closed e302912697050 ∧ code e302912697050 = 4700959208154 := by decide
theorem cert_e302912697050 : check e302912697050 [[.under],[.under]] .smaller = true := by decide
def e302912697066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e302912697066 : Closed e302912697066 ∧ code e302912697066 = 4700959208170 := by decide
theorem cert_e302912697066 : check e302912697066 [[.under],[.under]] .smaller = true := by decide
def e302912697142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302912697142 : Closed e302912697142 ∧ code e302912697142 = 4700959208246 := by decide
theorem cert_e302912697142 : check e302912697142 [[.under],[.under]] .smaller = true := by decide
def e302912697146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302912697146 : Closed e302912697146 ∧ code e302912697146 = 4700959208250 := by decide
theorem cert_e302912697146 : check e302912697146 [[.under],[.under]] .smaller = true := by decide
def e302912697242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e302912697242 : Closed e302912697242 ∧ code e302912697242 = 4700959208346 := by decide
theorem cert_e302912697242 : check e302912697242 [[.under],[.under]] .smaller = true := by decide
def e302912812782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e302912812782 : Closed e302912812782 ∧ code e302912812782 = 4700959323886 := by decide
theorem cert_e302912812782 : check e302912812782 [[.under],[.under]] .sourceHead = true := by decide
def e302912812910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e302912812910 : Closed e302912812910 ∧ code e302912812910 = 4700959324014 := by decide
theorem cert_e302912812910 : check e302912812910 [[.under],[.under]] .sourceHead = true := by decide
def e302912812918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e302912812918 : Closed e302912812918 ∧ code e302912812918 = 4700959324022 := by decide
theorem cert_e302912812918 : check e302912812918 [[.under],[.under]] .sourceHead = true := by decide
def e302912813806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e302912813806 : Closed e302912813806 ∧ code e302912813806 = 4700959324910 := by decide
theorem cert_e302912813806 : check e302912813806 [[.under],[.under]] .sourceHead = true := by decide
def e302912813998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e302912813998 : Closed e302912813998 ∧ code e302912813998 = 4700959325102 := by decide
theorem cert_e302912813998 : check e302912813998 [[.under],[.under]] .sourceHead = true := by decide
def e302912814010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e302912814010 : Closed e302912814010 ∧ code e302912814010 = 4700959325114 := by decide
theorem cert_e302912814010 : check e302912814010 [[.under],[.under]] .sourceHead = true := by decide
def e302912814446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302912814446 : Closed e302912814446 ∧ code e302912814446 = 4700959325550 := by decide
theorem cert_e302912814446 : check e302912814446 [[.under],[.under]] .sourceHead = true := by decide
def e302912814454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302912814454 : Closed e302912814454 ∧ code e302912814454 = 4700959325558 := by decide
theorem cert_e302912814454 : check e302912814454 [[.under],[.under]] .sourceHead = true := by decide
def e302912814510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302912814510 : Closed e302912814510 ∧ code e302912814510 = 4700959325614 := by decide
theorem cert_e302912814510 : check e302912814510 [[.under],[.under]] .sourceHead = true := by decide
def e302912814522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302912814522 : Closed e302912814522 ∧ code e302912814522 = 4700959325626 := by decide
theorem cert_e302912814522 : check e302912814522 [[.under],[.under]] .sourceHead = true := by decide
def e302912814550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302912814550 : Closed e302912814550 ∧ code e302912814550 = 4700959325654 := by decide
theorem cert_e302912814550 : check e302912814550 [[.under],[.under]] .sourceHead = true := by decide
def e302912814554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302912814554 : Closed e302912814554 ∧ code e302912814554 = 4700959325658 := by decide
theorem cert_e302912814554 : check e302912814554 [[.under],[.under]] .sourceHead = true := by decide
def e302912818926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e302912818926 : Closed e302912818926 ∧ code e302912818926 = 4700959330030 := by decide
theorem cert_e302912818926 : check e302912818926 [[.under],[.under]] .sourceHead = true := by decide
def e302912819054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e302912819054 : Closed e302912819054 ∧ code e302912819054 = 4700959330158 := by decide
theorem cert_e302912819054 : check e302912819054 [[.under],[.under]] .sourceHead = true := by decide
def e302912819062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e302912819062 : Closed e302912819062 ∧ code e302912819062 = 4700959330166 := by decide
theorem cert_e302912819062 : check e302912819062 [[.under],[.under]] .sourceHead = true := by decide
def e302912821742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e302912821742 : Closed e302912821742 ∧ code e302912821742 = 4700959332846 := by decide
theorem cert_e302912821742 : check e302912821742 [[.under],[.under]] .sourceHead = true := by decide
def e302912822510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302912822510 : Closed e302912822510 ∧ code e302912822510 = 4700959333614 := by decide
theorem cert_e302912822510 : check e302912822510 [[.under],[.under]] .sourceHead = true := by decide
def e302912822518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302912822518 : Closed e302912822518 ∧ code e302912822518 = 4700959333622 := by decide
theorem cert_e302912822518 : check e302912822518 [[.under],[.under]] .sourceHead = true := by decide
def e302912825070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e302912825070 : Closed e302912825070 ∧ code e302912825070 = 4700959336174 := by decide
theorem cert_e302912825070 : check e302912825070 [[.under],[.under]] .sourceHead = true := by decide
def e302912825262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e302912825262 : Closed e302912825262 ∧ code e302912825262 = 4700959336366 := by decide
theorem cert_e302912825262 : check e302912825262 [[.under],[.under]] .sourceHead = true := by decide
def e302912825274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e302912825274 : Closed e302912825274 ∧ code e302912825274 = 4700959336378 := by decide
theorem cert_e302912825274 : check e302912825274 [[.under],[.under]] .sourceHead = true := by decide
def e302912825838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e302912825838 : Closed e302912825838 ∧ code e302912825838 = 4700959336942 := by decide
theorem cert_e302912825838 : check e302912825838 [[.under],[.under]] .sourceHead = true := by decide
def e302912826990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302912826990 : Closed e302912826990 ∧ code e302912826990 = 4700959338094 := by decide
theorem cert_e302912826990 : check e302912826990 [[.under],[.under]] .sourceHead = true := by decide
def e302912827002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302912827002 : Closed e302912827002 ∧ code e302912827002 = 4700959338106 := by decide
theorem cert_e302912827002 : check e302912827002 [[.under],[.under]] .sourceHead = true := by decide
def e302912828270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302912828270 : Closed e302912828270 ∧ code e302912828270 = 4700959339374 := by decide
theorem cert_e302912828270 : check e302912828270 [[.under],[.under]] .sourceHead = true := by decide
def e302912828278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302912828278 : Closed e302912828278 ∧ code e302912828278 = 4700959339382 := by decide
theorem cert_e302912828278 : check e302912828278 [[.under],[.under]] .sourceHead = true := by decide
def e302912828334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302912828334 : Closed e302912828334 ∧ code e302912828334 = 4700959339438 := by decide
theorem cert_e302912828334 : check e302912828334 [[.under],[.under]] .sourceHead = true := by decide
def e302912828346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302912828346 : Closed e302912828346 ∧ code e302912828346 = 4700959339450 := by decide
theorem cert_e302912828346 : check e302912828346 [[.under],[.under]] .sourceHead = true := by decide
def e302912828374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302912828374 : Closed e302912828374 ∧ code e302912828374 = 4700959339478 := by decide
theorem cert_e302912828374 : check e302912828374 [[.under],[.under]] .sourceHead = true := by decide
def e302912828378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302912828378 : Closed e302912828378 ∧ code e302912828378 = 4700959339482 := by decide
theorem cert_e302912828378 : check e302912828378 [[.under],[.under]] .sourceHead = true := by decide
def e302912828654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302912828654 : Closed e302912828654 ∧ code e302912828654 = 4700959339758 := by decide
theorem cert_e302912828654 : check e302912828654 [[.under],[.under]] .sourceHead = true := by decide
def e302912828662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302912828662 : Closed e302912828662 ∧ code e302912828662 = 4700959339766 := by decide
theorem cert_e302912828662 : check e302912828662 [[.under],[.under]] .sourceHead = true := by decide
def e302912829038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302912829038 : Closed e302912829038 ∧ code e302912829038 = 4700959340142 := by decide
theorem cert_e302912829038 : check e302912829038 [[.under],[.under]] .sourceHead = true := by decide
def e302912829050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302912829050 : Closed e302912829050 ∧ code e302912829050 = 4700959340154 := by decide
theorem cert_e302912829050 : check e302912829050 [[.under],[.under]] .sourceHead = true := by decide
def e302912829238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302912829238 : Closed e302912829238 ∧ code e302912829238 = 4700959340342 := by decide
theorem cert_e302912829238 : check e302912829238 [[.under],[.under]] .sourceHead = true := by decide
def e302912829242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302912829242 : Closed e302912829242 ∧ code e302912829242 = 4700959340346 := by decide
theorem cert_e302912829242 : check e302912829242 [[.under],[.under]] .sourceHead = true := by decide
def e302912834414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e302912834414 : Closed e302912834414 ∧ code e302912834414 = 4700959345518 := by decide
theorem cert_e302912834414 : check e302912834414 [[.under],[.under]] .smaller = true := by decide
def e302912834422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e302912834422 : Closed e302912834422 ∧ code e302912834422 = 4700959345526 := by decide
theorem cert_e302912834422 : check e302912834422 [[.under],[.under]] .smaller = true := by decide
def e302912834478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e302912834478 : Closed e302912834478 ∧ code e302912834478 = 4700959345582 := by decide
theorem cert_e302912834478 : check e302912834478 [[.under],[.under]] .smaller = true := by decide
def e302912834490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e302912834490 : Closed e302912834490 ∧ code e302912834490 = 4700959345594 := by decide
theorem cert_e302912834490 : check e302912834490 [[.under],[.under]] .smaller = true := by decide
def e302912834518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e302912834518 : Closed e302912834518 ∧ code e302912834518 = 4700959345622 := by decide
theorem cert_e302912834518 : check e302912834518 [[.under],[.under]] .smaller = true := by decide
def e302912834522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e302912834522 : Closed e302912834522 ∧ code e302912834522 = 4700959345626 := by decide
theorem cert_e302912834522 : check e302912834522 [[.under],[.under]] .smaller = true := by decide
def e302912834798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302912834798 : Closed e302912834798 ∧ code e302912834798 = 4700959345902 := by decide
theorem cert_e302912834798 : check e302912834798 [[.under],[.under]] .smaller = true := by decide
def e302912834806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302912834806 : Closed e302912834806 ∧ code e302912834806 = 4700959345910 := by decide
theorem cert_e302912834806 : check e302912834806 [[.under],[.under]] .smaller = true := by decide
def e302912835182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302912835182 : Closed e302912835182 ∧ code e302912835182 = 4700959346286 := by decide
theorem cert_e302912835182 : check e302912835182 [[.under],[.under]] .smaller = true := by decide
def e302912835194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302912835194 : Closed e302912835194 ∧ code e302912835194 = 4700959346298 := by decide
theorem cert_e302912835194 : check e302912835194 [[.under],[.under]] .smaller = true := by decide
def e302912835382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302912835382 : Closed e302912835382 ∧ code e302912835382 = 4700959346486 := by decide
theorem cert_e302912835382 : check e302912835382 [[.under],[.under]] .smaller = true := by decide
def e302912835386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302912835386 : Closed e302912835386 ∧ code e302912835386 = 4700959346490 := by decide
theorem cert_e302912835386 : check e302912835386 [[.under],[.under]] .smaller = true := by decide
def e302912843502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e302912843502 : Closed e302912843502 ∧ code e302912843502 = 4700959354606 := by decide
theorem cert_e302912843502 : check e302912843502 [[.under],[.under]] .sourceHead = true := by decide
def e302912843630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e302912843630 : Closed e302912843630 ∧ code e302912843630 = 4700959354734 := by decide
theorem cert_e302912843630 : check e302912843630 [[.under],[.under]] .sourceHead = true := by decide
def e302912843638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e302912843638 : Closed e302912843638 ∧ code e302912843638 = 4700959354742 := by decide
theorem cert_e302912843638 : check e302912843638 [[.under],[.under]] .sourceHead = true := by decide
def e302912846318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e302912846318 : Closed e302912846318 ∧ code e302912846318 = 4700959357422 := by decide
theorem cert_e302912846318 : check e302912846318 [[.under],[.under]] .sourceHead = true := by decide
def e302912847086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e302912847086 : Closed e302912847086 ∧ code e302912847086 = 4700959358190 := by decide
theorem cert_e302912847086 : check e302912847086 [[.under],[.under]] .sourceHead = true := by decide
def e302912847094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e302912847094 : Closed e302912847094 ∧ code e302912847094 = 4700959358198 := by decide
theorem cert_e302912847094 : check e302912847094 [[.under],[.under]] .sourceHead = true := by decide
def e302912870126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e302912870126 : Closed e302912870126 ∧ code e302912870126 = 4700959381230 := by decide
theorem cert_e302912870126 : check e302912870126 [[.under],[.under]] .sourceHead = true := by decide
def e302912870318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e302912870318 : Closed e302912870318 ∧ code e302912870318 = 4700959381422 := by decide
theorem cert_e302912870318 : check e302912870318 [[.under],[.under]] .sourceHead = true := by decide
def e302912870330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e302912870330 : Closed e302912870330 ∧ code e302912870330 = 4700959381434 := by decide
theorem cert_e302912870330 : check e302912870330 [[.under],[.under]] .sourceHead = true := by decide
def e302912870894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e302912870894 : Closed e302912870894 ∧ code e302912870894 = 4700959381998 := by decide
theorem cert_e302912870894 : check e302912870894 [[.under],[.under]] .sourceHead = true := by decide
end Blc.Floor42
