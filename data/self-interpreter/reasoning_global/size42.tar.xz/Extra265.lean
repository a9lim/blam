import Batch265
import ExtraBase
namespace Blc.Floor42.Extra265
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211608620910 : Term := (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.lam (.lam (.app (.app (.var 6) (.var 1)) (.var 2))))))) (.var 2)))))))))))
theorem ex_e1211608620910 : ¬ IsSelfInterpreter e1211608620910 := by
  intro he
  have hp := replay_sound (t := e1211608620910) (u := t_e1211608620910) (ps := [[],[],[.right,.right,.under,.under,.under,.left],[],[.left],[.left],[.left,.under,.under,.right],[.left,.under,.under,.right,.under,.under,.right,.under,.under,.under,.left],[.left,.under,.under,.right,.under,.under,.right,.under,.under,.under],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.var 2)))))) (.var 1)) (.var 2)))))) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.lam (.lam (.app (.app (.var 6) (.var 1)) (.var 2))))))) (.var 2))))))))))) h
#print axioms ex_e1211608620910
private def t_e1211608628462 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2))))))) (.app (.var 1) (.var 2))))))) (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2)))))) (.app (.var 1) (.var 2))))))))))
theorem ex_e1211608628462 : ¬ IsSelfInterpreter e1211608628462 := by
  intro he
  have hp := replay_sound (t := e1211608628462) (u := t_e1211608628462) (ps := [[],[],[],[.left],[.left],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2))))))) (.app (.var 1) (.var 2))))))) (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.app (.var 1) (.var 2)))))) (.app (.var 1) (.var 2)))))))))) h
#print axioms ex_e1211608628462
private def t_e1211608628470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1)))))) (.app (.var 2) (.var 1))))))) (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1))))))) (.app (.var 2) (.var 1))))))))))
theorem ex_e1211608628470 : ¬ IsSelfInterpreter e1211608628470 := by
  intro he
  have hp := replay_sound (t := e1211608628470) (u := t_e1211608628470) (ps := [[],[],[],[.left],[.left],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1)))))) (.app (.var 2) (.var 1))))))) (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.app (.var 2) (.var 1))))))) (.app (.var 2) (.var 1)))))))))) h
#print axioms ex_e1211608628470
private def t_e1211608685422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem ex_e1211608685422 : ¬ IsSelfInterpreter e1211608685422 := by
  intro he
  have hp := replay_sound (t := e1211608685422) (u := t_e1211608685422) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608685422) (by decide) (by decide) hj
#print axioms ex_e1211608685422
private def t_e1211608685934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem ex_e1211608685934 : ¬ IsSelfInterpreter e1211608685934 := by
  intro he
  have hp := replay_sound (t := e1211608685934) (u := t_e1211608685934) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608685934) (by decide) (by decide) hj
#print axioms ex_e1211608685934
private def t_e1211608688494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem ex_e1211608688494 : ¬ IsSelfInterpreter e1211608688494 := by
  intro he
  have hp := replay_sound (t := e1211608688494) (u := t_e1211608688494) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608688494) (by decide) (by decide) hj
#print axioms ex_e1211608688494
private def t_e1211608689902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1211608689902 : ¬ IsSelfInterpreter e1211608689902 := by
  intro he
  have hp := replay_sound (t := e1211608689902) (u := t_e1211608689902) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608689902) (by decide) (by decide) hj
#print axioms ex_e1211608689902
private def t_e1211608689910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem ex_e1211608689910 : ¬ IsSelfInterpreter e1211608689910 := by
  intro he
  have hp := replay_sound (t := e1211608689910) (u := t_e1211608689910) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608689910) (by decide) (by decide) hj
#print axioms ex_e1211608689910
private def t_e1211608690294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem ex_e1211608690294 : ¬ IsSelfInterpreter e1211608690294 := by
  intro he
  have hp := replay_sound (t := e1211608690294) (u := t_e1211608690294) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608690294) (by decide) (by decide) hj
#print axioms ex_e1211608690294
private def t_e1211608691566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem ex_e1211608691566 : ¬ IsSelfInterpreter e1211608691566 := by
  intro he
  have hp := replay_sound (t := e1211608691566) (u := t_e1211608691566) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608691566) (by decide) (by decide) hj
#print axioms ex_e1211608691566
private def t_e1211608691630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem ex_e1211608691630 : ¬ IsSelfInterpreter e1211608691630 := by
  intro he
  have hp := replay_sound (t := e1211608691630) (u := t_e1211608691630) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608691630) (by decide) (by decide) hj
#print axioms ex_e1211608691630
private def t_e1211608691950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem ex_e1211608691950 : ¬ IsSelfInterpreter e1211608691950 := by
  intro he
  have hp := replay_sound (t := e1211608691950) (u := t_e1211608691950) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608691950) (by decide) (by decide) hj
#print axioms ex_e1211608691950
private def t_e1211608691958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem ex_e1211608691958 : ¬ IsSelfInterpreter e1211608691958 := by
  intro he
  have hp := replay_sound (t := e1211608691958) (u := t_e1211608691958) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608691958) (by decide) (by decide) hj
#print axioms ex_e1211608691958
private def t_e1211608693366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem ex_e1211608693366 : ¬ IsSelfInterpreter e1211608693366 := by
  intro he
  have hp := replay_sound (t := e1211608693366) (u := t_e1211608693366) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608693366) (by decide) (by decide) hj
#print axioms ex_e1211608693366
private def t_e1211608700782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem ex_e1211608700782 : ¬ IsSelfInterpreter e1211608700782 := by
  intro he
  have hp := replay_sound (t := e1211608700782) (u := t_e1211608700782) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2))) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608700782
private def t_e1211608700790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem ex_e1211608700790 : ¬ IsSelfInterpreter e1211608700790 := by
  intro he
  have hp := replay_sound (t := e1211608700790) (u := t_e1211608700790) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1))) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608700790
private def t_e1211608700854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem ex_e1211608700854 : ¬ IsSelfInterpreter e1211608700854 := by
  intro he
  have hp := replay_sound (t := e1211608700854) (u := t_e1211608700854) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608700854
private def t_e1211608702190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem ex_e1211608702190 : ¬ IsSelfInterpreter e1211608702190 := by
  intro he
  have hp := replay_sound (t := e1211608702190) (u := t_e1211608702190) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 0) (.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 1) (SO.var 2)))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 1))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608702190
private def t_e1211608702198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem ex_e1211608702198 : ¬ IsSelfInterpreter e1211608702198 := by
  intro he
  have hp := replay_sound (t := e1211608702198) (u := t_e1211608702198) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 1) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 2) (SO.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608702198
private def t_e1211608702582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem ex_e1211608702582 : ¬ IsSelfInterpreter e1211608702582 := by
  intro he
  have hp := replay_sound (t := e1211608702582) (u := t_e1211608702582) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1)))) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))))
#print axioms ex_e1211608702582
private def t_e1211608720822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem ex_e1211608720822 : ¬ IsSelfInterpreter e1211608720822 := by
  intro he
  have hp := replay_sound (t := e1211608720822) (u := t_e1211608720822) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608720822) (by decide) (by decide) hj
#print axioms ex_e1211608720822
private def t_e1211608720854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem ex_e1211608720854 : ¬ IsSelfInterpreter e1211608720854 := by
  intro he
  have hp := replay_sound (t := e1211608720854) (u := t_e1211608720854) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608720854) (by decide) (by decide) hj
#print axioms ex_e1211608720854
private def t_e1211608721014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem ex_e1211608721014 : ¬ IsSelfInterpreter e1211608721014 := by
  intro he
  have hp := replay_sound (t := e1211608721014) (u := t_e1211608721014) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608721014) (by decide) (by decide) hj
#print axioms ex_e1211608721014
private def t_e1211608721206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem ex_e1211608721206 : ¬ IsSelfInterpreter e1211608721206 := by
  intro he
  have hp := replay_sound (t := e1211608721206) (u := t_e1211608721206) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608721206) (by decide) (by decide) hj
#print axioms ex_e1211608721206
private def t_e1211608721210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem ex_e1211608721210 : ¬ IsSelfInterpreter e1211608721210 := by
  intro he
  have hp := replay_sound (t := e1211608721210) (u := t_e1211608721210) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211608721210) (by decide) (by decide) hj
#print axioms ex_e1211608721210
end Blc.Floor42.Extra265
