import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194168775638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1194168775638 : Closed e1194168775638 ∧ code e1194168775638 = 5592215286742 := by decide
theorem cert_e1194168775638 : check e1194168775638 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1194168775642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1194168775642 : Closed e1194168775642 ∧ code e1194168775642 = 5592215286746 := by decide
theorem cert_e1194168775642 : check e1194168775642 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e1194168775918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194168775918 : Closed e1194168775918 ∧ code e1194168775918 = 5592215287022 := by decide
theorem cert_e1194168775918 : check e1194168775918 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1194168775926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194168775926 : Closed e1194168775926 ∧ code e1194168775926 = 5592215287030 := by decide
theorem cert_e1194168775926 : check e1194168775926 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1194168776302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194168776302 : Closed e1194168776302 ∧ code e1194168776302 = 5592215287406 := by decide
theorem cert_e1194168776302 : check e1194168776302 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e1194168776314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194168776314 : Closed e1194168776314 ∧ code e1194168776314 = 5592215287418 := by decide
theorem cert_e1194168776314 : check e1194168776314 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e1194168776502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194168776502 : Closed e1194168776502 ∧ code e1194168776502 = 5592215287606 := by decide
theorem cert_e1194168776502 : check e1194168776502 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1194168776506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194168776506 : Closed e1194168776506 ∧ code e1194168776506 = 5592215287610 := by decide
theorem cert_e1194168776506 : check e1194168776506 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1194168777142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1194168777142 : Closed e1194168777142 ∧ code e1194168777142 = 5592215288246 := by decide
theorem cert_e1194168777142 : check e1194168777142 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194168777174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1194168777174 : Closed e1194168777174 ∧ code e1194168777174 = 5592215288278 := by decide
theorem cert_e1194168777174 : check e1194168777174 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194168777178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1194168777178 : Closed e1194168777178 ∧ code e1194168777178 = 5592215288282 := by decide
theorem cert_e1194168777178 : check e1194168777178 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194168777334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1194168777334 : Closed e1194168777334 ∧ code e1194168777334 = 5592215288438 := by decide
theorem cert_e1194168777334 : check e1194168777334 [[],[.left],[],[.under,.left],[.under],[.under]] .three = true := by decide
def e1194168777526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194168777526 : Closed e1194168777526 ∧ code e1194168777526 = 5592215288630 := by decide
theorem cert_e1194168777526 : check e1194168777526 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194168777530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194168777530 : Closed e1194168777530 ∧ code e1194168777530 = 5592215288634 := by decide
theorem cert_e1194168777530 : check e1194168777530 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e1194168784750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1194168784750 : Closed e1194168784750 ∧ code e1194168784750 = 5592215295854 := by decide
theorem cert_e1194168784750 : check e1194168784750 [[],[.left],[]] .sourceHead = true := by decide
def e1194168784758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1194168784758 : Closed e1194168784758 ∧ code e1194168784758 = 5592215295862 := by decide
theorem cert_e1194168784758 : check e1194168784758 [[],[.left],[]] .sourceHead = true := by decide
def e1194168784822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1194168784822 : Closed e1194168784822 ∧ code e1194168784822 = 5592215295926 := by decide
theorem cert_e1194168784822 : check e1194168784822 [[],[.left],[]] .sourceHead = true := by decide
def e1194168786158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1194168786158 : Closed e1194168786158 ∧ code e1194168786158 = 5592215297262 := by decide
theorem cert_e1194168786158 : check e1194168786158 [[],[.left],[]] .sourceHead = true := by decide
def e1194168786166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1194168786166 : Closed e1194168786166 ∧ code e1194168786166 = 5592215297270 := by decide
theorem cert_e1194168786166 : check e1194168786166 [[],[.left],[]] .sourceHead = true := by decide
def e1194168786550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1194168786550 : Closed e1194168786550 ∧ code e1194168786550 = 5592215297654 := by decide
theorem cert_e1194168786550 : check e1194168786550 [[],[.left],[]] .sourceHead = true := by decide
def e1194168798062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194168798062 : Closed e1194168798062 ∧ code e1194168798062 = 5592215309166 := by decide
theorem cert_e1194168798062 : check e1194168798062 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194168798070 : Closed e1194168798070 ∧ code e1194168798070 = 5592215309174 := by decide
theorem cert_e1194168798070 : check e1194168798070 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194168798126 : Closed e1194168798126 ∧ code e1194168798126 = 5592215309230 := by decide
theorem cert_e1194168798126 : check e1194168798126 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194168798138 : Closed e1194168798138 ∧ code e1194168798138 = 5592215309242 := by decide
theorem cert_e1194168798138 : check e1194168798138 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194168798166 : Closed e1194168798166 ∧ code e1194168798166 = 5592215309270 := by decide
theorem cert_e1194168798166 : check e1194168798166 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194168798170 : Closed e1194168798170 ∧ code e1194168798170 = 5592215309274 := by decide
theorem cert_e1194168798170 : check e1194168798170 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194168798446 : Closed e1194168798446 ∧ code e1194168798446 = 5592215309550 := by decide
theorem cert_e1194168798446 : check e1194168798446 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194168798454 : Closed e1194168798454 ∧ code e1194168798454 = 5592215309558 := by decide
theorem cert_e1194168798454 : check e1194168798454 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194168798830 : Closed e1194168798830 ∧ code e1194168798830 = 5592215309934 := by decide
theorem cert_e1194168798830 : check e1194168798830 [[],[.left],[],[.under]] .three = true := by decide
def e1194168798842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194168798842 : Closed e1194168798842 ∧ code e1194168798842 = 5592215309946 := by decide
theorem cert_e1194168798842 : check e1194168798842 [[],[.left],[],[.under]] .three = true := by decide
def e1194168799030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194168799030 : Closed e1194168799030 ∧ code e1194168799030 = 5592215310134 := by decide
theorem cert_e1194168799030 : check e1194168799030 [[],[.left],[],[.under]] .three = true := by decide
def e1194168799034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194168799034 : Closed e1194168799034 ∧ code e1194168799034 = 5592215310138 := by decide
theorem cert_e1194168799034 : check e1194168799034 [[],[.left],[],[.under]] .three = true := by decide
def e1194168804790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1194168804790 : Closed e1194168804790 ∧ code e1194168804790 = 5592215315894 := by decide
theorem cert_e1194168804790 : check e1194168804790 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194168804822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1194168804822 : Closed e1194168804822 ∧ code e1194168804822 = 5592215315926 := by decide
theorem cert_e1194168804822 : check e1194168804822 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194168804826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1194168804826 : Closed e1194168804826 ∧ code e1194168804826 = 5592215315930 := by decide
theorem cert_e1194168804826 : check e1194168804826 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194168804982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1194168804982 : Closed e1194168804982 ∧ code e1194168804982 = 5592215316086 := by decide
theorem cert_e1194168804982 : check e1194168804982 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194168805174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1194168805174 : Closed e1194168805174 ∧ code e1194168805174 = 5592215316278 := by decide
theorem cert_e1194168805174 : check e1194168805174 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194168805178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1194168805178 : Closed e1194168805178 ∧ code e1194168805178 = 5592215316282 := by decide
theorem cert_e1194168805178 : check e1194168805178 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194169142126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194169142126 : Closed e1194169142126 ∧ code e1194169142126 = 5592215653230 := by decide
theorem cert_e1194169142126 : check e1194169142126 [[],[.left]] .chain = true := by decide
def e1194169142134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194169142134 : Closed e1194169142134 ∧ code e1194169142134 = 5592215653238 := by decide
theorem cert_e1194169142134 : check e1194169142134 [[],[.left]] .chain = true := by decide
def e1194169142190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194169142190 : Closed e1194169142190 ∧ code e1194169142190 = 5592215653294 := by decide
theorem cert_e1194169142190 : check e1194169142190 [[],[.left]] .chain = true := by decide
def e1194169142202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194169142202 : Closed e1194169142202 ∧ code e1194169142202 = 5592215653306 := by decide
theorem cert_e1194169142202 : check e1194169142202 [[],[.left]] .chain = true := by decide
def e1194169142230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194169142230 : Closed e1194169142230 ∧ code e1194169142230 = 5592215653334 := by decide
theorem cert_e1194169142230 : check e1194169142230 [[],[.left]] .chain = true := by decide
def e1194169142234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194169142234 : Closed e1194169142234 ∧ code e1194169142234 = 5592215653338 := by decide
theorem cert_e1194169142234 : check e1194169142234 [[],[.left]] .chain = true := by decide
def e1194169142510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194169142510 : Closed e1194169142510 ∧ code e1194169142510 = 5592215653614 := by decide
theorem cert_e1194169142510 : check e1194169142510 [[],[.left]] .chain = true := by decide
def e1194169142518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194169142518 : Closed e1194169142518 ∧ code e1194169142518 = 5592215653622 := by decide
theorem cert_e1194169142518 : check e1194169142518 [[],[.left]] .chain = true := by decide
def e1194169142894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194169142894 : Closed e1194169142894 ∧ code e1194169142894 = 5592215653998 := by decide
theorem cert_e1194169142894 : check e1194169142894 [[],[.left]] .chain = true := by decide
def e1194169142906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194169142906 : Closed e1194169142906 ∧ code e1194169142906 = 5592215654010 := by decide
theorem cert_e1194169142906 : check e1194169142906 [[],[.left]] .chain = true := by decide
def e1194169143094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194169143094 : Closed e1194169143094 ∧ code e1194169143094 = 5592215654198 := by decide
theorem cert_e1194169143094 : check e1194169143094 [[],[.left]] .chain = true := by decide
def e1194169143098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194169143098 : Closed e1194169143098 ∧ code e1194169143098 = 5592215654202 := by decide
theorem cert_e1194169143098 : check e1194169143098 [[],[.left]] .chain = true := by decide
def e1194219056494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1194219056494 : Closed e1194219056494 ∧ code e1194219056494 = 5592265567598 := by decide
theorem cert_e1194219056494 : check e1194219056494 [[],[.left],[]] .chain = true := by decide
def e1194219056502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1194219056502 : Closed e1194219056502 ∧ code e1194219056502 = 5592265567606 := by decide
theorem cert_e1194219056502 : check e1194219056502 [[],[.left],[]] .chain = true := by decide
def e1194219056558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1194219056558 : Closed e1194219056558 ∧ code e1194219056558 = 5592265567662 := by decide
theorem cert_e1194219056558 : check e1194219056558 [[],[.left],[]] .chain = true := by decide
def e1194219056570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1194219056570 : Closed e1194219056570 ∧ code e1194219056570 = 5592265567674 := by decide
theorem cert_e1194219056570 : check e1194219056570 [[],[.left],[]] .chain = true := by decide
def e1194219056598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1194219056598 : Closed e1194219056598 ∧ code e1194219056598 = 5592265567702 := by decide
theorem cert_e1194219056598 : check e1194219056598 [[],[.left],[]] .chain = true := by decide
def e1194219056602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1194219056602 : Closed e1194219056602 ∧ code e1194219056602 = 5592265567706 := by decide
theorem cert_e1194219056602 : check e1194219056602 [[],[.left],[]] .chain = true := by decide
def e1194219056814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1194219056814 : Closed e1194219056814 ∧ code e1194219056814 = 5592265567918 := by decide
theorem cert_e1194219056814 : check e1194219056814 [[],[.left],[]] .chain = true := by decide
def e1194219056826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1194219056826 : Closed e1194219056826 ∧ code e1194219056826 = 5592265567930 := by decide
theorem cert_e1194219056826 : check e1194219056826 [[],[.left],[]] .chain = true := by decide
def e1194219056874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1194219056874 : Closed e1194219056874 ∧ code e1194219056874 = 5592265567978 := by decide
theorem cert_e1194219056874 : check e1194219056874 [[],[.left],[]] .chain = true := by decide
def e1194219056982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1194219056982 : Closed e1194219056982 ∧ code e1194219056982 = 5592265568086 := by decide
theorem cert_e1194219056982 : check e1194219056982 [[],[.left],[]] .chain = true := by decide
def e1194219056986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1194219056986 : Closed e1194219056986 ∧ code e1194219056986 = 5592265568090 := by decide
theorem cert_e1194219056986 : check e1194219056986 [[],[.left],[]] .chain = true := by decide
def e1194219057002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1194219057002 : Closed e1194219057002 ∧ code e1194219057002 = 5592265568106 := by decide
theorem cert_e1194219057002 : check e1194219057002 [[],[.left],[]] .chain = true := by decide
def e1194219058030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1194219058030 : Closed e1194219058030 ∧ code e1194219058030 = 5592265569134 := by decide
theorem cert_e1194219058030 : check e1194219058030 [[],[.left],[]] .chain = true := by decide
def e1194219058038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1194219058038 : Closed e1194219058038 ∧ code e1194219058038 = 5592265569142 := by decide
theorem cert_e1194219058038 : check e1194219058038 [[],[.left],[]] .chain = true := by decide
def e1194219058094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1194219058094 : Closed e1194219058094 ∧ code e1194219058094 = 5592265569198 := by decide
theorem cert_e1194219058094 : check e1194219058094 [[],[.left],[]] .chain = true := by decide
def e1194219058106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1194219058106 : Closed e1194219058106 ∧ code e1194219058106 = 5592265569210 := by decide
theorem cert_e1194219058106 : check e1194219058106 [[],[.left],[]] .chain = true := by decide
def e1194219058134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1194219058134 : Closed e1194219058134 ∧ code e1194219058134 = 5592265569238 := by decide
theorem cert_e1194219058134 : check e1194219058134 [[],[.left],[]] .chain = true := by decide
def e1194219058138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1194219058138 : Closed e1194219058138 ∧ code e1194219058138 = 5592265569242 := by decide
theorem cert_e1194219058138 : check e1194219058138 [[],[.left],[]] .chain = true := by decide
def e1194219058414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194219058414 : Closed e1194219058414 ∧ code e1194219058414 = 5592265569518 := by decide
theorem cert_e1194219058414 : check e1194219058414 [[],[.left],[]] .chain = true := by decide
def e1194219058422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194219058422 : Closed e1194219058422 ∧ code e1194219058422 = 5592265569526 := by decide
theorem cert_e1194219058422 : check e1194219058422 [[],[.left],[]] .chain = true := by decide
def e1194219058798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194219058798 : Closed e1194219058798 ∧ code e1194219058798 = 5592265569902 := by decide
theorem cert_e1194219058798 : check e1194219058798 [[],[.left],[]] .chain = true := by decide
def e1194219058810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194219058810 : Closed e1194219058810 ∧ code e1194219058810 = 5592265569914 := by decide
theorem cert_e1194219058810 : check e1194219058810 [[],[.left],[]] .chain = true := by decide
def e1194219058998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194219058998 : Closed e1194219058998 ∧ code e1194219058998 = 5592265570102 := by decide
theorem cert_e1194219058998 : check e1194219058998 [[],[.left],[]] .chain = true := by decide
def e1194219059002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194219059002 : Closed e1194219059002 ∧ code e1194219059002 = 5592265570106 := by decide
theorem cert_e1194219059002 : check e1194219059002 [[],[.left],[]] .chain = true := by decide
def e1194219059630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1194219059630 : Closed e1194219059630 ∧ code e1194219059630 = 5592265570734 := by decide
theorem cert_e1194219059630 : check e1194219059630 [[],[.left],[]] .chain = true := by decide
def e1194219059642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1194219059642 : Closed e1194219059642 ∧ code e1194219059642 = 5592265570746 := by decide
theorem cert_e1194219059642 : check e1194219059642 [[],[.left],[]] .chain = true := by decide
def e1194219059690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1194219059690 : Closed e1194219059690 ∧ code e1194219059690 = 5592265570794 := by decide
theorem cert_e1194219059690 : check e1194219059690 [[],[.left],[]] .chain = true := by decide
def e1194219059822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194219059822 : Closed e1194219059822 ∧ code e1194219059822 = 5592265570926 := by decide
theorem cert_e1194219059822 : check e1194219059822 [[],[.left],[]] .chain = true := by decide
def e1194219059834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194219059834 : Closed e1194219059834 ∧ code e1194219059834 = 5592265570938 := by decide
theorem cert_e1194219059834 : check e1194219059834 [[],[.left],[]] .chain = true := by decide
def e1194219060122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194219060122 : Closed e1194219060122 ∧ code e1194219060122 = 5592265571226 := by decide
theorem cert_e1194219060122 : check e1194219060122 [[],[.left],[]] .chain = true := by decide
def e1194219060438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1194219060438 : Closed e1194219060438 ∧ code e1194219060438 = 5592265571542 := by decide
theorem cert_e1194219060438 : check e1194219060438 [[],[.left],[]] .chain = true := by decide
def e1194219060442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1194219060442 : Closed e1194219060442 ∧ code e1194219060442 = 5592265571546 := by decide
theorem cert_e1194219060442 : check e1194219060442 [[],[.left],[]] .chain = true := by decide
def e1194219060458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1194219060458 : Closed e1194219060458 ∧ code e1194219060458 = 5592265571562 := by decide
theorem cert_e1194219060458 : check e1194219060458 [[],[.left],[]] .chain = true := by decide
def e1194219060534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194219060534 : Closed e1194219060534 ∧ code e1194219060534 = 5592265571638 := by decide
theorem cert_e1194219060534 : check e1194219060534 [[],[.left],[]] .chain = true := by decide
def e1194219060538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194219060538 : Closed e1194219060538 ∧ code e1194219060538 = 5592265571642 := by decide
theorem cert_e1194219060538 : check e1194219060538 [[],[.left],[]] .chain = true := by decide
def e1194219060634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194219060634 : Closed e1194219060634 ∧ code e1194219060634 = 5592265571738 := by decide
theorem cert_e1194219060634 : check e1194219060634 [[],[.left],[]] .chain = true := by decide
def e1194219064174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194219064174 : Closed e1194219064174 ∧ code e1194219064174 = 5592265575278 := by decide
theorem cert_e1194219064174 : check e1194219064174 [[],[.left],[]] .chain = true := by decide
def e1194219064182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194219064182 : Closed e1194219064182 ∧ code e1194219064182 = 5592265575286 := by decide
theorem cert_e1194219064182 : check e1194219064182 [[],[.left],[]] .chain = true := by decide
def e1194219064238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194219064238 : Closed e1194219064238 ∧ code e1194219064238 = 5592265575342 := by decide
theorem cert_e1194219064238 : check e1194219064238 [[],[.left],[]] .chain = true := by decide
def e1194219064250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194219064250 : Closed e1194219064250 ∧ code e1194219064250 = 5592265575354 := by decide
theorem cert_e1194219064250 : check e1194219064250 [[],[.left],[]] .chain = true := by decide
def e1194219064278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194219064278 : Closed e1194219064278 ∧ code e1194219064278 = 5592265575382 := by decide
theorem cert_e1194219064278 : check e1194219064278 [[],[.left],[]] .chain = true := by decide
def e1194219064282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194219064282 : Closed e1194219064282 ∧ code e1194219064282 = 5592265575386 := by decide
theorem cert_e1194219064282 : check e1194219064282 [[],[.left],[]] .chain = true := by decide
def e1194219064558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194219064558 : Closed e1194219064558 ∧ code e1194219064558 = 5592265575662 := by decide
theorem cert_e1194219064558 : check e1194219064558 [[],[.left],[]] .chain = true := by decide
def e1194219064566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194219064566 : Closed e1194219064566 ∧ code e1194219064566 = 5592265575670 := by decide
theorem cert_e1194219064566 : check e1194219064566 [[],[.left],[]] .chain = true := by decide
def e1194219064942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194219064942 : Closed e1194219064942 ∧ code e1194219064942 = 5592265576046 := by decide
theorem cert_e1194219064942 : check e1194219064942 [[],[.left],[]] .chain = true := by decide
def e1194219064954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194219064954 : Closed e1194219064954 ∧ code e1194219064954 = 5592265576058 := by decide
theorem cert_e1194219064954 : check e1194219064954 [[],[.left],[]] .chain = true := by decide
def e1194219065142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194219065142 : Closed e1194219065142 ∧ code e1194219065142 = 5592265576246 := by decide
theorem cert_e1194219065142 : check e1194219065142 [[],[.left],[]] .chain = true := by decide
def e1194219065146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194219065146 : Closed e1194219065146 ∧ code e1194219065146 = 5592265576250 := by decide
theorem cert_e1194219065146 : check e1194219065146 [[],[.left],[]] .chain = true := by decide
def e1194219070894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1194219070894 : Closed e1194219070894 ∧ code e1194219070894 = 5592265581998 := by decide
theorem cert_e1194219070894 : check e1194219070894 [[],[.left],[]] .chain = true := by decide
def e1194219070906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1194219070906 : Closed e1194219070906 ∧ code e1194219070906 = 5592265582010 := by decide
theorem cert_e1194219070906 : check e1194219070906 [[],[.left],[]] .chain = true := by decide
def e1194219070954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1194219070954 : Closed e1194219070954 ∧ code e1194219070954 = 5592265582058 := by decide
theorem cert_e1194219070954 : check e1194219070954 [[],[.left],[]] .chain = true := by decide
def e1194219071086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1194219071086 : Closed e1194219071086 ∧ code e1194219071086 = 5592265582190 := by decide
theorem cert_e1194219071086 : check e1194219071086 [[],[.left],[]] .chain = true := by decide
def e1194219071098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1194219071098 : Closed e1194219071098 ∧ code e1194219071098 = 5592265582202 := by decide
theorem cert_e1194219071098 : check e1194219071098 [[],[.left],[]] .chain = true := by decide
def e1194219071386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1194219071386 : Closed e1194219071386 ∧ code e1194219071386 = 5592265582490 := by decide
theorem cert_e1194219071386 : check e1194219071386 [[],[.left],[]] .chain = true := by decide
def e1194219074262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1194219074262 : Closed e1194219074262 ∧ code e1194219074262 = 5592265585366 := by decide
theorem cert_e1194219074262 : check e1194219074262 [[],[.left],[]] .chain = true := by decide
def e1194219074266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1194219074266 : Closed e1194219074266 ∧ code e1194219074266 = 5592265585370 := by decide
theorem cert_e1194219074266 : check e1194219074266 [[],[.left],[]] .chain = true := by decide
def e1194219074282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1194219074282 : Closed e1194219074282 ∧ code e1194219074282 = 5592265585386 := by decide
theorem cert_e1194219074282 : check e1194219074282 [[],[.left],[]] .chain = true := by decide
def e1194219074358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1194219074358 : Closed e1194219074358 ∧ code e1194219074358 = 5592265585462 := by decide
theorem cert_e1194219074358 : check e1194219074358 [[],[.left],[]] .chain = true := by decide
def e1194219074362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1194219074362 : Closed e1194219074362 ∧ code e1194219074362 = 5592265585466 := by decide
theorem cert_e1194219074362 : check e1194219074362 [[],[.left],[]] .chain = true := by decide
def e1194219074458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1194219074458 : Closed e1194219074458 ∧ code e1194219074458 = 5592265585562 := by decide
theorem cert_e1194219074458 : check e1194219074458 [[],[.left],[]] .chain = true := by decide
def e1194219211630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194219211630 : Closed e1194219211630 ∧ code e1194219211630 = 5592265722734 := by decide
theorem cert_e1194219211630 : check e1194219211630 [[],[.left],[],[]] .chain = true := by decide
def e1194219211638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194219211638 : Closed e1194219211638 ∧ code e1194219211638 = 5592265722742 := by decide
theorem cert_e1194219211638 : check e1194219211638 [[],[.left],[],[]] .chain = true := by decide
def e1194219211694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194219211694 : Closed e1194219211694 ∧ code e1194219211694 = 5592265722798 := by decide
theorem cert_e1194219211694 : check e1194219211694 [[],[.left],[],[]] .chain = true := by decide
def e1194219211706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194219211706 : Closed e1194219211706 ∧ code e1194219211706 = 5592265722810 := by decide
theorem cert_e1194219211706 : check e1194219211706 [[],[.left],[],[]] .chain = true := by decide
def e1194219211734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194219211734 : Closed e1194219211734 ∧ code e1194219211734 = 5592265722838 := by decide
theorem cert_e1194219211734 : check e1194219211734 [[],[.left],[],[]] .chain = true := by decide
def e1194219211738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194219211738 : Closed e1194219211738 ∧ code e1194219211738 = 5592265722842 := by decide
theorem cert_e1194219211738 : check e1194219211738 [[],[.left],[],[]] .chain = true := by decide
def e1194219212014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194219212014 : Closed e1194219212014 ∧ code e1194219212014 = 5592265723118 := by decide
theorem cert_e1194219212014 : check e1194219212014 [[],[.left],[],[]] .chain = true := by decide
def e1194219212022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194219212022 : Closed e1194219212022 ∧ code e1194219212022 = 5592265723126 := by decide
theorem cert_e1194219212022 : check e1194219212022 [[],[.left],[],[]] .chain = true := by decide
def e1194219212398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194219212398 : Closed e1194219212398 ∧ code e1194219212398 = 5592265723502 := by decide
theorem cert_e1194219212398 : check e1194219212398 [[],[.left],[],[]] .chain = true := by decide
def e1194219212410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194219212410 : Closed e1194219212410 ∧ code e1194219212410 = 5592265723514 := by decide
theorem cert_e1194219212410 : check e1194219212410 [[],[.left],[],[]] .chain = true := by decide
def e1194219212598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194219212598 : Closed e1194219212598 ∧ code e1194219212598 = 5592265723702 := by decide
theorem cert_e1194219212598 : check e1194219212598 [[],[.left],[],[]] .chain = true := by decide
def e1194219212602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194219212602 : Closed e1194219212602 ∧ code e1194219212602 = 5592265723706 := by decide
theorem cert_e1194219212602 : check e1194219212602 [[],[.left],[],[]] .chain = true := by decide
def e1194219801454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194219801454 : Closed e1194219801454 ∧ code e1194219801454 = 5592266312558 := by decide
theorem cert_e1194219801454 : check e1194219801454 [[],[.left]] .chain = true := by decide
def e1194219801462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194219801462 : Closed e1194219801462 ∧ code e1194219801462 = 5592266312566 := by decide
theorem cert_e1194219801462 : check e1194219801462 [[],[.left]] .chain = true := by decide
def e1194219801518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194219801518 : Closed e1194219801518 ∧ code e1194219801518 = 5592266312622 := by decide
theorem cert_e1194219801518 : check e1194219801518 [[],[.left]] .chain = true := by decide
def e1194219801530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194219801530 : Closed e1194219801530 ∧ code e1194219801530 = 5592266312634 := by decide
theorem cert_e1194219801530 : check e1194219801530 [[],[.left]] .chain = true := by decide
def e1194219801558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194219801558 : Closed e1194219801558 ∧ code e1194219801558 = 5592266312662 := by decide
theorem cert_e1194219801558 : check e1194219801558 [[],[.left]] .chain = true := by decide
def e1194219801562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194219801562 : Closed e1194219801562 ∧ code e1194219801562 = 5592266312666 := by decide
theorem cert_e1194219801562 : check e1194219801562 [[],[.left]] .chain = true := by decide
def e1194219801838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194219801838 : Closed e1194219801838 ∧ code e1194219801838 = 5592266312942 := by decide
theorem cert_e1194219801838 : check e1194219801838 [[],[.left]] .chain = true := by decide
def e1194219801846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194219801846 : Closed e1194219801846 ∧ code e1194219801846 = 5592266312950 := by decide
theorem cert_e1194219801846 : check e1194219801846 [[],[.left]] .chain = true := by decide
def e1194219802222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194219802222 : Closed e1194219802222 ∧ code e1194219802222 = 5592266313326 := by decide
theorem cert_e1194219802222 : check e1194219802222 [[],[.left]] .chain = true := by decide
def e1194219802234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194219802234 : Closed e1194219802234 ∧ code e1194219802234 = 5592266313338 := by decide
theorem cert_e1194219802234 : check e1194219802234 [[],[.left]] .chain = true := by decide
def e1194219802422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194219802422 : Closed e1194219802422 ∧ code e1194219802422 = 5592266313526 := by decide
theorem cert_e1194219802422 : check e1194219802422 [[],[.left]] .chain = true := by decide
def e1194219802426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194219802426 : Closed e1194219802426 ∧ code e1194219802426 = 5592266313530 := by decide
theorem cert_e1194219802426 : check e1194219802426 [[],[.left]] .chain = true := by decide
def e1194473667098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473667098 : Closed e1194473667098 ∧ code e1194473667098 = 5592520178202 := by decide
private def t_e1194473667098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473667098 : ¬ IsSelfInterpreter e1194473667098 :=
  wSource (t := t_e1194473667098) (replay_sound (ps := []) (t := e1194473667098) (by decide)) (by decide)
def e1194473675290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473675290 : Closed e1194473675290 ∧ code e1194473675290 = 5592520186394 := by decide
private def t_e1194473675290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473675290 : ¬ IsSelfInterpreter e1194473675290 :=
  wSource (t := t_e1194473675290) (replay_sound (ps := []) (t := e1194473675290) (by decide)) (by decide)
def e1194473732634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473732634 : Closed e1194473732634 ∧ code e1194473732634 = 5592520243738 := by decide
private def t_e1194473732634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473732634 : ¬ IsSelfInterpreter e1194473732634 :=
  wSource (t := t_e1194473732634) (replay_sound (ps := []) (t := e1194473732634) (by decide)) (by decide)
def e1194473744922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473744922 : Closed e1194473744922 ∧ code e1194473744922 = 5592520256026 := by decide
private def t_e1194473744922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473744922 : ¬ IsSelfInterpreter e1194473744922 :=
  wSource (t := t_e1194473744922) (replay_sound (ps := []) (t := e1194473744922) (by decide)) (by decide)
def e1194473773594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473773594 : Closed e1194473773594 ∧ code e1194473773594 = 5592520284698 := by decide
private def t_e1194473773594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473773594 : ¬ IsSelfInterpreter e1194473773594 :=
  wSource (t := t_e1194473773594) (replay_sound (ps := []) (t := e1194473773594) (by decide)) (by decide)
def e1194473777690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194473777690 : Closed e1194473777690 ∧ code e1194473777690 = 5592520288794 := by decide
private def t_e1194473777690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194473777690 : ¬ IsSelfInterpreter e1194473777690 :=
  wSource (t := t_e1194473777690) (replay_sound (ps := []) (t := e1194473777690) (by decide)) (by decide)
def e1194474060314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474060314 : Closed e1194474060314 ∧ code e1194474060314 = 5592520571418 := by decide
private def t_e1194474060314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474060314 : ¬ IsSelfInterpreter e1194474060314 :=
  wSource (t := t_e1194474060314) (replay_sound (ps := []) (t := e1194474060314) (by decide)) (by decide)
def e1194474068506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474068506 : Closed e1194474068506 ∧ code e1194474068506 = 5592520579610 := by decide
private def t_e1194474068506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474068506 : ¬ IsSelfInterpreter e1194474068506 :=
  wSource (t := t_e1194474068506) (replay_sound (ps := []) (t := e1194474068506) (by decide)) (by decide)
def e1194474453530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474453530 : Closed e1194474453530 ∧ code e1194474453530 = 5592520964634 := by decide
private def t_e1194474453530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474453530 : ¬ IsSelfInterpreter e1194474453530 :=
  wSource (t := t_e1194474453530) (replay_sound (ps := []) (t := e1194474453530) (by decide)) (by decide)
def e1194474465818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474465818 : Closed e1194474465818 ∧ code e1194474465818 = 5592520976922 := by decide
private def t_e1194474465818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474465818 : ¬ IsSelfInterpreter e1194474465818 :=
  wSource (t := t_e1194474465818) (replay_sound (ps := []) (t := e1194474465818) (by decide)) (by decide)
def e1194474658330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474658330 : Closed e1194474658330 ∧ code e1194474658330 = 5592521169434 := by decide
private def t_e1194474658330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474658330 : ¬ IsSelfInterpreter e1194474658330 :=
  wSource (t := t_e1194474658330) (replay_sound (ps := []) (t := e1194474658330) (by decide)) (by decide)
def e1194474662426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1194474662426 : Closed e1194474662426 ∧ code e1194474662426 = 5592521173530 := by decide
private def t_e1194474662426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1194474662426 : ¬ IsSelfInterpreter e1194474662426 :=
  wSource (t := t_e1194474662426) (replay_sound (ps := []) (t := e1194474662426) (by decide)) (by decide)
def e1194543771846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543771846 : Closed e1194543771846 ∧ code e1194543771846 = 5592590282950 := by decide
theorem cert_e1194543771846 : check e1194543771846 [[]] .width = true := by decide
def e1194543788230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543788230 : Closed e1194543788230 ∧ code e1194543788230 = 5592590299334 := by decide
theorem cert_e1194543788230 : check e1194543788230 [[]] .width = true := by decide
def e1194543902918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543902918 : Closed e1194543902918 ∧ code e1194543902918 = 5592590414022 := by decide
theorem cert_e1194543902918 : check e1194543902918 [[]] .width = true := by decide
def e1194543927494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543927494 : Closed e1194543927494 ∧ code e1194543927494 = 5592590438598 := by decide
theorem cert_e1194543927494 : check e1194543927494 [[]] .width = true := by decide
def e1194543984838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543984838 : Closed e1194543984838 ∧ code e1194543984838 = 5592590495942 := by decide
theorem cert_e1194543984838 : check e1194543984838 [[]] .width = true := by decide
def e1194543993030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194543993030 : Closed e1194543993030 ∧ code e1194543993030 = 5592590504134 := by decide
theorem cert_e1194543993030 : check e1194543993030 [[]] .width = true := by decide
def e1194544558278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194544558278 : Closed e1194544558278 ∧ code e1194544558278 = 5592591069382 := by decide
theorem cert_e1194544558278 : check e1194544558278 [[]] .width = true := by decide
def e1194544574662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194544574662 : Closed e1194544574662 ∧ code e1194544574662 = 5592591085766 := by decide
theorem cert_e1194544574662 : check e1194544574662 [[]] .width = true := by decide
def e1194545344710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194545344710 : Closed e1194545344710 ∧ code e1194545344710 = 5592591855814 := by decide
theorem cert_e1194545344710 : check e1194545344710 [[]] .width = true := by decide
def e1194545369286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194545369286 : Closed e1194545369286 ∧ code e1194545369286 = 5592591880390 := by decide
theorem cert_e1194545369286 : check e1194545369286 [[]] .width = true := by decide
def e1194545754310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194545754310 : Closed e1194545754310 ∧ code e1194545754310 = 5592592265414 := by decide
theorem cert_e1194545754310 : check e1194545754310 [[]] .width = true := by decide
def e1194545762502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1194545762502 : Closed e1194545762502 ∧ code e1194545762502 = 5592592273606 := by decide
theorem cert_e1194545762502 : check e1194545762502 [[]] .width = true := by decide
def e1194588155246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1194588155246 : Closed e1194588155246 ∧ code e1194588155246 = 5592634666350 := by decide
theorem cert_e1194588155246 : check e1194588155246 [[],[.left],[]] .smaller = true := by decide
def e1194588155254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1194588155254 : Closed e1194588155254 ∧ code e1194588155254 = 5592634666358 := by decide
theorem cert_e1194588155254 : check e1194588155254 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor42
