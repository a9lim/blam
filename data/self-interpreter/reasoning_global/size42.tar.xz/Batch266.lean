import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1212363577822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1212363577822 : Closed e1212363577822 ∧ code e1212363577822 = 5610410088926 := by decide
theorem cert_e1212363577822 : check e1212363577822 [[],[.left]] .chain = true := by decide
def e1212363577846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1212363577846 : Closed e1212363577846 ∧ code e1212363577846 = 5610410088950 := by decide
theorem cert_e1212363577846 : check e1212363577846 [[],[.left]] .chain = true := by decide
def e1212363578590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1212363578590 : Closed e1212363578590 ∧ code e1212363578590 = 5610410089694 := by decide
theorem cert_e1212363578590 : check e1212363578590 [[],[.left]] .chain = true := by decide
def e1212363578618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1212363578618 : Closed e1212363578618 ∧ code e1212363578618 = 5610410089722 := by decide
theorem cert_e1212363578618 : check e1212363578618 [[],[.left]] .chain = true := by decide
def e1212363579190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1212363579190 : Closed e1212363579190 ∧ code e1212363579190 = 5610410090294 := by decide
theorem cert_e1212363579190 : check e1212363579190 [[],[.left]] .chain = true := by decide
def e1212363579194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1212363579194 : Closed e1212363579194 ∧ code e1212363579194 = 5610410090298 := by decide
theorem cert_e1212363579194 : check e1212363579194 [[],[.left]] .chain = true := by decide
def e1212363593966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1212363593966 : Closed e1212363593966 ∧ code e1212363593966 = 5610410105070 := by decide
theorem cert_e1212363593966 : check e1212363593966 [[],[.left]] .chain = true := by decide
def e1212363593974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1212363593974 : Closed e1212363593974 ∧ code e1212363593974 = 5610410105078 := by decide
theorem cert_e1212363593974 : check e1212363593974 [[],[.left]] .chain = true := by decide
def e1212363594526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1212363594526 : Closed e1212363594526 ∧ code e1212363594526 = 5610410105630 := by decide
theorem cert_e1212363594526 : check e1212363594526 [[],[.left]] .chain = true := by decide
def e1212363594638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1212363594638 : Closed e1212363594638 ∧ code e1212363594638 = 5610410105742 := by decide
theorem cert_e1212363594638 : check e1212363594638 [[],[.left]] .chain = true := by decide
def e1212363594862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1212363594862 : Closed e1212363594862 ∧ code e1212363594862 = 5610410105966 := by decide
theorem cert_e1212363594862 : check e1212363594862 [[],[.left]] .chain = true := by decide
def e1212363594874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1212363594874 : Closed e1212363594874 ∧ code e1212363594874 = 5610410105978 := by decide
theorem cert_e1212363594874 : check e1212363594874 [[],[.left]] .chain = true := by decide
def e1212363595038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1212363595038 : Closed e1212363595038 ∧ code e1212363595038 = 5610410106142 := by decide
theorem cert_e1212363595038 : check e1212363595038 [[],[.left]] .chain = true := by decide
def e1212363595206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1212363595206 : Closed e1212363595206 ∧ code e1212363595206 = 5610410106310 := by decide
theorem cert_e1212363595206 : check e1212363595206 [[],[.left]] .chain = true := by decide
def e1212363595318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1212363595318 : Closed e1212363595318 ∧ code e1212363595318 = 5610410106422 := by decide
theorem cert_e1212363595318 : check e1212363595318 [[],[.left]] .chain = true := by decide
def e1212363595322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1212363595322 : Closed e1212363595322 ∧ code e1212363595322 = 5610410106426 := by decide
theorem cert_e1212363595322 : check e1212363595322 [[],[.left]] .chain = true := by decide
def e1212363595406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1212363595406 : Closed e1212363595406 ∧ code e1212363595406 = 5610410106510 := by decide
theorem cert_e1212363595406 : check e1212363595406 [[],[.left]] .chain = true := by decide
def e1212363595462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1212363595462 : Closed e1212363595462 ∧ code e1212363595462 = 5610410106566 := by decide
theorem cert_e1212363595462 : check e1212363595462 [[],[.left]] .chain = true := by decide
def e1212363597598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1212363597598 : Closed e1212363597598 ∧ code e1212363597598 = 5610410108702 := by decide
theorem cert_e1212363597598 : check e1212363597598 [[],[.left]] .chain = true := by decide
def e1212363597710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1212363597710 : Closed e1212363597710 ∧ code e1212363597710 = 5610410108814 := by decide
theorem cert_e1212363597710 : check e1212363597710 [[],[.left]] .chain = true := by decide
def e1212363600670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1212363600670 : Closed e1212363600670 ∧ code e1212363600670 = 5610410111774 := by decide
theorem cert_e1212363600670 : check e1212363600670 [[],[.left]] .chain = true := by decide
def e1212363600838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1212363600838 : Closed e1212363600838 ∧ code e1212363600838 = 5610410111942 := by decide
theorem cert_e1212363600838 : check e1212363600838 [[],[.left]] .chain = true := by decide
def e1212363602318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1212363602318 : Closed e1212363602318 ∧ code e1212363602318 = 5610410113422 := by decide
theorem cert_e1212363602318 : check e1212363602318 [[],[.left]] .chain = true := by decide
def e1212363602374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1212363602374 : Closed e1212363602374 ∧ code e1212363602374 = 5610410113478 := by decide
theorem cert_e1212363602374 : check e1212363602374 [[],[.left]] .chain = true := by decide
def e1400255220834 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400255220834 : Closed e1400255220834 ∧ code e1400255220834 = 5798301731938 := by decide
theorem cert_e1400255220834 : check e1400255220834 [[.left]] .width = true := by decide
def e1400255482978 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400255482978 : Closed e1400255482978 ∧ code e1400255482978 = 5798301994082 := by decide
theorem cert_e1400255482978 : check e1400255482978 [[.left]] .width = true := by decide
def e1400257317986 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400257317986 : Closed e1400257317986 ∧ code e1400257317986 = 5798303829090 := by decide
theorem cert_e1400257317986 : check e1400257317986 [[.left]] .width = true := by decide
def e1400257711202 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400257711202 : Closed e1400257711202 ∧ code e1400257711202 = 5798304222306 := by decide
theorem cert_e1400257711202 : check e1400257711202 [[.left]] .width = true := by decide
def e1400258628706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400258628706 : Closed e1400258628706 ∧ code e1400258628706 = 5798305139810 := by decide
theorem cert_e1400258628706 : check e1400258628706 [[.left]] .width = true := by decide
def e1400258759778 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400258759778 : Closed e1400258759778 ∧ code e1400258759778 = 5798305270882 := by decide
theorem cert_e1400258759778 : check e1400258759778 [[.left]] .width = true := by decide
def e1400267803746 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400267803746 : Closed e1400267803746 ∧ code e1400267803746 = 5798314314850 := by decide
theorem cert_e1400267803746 : check e1400267803746 [[.left]] .width = true := by decide
def e1400268065890 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400268065890 : Closed e1400268065890 ∧ code e1400268065890 = 5798314576994 := by decide
theorem cert_e1400268065890 : check e1400268065890 [[.left]] .width = true := by decide
def e1400280386658 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400280386658 : Closed e1400280386658 ∧ code e1400280386658 = 5798326897762 := by decide
theorem cert_e1400280386658 : check e1400280386658 [[.left]] .width = true := by decide
def e1400280779874 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400280779874 : Closed e1400280779874 ∧ code e1400280779874 = 5798327290978 := by decide
theorem cert_e1400280779874 : check e1400280779874 [[.left]] .width = true := by decide
def e1400286940258 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400286940258 : Closed e1400286940258 ∧ code e1400286940258 = 5798333451362 := by decide
theorem cert_e1400286940258 : check e1400286940258 [[.left]] .width = true := by decide
def e1400287071330 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))
theorem wire_e1400287071330 : Closed e1400287071330 ∧ code e1400287071330 = 5798333582434 := by decide
theorem cert_e1400287071330 : check e1400287071330 [[.left]] .width = true := by decide
def e1400965355234 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965355234 : Closed e1400965355234 ∧ code e1400965355234 = 5799011866338 := by decide
theorem cert_e1400965355234 : check e1400965355234 [[.left],[.left]] .chain = true := by decide
def e1400965355362 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965355362 : Closed e1400965355362 ∧ code e1400965355362 = 5799011866466 := by decide
theorem cert_e1400965355362 : check e1400965355362 [[.left],[.left]] .chain = true := by decide
def e1400965356258 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965356258 : Closed e1400965356258 ∧ code e1400965356258 = 5799011867362 := by decide
theorem cert_e1400965356258 : check e1400965356258 [[.left],[.left]] .chain = true := by decide
def e1400965356450 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965356450 : Closed e1400965356450 ∧ code e1400965356450 = 5799011867554 := by decide
theorem cert_e1400965356450 : check e1400965356450 [[.left],[.left]] .chain = true := by decide
def e1400965356898 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965356898 : Closed e1400965356898 ∧ code e1400965356898 = 5799011868002 := by decide
theorem cert_e1400965356898 : check e1400965356898 [[.left],[.left]] .chain = true := by decide
def e1400965356962 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965356962 : Closed e1400965356962 ∧ code e1400965356962 = 5799011868066 := by decide
theorem cert_e1400965356962 : check e1400965356962 [[.left],[.left]] .chain = true := by decide
def e1400965360354 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965360354 : Closed e1400965360354 ∧ code e1400965360354 = 5799011871458 := by decide
theorem cert_e1400965360354 : check e1400965360354 [[.left],[.left]] .chain = true := by decide
def e1400965360546 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965360546 : Closed e1400965360546 ∧ code e1400965360546 = 5799011871650 := by decide
theorem cert_e1400965360546 : check e1400965360546 [[.left],[.left]] .chain = true := by decide
def e1400965361314 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965361314 : Closed e1400965361314 ∧ code e1400965361314 = 5799011872418 := by decide
theorem cert_e1400965361314 : check e1400965361314 [[.left],[.left]] .chain = true := by decide
def e1400965363042 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965363042 : Closed e1400965363042 ∧ code e1400965363042 = 5799011874146 := by decide
theorem cert_e1400965363042 : check e1400965363042 [[.left],[.left]] .chain = true := by decide
def e1400965363106 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965363106 : Closed e1400965363106 ∧ code e1400965363106 = 5799011874210 := by decide
theorem cert_e1400965363106 : check e1400965363106 [[.left],[.left]] .chain = true := by decide
def e1400965363362 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965363362 : Closed e1400965363362 ∧ code e1400965363362 = 5799011874466 := by decide
theorem cert_e1400965363362 : check e1400965363362 [[.left],[.left]] .chain = true := by decide
def e1400965379810 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965379810 : Closed e1400965379810 ∧ code e1400965379810 = 5799011890914 := by decide
theorem cert_e1400965379810 : check e1400965379810 [[.left],[.left]] .chain = true := by decide
def e1400965379938 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965379938 : Closed e1400965379938 ∧ code e1400965379938 = 5799011891042 := by decide
theorem cert_e1400965379938 : check e1400965379938 [[.left],[.left]] .chain = true := by decide
def e1400965380834 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965380834 : Closed e1400965380834 ∧ code e1400965380834 = 5799011891938 := by decide
theorem cert_e1400965380834 : check e1400965380834 [[.left],[.left]] .chain = true := by decide
def e1400965381026 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965381026 : Closed e1400965381026 ∧ code e1400965381026 = 5799011892130 := by decide
theorem cert_e1400965381026 : check e1400965381026 [[.left],[.left]] .chain = true := by decide
def e1400965381474 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965381474 : Closed e1400965381474 ∧ code e1400965381474 = 5799011892578 := by decide
theorem cert_e1400965381474 : check e1400965381474 [[.left],[.left]] .chain = true := by decide
def e1400965381538 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965381538 : Closed e1400965381538 ∧ code e1400965381538 = 5799011892642 := by decide
theorem cert_e1400965381538 : check e1400965381538 [[.left],[.left]] .chain = true := by decide
def e1400965385954 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965385954 : Closed e1400965385954 ∧ code e1400965385954 = 5799011897058 := by decide
theorem cert_e1400965385954 : check e1400965385954 [[.left],[.left]] .chain = true := by decide
def e1400965386082 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965386082 : Closed e1400965386082 ∧ code e1400965386082 = 5799011897186 := by decide
theorem cert_e1400965386082 : check e1400965386082 [[.left],[.left]] .chain = true := by decide
def e1400965392098 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965392098 : Closed e1400965392098 ∧ code e1400965392098 = 5799011903202 := by decide
theorem cert_e1400965392098 : check e1400965392098 [[.left],[.left]] .chain = true := by decide
def e1400965392290 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965392290 : Closed e1400965392290 ∧ code e1400965392290 = 5799011903394 := by decide
theorem cert_e1400965392290 : check e1400965392290 [[.left],[.left]] .chain = true := by decide
def e1400965393946 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965393946 : Closed e1400965393946 ∧ code e1400965393946 = 5799011905050 := by decide
theorem cert_e1400965393946 : check e1400965393946 [[.left]] .chain = true := by decide
def e1400965395298 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965395298 : Closed e1400965395298 ∧ code e1400965395298 = 5799011906402 := by decide
theorem cert_e1400965395298 : check e1400965395298 [[.left],[.left]] .chain = true := by decide
def e1400965395362 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965395362 : Closed e1400965395362 ∧ code e1400965395362 = 5799011906466 := by decide
theorem cert_e1400965395362 : check e1400965395362 [[.left],[.left]] .chain = true := by decide
def e1400965395994 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965395994 : Closed e1400965395994 ∧ code e1400965395994 = 5799011907098 := by decide
theorem cert_e1400965395994 : check e1400965395994 [[.left]] .chain = true := by decide
def e1400965405410 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1400965405410 : Closed e1400965405410 ∧ code e1400965405410 = 5799011916514 := by decide
theorem cert_e1400965405410 : check e1400965405410 [[.left],[.left]] .chain = true := by decide
def e1400965405602 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965405602 : Closed e1400965405602 ∧ code e1400965405602 = 5799011916706 := by decide
theorem cert_e1400965405602 : check e1400965405602 [[.left],[.left]] .chain = true := by decide
def e1400965406370 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965406370 : Closed e1400965406370 ∧ code e1400965406370 = 5799011917474 := by decide
theorem cert_e1400965406370 : check e1400965406370 [[.left],[.left]] .chain = true := by decide
def e1400965408482 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965408482 : Closed e1400965408482 ∧ code e1400965408482 = 5799011919586 := by decide
theorem cert_e1400965408482 : check e1400965408482 [[.left],[.left]] .chain = true := by decide
def e1400965408674 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965408674 : Closed e1400965408674 ∧ code e1400965408674 = 5799011919778 := by decide
theorem cert_e1400965408674 : check e1400965408674 [[.left],[.left]] .chain = true := by decide
def e1400965410330 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965410330 : Closed e1400965410330 ∧ code e1400965410330 = 5799011921434 := by decide
theorem cert_e1400965410330 : check e1400965410330 [[.left]] .chain = true := by decide
def e1400965413282 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965413282 : Closed e1400965413282 ∧ code e1400965413282 = 5799011924386 := by decide
theorem cert_e1400965413282 : check e1400965413282 [[.left],[.left]] .chain = true := by decide
def e1400965413402 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965413402 : Closed e1400965413402 ∧ code e1400965413402 = 5799011924506 := by decide
theorem cert_e1400965413402 : check e1400965413402 [[.left]] .chain = true := by decide
def e1400965418338 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1400965418338 : Closed e1400965418338 ∧ code e1400965418338 = 5799011929442 := by decide
theorem cert_e1400965418338 : check e1400965418338 [[.left],[.left]] .chain = true := by decide
def e1400965418402 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965418402 : Closed e1400965418402 ∧ code e1400965418402 = 5799011929506 := by decide
theorem cert_e1400965418402 : check e1400965418402 [[.left],[.left]] .chain = true := by decide
def e1400965418658 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1400965418658 : Closed e1400965418658 ∧ code e1400965418658 = 5799011929762 := by decide
theorem cert_e1400965418658 : check e1400965418658 [[.left],[.left]] .chain = true := by decide
def e1400965419874 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965419874 : Closed e1400965419874 ∧ code e1400965419874 = 5799011930978 := by decide
theorem cert_e1400965419874 : check e1400965419874 [[.left],[.left]] .chain = true := by decide
def e1400965419938 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965419938 : Closed e1400965419938 ∧ code e1400965419938 = 5799011931042 := by decide
theorem cert_e1400965419938 : check e1400965419938 [[.left],[.left]] .chain = true := by decide
def e1400965420570 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965420570 : Closed e1400965420570 ∧ code e1400965420570 = 5799011931674 := by decide
theorem cert_e1400965420570 : check e1400965420570 [[.left]] .chain = true := by decide
def e1400965421474 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965421474 : Closed e1400965421474 ∧ code e1400965421474 = 5799011932578 := by decide
theorem cert_e1400965421474 : check e1400965421474 [[.left],[.left]] .chain = true := by decide
def e1400965421594 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965421594 : Closed e1400965421594 ∧ code e1400965421594 = 5799011932698 := by decide
theorem cert_e1400965421594 : check e1400965421594 [[.left]] .chain = true := by decide
def e1400965478114 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965478114 : Closed e1400965478114 ∧ code e1400965478114 = 5799011989218 := by decide
theorem cert_e1400965478114 : check e1400965478114 [[.left],[.left]] .chain = true := by decide
def e1400965478242 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965478242 : Closed e1400965478242 ∧ code e1400965478242 = 5799011989346 := by decide
theorem cert_e1400965478242 : check e1400965478242 [[.left],[.left]] .chain = true := by decide
def e1400965479138 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965479138 : Closed e1400965479138 ∧ code e1400965479138 = 5799011990242 := by decide
theorem cert_e1400965479138 : check e1400965479138 [[.left],[.left]] .chain = true := by decide
def e1400965479330 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965479330 : Closed e1400965479330 ∧ code e1400965479330 = 5799011990434 := by decide
theorem cert_e1400965479330 : check e1400965479330 [[.left],[.left]] .chain = true := by decide
def e1400965479778 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965479778 : Closed e1400965479778 ∧ code e1400965479778 = 5799011990882 := by decide
theorem cert_e1400965479778 : check e1400965479778 [[.left],[.left]] .chain = true := by decide
def e1400965479842 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965479842 : Closed e1400965479842 ∧ code e1400965479842 = 5799011990946 := by decide
theorem cert_e1400965479842 : check e1400965479842 [[.left],[.left]] .chain = true := by decide
def e1400965484258 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400965484258 : Closed e1400965484258 ∧ code e1400965484258 = 5799011995362 := by decide
theorem cert_e1400965484258 : check e1400965484258 [[.left],[.left]] .chain = true := by decide
def e1400965484386 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400965484386 : Closed e1400965484386 ∧ code e1400965484386 = 5799011995490 := by decide
theorem cert_e1400965484386 : check e1400965484386 [[.left],[.left]] .chain = true := by decide
def e1400965490402 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400965490402 : Closed e1400965490402 ∧ code e1400965490402 = 5799012001506 := by decide
theorem cert_e1400965490402 : check e1400965490402 [[.left],[.left]] .chain = true := by decide
def e1400965490594 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965490594 : Closed e1400965490594 ∧ code e1400965490594 = 5799012001698 := by decide
theorem cert_e1400965490594 : check e1400965490594 [[.left],[.left]] .chain = true := by decide
def e1400965492250 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965492250 : Closed e1400965492250 ∧ code e1400965492250 = 5799012003354 := by decide
theorem cert_e1400965492250 : check e1400965492250 [[.left]] .chain = true := by decide
def e1400965493602 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400965493602 : Closed e1400965493602 ∧ code e1400965493602 = 5799012004706 := by decide
theorem cert_e1400965493602 : check e1400965493602 [[.left],[.left]] .chain = true := by decide
def e1400965493666 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965493666 : Closed e1400965493666 ∧ code e1400965493666 = 5799012004770 := by decide
theorem cert_e1400965493666 : check e1400965493666 [[.left],[.left]] .chain = true := by decide
def e1400965494298 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965494298 : Closed e1400965494298 ∧ code e1400965494298 = 5799012005402 := by decide
theorem cert_e1400965494298 : check e1400965494298 [[.left]] .chain = true := by decide
def e1400965585634 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400965585634 : Closed e1400965585634 ∧ code e1400965585634 = 5799012096738 := by decide
theorem cert_e1400965585634 : check e1400965585634 [[.left],[.left]] .chain = true := by decide
def e1400965585826 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965585826 : Closed e1400965585826 ∧ code e1400965585826 = 5799012096930 := by decide
theorem cert_e1400965585826 : check e1400965585826 [[.left],[.left]] .chain = true := by decide
def e1400965586594 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965586594 : Closed e1400965586594 ∧ code e1400965586594 = 5799012097698 := by decide
theorem cert_e1400965586594 : check e1400965586594 [[.left],[.left]] .chain = true := by decide
def e1400965588706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400965588706 : Closed e1400965588706 ∧ code e1400965588706 = 5799012099810 := by decide
theorem cert_e1400965588706 : check e1400965588706 [[.left],[.left]] .chain = true := by decide
def e1400965588898 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965588898 : Closed e1400965588898 ∧ code e1400965588898 = 5799012100002 := by decide
theorem cert_e1400965588898 : check e1400965588898 [[.left],[.left]] .chain = true := by decide
def e1400965590554 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965590554 : Closed e1400965590554 ∧ code e1400965590554 = 5799012101658 := by decide
theorem cert_e1400965590554 : check e1400965590554 [[.left]] .chain = true := by decide
def e1400965593506 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965593506 : Closed e1400965593506 ∧ code e1400965593506 = 5799012104610 := by decide
theorem cert_e1400965593506 : check e1400965593506 [[.left],[.left]] .chain = true := by decide
def e1400965593626 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965593626 : Closed e1400965593626 ∧ code e1400965593626 = 5799012104730 := by decide
theorem cert_e1400965593626 : check e1400965593626 [[.left]] .chain = true := by decide
def e1400965639522 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400965639522 : Closed e1400965639522 ∧ code e1400965639522 = 5799012150626 := by decide
theorem cert_e1400965639522 : check e1400965639522 [[.left],[.left]] .chain = true := by decide
def e1400965639586 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965639586 : Closed e1400965639586 ∧ code e1400965639586 = 5799012150690 := by decide
theorem cert_e1400965639586 : check e1400965639586 [[.left],[.left]] .chain = true := by decide
def e1400965639842 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400965639842 : Closed e1400965639842 ∧ code e1400965639842 = 5799012150946 := by decide
theorem cert_e1400965639842 : check e1400965639842 [[.left],[.left]] .chain = true := by decide
def e1400965641058 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400965641058 : Closed e1400965641058 ∧ code e1400965641058 = 5799012152162 := by decide
theorem cert_e1400965641058 : check e1400965641058 [[.left],[.left]] .chain = true := by decide
def e1400965641122 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965641122 : Closed e1400965641122 ∧ code e1400965641122 = 5799012152226 := by decide
theorem cert_e1400965641122 : check e1400965641122 [[.left],[.left]] .chain = true := by decide
def e1400965641754 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965641754 : Closed e1400965641754 ∧ code e1400965641754 = 5799012152858 := by decide
theorem cert_e1400965641754 : check e1400965641754 [[.left]] .chain = true := by decide
def e1400965642658 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400965642658 : Closed e1400965642658 ∧ code e1400965642658 = 5799012153762 := by decide
theorem cert_e1400965642658 : check e1400965642658 [[.left],[.left]] .chain = true := by decide
def e1400965642778 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1400965642778 : Closed e1400965642778 ∧ code e1400965642778 = 5799012153882 := by decide
theorem cert_e1400965642778 : check e1400965642778 [[.left]] .chain = true := by decide
def e1400967837410 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400967837410 : Closed e1400967837410 ∧ code e1400967837410 = 5799014348514 := by decide
theorem cert_e1400967837410 : check e1400967837410 [[.left],[.left]] .chain = true := by decide
def e1400967837538 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400967837538 : Closed e1400967837538 ∧ code e1400967837538 = 5799014348642 := by decide
theorem cert_e1400967837538 : check e1400967837538 [[.left],[.left]] .chain = true := by decide
def e1400967838434 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400967838434 : Closed e1400967838434 ∧ code e1400967838434 = 5799014349538 := by decide
theorem cert_e1400967838434 : check e1400967838434 [[.left],[.left]] .chain = true := by decide
def e1400967838626 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400967838626 : Closed e1400967838626 ∧ code e1400967838626 = 5799014349730 := by decide
theorem cert_e1400967838626 : check e1400967838626 [[.left],[.left]] .chain = true := by decide
def e1400967839074 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400967839074 : Closed e1400967839074 ∧ code e1400967839074 = 5799014350178 := by decide
theorem cert_e1400967839074 : check e1400967839074 [[.left],[.left]] .chain = true := by decide
def e1400967839138 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400967839138 : Closed e1400967839138 ∧ code e1400967839138 = 5799014350242 := by decide
theorem cert_e1400967839138 : check e1400967839138 [[.left],[.left]] .chain = true := by decide
def e1400967843554 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400967843554 : Closed e1400967843554 ∧ code e1400967843554 = 5799014354658 := by decide
theorem cert_e1400967843554 : check e1400967843554 [[.left],[.left]] .chain = true := by decide
def e1400967843682 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400967843682 : Closed e1400967843682 ∧ code e1400967843682 = 5799014354786 := by decide
theorem cert_e1400967843682 : check e1400967843682 [[.left],[.left]] .chain = true := by decide
def e1400967849698 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400967849698 : Closed e1400967849698 ∧ code e1400967849698 = 5799014360802 := by decide
theorem cert_e1400967849698 : check e1400967849698 [[.left],[.left]] .chain = true := by decide
def e1400967849890 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400967849890 : Closed e1400967849890 ∧ code e1400967849890 = 5799014360994 := by decide
theorem cert_e1400967849890 : check e1400967849890 [[.left],[.left]] .chain = true := by decide
def e1400967852898 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400967852898 : Closed e1400967852898 ∧ code e1400967852898 = 5799014364002 := by decide
theorem cert_e1400967852898 : check e1400967852898 [[.left],[.left]] .chain = true := by decide
def e1400967852962 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400967852962 : Closed e1400967852962 ∧ code e1400967852962 = 5799014364066 := by decide
theorem cert_e1400967852962 : check e1400967852962 [[.left],[.left]] .chain = true := by decide
def e1400977274594 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400977274594 : Closed e1400977274594 ∧ code e1400977274594 = 5799023785698 := by decide
theorem cert_e1400977274594 : check e1400977274594 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977274722 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400977274722 : Closed e1400977274722 ∧ code e1400977274722 = 5799023785826 := by decide
theorem cert_e1400977274722 : check e1400977274722 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977275618 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1400977275618 : Closed e1400977275618 ∧ code e1400977275618 = 5799023786722 := by decide
theorem cert_e1400977275618 : check e1400977275618 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977275810 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400977275810 : Closed e1400977275810 ∧ code e1400977275810 = 5799023786914 := by decide
theorem cert_e1400977275810 : check e1400977275810 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977276258 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1400977276258 : Closed e1400977276258 ∧ code e1400977276258 = 5799023787362 := by decide
theorem cert_e1400977276258 : check e1400977276258 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977276322 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1400977276322 : Closed e1400977276322 ∧ code e1400977276322 = 5799023787426 := by decide
theorem cert_e1400977276322 : check e1400977276322 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977280738 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400977280738 : Closed e1400977280738 ∧ code e1400977280738 = 5799023791842 := by decide
theorem cert_e1400977280738 : check e1400977280738 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977280866 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400977280866 : Closed e1400977280866 ∧ code e1400977280866 = 5799023791970 := by decide
theorem cert_e1400977280866 : check e1400977280866 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977286882 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1400977286882 : Closed e1400977286882 ∧ code e1400977286882 = 5799023797986 := by decide
theorem cert_e1400977286882 : check e1400977286882 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977287074 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400977287074 : Closed e1400977287074 ∧ code e1400977287074 = 5799023798178 := by decide
theorem cert_e1400977287074 : check e1400977287074 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977290082 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1400977290082 : Closed e1400977290082 ∧ code e1400977290082 = 5799023801186 := by decide
theorem cert_e1400977290082 : check e1400977290082 [[.left],[.left],[.left]] .smaller = true := by decide
def e1400977290146 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1400977290146 : Closed e1400977290146 ∧ code e1400977290146 = 5799023801250 := by decide
theorem cert_e1400977290146 : check e1400977290146 [[.left],[.left],[.left]] .smaller = true := by decide
def e1402308242914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308242914 : Closed e1402308242914 ∧ code e1402308242914 = 5800354754018 := by decide
theorem cert_e1402308242914 : check e1402308242914 [[.left],[.left]] .chain = true := by decide
def e1402308243298 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308243298 : Closed e1402308243298 ∧ code e1402308243298 = 5800354754402 := by decide
theorem cert_e1402308243298 : check e1402308243298 [[.left],[.left]] .chain = true := by decide
def e1402308244962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308244962 : Closed e1402308244962 ∧ code e1402308244962 = 5800354756066 := by decide
theorem cert_e1402308244962 : check e1402308244962 [[.left],[.left]] .chain = true := by decide
def e1402308245218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308245218 : Closed e1402308245218 ∧ code e1402308245218 = 5800354756322 := by decide
theorem cert_e1402308245218 : check e1402308245218 [[.left],[.left]] .smaller = true := by decide
def e1402308245346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308245346 : Closed e1402308245346 ∧ code e1402308245346 = 5800354756450 := by decide
theorem cert_e1402308245346 : check e1402308245346 [[.left],[.left]] .smaller = true := by decide
def e1402308245410 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308245410 : Closed e1402308245410 ∧ code e1402308245410 = 5800354756514 := by decide
theorem cert_e1402308245410 : check e1402308245410 [[.left],[.left]] .chain = true := by decide
def e1402308246370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308246370 : Closed e1402308246370 ∧ code e1402308246370 = 5800354757474 := by decide
theorem cert_e1402308246370 : check e1402308246370 [[.left],[.left]] .smaller = true := by decide
def e1402308246882 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308246882 : Closed e1402308246882 ∧ code e1402308246882 = 5800354757986 := by decide
theorem cert_e1402308246882 : check e1402308246882 [[.left],[.left]] .chain = true := by decide
def e1402308246946 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308246946 : Closed e1402308246946 ∧ code e1402308246946 = 5800354758050 := by decide
theorem cert_e1402308246946 : check e1402308246946 [[.left],[.left]] .chain = true := by decide
def e1402308253154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308253154 : Closed e1402308253154 ∧ code e1402308253154 = 5800354764258 := by decide
theorem cert_e1402308253154 : check e1402308253154 [[.left],[.left]] .chain = true := by decide
def e1402308253410 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308253410 : Closed e1402308253410 ∧ code e1402308253410 = 5800354764514 := by decide
theorem cert_e1402308253410 : check e1402308253410 [[.left],[.left]] .smaller = true := by decide
def e1402308253538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308253538 : Closed e1402308253538 ∧ code e1402308253538 = 5800354764642 := by decide
theorem cert_e1402308253538 : check e1402308253538 [[.left],[.left]] .smaller = true := by decide
def e1402308253602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308253602 : Closed e1402308253602 ∧ code e1402308253602 = 5800354764706 := by decide
theorem cert_e1402308253602 : check e1402308253602 [[.left],[.left]] .chain = true := by decide
def e1402308254434 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308254434 : Closed e1402308254434 ∧ code e1402308254434 = 5800354765538 := by decide
theorem cert_e1402308254434 : check e1402308254434 [[.left],[.left]] .smaller = true := by decide
def e1402308254626 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308254626 : Closed e1402308254626 ∧ code e1402308254626 = 5800354765730 := by decide
theorem cert_e1402308254626 : check e1402308254626 [[.left],[.left]] .smaller = true := by decide
def e1402308255074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308255074 : Closed e1402308255074 ∧ code e1402308255074 = 5800354766178 := by decide
theorem cert_e1402308255074 : check e1402308255074 [[.left],[.left]] .smaller = true := by decide
def e1402308255138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308255138 : Closed e1402308255138 ∧ code e1402308255138 = 5800354766242 := by decide
theorem cert_e1402308255138 : check e1402308255138 [[.left],[.left]] .smaller = true := by decide
def e1402308255394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308255394 : Closed e1402308255394 ∧ code e1402308255394 = 5800354766498 := by decide
theorem cert_e1402308255394 : check e1402308255394 [[.left],[.left]] .chain = true := by decide
def e1402308258658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308258658 : Closed e1402308258658 ∧ code e1402308258658 = 5800354769762 := by decide
theorem cert_e1402308258658 : check e1402308258658 [[.left],[.left]] .smaller = true := by decide
def e1402308259170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308259170 : Closed e1402308259170 ∧ code e1402308259170 = 5800354770274 := by decide
theorem cert_e1402308259170 : check e1402308259170 [[.left],[.left]] .smaller = true := by decide
def e1402308259234 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308259234 : Closed e1402308259234 ∧ code e1402308259234 = 5800354770338 := by decide
theorem cert_e1402308259234 : check e1402308259234 [[.left],[.left]] .smaller = true := by decide
def e1402308261218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308261218 : Closed e1402308261218 ∧ code e1402308261218 = 5800354772322 := by decide
theorem cert_e1402308261218 : check e1402308261218 [[.left],[.left]] .chain = true := by decide
def e1402308261282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308261282 : Closed e1402308261282 ∧ code e1402308261282 = 5800354772386 := by decide
theorem cert_e1402308261282 : check e1402308261282 [[.left],[.left]] .chain = true := by decide
def e1402308261538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402308261538 : Closed e1402308261538 ∧ code e1402308261538 = 5800354772642 := by decide
theorem cert_e1402308261538 : check e1402308261538 [[.left],[.left]] .chain = true := by decide
def e1402308292066 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308292066 : Closed e1402308292066 ∧ code e1402308292066 = 5800354803170 := by decide
theorem cert_e1402308292066 : check e1402308292066 [[.left],[.left]] .chain = true := by decide
def e1402308292450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402308292450 : Closed e1402308292450 ∧ code e1402308292450 = 5800354803554 := by decide
theorem cert_e1402308292450 : check e1402308292450 [[.left],[.left]] .chain = true := by decide
def e1402308294114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402308294114 : Closed e1402308294114 ∧ code e1402308294114 = 5800354805218 := by decide
theorem cert_e1402308294114 : check e1402308294114 [[.left],[.left]] .chain = true := by decide
def e1402308294370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402308294370 : Closed e1402308294370 ∧ code e1402308294370 = 5800354805474 := by decide
theorem cert_e1402308294370 : check e1402308294370 [[.left],[.left]] .smaller = true := by decide
end Blc.Floor42
