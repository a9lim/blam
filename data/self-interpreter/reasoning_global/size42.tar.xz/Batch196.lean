import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204331130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211204331130 : Closed e1211204331130 ∧ code e1211204331130 = 5609250842234 := by decide
theorem cert_e1211204331130 : check e1211204331130 [[],[]] .chain = true := by decide
def e1211204331294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211204331294 : Closed e1211204331294 ∧ code e1211204331294 = 5609250842398 := by decide
theorem cert_e1211204331294 : check e1211204331294 [[],[]] .chain = true := by decide
def e1211204331394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204331394 : Closed e1211204331394 ∧ code e1211204331394 = 5609250842498 := by decide
theorem cert_e1211204331394 : check e1211204331394 [[],[]] .chain = true := by decide
def e1211204331406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211204331406 : Closed e1211204331406 ∧ code e1211204331406 = 5609250842510 := by decide
theorem cert_e1211204331406 : check e1211204331406 [[],[]] .chain = true := by decide
def e1211204331418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204331418 : Closed e1211204331418 ∧ code e1211204331418 = 5609250842522 := by decide
theorem cert_e1211204331418 : check e1211204331418 [[],[]] .chain = true := by decide
def e1211204333598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211204333598 : Closed e1211204333598 ∧ code e1211204333598 = 5609250844702 := by decide
theorem cert_e1211204333598 : check e1211204333598 [[],[]] .chain = true := by decide
def e1211204333766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211204333766 : Closed e1211204333766 ∧ code e1211204333766 = 5609250844870 := by decide
theorem cert_e1211204333766 : check e1211204333766 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204333790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211204333790 : Closed e1211204333790 ∧ code e1211204333790 = 5609250844894 := by decide
theorem cert_e1211204333790 : check e1211204333790 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204333794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211204333794 : Closed e1211204333794 ∧ code e1211204333794 = 5609250844898 := by decide
theorem cert_e1211204333794 : check e1211204333794 [[],[]] .chain = true := by decide
def e1211204333806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211204333806 : Closed e1211204333806 ∧ code e1211204333806 = 5609250844910 := by decide
theorem cert_e1211204333806 : check e1211204333806 [[],[]] .chain = true := by decide
def e1211204333814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211204333814 : Closed e1211204333814 ∧ code e1211204333814 = 5609250844918 := by decide
theorem cert_e1211204333814 : check e1211204333814 [[],[]] .chain = true := by decide
def e1211204333818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211204333818 : Closed e1211204333818 ∧ code e1211204333818 = 5609250844922 := by decide
theorem cert_e1211204333818 : check e1211204333818 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204334294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211204334294 : Closed e1211204334294 ∧ code e1211204334294 = 5609250845398 := by decide
theorem cert_e1211204334294 : check e1211204334294 [[],[]] .chain = true := by decide
def e1211204334298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211204334298 : Closed e1211204334298 ∧ code e1211204334298 = 5609250845402 := by decide
theorem cert_e1211204334298 : check e1211204334298 [[],[]] .chain = true := by decide
def e1211204334314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211204334314 : Closed e1211204334314 ∧ code e1211204334314 = 5609250845418 := by decide
theorem cert_e1211204334314 : check e1211204334314 [[],[]] .chain = true := by decide
def e1211204334342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204334342 : Closed e1211204334342 ∧ code e1211204334342 = 5609250845446 := by decide
theorem cert_e1211204334342 : check e1211204334342 [[],[]] .chain = true := by decide
def e1211204334366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211204334366 : Closed e1211204334366 ∧ code e1211204334366 = 5609250845470 := by decide
theorem cert_e1211204334366 : check e1211204334366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204334390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204334390 : Closed e1211204334390 ∧ code e1211204334390 = 5609250845494 := by decide
theorem cert_e1211204334390 : check e1211204334390 [[],[]] .chain = true := by decide
def e1211204334394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204334394 : Closed e1211204334394 ∧ code e1211204334394 = 5609250845498 := by decide
theorem cert_e1211204334394 : check e1211204334394 [[],[]] .chain = true := by decide
def e1211204334466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204334466 : Closed e1211204334466 ∧ code e1211204334466 = 5609250845570 := by decide
theorem cert_e1211204334466 : check e1211204334466 [[],[]] .chain = true := by decide
def e1211204334478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211204334478 : Closed e1211204334478 ∧ code e1211204334478 = 5609250845582 := by decide
theorem cert_e1211204334478 : check e1211204334478 [[],[]] .chain = true := by decide
def e1211204334490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204334490 : Closed e1211204334490 ∧ code e1211204334490 = 5609250845594 := by decide
theorem cert_e1211204334490 : check e1211204334490 [[],[]] .chain = true := by decide
def e1211204334534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211204334534 : Closed e1211204334534 ∧ code e1211204334534 = 5609250845638 := by decide
theorem cert_e1211204334534 : check e1211204334534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204337910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))) (.var 1))))))
theorem wire_e1211204337910 : Closed e1211204337910 ∧ code e1211204337910 = 5609250849014 := by decide
theorem cert_e1211204337910 : check e1211204337910 [[],[]] .chain = true := by decide
def e1211204337914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 4)))))) (.var 0))))))
theorem wire_e1211204337914 : Closed e1211204337914 ∧ code e1211204337914 = 5609250849018 := by decide
theorem cert_e1211204337914 : check e1211204337914 [[],[]] .chain = true := by decide
def e1211204338294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204338294 : Closed e1211204338294 ∧ code e1211204338294 = 5609250849398 := by decide
theorem cert_e1211204338294 : check e1211204338294 [[],[]] .chain = true := by decide
def e1211204338486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204338486 : Closed e1211204338486 ∧ code e1211204338486 = 5609250849590 := by decide
theorem cert_e1211204338486 : check e1211204338486 [[],[]] .chain = true := by decide
def e1211204338490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204338490 : Closed e1211204338490 ∧ code e1211204338490 = 5609250849594 := by decide
theorem cert_e1211204338490 : check e1211204338490 [[],[]] .chain = true := by decide
def e1211204338574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.lam (.var 2)))))))
theorem wire_e1211204338574 : Closed e1211204338574 ∧ code e1211204338574 = 5609250849678 := by decide
theorem cert_e1211204338574 : check e1211204338574 [[],[]] .chain = true := by decide
def e1211204338630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.lam (.var 1)))))))
theorem wire_e1211204338630 : Closed e1211204338630 ∧ code e1211204338630 = 5609250849734 := by decide
theorem cert_e1211204338630 : check e1211204338630 [[],[]] .chain = true := by decide
def e1211204339254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e1211204339254 : Closed e1211204339254 ∧ code e1211204339254 = 5609250850358 := by decide
theorem cert_e1211204339254 : check e1211204339254 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204339342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e1211204339342 : Closed e1211204339342 ∧ code e1211204339342 = 5609250850446 := by decide
private def t_e1211204339342 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.lam (.var 1))))) (.lam (.var 2)))
theorem cert_e1211204339342 : ¬ IsSelfInterpreter e1211204339342 :=
  wIdentity (t := t_e1211204339342) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e1211204339342)) (by decide)) (by decide)
def e1211204339438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e1211204339438 : Closed e1211204339438 ∧ code e1211204339438 = 5609250850542 := by decide
theorem cert_e1211204339438 : check e1211204339438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204339446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e1211204339446 : Closed e1211204339446 ∧ code e1211204339446 = 5609250850550 := by decide
theorem cert_e1211204339446 : check e1211204339446 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204339478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211204339478 : Closed e1211204339478 ∧ code e1211204339478 = 5609250850582 := by decide
theorem cert_e1211204339478 : check e1211204339478 [[],[]] .chain = true := by decide
def e1211204339574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211204339574 : Closed e1211204339574 ∧ code e1211204339574 = 5609250850678 := by decide
theorem cert_e1211204339574 : check e1211204339574 [[],[]] .chain = true := by decide
def e1211204339594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211204339594 : Closed e1211204339594 ∧ code e1211204339594 = 5609250850698 := by decide
theorem cert_e1211204339594 : check e1211204339594 [[],[]] .chain = true := by decide
def e1211204339630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e1211204339630 : Closed e1211204339630 ∧ code e1211204339630 = 5609250850734 := by decide
theorem cert_e1211204339630 : check e1211204339630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204339638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211204339638 : Closed e1211204339638 ∧ code e1211204339638 = 5609250850742 := by decide
theorem cert_e1211204339638 : check e1211204339638 [[],[]] .chain = true := by decide
def e1211204339642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e1211204339642 : Closed e1211204339642 ∧ code e1211204339642 = 5609250850746 := by decide
theorem cert_e1211204339642 : check e1211204339642 [[],[]] .chain = true := by decide
def e1211204339670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e1211204339670 : Closed e1211204339670 ∧ code e1211204339670 = 5609250850774 := by decide
theorem cert_e1211204339670 : check e1211204339670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204340110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211204340110 : Closed e1211204340110 ∧ code e1211204340110 = 5609250851214 := by decide
theorem cert_e1211204340110 : check e1211204340110 [[],[]] .chain = true := by decide
def e1211204340166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211204340166 : Closed e1211204340166 ∧ code e1211204340166 = 5609250851270 := by decide
theorem cert_e1211204340166 : check e1211204340166 [[],[]] .chain = true := by decide
def e1211204340766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.lam (.var 3))))))))
theorem wire_e1211204340766 : Closed e1211204340766 ∧ code e1211204340766 = 5609250851870 := by decide
theorem cert_e1211204340766 : check e1211204340766 [[],[]] .chain = true := by decide
def e1211204340962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211204340962 : Closed e1211204340962 ∧ code e1211204340962 = 5609250852066 := by decide
theorem cert_e1211204340962 : check e1211204340962 [[],[]] .chain = true := by decide
def e1211204340974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211204340974 : Closed e1211204340974 ∧ code e1211204340974 = 5609250852078 := by decide
theorem cert_e1211204340974 : check e1211204340974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204340982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211204340982 : Closed e1211204340982 ∧ code e1211204340982 = 5609250852086 := by decide
theorem cert_e1211204340982 : check e1211204340982 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204341262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211204341262 : Closed e1211204341262 ∧ code e1211204341262 = 5609250852366 := by decide
theorem cert_e1211204341262 : check e1211204341262 [[],[]] .chain = true := by decide
def e1211204341274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211204341274 : Closed e1211204341274 ∧ code e1211204341274 = 5609250852378 := by decide
theorem cert_e1211204341274 : check e1211204341274 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204341346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211204341346 : Closed e1211204341346 ∧ code e1211204341346 = 5609250852450 := by decide
theorem cert_e1211204341346 : check e1211204341346 [[],[]] .chain = true := by decide
def e1211204341358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211204341358 : Closed e1211204341358 ∧ code e1211204341358 = 5609250852462 := by decide
theorem cert_e1211204341358 : check e1211204341358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204341366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204341366 : Closed e1211204341366 ∧ code e1211204341366 = 5609250852470 := by decide
theorem cert_e1211204341366 : check e1211204341366 [[],[]] .chain = true := by decide
def e1211204341370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211204341370 : Closed e1211204341370 ∧ code e1211204341370 = 5609250852474 := by decide
theorem cert_e1211204341370 : check e1211204341370 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204341558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204341558 : Closed e1211204341558 ∧ code e1211204341558 = 5609250852662 := by decide
theorem cert_e1211204341558 : check e1211204341558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211204341562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204341562 : Closed e1211204341562 ∧ code e1211204341562 = 5609250852666 := by decide
theorem cert_e1211204341562 : check e1211204341562 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204343478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211204343478 : Closed e1211204343478 ∧ code e1211204343478 = 5609250854582 := by decide
theorem cert_e1211204343478 : check e1211204343478 [[],[]] .chain = true := by decide
def e1211204343510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211204343510 : Closed e1211204343510 ∧ code e1211204343510 = 5609250854614 := by decide
theorem cert_e1211204343510 : check e1211204343510 [[],[]] .chain = true := by decide
def e1211204343514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e1211204343514 : Closed e1211204343514 ∧ code e1211204343514 = 5609250854618 := by decide
theorem cert_e1211204343514 : check e1211204343514 [[],[]] .chain = true := by decide
def e1211204343638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211204343638 : Closed e1211204343638 ∧ code e1211204343638 = 5609250854742 := by decide
theorem cert_e1211204343638 : check e1211204343638 [[],[]] .chain = true := by decide
def e1211204343642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211204343642 : Closed e1211204343642 ∧ code e1211204343642 = 5609250854746 := by decide
theorem cert_e1211204343642 : check e1211204343642 [[],[]] .chain = true := by decide
def e1211204343658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211204343658 : Closed e1211204343658 ∧ code e1211204343658 = 5609250854762 := by decide
theorem cert_e1211204343658 : check e1211204343658 [[],[]] .chain = true := by decide
def e1211204343862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 1))))))
theorem wire_e1211204343862 : Closed e1211204343862 ∧ code e1211204343862 = 5609250854966 := by decide
theorem cert_e1211204343862 : check e1211204343862 [[],[]] .chain = true := by decide
def e1211204343950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 2)))))))
theorem wire_e1211204343950 : Closed e1211204343950 ∧ code e1211204343950 = 5609250855054 := by decide
theorem cert_e1211204343950 : check e1211204343950 [[],[]] .chain = true := by decide
def e1211204344034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.lam (.var 0)))))))
theorem wire_e1211204344034 : Closed e1211204344034 ∧ code e1211204344034 = 5609250855138 := by decide
theorem cert_e1211204344034 : check e1211204344034 [[],[]] .chain = true := by decide
def e1211204344046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211204344046 : Closed e1211204344046 ∧ code e1211204344046 = 5609250855150 := by decide
theorem cert_e1211204344046 : check e1211204344046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204344054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211204344054 : Closed e1211204344054 ∧ code e1211204344054 = 5609250855158 := by decide
theorem cert_e1211204344054 : check e1211204344054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204344246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211204344246 : Closed e1211204344246 ∧ code e1211204344246 = 5609250855350 := by decide
theorem cert_e1211204344246 : check e1211204344246 [[],[]] .chain = true := by decide
def e1211204344278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211204344278 : Closed e1211204344278 ∧ code e1211204344278 = 5609250855382 := by decide
theorem cert_e1211204344278 : check e1211204344278 [[],[]] .chain = true := by decide
def e1211204344282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e1211204344282 : Closed e1211204344282 ∧ code e1211204344282 = 5609250855386 := by decide
theorem cert_e1211204344282 : check e1211204344282 [[],[]] .chain = true := by decide
def e1211204344438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211204344438 : Closed e1211204344438 ∧ code e1211204344438 = 5609250855542 := by decide
theorem cert_e1211204344438 : check e1211204344438 [[],[]] .chain = true := by decide
def e1211204344582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204344582 : Closed e1211204344582 ∧ code e1211204344582 = 5609250855686 := by decide
theorem cert_e1211204344582 : check e1211204344582 [[],[]] .chain = true := by decide
def e1211204344606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211204344606 : Closed e1211204344606 ∧ code e1211204344606 = 5609250855710 := by decide
theorem cert_e1211204344606 : check e1211204344606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204344630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204344630 : Closed e1211204344630 ∧ code e1211204344630 = 5609250855734 := by decide
theorem cert_e1211204344630 : check e1211204344630 [[],[]] .chain = true := by decide
def e1211204344634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204344634 : Closed e1211204344634 ∧ code e1211204344634 = 5609250855738 := by decide
theorem cert_e1211204344634 : check e1211204344634 [[],[]] .chain = true := by decide
def e1211204344718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211204344718 : Closed e1211204344718 ∧ code e1211204344718 = 5609250855822 := by decide
theorem cert_e1211204344718 : check e1211204344718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204344854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211204344854 : Closed e1211204344854 ∧ code e1211204344854 = 5609250855958 := by decide
theorem cert_e1211204344854 : check e1211204344854 [[],[]] .chain = true := by decide
def e1211204344858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211204344858 : Closed e1211204344858 ∧ code e1211204344858 = 5609250855962 := by decide
theorem cert_e1211204344858 : check e1211204344858 [[],[]] .chain = true := by decide
def e1211204344902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211204344902 : Closed e1211204344902 ∧ code e1211204344902 = 5609250856006 := by decide
theorem cert_e1211204344902 : check e1211204344902 [[],[]] .chain = true := by decide
def e1211204344930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211204344930 : Closed e1211204344930 ∧ code e1211204344930 = 5609250856034 := by decide
theorem cert_e1211204344930 : check e1211204344930 [[],[]] .chain = true := by decide
def e1211204344942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211204344942 : Closed e1211204344942 ∧ code e1211204344942 = 5609250856046 := by decide
theorem cert_e1211204344942 : check e1211204344942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204344950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211204344950 : Closed e1211204344950 ∧ code e1211204344950 = 5609250856054 := by decide
theorem cert_e1211204344950 : check e1211204344950 [[],[]] .chain = true := by decide
def e1211204344954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211204344954 : Closed e1211204344954 ∧ code e1211204344954 = 5609250856058 := by decide
theorem cert_e1211204344954 : check e1211204344954 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204345046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211204345046 : Closed e1211204345046 ∧ code e1211204345046 = 5609250856150 := by decide
theorem cert_e1211204345046 : check e1211204345046 [[],[]] .chain = true := by decide
def e1211204345050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211204345050 : Closed e1211204345050 ∧ code e1211204345050 = 5609250856154 := by decide
theorem cert_e1211204345050 : check e1211204345050 [[],[]] .chain = true := by decide
def e1211204345066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211204345066 : Closed e1211204345066 ∧ code e1211204345066 = 5609250856170 := by decide
theorem cert_e1211204345066 : check e1211204345066 [[],[]] .chain = true := by decide
def e1211204345094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211204345094 : Closed e1211204345094 ∧ code e1211204345094 = 5609250856198 := by decide
theorem cert_e1211204345094 : check e1211204345094 [[],[]] .chain = true := by decide
def e1211204345118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211204345118 : Closed e1211204345118 ∧ code e1211204345118 = 5609250856222 := by decide
theorem cert_e1211204345118 : check e1211204345118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204345142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211204345142 : Closed e1211204345142 ∧ code e1211204345142 = 5609250856246 := by decide
theorem cert_e1211204345142 : check e1211204345142 [[],[]] .chain = true := by decide
def e1211204345146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211204345146 : Closed e1211204345146 ∧ code e1211204345146 = 5609250856250 := by decide
theorem cert_e1211204345146 : check e1211204345146 [[],[]] .chain = true := by decide
def e1211204345218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211204345218 : Closed e1211204345218 ∧ code e1211204345218 = 5609250856322 := by decide
theorem cert_e1211204345218 : check e1211204345218 [[],[]] .chain = true := by decide
def e1211204345230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211204345230 : Closed e1211204345230 ∧ code e1211204345230 = 5609250856334 := by decide
theorem cert_e1211204345230 : check e1211204345230 [[],[]] .chain = true := by decide
def e1211204345242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211204345242 : Closed e1211204345242 ∧ code e1211204345242 = 5609250856346 := by decide
theorem cert_e1211204345242 : check e1211204345242 [[],[]] .chain = true := by decide
def e1211204345286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211204345286 : Closed e1211204345286 ∧ code e1211204345286 = 5609250856390 := by decide
theorem cert_e1211204345286 : check e1211204345286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204345398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211204345398 : Closed e1211204345398 ∧ code e1211204345398 = 5609250856502 := by decide
theorem cert_e1211204345398 : check e1211204345398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204345402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211204345402 : Closed e1211204345402 ∧ code e1211204345402 = 5609250856506 := by decide
theorem cert_e1211204345402 : check e1211204345402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204345486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211204345486 : Closed e1211204345486 ∧ code e1211204345486 = 5609250856590 := by decide
theorem cert_e1211204345486 : check e1211204345486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211204345542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211204345542 : Closed e1211204345542 ∧ code e1211204345542 = 5609250856646 := by decide
theorem cert_e1211204345542 : check e1211204345542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211204345918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211204345918 : Closed e1211204345918 ∧ code e1211204345918 = 5609250857022 := by decide
theorem cert_e1211204345918 : check e1211204345918 [[],[]] .chain = true := by decide
def e1211204346338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211204346338 : Closed e1211204346338 ∧ code e1211204346338 = 5609250857442 := by decide
theorem cert_e1211204346338 : check e1211204346338 [[],[]] .chain = true := by decide
def e1211204346350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211204346350 : Closed e1211204346350 ∧ code e1211204346350 = 5609250857454 := by decide
theorem cert_e1211204346350 : check e1211204346350 [[],[]] .chain = true := by decide
def e1211204347318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211204347318 : Closed e1211204347318 ∧ code e1211204347318 = 5609250858422 := by decide
theorem cert_e1211204347318 : check e1211204347318 [[],[]] .chain = true := by decide
def e1211204347350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211204347350 : Closed e1211204347350 ∧ code e1211204347350 = 5609250858454 := by decide
theorem cert_e1211204347350 : check e1211204347350 [[],[]] .chain = true := by decide
def e1211204347354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211204347354 : Closed e1211204347354 ∧ code e1211204347354 = 5609250858458 := by decide
theorem cert_e1211204347354 : check e1211204347354 [[],[]] .chain = true := by decide
def e1211204347510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211204347510 : Closed e1211204347510 ∧ code e1211204347510 = 5609250858614 := by decide
theorem cert_e1211204347510 : check e1211204347510 [[],[]] .chain = true := by decide
def e1211204347654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204347654 : Closed e1211204347654 ∧ code e1211204347654 = 5609250858758 := by decide
theorem cert_e1211204347654 : check e1211204347654 [[],[]] .chain = true := by decide
def e1211204347678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211204347678 : Closed e1211204347678 ∧ code e1211204347678 = 5609250858782 := by decide
theorem cert_e1211204347678 : check e1211204347678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211204347702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204347702 : Closed e1211204347702 ∧ code e1211204347702 = 5609250858806 := by decide
theorem cert_e1211204347702 : check e1211204347702 [[],[]] .chain = true := by decide
def e1211204347706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204347706 : Closed e1211204347706 ∧ code e1211204347706 = 5609250858810 := by decide
theorem cert_e1211204347706 : check e1211204347706 [[],[]] .chain = true := by decide
def e1211204347790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211204347790 : Closed e1211204347790 ∧ code e1211204347790 = 5609250858894 := by decide
theorem cert_e1211204347790 : check e1211204347790 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211204349982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211204349982 : Closed e1211204349982 ∧ code e1211204349982 = 5609250861086 := by decide
theorem cert_e1211204349982 : check e1211204349982 [[],[]] .chain = true := by decide
def e1211204350150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211204350150 : Closed e1211204350150 ∧ code e1211204350150 = 5609250861254 := by decide
theorem cert_e1211204350150 : check e1211204350150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204350174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211204350174 : Closed e1211204350174 ∧ code e1211204350174 = 5609250861278 := by decide
theorem cert_e1211204350174 : check e1211204350174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204350178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211204350178 : Closed e1211204350178 ∧ code e1211204350178 = 5609250861282 := by decide
theorem cert_e1211204350178 : check e1211204350178 [[],[]] .chain = true := by decide
def e1211204350190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211204350190 : Closed e1211204350190 ∧ code e1211204350190 = 5609250861294 := by decide
theorem cert_e1211204350190 : check e1211204350190 [[],[]] .chain = true := by decide
def e1211204350198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211204350198 : Closed e1211204350198 ∧ code e1211204350198 = 5609250861302 := by decide
theorem cert_e1211204350198 : check e1211204350198 [[],[]] .chain = true := by decide
def e1211204350202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211204350202 : Closed e1211204350202 ∧ code e1211204350202 = 5609250861306 := by decide
theorem cert_e1211204350202 : check e1211204350202 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204350678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211204350678 : Closed e1211204350678 ∧ code e1211204350678 = 5609250861782 := by decide
theorem cert_e1211204350678 : check e1211204350678 [[],[]] .chain = true := by decide
def e1211204350682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211204350682 : Closed e1211204350682 ∧ code e1211204350682 = 5609250861786 := by decide
theorem cert_e1211204350682 : check e1211204350682 [[],[]] .chain = true := by decide
def e1211204350698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211204350698 : Closed e1211204350698 ∧ code e1211204350698 = 5609250861802 := by decide
theorem cert_e1211204350698 : check e1211204350698 [[],[]] .chain = true := by decide
def e1211204350726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211204350726 : Closed e1211204350726 ∧ code e1211204350726 = 5609250861830 := by decide
theorem cert_e1211204350726 : check e1211204350726 [[],[]] .chain = true := by decide
def e1211204350750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211204350750 : Closed e1211204350750 ∧ code e1211204350750 = 5609250861854 := by decide
theorem cert_e1211204350750 : check e1211204350750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204350774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211204350774 : Closed e1211204350774 ∧ code e1211204350774 = 5609250861878 := by decide
theorem cert_e1211204350774 : check e1211204350774 [[],[]] .chain = true := by decide
def e1211204350778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211204350778 : Closed e1211204350778 ∧ code e1211204350778 = 5609250861882 := by decide
theorem cert_e1211204350778 : check e1211204350778 [[],[]] .chain = true := by decide
def e1211204350850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211204350850 : Closed e1211204350850 ∧ code e1211204350850 = 5609250861954 := by decide
theorem cert_e1211204350850 : check e1211204350850 [[],[]] .chain = true := by decide
def e1211204350862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211204350862 : Closed e1211204350862 ∧ code e1211204350862 = 5609250861966 := by decide
theorem cert_e1211204350862 : check e1211204350862 [[],[]] .chain = true := by decide
def e1211204350874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211204350874 : Closed e1211204350874 ∧ code e1211204350874 = 5609250861978 := by decide
theorem cert_e1211204350874 : check e1211204350874 [[],[]] .chain = true := by decide
def e1211204350918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211204350918 : Closed e1211204350918 ∧ code e1211204350918 = 5609250862022 := by decide
theorem cert_e1211204350918 : check e1211204350918 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211204352110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211204352110 : Closed e1211204352110 ∧ code e1211204352110 = 5609250863214 := by decide
theorem cert_e1211204352110 : check e1211204352110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204352122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211204352122 : Closed e1211204352122 ∧ code e1211204352122 = 5609250863226 := by decide
theorem cert_e1211204352122 : check e1211204352122 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204352398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211204352398 : Closed e1211204352398 ∧ code e1211204352398 = 5609250863502 := by decide
theorem cert_e1211204352398 : check e1211204352398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204352454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211204352454 : Closed e1211204352454 ∧ code e1211204352454 = 5609250863558 := by decide
theorem cert_e1211204352454 : check e1211204352454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211204376286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211204376286 : Closed e1211204376286 ∧ code e1211204376286 = 5609250887390 := by decide
theorem cert_e1211204376286 : check e1211204376286 [[],[]] .smaller = true := by decide
def e1211204376310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211204376310 : Closed e1211204376310 ∧ code e1211204376310 = 5609250887414 := by decide
theorem cert_e1211204376310 : check e1211204376310 [[],[]] .smaller = true := by decide
def e1211204376414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211204376414 : Closed e1211204376414 ∧ code e1211204376414 = 5609250887518 := by decide
theorem cert_e1211204376414 : check e1211204376414 [[],[]] .smaller = true := by decide
def e1211204376442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211204376442 : Closed e1211204376442 ∧ code e1211204376442 = 5609250887546 := by decide
theorem cert_e1211204376442 : check e1211204376442 [[],[]] .smaller = true := by decide
def e1211204376534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211204376534 : Closed e1211204376534 ∧ code e1211204376534 = 5609250887638 := by decide
theorem cert_e1211204376534 : check e1211204376534 [[],[]] .smaller = true := by decide
def e1211204376538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211204376538 : Closed e1211204376538 ∧ code e1211204376538 = 5609250887642 := by decide
theorem cert_e1211204376538 : check e1211204376538 [[],[]] .smaller = true := by decide
def e1211204377054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211204377054 : Closed e1211204377054 ∧ code e1211204377054 = 5609250888158 := by decide
theorem cert_e1211204377054 : check e1211204377054 [[],[]] .smaller = true := by decide
def e1211204377078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211204377078 : Closed e1211204377078 ∧ code e1211204377078 = 5609250888182 := by decide
theorem cert_e1211204377078 : check e1211204377078 [[],[]] .smaller = true := by decide
def e1211204377822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211204377822 : Closed e1211204377822 ∧ code e1211204377822 = 5609250888926 := by decide
theorem cert_e1211204377822 : check e1211204377822 [[],[]] .smaller = true := by decide
def e1211204377850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211204377850 : Closed e1211204377850 ∧ code e1211204377850 = 5609250888954 := by decide
theorem cert_e1211204377850 : check e1211204377850 [[],[]] .smaller = true := by decide
def e1211204378422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211204378422 : Closed e1211204378422 ∧ code e1211204378422 = 5609250889526 := by decide
theorem cert_e1211204378422 : check e1211204378422 [[],[]] .smaller = true := by decide
def e1211204378426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211204378426 : Closed e1211204378426 ∧ code e1211204378426 = 5609250889530 := by decide
theorem cert_e1211204378426 : check e1211204378426 [[],[]] .smaller = true := by decide
def e1211204393198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211204393198 : Closed e1211204393198 ∧ code e1211204393198 = 5609250904302 := by decide
theorem cert_e1211204393198 : check e1211204393198 [[],[]] .smaller = true := by decide
def e1211204393206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211204393206 : Closed e1211204393206 ∧ code e1211204393206 = 5609250904310 := by decide
theorem cert_e1211204393206 : check e1211204393206 [[],[]] .smaller = true := by decide
def e1211204393758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211204393758 : Closed e1211204393758 ∧ code e1211204393758 = 5609250904862 := by decide
theorem cert_e1211204393758 : check e1211204393758 [[],[]] .smaller = true := by decide
def e1211204393870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211204393870 : Closed e1211204393870 ∧ code e1211204393870 = 5609250904974 := by decide
theorem cert_e1211204393870 : check e1211204393870 [[],[]] .smaller = true := by decide
def e1211204394094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211204394094 : Closed e1211204394094 ∧ code e1211204394094 = 5609250905198 := by decide
theorem cert_e1211204394094 : check e1211204394094 [[],[]] .smaller = true := by decide
def e1211204394106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211204394106 : Closed e1211204394106 ∧ code e1211204394106 = 5609250905210 := by decide
theorem cert_e1211204394106 : check e1211204394106 [[],[]] .smaller = true := by decide
def e1211204394270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211204394270 : Closed e1211204394270 ∧ code e1211204394270 = 5609250905374 := by decide
theorem cert_e1211204394270 : check e1211204394270 [[],[]] .smaller = true := by decide
def e1211204394438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211204394438 : Closed e1211204394438 ∧ code e1211204394438 = 5609250905542 := by decide
theorem cert_e1211204394438 : check e1211204394438 [[],[]] .smaller = true := by decide
def e1211204394462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1211204394462 : Closed e1211204394462 ∧ code e1211204394462 = 5609250905566 := by decide
theorem cert_e1211204394462 : check e1211204394462 [[],[]] .chain = true := by decide
def e1211204394478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1211204394478 : Closed e1211204394478 ∧ code e1211204394478 = 5609250905582 := by decide
theorem cert_e1211204394478 : check e1211204394478 [[],[]] .chain = true := by decide
def e1211204394550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211204394550 : Closed e1211204394550 ∧ code e1211204394550 = 5609250905654 := by decide
theorem cert_e1211204394550 : check e1211204394550 [[],[]] .smaller = true := by decide
def e1211204394554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211204394554 : Closed e1211204394554 ∧ code e1211204394554 = 5609250905658 := by decide
theorem cert_e1211204394554 : check e1211204394554 [[],[]] .smaller = true := by decide
def e1211204394638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211204394638 : Closed e1211204394638 ∧ code e1211204394638 = 5609250905742 := by decide
theorem cert_e1211204394638 : check e1211204394638 [[],[]] .smaller = true := by decide
def e1211204394694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211204394694 : Closed e1211204394694 ∧ code e1211204394694 = 5609250905798 := by decide
theorem cert_e1211204394694 : check e1211204394694 [[],[]] .smaller = true := by decide
def e1211204394718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1211204394718 : Closed e1211204394718 ∧ code e1211204394718 = 5609250905822 := by decide
theorem cert_e1211204394718 : check e1211204394718 [[],[]] .chain = true := by decide
def e1211204394742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1211204394742 : Closed e1211204394742 ∧ code e1211204394742 = 5609250905846 := by decide
theorem cert_e1211204394742 : check e1211204394742 [[],[]] .chain = true := by decide
def e1211204394862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1211204394862 : Closed e1211204394862 ∧ code e1211204394862 = 5609250905966 := by decide
theorem cert_e1211204394862 : check e1211204394862 [[],[]] .chain = true := by decide
end Blc.Floor42
