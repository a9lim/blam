import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205209910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205209910 : Closed e1211205209910 ∧ code e1211205209910 = 5609251721014 := by decide
theorem cert_e1211205209910 : check e1211205209910 [[],[]] .chain = true := by decide
def e1211205209914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205209914 : Closed e1211205209914 ∧ code e1211205209914 = 5609251721018 := by decide
theorem cert_e1211205209914 : check e1211205209914 [[],[]] .chain = true := by decide
def e1211205214686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211205214686 : Closed e1211205214686 ∧ code e1211205214686 = 5609251725790 := by decide
theorem cert_e1211205214686 : check e1211205214686 [[],[]] .chain = true := by decide
def e1211205214710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211205214710 : Closed e1211205214710 ∧ code e1211205214710 = 5609251725814 := by decide
theorem cert_e1211205214710 : check e1211205214710 [[],[]] .chain = true := by decide
def e1211205215662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211205215662 : Closed e1211205215662 ∧ code e1211205215662 = 5609251726766 := by decide
theorem cert_e1211205215662 : check e1211205215662 [[],[]] .chain = true := by decide
def e1211205215674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211205215674 : Closed e1211205215674 ∧ code e1211205215674 = 5609251726778 := by decide
theorem cert_e1211205215674 : check e1211205215674 [[],[]] .chain = true := by decide
def e1211205215722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211205215722 : Closed e1211205215722 ∧ code e1211205215722 = 5609251726826 := by decide
theorem cert_e1211205215722 : check e1211205215722 [[],[]] .chain = true := by decide
def e1211205215854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205215854 : Closed e1211205215854 ∧ code e1211205215854 = 5609251726958 := by decide
theorem cert_e1211205215854 : check e1211205215854 [[],[]] .chain = true := by decide
def e1211205215866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205215866 : Closed e1211205215866 ∧ code e1211205215866 = 5609251726970 := by decide
theorem cert_e1211205215866 : check e1211205215866 [[],[]] .chain = true := by decide
def e1211205216030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211205216030 : Closed e1211205216030 ∧ code e1211205216030 = 5609251727134 := by decide
theorem cert_e1211205216030 : check e1211205216030 [[],[]] .chain = true := by decide
def e1211205216130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205216130 : Closed e1211205216130 ∧ code e1211205216130 = 5609251727234 := by decide
theorem cert_e1211205216130 : check e1211205216130 [[],[]] .chain = true := by decide
def e1211205216142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211205216142 : Closed e1211205216142 ∧ code e1211205216142 = 5609251727246 := by decide
theorem cert_e1211205216142 : check e1211205216142 [[],[]] .chain = true := by decide
def e1211205216154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205216154 : Closed e1211205216154 ∧ code e1211205216154 = 5609251727258 := by decide
theorem cert_e1211205216154 : check e1211205216154 [[],[]] .chain = true := by decide
def e1211205218334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211205218334 : Closed e1211205218334 ∧ code e1211205218334 = 5609251729438 := by decide
theorem cert_e1211205218334 : check e1211205218334 [[],[]] .chain = true := by decide
def e1211205218502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211205218502 : Closed e1211205218502 ∧ code e1211205218502 = 5609251729606 := by decide
theorem cert_e1211205218502 : checkPay e1211205218502 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205218526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205218526 : Closed e1211205218526 ∧ code e1211205218526 = 5609251729630 := by decide
theorem cert_e1211205218526 : checkPay e1211205218526 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205218530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211205218530 : Closed e1211205218530 ∧ code e1211205218530 = 5609251729634 := by decide
theorem cert_e1211205218530 : check e1211205218530 [[],[]] .chain = true := by decide
def e1211205218542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205218542 : Closed e1211205218542 ∧ code e1211205218542 = 5609251729646 := by decide
theorem cert_e1211205218542 : check e1211205218542 [[],[]] .chain = true := by decide
def e1211205218550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205218550 : Closed e1211205218550 ∧ code e1211205218550 = 5609251729654 := by decide
theorem cert_e1211205218550 : check e1211205218550 [[],[]] .chain = true := by decide
def e1211205218554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205218554 : Closed e1211205218554 ∧ code e1211205218554 = 5609251729658 := by decide
theorem cert_e1211205218554 : checkPay e1211205218554 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205219030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211205219030 : Closed e1211205219030 ∧ code e1211205219030 = 5609251730134 := by decide
theorem cert_e1211205219030 : check e1211205219030 [[],[]] .chain = true := by decide
def e1211205219034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211205219034 : Closed e1211205219034 ∧ code e1211205219034 = 5609251730138 := by decide
theorem cert_e1211205219034 : check e1211205219034 [[],[]] .chain = true := by decide
def e1211205219050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211205219050 : Closed e1211205219050 ∧ code e1211205219050 = 5609251730154 := by decide
theorem cert_e1211205219050 : check e1211205219050 [[],[]] .chain = true := by decide
def e1211205219078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205219078 : Closed e1211205219078 ∧ code e1211205219078 = 5609251730182 := by decide
theorem cert_e1211205219078 : check e1211205219078 [[],[]] .chain = true := by decide
def e1211205219102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211205219102 : Closed e1211205219102 ∧ code e1211205219102 = 5609251730206 := by decide
theorem cert_e1211205219102 : checkPay e1211205219102 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205219126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205219126 : Closed e1211205219126 ∧ code e1211205219126 = 5609251730230 := by decide
theorem cert_e1211205219126 : check e1211205219126 [[],[]] .chain = true := by decide
def e1211205219130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205219130 : Closed e1211205219130 ∧ code e1211205219130 = 5609251730234 := by decide
theorem cert_e1211205219130 : check e1211205219130 [[],[]] .chain = true := by decide
def e1211205219202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205219202 : Closed e1211205219202 ∧ code e1211205219202 = 5609251730306 := by decide
theorem cert_e1211205219202 : check e1211205219202 [[],[]] .chain = true := by decide
def e1211205219214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211205219214 : Closed e1211205219214 ∧ code e1211205219214 = 5609251730318 := by decide
theorem cert_e1211205219214 : check e1211205219214 [[],[]] .chain = true := by decide
def e1211205219226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205219226 : Closed e1211205219226 ∧ code e1211205219226 = 5609251730330 := by decide
theorem cert_e1211205219226 : check e1211205219226 [[],[]] .chain = true := by decide
def e1211205219270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211205219270 : Closed e1211205219270 ∧ code e1211205219270 = 5609251730374 := by decide
theorem cert_e1211205219270 : checkPay e1211205219270 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205289918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e1211205289918 : Closed e1211205289918 ∧ code e1211205289918 = 5609251801022 := by decide
theorem cert_e1211205289918 : check e1211205289918 [[],[]] .chain = true := by decide
def e1211205289966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e1211205289966 : Closed e1211205289966 ∧ code e1211205289966 = 5609251801070 := by decide
theorem cert_e1211205289966 : check e1211205289966 [[],[]] .chain = true := by decide
def e1211205293790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211205293790 : Closed e1211205293790 ∧ code e1211205293790 = 5609251804894 := by decide
theorem cert_e1211205293790 : check e1211205293790 [[],[]] .chain = true := by decide
def e1211205293814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211205293814 : Closed e1211205293814 ∧ code e1211205293814 = 5609251804918 := by decide
theorem cert_e1211205293814 : check e1211205293814 [[],[]] .chain = true := by decide
def e1211205293918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211205293918 : Closed e1211205293918 ∧ code e1211205293918 = 5609251805022 := by decide
theorem cert_e1211205293918 : check e1211205293918 [[],[]] .chain = true := by decide
def e1211205293946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211205293946 : Closed e1211205293946 ∧ code e1211205293946 = 5609251805050 := by decide
theorem cert_e1211205293946 : check e1211205293946 [[],[]] .chain = true := by decide
def e1211205294038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211205294038 : Closed e1211205294038 ∧ code e1211205294038 = 5609251805142 := by decide
theorem cert_e1211205294038 : check e1211205294038 [[],[]] .chain = true := by decide
def e1211205294042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211205294042 : Closed e1211205294042 ∧ code e1211205294042 = 5609251805146 := by decide
theorem cert_e1211205294042 : check e1211205294042 [[],[]] .chain = true := by decide
def e1211205294558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211205294558 : Closed e1211205294558 ∧ code e1211205294558 = 5609251805662 := by decide
theorem cert_e1211205294558 : check e1211205294558 [[],[]] .chain = true := by decide
def e1211205294582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211205294582 : Closed e1211205294582 ∧ code e1211205294582 = 5609251805686 := by decide
theorem cert_e1211205294582 : check e1211205294582 [[],[]] .chain = true := by decide
def e1211205295326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205295326 : Closed e1211205295326 ∧ code e1211205295326 = 5609251806430 := by decide
theorem cert_e1211205295326 : check e1211205295326 [[],[]] .chain = true := by decide
def e1211205295354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205295354 : Closed e1211205295354 ∧ code e1211205295354 = 5609251806458 := by decide
theorem cert_e1211205295354 : check e1211205295354 [[],[]] .chain = true := by decide
def e1211205295926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205295926 : Closed e1211205295926 ∧ code e1211205295926 = 5609251807030 := by decide
theorem cert_e1211205295926 : check e1211205295926 [[],[]] .chain = true := by decide
def e1211205295930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205295930 : Closed e1211205295930 ∧ code e1211205295930 = 5609251807034 := by decide
theorem cert_e1211205295930 : check e1211205295930 [[],[]] .chain = true := by decide
def e1211205310126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211205310126 : Closed e1211205310126 ∧ code e1211205310126 = 5609251821230 := by decide
theorem cert_e1211205310126 : check e1211205310126 [[],[]] .chain = true := by decide
def e1211205310138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211205310138 : Closed e1211205310138 ∧ code e1211205310138 = 5609251821242 := by decide
theorem cert_e1211205310138 : check e1211205310138 [[],[]] .chain = true := by decide
def e1211205310186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211205310186 : Closed e1211205310186 ∧ code e1211205310186 = 5609251821290 := by decide
theorem cert_e1211205310186 : check e1211205310186 [[],[]] .chain = true := by decide
def e1211205310378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211205310378 : Closed e1211205310378 ∧ code e1211205310378 = 5609251821482 := by decide
theorem cert_e1211205310378 : check e1211205310378 [[],[]] .chain = true := by decide
def e1211205310510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211205310510 : Closed e1211205310510 ∧ code e1211205310510 = 5609251821614 := by decide
theorem cert_e1211205310510 : check e1211205310510 [[],[]] .chain = true := by decide
def e1211205310702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211205310702 : Closed e1211205310702 ∧ code e1211205310702 = 5609251821806 := by decide
theorem cert_e1211205310702 : check e1211205310702 [[],[]] .chain = true := by decide
def e1211205310710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211205310710 : Closed e1211205310710 ∧ code e1211205310710 = 5609251821814 := by decide
theorem cert_e1211205310710 : check e1211205310710 [[],[]] .chain = true := by decide
def e1211205310894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211205310894 : Closed e1211205310894 ∧ code e1211205310894 = 5609251821998 := by decide
theorem cert_e1211205310894 : check e1211205310894 [[],[]] .chain = true := by decide
def e1211205310906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211205310906 : Closed e1211205310906 ∧ code e1211205310906 = 5609251822010 := by decide
theorem cert_e1211205310906 : check e1211205310906 [[],[]] .chain = true := by decide
def e1211205310954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211205310954 : Closed e1211205310954 ∧ code e1211205310954 = 5609251822058 := by decide
theorem cert_e1211205310954 : check e1211205310954 [[],[]] .chain = true := by decide
def e1211205311086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205311086 : Closed e1211205311086 ∧ code e1211205311086 = 5609251822190 := by decide
theorem cert_e1211205311086 : check e1211205311086 [[],[]] .chain = true := by decide
def e1211205311098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205311098 : Closed e1211205311098 ∧ code e1211205311098 = 5609251822202 := by decide
theorem cert_e1211205311098 : check e1211205311098 [[],[]] .chain = true := by decide
def e1211205311262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211205311262 : Closed e1211205311262 ∧ code e1211205311262 = 5609251822366 := by decide
theorem cert_e1211205311262 : check e1211205311262 [[],[]] .chain = true := by decide
def e1211205311362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205311362 : Closed e1211205311362 ∧ code e1211205311362 = 5609251822466 := by decide
theorem cert_e1211205311362 : check e1211205311362 [[],[]] .chain = true := by decide
def e1211205311374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211205311374 : Closed e1211205311374 ∧ code e1211205311374 = 5609251822478 := by decide
theorem cert_e1211205311374 : check e1211205311374 [[],[]] .chain = true := by decide
def e1211205311386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205311386 : Closed e1211205311386 ∧ code e1211205311386 = 5609251822490 := by decide
theorem cert_e1211205311386 : check e1211205311386 [[],[]] .chain = true := by decide
def e1211205311598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211205311598 : Closed e1211205311598 ∧ code e1211205311598 = 5609251822702 := by decide
theorem cert_e1211205311598 : check e1211205311598 [[],[]] .chain = true := by decide
def e1211205311610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211205311610 : Closed e1211205311610 ∧ code e1211205311610 = 5609251822714 := by decide
theorem cert_e1211205311610 : check e1211205311610 [[],[]] .chain = true := by decide
def e1211205311774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211205311774 : Closed e1211205311774 ∧ code e1211205311774 = 5609251822878 := by decide
theorem cert_e1211205311774 : check e1211205311774 [[],[]] .chain = true := by decide
def e1211205311942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211205311942 : Closed e1211205311942 ∧ code e1211205311942 = 5609251823046 := by decide
theorem cert_e1211205311942 : check e1211205311942 [[],[]] .chain = true := by decide
def e1211205312010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211205312010 : Closed e1211205312010 ∧ code e1211205312010 = 5609251823114 := by decide
theorem cert_e1211205312010 : check e1211205312010 [[],[]] .chain = true := by decide
def e1211205312054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205312054 : Closed e1211205312054 ∧ code e1211205312054 = 5609251823158 := by decide
theorem cert_e1211205312054 : check e1211205312054 [[],[]] .chain = true := by decide
def e1211205312058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205312058 : Closed e1211205312058 ∧ code e1211205312058 = 5609251823162 := by decide
theorem cert_e1211205312058 : check e1211205312058 [[],[]] .chain = true := by decide
def e1211205312106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211205312106 : Closed e1211205312106 ∧ code e1211205312106 = 5609251823210 := by decide
theorem cert_e1211205312106 : check e1211205312106 [[],[]] .chain = true := by decide
def e1211205312130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205312130 : Closed e1211205312130 ∧ code e1211205312130 = 5609251823234 := by decide
theorem cert_e1211205312130 : check e1211205312130 [[],[]] .chain = true := by decide
def e1211205312142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205312142 : Closed e1211205312142 ∧ code e1211205312142 = 5609251823246 := by decide
theorem cert_e1211205312142 : check e1211205312142 [[],[]] .chain = true := by decide
def e1211205312154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205312154 : Closed e1211205312154 ∧ code e1211205312154 = 5609251823258 := by decide
theorem cert_e1211205312154 : check e1211205312154 [[],[]] .chain = true := by decide
def e1211205312198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205312198 : Closed e1211205312198 ∧ code e1211205312198 = 5609251823302 := by decide
theorem cert_e1211205312198 : check e1211205312198 [[],[]] .chain = true := by decide
def e1211205312990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211205312990 : Closed e1211205312990 ∧ code e1211205312990 = 5609251824094 := by decide
theorem cert_e1211205312990 : check e1211205312990 [[],[]] .chain = true := by decide
def e1211205313014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211205313014 : Closed e1211205313014 ∧ code e1211205313014 = 5609251824118 := by decide
theorem cert_e1211205313014 : check e1211205313014 [[],[]] .chain = true := by decide
def e1211205313966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211205313966 : Closed e1211205313966 ∧ code e1211205313966 = 5609251825070 := by decide
theorem cert_e1211205313966 : check e1211205313966 [[],[]] .chain = true := by decide
def e1211205313978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211205313978 : Closed e1211205313978 ∧ code e1211205313978 = 5609251825082 := by decide
theorem cert_e1211205313978 : check e1211205313978 [[],[]] .chain = true := by decide
def e1211205314026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211205314026 : Closed e1211205314026 ∧ code e1211205314026 = 5609251825130 := by decide
theorem cert_e1211205314026 : check e1211205314026 [[],[]] .chain = true := by decide
def e1211205314158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205314158 : Closed e1211205314158 ∧ code e1211205314158 = 5609251825262 := by decide
theorem cert_e1211205314158 : check e1211205314158 [[],[]] .chain = true := by decide
def e1211205314170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205314170 : Closed e1211205314170 ∧ code e1211205314170 = 5609251825274 := by decide
theorem cert_e1211205314170 : check e1211205314170 [[],[]] .chain = true := by decide
def e1211205314334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211205314334 : Closed e1211205314334 ∧ code e1211205314334 = 5609251825438 := by decide
theorem cert_e1211205314334 : check e1211205314334 [[],[]] .chain = true := by decide
def e1211205314434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205314434 : Closed e1211205314434 ∧ code e1211205314434 = 5609251825538 := by decide
theorem cert_e1211205314434 : check e1211205314434 [[],[]] .chain = true := by decide
def e1211205314446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211205314446 : Closed e1211205314446 ∧ code e1211205314446 = 5609251825550 := by decide
theorem cert_e1211205314446 : check e1211205314446 [[],[]] .chain = true := by decide
def e1211205314458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205314458 : Closed e1211205314458 ∧ code e1211205314458 = 5609251825562 := by decide
theorem cert_e1211205314458 : check e1211205314458 [[],[]] .chain = true := by decide
def e1211205317406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211205317406 : Closed e1211205317406 ∧ code e1211205317406 = 5609251828510 := by decide
theorem cert_e1211205317406 : check e1211205317406 [[],[]] .chain = true := by decide
def e1211205317574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211205317574 : Closed e1211205317574 ∧ code e1211205317574 = 5609251828678 := by decide
theorem cert_e1211205317574 : check e1211205317574 [[],[]] .chain = true := by decide
def e1211205318774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205318774 : Closed e1211205318774 ∧ code e1211205318774 = 5609251829878 := by decide
theorem cert_e1211205318774 : check e1211205318774 [[],[]] .chain = true := by decide
def e1211205319018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211205319018 : Closed e1211205319018 ∧ code e1211205319018 = 5609251830122 := by decide
theorem cert_e1211205319018 : check e1211205319018 [[],[]] .chain = true := by decide
def e1211205319042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205319042 : Closed e1211205319042 ∧ code e1211205319042 = 5609251830146 := by decide
theorem cert_e1211205319042 : check e1211205319042 [[],[]] .chain = true := by decide
def e1211205319054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205319054 : Closed e1211205319054 ∧ code e1211205319054 = 5609251830158 := by decide
theorem cert_e1211205319054 : check e1211205319054 [[],[]] .chain = true := by decide
def e1211205319066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205319066 : Closed e1211205319066 ∧ code e1211205319066 = 5609251830170 := by decide
theorem cert_e1211205319066 : check e1211205319066 [[],[]] .chain = true := by decide
def e1211205319110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205319110 : Closed e1211205319110 ∧ code e1211205319110 = 5609251830214 := by decide
theorem cert_e1211205319110 : check e1211205319110 [[],[]] .chain = true := by decide
def e1211205354462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211205354462 : Closed e1211205354462 ∧ code e1211205354462 = 5609251865566 := by decide
theorem cert_e1211205354462 : check e1211205354462 [[],[]] .chain = true := by decide
def e1211205354478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211205354478 : Closed e1211205354478 ∧ code e1211205354478 = 5609251865582 := by decide
theorem cert_e1211205354478 : check e1211205354478 [[],[]] .chain = true := by decide
def e1211205356398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211205356398 : Closed e1211205356398 ∧ code e1211205356398 = 5609251867502 := by decide
theorem cert_e1211205356398 : check e1211205356398 [[],[]] .chain = true := by decide
def e1211205356406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211205356406 : Closed e1211205356406 ∧ code e1211205356406 = 5609251867510 := by decide
theorem cert_e1211205356406 : check e1211205356406 [[],[]] .chain = true := by decide
def e1211205356462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211205356462 : Closed e1211205356462 ∧ code e1211205356462 = 5609251867566 := by decide
theorem cert_e1211205356462 : check e1211205356462 [[],[]] .chain = true := by decide
def e1211205356470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1211205356470 : Closed e1211205356470 ∧ code e1211205356470 = 5609251867574 := by decide
theorem cert_e1211205356470 : check e1211205356470 [[],[]] .chain = true := by decide
def e1211205356474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211205356474 : Closed e1211205356474 ∧ code e1211205356474 = 5609251867578 := by decide
theorem cert_e1211205356474 : check e1211205356474 [[],[]] .chain = true := by decide
def e1211205356502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211205356502 : Closed e1211205356502 ∧ code e1211205356502 = 5609251867606 := by decide
theorem cert_e1211205356502 : check e1211205356502 [[],[]] .chain = true := by decide
def e1211205356506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211205356506 : Closed e1211205356506 ∧ code e1211205356506 = 5609251867610 := by decide
theorem cert_e1211205356506 : check e1211205356506 [[],[]] .chain = true := by decide
def e1211205356782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205356782 : Closed e1211205356782 ∧ code e1211205356782 = 5609251867886 := by decide
theorem cert_e1211205356782 : check e1211205356782 [[],[]] .chain = true := by decide
def e1211205356790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205356790 : Closed e1211205356790 ∧ code e1211205356790 = 5609251867894 := by decide
theorem cert_e1211205356790 : check e1211205356790 [[],[]] .chain = true := by decide
def e1211205357082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211205357082 : Closed e1211205357082 ∧ code e1211205357082 = 5609251868186 := by decide
theorem cert_e1211205357082 : checkPay e1211205357082 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205357118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211205357118 : Closed e1211205357118 ∧ code e1211205357118 = 5609251868222 := by decide
theorem cert_e1211205357118 : checkPay e1211205357118 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205357166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205357166 : Closed e1211205357166 ∧ code e1211205357166 = 5609251868270 := by decide
theorem cert_e1211205357166 : check e1211205357166 [[],[]] .chain = true := by decide
def e1211205357174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205357174 : Closed e1211205357174 ∧ code e1211205357174 = 5609251868278 := by decide
theorem cert_e1211205357174 : check e1211205357174 [[],[]] .chain = true := by decide
def e1211205357178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205357178 : Closed e1211205357178 ∧ code e1211205357178 = 5609251868282 := by decide
theorem cert_e1211205357178 : check e1211205357178 [[],[]] .chain = true := by decide
def e1211205357366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205357366 : Closed e1211205357366 ∧ code e1211205357366 = 5609251868470 := by decide
theorem cert_e1211205357366 : check e1211205357366 [[],[]] .chain = true := by decide
def e1211205357370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205357370 : Closed e1211205357370 ∧ code e1211205357370 = 5609251868474 := by decide
theorem cert_e1211205357370 : check e1211205357370 [[],[]] .chain = true := by decide
def e1211205357454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211205357454 : Closed e1211205357454 ∧ code e1211205357454 = 5609251868558 := by decide
theorem cert_e1211205357454 : checkPay e1211205357454 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205364566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211205364566 : Closed e1211205364566 ∧ code e1211205364566 = 5609251875670 := by decide
theorem cert_e1211205364566 : check e1211205364566 [[],[]] .chain = true := by decide
def e1211205364570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211205364570 : Closed e1211205364570 ∧ code e1211205364570 = 5609251875674 := by decide
theorem cert_e1211205364570 : check e1211205364570 [[],[]] .chain = true := by decide
def e1211205364586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211205364586 : Closed e1211205364586 ∧ code e1211205364586 = 5609251875690 := by decide
theorem cert_e1211205364586 : check e1211205364586 [[],[]] .chain = true := by decide
def e1211205364650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211205364650 : Closed e1211205364650 ∧ code e1211205364650 = 5609251875754 := by decide
theorem cert_e1211205364650 : check e1211205364650 [[],[]] .chain = true := by decide
def e1211205364758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211205364758 : Closed e1211205364758 ∧ code e1211205364758 = 5609251875862 := by decide
theorem cert_e1211205364758 : check e1211205364758 [[],[]] .chain = true := by decide
def e1211205364762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211205364762 : Closed e1211205364762 ∧ code e1211205364762 = 5609251875866 := by decide
theorem cert_e1211205364762 : check e1211205364762 [[],[]] .chain = true := by decide
def e1211205364806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211205364806 : Closed e1211205364806 ∧ code e1211205364806 = 5609251875910 := by decide
theorem cert_e1211205364806 : check e1211205364806 [[],[]] .chain = true := by decide
def e1211205364834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211205364834 : Closed e1211205364834 ∧ code e1211205364834 = 5609251875938 := by decide
theorem cert_e1211205364834 : check e1211205364834 [[],[]] .chain = true := by decide
def e1211205364846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211205364846 : Closed e1211205364846 ∧ code e1211205364846 = 5609251875950 := by decide
theorem cert_e1211205364846 : checkPay e1211205364846 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205364854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211205364854 : Closed e1211205364854 ∧ code e1211205364854 = 5609251875958 := by decide
theorem cert_e1211205364854 : check e1211205364854 [[],[]] .chain = true := by decide
def e1211205364858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211205364858 : Closed e1211205364858 ∧ code e1211205364858 = 5609251875962 := by decide
theorem cert_e1211205364858 : checkPay e1211205364858 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205364950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211205364950 : Closed e1211205364950 ∧ code e1211205364950 = 5609251876054 := by decide
theorem cert_e1211205364950 : check e1211205364950 [[],[]] .chain = true := by decide
def e1211205364954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211205364954 : Closed e1211205364954 ∧ code e1211205364954 = 5609251876058 := by decide
theorem cert_e1211205364954 : check e1211205364954 [[],[]] .chain = true := by decide
def e1211205364970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211205364970 : Closed e1211205364970 ∧ code e1211205364970 = 5609251876074 := by decide
theorem cert_e1211205364970 : check e1211205364970 [[],[]] .chain = true := by decide
def e1211205364998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205364998 : Closed e1211205364998 ∧ code e1211205364998 = 5609251876102 := by decide
theorem cert_e1211205364998 : check e1211205364998 [[],[]] .chain = true := by decide
def e1211205365022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211205365022 : Closed e1211205365022 ∧ code e1211205365022 = 5609251876126 := by decide
theorem cert_e1211205365022 : checkPay e1211205365022 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205365046 : Closed e1211205365046 ∧ code e1211205365046 = 5609251876150 := by decide
theorem cert_e1211205365046 : check e1211205365046 [[],[]] .chain = true := by decide
def e1211205365050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205365050 : Closed e1211205365050 ∧ code e1211205365050 = 5609251876154 := by decide
theorem cert_e1211205365050 : check e1211205365050 [[],[]] .chain = true := by decide
def e1211205365122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205365122 : Closed e1211205365122 ∧ code e1211205365122 = 5609251876226 := by decide
theorem cert_e1211205365122 : check e1211205365122 [[],[]] .chain = true := by decide
def e1211205365134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211205365134 : Closed e1211205365134 ∧ code e1211205365134 = 5609251876238 := by decide
theorem cert_e1211205365134 : check e1211205365134 [[],[]] .chain = true := by decide
def e1211205365146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205365146 : Closed e1211205365146 ∧ code e1211205365146 = 5609251876250 := by decide
theorem cert_e1211205365146 : check e1211205365146 [[],[]] .chain = true := by decide
def e1211205365190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211205365190 : Closed e1211205365190 ∧ code e1211205365190 = 5609251876294 := by decide
theorem cert_e1211205365190 : checkPay e1211205365190 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211205365258 : Closed e1211205365258 ∧ code e1211205365258 = 5609251876362 := by decide
theorem cert_e1211205365258 : check e1211205365258 [[],[]] .chain = true := by decide
def e1211205365302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205365302 : Closed e1211205365302 ∧ code e1211205365302 = 5609251876406 := by decide
theorem cert_e1211205365302 : check e1211205365302 [[],[]] .chain = true := by decide
def e1211205365306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205365306 : Closed e1211205365306 ∧ code e1211205365306 = 5609251876410 := by decide
theorem cert_e1211205365306 : check e1211205365306 [[],[]] .chain = true := by decide
def e1211205365354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211205365354 : Closed e1211205365354 ∧ code e1211205365354 = 5609251876458 := by decide
theorem cert_e1211205365354 : check e1211205365354 [[],[]] .chain = true := by decide
def e1211205365378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205365378 : Closed e1211205365378 ∧ code e1211205365378 = 5609251876482 := by decide
theorem cert_e1211205365378 : check e1211205365378 [[],[]] .chain = true := by decide
def e1211205365390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205365390 : Closed e1211205365390 ∧ code e1211205365390 = 5609251876494 := by decide
theorem cert_e1211205365390 : check e1211205365390 [[],[]] .chain = true := by decide
def e1211205365402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205365402 : Closed e1211205365402 ∧ code e1211205365402 = 5609251876506 := by decide
theorem cert_e1211205365402 : check e1211205365402 [[],[]] .chain = true := by decide
def e1211205365446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205365446 : Closed e1211205365446 ∧ code e1211205365446 = 5609251876550 := by decide
theorem cert_e1211205365446 : check e1211205365446 [[],[]] .chain = true := by decide
def e1211205365530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211205365530 : Closed e1211205365530 ∧ code e1211205365530 = 5609251876634 := by decide
theorem cert_e1211205365530 : checkPay e1211205365530 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211205365574 : Closed e1211205365574 ∧ code e1211205365574 = 5609251876678 := by decide
theorem cert_e1211205365574 : checkPay e1211205365574 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211205365790 : Closed e1211205365790 ∧ code e1211205365790 = 5609251876894 := by decide
theorem cert_e1211205365790 : check e1211205365790 [[],[]] .chain = true := by decide
def e1211205365958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211205365958 : Closed e1211205365958 ∧ code e1211205365958 = 5609251877062 := by decide
theorem cert_e1211205365958 : checkPay e1211205365958 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205365982 : Closed e1211205365982 ∧ code e1211205365982 = 5609251877086 := by decide
theorem cert_e1211205365982 : checkPay e1211205365982 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205365986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211205365986 : Closed e1211205365986 ∧ code e1211205365986 = 5609251877090 := by decide
theorem cert_e1211205365986 : check e1211205365986 [[],[]] .chain = true := by decide
def e1211205365998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205365998 : Closed e1211205365998 ∧ code e1211205365998 = 5609251877102 := by decide
theorem cert_e1211205365998 : check e1211205365998 [[],[]] .chain = true := by decide
def e1211205366006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205366006 : Closed e1211205366006 ∧ code e1211205366006 = 5609251877110 := by decide
theorem cert_e1211205366006 : check e1211205366006 [[],[]] .chain = true := by decide
def e1211205366010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205366010 : Closed e1211205366010 ∧ code e1211205366010 = 5609251877114 := by decide
theorem cert_e1211205366010 : checkPay e1211205366010 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205366486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211205366486 : Closed e1211205366486 ∧ code e1211205366486 = 5609251877590 := by decide
theorem cert_e1211205366486 : check e1211205366486 [[],[]] .chain = true := by decide
def e1211205366490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211205366490 : Closed e1211205366490 ∧ code e1211205366490 = 5609251877594 := by decide
theorem cert_e1211205366490 : check e1211205366490 [[],[]] .chain = true := by decide
def e1211205366506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211205366506 : Closed e1211205366506 ∧ code e1211205366506 = 5609251877610 := by decide
theorem cert_e1211205366506 : check e1211205366506 [[],[]] .chain = true := by decide
def e1211205366534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205366534 : Closed e1211205366534 ∧ code e1211205366534 = 5609251877638 := by decide
theorem cert_e1211205366534 : check e1211205366534 [[],[]] .chain = true := by decide
def e1211205366558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211205366558 : Closed e1211205366558 ∧ code e1211205366558 = 5609251877662 := by decide
theorem cert_e1211205366558 : checkPay e1211205366558 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205366582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205366582 : Closed e1211205366582 ∧ code e1211205366582 = 5609251877686 := by decide
theorem cert_e1211205366582 : check e1211205366582 [[],[]] .chain = true := by decide
def e1211205366586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205366586 : Closed e1211205366586 ∧ code e1211205366586 = 5609251877690 := by decide
theorem cert_e1211205366586 : check e1211205366586 [[],[]] .chain = true := by decide
def e1211205366658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205366658 : Closed e1211205366658 ∧ code e1211205366658 = 5609251877762 := by decide
theorem cert_e1211205366658 : check e1211205366658 [[],[]] .chain = true := by decide
def e1211205366670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211205366670 : Closed e1211205366670 ∧ code e1211205366670 = 5609251877774 := by decide
theorem cert_e1211205366670 : check e1211205366670 [[],[]] .chain = true := by decide
def e1211205366682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205366682 : Closed e1211205366682 ∧ code e1211205366682 = 5609251877786 := by decide
theorem cert_e1211205366682 : check e1211205366682 [[],[]] .chain = true := by decide
end Blc.Floor42
