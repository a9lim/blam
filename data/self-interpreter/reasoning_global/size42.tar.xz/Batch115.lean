import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205824696154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205824696154 : Closed e1205824696154 ∧ code e1205824696154 = 5603871207258 := by decide
theorem cert_e1205824696154 : check e1205824696154 [[],[]] .smaller = true := by decide
def e1205824696170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205824696170 : Closed e1205824696170 ∧ code e1205824696170 = 5603871207274 := by decide
theorem cert_e1205824696170 : check e1205824696170 [[],[]] .smaller = true := by decide
def e1205824697198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1205824697198 : Closed e1205824697198 ∧ code e1205824697198 = 5603871208302 := by decide
theorem cert_e1205824697198 : check e1205824697198 [[],[]] .smaller = true := by decide
def e1205824697206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1205824697206 : Closed e1205824697206 ∧ code e1205824697206 = 5603871208310 := by decide
theorem cert_e1205824697206 : check e1205824697206 [[],[]] .smaller = true := by decide
def e1205824697262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1205824697262 : Closed e1205824697262 ∧ code e1205824697262 = 5603871208366 := by decide
theorem cert_e1205824697262 : check e1205824697262 [[],[]] .smaller = true := by decide
def e1205824697274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1205824697274 : Closed e1205824697274 ∧ code e1205824697274 = 5603871208378 := by decide
theorem cert_e1205824697274 : check e1205824697274 [[],[]] .smaller = true := by decide
def e1205824697302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1205824697302 : Closed e1205824697302 ∧ code e1205824697302 = 5603871208406 := by decide
theorem cert_e1205824697302 : check e1205824697302 [[],[]] .smaller = true := by decide
def e1205824697306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1205824697306 : Closed e1205824697306 ∧ code e1205824697306 = 5603871208410 := by decide
theorem cert_e1205824697306 : check e1205824697306 [[],[]] .smaller = true := by decide
def e1205824697582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205824697582 : Closed e1205824697582 ∧ code e1205824697582 = 5603871208686 := by decide
theorem cert_e1205824697582 : check e1205824697582 [[],[]] .smaller = true := by decide
def e1205824697590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205824697590 : Closed e1205824697590 ∧ code e1205824697590 = 5603871208694 := by decide
theorem cert_e1205824697590 : check e1205824697590 [[],[]] .smaller = true := by decide
def e1205824697966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205824697966 : Closed e1205824697966 ∧ code e1205824697966 = 5603871209070 := by decide
theorem cert_e1205824697966 : check e1205824697966 [[],[]] .smaller = true := by decide
def e1205824697978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205824697978 : Closed e1205824697978 ∧ code e1205824697978 = 5603871209082 := by decide
theorem cert_e1205824697978 : check e1205824697978 [[],[]] .smaller = true := by decide
def e1205824698166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205824698166 : Closed e1205824698166 ∧ code e1205824698166 = 5603871209270 := by decide
theorem cert_e1205824698166 : check e1205824698166 [[],[]] .smaller = true := by decide
def e1205824698170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205824698170 : Closed e1205824698170 ∧ code e1205824698170 = 5603871209274 := by decide
theorem cert_e1205824698170 : check e1205824698170 [[],[]] .smaller = true := by decide
def e1205824698798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205824698798 : Closed e1205824698798 ∧ code e1205824698798 = 5603871209902 := by decide
theorem cert_e1205824698798 : check e1205824698798 [[],[]] .smaller = true := by decide
def e1205824698810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205824698810 : Closed e1205824698810 ∧ code e1205824698810 = 5603871209914 := by decide
theorem cert_e1205824698810 : check e1205824698810 [[],[]] .smaller = true := by decide
def e1205824698858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205824698858 : Closed e1205824698858 ∧ code e1205824698858 = 5603871209962 := by decide
theorem cert_e1205824698858 : check e1205824698858 [[],[]] .smaller = true := by decide
def e1205824698990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205824698990 : Closed e1205824698990 ∧ code e1205824698990 = 5603871210094 := by decide
theorem cert_e1205824698990 : check e1205824698990 [[],[]] .smaller = true := by decide
def e1205824699002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205824699002 : Closed e1205824699002 ∧ code e1205824699002 = 5603871210106 := by decide
theorem cert_e1205824699002 : check e1205824699002 [[],[]] .smaller = true := by decide
def e1205824699290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205824699290 : Closed e1205824699290 ∧ code e1205824699290 = 5603871210394 := by decide
theorem cert_e1205824699290 : check e1205824699290 [[],[]] .smaller = true := by decide
def e1205824699606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205824699606 : Closed e1205824699606 ∧ code e1205824699606 = 5603871210710 := by decide
theorem cert_e1205824699606 : check e1205824699606 [[],[]] .smaller = true := by decide
def e1205824699610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205824699610 : Closed e1205824699610 ∧ code e1205824699610 = 5603871210714 := by decide
theorem cert_e1205824699610 : check e1205824699610 [[],[]] .smaller = true := by decide
def e1205824699626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205824699626 : Closed e1205824699626 ∧ code e1205824699626 = 5603871210730 := by decide
theorem cert_e1205824699626 : check e1205824699626 [[],[]] .smaller = true := by decide
def e1205824699702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205824699702 : Closed e1205824699702 ∧ code e1205824699702 = 5603871210806 := by decide
theorem cert_e1205824699702 : check e1205824699702 [[],[]] .smaller = true := by decide
def e1205824699706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205824699706 : Closed e1205824699706 ∧ code e1205824699706 = 5603871210810 := by decide
theorem cert_e1205824699706 : check e1205824699706 [[],[]] .smaller = true := by decide
def e1205824699802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205824699802 : Closed e1205824699802 ∧ code e1205824699802 = 5603871210906 := by decide
theorem cert_e1205824699802 : check e1205824699802 [[],[]] .smaller = true := by decide
def e1205824701406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1205824701406 : Closed e1205824701406 ∧ code e1205824701406 = 5603871212510 := by decide
theorem cert_e1205824701406 : check e1205824701406 [[],[]] .smaller = true := by decide
def e1205824701422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1205824701422 : Closed e1205824701422 ∧ code e1205824701422 = 5603871212526 := by decide
theorem cert_e1205824701422 : check e1205824701422 [[],[]] .smaller = true := by decide
def e1205824703342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205824703342 : Closed e1205824703342 ∧ code e1205824703342 = 5603871214446 := by decide
theorem cert_e1205824703342 : check e1205824703342 [[],[]] .smaller = true := by decide
def e1205824703350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205824703350 : Closed e1205824703350 ∧ code e1205824703350 = 5603871214454 := by decide
theorem cert_e1205824703350 : check e1205824703350 [[],[]] .smaller = true := by decide
def e1205824703406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205824703406 : Closed e1205824703406 ∧ code e1205824703406 = 5603871214510 := by decide
theorem cert_e1205824703406 : check e1205824703406 [[],[]] .smaller = true := by decide
def e1205824703418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205824703418 : Closed e1205824703418 ∧ code e1205824703418 = 5603871214522 := by decide
theorem cert_e1205824703418 : check e1205824703418 [[],[]] .smaller = true := by decide
def e1205824703446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205824703446 : Closed e1205824703446 ∧ code e1205824703446 = 5603871214550 := by decide
theorem cert_e1205824703446 : check e1205824703446 [[],[]] .smaller = true := by decide
def e1205824703450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205824703450 : Closed e1205824703450 ∧ code e1205824703450 = 5603871214554 := by decide
theorem cert_e1205824703450 : check e1205824703450 [[],[]] .smaller = true := by decide
def e1205824703726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205824703726 : Closed e1205824703726 ∧ code e1205824703726 = 5603871214830 := by decide
theorem cert_e1205824703726 : check e1205824703726 [[],[]] .smaller = true := by decide
def e1205824703734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205824703734 : Closed e1205824703734 ∧ code e1205824703734 = 5603871214838 := by decide
theorem cert_e1205824703734 : check e1205824703734 [[],[]] .smaller = true := by decide
def e1205824704110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205824704110 : Closed e1205824704110 ∧ code e1205824704110 = 5603871215214 := by decide
theorem cert_e1205824704110 : check e1205824704110 [[],[]] .smaller = true := by decide
def e1205824704122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205824704122 : Closed e1205824704122 ∧ code e1205824704122 = 5603871215226 := by decide
theorem cert_e1205824704122 : check e1205824704122 [[],[]] .smaller = true := by decide
def e1205824704310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205824704310 : Closed e1205824704310 ∧ code e1205824704310 = 5603871215414 := by decide
theorem cert_e1205824704310 : check e1205824704310 [[],[]] .smaller = true := by decide
def e1205824704314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205824704314 : Closed e1205824704314 ∧ code e1205824704314 = 5603871215418 := by decide
theorem cert_e1205824704314 : check e1205824704314 [[],[]] .smaller = true := by decide
def e1205824709086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1205824709086 : Closed e1205824709086 ∧ code e1205824709086 = 5603871220190 := by decide
theorem cert_e1205824709086 : check e1205824709086 [[],[]] .smaller = true := by decide
def e1205824709110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1205824709110 : Closed e1205824709110 ∧ code e1205824709110 = 5603871220214 := by decide
theorem cert_e1205824709110 : check e1205824709110 [[],[]] .smaller = true := by decide
def e1205824710062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205824710062 : Closed e1205824710062 ∧ code e1205824710062 = 5603871221166 := by decide
theorem cert_e1205824710062 : check e1205824710062 [[],[]] .smaller = true := by decide
def e1205824710074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205824710074 : Closed e1205824710074 ∧ code e1205824710074 = 5603871221178 := by decide
theorem cert_e1205824710074 : check e1205824710074 [[],[]] .smaller = true := by decide
def e1205824710122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205824710122 : Closed e1205824710122 ∧ code e1205824710122 = 5603871221226 := by decide
theorem cert_e1205824710122 : check e1205824710122 [[],[]] .smaller = true := by decide
def e1205824710254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205824710254 : Closed e1205824710254 ∧ code e1205824710254 = 5603871221358 := by decide
theorem cert_e1205824710254 : check e1205824710254 [[],[]] .smaller = true := by decide
def e1205824710266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205824710266 : Closed e1205824710266 ∧ code e1205824710266 = 5603871221370 := by decide
theorem cert_e1205824710266 : check e1205824710266 [[],[]] .smaller = true := by decide
def e1205824710554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205824710554 : Closed e1205824710554 ∧ code e1205824710554 = 5603871221658 := by decide
theorem cert_e1205824710554 : check e1205824710554 [[],[]] .smaller = true := by decide
def e1205824712942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1205824712942 : Closed e1205824712942 ∧ code e1205824712942 = 5603871224046 := by decide
theorem cert_e1205824712942 : check e1205824712942 [[],[]] .smaller = true := by decide
def e1205824712950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1205824712950 : Closed e1205824712950 ∧ code e1205824712950 = 5603871224054 := by decide
theorem cert_e1205824712950 : check e1205824712950 [[],[]] .smaller = true := by decide
def e1205824713430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205824713430 : Closed e1205824713430 ∧ code e1205824713430 = 5603871224534 := by decide
theorem cert_e1205824713430 : check e1205824713430 [[],[]] .smaller = true := by decide
def e1205824713434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205824713434 : Closed e1205824713434 ∧ code e1205824713434 = 5603871224538 := by decide
theorem cert_e1205824713434 : check e1205824713434 [[],[]] .smaller = true := by decide
def e1205824713450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205824713450 : Closed e1205824713450 ∧ code e1205824713450 = 5603871224554 := by decide
theorem cert_e1205824713450 : check e1205824713450 [[],[]] .smaller = true := by decide
def e1205824713526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205824713526 : Closed e1205824713526 ∧ code e1205824713526 = 5603871224630 := by decide
theorem cert_e1205824713526 : check e1205824713526 [[],[]] .smaller = true := by decide
def e1205824713530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205824713530 : Closed e1205824713530 ∧ code e1205824713530 = 5603871224634 := by decide
theorem cert_e1205824713530 : check e1205824713530 [[],[]] .smaller = true := by decide
def e1205824713626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205824713626 : Closed e1205824713626 ∧ code e1205824713626 = 5603871224730 := by decide
theorem cert_e1205824713626 : check e1205824713626 [[],[]] .smaller = true := by decide
def e1205824827758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1205824827758 : Closed e1205824827758 ∧ code e1205824827758 = 5603871338862 := by decide
theorem cert_e1205824827758 : check e1205824827758 [[],[]] .chain = true := by decide
def e1205824827766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1205824827766 : Closed e1205824827766 ∧ code e1205824827766 = 5603871338870 := by decide
theorem cert_e1205824827766 : check e1205824827766 [[],[]] .chain = true := by decide
def e1205824828974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205824828974 : Closed e1205824828974 ∧ code e1205824828974 = 5603871340078 := by decide
theorem cert_e1205824828974 : check e1205824828974 [[],[]] .chain = true := by decide
def e1205824829154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205824829154 : Closed e1205824829154 ∧ code e1205824829154 = 5603871340258 := by decide
theorem cert_e1205824829154 : check e1205824829154 [[],[]] .chain = true := by decide
def e1205824829166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e1205824829166 : Closed e1205824829166 ∧ code e1205824829166 = 5603871340270 := by decide
theorem cert_e1205824829166 : check e1205824829166 [[],[]] .sourceHead = true := by decide
def e1205824829206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205824829206 : Closed e1205824829206 ∧ code e1205824829206 = 5603871340310 := by decide
theorem cert_e1205824829206 : check e1205824829206 [[],[]] .chain = true := by decide
def e1205824829282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205824829282 : Closed e1205824829282 ∧ code e1205824829282 = 5603871340386 := by decide
theorem cert_e1205824829282 : check e1205824829282 [[],[]] .chain = true := by decide
def e1205824829294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e1205824829294 : Closed e1205824829294 ∧ code e1205824829294 = 5603871340398 := by decide
theorem cert_e1205824829294 : check e1205824829294 [[],[]] .sourceHead = true := by decide
def e1205824829302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e1205824829302 : Closed e1205824829302 ∧ code e1205824829302 = 5603871340406 := by decide
theorem cert_e1205824829302 : check e1205824829302 [[],[]] .sourceHead = true := by decide
def e1205824829614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205824829614 : Closed e1205824829614 ∧ code e1205824829614 = 5603871340718 := by decide
theorem cert_e1205824829614 : check e1205824829614 [[],[]] .chain = true := by decide
def e1205824829626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205824829626 : Closed e1205824829626 ∧ code e1205824829626 = 5603871340730 := by decide
theorem cert_e1205824829626 : check e1205824829626 [[],[]] .chain = true := by decide
def e1205824829998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205824829998 : Closed e1205824829998 ∧ code e1205824829998 = 5603871341102 := by decide
theorem cert_e1205824829998 : check e1205824829998 [[],[]] .chain = true := by decide
def e1205824830178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205824830178 : Closed e1205824830178 ∧ code e1205824830178 = 5603871341282 := by decide
theorem cert_e1205824830178 : check e1205824830178 [[],[]] .chain = true := by decide
def e1205824830190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1205824830190 : Closed e1205824830190 ∧ code e1205824830190 = 5603871341294 := by decide
theorem cert_e1205824830190 : check e1205824830190 [[],[]] .sourceHead = true := by decide
def e1205824830346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205824830346 : Closed e1205824830346 ∧ code e1205824830346 = 5603871341450 := by decide
theorem cert_e1205824830346 : check e1205824830346 [[],[]] .chain = true := by decide
def e1205824830370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205824830370 : Closed e1205824830370 ∧ code e1205824830370 = 5603871341474 := by decide
theorem cert_e1205824830370 : check e1205824830370 [[],[]] .chain = true := by decide
def e1205824830382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1205824830382 : Closed e1205824830382 ∧ code e1205824830382 = 5603871341486 := by decide
theorem cert_e1205824830382 : check e1205824830382 [[],[]] .sourceHead = true := by decide
def e1205824830394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1205824830394 : Closed e1205824830394 ∧ code e1205824830394 = 5603871341498 := by decide
theorem cert_e1205824830394 : check e1205824830394 [[],[]] .sourceHead = true := by decide
def e1205824830550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205824830550 : Closed e1205824830550 ∧ code e1205824830550 = 5603871341654 := by decide
theorem cert_e1205824830550 : check e1205824830550 [[],[]] .chain = true := by decide
def e1205824830554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205824830554 : Closed e1205824830554 ∧ code e1205824830554 = 5603871341658 := by decide
theorem cert_e1205824830554 : check e1205824830554 [[],[]] .chain = true := by decide
def e1205824830742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205824830742 : Closed e1205824830742 ∧ code e1205824830742 = 5603871341846 := by decide
theorem cert_e1205824830742 : check e1205824830742 [[],[]] .chain = true := by decide
def e1205824830818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205824830818 : Closed e1205824830818 ∧ code e1205824830818 = 5603871341922 := by decide
theorem cert_e1205824830818 : check e1205824830818 [[],[]] .chain = true := by decide
def e1205824830830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205824830830 : Closed e1205824830830 ∧ code e1205824830830 = 5603871341934 := by decide
theorem cert_e1205824830830 : check e1205824830830 [[],[]] .sourceHead = true := by decide
def e1205824830838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205824830838 : Closed e1205824830838 ∧ code e1205824830838 = 5603871341942 := by decide
theorem cert_e1205824830838 : check e1205824830838 [[],[]] .sourceHead = true := by decide
def e1205824830858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205824830858 : Closed e1205824830858 ∧ code e1205824830858 = 5603871341962 := by decide
theorem cert_e1205824830858 : check e1205824830858 [[],[]] .chain = true := by decide
def e1205824830882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205824830882 : Closed e1205824830882 ∧ code e1205824830882 = 5603871341986 := by decide
theorem cert_e1205824830882 : check e1205824830882 [[],[]] .chain = true := by decide
def e1205824830894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205824830894 : Closed e1205824830894 ∧ code e1205824830894 = 5603871341998 := by decide
theorem cert_e1205824830894 : check e1205824830894 [[],[]] .sourceHead = true := by decide
def e1205824830906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205824830906 : Closed e1205824830906 ∧ code e1205824830906 = 5603871342010 := by decide
theorem cert_e1205824830906 : check e1205824830906 [[],[]] .sourceHead = true := by decide
def e1205824830934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205824830934 : Closed e1205824830934 ∧ code e1205824830934 = 5603871342038 := by decide
theorem cert_e1205824830934 : check e1205824830934 [[],[]] .sourceHead = true := by decide
def e1205824830938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205824830938 : Closed e1205824830938 ∧ code e1205824830938 = 5603871342042 := by decide
theorem cert_e1205824830938 : check e1205824830938 [[],[]] .sourceHead = true := by decide
def e1205824831982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1205824831982 : Closed e1205824831982 ∧ code e1205824831982 = 5603871343086 := by decide
theorem cert_e1205824831982 : check e1205824831982 [[],[]] .chain = true := by decide
def e1205824831990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1205824831990 : Closed e1205824831990 ∧ code e1205824831990 = 5603871343094 := by decide
theorem cert_e1205824831990 : check e1205824831990 [[],[]] .chain = true := by decide
def e1205824832750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1205824832750 : Closed e1205824832750 ∧ code e1205824832750 = 5603871343854 := by decide
theorem cert_e1205824832750 : check e1205824832750 [[],[]] .chain = true := by decide
def e1205824832758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1205824832758 : Closed e1205824832758 ∧ code e1205824832758 = 5603871343862 := by decide
theorem cert_e1205824832758 : check e1205824832758 [[],[]] .chain = true := by decide
def e1205824833310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e1205824833310 : Closed e1205824833310 ∧ code e1205824833310 = 5603871344414 := by decide
theorem cert_e1205824833310 : check e1205824833310 [[],[]] .chain = true := by decide
def e1205824833422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e1205824833422 : Closed e1205824833422 ∧ code e1205824833422 = 5603871344526 := by decide
theorem cert_e1205824833422 : check e1205824833422 [[],[]] .chain = true := by decide
def e1205824835118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205824835118 : Closed e1205824835118 ∧ code e1205824835118 = 5603871346222 := by decide
theorem cert_e1205824835118 : check e1205824835118 [[],[]] .chain = true := by decide
def e1205824835298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205824835298 : Closed e1205824835298 ∧ code e1205824835298 = 5603871346402 := by decide
theorem cert_e1205824835298 : check e1205824835298 [[],[]] .chain = true := by decide
def e1205824835310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e1205824835310 : Closed e1205824835310 ∧ code e1205824835310 = 5603871346414 := by decide
theorem cert_e1205824835310 : check e1205824835310 [[],[]] .sourceHead = true := by decide
def e1205824835350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205824835350 : Closed e1205824835350 ∧ code e1205824835350 = 5603871346454 := by decide
theorem cert_e1205824835350 : check e1205824835350 [[],[]] .chain = true := by decide
def e1205824835426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205824835426 : Closed e1205824835426 ∧ code e1205824835426 = 5603871346530 := by decide
theorem cert_e1205824835426 : check e1205824835426 [[],[]] .chain = true := by decide
def e1205824835438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e1205824835438 : Closed e1205824835438 ∧ code e1205824835438 = 5603871346542 := by decide
theorem cert_e1205824835438 : check e1205824835438 [[],[]] .sourceHead = true := by decide
def e1205824835446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e1205824835446 : Closed e1205824835446 ∧ code e1205824835446 = 5603871346550 := by decide
theorem cert_e1205824835446 : check e1205824835446 [[],[]] .sourceHead = true := by decide
def e1205824837694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205824837694 : Closed e1205824837694 ∧ code e1205824837694 = 5603871348798 := by decide
theorem cert_e1205824837694 : check e1205824837694 [[],[]] .chain = true := by decide
def e1205824838114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205824838114 : Closed e1205824838114 ∧ code e1205824838114 = 5603871349218 := by decide
theorem cert_e1205824838114 : check e1205824838114 [[],[]] .chain = true := by decide
def e1205824838126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205824838126 : Closed e1205824838126 ∧ code e1205824838126 = 5603871349230 := by decide
theorem cert_e1205824838126 : check e1205824838126 [[],[]] .sourceHead = true := by decide
def e1205824838686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205824838686 : Closed e1205824838686 ∧ code e1205824838686 = 5603871349790 := by decide
theorem cert_e1205824838686 : check e1205824838686 [[],[]] .chain = true := by decide
def e1205824838882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205824838882 : Closed e1205824838882 ∧ code e1205824838882 = 5603871349986 := by decide
theorem cert_e1205824838882 : check e1205824838882 [[],[]] .chain = true := by decide
def e1205824838894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205824838894 : Closed e1205824838894 ∧ code e1205824838894 = 5603871349998 := by decide
theorem cert_e1205824838894 : check e1205824838894 [[],[]] .sourceHead = true := by decide
def e1205824838902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205824838902 : Closed e1205824838902 ∧ code e1205824838902 = 5603871350006 := by decide
theorem cert_e1205824838902 : check e1205824838902 [[],[]] .sourceHead = true := by decide
def e1205824839918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1205824839918 : Closed e1205824839918 ∧ code e1205824839918 = 5603871351022 := by decide
theorem cert_e1205824839918 : check e1205824839918 [[],[]] .chain = true := by decide
def e1205824839930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1205824839930 : Closed e1205824839930 ∧ code e1205824839930 = 5603871351034 := by decide
theorem cert_e1205824839930 : check e1205824839930 [[],[]] .chain = true := by decide
def e1205824840302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1205824840302 : Closed e1205824840302 ∧ code e1205824840302 = 5603871351406 := by decide
theorem cert_e1205824840302 : check e1205824840302 [[],[]] .chain = true := by decide
def e1205824840314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1205824840314 : Closed e1205824840314 ∧ code e1205824840314 = 5603871351418 := by decide
theorem cert_e1205824840314 : check e1205824840314 [[],[]] .chain = true := by decide
def e1205824840478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e1205824840478 : Closed e1205824840478 ∧ code e1205824840478 = 5603871351582 := by decide
theorem cert_e1205824840478 : check e1205824840478 [[],[]] .chain = true := by decide
def e1205824840646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e1205824840646 : Closed e1205824840646 ∧ code e1205824840646 = 5603871351750 := by decide
theorem cert_e1205824840646 : check e1205824840646 [[],[]] .chain = true := by decide
def e1205824841262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1205824841262 : Closed e1205824841262 ∧ code e1205824841262 = 5603871352366 := by decide
theorem cert_e1205824841262 : check e1205824841262 [[],[]] .chain = true := by decide
def e1205824841442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1205824841442 : Closed e1205824841442 ∧ code e1205824841442 = 5603871352546 := by decide
theorem cert_e1205824841442 : check e1205824841442 [[],[]] .chain = true := by decide
def e1205824841454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1205824841454 : Closed e1205824841454 ∧ code e1205824841454 = 5603871352558 := by decide
theorem cert_e1205824841454 : check e1205824841454 [[],[]] .sourceHead = true := by decide
def e1205824841610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205824841610 : Closed e1205824841610 ∧ code e1205824841610 = 5603871352714 := by decide
theorem cert_e1205824841610 : check e1205824841610 [[],[]] .chain = true := by decide
def e1205824841634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205824841634 : Closed e1205824841634 ∧ code e1205824841634 = 5603871352738 := by decide
theorem cert_e1205824841634 : check e1205824841634 [[],[]] .chain = true := by decide
def e1205824841646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1205824841646 : Closed e1205824841646 ∧ code e1205824841646 = 5603871352750 := by decide
theorem cert_e1205824841646 : check e1205824841646 [[],[]] .sourceHead = true := by decide
def e1205824841658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1205824841658 : Closed e1205824841658 ∧ code e1205824841658 = 5603871352762 := by decide
theorem cert_e1205824841658 : check e1205824841658 [[],[]] .sourceHead = true := by decide
def e1205824841790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e1205824841790 : Closed e1205824841790 ∧ code e1205824841790 = 5603871352894 := by decide
theorem cert_e1205824841790 : check e1205824841790 [[],[]] .chain = true := by decide
def e1205824842210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205824842210 : Closed e1205824842210 ∧ code e1205824842210 = 5603871353314 := by decide
theorem cert_e1205824842210 : check e1205824842210 [[],[]] .chain = true := by decide
def e1205824842222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1205824842222 : Closed e1205824842222 ∧ code e1205824842222 = 5603871353326 := by decide
theorem cert_e1205824842222 : check e1205824842222 [[],[]] .sourceHead = true := by decide
def e1205824843278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205824843278 : Closed e1205824843278 ∧ code e1205824843278 = 5603871354382 := by decide
theorem cert_e1205824843278 : check e1205824843278 [[],[]] .chain = true := by decide
def e1205824843362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205824843362 : Closed e1205824843362 ∧ code e1205824843362 = 5603871354466 := by decide
theorem cert_e1205824843362 : check e1205824843362 [[],[]] .chain = true := by decide
def e1205824843374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205824843374 : Closed e1205824843374 ∧ code e1205824843374 = 5603871354478 := by decide
theorem cert_e1205824843374 : check e1205824843374 [[],[]] .sourceHead = true := by decide
def e1205824843386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205824843386 : Closed e1205824843386 ∧ code e1205824843386 = 5603871354490 := by decide
theorem cert_e1205824843386 : check e1205824843386 [[],[]] .sourceHead = true := by decide
def e1205824843894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205824843894 : Closed e1205824843894 ∧ code e1205824843894 = 5603871354998 := by decide
theorem cert_e1205824843894 : check e1205824843894 [[],[]] .chain = true := by decide
def e1205824843898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1205824843898 : Closed e1205824843898 ∧ code e1205824843898 = 5603871355002 := by decide
theorem cert_e1205824843898 : check e1205824843898 [[],[]] .chain = true := by decide
def e1205824844086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205824844086 : Closed e1205824844086 ∧ code e1205824844086 = 5603871355190 := by decide
theorem cert_e1205824844086 : check e1205824844086 [[],[]] .chain = true := by decide
def e1205824844090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205824844090 : Closed e1205824844090 ∧ code e1205824844090 = 5603871355194 := by decide
theorem cert_e1205824844090 : check e1205824844090 [[],[]] .chain = true := by decide
def e1205824844174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205824844174 : Closed e1205824844174 ∧ code e1205824844174 = 5603871355278 := by decide
theorem cert_e1205824844174 : check e1205824844174 [[],[]] .chain = true := by decide
def e1205824844230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1205824844230 : Closed e1205824844230 ∧ code e1205824844230 = 5603871355334 := by decide
theorem cert_e1205824844230 : check e1205824844230 [[],[]] .chain = true := by decide
def e1205824844566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205824844566 : Closed e1205824844566 ∧ code e1205824844566 = 5603871355670 := by decide
theorem cert_e1205824844566 : check e1205824844566 [[],[]] .chain = true := by decide
def e1205824844642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205824844642 : Closed e1205824844642 ∧ code e1205824844642 = 5603871355746 := by decide
theorem cert_e1205824844642 : check e1205824844642 [[],[]] .chain = true := by decide
def e1205824844654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205824844654 : Closed e1205824844654 ∧ code e1205824844654 = 5603871355758 := by decide
theorem cert_e1205824844654 : check e1205824844654 [[],[]] .sourceHead = true := by decide
def e1205824844662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205824844662 : Closed e1205824844662 ∧ code e1205824844662 = 5603871355766 := by decide
theorem cert_e1205824844662 : check e1205824844662 [[],[]] .sourceHead = true := by decide
def e1205824844682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205824844682 : Closed e1205824844682 ∧ code e1205824844682 = 5603871355786 := by decide
theorem cert_e1205824844682 : check e1205824844682 [[],[]] .chain = true := by decide
def e1205824844706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205824844706 : Closed e1205824844706 ∧ code e1205824844706 = 5603871355810 := by decide
theorem cert_e1205824844706 : check e1205824844706 [[],[]] .chain = true := by decide
def e1205824844718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205824844718 : Closed e1205824844718 ∧ code e1205824844718 = 5603871355822 := by decide
theorem cert_e1205824844718 : check e1205824844718 [[],[]] .sourceHead = true := by decide
def e1205824844730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205824844730 : Closed e1205824844730 ∧ code e1205824844730 = 5603871355834 := by decide
theorem cert_e1205824844730 : check e1205824844730 [[],[]] .sourceHead = true := by decide
def e1205824844758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205824844758 : Closed e1205824844758 ∧ code e1205824844758 = 5603871355862 := by decide
theorem cert_e1205824844758 : check e1205824844758 [[],[]] .sourceHead = true := by decide
def e1205824844762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205824844762 : Closed e1205824844762 ∧ code e1205824844762 = 5603871355866 := by decide
theorem cert_e1205824844762 : check e1205824844762 [[],[]] .sourceHead = true := by decide
def e1205824844830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205824844830 : Closed e1205824844830 ∧ code e1205824844830 = 5603871355934 := by decide
theorem cert_e1205824844830 : check e1205824844830 [[],[]] .chain = true := by decide
def e1205824845026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205824845026 : Closed e1205824845026 ∧ code e1205824845026 = 5603871356130 := by decide
theorem cert_e1205824845026 : check e1205824845026 [[],[]] .chain = true := by decide
def e1205824845038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205824845038 : Closed e1205824845038 ∧ code e1205824845038 = 5603871356142 := by decide
theorem cert_e1205824845038 : check e1205824845038 [[],[]] .sourceHead = true := by decide
def e1205824845046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205824845046 : Closed e1205824845046 ∧ code e1205824845046 = 5603871356150 := by decide
theorem cert_e1205824845046 : check e1205824845046 [[],[]] .sourceHead = true := by decide
def e1205824845326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205824845326 : Closed e1205824845326 ∧ code e1205824845326 = 5603871356430 := by decide
theorem cert_e1205824845326 : check e1205824845326 [[],[]] .chain = true := by decide
def e1205824845410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205824845410 : Closed e1205824845410 ∧ code e1205824845410 = 5603871356514 := by decide
theorem cert_e1205824845410 : check e1205824845410 [[],[]] .chain = true := by decide
def e1205824845422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205824845422 : Closed e1205824845422 ∧ code e1205824845422 = 5603871356526 := by decide
theorem cert_e1205824845422 : check e1205824845422 [[],[]] .sourceHead = true := by decide
def e1205824845434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205824845434 : Closed e1205824845434 ∧ code e1205824845434 = 5603871356538 := by decide
theorem cert_e1205824845434 : check e1205824845434 [[],[]] .sourceHead = true := by decide
def e1205824845622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205824845622 : Closed e1205824845622 ∧ code e1205824845622 = 5603871356726 := by decide
theorem cert_e1205824845622 : check e1205824845622 [[],[]] .sourceHead = true := by decide
def e1205824845626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205824845626 : Closed e1205824845626 ∧ code e1205824845626 = 5603871356730 := by decide
theorem cert_e1205824845626 : check e1205824845626 [[],[]] .sourceHead = true := by decide
def e1205824850798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205824850798 : Closed e1205824850798 ∧ code e1205824850798 = 5603871361902 := by decide
theorem cert_e1205824850798 : check e1205824850798 [[],[]] .smaller = true := by decide
def e1205824850806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205824850806 : Closed e1205824850806 ∧ code e1205824850806 = 5603871361910 := by decide
theorem cert_e1205824850806 : check e1205824850806 [[],[]] .smaller = true := by decide
def e1205824850862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205824850862 : Closed e1205824850862 ∧ code e1205824850862 = 5603871361966 := by decide
theorem cert_e1205824850862 : check e1205824850862 [[],[]] .smaller = true := by decide
def e1205824850874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205824850874 : Closed e1205824850874 ∧ code e1205824850874 = 5603871361978 := by decide
theorem cert_e1205824850874 : check e1205824850874 [[],[]] .smaller = true := by decide
def e1205824850902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205824850902 : Closed e1205824850902 ∧ code e1205824850902 = 5603871362006 := by decide
theorem cert_e1205824850902 : check e1205824850902 [[],[]] .smaller = true := by decide
def e1205824850906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205824850906 : Closed e1205824850906 ∧ code e1205824850906 = 5603871362010 := by decide
theorem cert_e1205824850906 : check e1205824850906 [[],[]] .smaller = true := by decide
def e1205824851182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205824851182 : Closed e1205824851182 ∧ code e1205824851182 = 5603871362286 := by decide
theorem cert_e1205824851182 : check e1205824851182 [[],[]] .smaller = true := by decide
def e1205824851190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205824851190 : Closed e1205824851190 ∧ code e1205824851190 = 5603871362294 := by decide
theorem cert_e1205824851190 : check e1205824851190 [[],[]] .smaller = true := by decide
end Blc.Floor42
