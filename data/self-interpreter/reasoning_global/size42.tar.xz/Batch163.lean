import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186990906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186990906 : Closed e1211186990906 ∧ code e1211186990906 = 5609233502010 := by decide
theorem cert_e1211186990906 : check e1211186990906 [[],[]] .smaller = true := by decide
def e1211186990990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211186990990 : Closed e1211186990990 ∧ code e1211186990990 = 5609233502094 := by decide
theorem cert_e1211186990990 : check e1211186990990 [[],[]] .three = true := by decide
def e1211186991002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186991002 : Closed e1211186991002 ∧ code e1211186991002 = 5609233502106 := by decide
theorem cert_e1211186991002 : check e1211186991002 [[],[]] .three = true := by decide
def e1211186996662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211186996662 : Closed e1211186996662 ∧ code e1211186996662 = 5609233507766 := by decide
theorem cert_e1211186996662 : check e1211186996662 [[],[]] .smaller = true := by decide
def e1211186996694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211186996694 : Closed e1211186996694 ∧ code e1211186996694 = 5609233507798 := by decide
theorem cert_e1211186996694 : check e1211186996694 [[],[]] .smaller = true := by decide
def e1211186996698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211186996698 : Closed e1211186996698 ∧ code e1211186996698 = 5609233507802 := by decide
theorem cert_e1211186996698 : check e1211186996698 [[],[]] .smaller = true := by decide
def e1211186996798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1211186996798 : Closed e1211186996798 ∧ code e1211186996798 = 5609233507902 := by decide
theorem cert_e1211186996798 : check e1211186996798 [[],[]] .three = true := by decide
def e1211186996854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186996854 : Closed e1211186996854 ∧ code e1211186996854 = 5609233507958 := by decide
theorem cert_e1211186996854 : check e1211186996854 [[],[]] .smaller = true := by decide
def e1211186997046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186997046 : Closed e1211186997046 ∧ code e1211186997046 = 5609233508150 := by decide
theorem cert_e1211186997046 : check e1211186997046 [[],[]] .smaller = true := by decide
def e1211186997050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186997050 : Closed e1211186997050 ∧ code e1211186997050 = 5609233508154 := by decide
theorem cert_e1211186997050 : check e1211186997050 [[],[]] .smaller = true := by decide
def e1211186997190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1211186997190 : Closed e1211186997190 ∧ code e1211186997190 = 5609233508294 := by decide
theorem cert_e1211186997190 : check e1211186997190 [[],[]] .three = true := by decide
def e1211187000022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211187000022 : Closed e1211187000022 ∧ code e1211187000022 = 5609233511126 := by decide
theorem cert_e1211187000022 : check e1211187000022 [[],[]] .three = true := by decide
def e1211187000026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211187000026 : Closed e1211187000026 ∧ code e1211187000026 = 5609233511130 := by decide
theorem cert_e1211187000026 : check e1211187000026 [[],[]] .three = true := by decide
def e1211187000042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211187000042 : Closed e1211187000042 ∧ code e1211187000042 = 5609233511146 := by decide
theorem cert_e1211187000042 : check e1211187000042 [[],[]] .three = true := by decide
def e1211187000094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211187000094 : Closed e1211187000094 ∧ code e1211187000094 = 5609233511198 := by decide
theorem cert_e1211187000094 : check e1211187000094 [[],[]] .three = true := by decide
def e1211187000118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187000118 : Closed e1211187000118 ∧ code e1211187000118 = 5609233511222 := by decide
theorem cert_e1211187000118 : check e1211187000118 [[],[]] .three = true := by decide
def e1211187000122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187000122 : Closed e1211187000122 ∧ code e1211187000122 = 5609233511226 := by decide
theorem cert_e1211187000122 : check e1211187000122 [[],[]] .three = true := by decide
def e1211187000206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211187000206 : Closed e1211187000206 ∧ code e1211187000206 = 5609233511310 := by decide
theorem cert_e1211187000206 : check e1211187000206 [[],[]] .three = true := by decide
def e1211187000218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187000218 : Closed e1211187000218 ∧ code e1211187000218 = 5609233511322 := by decide
theorem cert_e1211187000218 : check e1211187000218 [[],[]] .three = true := by decide
def e1211187000262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211187000262 : Closed e1211187000262 ∧ code e1211187000262 = 5609233511366 := by decide
theorem cert_e1211187000262 : check e1211187000262 [[],[]] .three = true := by decide
def e1211187005238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187005238 : Closed e1211187005238 ∧ code e1211187005238 = 5609233516342 := by decide
theorem cert_e1211187005238 : check e1211187005238 [[],[]] .three = true := by decide
def e1211187005242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187005242 : Closed e1211187005242 ∧ code e1211187005242 = 5609233516346 := by decide
theorem cert_e1211187005242 : check e1211187005242 [[],[]] .three = true := by decide
def e1211187005338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211187005338 : Closed e1211187005338 ∧ code e1211187005338 = 5609233516442 := by decide
theorem cert_e1211187005338 : check e1211187005338 [[],[]] .three = true := by decide
def e1211187006774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187006774 : Closed e1211187006774 ∧ code e1211187006774 = 5609233517878 := by decide
private def t_e1211187006774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem cert_e1211187006774 : ¬ IsSelfInterpreter e1211187006774 :=
  wSource (t := t_e1211187006774) (replay_sound (ps := []) (t := e1211187006774) (by decide)) (by decide)
def e1211187006778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187006778 : Closed e1211187006778 ∧ code e1211187006778 = 5609233517882 := by decide
private def t_e1211187006778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem cert_e1211187006778 : ¬ IsSelfInterpreter e1211187006778 :=
  wSource (t := t_e1211187006778) (replay_sound (ps := []) (t := e1211187006778) (by decide)) (by decide)
def e1211187008214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211187008214 : Closed e1211187008214 ∧ code e1211187008214 = 5609233519318 := by decide
theorem cert_e1211187008214 : check e1211187008214 [[],[]] .three = true := by decide
def e1211187008218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211187008218 : Closed e1211187008218 ∧ code e1211187008218 = 5609233519322 := by decide
theorem cert_e1211187008218 : check e1211187008218 [[],[]] .three = true := by decide
def e1211187008234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211187008234 : Closed e1211187008234 ∧ code e1211187008234 = 5609233519338 := by decide
theorem cert_e1211187008234 : check e1211187008234 [[],[]] .three = true := by decide
def e1211187008310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187008310 : Closed e1211187008310 ∧ code e1211187008310 = 5609233519414 := by decide
theorem cert_e1211187008310 : check e1211187008310 [[],[]] .three = true := by decide
def e1211187008314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187008314 : Closed e1211187008314 ∧ code e1211187008314 = 5609233519418 := by decide
theorem cert_e1211187008314 : check e1211187008314 [[],[]] .three = true := by decide
def e1211187008410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187008410 : Closed e1211187008410 ∧ code e1211187008410 = 5609233519514 := by decide
theorem cert_e1211187008410 : check e1211187008410 [[],[]] .three = true := by decide
def e1211187009934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211187009934 : Closed e1211187009934 ∧ code e1211187009934 = 5609233521038 := by decide
theorem cert_e1211187009934 : check e1211187009934 [[],[]] .three = true := by decide
def e1211187009990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211187009990 : Closed e1211187009990 ∧ code e1211187009990 = 5609233521094 := by decide
theorem cert_e1211187009990 : check e1211187009990 [[],[]] .three = true := by decide
def e1211187010014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211187010014 : Closed e1211187010014 ∧ code e1211187010014 = 5609233521118 := by decide
theorem cert_e1211187010014 : check e1211187010014 [[],[]] .three = true := by decide
def e1211187010030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211187010030 : Closed e1211187010030 ∧ code e1211187010030 = 5609233521134 := by decide
theorem cert_e1211187010030 : check e1211187010030 [[],[]] .three = true := by decide
def e1211187010038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211187010038 : Closed e1211187010038 ∧ code e1211187010038 = 5609233521142 := by decide
theorem cert_e1211187010038 : check e1211187010038 [[],[]] .three = true := by decide
def e1211187010758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211187010758 : Closed e1211187010758 ∧ code e1211187010758 = 5609233521862 := by decide
theorem cert_e1211187010758 : check e1211187010758 [[],[]] .three = true := by decide
def e1211187010782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211187010782 : Closed e1211187010782 ∧ code e1211187010782 = 5609233521886 := by decide
theorem cert_e1211187010782 : check e1211187010782 [[],[]] .three = true := by decide
def e1211187010798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211187010798 : Closed e1211187010798 ∧ code e1211187010798 = 5609233521902 := by decide
theorem cert_e1211187010798 : check e1211187010798 [[],[]] .three = true := by decide
def e1211187010806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211187010806 : Closed e1211187010806 ∧ code e1211187010806 = 5609233521910 := by decide
theorem cert_e1211187010806 : check e1211187010806 [[],[]] .three = true := by decide
def e1211187010810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211187010810 : Closed e1211187010810 ∧ code e1211187010810 = 5609233521914 := by decide
theorem cert_e1211187010810 : check e1211187010810 [[],[]] .three = true := by decide
def e1211187011182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211187011182 : Closed e1211187011182 ∧ code e1211187011182 = 5609233522286 := by decide
theorem cert_e1211187011182 : check e1211187011182 [[],[]] .three = true := by decide
def e1211187011190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211187011190 : Closed e1211187011190 ∧ code e1211187011190 = 5609233522294 := by decide
theorem cert_e1211187011190 : check e1211187011190 [[],[]] .three = true := by decide
def e1211187011194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211187011194 : Closed e1211187011194 ∧ code e1211187011194 = 5609233522298 := by decide
theorem cert_e1211187011194 : check e1211187011194 [[],[]] .three = true := by decide
def e1211187011382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187011382 : Closed e1211187011382 ∧ code e1211187011382 = 5609233522486 := by decide
theorem cert_e1211187011382 : check e1211187011382 [[],[]] .three = true := by decide
def e1211187011386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187011386 : Closed e1211187011386 ∧ code e1211187011386 = 5609233522490 := by decide
theorem cert_e1211187011386 : check e1211187011386 [[],[]] .three = true := by decide
def e1211187014742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e1211187014742 : Closed e1211187014742 ∧ code e1211187014742 = 5609233525846 := by decide
theorem cert_e1211187014742 : check e1211187014742 [[],[]] .three = true := by decide
def e1211187014746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e1211187014746 : Closed e1211187014746 ∧ code e1211187014746 = 5609233525850 := by decide
theorem cert_e1211187014746 : check e1211187014746 [[],[]] .three = true := by decide
def e1211187014934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211187014934 : Closed e1211187014934 ∧ code e1211187014934 = 5609233526038 := by decide
theorem cert_e1211187014934 : check e1211187014934 [[],[]] .three = true := by decide
def e1211187015010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211187015010 : Closed e1211187015010 ∧ code e1211187015010 = 5609233526114 := by decide
theorem cert_e1211187015010 : check e1211187015010 [[],[]] .three = true := by decide
def e1211187015022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211187015022 : Closed e1211187015022 ∧ code e1211187015022 = 5609233526126 := by decide
theorem cert_e1211187015022 : check e1211187015022 [[],[]] .three = true := by decide
def e1211187015030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211187015030 : Closed e1211187015030 ∧ code e1211187015030 = 5609233526134 := by decide
theorem cert_e1211187015030 : check e1211187015030 [[],[]] .three = true := by decide
def e1211187015050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211187015050 : Closed e1211187015050 ∧ code e1211187015050 = 5609233526154 := by decide
theorem cert_e1211187015050 : check e1211187015050 [[],[]] .three = true := by decide
def e1211187015074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211187015074 : Closed e1211187015074 ∧ code e1211187015074 = 5609233526178 := by decide
theorem cert_e1211187015074 : check e1211187015074 [[],[]] .three = true := by decide
def e1211187015086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211187015086 : Closed e1211187015086 ∧ code e1211187015086 = 5609233526190 := by decide
theorem cert_e1211187015086 : check e1211187015086 [[],[]] .three = true := by decide
def e1211187015094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1)))))))
theorem wire_e1211187015094 : Closed e1211187015094 ∧ code e1211187015094 = 5609233526198 := by decide
theorem cert_e1211187015094 : check e1211187015094 [[],[]] .three = true := by decide
def e1211187015098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211187015098 : Closed e1211187015098 ∧ code e1211187015098 = 5609233526202 := by decide
theorem cert_e1211187015098 : check e1211187015098 [[],[]] .three = true := by decide
def e1211187015126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211187015126 : Closed e1211187015126 ∧ code e1211187015126 = 5609233526230 := by decide
theorem cert_e1211187015126 : check e1211187015126 [[],[]] .three = true := by decide
def e1211187015130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211187015130 : Closed e1211187015130 ∧ code e1211187015130 = 5609233526234 := by decide
theorem cert_e1211187015130 : check e1211187015130 [[],[]] .three = true := by decide
def e1211187015210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e1211187015210 : Closed e1211187015210 ∧ code e1211187015210 = 5609233526314 := by decide
theorem cert_e1211187015210 : check e1211187015210 [[],[]] .three = true := by decide
def e1211187015306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211187015306 : Closed e1211187015306 ∧ code e1211187015306 = 5609233526410 := by decide
theorem cert_e1211187015306 : check e1211187015306 [[],[]] .three = true := by decide
def e1211187015330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211187015330 : Closed e1211187015330 ∧ code e1211187015330 = 5609233526434 := by decide
theorem cert_e1211187015330 : check e1211187015330 [[],[]] .three = true := by decide
def e1211187015342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211187015342 : Closed e1211187015342 ∧ code e1211187015342 = 5609233526446 := by decide
theorem cert_e1211187015342 : check e1211187015342 [[],[]] .three = true := by decide
def e1211187015350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211187015350 : Closed e1211187015350 ∧ code e1211187015350 = 5609233526454 := by decide
theorem cert_e1211187015350 : check e1211187015350 [[],[]] .three = true := by decide
def e1211187015354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211187015354 : Closed e1211187015354 ∧ code e1211187015354 = 5609233526458 := by decide
theorem cert_e1211187015354 : check e1211187015354 [[],[]] .three = true := by decide
def e1211187015382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211187015382 : Closed e1211187015382 ∧ code e1211187015382 = 5609233526486 := by decide
theorem cert_e1211187015382 : check e1211187015382 [[],[]] .three = true := by decide
def e1211187015386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211187015386 : Closed e1211187015386 ∧ code e1211187015386 = 5609233526490 := by decide
theorem cert_e1211187015386 : check e1211187015386 [[],[]] .three = true := by decide
def e1211187015402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211187015402 : Closed e1211187015402 ∧ code e1211187015402 = 5609233526506 := by decide
theorem cert_e1211187015402 : check e1211187015402 [[],[]] .three = true := by decide
def e1211187015510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211187015510 : Closed e1211187015510 ∧ code e1211187015510 = 5609233526614 := by decide
theorem cert_e1211187015510 : check e1211187015510 [[],[]] .three = true := by decide
def e1211187015514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211187015514 : Closed e1211187015514 ∧ code e1211187015514 = 5609233526618 := by decide
theorem cert_e1211187015514 : check e1211187015514 [[],[]] .three = true := by decide
def e1211187015530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211187015530 : Closed e1211187015530 ∧ code e1211187015530 = 5609233526634 := by decide
theorem cert_e1211187015530 : check e1211187015530 [[],[]] .three = true := by decide
def e1211187015798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211187015798 : Closed e1211187015798 ∧ code e1211187015798 = 5609233526902 := by decide
theorem cert_e1211187015798 : check e1211187015798 [[],[]] .three = true := by decide
def e1211187015802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211187015802 : Closed e1211187015802 ∧ code e1211187015802 = 5609233526906 := by decide
theorem cert_e1211187015802 : check e1211187015802 [[],[]] .three = true := by decide
def e1211187015894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e1211187015894 : Closed e1211187015894 ∧ code e1211187015894 = 5609233526998 := by decide
theorem cert_e1211187015894 : check e1211187015894 [[],[]] .three = true := by decide
def e1211187015990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187015990 : Closed e1211187015990 ∧ code e1211187015990 = 5609233527094 := by decide
theorem cert_e1211187015990 : check e1211187015990 [[],[]] .three = true := by decide
def e1211187015994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187015994 : Closed e1211187015994 ∧ code e1211187015994 = 5609233527098 := by decide
theorem cert_e1211187015994 : check e1211187015994 [[],[]] .three = true := by decide
def e1211187016078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211187016078 : Closed e1211187016078 ∧ code e1211187016078 = 5609233527182 := by decide
theorem cert_e1211187016078 : check e1211187016078 [[],[]] .three = true := by decide
def e1211187016134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211187016134 : Closed e1211187016134 ∧ code e1211187016134 = 5609233527238 := by decide
theorem cert_e1211187016134 : check e1211187016134 [[],[]] .three = true := by decide
def e1211187016158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211187016158 : Closed e1211187016158 ∧ code e1211187016158 = 5609233527262 := by decide
theorem cert_e1211187016158 : check e1211187016158 [[],[]] .three = true := by decide
def e1211187016174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211187016174 : Closed e1211187016174 ∧ code e1211187016174 = 5609233527278 := by decide
theorem cert_e1211187016174 : check e1211187016174 [[],[]] .three = true := by decide
def e1211187016182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211187016182 : Closed e1211187016182 ∧ code e1211187016182 = 5609233527286 := by decide
theorem cert_e1211187016182 : check e1211187016182 [[],[]] .three = true := by decide
def e1211187016470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211187016470 : Closed e1211187016470 ∧ code e1211187016470 = 5609233527574 := by decide
theorem cert_e1211187016470 : check e1211187016470 [[],[]] .three = true := by decide
def e1211187016546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211187016546 : Closed e1211187016546 ∧ code e1211187016546 = 5609233527650 := by decide
theorem cert_e1211187016546 : check e1211187016546 [[],[]] .three = true := by decide
def e1211187016558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211187016558 : Closed e1211187016558 ∧ code e1211187016558 = 5609233527662 := by decide
theorem cert_e1211187016558 : check e1211187016558 [[],[]] .three = true := by decide
def e1211187016566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211187016566 : Closed e1211187016566 ∧ code e1211187016566 = 5609233527670 := by decide
theorem cert_e1211187016566 : check e1211187016566 [[],[]] .three = true := by decide
def e1211187016586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211187016586 : Closed e1211187016586 ∧ code e1211187016586 = 5609233527690 := by decide
theorem cert_e1211187016586 : check e1211187016586 [[],[]] .three = true := by decide
def e1211187016610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211187016610 : Closed e1211187016610 ∧ code e1211187016610 = 5609233527714 := by decide
theorem cert_e1211187016610 : check e1211187016610 [[],[]] .three = true := by decide
def e1211187016622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211187016622 : Closed e1211187016622 ∧ code e1211187016622 = 5609233527726 := by decide
theorem cert_e1211187016622 : check e1211187016622 [[],[]] .three = true := by decide
def e1211187016630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1211187016630 : Closed e1211187016630 ∧ code e1211187016630 = 5609233527734 := by decide
theorem cert_e1211187016630 : check e1211187016630 [[],[]] .three = true := by decide
def e1211187016634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211187016634 : Closed e1211187016634 ∧ code e1211187016634 = 5609233527738 := by decide
theorem cert_e1211187016634 : check e1211187016634 [[],[]] .three = true := by decide
def e1211187016662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211187016662 : Closed e1211187016662 ∧ code e1211187016662 = 5609233527766 := by decide
theorem cert_e1211187016662 : check e1211187016662 [[],[]] .three = true := by decide
def e1211187016666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211187016666 : Closed e1211187016666 ∧ code e1211187016666 = 5609233527770 := by decide
theorem cert_e1211187016666 : check e1211187016666 [[],[]] .three = true := by decide
def e1211187016734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211187016734 : Closed e1211187016734 ∧ code e1211187016734 = 5609233527838 := by decide
theorem cert_e1211187016734 : check e1211187016734 [[],[]] .three = true := by decide
def e1211187016930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211187016930 : Closed e1211187016930 ∧ code e1211187016930 = 5609233528034 := by decide
theorem cert_e1211187016930 : check e1211187016930 [[],[]] .three = true := by decide
def e1211187016942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211187016942 : Closed e1211187016942 ∧ code e1211187016942 = 5609233528046 := by decide
theorem cert_e1211187016942 : check e1211187016942 [[],[]] .three = true := by decide
def e1211187016950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211187016950 : Closed e1211187016950 ∧ code e1211187016950 = 5609233528054 := by decide
theorem cert_e1211187016950 : check e1211187016950 [[],[]] .three = true := by decide
def e1211187017230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211187017230 : Closed e1211187017230 ∧ code e1211187017230 = 5609233528334 := by decide
theorem cert_e1211187017230 : check e1211187017230 [[],[]] .three = true := by decide
def e1211187017242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187017242 : Closed e1211187017242 ∧ code e1211187017242 = 5609233528346 := by decide
theorem cert_e1211187017242 : check e1211187017242 [[],[]] .three = true := by decide
def e1211187017278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211187017278 : Closed e1211187017278 ∧ code e1211187017278 = 5609233528382 := by decide
theorem cert_e1211187017278 : check e1211187017278 [[],[]] .three = true := by decide
def e1211187017314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211187017314 : Closed e1211187017314 ∧ code e1211187017314 = 5609233528418 := by decide
theorem cert_e1211187017314 : check e1211187017314 [[],[]] .three = true := by decide
def e1211187017326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211187017326 : Closed e1211187017326 ∧ code e1211187017326 = 5609233528430 := by decide
theorem cert_e1211187017326 : check e1211187017326 [[],[]] .three = true := by decide
def e1211187017334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211187017334 : Closed e1211187017334 ∧ code e1211187017334 = 5609233528438 := by decide
theorem cert_e1211187017334 : check e1211187017334 [[],[]] .three = true := by decide
def e1211187017338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211187017338 : Closed e1211187017338 ∧ code e1211187017338 = 5609233528442 := by decide
theorem cert_e1211187017338 : check e1211187017338 [[],[]] .three = true := by decide
def e1211187017502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211187017502 : Closed e1211187017502 ∧ code e1211187017502 = 5609233528606 := by decide
theorem cert_e1211187017502 : check e1211187017502 [[],[]] .three = true := by decide
def e1211187017526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187017526 : Closed e1211187017526 ∧ code e1211187017526 = 5609233528630 := by decide
theorem cert_e1211187017526 : check e1211187017526 [[],[]] .three = true := by decide
def e1211187017530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187017530 : Closed e1211187017530 ∧ code e1211187017530 = 5609233528634 := by decide
theorem cert_e1211187017530 : check e1211187017530 [[],[]] .three = true := by decide
def e1211187017614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211187017614 : Closed e1211187017614 ∧ code e1211187017614 = 5609233528718 := by decide
theorem cert_e1211187017614 : check e1211187017614 [[],[]] .three = true := by decide
def e1211187017786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211187017786 : Closed e1211187017786 ∧ code e1211187017786 = 5609233528890 := by decide
theorem cert_e1211187017786 : check e1211187017786 [[],[]] .three = true := by decide
def e1211187017834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e1211187017834 : Closed e1211187017834 ∧ code e1211187017834 = 5609233528938 := by decide
theorem cert_e1211187017834 : check e1211187017834 [[],[]] .three = true := by decide
def e1211187017882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211187017882 : Closed e1211187017882 ∧ code e1211187017882 = 5609233528986 := by decide
theorem cert_e1211187017882 : check e1211187017882 [[],[]] .three = true := by decide
def e1211187017926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211187017926 : Closed e1211187017926 ∧ code e1211187017926 = 5609233529030 := by decide
theorem cert_e1211187017926 : check e1211187017926 [[],[]] .three = true := by decide
def e1211187017950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e1211187017950 : Closed e1211187017950 ∧ code e1211187017950 = 5609233529054 := by decide
theorem cert_e1211187017950 : check e1211187017950 [[],[]] .three = true := by decide
def e1211187017966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211187017966 : Closed e1211187017966 ∧ code e1211187017966 = 5609233529070 := by decide
theorem cert_e1211187017966 : check e1211187017966 [[],[]] .three = true := by decide
def e1211187017974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211187017974 : Closed e1211187017974 ∧ code e1211187017974 = 5609233529078 := by decide
theorem cert_e1211187017974 : check e1211187017974 [[],[]] .three = true := by decide
def e1211187017978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1211187017978 : Closed e1211187017978 ∧ code e1211187017978 = 5609233529082 := by decide
theorem cert_e1211187017978 : check e1211187017978 [[],[]] .three = true := by decide
def e1211187018122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211187018122 : Closed e1211187018122 ∧ code e1211187018122 = 5609233529226 := by decide
theorem cert_e1211187018122 : check e1211187018122 [[],[]] .three = true := by decide
def e1211187018146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211187018146 : Closed e1211187018146 ∧ code e1211187018146 = 5609233529250 := by decide
theorem cert_e1211187018146 : check e1211187018146 [[],[]] .three = true := by decide
def e1211187018158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211187018158 : Closed e1211187018158 ∧ code e1211187018158 = 5609233529262 := by decide
theorem cert_e1211187018158 : check e1211187018158 [[],[]] .three = true := by decide
def e1211187018166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211187018166 : Closed e1211187018166 ∧ code e1211187018166 = 5609233529270 := by decide
theorem cert_e1211187018166 : check e1211187018166 [[],[]] .three = true := by decide
def e1211187018170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211187018170 : Closed e1211187018170 ∧ code e1211187018170 = 5609233529274 := by decide
theorem cert_e1211187018170 : check e1211187018170 [[],[]] .three = true := by decide
def e1211187018198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211187018198 : Closed e1211187018198 ∧ code e1211187018198 = 5609233529302 := by decide
theorem cert_e1211187018198 : check e1211187018198 [[],[]] .three = true := by decide
def e1211187018202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211187018202 : Closed e1211187018202 ∧ code e1211187018202 = 5609233529306 := by decide
theorem cert_e1211187018202 : check e1211187018202 [[],[]] .three = true := by decide
def e1211187018218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211187018218 : Closed e1211187018218 ∧ code e1211187018218 = 5609233529322 := by decide
theorem cert_e1211187018218 : check e1211187018218 [[],[]] .three = true := by decide
def e1211187018254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211187018254 : Closed e1211187018254 ∧ code e1211187018254 = 5609233529358 := by decide
theorem cert_e1211187018254 : check e1211187018254 [[],[]] .three = true := by decide
def e1211187018266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187018266 : Closed e1211187018266 ∧ code e1211187018266 = 5609233529370 := by decide
theorem cert_e1211187018266 : check e1211187018266 [[],[]] .three = true := by decide
def e1211187018302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e1211187018302 : Closed e1211187018302 ∧ code e1211187018302 = 5609233529406 := by decide
theorem cert_e1211187018302 : check e1211187018302 [[],[]] .three = true := by decide
def e1211187018338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211187018338 : Closed e1211187018338 ∧ code e1211187018338 = 5609233529442 := by decide
theorem cert_e1211187018338 : check e1211187018338 [[],[]] .three = true := by decide
def e1211187018350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211187018350 : Closed e1211187018350 ∧ code e1211187018350 = 5609233529454 := by decide
theorem cert_e1211187018350 : check e1211187018350 [[],[]] .three = true := by decide
def e1211187018358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211187018358 : Closed e1211187018358 ∧ code e1211187018358 = 5609233529462 := by decide
theorem cert_e1211187018358 : check e1211187018358 [[],[]] .three = true := by decide
def e1211187018362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211187018362 : Closed e1211187018362 ∧ code e1211187018362 = 5609233529466 := by decide
theorem cert_e1211187018362 : check e1211187018362 [[],[]] .three = true := by decide
def e1211187018526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211187018526 : Closed e1211187018526 ∧ code e1211187018526 = 5609233529630 := by decide
theorem cert_e1211187018526 : check e1211187018526 [[],[]] .three = true := by decide
def e1211187018550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187018550 : Closed e1211187018550 ∧ code e1211187018550 = 5609233529654 := by decide
theorem cert_e1211187018550 : check e1211187018550 [[],[]] .three = true := by decide
def e1211187018554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187018554 : Closed e1211187018554 ∧ code e1211187018554 = 5609233529658 := by decide
theorem cert_e1211187018554 : check e1211187018554 [[],[]] .three = true := by decide
def e1211187018638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211187018638 : Closed e1211187018638 ∧ code e1211187018638 = 5609233529742 := by decide
theorem cert_e1211187018638 : check e1211187018638 [[],[]] .three = true := by decide
def e1211187018650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211187018650 : Closed e1211187018650 ∧ code e1211187018650 = 5609233529754 := by decide
theorem cert_e1211187018650 : check e1211187018650 [[],[]] .three = true := by decide
def e1211187018694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e1211187018694 : Closed e1211187018694 ∧ code e1211187018694 = 5609233529798 := by decide
theorem cert_e1211187018694 : check e1211187018694 [[],[]] .three = true := by decide
def e1211187018862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211187018862 : Closed e1211187018862 ∧ code e1211187018862 = 5609233529966 := by decide
theorem cert_e1211187018862 : check e1211187018862 [[],[]] .three = true := by decide
def e1211187018870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211187018870 : Closed e1211187018870 ∧ code e1211187018870 = 5609233529974 := by decide
theorem cert_e1211187018870 : check e1211187018870 [[],[]] .three = true := by decide
def e1211187018874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211187018874 : Closed e1211187018874 ∧ code e1211187018874 = 5609233529978 := by decide
theorem cert_e1211187018874 : check e1211187018874 [[],[]] .three = true := by decide
def e1211187018966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211187018966 : Closed e1211187018966 ∧ code e1211187018966 = 5609233530070 := by decide
theorem cert_e1211187018966 : check e1211187018966 [[],[]] .three = true := by decide
def e1211187018970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211187018970 : Closed e1211187018970 ∧ code e1211187018970 = 5609233530074 := by decide
theorem cert_e1211187018970 : check e1211187018970 [[],[]] .three = true := by decide
def e1211187018986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211187018986 : Closed e1211187018986 ∧ code e1211187018986 = 5609233530090 := by decide
theorem cert_e1211187018986 : check e1211187018986 [[],[]] .three = true := by decide
def e1211187019038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211187019038 : Closed e1211187019038 ∧ code e1211187019038 = 5609233530142 := by decide
theorem cert_e1211187019038 : check e1211187019038 [[],[]] .three = true := by decide
def e1211187019062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211187019062 : Closed e1211187019062 ∧ code e1211187019062 = 5609233530166 := by decide
theorem cert_e1211187019062 : check e1211187019062 [[],[]] .three = true := by decide
def e1211187019066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211187019066 : Closed e1211187019066 ∧ code e1211187019066 = 5609233530170 := by decide
theorem cert_e1211187019066 : check e1211187019066 [[],[]] .three = true := by decide
def e1211187019150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211187019150 : Closed e1211187019150 ∧ code e1211187019150 = 5609233530254 := by decide
theorem cert_e1211187019150 : check e1211187019150 [[],[]] .three = true := by decide
def e1211187019162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211187019162 : Closed e1211187019162 ∧ code e1211187019162 = 5609233530266 := by decide
theorem cert_e1211187019162 : check e1211187019162 [[],[]] .three = true := by decide
def e1211187019206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211187019206 : Closed e1211187019206 ∧ code e1211187019206 = 5609233530310 := by decide
theorem cert_e1211187019206 : check e1211187019206 [[],[]] .three = true := by decide
def e1211187019318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211187019318 : Closed e1211187019318 ∧ code e1211187019318 = 5609233530422 := by decide
theorem cert_e1211187019318 : check e1211187019318 [[],[]] .three = true := by decide
def e1211187019322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211187019322 : Closed e1211187019322 ∧ code e1211187019322 = 5609233530426 := by decide
theorem cert_e1211187019322 : check e1211187019322 [[],[]] .three = true := by decide
def e1211187019406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211187019406 : Closed e1211187019406 ∧ code e1211187019406 = 5609233530510 := by decide
theorem cert_e1211187019406 : check e1211187019406 [[],[]] .three = true := by decide
def e1211187019462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211187019462 : Closed e1211187019462 ∧ code e1211187019462 = 5609233530566 := by decide
theorem cert_e1211187019462 : check e1211187019462 [[],[]] .three = true := by decide
def e1211187022614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211187022614 : Closed e1211187022614 ∧ code e1211187022614 = 5609233533718 := by decide
theorem cert_e1211187022614 : check e1211187022614 [[],[]] .three = true := by decide
def e1211187022690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211187022690 : Closed e1211187022690 ∧ code e1211187022690 = 5609233533794 := by decide
theorem cert_e1211187022690 : check e1211187022690 [[],[]] .three = true := by decide
def e1211187022702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211187022702 : Closed e1211187022702 ∧ code e1211187022702 = 5609233533806 := by decide
theorem cert_e1211187022702 : check e1211187022702 [[],[]] .three = true := by decide
def e1211187022710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211187022710 : Closed e1211187022710 ∧ code e1211187022710 = 5609233533814 := by decide
theorem cert_e1211187022710 : check e1211187022710 [[],[]] .three = true := by decide
def e1211187022730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211187022730 : Closed e1211187022730 ∧ code e1211187022730 = 5609233533834 := by decide
theorem cert_e1211187022730 : check e1211187022730 [[],[]] .three = true := by decide
def e1211187022754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211187022754 : Closed e1211187022754 ∧ code e1211187022754 = 5609233533858 := by decide
theorem cert_e1211187022754 : check e1211187022754 [[],[]] .three = true := by decide
def e1211187022766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211187022766 : Closed e1211187022766 ∧ code e1211187022766 = 5609233533870 := by decide
theorem cert_e1211187022766 : check e1211187022766 [[],[]] .three = true := by decide
def e1211187022774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1211187022774 : Closed e1211187022774 ∧ code e1211187022774 = 5609233533878 := by decide
theorem cert_e1211187022774 : check e1211187022774 [[],[]] .three = true := by decide
end Blc.Floor42
