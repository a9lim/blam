import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211281799034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211281799034 : Closed e1211281799034 ∧ code e1211281799034 = 5609328310138 := by decide
theorem cert_e1211281799034 : check e1211281799034 [[],[]] .chain = true := by decide
def e1211281799086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211281799086 : Closed e1211281799086 ∧ code e1211281799086 = 5609328310190 := by decide
theorem cert_e1211281799086 : check e1211281799086 [[],[]] .chain = true := by decide
def e1211281799098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211281799098 : Closed e1211281799098 ∧ code e1211281799098 = 5609328310202 := by decide
theorem cert_e1211281799098 : check e1211281799098 [[],[]] .chain = true := by decide
def e1211281799382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211281799382 : Closed e1211281799382 ∧ code e1211281799382 = 5609328310486 := by decide
theorem cert_e1211281799382 : check e1211281799382 [[],[]] .smaller = true := by decide
def e1211281799386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211281799386 : Closed e1211281799386 ∧ code e1211281799386 = 5609328310490 := by decide
theorem cert_e1211281799386 : check e1211281799386 [[],[]] .smaller = true := by decide
def e1211281799402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211281799402 : Closed e1211281799402 ∧ code e1211281799402 = 5609328310506 := by decide
theorem cert_e1211281799402 : check e1211281799402 [[],[]] .smaller = true := by decide
def e1211281799734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211281799734 : Closed e1211281799734 ∧ code e1211281799734 = 5609328310838 := by decide
theorem cert_e1211281799734 : check e1211281799734 [[],[]] .smaller = true := by decide
def e1211281799738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211281799738 : Closed e1211281799738 ∧ code e1211281799738 = 5609328310842 := by decide
theorem cert_e1211281799738 : check e1211281799738 [[],[]] .smaller = true := by decide
def e1211281799822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211281799822 : Closed e1211281799822 ∧ code e1211281799822 = 5609328310926 := by decide
theorem cert_e1211281799822 : check e1211281799822 [[],[]] .smaller = true := by decide
def e1211281799878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211281799878 : Closed e1211281799878 ∧ code e1211281799878 = 5609328310982 := by decide
theorem cert_e1211281799878 : check e1211281799878 [[],[]] .smaller = true := by decide
def e1211281799902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211281799902 : Closed e1211281799902 ∧ code e1211281799902 = 5609328311006 := by decide
theorem cert_e1211281799902 : check e1211281799902 [[],[]] .chain = true := by decide
def e1211281799926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211281799926 : Closed e1211281799926 ∧ code e1211281799926 = 5609328311030 := by decide
theorem cert_e1211281799926 : check e1211281799926 [[],[]] .chain = true := by decide
def e1211281799962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211281799962 : Closed e1211281799962 ∧ code e1211281799962 = 5609328311066 := by decide
theorem cert_e1211281799962 : check e1211281799962 [[],[]] .smaller = true := by decide
def e1211281800006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211281800006 : Closed e1211281800006 ∧ code e1211281800006 = 5609328311110 := by decide
theorem cert_e1211281800006 : check e1211281800006 [[],[]] .smaller = true := by decide
def e1211281800030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211281800030 : Closed e1211281800030 ∧ code e1211281800030 = 5609328311134 := by decide
theorem cert_e1211281800030 : check e1211281800030 [[],[]] .chain = true := by decide
def e1211281800058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211281800058 : Closed e1211281800058 ∧ code e1211281800058 = 5609328311162 := by decide
theorem cert_e1211281800058 : check e1211281800058 [[],[]] .chain = true := by decide
def e1211281800150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211281800150 : Closed e1211281800150 ∧ code e1211281800150 = 5609328311254 := by decide
theorem cert_e1211281800150 : check e1211281800150 [[],[]] .chain = true := by decide
def e1211281800154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211281800154 : Closed e1211281800154 ∧ code e1211281800154 = 5609328311258 := by decide
theorem cert_e1211281800154 : check e1211281800154 [[],[]] .chain = true := by decide
def e1211281800558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211281800558 : Closed e1211281800558 ∧ code e1211281800558 = 5609328311662 := by decide
theorem cert_e1211281800558 : check e1211281800558 [[],[]] .chain = true := by decide
def e1211281800566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211281800566 : Closed e1211281800566 ∧ code e1211281800566 = 5609328311670 := by decide
theorem cert_e1211281800566 : check e1211281800566 [[],[]] .chain = true := by decide
def e1211281800622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211281800622 : Closed e1211281800622 ∧ code e1211281800622 = 5609328311726 := by decide
theorem cert_e1211281800622 : check e1211281800622 [[],[]] .chain = true := by decide
def e1211281800634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211281800634 : Closed e1211281800634 ∧ code e1211281800634 = 5609328311738 := by decide
theorem cert_e1211281800634 : check e1211281800634 [[],[]] .chain = true := by decide
def e1211281800662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211281800662 : Closed e1211281800662 ∧ code e1211281800662 = 5609328311766 := by decide
theorem cert_e1211281800662 : check e1211281800662 [[],[]] .chain = true := by decide
def e1211281800666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211281800666 : Closed e1211281800666 ∧ code e1211281800666 = 5609328311770 := by decide
theorem cert_e1211281800666 : check e1211281800666 [[],[]] .chain = true := by decide
def e1211281802990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e1211281802990 : Closed e1211281802990 ∧ code e1211281802990 = 5609328314094 := by decide
theorem cert_e1211281802990 : check e1211281802990 [[],[]] .smaller = true := by decide
def e1211281802998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e1211281802998 : Closed e1211281802998 ∧ code e1211281802998 = 5609328314102 := by decide
theorem cert_e1211281802998 : check e1211281802998 [[],[]] .smaller = true := by decide
def e1211281803182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e1211281803182 : Closed e1211281803182 ∧ code e1211281803182 = 5609328314286 := by decide
theorem cert_e1211281803182 : check e1211281803182 [[],[]] .smaller = true := by decide
def e1211281803222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e1211281803222 : Closed e1211281803222 ∧ code e1211281803222 = 5609328314326 := by decide
theorem cert_e1211281803222 : check e1211281803222 [[],[]] .smaller = true := by decide
def e1211281804526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211281804526 : Closed e1211281804526 ∧ code e1211281804526 = 5609328315630 := by decide
theorem cert_e1211281804526 : check e1211281804526 [[],[]] .smaller = true := by decide
def e1211281804534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211281804534 : Closed e1211281804534 ∧ code e1211281804534 = 5609328315638 := by decide
theorem cert_e1211281804534 : check e1211281804534 [[],[]] .smaller = true := by decide
def e1211281804910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211281804910 : Closed e1211281804910 ∧ code e1211281804910 = 5609328316014 := by decide
theorem cert_e1211281804910 : check e1211281804910 [[],[]] .smaller = true := by decide
def e1211281804922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211281804922 : Closed e1211281804922 ∧ code e1211281804922 = 5609328316026 := by decide
theorem cert_e1211281804922 : check e1211281804922 [[],[]] .smaller = true := by decide
def e1211281805110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211281805110 : Closed e1211281805110 ∧ code e1211281805110 = 5609328316214 := by decide
theorem cert_e1211281805110 : check e1211281805110 [[],[]] .smaller = true := by decide
def e1211281805114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211281805114 : Closed e1211281805114 ∧ code e1211281805114 = 5609328316218 := by decide
theorem cert_e1211281805114 : check e1211281805114 [[],[]] .smaller = true := by decide
def e1211281807598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211281807598 : Closed e1211281807598 ∧ code e1211281807598 = 5609328318702 := by decide
theorem cert_e1211281807598 : check e1211281807598 [[],[]] .smaller = true := by decide
def e1211281807606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211281807606 : Closed e1211281807606 ∧ code e1211281807606 = 5609328318710 := by decide
theorem cert_e1211281807606 : check e1211281807606 [[],[]] .smaller = true := by decide
def e1211281808158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211281808158 : Closed e1211281808158 ∧ code e1211281808158 = 5609328319262 := by decide
theorem cert_e1211281808158 : check e1211281808158 [[],[]] .smaller = true := by decide
def e1211281808270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211281808270 : Closed e1211281808270 ∧ code e1211281808270 = 5609328319374 := by decide
theorem cert_e1211281808270 : check e1211281808270 [[],[]] .smaller = true := by decide
def e1211281808494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211281808494 : Closed e1211281808494 ∧ code e1211281808494 = 5609328319598 := by decide
theorem cert_e1211281808494 : check e1211281808494 [[],[]] .smaller = true := by decide
def e1211281808506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211281808506 : Closed e1211281808506 ∧ code e1211281808506 = 5609328319610 := by decide
theorem cert_e1211281808506 : check e1211281808506 [[],[]] .smaller = true := by decide
def e1211281808670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211281808670 : Closed e1211281808670 ∧ code e1211281808670 = 5609328319774 := by decide
theorem cert_e1211281808670 : check e1211281808670 [[],[]] .smaller = true := by decide
def e1211281808838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211281808838 : Closed e1211281808838 ∧ code e1211281808838 = 5609328319942 := by decide
theorem cert_e1211281808838 : check e1211281808838 [[],[]] .smaller = true := by decide
def e1211281808862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e1211281808862 : Closed e1211281808862 ∧ code e1211281808862 = 5609328319966 := by decide
theorem cert_e1211281808862 : check e1211281808862 [[],[]] .chain = true := by decide
def e1211281808878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e1211281808878 : Closed e1211281808878 ∧ code e1211281808878 = 5609328319982 := by decide
theorem cert_e1211281808878 : check e1211281808878 [[],[]] .chain = true := by decide
def e1211281808950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211281808950 : Closed e1211281808950 ∧ code e1211281808950 = 5609328320054 := by decide
theorem cert_e1211281808950 : check e1211281808950 [[],[]] .smaller = true := by decide
def e1211281808954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211281808954 : Closed e1211281808954 ∧ code e1211281808954 = 5609328320058 := by decide
theorem cert_e1211281808954 : check e1211281808954 [[],[]] .smaller = true := by decide
def e1211281809038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211281809038 : Closed e1211281809038 ∧ code e1211281809038 = 5609328320142 := by decide
theorem cert_e1211281809038 : check e1211281809038 [[],[]] .smaller = true := by decide
def e1211281809094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211281809094 : Closed e1211281809094 ∧ code e1211281809094 = 5609328320198 := by decide
theorem cert_e1211281809094 : check e1211281809094 [[],[]] .smaller = true := by decide
def e1211281809118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e1211281809118 : Closed e1211281809118 ∧ code e1211281809118 = 5609328320222 := by decide
theorem cert_e1211281809118 : check e1211281809118 [[],[]] .chain = true := by decide
def e1211281809142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e1211281809142 : Closed e1211281809142 ∧ code e1211281809142 = 5609328320246 := by decide
theorem cert_e1211281809142 : check e1211281809142 [[],[]] .chain = true := by decide
def e1211281809262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e1211281809262 : Closed e1211281809262 ∧ code e1211281809262 = 5609328320366 := by decide
theorem cert_e1211281809262 : check e1211281809262 [[],[]] .chain = true := by decide
def e1211281809270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e1211281809270 : Closed e1211281809270 ∧ code e1211281809270 = 5609328320374 := by decide
theorem cert_e1211281809270 : check e1211281809270 [[],[]] .chain = true := by decide
def e1211281811230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211281811230 : Closed e1211281811230 ∧ code e1211281811230 = 5609328322334 := by decide
theorem cert_e1211281811230 : check e1211281811230 [[],[]] .smaller = true := by decide
def e1211281811342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211281811342 : Closed e1211281811342 ∧ code e1211281811342 = 5609328322446 := by decide
theorem cert_e1211281811342 : check e1211281811342 [[],[]] .smaller = true := by decide
def e1211281813726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281813726 : Closed e1211281813726 ∧ code e1211281813726 = 5609328324830 := by decide
theorem cert_e1211281813726 : check e1211281813726 [[],[]] .smaller = true := by decide
def e1211281813754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281813754 : Closed e1211281813754 ∧ code e1211281813754 = 5609328324858 := by decide
theorem cert_e1211281813754 : check e1211281813754 [[],[]] .smaller = true := by decide
def e1211281814302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211281814302 : Closed e1211281814302 ∧ code e1211281814302 = 5609328325406 := by decide
theorem cert_e1211281814302 : check e1211281814302 [[],[]] .smaller = true := by decide
def e1211281814470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211281814470 : Closed e1211281814470 ∧ code e1211281814470 = 5609328325574 := by decide
theorem cert_e1211281814470 : check e1211281814470 [[],[]] .smaller = true := by decide
def e1211281814494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211281814494 : Closed e1211281814494 ∧ code e1211281814494 = 5609328325598 := by decide
theorem cert_e1211281814494 : check e1211281814494 [[],[]] .chain = true := by decide
def e1211281814510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211281814510 : Closed e1211281814510 ∧ code e1211281814510 = 5609328325614 := by decide
theorem cert_e1211281814510 : check e1211281814510 [[],[]] .chain = true := by decide
def e1211281815662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211281815662 : Closed e1211281815662 ∧ code e1211281815662 = 5609328326766 := by decide
theorem cert_e1211281815662 : check e1211281815662 [[],[]] .smaller = true := by decide
def e1211281815674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211281815674 : Closed e1211281815674 ∧ code e1211281815674 = 5609328326778 := by decide
theorem cert_e1211281815674 : check e1211281815674 [[],[]] .smaller = true := by decide
def e1211281815950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211281815950 : Closed e1211281815950 ∧ code e1211281815950 = 5609328327054 := by decide
theorem cert_e1211281815950 : check e1211281815950 [[],[]] .smaller = true := by decide
def e1211281816006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211281816006 : Closed e1211281816006 ∧ code e1211281816006 = 5609328327110 := by decide
theorem cert_e1211281816006 : check e1211281816006 [[],[]] .smaller = true := by decide
def e1211281816030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211281816030 : Closed e1211281816030 ∧ code e1211281816030 = 5609328327134 := by decide
theorem cert_e1211281816030 : check e1211281816030 [[],[]] .chain = true := by decide
def e1211281816054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211281816054 : Closed e1211281816054 ∧ code e1211281816054 = 5609328327158 := by decide
theorem cert_e1211281816054 : check e1211281816054 [[],[]] .chain = true := by decide
def e1211281816814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211281816814 : Closed e1211281816814 ∧ code e1211281816814 = 5609328327918 := by decide
theorem cert_e1211281816814 : check e1211281816814 [[],[]] .chain = true := by decide
def e1211281816822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211281816822 : Closed e1211281816822 ∧ code e1211281816822 = 5609328327926 := by decide
theorem cert_e1211281816822 : check e1211281816822 [[],[]] .chain = true := by decide
def e1211281818478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211281818478 : Closed e1211281818478 ∧ code e1211281818478 = 5609328329582 := by decide
theorem cert_e1211281818478 : check e1211281818478 [[],[]] .smaller = true := by decide
def e1211281818490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211281818490 : Closed e1211281818490 ∧ code e1211281818490 = 5609328329594 := by decide
theorem cert_e1211281818490 : check e1211281818490 [[],[]] .smaller = true := by decide
def e1211281818542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211281818542 : Closed e1211281818542 ∧ code e1211281818542 = 5609328329646 := by decide
theorem cert_e1211281818542 : check e1211281818542 [[],[]] .smaller = true := by decide
def e1211281818602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211281818602 : Closed e1211281818602 ∧ code e1211281818602 = 5609328329706 := by decide
theorem cert_e1211281818602 : check e1211281818602 [[],[]] .smaller = true := by decide
def e1211281819246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211281819246 : Closed e1211281819246 ∧ code e1211281819246 = 5609328330350 := by decide
theorem cert_e1211281819246 : check e1211281819246 [[],[]] .smaller = true := by decide
def e1211281819258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211281819258 : Closed e1211281819258 ∧ code e1211281819258 = 5609328330362 := by decide
theorem cert_e1211281819258 : check e1211281819258 [[],[]] .smaller = true := by decide
def e1211281819546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211281819546 : Closed e1211281819546 ∧ code e1211281819546 = 5609328330650 := by decide
theorem cert_e1211281819546 : check e1211281819546 [[],[]] .smaller = true := by decide
def e1211281820782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211281820782 : Closed e1211281820782 ∧ code e1211281820782 = 5609328331886 := by decide
theorem cert_e1211281820782 : check e1211281820782 [[],[]] .smaller = true := by decide
def e1211281820794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211281820794 : Closed e1211281820794 ∧ code e1211281820794 = 5609328331898 := by decide
theorem cert_e1211281820794 : check e1211281820794 [[],[]] .smaller = true := by decide
def e1211281820958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211281820958 : Closed e1211281820958 ∧ code e1211281820958 = 5609328332062 := by decide
theorem cert_e1211281820958 : check e1211281820958 [[],[]] .smaller = true := by decide
def e1211281821126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211281821126 : Closed e1211281821126 ∧ code e1211281821126 = 5609328332230 := by decide
theorem cert_e1211281821126 : check e1211281821126 [[],[]] .smaller = true := by decide
def e1211281821150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211281821150 : Closed e1211281821150 ∧ code e1211281821150 = 5609328332254 := by decide
theorem cert_e1211281821150 : check e1211281821150 [[],[]] .chain = true := by decide
def e1211281821166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211281821166 : Closed e1211281821166 ∧ code e1211281821166 = 5609328332270 := by decide
theorem cert_e1211281821166 : check e1211281821166 [[],[]] .chain = true := by decide
def e1211281821466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211281821466 : Closed e1211281821466 ∧ code e1211281821466 = 5609328332570 := by decide
theorem cert_e1211281821466 : check e1211281821466 [[],[]] .smaller = true := by decide
def e1211281821510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211281821510 : Closed e1211281821510 ∧ code e1211281821510 = 5609328332614 := by decide
theorem cert_e1211281821510 : check e1211281821510 [[],[]] .smaller = true := by decide
def e1211281821534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211281821534 : Closed e1211281821534 ∧ code e1211281821534 = 5609328332638 := by decide
theorem cert_e1211281821534 : check e1211281821534 [[],[]] .chain = true := by decide
def e1211281821562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211281821562 : Closed e1211281821562 ∧ code e1211281821562 = 5609328332666 := by decide
theorem cert_e1211281821562 : check e1211281821562 [[],[]] .chain = true := by decide
def e1211281821614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211281821614 : Closed e1211281821614 ∧ code e1211281821614 = 5609328332718 := by decide
theorem cert_e1211281821614 : check e1211281821614 [[],[]] .chain = true := by decide
def e1211281821626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211281821626 : Closed e1211281821626 ∧ code e1211281821626 = 5609328332730 := by decide
theorem cert_e1211281821626 : check e1211281821626 [[],[]] .chain = true := by decide
def e1211281821918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211281821918 : Closed e1211281821918 ∧ code e1211281821918 = 5609328333022 := by decide
theorem cert_e1211281821918 : check e1211281821918 [[],[]] .smaller = true := by decide
def e1211281821946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211281821946 : Closed e1211281821946 ∧ code e1211281821946 = 5609328333050 := by decide
theorem cert_e1211281821946 : check e1211281821946 [[],[]] .smaller = true := by decide
def e1211281822494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211281822494 : Closed e1211281822494 ∧ code e1211281822494 = 5609328333598 := by decide
theorem cert_e1211281822494 : check e1211281822494 [[],[]] .smaller = true := by decide
def e1211281822662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211281822662 : Closed e1211281822662 ∧ code e1211281822662 = 5609328333766 := by decide
theorem cert_e1211281822662 : check e1211281822662 [[],[]] .smaller = true := by decide
def e1211281822686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211281822686 : Closed e1211281822686 ∧ code e1211281822686 = 5609328333790 := by decide
theorem cert_e1211281822686 : check e1211281822686 [[],[]] .chain = true := by decide
def e1211281822702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211281822702 : Closed e1211281822702 ∧ code e1211281822702 = 5609328333806 := by decide
theorem cert_e1211281822702 : check e1211281822702 [[],[]] .chain = true := by decide
def e1211281824822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281824822 : Closed e1211281824822 ∧ code e1211281824822 = 5609328335926 := by decide
theorem cert_e1211281824822 : check e1211281824822 [[],[]] .smaller = true := by decide
def e1211281824826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281824826 : Closed e1211281824826 ∧ code e1211281824826 = 5609328335930 := by decide
theorem cert_e1211281824826 : check e1211281824826 [[],[]] .smaller = true := by decide
def e1211281824966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211281824966 : Closed e1211281824966 ∧ code e1211281824966 = 5609328336070 := by decide
theorem cert_e1211281824966 : check e1211281824966 [[],[]] .smaller = true := by decide
def e1211281824990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211281824990 : Closed e1211281824990 ∧ code e1211281824990 = 5609328336094 := by decide
theorem cert_e1211281824990 : check e1211281824990 [[],[]] .chain = true := by decide
def e1211281825018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211281825018 : Closed e1211281825018 ∧ code e1211281825018 = 5609328336122 := by decide
theorem cert_e1211281825018 : check e1211281825018 [[],[]] .chain = true := by decide
def e1211281825390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211281825390 : Closed e1211281825390 ∧ code e1211281825390 = 5609328336494 := by decide
theorem cert_e1211281825390 : check e1211281825390 [[],[]] .chain = true := by decide
def e1211281825402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211281825402 : Closed e1211281825402 ∧ code e1211281825402 = 5609328336506 := by decide
theorem cert_e1211281825402 : check e1211281825402 [[],[]] .chain = true := by decide
def e1211281826230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211281826230 : Closed e1211281826230 ∧ code e1211281826230 = 5609328337334 := by decide
theorem cert_e1211281826230 : check e1211281826230 [[],[]] .smaller = true := by decide
def e1211281826234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e1211281826234 : Closed e1211281826234 ∧ code e1211281826234 = 5609328337338 := by decide
theorem cert_e1211281826234 : check e1211281826234 [[],[]] .smaller = true := by decide
def e1211281826262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211281826262 : Closed e1211281826262 ∧ code e1211281826262 = 5609328337366 := by decide
theorem cert_e1211281826262 : check e1211281826262 [[],[]] .smaller = true := by decide
def e1211281826282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e1211281826282 : Closed e1211281826282 ∧ code e1211281826282 = 5609328337386 := by decide
theorem cert_e1211281826282 : check e1211281826282 [[],[]] .smaller = true := by decide
def e1211281826614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211281826614 : Closed e1211281826614 ∧ code e1211281826614 = 5609328337718 := by decide
theorem cert_e1211281826614 : check e1211281826614 [[],[]] .smaller = true := by decide
def e1211281826618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211281826618 : Closed e1211281826618 ∧ code e1211281826618 = 5609328337722 := by decide
theorem cert_e1211281826618 : check e1211281826618 [[],[]] .smaller = true := by decide
def e1211281826714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211281826714 : Closed e1211281826714 ∧ code e1211281826714 = 5609328337818 := by decide
theorem cert_e1211281826714 : check e1211281826714 [[],[]] .smaller = true := by decide
def e1211281827382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211281827382 : Closed e1211281827382 ∧ code e1211281827382 = 5609328338486 := by decide
theorem cert_e1211281827382 : check e1211281827382 [[],[]] .smaller = true := by decide
def e1211281827386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211281827386 : Closed e1211281827386 ∧ code e1211281827386 = 5609328338490 := by decide
theorem cert_e1211281827386 : check e1211281827386 [[],[]] .smaller = true := by decide
def e1211281827470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211281827470 : Closed e1211281827470 ∧ code e1211281827470 = 5609328338574 := by decide
theorem cert_e1211281827470 : check e1211281827470 [[],[]] .smaller = true := by decide
def e1211281827526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211281827526 : Closed e1211281827526 ∧ code e1211281827526 = 5609328338630 := by decide
theorem cert_e1211281827526 : check e1211281827526 [[],[]] .smaller = true := by decide
def e1211281827550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211281827550 : Closed e1211281827550 ∧ code e1211281827550 = 5609328338654 := by decide
theorem cert_e1211281827550 : check e1211281827550 [[],[]] .chain = true := by decide
def e1211281827574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211281827574 : Closed e1211281827574 ∧ code e1211281827574 = 5609328338678 := by decide
theorem cert_e1211281827574 : check e1211281827574 [[],[]] .chain = true := by decide
def e1211281827610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211281827610 : Closed e1211281827610 ∧ code e1211281827610 = 5609328338714 := by decide
theorem cert_e1211281827610 : check e1211281827610 [[],[]] .smaller = true := by decide
def e1211281827654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211281827654 : Closed e1211281827654 ∧ code e1211281827654 = 5609328338758 := by decide
theorem cert_e1211281827654 : check e1211281827654 [[],[]] .smaller = true := by decide
def e1211281827678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211281827678 : Closed e1211281827678 ∧ code e1211281827678 = 5609328338782 := by decide
theorem cert_e1211281827678 : check e1211281827678 [[],[]] .chain = true := by decide
def e1211281827706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211281827706 : Closed e1211281827706 ∧ code e1211281827706 = 5609328338810 := by decide
theorem cert_e1211281827706 : check e1211281827706 [[],[]] .chain = true := by decide
def e1211281827798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211281827798 : Closed e1211281827798 ∧ code e1211281827798 = 5609328338902 := by decide
theorem cert_e1211281827798 : check e1211281827798 [[],[]] .chain = true := by decide
def e1211281827802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211281827802 : Closed e1211281827802 ∧ code e1211281827802 = 5609328338906 := by decide
theorem cert_e1211281827802 : check e1211281827802 [[],[]] .chain = true := by decide
def e1211281827950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211281827950 : Closed e1211281827950 ∧ code e1211281827950 = 5609328339054 := by decide
theorem cert_e1211281827950 : check e1211281827950 [[],[]] .smaller = true := by decide
def e1211281827962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211281827962 : Closed e1211281827962 ∧ code e1211281827962 = 5609328339066 := by decide
theorem cert_e1211281827962 : check e1211281827962 [[],[]] .smaller = true := by decide
def e1211281828238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211281828238 : Closed e1211281828238 ∧ code e1211281828238 = 5609328339342 := by decide
theorem cert_e1211281828238 : check e1211281828238 [[],[]] .smaller = true := by decide
def e1211281828294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211281828294 : Closed e1211281828294 ∧ code e1211281828294 = 5609328339398 := by decide
theorem cert_e1211281828294 : check e1211281828294 [[],[]] .smaller = true := by decide
def e1211281828318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211281828318 : Closed e1211281828318 ∧ code e1211281828318 = 5609328339422 := by decide
theorem cert_e1211281828318 : check e1211281828318 [[],[]] .chain = true := by decide
def e1211281828342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211281828342 : Closed e1211281828342 ∧ code e1211281828342 = 5609328339446 := by decide
theorem cert_e1211281828342 : check e1211281828342 [[],[]] .chain = true := by decide
def e1211281828918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211281828918 : Closed e1211281828918 ∧ code e1211281828918 = 5609328340022 := by decide
theorem cert_e1211281828918 : check e1211281828918 [[],[]] .smaller = true := by decide
def e1211281828922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211281828922 : Closed e1211281828922 ∧ code e1211281828922 = 5609328340026 := by decide
theorem cert_e1211281828922 : check e1211281828922 [[],[]] .smaller = true := by decide
def e1211281829062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211281829062 : Closed e1211281829062 ∧ code e1211281829062 = 5609328340166 := by decide
theorem cert_e1211281829062 : check e1211281829062 [[],[]] .smaller = true := by decide
def e1211281829086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211281829086 : Closed e1211281829086 ∧ code e1211281829086 = 5609328340190 := by decide
theorem cert_e1211281829086 : check e1211281829086 [[],[]] .chain = true := by decide
def e1211281829114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211281829114 : Closed e1211281829114 ∧ code e1211281829114 = 5609328340218 := by decide
theorem cert_e1211281829114 : check e1211281829114 [[],[]] .chain = true := by decide
def e1211281829686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211281829686 : Closed e1211281829686 ∧ code e1211281829686 = 5609328340790 := by decide
theorem cert_e1211281829686 : check e1211281829686 [[],[]] .chain = true := by decide
def e1211281829690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211281829690 : Closed e1211281829690 ∧ code e1211281829690 = 5609328340794 := by decide
theorem cert_e1211281829690 : check e1211281829690 [[],[]] .chain = true := by decide
def e1211281830766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211281830766 : Closed e1211281830766 ∧ code e1211281830766 = 5609328341870 := by decide
theorem cert_e1211281830766 : check e1211281830766 [[],[]] .chain = true := by decide
def e1211281830774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211281830774 : Closed e1211281830774 ∧ code e1211281830774 = 5609328341878 := by decide
theorem cert_e1211281830774 : check e1211281830774 [[],[]] .chain = true := by decide
def e1211281830830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211281830830 : Closed e1211281830830 ∧ code e1211281830830 = 5609328341934 := by decide
theorem cert_e1211281830830 : check e1211281830830 [[],[]] .chain = true := by decide
def e1211281830842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211281830842 : Closed e1211281830842 ∧ code e1211281830842 = 5609328341946 := by decide
theorem cert_e1211281830842 : check e1211281830842 [[],[]] .chain = true := by decide
def e1211281830870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211281830870 : Closed e1211281830870 ∧ code e1211281830870 = 5609328341974 := by decide
theorem cert_e1211281830870 : check e1211281830870 [[],[]] .chain = true := by decide
def e1211281830874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211281830874 : Closed e1211281830874 ∧ code e1211281830874 = 5609328341978 := by decide
theorem cert_e1211281830874 : check e1211281830874 [[],[]] .chain = true := by decide
def e1211281831150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211281831150 : Closed e1211281831150 ∧ code e1211281831150 = 5609328342254 := by decide
theorem cert_e1211281831150 : check e1211281831150 [[],[]] .chain = true := by decide
def e1211281831158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211281831158 : Closed e1211281831158 ∧ code e1211281831158 = 5609328342262 := by decide
theorem cert_e1211281831158 : check e1211281831158 [[],[]] .chain = true := by decide
def e1211281831534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211281831534 : Closed e1211281831534 ∧ code e1211281831534 = 5609328342638 := by decide
theorem cert_e1211281831534 : check e1211281831534 [[],[]] .chain = true := by decide
def e1211281831546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211281831546 : Closed e1211281831546 ∧ code e1211281831546 = 5609328342650 := by decide
theorem cert_e1211281831546 : check e1211281831546 [[],[]] .chain = true := by decide
def e1211281831734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211281831734 : Closed e1211281831734 ∧ code e1211281831734 = 5609328342838 := by decide
theorem cert_e1211281831734 : check e1211281831734 [[],[]] .chain = true := by decide
def e1211281831738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211281831738 : Closed e1211281831738 ∧ code e1211281831738 = 5609328342842 := by decide
theorem cert_e1211281831738 : check e1211281831738 [[],[]] .chain = true := by decide
def e1211281839838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211281839838 : Closed e1211281839838 ∧ code e1211281839838 = 5609328350942 := by decide
theorem cert_e1211281839838 : check e1211281839838 [[],[]] .smaller = true := by decide
def e1211281839862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211281839862 : Closed e1211281839862 ∧ code e1211281839862 = 5609328350966 := by decide
theorem cert_e1211281839862 : check e1211281839862 [[],[]] .smaller = true := by decide
def e1211281839966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211281839966 : Closed e1211281839966 ∧ code e1211281839966 = 5609328351070 := by decide
theorem cert_e1211281839966 : check e1211281839966 [[],[]] .smaller = true := by decide
def e1211281839994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211281839994 : Closed e1211281839994 ∧ code e1211281839994 = 5609328351098 := by decide
theorem cert_e1211281839994 : check e1211281839994 [[],[]] .smaller = true := by decide
def e1211281840086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211281840086 : Closed e1211281840086 ∧ code e1211281840086 = 5609328351190 := by decide
theorem cert_e1211281840086 : check e1211281840086 [[],[]] .smaller = true := by decide
def e1211281840090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211281840090 : Closed e1211281840090 ∧ code e1211281840090 = 5609328351194 := by decide
theorem cert_e1211281840090 : check e1211281840090 [[],[]] .smaller = true := by decide
def e1211281840606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211281840606 : Closed e1211281840606 ∧ code e1211281840606 = 5609328351710 := by decide
theorem cert_e1211281840606 : check e1211281840606 [[],[]] .smaller = true := by decide
def e1211281840630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211281840630 : Closed e1211281840630 ∧ code e1211281840630 = 5609328351734 := by decide
theorem cert_e1211281840630 : check e1211281840630 [[],[]] .smaller = true := by decide
def e1211281841374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211281841374 : Closed e1211281841374 ∧ code e1211281841374 = 5609328352478 := by decide
theorem cert_e1211281841374 : check e1211281841374 [[],[]] .smaller = true := by decide
def e1211281841402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211281841402 : Closed e1211281841402 ∧ code e1211281841402 = 5609328352506 := by decide
theorem cert_e1211281841402 : check e1211281841402 [[],[]] .smaller = true := by decide
def e1211281841726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211281841726 : Closed e1211281841726 ∧ code e1211281841726 = 5609328352830 := by decide
theorem cert_e1211281841726 : check e1211281841726 [[],[]] .smaller = true := by decide
def e1211281841950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211281841950 : Closed e1211281841950 ∧ code e1211281841950 = 5609328353054 := by decide
theorem cert_e1211281841950 : check e1211281841950 [[],[]] .smaller = true := by decide
def e1211281841974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211281841974 : Closed e1211281841974 ∧ code e1211281841974 = 5609328353078 := by decide
theorem cert_e1211281841974 : check e1211281841974 [[],[]] .smaller = true := by decide
def e1211281841978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211281841978 : Closed e1211281841978 ∧ code e1211281841978 = 5609328353082 := by decide
theorem cert_e1211281841978 : check e1211281841978 [[],[]] .smaller = true := by decide
def e1211281856750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211281856750 : Closed e1211281856750 ∧ code e1211281856750 = 5609328367854 := by decide
theorem cert_e1211281856750 : check e1211281856750 [[],[]] .smaller = true := by decide
def e1211281856758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211281856758 : Closed e1211281856758 ∧ code e1211281856758 = 5609328367862 := by decide
theorem cert_e1211281856758 : check e1211281856758 [[],[]] .smaller = true := by decide
end Blc.Floor42
