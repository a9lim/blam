import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202690885134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202690885134 : Closed e1202690885134 ∧ code e1202690885134 = 5600737396238 := by decide
theorem cert_e1202690885134 : check e1202690885134 [[]] .width = true := by decide
def e1202690885146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690885146 : Closed e1202690885146 ∧ code e1202690885146 = 5600737396250 := by decide
theorem cert_e1202690885146 : check e1202690885146 [[]] .width = true := by decide
def e1202690885218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202690885218 : Closed e1202690885218 ∧ code e1202690885218 = 5600737396322 := by decide
theorem cert_e1202690885218 : check e1202690885218 [[]] .width = true := by decide
def e1202690908186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690908186 : Closed e1202690908186 ∧ code e1202690908186 = 5600737419290 := by decide
theorem cert_e1202690908186 : check e1202690908186 [[]] .width = true := by decide
def e1202690908278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202690908278 : Closed e1202690908278 ∧ code e1202690908278 = 5600737419382 := by decide
theorem cert_e1202690908278 : check e1202690908278 [[]] .width = true := by decide
def e1202690908522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202690908522 : Closed e1202690908522 ∧ code e1202690908522 = 5600737419626 := by decide
theorem cert_e1202690908522 : check e1202690908522 [[]] .width = true := by decide
def e1202690908570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202690908570 : Closed e1202690908570 ∧ code e1202690908570 = 5600737419674 := by decide
theorem cert_e1202690908570 : check e1202690908570 [[]] .width = true := by decide
def e1202690932934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202690932934 : Closed e1202690932934 ∧ code e1202690932934 = 5600737444038 := by decide
theorem cert_e1202690932934 : check e1202690932934 [[]] .width = true := by decide
def e1202690940954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690940954 : Closed e1202690940954 ∧ code e1202690940954 = 5600737452058 := by decide
theorem cert_e1202690940954 : check e1202690940954 [[]] .width = true := by decide
def e1202690941046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202690941046 : Closed e1202690941046 ∧ code e1202690941046 = 5600737452150 := by decide
private def t_e1202690941046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202690941046 : ¬ IsSelfInterpreter e1202690941046 :=
  wSource (t := t_e1202690941046) (replay_sound (ps := []) (t := e1202690941046) (by decide)) (by decide)
def e1202690941290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202690941290 : Closed e1202690941290 ∧ code e1202690941290 = 5600737452394 := by decide
private def t_e1202690941290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202690941290 : ¬ IsSelfInterpreter e1202690941290 :=
  wSource (t := t_e1202690941290) (replay_sound (ps := []) (t := e1202690941290) (by decide)) (by decide)
def e1202690941338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202690941338 : Closed e1202690941338 ∧ code e1202690941338 = 5600737452442 := by decide
private def t_e1202690941338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202690941338 : ¬ IsSelfInterpreter e1202690941338 :=
  wSource (t := t_e1202690941338) (replay_sound (ps := []) (t := e1202690941338) (by decide)) (by decide)
def e1202699337754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202699337754 : Closed e1202699337754 ∧ code e1202699337754 = 5600745848858 := by decide
theorem cert_e1202699337754 : check e1202699337754 [[]] .width = true := by decide
def e1202699337846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202699337846 : Closed e1202699337846 ∧ code e1202699337846 = 5600745848950 := by decide
theorem cert_e1202699337846 : check e1202699337846 [[]] .width = true := by decide
def e1202699338090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202699338090 : Closed e1202699338090 ∧ code e1202699338090 = 5600745849194 := by decide
theorem cert_e1202699338090 : check e1202699338090 [[]] .width = true := by decide
def e1202699338138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202699338138 : Closed e1202699338138 ∧ code e1202699338138 = 5600745849242 := by decide
theorem cert_e1202699338138 : check e1202699338138 [[]] .width = true := by decide
def e1202699339146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202699339146 : Closed e1202699339146 ∧ code e1202699339146 = 5600745850250 := by decide
theorem cert_e1202699339146 : check e1202699339146 [[]] .width = true := by decide
def e1202699339170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202699339170 : Closed e1202699339170 ∧ code e1202699339170 = 5600745850274 := by decide
theorem cert_e1202699339170 : check e1202699339170 [[]] .width = true := by decide
def e1202699339278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202699339278 : Closed e1202699339278 ∧ code e1202699339278 = 5600745850382 := by decide
theorem cert_e1202699339278 : check e1202699339278 [[]] .width = true := by decide
def e1202699339290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202699339290 : Closed e1202699339290 ∧ code e1202699339290 = 5600745850394 := by decide
theorem cert_e1202699339290 : check e1202699339290 [[]] .width = true := by decide
def e1202699339362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202699339362 : Closed e1202699339362 ∧ code e1202699339362 = 5600745850466 := by decide
theorem cert_e1202699339362 : check e1202699339362 [[]] .width = true := by decide
def e1202699616454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202699616454 : Closed e1202699616454 ∧ code e1202699616454 = 5600746127558 := by decide
theorem cert_e1202699616454 : check e1202699616454 [[]] .width = true := by decide
def e1202699661510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202699661510 : Closed e1202699661510 ∧ code e1202699661510 = 5600746172614 := by decide
theorem cert_e1202699661510 : check e1202699661510 [[]] .width = true := by decide
def e1202699730970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202699730970 : Closed e1202699730970 ∧ code e1202699730970 = 5600746242074 := by decide
theorem cert_e1202699730970 : check e1202699730970 [[]] .width = true := by decide
def e1202699731062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202699731062 : Closed e1202699731062 ∧ code e1202699731062 = 5600746242166 := by decide
theorem cert_e1202699731062 : check e1202699731062 [[]] .width = true := by decide
def e1202699731306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202699731306 : Closed e1202699731306 ∧ code e1202699731306 = 5600746242410 := by decide
theorem cert_e1202699731306 : check e1202699731306 [[]] .width = true := by decide
def e1202699731354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202699731354 : Closed e1202699731354 ∧ code e1202699731354 = 5600746242458 := by decide
theorem cert_e1202699731354 : check e1202699731354 [[]] .width = true := by decide
def e1202699732362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202699732362 : Closed e1202699732362 ∧ code e1202699732362 = 5600746243466 := by decide
theorem cert_e1202699732362 : check e1202699732362 [[]] .width = true := by decide
def e1202699732386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202699732386 : Closed e1202699732386 ∧ code e1202699732386 = 5600746243490 := by decide
theorem cert_e1202699732386 : check e1202699732386 [[]] .width = true := by decide
def e1202699732494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202699732494 : Closed e1202699732494 ∧ code e1202699732494 = 5600746243598 := by decide
theorem cert_e1202699732494 : check e1202699732494 [[]] .width = true := by decide
def e1202699732506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202699732506 : Closed e1202699732506 ∧ code e1202699732506 = 5600746243610 := by decide
theorem cert_e1202699732506 : check e1202699732506 [[]] .width = true := by decide
def e1202699732578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202699732578 : Closed e1202699732578 ∧ code e1202699732578 = 5600746243682 := by decide
theorem cert_e1202699732578 : check e1202699732578 [[]] .width = true := by decide
def e1202699747526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202699747526 : Closed e1202699747526 ∧ code e1202699747526 = 5600746258630 := by decide
theorem cert_e1202699747526 : check e1202699747526 [[]] .width = true := by decide
def e1202711920666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202711920666 : Closed e1202711920666 ∧ code e1202711920666 = 5600758431770 := by decide
theorem cert_e1202711920666 : check e1202711920666 [[]] .width = true := by decide
def e1202711920758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202711920758 : Closed e1202711920758 ∧ code e1202711920758 = 5600758431862 := by decide
theorem cert_e1202711920758 : check e1202711920758 [[]] .width = true := by decide
def e1202711921002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202711921002 : Closed e1202711921002 ∧ code e1202711921002 = 5600758432106 := by decide
theorem cert_e1202711921002 : check e1202711921002 [[]] .width = true := by decide
def e1202711921050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202711921050 : Closed e1202711921050 ∧ code e1202711921050 = 5600758432154 := by decide
theorem cert_e1202711921050 : check e1202711921050 [[]] .width = true := by decide
def e1202711922058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202711922058 : Closed e1202711922058 ∧ code e1202711922058 = 5600758433162 := by decide
theorem cert_e1202711922058 : check e1202711922058 [[]] .width = true := by decide
def e1202711922082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202711922082 : Closed e1202711922082 ∧ code e1202711922082 = 5600758433186 := by decide
theorem cert_e1202711922082 : check e1202711922082 [[]] .width = true := by decide
def e1202711922190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202711922190 : Closed e1202711922190 ∧ code e1202711922190 = 5600758433294 := by decide
theorem cert_e1202711922190 : check e1202711922190 [[]] .width = true := by decide
def e1202711922202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202711922202 : Closed e1202711922202 ∧ code e1202711922202 = 5600758433306 := by decide
theorem cert_e1202711922202 : check e1202711922202 [[]] .width = true := by decide
def e1202711922274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202711922274 : Closed e1202711922274 ∧ code e1202711922274 = 5600758433378 := by decide
theorem cert_e1202711922274 : check e1202711922274 [[]] .width = true := by decide
def e1202712338458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202712338458 : Closed e1202712338458 ∧ code e1202712338458 = 5600758849562 := by decide
theorem cert_e1202712338458 : check e1202712338458 [[]] .width = true := by decide
def e1202712338550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202712338550 : Closed e1202712338550 ∧ code e1202712338550 = 5600758849654 := by decide
theorem cert_e1202712338550 : check e1202712338550 [[]] .width = true := by decide
def e1202712338794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202712338794 : Closed e1202712338794 ∧ code e1202712338794 = 5600758849898 := by decide
theorem cert_e1202712338794 : check e1202712338794 [[]] .width = true := by decide
def e1202712338842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202712338842 : Closed e1202712338842 ∧ code e1202712338842 = 5600758849946 := by decide
theorem cert_e1202712338842 : check e1202712338842 [[]] .width = true := by decide
def e1202712359110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202712359110 : Closed e1202712359110 ∧ code e1202712359110 = 5600758870214 := by decide
theorem cert_e1202712359110 : check e1202712359110 [[]] .width = true := by decide
def e1202712379418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202712379418 : Closed e1202712379418 ∧ code e1202712379418 = 5600758890522 := by decide
theorem cert_e1202712379418 : check e1202712379418 [[]] .width = true := by decide
def e1202712379510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202712379510 : Closed e1202712379510 ∧ code e1202712379510 = 5600758890614 := by decide
theorem cert_e1202712379510 : check e1202712379510 [[]] .width = true := by decide
def e1202712379754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202712379754 : Closed e1202712379754 ∧ code e1202712379754 = 5600758890858 := by decide
theorem cert_e1202712379754 : check e1202712379754 [[]] .width = true := by decide
def e1202712379802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202712379802 : Closed e1202712379802 ∧ code e1202712379802 = 5600758890906 := by decide
theorem cert_e1202712379802 : check e1202712379802 [[]] .width = true := by decide
def e1202712380810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202712380810 : Closed e1202712380810 ∧ code e1202712380810 = 5600758891914 := by decide
theorem cert_e1202712380810 : check e1202712380810 [[]] .width = true := by decide
def e1202712380834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202712380834 : Closed e1202712380834 ∧ code e1202712380834 = 5600758891938 := by decide
theorem cert_e1202712380834 : check e1202712380834 [[]] .width = true := by decide
def e1202712380942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202712380942 : Closed e1202712380942 ∧ code e1202712380942 = 5600758892046 := by decide
theorem cert_e1202712380942 : check e1202712380942 [[]] .width = true := by decide
def e1202712380954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202712380954 : Closed e1202712380954 ∧ code e1202712380954 = 5600758892058 := by decide
theorem cert_e1202712380954 : check e1202712380954 [[]] .width = true := by decide
def e1202712381026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202712381026 : Closed e1202712381026 ∧ code e1202712381026 = 5600758892130 := by decide
theorem cert_e1202712381026 : check e1202712381026 [[]] .width = true := by decide
def e1202712403994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202712403994 : Closed e1202712403994 ∧ code e1202712403994 = 5600758915098 := by decide
theorem cert_e1202712403994 : check e1202712403994 [[]] .width = true := by decide
def e1202712404086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202712404086 : Closed e1202712404086 ∧ code e1202712404086 = 5600758915190 := by decide
theorem cert_e1202712404086 : check e1202712404086 [[]] .width = true := by decide
def e1202712404330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202712404330 : Closed e1202712404330 ∧ code e1202712404330 = 5600758915434 := by decide
theorem cert_e1202712404330 : check e1202712404330 [[]] .width = true := by decide
def e1202712404378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202712404378 : Closed e1202712404378 ∧ code e1202712404378 = 5600758915482 := by decide
theorem cert_e1202712404378 : check e1202712404378 [[]] .width = true := by decide
def e1202718490822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202718490822 : Closed e1202718490822 ∧ code e1202718490822 = 5600765001926 := by decide
theorem cert_e1202718490822 : check e1202718490822 [[]] .width = true := by decide
def e1202718629914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202718629914 : Closed e1202718629914 ∧ code e1202718629914 = 5600765141018 := by decide
theorem cert_e1202718629914 : check e1202718629914 [[]] .width = true := by decide
def e1202718630006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202718630006 : Closed e1202718630006 ∧ code e1202718630006 = 5600765141110 := by decide
theorem cert_e1202718630006 : check e1202718630006 [[]] .width = true := by decide
def e1202718630250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202718630250 : Closed e1202718630250 ∧ code e1202718630250 = 5600765141354 := by decide
theorem cert_e1202718630250 : check e1202718630250 [[]] .width = true := by decide
def e1202718630298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202718630298 : Closed e1202718630298 ∧ code e1202718630298 = 5600765141402 := by decide
theorem cert_e1202718630298 : check e1202718630298 [[]] .width = true := by decide
def e1202718720198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202718720198 : Closed e1202718720198 ∧ code e1202718720198 = 5600765231302 := by decide
theorem cert_e1202718720198 : check e1202718720198 [[]] .width = true := by decide
def e1202718728218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202718728218 : Closed e1202718728218 ∧ code e1202718728218 = 5600765239322 := by decide
theorem cert_e1202718728218 : check e1202718728218 [[]] .width = true := by decide
def e1202718728310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202718728310 : Closed e1202718728310 ∧ code e1202718728310 = 5600765239414 := by decide
theorem cert_e1202718728310 : check e1202718728310 [[]] .width = true := by decide
def e1202718728554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202718728554 : Closed e1202718728554 ∧ code e1202718728554 = 5600765239658 := by decide
theorem cert_e1202718728554 : check e1202718728554 [[]] .width = true := by decide
def e1202718728602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202718728602 : Closed e1202718728602 ∧ code e1202718728602 = 5600765239706 := by decide
theorem cert_e1202718728602 : check e1202718728602 [[]] .width = true := by decide
def e1202721681606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202721681606 : Closed e1202721681606 ∧ code e1202721681606 = 5600768192710 := by decide
theorem cert_e1202721681606 : check e1202721681606 [[]] .width = true := by decide
def e1202721751066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202721751066 : Closed e1202721751066 ∧ code e1202721751066 = 5600768262170 := by decide
theorem cert_e1202721751066 : check e1202721751066 [[]] .width = true := by decide
def e1202721751158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202721751158 : Closed e1202721751158 ∧ code e1202721751158 = 5600768262262 := by decide
theorem cert_e1202721751158 : check e1202721751158 [[]] .width = true := by decide
def e1202721751402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202721751402 : Closed e1202721751402 ∧ code e1202721751402 = 5600768262506 := by decide
theorem cert_e1202721751402 : check e1202721751402 [[]] .width = true := by decide
def e1202721751450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202721751450 : Closed e1202721751450 ∧ code e1202721751450 = 5600768262554 := by decide
theorem cert_e1202721751450 : check e1202721751450 [[]] .width = true := by decide
def e1202721752458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202721752458 : Closed e1202721752458 ∧ code e1202721752458 = 5600768263562 := by decide
theorem cert_e1202721752458 : check e1202721752458 [[]] .width = true := by decide
def e1202721752482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202721752482 : Closed e1202721752482 ∧ code e1202721752482 = 5600768263586 := by decide
theorem cert_e1202721752482 : check e1202721752482 [[]] .width = true := by decide
def e1202721752590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202721752590 : Closed e1202721752590 ∧ code e1202721752590 = 5600768263694 := by decide
theorem cert_e1202721752590 : check e1202721752590 [[]] .width = true := by decide
def e1202721752602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202721752602 : Closed e1202721752602 ∧ code e1202721752602 = 5600768263706 := by decide
theorem cert_e1202721752602 : check e1202721752602 [[]] .width = true := by decide
def e1202721752674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202721752674 : Closed e1202721752674 ∧ code e1202721752674 = 5600768263778 := by decide
theorem cert_e1202721752674 : check e1202721752674 [[]] .width = true := by decide
def e1202721767622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202721767622 : Closed e1202721767622 ∧ code e1202721767622 = 5600768278726 := by decide
theorem cert_e1202721767622 : check e1202721767622 [[]] .width = true := by decide
def e1202721796294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202721796294 : Closed e1202721796294 ∧ code e1202721796294 = 5600768307398 := by decide
theorem cert_e1202721796294 : check e1202721796294 [[]] .width = true := by decide
def e1202721816602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202721816602 : Closed e1202721816602 ∧ code e1202721816602 = 5600768327706 := by decide
theorem cert_e1202721816602 : check e1202721816602 [[]] .width = true := by decide
def e1202721816694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202721816694 : Closed e1202721816694 ∧ code e1202721816694 = 5600768327798 := by decide
theorem cert_e1202721816694 : check e1202721816694 [[]] .width = true := by decide
def e1202721816938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202721816938 : Closed e1202721816938 ∧ code e1202721816938 = 5600768328042 := by decide
theorem cert_e1202721816938 : check e1202721816938 [[]] .width = true := by decide
def e1202721816986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202721816986 : Closed e1202721816986 ∧ code e1202721816986 = 5600768328090 := by decide
theorem cert_e1202721816986 : check e1202721816986 [[]] .width = true := by decide
def e1202721817994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202721817994 : Closed e1202721817994 ∧ code e1202721817994 = 5600768329098 := by decide
theorem cert_e1202721817994 : check e1202721817994 [[]] .width = true := by decide
def e1202721818018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202721818018 : Closed e1202721818018 ∧ code e1202721818018 = 5600768329122 := by decide
theorem cert_e1202721818018 : check e1202721818018 [[]] .width = true := by decide
def e1202721818126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202721818126 : Closed e1202721818126 ∧ code e1202721818126 = 5600768329230 := by decide
theorem cert_e1202721818126 : check e1202721818126 [[]] .width = true := by decide
def e1202721818138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202721818138 : Closed e1202721818138 ∧ code e1202721818138 = 5600768329242 := by decide
theorem cert_e1202721818138 : check e1202721818138 [[]] .width = true := by decide
def e1202721818210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202721818210 : Closed e1202721818210 ∧ code e1202721818210 = 5600768329314 := by decide
theorem cert_e1202721818210 : check e1202721818210 [[]] .width = true := by decide
def e1202721841178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202721841178 : Closed e1202721841178 ∧ code e1202721841178 = 5600768352282 := by decide
theorem cert_e1202721841178 : check e1202721841178 [[]] .width = true := by decide
def e1202721841270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202721841270 : Closed e1202721841270 ∧ code e1202721841270 = 5600768352374 := by decide
theorem cert_e1202721841270 : check e1202721841270 [[]] .width = true := by decide
def e1202721841514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202721841514 : Closed e1202721841514 ∧ code e1202721841514 = 5600768352618 := by decide
theorem cert_e1202721841514 : check e1202721841514 [[]] .width = true := by decide
def e1202721841562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202721841562 : Closed e1202721841562 ∧ code e1202721841562 = 5600768352666 := by decide
theorem cert_e1202721841562 : check e1202721841562 [[]] .width = true := by decide
def e1202721865926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202721865926 : Closed e1202721865926 ∧ code e1202721865926 = 5600768377030 := by decide
theorem cert_e1202721865926 : check e1202721865926 [[]] .width = true := by decide
def e1202721873946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202721873946 : Closed e1202721873946 ∧ code e1202721873946 = 5600768385050 := by decide
theorem cert_e1202721873946 : check e1202721873946 [[]] .width = true := by decide
def e1202721874038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202721874038 : Closed e1202721874038 ∧ code e1202721874038 = 5600768385142 := by decide
theorem cert_e1202721874038 : check e1202721874038 [[]] .width = true := by decide
def e1202721874282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202721874282 : Closed e1202721874282 ∧ code e1202721874282 = 5600768385386 := by decide
theorem cert_e1202721874282 : check e1202721874282 [[]] .width = true := by decide
def e1202721874330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202721874330 : Closed e1202721874330 ∧ code e1202721874330 = 5600768385434 := by decide
theorem cert_e1202721874330 : check e1202721874330 [[]] .width = true := by decide
def e1202842545518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1202842545518 : Closed e1202842545518 ∧ code e1202842545518 = 5600889056622 := by decide
theorem cert_e1202842545518 : check e1202842545518 [[],[]] .chain = true := by decide
def e1202842545526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1202842545526 : Closed e1202842545526 ∧ code e1202842545526 = 5600889056630 := by decide
theorem cert_e1202842545526 : check e1202842545526 [[],[]] .chain = true := by decide
def e1202842545582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1202842545582 : Closed e1202842545582 ∧ code e1202842545582 = 5600889056686 := by decide
theorem cert_e1202842545582 : check e1202842545582 [[],[]] .chain = true := by decide
def e1202842545594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1202842545594 : Closed e1202842545594 ∧ code e1202842545594 = 5600889056698 := by decide
theorem cert_e1202842545594 : check e1202842545594 [[],[]] .chain = true := by decide
def e1202842545622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1202842545622 : Closed e1202842545622 ∧ code e1202842545622 = 5600889056726 := by decide
theorem cert_e1202842545622 : check e1202842545622 [[],[]] .chain = true := by decide
def e1202842545626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1202842545626 : Closed e1202842545626 ∧ code e1202842545626 = 5600889056730 := by decide
theorem cert_e1202842545626 : check e1202842545626 [[],[]] .chain = true := by decide
def e1202842545838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1202842545838 : Closed e1202842545838 ∧ code e1202842545838 = 5600889056942 := by decide
theorem cert_e1202842545838 : check e1202842545838 [[],[]] .chain = true := by decide
def e1202842545850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1202842545850 : Closed e1202842545850 ∧ code e1202842545850 = 5600889056954 := by decide
theorem cert_e1202842545850 : check e1202842545850 [[],[]] .chain = true := by decide
def e1202842545898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1202842545898 : Closed e1202842545898 ∧ code e1202842545898 = 5600889057002 := by decide
theorem cert_e1202842545898 : check e1202842545898 [[],[]] .chain = true := by decide
def e1202842546006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1202842546006 : Closed e1202842546006 ∧ code e1202842546006 = 5600889057110 := by decide
theorem cert_e1202842546006 : check e1202842546006 [[],[]] .chain = true := by decide
def e1202842546010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1202842546010 : Closed e1202842546010 ∧ code e1202842546010 = 5600889057114 := by decide
theorem cert_e1202842546010 : check e1202842546010 [[],[]] .chain = true := by decide
def e1202842546026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1202842546026 : Closed e1202842546026 ∧ code e1202842546026 = 5600889057130 := by decide
theorem cert_e1202842546026 : check e1202842546026 [[],[]] .chain = true := by decide
def e1202842547054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1202842547054 : Closed e1202842547054 ∧ code e1202842547054 = 5600889058158 := by decide
theorem cert_e1202842547054 : check e1202842547054 [[],[]] .chain = true := by decide
def e1202842547062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1202842547062 : Closed e1202842547062 ∧ code e1202842547062 = 5600889058166 := by decide
theorem cert_e1202842547062 : check e1202842547062 [[],[]] .chain = true := by decide
def e1202842547118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1202842547118 : Closed e1202842547118 ∧ code e1202842547118 = 5600889058222 := by decide
theorem cert_e1202842547118 : check e1202842547118 [[],[]] .chain = true := by decide
def e1202842547130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1202842547130 : Closed e1202842547130 ∧ code e1202842547130 = 5600889058234 := by decide
theorem cert_e1202842547130 : check e1202842547130 [[],[]] .chain = true := by decide
def e1202842547158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1202842547158 : Closed e1202842547158 ∧ code e1202842547158 = 5600889058262 := by decide
theorem cert_e1202842547158 : check e1202842547158 [[],[]] .chain = true := by decide
def e1202842547162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1202842547162 : Closed e1202842547162 ∧ code e1202842547162 = 5600889058266 := by decide
theorem cert_e1202842547162 : check e1202842547162 [[],[]] .chain = true := by decide
def e1202842547438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1202842547438 : Closed e1202842547438 ∧ code e1202842547438 = 5600889058542 := by decide
theorem cert_e1202842547438 : check e1202842547438 [[],[]] .chain = true := by decide
def e1202842547446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1202842547446 : Closed e1202842547446 ∧ code e1202842547446 = 5600889058550 := by decide
theorem cert_e1202842547446 : check e1202842547446 [[],[]] .chain = true := by decide
def e1202842547822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1202842547822 : Closed e1202842547822 ∧ code e1202842547822 = 5600889058926 := by decide
theorem cert_e1202842547822 : check e1202842547822 [[],[]] .chain = true := by decide
def e1202842547834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1202842547834 : Closed e1202842547834 ∧ code e1202842547834 = 5600889058938 := by decide
theorem cert_e1202842547834 : check e1202842547834 [[],[]] .chain = true := by decide
def e1202842548022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1202842548022 : Closed e1202842548022 ∧ code e1202842548022 = 5600889059126 := by decide
theorem cert_e1202842548022 : check e1202842548022 [[],[]] .chain = true := by decide
def e1202842548026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1202842548026 : Closed e1202842548026 ∧ code e1202842548026 = 5600889059130 := by decide
theorem cert_e1202842548026 : check e1202842548026 [[],[]] .chain = true := by decide
def e1202842548654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1202842548654 : Closed e1202842548654 ∧ code e1202842548654 = 5600889059758 := by decide
theorem cert_e1202842548654 : check e1202842548654 [[],[]] .chain = true := by decide
def e1202842548666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1202842548666 : Closed e1202842548666 ∧ code e1202842548666 = 5600889059770 := by decide
theorem cert_e1202842548666 : check e1202842548666 [[],[]] .chain = true := by decide
def e1202842548714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1202842548714 : Closed e1202842548714 ∧ code e1202842548714 = 5600889059818 := by decide
theorem cert_e1202842548714 : check e1202842548714 [[],[]] .chain = true := by decide
def e1202842548846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1202842548846 : Closed e1202842548846 ∧ code e1202842548846 = 5600889059950 := by decide
theorem cert_e1202842548846 : check e1202842548846 [[],[]] .chain = true := by decide
def e1202842548858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1202842548858 : Closed e1202842548858 ∧ code e1202842548858 = 5600889059962 := by decide
theorem cert_e1202842548858 : check e1202842548858 [[],[]] .chain = true := by decide
def e1202842549146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1202842549146 : Closed e1202842549146 ∧ code e1202842549146 = 5600889060250 := by decide
theorem cert_e1202842549146 : check e1202842549146 [[],[]] .chain = true := by decide
def e1202842549462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1202842549462 : Closed e1202842549462 ∧ code e1202842549462 = 5600889060566 := by decide
theorem cert_e1202842549462 : check e1202842549462 [[],[]] .chain = true := by decide
def e1202842549466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1202842549466 : Closed e1202842549466 ∧ code e1202842549466 = 5600889060570 := by decide
theorem cert_e1202842549466 : check e1202842549466 [[],[]] .chain = true := by decide
def e1202842549482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1202842549482 : Closed e1202842549482 ∧ code e1202842549482 = 5600889060586 := by decide
theorem cert_e1202842549482 : check e1202842549482 [[],[]] .chain = true := by decide
def e1202842549558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1202842549558 : Closed e1202842549558 ∧ code e1202842549558 = 5600889060662 := by decide
theorem cert_e1202842549558 : check e1202842549558 [[],[]] .chain = true := by decide
def e1202842549562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1202842549562 : Closed e1202842549562 ∧ code e1202842549562 = 5600889060666 := by decide
theorem cert_e1202842549562 : check e1202842549562 [[],[]] .chain = true := by decide
def e1202842549658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1202842549658 : Closed e1202842549658 ∧ code e1202842549658 = 5600889060762 := by decide
theorem cert_e1202842549658 : check e1202842549658 [[],[]] .chain = true := by decide
def e1202842553198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1202842553198 : Closed e1202842553198 ∧ code e1202842553198 = 5600889064302 := by decide
theorem cert_e1202842553198 : check e1202842553198 [[],[]] .chain = true := by decide
def e1202842553206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1202842553206 : Closed e1202842553206 ∧ code e1202842553206 = 5600889064310 := by decide
theorem cert_e1202842553206 : check e1202842553206 [[],[]] .chain = true := by decide
def e1202842553262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1202842553262 : Closed e1202842553262 ∧ code e1202842553262 = 5600889064366 := by decide
theorem cert_e1202842553262 : check e1202842553262 [[],[]] .chain = true := by decide
def e1202842553274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1202842553274 : Closed e1202842553274 ∧ code e1202842553274 = 5600889064378 := by decide
theorem cert_e1202842553274 : check e1202842553274 [[],[]] .chain = true := by decide
def e1202842553302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1202842553302 : Closed e1202842553302 ∧ code e1202842553302 = 5600889064406 := by decide
theorem cert_e1202842553302 : check e1202842553302 [[],[]] .chain = true := by decide
def e1202842553306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1202842553306 : Closed e1202842553306 ∧ code e1202842553306 = 5600889064410 := by decide
theorem cert_e1202842553306 : check e1202842553306 [[],[]] .chain = true := by decide
def e1202842553582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1202842553582 : Closed e1202842553582 ∧ code e1202842553582 = 5600889064686 := by decide
theorem cert_e1202842553582 : check e1202842553582 [[],[]] .chain = true := by decide
def e1202842553590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1202842553590 : Closed e1202842553590 ∧ code e1202842553590 = 5600889064694 := by decide
theorem cert_e1202842553590 : check e1202842553590 [[],[]] .chain = true := by decide
def e1202842553966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1202842553966 : Closed e1202842553966 ∧ code e1202842553966 = 5600889065070 := by decide
theorem cert_e1202842553966 : check e1202842553966 [[],[]] .chain = true := by decide
def e1202842553978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1202842553978 : Closed e1202842553978 ∧ code e1202842553978 = 5600889065082 := by decide
theorem cert_e1202842553978 : check e1202842553978 [[],[]] .chain = true := by decide
def e1202842554166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1202842554166 : Closed e1202842554166 ∧ code e1202842554166 = 5600889065270 := by decide
theorem cert_e1202842554166 : check e1202842554166 [[],[]] .chain = true := by decide
def e1202842554170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1202842554170 : Closed e1202842554170 ∧ code e1202842554170 = 5600889065274 := by decide
theorem cert_e1202842554170 : check e1202842554170 [[],[]] .chain = true := by decide
def e1202842559918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1202842559918 : Closed e1202842559918 ∧ code e1202842559918 = 5600889071022 := by decide
theorem cert_e1202842559918 : check e1202842559918 [[],[]] .chain = true := by decide
def e1202842559930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1202842559930 : Closed e1202842559930 ∧ code e1202842559930 = 5600889071034 := by decide
theorem cert_e1202842559930 : check e1202842559930 [[],[]] .chain = true := by decide
def e1202842559978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1202842559978 : Closed e1202842559978 ∧ code e1202842559978 = 5600889071082 := by decide
theorem cert_e1202842559978 : check e1202842559978 [[],[]] .chain = true := by decide
def e1202842560110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1202842560110 : Closed e1202842560110 ∧ code e1202842560110 = 5600889071214 := by decide
theorem cert_e1202842560110 : check e1202842560110 [[],[]] .chain = true := by decide
def e1202842560122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1202842560122 : Closed e1202842560122 ∧ code e1202842560122 = 5600889071226 := by decide
theorem cert_e1202842560122 : check e1202842560122 [[],[]] .chain = true := by decide
def e1202842560410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1202842560410 : Closed e1202842560410 ∧ code e1202842560410 = 5600889071514 := by decide
theorem cert_e1202842560410 : check e1202842560410 [[],[]] .chain = true := by decide
def e1202842563286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1202842563286 : Closed e1202842563286 ∧ code e1202842563286 = 5600889074390 := by decide
theorem cert_e1202842563286 : check e1202842563286 [[],[]] .chain = true := by decide
def e1202842563290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1202842563290 : Closed e1202842563290 ∧ code e1202842563290 = 5600889074394 := by decide
theorem cert_e1202842563290 : check e1202842563290 [[],[]] .chain = true := by decide
def e1202842563306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1202842563306 : Closed e1202842563306 ∧ code e1202842563306 = 5600889074410 := by decide
theorem cert_e1202842563306 : check e1202842563306 [[],[]] .chain = true := by decide
def e1202842563382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1202842563382 : Closed e1202842563382 ∧ code e1202842563382 = 5600889074486 := by decide
theorem cert_e1202842563382 : check e1202842563382 [[],[]] .chain = true := by decide
def e1202842563386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1202842563386 : Closed e1202842563386 ∧ code e1202842563386 = 5600889074490 := by decide
theorem cert_e1202842563386 : check e1202842563386 [[],[]] .chain = true := by decide
def e1202842563482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1202842563482 : Closed e1202842563482 ∧ code e1202842563482 = 5600889074586 := by decide
theorem cert_e1202842563482 : check e1202842563482 [[],[]] .chain = true := by decide
end Blc.Floor42
