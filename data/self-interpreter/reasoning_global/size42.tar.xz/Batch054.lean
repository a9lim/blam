import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1130566298990 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1130566298990 : Closed e1130566298990 ∧ code e1130566298990 = 5528612810094 := by decide
theorem cert_e1130566298990 : check e1130566298990 [[],[.under]] .three = true := by decide
def e1130566298998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1130566298998 : Closed e1130566298998 ∧ code e1130566298998 = 5528612810102 := by decide
theorem cert_e1130566298998 : check e1130566298998 [[],[.under]] .three = true := by decide
def e1130566299054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1130566299054 : Closed e1130566299054 ∧ code e1130566299054 = 5528612810158 := by decide
theorem cert_e1130566299054 : check e1130566299054 [[],[.under]] .three = true := by decide
def e1130566299066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1130566299066 : Closed e1130566299066 ∧ code e1130566299066 = 5528612810170 := by decide
theorem cert_e1130566299066 : check e1130566299066 [[],[.under]] .three = true := by decide
def e1130566299094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1130566299094 : Closed e1130566299094 ∧ code e1130566299094 = 5528612810198 := by decide
theorem cert_e1130566299094 : check e1130566299094 [[],[.under]] .three = true := by decide
def e1130566299098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1130566299098 : Closed e1130566299098 ∧ code e1130566299098 = 5528612810202 := by decide
theorem cert_e1130566299098 : check e1130566299098 [[],[.under]] .three = true := by decide
def e1130566299310 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1130566299310 : Closed e1130566299310 ∧ code e1130566299310 = 5528612810414 := by decide
theorem cert_e1130566299310 : check e1130566299310 [[],[.under]] .three = true := by decide
def e1130566299322 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1130566299322 : Closed e1130566299322 ∧ code e1130566299322 = 5528612810426 := by decide
theorem cert_e1130566299322 : check e1130566299322 [[],[.under]] .three = true := by decide
def e1130566299370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1130566299370 : Closed e1130566299370 ∧ code e1130566299370 = 5528612810474 := by decide
theorem cert_e1130566299370 : check e1130566299370 [[],[.under]] .three = true := by decide
def e1130566299478 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1130566299478 : Closed e1130566299478 ∧ code e1130566299478 = 5528612810582 := by decide
theorem cert_e1130566299478 : check e1130566299478 [[],[.under]] .three = true := by decide
def e1130566299482 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1130566299482 : Closed e1130566299482 ∧ code e1130566299482 = 5528612810586 := by decide
theorem cert_e1130566299482 : check e1130566299482 [[],[.under]] .three = true := by decide
def e1130566299498 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1130566299498 : Closed e1130566299498 ∧ code e1130566299498 = 5528612810602 := by decide
theorem cert_e1130566299498 : check e1130566299498 [[],[.under]] .three = true := by decide
def e1130566300526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1130566300526 : Closed e1130566300526 ∧ code e1130566300526 = 5528612811630 := by decide
theorem cert_e1130566300526 : check e1130566300526 [[],[.under]] .three = true := by decide
def e1130566300534 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1130566300534 : Closed e1130566300534 ∧ code e1130566300534 = 5528612811638 := by decide
theorem cert_e1130566300534 : check e1130566300534 [[],[.under]] .three = true := by decide
def e1130566300590 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1130566300590 : Closed e1130566300590 ∧ code e1130566300590 = 5528612811694 := by decide
theorem cert_e1130566300590 : check e1130566300590 [[],[.under]] .three = true := by decide
def e1130566300602 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1130566300602 : Closed e1130566300602 ∧ code e1130566300602 = 5528612811706 := by decide
theorem cert_e1130566300602 : check e1130566300602 [[],[.under]] .three = true := by decide
def e1130566300630 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1130566300630 : Closed e1130566300630 ∧ code e1130566300630 = 5528612811734 := by decide
theorem cert_e1130566300630 : check e1130566300630 [[],[.under]] .three = true := by decide
def e1130566300634 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1130566300634 : Closed e1130566300634 ∧ code e1130566300634 = 5528612811738 := by decide
theorem cert_e1130566300634 : check e1130566300634 [[],[.under]] .three = true := by decide
def e1130566300910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130566300910 : Closed e1130566300910 ∧ code e1130566300910 = 5528612812014 := by decide
theorem cert_e1130566300910 : check e1130566300910 [[],[.under]] .three = true := by decide
def e1130566300918 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130566300918 : Closed e1130566300918 ∧ code e1130566300918 = 5528612812022 := by decide
theorem cert_e1130566300918 : check e1130566300918 [[],[.under]] .three = true := by decide
def e1130566301294 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130566301294 : Closed e1130566301294 ∧ code e1130566301294 = 5528612812398 := by decide
theorem cert_e1130566301294 : check e1130566301294 [[],[.under]] .three = true := by decide
def e1130566301306 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130566301306 : Closed e1130566301306 ∧ code e1130566301306 = 5528612812410 := by decide
theorem cert_e1130566301306 : check e1130566301306 [[],[.under]] .three = true := by decide
def e1130566301494 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130566301494 : Closed e1130566301494 ∧ code e1130566301494 = 5528612812598 := by decide
theorem cert_e1130566301494 : check e1130566301494 [[],[.under]] .three = true := by decide
def e1130566301498 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130566301498 : Closed e1130566301498 ∧ code e1130566301498 = 5528612812602 := by decide
theorem cert_e1130566301498 : check e1130566301498 [[],[.under]] .three = true := by decide
def e1130566302126 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1130566302126 : Closed e1130566302126 ∧ code e1130566302126 = 5528612813230 := by decide
theorem cert_e1130566302126 : check e1130566302126 [[],[.under]] .three = true := by decide
def e1130566302138 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1130566302138 : Closed e1130566302138 ∧ code e1130566302138 = 5528612813242 := by decide
theorem cert_e1130566302138 : check e1130566302138 [[],[.under]] .three = true := by decide
def e1130566302186 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1130566302186 : Closed e1130566302186 ∧ code e1130566302186 = 5528612813290 := by decide
theorem cert_e1130566302186 : check e1130566302186 [[],[.under]] .three = true := by decide
def e1130566302318 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130566302318 : Closed e1130566302318 ∧ code e1130566302318 = 5528612813422 := by decide
theorem cert_e1130566302318 : check e1130566302318 [[],[.under]] .three = true := by decide
def e1130566302330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130566302330 : Closed e1130566302330 ∧ code e1130566302330 = 5528612813434 := by decide
theorem cert_e1130566302330 : check e1130566302330 [[],[.under]] .three = true := by decide
def e1130566302618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1130566302618 : Closed e1130566302618 ∧ code e1130566302618 = 5528612813722 := by decide
theorem cert_e1130566302618 : check e1130566302618 [[],[.under]] .three = true := by decide
def e1130566302934 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1130566302934 : Closed e1130566302934 ∧ code e1130566302934 = 5528612814038 := by decide
theorem cert_e1130566302934 : check e1130566302934 [[],[.under]] .three = true := by decide
def e1130566302938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1130566302938 : Closed e1130566302938 ∧ code e1130566302938 = 5528612814042 := by decide
theorem cert_e1130566302938 : check e1130566302938 [[],[.under]] .three = true := by decide
def e1130566302954 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1130566302954 : Closed e1130566302954 ∧ code e1130566302954 = 5528612814058 := by decide
theorem cert_e1130566302954 : check e1130566302954 [[],[.under]] .three = true := by decide
def e1130566303030 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130566303030 : Closed e1130566303030 ∧ code e1130566303030 = 5528612814134 := by decide
theorem cert_e1130566303030 : check e1130566303030 [[],[.under]] .three = true := by decide
def e1130566303034 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130566303034 : Closed e1130566303034 ∧ code e1130566303034 = 5528612814138 := by decide
theorem cert_e1130566303034 : check e1130566303034 [[],[.under]] .three = true := by decide
def e1130566303130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1130566303130 : Closed e1130566303130 ∧ code e1130566303130 = 5528612814234 := by decide
theorem cert_e1130566303130 : check e1130566303130 [[],[.under]] .three = true := by decide
def e1130566306670 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130566306670 : Closed e1130566306670 ∧ code e1130566306670 = 5528612817774 := by decide
theorem cert_e1130566306670 : check e1130566306670 [[],[.under]] .three = true := by decide
def e1130566306678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130566306678 : Closed e1130566306678 ∧ code e1130566306678 = 5528612817782 := by decide
theorem cert_e1130566306678 : check e1130566306678 [[],[.under]] .three = true := by decide
def e1130566306734 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130566306734 : Closed e1130566306734 ∧ code e1130566306734 = 5528612817838 := by decide
theorem cert_e1130566306734 : check e1130566306734 [[],[.under]] .three = true := by decide
def e1130566306746 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130566306746 : Closed e1130566306746 ∧ code e1130566306746 = 5528612817850 := by decide
theorem cert_e1130566306746 : check e1130566306746 [[],[.under]] .three = true := by decide
def e1130566306774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130566306774 : Closed e1130566306774 ∧ code e1130566306774 = 5528612817878 := by decide
theorem cert_e1130566306774 : check e1130566306774 [[],[.under]] .three = true := by decide
def e1130566306778 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130566306778 : Closed e1130566306778 ∧ code e1130566306778 = 5528612817882 := by decide
theorem cert_e1130566306778 : check e1130566306778 [[],[.under]] .three = true := by decide
def e1130566307054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130566307054 : Closed e1130566307054 ∧ code e1130566307054 = 5528612818158 := by decide
theorem cert_e1130566307054 : check e1130566307054 [[],[.under]] .three = true := by decide
def e1130566307062 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130566307062 : Closed e1130566307062 ∧ code e1130566307062 = 5528612818166 := by decide
theorem cert_e1130566307062 : check e1130566307062 [[],[.under]] .three = true := by decide
def e1130566307438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130566307438 : Closed e1130566307438 ∧ code e1130566307438 = 5528612818542 := by decide
theorem cert_e1130566307438 : check e1130566307438 [[],[.under]] .three = true := by decide
def e1130566307450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130566307450 : Closed e1130566307450 ∧ code e1130566307450 = 5528612818554 := by decide
theorem cert_e1130566307450 : check e1130566307450 [[],[.under]] .three = true := by decide
def e1130566307638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130566307638 : Closed e1130566307638 ∧ code e1130566307638 = 5528612818742 := by decide
theorem cert_e1130566307638 : check e1130566307638 [[],[.under]] .three = true := by decide
def e1130566307642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130566307642 : Closed e1130566307642 ∧ code e1130566307642 = 5528612818746 := by decide
theorem cert_e1130566307642 : check e1130566307642 [[],[.under]] .three = true := by decide
def e1130566313390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1130566313390 : Closed e1130566313390 ∧ code e1130566313390 = 5528612824494 := by decide
theorem cert_e1130566313390 : check e1130566313390 [[],[.under]] .three = true := by decide
def e1130566313402 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1130566313402 : Closed e1130566313402 ∧ code e1130566313402 = 5528612824506 := by decide
theorem cert_e1130566313402 : check e1130566313402 [[],[.under]] .three = true := by decide
def e1130566313450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1130566313450 : Closed e1130566313450 ∧ code e1130566313450 = 5528612824554 := by decide
theorem cert_e1130566313450 : check e1130566313450 [[],[.under]] .three = true := by decide
def e1130566313582 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1130566313582 : Closed e1130566313582 ∧ code e1130566313582 = 5528612824686 := by decide
theorem cert_e1130566313582 : check e1130566313582 [[],[.under]] .three = true := by decide
def e1130566313594 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1130566313594 : Closed e1130566313594 ∧ code e1130566313594 = 5528612824698 := by decide
theorem cert_e1130566313594 : check e1130566313594 [[],[.under]] .three = true := by decide
def e1130566313882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1130566313882 : Closed e1130566313882 ∧ code e1130566313882 = 5528612824986 := by decide
theorem cert_e1130566313882 : check e1130566313882 [[],[.under]] .three = true := by decide
def e1130566316758 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1130566316758 : Closed e1130566316758 ∧ code e1130566316758 = 5528612827862 := by decide
theorem cert_e1130566316758 : check e1130566316758 [[],[.under]] .three = true := by decide
def e1130566316762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1130566316762 : Closed e1130566316762 ∧ code e1130566316762 = 5528612827866 := by decide
theorem cert_e1130566316762 : check e1130566316762 [[],[.under]] .three = true := by decide
def e1130566316778 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1130566316778 : Closed e1130566316778 ∧ code e1130566316778 = 5528612827882 := by decide
theorem cert_e1130566316778 : check e1130566316778 [[],[.under]] .three = true := by decide
def e1130566316854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1130566316854 : Closed e1130566316854 ∧ code e1130566316854 = 5528612827958 := by decide
theorem cert_e1130566316854 : check e1130566316854 [[],[.under]] .three = true := by decide
def e1130566316858 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1130566316858 : Closed e1130566316858 ∧ code e1130566316858 = 5528612827962 := by decide
theorem cert_e1130566316858 : check e1130566316858 [[],[.under]] .three = true := by decide
def e1130566316954 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1130566316954 : Closed e1130566316954 ∧ code e1130566316954 = 5528612828058 := by decide
theorem cert_e1130566316954 : check e1130566316954 [[],[.under]] .three = true := by decide
def e1130566454126 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130566454126 : Closed e1130566454126 ∧ code e1130566454126 = 5528612965230 := by decide
theorem cert_e1130566454126 : check e1130566454126 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566454134 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130566454134 : Closed e1130566454134 ∧ code e1130566454134 = 5528612965238 := by decide
theorem cert_e1130566454134 : check e1130566454134 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566454190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130566454190 : Closed e1130566454190 ∧ code e1130566454190 = 5528612965294 := by decide
theorem cert_e1130566454190 : check e1130566454190 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1130566454202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130566454202 : Closed e1130566454202 ∧ code e1130566454202 = 5528612965306 := by decide
theorem cert_e1130566454202 : check e1130566454202 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566454230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130566454230 : Closed e1130566454230 ∧ code e1130566454230 = 5528612965334 := by decide
theorem cert_e1130566454230 : check e1130566454230 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[.under,.under,.left]] .identityHead = true := by decide
def e1130566454234 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130566454234 : Closed e1130566454234 ∧ code e1130566454234 = 5528612965338 := by decide
theorem cert_e1130566454234 : check e1130566454234 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566454510 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130566454510 : Closed e1130566454510 ∧ code e1130566454510 = 5528612965614 := by decide
theorem cert_e1130566454510 : check e1130566454510 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1130566454518 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130566454518 : Closed e1130566454518 ∧ code e1130566454518 = 5528612965622 := by decide
theorem cert_e1130566454518 : check e1130566454518 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[.left],[],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e1130566454894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130566454894 : Closed e1130566454894 ∧ code e1130566454894 = 5528612965998 := by decide
theorem cert_e1130566454894 : check e1130566454894 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566454906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130566454906 : Closed e1130566454906 ∧ code e1130566454906 = 5528612966010 := by decide
theorem cert_e1130566454906 : check e1130566454906 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1130566455094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130566455094 : Closed e1130566455094 ∧ code e1130566455094 = 5528612966198 := by decide
theorem cert_e1130566455094 : check e1130566455094 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1130566455098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130566455098 : Closed e1130566455098 ∧ code e1130566455098 = 5528612966202 := by decide
theorem cert_e1130566455098 : check e1130566455098 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1130567043950 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130567043950 : Closed e1130567043950 ∧ code e1130567043950 = 5528613555054 := by decide
def e1130567043958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130567043958 : Closed e1130567043958 ∧ code e1130567043958 = 5528613555062 := by decide
def e1130567044014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130567044014 : Closed e1130567044014 ∧ code e1130567044014 = 5528613555118 := by decide
def e1130567044026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130567044026 : Closed e1130567044026 ∧ code e1130567044026 = 5528613555130 := by decide
private def t_e1130567044026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e1130567044026 : ¬ IsSelfInterpreter e1130567044026 :=
  wSource (t := t_e1130567044026) (replay_sound (ps := []) (t := e1130567044026) (by decide)) (by decide)
def e1130567044054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130567044054 : Closed e1130567044054 ∧ code e1130567044054 = 5528613555158 := by decide
def e1130567044058 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130567044058 : Closed e1130567044058 ∧ code e1130567044058 = 5528613555162 := by decide
private def t_e1130567044058 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e1130567044058 : ¬ IsSelfInterpreter e1130567044058 :=
  wSource (t := t_e1130567044058) (replay_sound (ps := []) (t := e1130567044058) (by decide)) (by decide)
def e1130567044334 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130567044334 : Closed e1130567044334 ∧ code e1130567044334 = 5528613555438 := by decide
def e1130567044342 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130567044342 : Closed e1130567044342 ∧ code e1130567044342 = 5528613555446 := by decide
def e1130567044718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130567044718 : Closed e1130567044718 ∧ code e1130567044718 = 5528613555822 := by decide
theorem cert_e1130567044718 : check e1130567044718 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1130567044730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130567044730 : Closed e1130567044730 ∧ code e1130567044730 = 5528613555834 := by decide
theorem cert_e1130567044730 : check e1130567044730 [[],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1130567044918 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130567044918 : Closed e1130567044918 ∧ code e1130567044918 = 5528613556022 := by decide
def e1130567044922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130567044922 : Closed e1130567044922 ∧ code e1130567044922 = 5528613556026 := by decide
def e1131187100382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1131187100382 : Closed e1131187100382 ∧ code e1131187100382 = 5529233611486 := by decide
theorem cert_e1131187100382 : check e1131187100382 [[],[.under]] .smaller = true := by decide
def e1131187100406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1131187100406 : Closed e1131187100406 ∧ code e1131187100406 = 5529233611510 := by decide
theorem cert_e1131187100406 : check e1131187100406 [[],[.under]] .smaller = true := by decide
def e1131187100510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1131187100510 : Closed e1131187100510 ∧ code e1131187100510 = 5529233611614 := by decide
theorem cert_e1131187100510 : check e1131187100510 [[],[.under]] .smaller = true := by decide
def e1131187100526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1131187100526 : Closed e1131187100526 ∧ code e1131187100526 = 5529233611630 := by decide
theorem cert_e1131187100526 : check e1131187100526 [[],[.under]] .smaller = true := by decide
def e1131187100534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1131187100534 : Closed e1131187100534 ∧ code e1131187100534 = 5529233611638 := by decide
theorem cert_e1131187100534 : check e1131187100534 [[],[.under]] .smaller = true := by decide
def e1131187100538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1131187100538 : Closed e1131187100538 ∧ code e1131187100538 = 5529233611642 := by decide
theorem cert_e1131187100538 : check e1131187100538 [[],[.under]] .smaller = true := by decide
def e1131187100598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1131187100598 : Closed e1131187100598 ∧ code e1131187100598 = 5529233611702 := by decide
theorem cert_e1131187100598 : check e1131187100598 [[],[.under]] .smaller = true := by decide
def e1131187100630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1131187100630 : Closed e1131187100630 ∧ code e1131187100630 = 5529233611734 := by decide
theorem cert_e1131187100630 : check e1131187100630 [[],[.under]] .smaller = true := by decide
def e1131187100634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1131187100634 : Closed e1131187100634 ∧ code e1131187100634 = 5529233611738 := by decide
theorem cert_e1131187100634 : check e1131187100634 [[],[.under]] .smaller = true := by decide
def e1131187101022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1131187101022 : Closed e1131187101022 ∧ code e1131187101022 = 5529233612126 := by decide
theorem cert_e1131187101022 : check e1131187101022 [[],[.under]] .smaller = true := by decide
def e1131187101038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1131187101038 : Closed e1131187101038 ∧ code e1131187101038 = 5529233612142 := by decide
theorem cert_e1131187101038 : check e1131187101038 [[],[.under]] .smaller = true := by decide
def e1131187101046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1131187101046 : Closed e1131187101046 ∧ code e1131187101046 = 5529233612150 := by decide
theorem cert_e1131187101046 : check e1131187101046 [[],[.under]] .smaller = true := by decide
def e1131187101050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1131187101050 : Closed e1131187101050 ∧ code e1131187101050 = 5529233612154 := by decide
theorem cert_e1131187101050 : check e1131187101050 [[],[.under]] .smaller = true := by decide
def e1131187101102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1131187101102 : Closed e1131187101102 ∧ code e1131187101102 = 5529233612206 := by decide
theorem cert_e1131187101102 : check e1131187101102 [[],[.under]] .smaller = true := by decide
def e1131187101114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1131187101114 : Closed e1131187101114 ∧ code e1131187101114 = 5529233612218 := by decide
theorem cert_e1131187101114 : check e1131187101114 [[],[.under]] .smaller = true := by decide
def e1131187101142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1131187101142 : Closed e1131187101142 ∧ code e1131187101142 = 5529233612246 := by decide
theorem cert_e1131187101142 : check e1131187101142 [[],[.under]] .smaller = true := by decide
def e1131187101146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1131187101146 : Closed e1131187101146 ∧ code e1131187101146 = 5529233612250 := by decide
theorem cert_e1131187101146 : check e1131187101146 [[],[.under]] .smaller = true := by decide
def e1131187101162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1131187101162 : Closed e1131187101162 ∧ code e1131187101162 = 5529233612266 := by decide
theorem cert_e1131187101162 : check e1131187101162 [[],[.under]] .smaller = true := by decide
def e1131187101366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1131187101366 : Closed e1131187101366 ∧ code e1131187101366 = 5529233612470 := by decide
theorem cert_e1131187101366 : check e1131187101366 [[],[.under]] .smaller = true := by decide
def e1131187101398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1131187101398 : Closed e1131187101398 ∧ code e1131187101398 = 5529233612502 := by decide
theorem cert_e1131187101398 : check e1131187101398 [[],[.under]] .smaller = true := by decide
def e1131187101402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1131187101402 : Closed e1131187101402 ∧ code e1131187101402 = 5529233612506 := by decide
theorem cert_e1131187101402 : check e1131187101402 [[],[.under]] .smaller = true := by decide
def e1131187101526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1131187101526 : Closed e1131187101526 ∧ code e1131187101526 = 5529233612630 := by decide
theorem cert_e1131187101526 : check e1131187101526 [[],[.under]] .smaller = true := by decide
def e1131187101530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1131187101530 : Closed e1131187101530 ∧ code e1131187101530 = 5529233612634 := by decide
theorem cert_e1131187101530 : check e1131187101530 [[],[.under]] .smaller = true := by decide
def e1131187101546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1131187101546 : Closed e1131187101546 ∧ code e1131187101546 = 5529233612650 := by decide
theorem cert_e1131187101546 : check e1131187101546 [[],[.under]] .smaller = true := by decide
def e1131187103454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1131187103454 : Closed e1131187103454 ∧ code e1131187103454 = 5529233614558 := by decide
theorem cert_e1131187103454 : check e1131187103454 [[],[.under]] .smaller = true := by decide
def e1131187103478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1131187103478 : Closed e1131187103478 ∧ code e1131187103478 = 5529233614582 := by decide
theorem cert_e1131187103478 : check e1131187103478 [[],[.under]] .smaller = true := by decide
def e1131187103582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1131187103582 : Closed e1131187103582 ∧ code e1131187103582 = 5529233614686 := by decide
theorem cert_e1131187103582 : check e1131187103582 [[],[.under]] .smaller = true := by decide
def e1131187103598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1131187103598 : Closed e1131187103598 ∧ code e1131187103598 = 5529233614702 := by decide
theorem cert_e1131187103598 : check e1131187103598 [[],[.under]] .smaller = true := by decide
def e1131187103606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1131187103606 : Closed e1131187103606 ∧ code e1131187103606 = 5529233614710 := by decide
theorem cert_e1131187103606 : check e1131187103606 [[],[.under]] .smaller = true := by decide
def e1131187103610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1131187103610 : Closed e1131187103610 ∧ code e1131187103610 = 5529233614714 := by decide
theorem cert_e1131187103610 : check e1131187103610 [[],[.under]] .smaller = true := by decide
def e1131187103670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1131187103670 : Closed e1131187103670 ∧ code e1131187103670 = 5529233614774 := by decide
theorem cert_e1131187103670 : check e1131187103670 [[],[.under]] .smaller = true := by decide
def e1131187103702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1131187103702 : Closed e1131187103702 ∧ code e1131187103702 = 5529233614806 := by decide
theorem cert_e1131187103702 : check e1131187103702 [[],[.under]] .smaller = true := by decide
def e1131187103706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1131187103706 : Closed e1131187103706 ∧ code e1131187103706 = 5529233614810 := by decide
theorem cert_e1131187103706 : check e1131187103706 [[],[.under]] .smaller = true := by decide
def e1131187104222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131187104222 : Closed e1131187104222 ∧ code e1131187104222 = 5529233615326 := by decide
theorem cert_e1131187104222 : check e1131187104222 [[],[.under]] .smaller = true := by decide
def e1131187104246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131187104246 : Closed e1131187104246 ∧ code e1131187104246 = 5529233615350 := by decide
theorem cert_e1131187104246 : check e1131187104246 [[],[.under]] .smaller = true := by decide
def e1131187104990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1131187104990 : Closed e1131187104990 ∧ code e1131187104990 = 5529233616094 := by decide
theorem cert_e1131187104990 : check e1131187104990 [[],[.under]] .smaller = true := by decide
def e1131187105006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131187105006 : Closed e1131187105006 ∧ code e1131187105006 = 5529233616110 := by decide
theorem cert_e1131187105006 : check e1131187105006 [[],[.under]] .smaller = true := by decide
def e1131187105014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131187105014 : Closed e1131187105014 ∧ code e1131187105014 = 5529233616118 := by decide
theorem cert_e1131187105014 : check e1131187105014 [[],[.under]] .smaller = true := by decide
def e1131187105018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1131187105018 : Closed e1131187105018 ∧ code e1131187105018 = 5529233616122 := by decide
theorem cert_e1131187105018 : check e1131187105018 [[],[.under]] .smaller = true := by decide
def e1131187105398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131187105398 : Closed e1131187105398 ∧ code e1131187105398 = 5529233616502 := by decide
theorem cert_e1131187105398 : check e1131187105398 [[],[.under]] .smaller = true := by decide
def e1131187105590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131187105590 : Closed e1131187105590 ∧ code e1131187105590 = 5529233616694 := by decide
theorem cert_e1131187105590 : check e1131187105590 [[],[.under]] .smaller = true := by decide
def e1131187105594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131187105594 : Closed e1131187105594 ∧ code e1131187105594 = 5529233616698 := by decide
theorem cert_e1131187105594 : check e1131187105594 [[],[.under]] .smaller = true := by decide
def e1131187106654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1131187106654 : Closed e1131187106654 ∧ code e1131187106654 = 5529233617758 := by decide
theorem cert_e1131187106654 : check e1131187106654 [[],[.under]] .smaller = true := by decide
def e1131187106670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1131187106670 : Closed e1131187106670 ∧ code e1131187106670 = 5529233617774 := by decide
theorem cert_e1131187106670 : check e1131187106670 [[],[.under]] .smaller = true := by decide
def e1131187106678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1131187106678 : Closed e1131187106678 ∧ code e1131187106678 = 5529233617782 := by decide
theorem cert_e1131187106678 : check e1131187106678 [[],[.under]] .smaller = true := by decide
def e1131187106682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1131187106682 : Closed e1131187106682 ∧ code e1131187106682 = 5529233617786 := by decide
theorem cert_e1131187106682 : check e1131187106682 [[],[.under]] .smaller = true := by decide
def e1131187106734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1131187106734 : Closed e1131187106734 ∧ code e1131187106734 = 5529233617838 := by decide
theorem cert_e1131187106734 : check e1131187106734 [[],[.under]] .smaller = true := by decide
def e1131187106746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1131187106746 : Closed e1131187106746 ∧ code e1131187106746 = 5529233617850 := by decide
theorem cert_e1131187106746 : check e1131187106746 [[],[.under]] .smaller = true := by decide
def e1131187106774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1131187106774 : Closed e1131187106774 ∧ code e1131187106774 = 5529233617878 := by decide
theorem cert_e1131187106774 : check e1131187106774 [[],[.under]] .smaller = true := by decide
def e1131187106778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1131187106778 : Closed e1131187106778 ∧ code e1131187106778 = 5529233617882 := by decide
theorem cert_e1131187106778 : check e1131187106778 [[],[.under]] .smaller = true := by decide
def e1131187106794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1131187106794 : Closed e1131187106794 ∧ code e1131187106794 = 5529233617898 := by decide
theorem cert_e1131187106794 : check e1131187106794 [[],[.under]] .smaller = true := by decide
def e1131187107038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1131187107038 : Closed e1131187107038 ∧ code e1131187107038 = 5529233618142 := by decide
theorem cert_e1131187107038 : check e1131187107038 [[],[.under]] .smaller = true := by decide
def e1131187107054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131187107054 : Closed e1131187107054 ∧ code e1131187107054 = 5529233618158 := by decide
theorem cert_e1131187107054 : check e1131187107054 [[],[.under]] .smaller = true := by decide
def e1131187107062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131187107062 : Closed e1131187107062 ∧ code e1131187107062 = 5529233618166 := by decide
theorem cert_e1131187107062 : check e1131187107062 [[],[.under]] .smaller = true := by decide
def e1131187107066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1131187107066 : Closed e1131187107066 ∧ code e1131187107066 = 5529233618170 := by decide
theorem cert_e1131187107066 : check e1131187107066 [[],[.under]] .smaller = true := by decide
def e1131187107438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1131187107438 : Closed e1131187107438 ∧ code e1131187107438 = 5529233618542 := by decide
theorem cert_e1131187107438 : check e1131187107438 [[],[.under]] .smaller = true := by decide
def e1131187107450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1131187107450 : Closed e1131187107450 ∧ code e1131187107450 = 5529233618554 := by decide
theorem cert_e1131187107450 : check e1131187107450 [[],[.under]] .smaller = true := by decide
def e1131187107638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131187107638 : Closed e1131187107638 ∧ code e1131187107638 = 5529233618742 := by decide
theorem cert_e1131187107638 : check e1131187107638 [[],[.under]] .smaller = true := by decide
def e1131187107642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131187107642 : Closed e1131187107642 ∧ code e1131187107642 = 5529233618746 := by decide
theorem cert_e1131187107642 : check e1131187107642 [[],[.under]] .smaller = true := by decide
def e1131187107738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131187107738 : Closed e1131187107738 ∧ code e1131187107738 = 5529233618842 := by decide
theorem cert_e1131187107738 : check e1131187107738 [[],[.under]] .smaller = true := by decide
def e1131187108278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1131187108278 : Closed e1131187108278 ∧ code e1131187108278 = 5529233619382 := by decide
theorem cert_e1131187108278 : check e1131187108278 [[],[.under]] .smaller = true := by decide
def e1131187108310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1131187108310 : Closed e1131187108310 ∧ code e1131187108310 = 5529233619414 := by decide
theorem cert_e1131187108310 : check e1131187108310 [[],[.under]] .smaller = true := by decide
def e1131187108314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1131187108314 : Closed e1131187108314 ∧ code e1131187108314 = 5529233619418 := by decide
theorem cert_e1131187108314 : check e1131187108314 [[],[.under]] .smaller = true := by decide
def e1131187108470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1131187108470 : Closed e1131187108470 ∧ code e1131187108470 = 5529233619574 := by decide
theorem cert_e1131187108470 : check e1131187108470 [[],[.under]] .smaller = true := by decide
def e1131187108662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131187108662 : Closed e1131187108662 ∧ code e1131187108662 = 5529233619766 := by decide
theorem cert_e1131187108662 : check e1131187108662 [[],[.under]] .smaller = true := by decide
def e1131187108666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131187108666 : Closed e1131187108666 ∧ code e1131187108666 = 5529233619770 := by decide
theorem cert_e1131187108666 : check e1131187108666 [[],[.under]] .smaller = true := by decide
def e1131187109078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1131187109078 : Closed e1131187109078 ∧ code e1131187109078 = 5529233620182 := by decide
theorem cert_e1131187109078 : check e1131187109078 [[],[.under]] .smaller = true := by decide
def e1131187109082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1131187109082 : Closed e1131187109082 ∧ code e1131187109082 = 5529233620186 := by decide
theorem cert_e1131187109082 : check e1131187109082 [[],[.under]] .smaller = true := by decide
def e1131187109098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1131187109098 : Closed e1131187109098 ∧ code e1131187109098 = 5529233620202 := by decide
theorem cert_e1131187109098 : check e1131187109098 [[],[.under]] .smaller = true := by decide
def e1131187109174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1131187109174 : Closed e1131187109174 ∧ code e1131187109174 = 5529233620278 := by decide
theorem cert_e1131187109174 : check e1131187109174 [[],[.under]] .smaller = true := by decide
def e1131187109178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1131187109178 : Closed e1131187109178 ∧ code e1131187109178 = 5529233620282 := by decide
theorem cert_e1131187109178 : check e1131187109178 [[],[.under]] .smaller = true := by decide
def e1131187109274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1131187109274 : Closed e1131187109274 ∧ code e1131187109274 = 5529233620378 := by decide
theorem cert_e1131187109274 : check e1131187109274 [[],[.under]] .smaller = true := by decide
def e1131187115742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1131187115742 : Closed e1131187115742 ∧ code e1131187115742 = 5529233626846 := by decide
theorem cert_e1131187115742 : check e1131187115742 [[],[.under]] .smaller = true := by decide
def e1131187115766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1131187115766 : Closed e1131187115766 ∧ code e1131187115766 = 5529233626870 := by decide
theorem cert_e1131187115766 : check e1131187115766 [[],[.under]] .smaller = true := by decide
def e1131187115870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1131187115870 : Closed e1131187115870 ∧ code e1131187115870 = 5529233626974 := by decide
theorem cert_e1131187115870 : check e1131187115870 [[],[.under]] .smaller = true := by decide
def e1131187115886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1131187115886 : Closed e1131187115886 ∧ code e1131187115886 = 5529233626990 := by decide
theorem cert_e1131187115886 : check e1131187115886 [[],[.under]] .smaller = true := by decide
end Blc.Floor42
