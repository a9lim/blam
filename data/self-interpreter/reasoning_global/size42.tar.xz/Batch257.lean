import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211583809086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211583809086 : Closed e1211583809086 ∧ code e1211583809086 = 5609630320190 := by decide
theorem cert_e1211583809086 : check e1211583809086 [[],[],[],[]] .chain = true := by decide
def e1211583809134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211583809134 : Closed e1211583809134 ∧ code e1211583809134 = 5609630320238 := by decide
theorem cert_e1211583809134 : check e1211583809134 [[],[],[],[]] .chain = true := by decide
def e1211583809146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211583809146 : Closed e1211583809146 ∧ code e1211583809146 = 5609630320250 := by decide
theorem cert_e1211583809146 : check e1211583809146 [[],[],[],[]] .chain = true := by decide
def e1211583809434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211583809434 : Closed e1211583809434 ∧ code e1211583809434 = 5609630320538 := by decide
theorem cert_e1211583809434 : check e1211583809434 [[],[],[],[]] .chain = true := by decide
def e1211583809478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211583809478 : Closed e1211583809478 ∧ code e1211583809478 = 5609630320582 := by decide
theorem cert_e1211583809478 : check e1211583809478 [[],[],[],[]] .chain = true := by decide
def e1211583810654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211583810654 : Closed e1211583810654 ∧ code e1211583810654 = 5609630321758 := by decide
theorem cert_e1211583810654 : check e1211583810654 [[],[],[],[]] .chain = true := by decide
def e1211583810670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211583810670 : Closed e1211583810670 ∧ code e1211583810670 = 5609630321774 := by decide
theorem cert_e1211583810670 : check e1211583810670 [[],[],[],[]] .chain = true := by decide
def e1211583810682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211583810682 : Closed e1211583810682 ∧ code e1211583810682 = 5609630321786 := by decide
theorem cert_e1211583810682 : check e1211583810682 [[],[],[],[]] .chain = true := by decide
def e1211583810846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211583810846 : Closed e1211583810846 ∧ code e1211583810846 = 5609630321950 := by decide
theorem cert_e1211583810846 : check e1211583810846 [[],[],[],[]] .chain = true := by decide
def e1211583811014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211583811014 : Closed e1211583811014 ∧ code e1211583811014 = 5609630322118 := by decide
theorem cert_e1211583811014 : check e1211583811014 [[],[],[],[]] .chain = true := by decide
def e1211583811038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211583811038 : Closed e1211583811038 ∧ code e1211583811038 = 5609630322142 := by decide
theorem cert_e1211583811038 : checkPay e1211583811038 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e1211583811042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211583811042 : Closed e1211583811042 ∧ code e1211583811042 = 5609630322146 := by decide
theorem cert_e1211583811042 : check e1211583811042 [[],[],[],[]] .chain = true := by decide
def e1211583811054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211583811054 : Closed e1211583811054 ∧ code e1211583811054 = 5609630322158 := by decide
theorem cert_e1211583811054 : checkPay e1211583811054 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1211583811354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211583811354 : Closed e1211583811354 ∧ code e1211583811354 = 5609630322458 := by decide
theorem cert_e1211583811354 : check e1211583811354 [[],[],[],[]] .chain = true := by decide
def e1211583811398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211583811398 : Closed e1211583811398 ∧ code e1211583811398 = 5609630322502 := by decide
theorem cert_e1211583811398 : check e1211583811398 [[],[],[],[]] .chain = true := by decide
def e1211583811422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211583811422 : Closed e1211583811422 ∧ code e1211583811422 = 5609630322526 := by decide
theorem cert_e1211583811422 : checkPay e1211583811422 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211583811450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211583811450 : Closed e1211583811450 ∧ code e1211583811450 = 5609630322554 := by decide
theorem cert_e1211583811450 : checkPay e1211583811450 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211583811466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211583811466 : Closed e1211583811466 ∧ code e1211583811466 = 5609630322570 := by decide
theorem cert_e1211583811466 : check e1211583811466 [[],[],[],[]] .chain = true := by decide
def e1211583811490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211583811490 : Closed e1211583811490 ∧ code e1211583811490 = 5609630322594 := by decide
theorem cert_e1211583811490 : check e1211583811490 [[],[],[],[]] .chain = true := by decide
def e1211583811502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211583811502 : Closed e1211583811502 ∧ code e1211583811502 = 5609630322606 := by decide
theorem cert_e1211583811502 : checkPay e1211583811502 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.left],[],[.under,.left],[.under,.left,.left,.left]] = true := by decide
def e1211583811514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211583811514 : Closed e1211583811514 ∧ code e1211583811514 = 5609630322618 := by decide
theorem cert_e1211583811514 : checkPay e1211583811514 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211583811710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211583811710 : Closed e1211583811710 ∧ code e1211583811710 = 5609630322814 := by decide
theorem cert_e1211583811710 : check e1211583811710 [[],[],[],[]] .chain = true := by decide
def e1211583812382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211583812382 : Closed e1211583812382 ∧ code e1211583812382 = 5609630323486 := by decide
theorem cert_e1211583812382 : check e1211583812382 [[],[],[],[]] .chain = true := by decide
def e1211583812550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211583812550 : Closed e1211583812550 ∧ code e1211583812550 = 5609630323654 := by decide
theorem cert_e1211583812550 : check e1211583812550 [[],[],[],[]] .chain = true := by decide
def e1211583812574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211583812574 : Closed e1211583812574 ∧ code e1211583812574 = 5609630323678 := by decide
theorem cert_e1211583812574 : checkPay e1211583812574 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211583812578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211583812578 : Closed e1211583812578 ∧ code e1211583812578 = 5609630323682 := by decide
theorem cert_e1211583812578 : check e1211583812578 [[],[],[],[]] .chain = true := by decide
def e1211583812590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211583812590 : Closed e1211583812590 ∧ code e1211583812590 = 5609630323694 := by decide
theorem cert_e1211583812590 : checkPay e1211583812590 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211583814854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211583814854 : Closed e1211583814854 ∧ code e1211583814854 = 5609630325958 := by decide
theorem cert_e1211583814854 : check e1211583814854 [[],[],[],[]] .chain = true := by decide
def e1211583814878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211583814878 : Closed e1211583814878 ∧ code e1211583814878 = 5609630325982 := by decide
theorem cert_e1211583814878 : checkPay e1211583814878 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211583814906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211583814906 : Closed e1211583814906 ∧ code e1211583814906 = 5609630326010 := by decide
theorem cert_e1211583814906 : checkPay e1211583814906 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.under,.under,.right],[.under,.under,.under,.right,.under,.under,.right]] = true := by decide
def e1211583815182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211583815182 : Closed e1211583815182 ∧ code e1211583815182 = 5609630326286 := by decide
theorem cert_e1211583815182 : check e1211583815182 [[],[],[],[]] .chain = true := by decide
def e1211583815266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211583815266 : Closed e1211583815266 ∧ code e1211583815266 = 5609630326370 := by decide
theorem cert_e1211583815266 : check e1211583815266 [[],[],[],[]] .chain = true := by decide
def e1211583815278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211583815278 : Closed e1211583815278 ∧ code e1211583815278 = 5609630326382 := by decide
theorem cert_e1211583815278 : checkPay e1211583815278 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211583815290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211583815290 : Closed e1211583815290 ∧ code e1211583815290 = 5609630326394 := by decide
theorem cert_e1211583815290 : checkPay e1211583815290 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211583816502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211583816502 : Closed e1211583816502 ∧ code e1211583816502 = 5609630327606 := by decide
theorem cert_e1211583816502 : check e1211583816502 [[],[],[],[]] .chain = true := by decide
def e1211583816506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211583816506 : Closed e1211583816506 ∧ code e1211583816506 = 5609630327610 := by decide
theorem cert_e1211583816506 : check e1211583816506 [[],[],[],[]] .chain = true := by decide
def e1211583816602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211583816602 : Closed e1211583816602 ∧ code e1211583816602 = 5609630327706 := by decide
theorem cert_e1211583816602 : check e1211583816602 [[],[],[],[]] .chain = true := by decide
def e1211583817270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211583817270 : Closed e1211583817270 ∧ code e1211583817270 = 5609630328374 := by decide
theorem cert_e1211583817270 : check e1211583817270 [[],[],[],[]] .chain = true := by decide
def e1211583817274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211583817274 : Closed e1211583817274 ∧ code e1211583817274 = 5609630328378 := by decide
theorem cert_e1211583817274 : check e1211583817274 [[],[],[],[]] .chain = true := by decide
def e1211583817358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211583817358 : Closed e1211583817358 ∧ code e1211583817358 = 5609630328462 := by decide
theorem cert_e1211583817358 : check e1211583817358 [[],[],[],[]] .chain = true := by decide
def e1211583817414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211583817414 : Closed e1211583817414 ∧ code e1211583817414 = 5609630328518 := by decide
theorem cert_e1211583817414 : check e1211583817414 [[],[],[],[]] .chain = true := by decide
def e1211583817438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211583817438 : Closed e1211583817438 ∧ code e1211583817438 = 5609630328542 := by decide
theorem cert_e1211583817438 : check e1211583817438 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583817462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211583817462 : Closed e1211583817462 ∧ code e1211583817462 = 5609630328566 := by decide
theorem cert_e1211583817462 : check e1211583817462 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583817498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211583817498 : Closed e1211583817498 ∧ code e1211583817498 = 5609630328602 := by decide
theorem cert_e1211583817498 : check e1211583817498 [[],[],[],[]] .chain = true := by decide
def e1211583817542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211583817542 : Closed e1211583817542 ∧ code e1211583817542 = 5609630328646 := by decide
theorem cert_e1211583817542 : check e1211583817542 [[],[],[],[]] .chain = true := by decide
def e1211583817566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211583817566 : Closed e1211583817566 ∧ code e1211583817566 = 5609630328670 := by decide
theorem cert_e1211583817566 : check e1211583817566 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583817594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211583817594 : Closed e1211583817594 ∧ code e1211583817594 = 5609630328698 := by decide
theorem cert_e1211583817594 : check e1211583817594 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583817686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211583817686 : Closed e1211583817686 ∧ code e1211583817686 = 5609630328790 := by decide
theorem cert_e1211583817686 : check e1211583817686 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583817690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211583817690 : Closed e1211583817690 ∧ code e1211583817690 = 5609630328794 := by decide
theorem cert_e1211583817690 : check e1211583817690 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583818126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211583818126 : Closed e1211583818126 ∧ code e1211583818126 = 5609630329230 := by decide
theorem cert_e1211583818126 : check e1211583818126 [[],[],[],[]] .chain = true := by decide
def e1211583818182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211583818182 : Closed e1211583818182 ∧ code e1211583818182 = 5609630329286 := by decide
theorem cert_e1211583818182 : check e1211583818182 [[],[],[],[]] .chain = true := by decide
def e1211583818206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211583818206 : Closed e1211583818206 ∧ code e1211583818206 = 5609630329310 := by decide
theorem cert_e1211583818206 : check e1211583818206 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583818230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211583818230 : Closed e1211583818230 ∧ code e1211583818230 = 5609630329334 := by decide
theorem cert_e1211583818230 : check e1211583818230 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583818950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211583818950 : Closed e1211583818950 ∧ code e1211583818950 = 5609630330054 := by decide
theorem cert_e1211583818950 : check e1211583818950 [[],[],[],[]] .chain = true := by decide
def e1211583818974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211583818974 : Closed e1211583818974 ∧ code e1211583818974 = 5609630330078 := by decide
theorem cert_e1211583818974 : check e1211583818974 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583819002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211583819002 : Closed e1211583819002 ∧ code e1211583819002 = 5609630330106 := by decide
theorem cert_e1211583819002 : check e1211583819002 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583819574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211583819574 : Closed e1211583819574 ∧ code e1211583819574 = 5609630330678 := by decide
private def t_e1211583819574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211583819574 : ¬ IsSelfInterpreter e1211583819574 :=
  wSource (t := t_e1211583819574) (replay_sound (ps := []) (t := e1211583819574) (by decide)) (by decide)
def e1211583819578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211583819578 : Closed e1211583819578 ∧ code e1211583819578 = 5609630330682 := by decide
private def t_e1211583819578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211583819578 : ¬ IsSelfInterpreter e1211583819578 :=
  wSource (t := t_e1211583819578) (replay_sound (ps := []) (t := e1211583819578) (by decide)) (by decide)
def e1211583819894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211583819894 : Closed e1211583819894 ∧ code e1211583819894 = 5609630330998 := by decide
theorem cert_e1211583819894 : check e1211583819894 [[],[],[],[]] .chain = true := by decide
def e1211583819898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211583819898 : Closed e1211583819898 ∧ code e1211583819898 = 5609630331002 := by decide
theorem cert_e1211583819898 : check e1211583819898 [[],[],[],[]] .chain = true := by decide
def e1211583820086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211583820086 : Closed e1211583820086 ∧ code e1211583820086 = 5609630331190 := by decide
theorem cert_e1211583820086 : check e1211583820086 [[],[],[],[]] .chain = true := by decide
def e1211583820090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211583820090 : Closed e1211583820090 ∧ code e1211583820090 = 5609630331194 := by decide
theorem cert_e1211583820090 : check e1211583820090 [[],[],[],[]] .chain = true := by decide
def e1211583820174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211583820174 : Closed e1211583820174 ∧ code e1211583820174 = 5609630331278 := by decide
theorem cert_e1211583820174 : check e1211583820174 [[],[],[],[]] .chain = true := by decide
def e1211583820230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211583820230 : Closed e1211583820230 ∧ code e1211583820230 = 5609630331334 := by decide
theorem cert_e1211583820230 : check e1211583820230 [[],[],[],[]] .chain = true := by decide
def e1211583820566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211583820566 : Closed e1211583820566 ∧ code e1211583820566 = 5609630331670 := by decide
theorem cert_e1211583820566 : check e1211583820566 [[],[],[],[]] .chain = true := by decide
def e1211583820642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211583820642 : Closed e1211583820642 ∧ code e1211583820642 = 5609630331746 := by decide
theorem cert_e1211583820642 : check e1211583820642 [[],[],[],[]] .chain = true := by decide
def e1211583820654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211583820654 : Closed e1211583820654 ∧ code e1211583820654 = 5609630331758 := by decide
theorem cert_e1211583820654 : check e1211583820654 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583820662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211583820662 : Closed e1211583820662 ∧ code e1211583820662 = 5609630331766 := by decide
theorem cert_e1211583820662 : check e1211583820662 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211583820682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211583820682 : Closed e1211583820682 ∧ code e1211583820682 = 5609630331786 := by decide
theorem cert_e1211583820682 : check e1211583820682 [[],[],[],[]] .chain = true := by decide
def e1211583820706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211583820706 : Closed e1211583820706 ∧ code e1211583820706 = 5609630331810 := by decide
theorem cert_e1211583820706 : check e1211583820706 [[],[],[],[]] .chain = true := by decide
def e1211583820718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211583820718 : Closed e1211583820718 ∧ code e1211583820718 = 5609630331822 := by decide
theorem cert_e1211583820718 : check e1211583820718 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583820730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211583820730 : Closed e1211583820730 ∧ code e1211583820730 = 5609630331834 := by decide
theorem cert_e1211583820730 : check e1211583820730 [[],[],[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1211583820758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211583820758 : Closed e1211583820758 ∧ code e1211583820758 = 5609630331862 := by decide
theorem cert_e1211583820758 : check e1211583820758 [[],[],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583820762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211583820762 : Closed e1211583820762 ∧ code e1211583820762 = 5609630331866 := by decide
theorem cert_e1211583820762 : check e1211583820762 [[],[],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211583820830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211583820830 : Closed e1211583820830 ∧ code e1211583820830 = 5609630331934 := by decide
theorem cert_e1211583820830 : check e1211583820830 [[],[],[],[]] .chain = true := by decide
def e1211583821026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211583821026 : Closed e1211583821026 ∧ code e1211583821026 = 5609630332130 := by decide
theorem cert_e1211583821026 : check e1211583821026 [[],[],[],[]] .chain = true := by decide
def e1211583821038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211583821038 : Closed e1211583821038 ∧ code e1211583821038 = 5609630332142 := by decide
theorem cert_e1211583821038 : check e1211583821038 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583821046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211583821046 : Closed e1211583821046 ∧ code e1211583821046 = 5609630332150 := by decide
theorem cert_e1211583821046 : check e1211583821046 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583821326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211583821326 : Closed e1211583821326 ∧ code e1211583821326 = 5609630332430 := by decide
theorem cert_e1211583821326 : check e1211583821326 [[],[],[],[]] .chain = true := by decide
def e1211583821410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211583821410 : Closed e1211583821410 ∧ code e1211583821410 = 5609630332514 := by decide
theorem cert_e1211583821410 : check e1211583821410 [[],[],[],[]] .chain = true := by decide
def e1211583821422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211583821422 : Closed e1211583821422 ∧ code e1211583821422 = 5609630332526 := by decide
theorem cert_e1211583821422 : check e1211583821422 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583821434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211583821434 : Closed e1211583821434 ∧ code e1211583821434 = 5609630332538 := by decide
theorem cert_e1211583821434 : check e1211583821434 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e1211583821622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211583821622 : Closed e1211583821622 ∧ code e1211583821622 = 5609630332726 := by decide
private def t_e1211583821622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211583821622 : ¬ IsSelfInterpreter e1211583821622 :=
  wSource (t := t_e1211583821622) (replay_sound (ps := []) (t := e1211583821622) (by decide)) (by decide)
def e1211583821626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211583821626 : Closed e1211583821626 ∧ code e1211583821626 = 5609630332730 := by decide
private def t_e1211583821626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211583821626 : ¬ IsSelfInterpreter e1211583821626 :=
  wSource (t := t_e1211583821626) (replay_sound (ps := []) (t := e1211583821626) (by decide)) (by decide)
def e1211583829726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211583829726 : Closed e1211583829726 ∧ code e1211583829726 = 5609630340830 := by decide
theorem cert_e1211583829726 : check e1211583829726 [[],[],[],[]] .chain = true := by decide
def e1211583829750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211583829750 : Closed e1211583829750 ∧ code e1211583829750 = 5609630340854 := by decide
theorem cert_e1211583829750 : check e1211583829750 [[],[],[],[]] .chain = true := by decide
def e1211583829854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211583829854 : Closed e1211583829854 ∧ code e1211583829854 = 5609630340958 := by decide
theorem cert_e1211583829854 : check e1211583829854 [[],[],[],[]] .chain = true := by decide
def e1211583829882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211583829882 : Closed e1211583829882 ∧ code e1211583829882 = 5609630340986 := by decide
theorem cert_e1211583829882 : check e1211583829882 [[],[],[],[]] .chain = true := by decide
def e1211583829974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211583829974 : Closed e1211583829974 ∧ code e1211583829974 = 5609630341078 := by decide
theorem cert_e1211583829974 : check e1211583829974 [[],[],[],[]] .chain = true := by decide
def e1211583829978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211583829978 : Closed e1211583829978 ∧ code e1211583829978 = 5609630341082 := by decide
theorem cert_e1211583829978 : check e1211583829978 [[],[],[],[]] .chain = true := by decide
def e1211583830494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211583830494 : Closed e1211583830494 ∧ code e1211583830494 = 5609630341598 := by decide
theorem cert_e1211583830494 : check e1211583830494 [[],[],[],[]] .chain = true := by decide
def e1211583830518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211583830518 : Closed e1211583830518 ∧ code e1211583830518 = 5609630341622 := by decide
theorem cert_e1211583830518 : check e1211583830518 [[],[],[],[]] .chain = true := by decide
def e1211583831262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211583831262 : Closed e1211583831262 ∧ code e1211583831262 = 5609630342366 := by decide
theorem cert_e1211583831262 : check e1211583831262 [[],[],[],[]] .chain = true := by decide
def e1211583831290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211583831290 : Closed e1211583831290 ∧ code e1211583831290 = 5609630342394 := by decide
theorem cert_e1211583831290 : check e1211583831290 [[],[],[],[]] .chain = true := by decide
def e1211583831862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583831862 : Closed e1211583831862 ∧ code e1211583831862 = 5609630342966 := by decide
theorem cert_e1211583831862 : check e1211583831862 [[],[],[],[]] .chain = true := by decide
def e1211583831866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583831866 : Closed e1211583831866 ∧ code e1211583831866 = 5609630342970 := by decide
theorem cert_e1211583831866 : check e1211583831866 [[],[],[],[]] .chain = true := by decide
def e1211583846638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211583846638 : Closed e1211583846638 ∧ code e1211583846638 = 5609630357742 := by decide
theorem cert_e1211583846638 : check e1211583846638 [[],[],[],[]] .chain = true := by decide
def e1211583846646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211583846646 : Closed e1211583846646 ∧ code e1211583846646 = 5609630357750 := by decide
theorem cert_e1211583846646 : check e1211583846646 [[],[],[],[]] .chain = true := by decide
def e1211583847198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211583847198 : Closed e1211583847198 ∧ code e1211583847198 = 5609630358302 := by decide
theorem cert_e1211583847198 : check e1211583847198 [[],[],[],[]] .chain = true := by decide
def e1211583847310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211583847310 : Closed e1211583847310 ∧ code e1211583847310 = 5609630358414 := by decide
theorem cert_e1211583847310 : check e1211583847310 [[],[],[],[]] .chain = true := by decide
def e1211583847518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211583847518 : Closed e1211583847518 ∧ code e1211583847518 = 5609630358622 := by decide
theorem cert_e1211583847518 : check e1211583847518 [[],[],[],[]] .chain = true := by decide
def e1211583847534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211583847534 : Closed e1211583847534 ∧ code e1211583847534 = 5609630358638 := by decide
theorem cert_e1211583847534 : check e1211583847534 [[],[],[],[]] .chain = true := by decide
def e1211583847546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211583847546 : Closed e1211583847546 ∧ code e1211583847546 = 5609630358650 := by decide
theorem cert_e1211583847546 : check e1211583847546 [[],[],[],[]] .chain = true := by decide
def e1211583847710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211583847710 : Closed e1211583847710 ∧ code e1211583847710 = 5609630358814 := by decide
theorem cert_e1211583847710 : check e1211583847710 [[],[],[],[]] .chain = true := by decide
def e1211583847878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211583847878 : Closed e1211583847878 ∧ code e1211583847878 = 5609630358982 := by decide
theorem cert_e1211583847878 : check e1211583847878 [[],[],[],[]] .chain = true := by decide
def e1211583847902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211583847902 : Closed e1211583847902 ∧ code e1211583847902 = 5609630359006 := by decide
theorem cert_e1211583847902 : check e1211583847902 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211583847906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211583847906 : Closed e1211583847906 ∧ code e1211583847906 = 5609630359010 := by decide
theorem cert_e1211583847906 : check e1211583847906 [[],[],[],[]] .chain = true := by decide
def e1211583847918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211583847918 : Closed e1211583847918 ∧ code e1211583847918 = 5609630359022 := by decide
theorem cert_e1211583847918 : check e1211583847918 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211583847990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211583847990 : Closed e1211583847990 ∧ code e1211583847990 = 5609630359094 := by decide
theorem cert_e1211583847990 : check e1211583847990 [[],[],[],[]] .chain = true := by decide
def e1211583847994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211583847994 : Closed e1211583847994 ∧ code e1211583847994 = 5609630359098 := by decide
theorem cert_e1211583847994 : check e1211583847994 [[],[],[],[]] .chain = true := by decide
def e1211583848078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211583848078 : Closed e1211583848078 ∧ code e1211583848078 = 5609630359182 := by decide
theorem cert_e1211583848078 : check e1211583848078 [[],[],[],[]] .chain = true := by decide
def e1211583848134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211583848134 : Closed e1211583848134 ∧ code e1211583848134 = 5609630359238 := by decide
theorem cert_e1211583848134 : check e1211583848134 [[],[],[],[]] .chain = true := by decide
def e1211583848158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211583848158 : Closed e1211583848158 ∧ code e1211583848158 = 5609630359262 := by decide
theorem cert_e1211583848158 : checkPay e1211583848158 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211583848182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211583848182 : Closed e1211583848182 ∧ code e1211583848182 = 5609630359286 := by decide
theorem cert_e1211583848182 : check e1211583848182 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1211583848214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211583848214 : Closed e1211583848214 ∧ code e1211583848214 = 5609630359318 := by decide
theorem cert_e1211583848214 : check e1211583848214 [[],[],[],[]] .chain = true := by decide
def e1211583848290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211583848290 : Closed e1211583848290 ∧ code e1211583848290 = 5609630359394 := by decide
theorem cert_e1211583848290 : check e1211583848290 [[],[],[],[]] .chain = true := by decide
def e1211583848302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211583848302 : Closed e1211583848302 ∧ code e1211583848302 = 5609630359406 := by decide
theorem cert_e1211583848302 : check e1211583848302 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211583848310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211583848310 : Closed e1211583848310 ∧ code e1211583848310 = 5609630359414 := by decide
theorem cert_e1211583848310 : check e1211583848310 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211583850270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211583850270 : Closed e1211583850270 ∧ code e1211583850270 = 5609630361374 := by decide
theorem cert_e1211583850270 : check e1211583850270 [[],[],[],[]] .chain = true := by decide
def e1211583850382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211583850382 : Closed e1211583850382 ∧ code e1211583850382 = 5609630361486 := by decide
theorem cert_e1211583850382 : check e1211583850382 [[],[],[],[]] .chain = true := by decide
def e1211583852670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211583852670 : Closed e1211583852670 ∧ code e1211583852670 = 5609630363774 := by decide
theorem cert_e1211583852670 : check e1211583852670 [[],[],[],[]] .chain = true := by decide
def e1211583853342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211583853342 : Closed e1211583853342 ∧ code e1211583853342 = 5609630364446 := by decide
theorem cert_e1211583853342 : check e1211583853342 [[],[],[],[]] .chain = true := by decide
def e1211583853510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211583853510 : Closed e1211583853510 ∧ code e1211583853510 = 5609630364614 := by decide
theorem cert_e1211583853510 : check e1211583853510 [[],[],[],[]] .chain = true := by decide
def e1211583853534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211583853534 : Closed e1211583853534 ∧ code e1211583853534 = 5609630364638 := by decide
theorem cert_e1211583853534 : check e1211583853534 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211583853538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211583853538 : Closed e1211583853538 ∧ code e1211583853538 = 5609630364642 := by decide
theorem cert_e1211583853538 : check e1211583853538 [[],[],[],[]] .chain = true := by decide
def e1211583853550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211583853550 : Closed e1211583853550 ∧ code e1211583853550 = 5609630364654 := by decide
theorem cert_e1211583853550 : check e1211583853550 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211583854990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211583854990 : Closed e1211583854990 ∧ code e1211583854990 = 5609630366094 := by decide
theorem cert_e1211583854990 : check e1211583854990 [[],[],[],[]] .chain = true := by decide
def e1211583855046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211583855046 : Closed e1211583855046 ∧ code e1211583855046 = 5609630366150 := by decide
theorem cert_e1211583855046 : check e1211583855046 [[],[],[],[]] .chain = true := by decide
def e1211583855070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211583855070 : Closed e1211583855070 ∧ code e1211583855070 = 5609630366174 := by decide
theorem cert_e1211583855070 : check e1211583855070 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211583855094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211583855094 : Closed e1211583855094 ∧ code e1211583855094 = 5609630366198 := by decide
theorem cert_e1211583855094 : check e1211583855094 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211583855646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211583855646 : Closed e1211583855646 ∧ code e1211583855646 = 5609630366750 := by decide
theorem cert_e1211583855646 : check e1211583855646 [[],[],[],[]] .chain = true := by decide
def e1211583855842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211583855842 : Closed e1211583855842 ∧ code e1211583855842 = 5609630366946 := by decide
theorem cert_e1211583855842 : check e1211583855842 [[],[],[],[]] .chain = true := by decide
def e1211583855854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211583855854 : Closed e1211583855854 ∧ code e1211583855854 = 5609630366958 := by decide
theorem cert_e1211583855854 : check e1211583855854 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211583855862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211583855862 : Closed e1211583855862 ∧ code e1211583855862 = 5609630366966 := by decide
theorem cert_e1211583855862 : check e1211583855862 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1211583892334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211583892334 : Closed e1211583892334 ∧ code e1211583892334 = 5609630403438 := by decide
theorem cert_e1211583892334 : check e1211583892334 [[],[],[],[]] .smaller = true := by decide
def e1211583892342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211583892342 : Closed e1211583892342 ∧ code e1211583892342 = 5609630403446 := by decide
theorem cert_e1211583892342 : check e1211583892342 [[],[],[],[]] .smaller = true := by decide
def e1211583892398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211583892398 : Closed e1211583892398 ∧ code e1211583892398 = 5609630403502 := by decide
theorem cert_e1211583892398 : check e1211583892398 [[],[],[],[]] .smaller = true := by decide
def e1211583892410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211583892410 : Closed e1211583892410 ∧ code e1211583892410 = 5609630403514 := by decide
theorem cert_e1211583892410 : check e1211583892410 [[],[],[],[]] .smaller = true := by decide
def e1211583892438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211583892438 : Closed e1211583892438 ∧ code e1211583892438 = 5609630403542 := by decide
theorem cert_e1211583892438 : check e1211583892438 [[],[],[],[]] .smaller = true := by decide
def e1211583892442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211583892442 : Closed e1211583892442 ∧ code e1211583892442 = 5609630403546 := by decide
theorem cert_e1211583892442 : check e1211583892442 [[],[],[],[]] .smaller = true := by decide
def e1211583892718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211583892718 : Closed e1211583892718 ∧ code e1211583892718 = 5609630403822 := by decide
theorem cert_e1211583892718 : check e1211583892718 [[],[],[],[]] .smaller = true := by decide
def e1211583892726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211583892726 : Closed e1211583892726 ∧ code e1211583892726 = 5609630403830 := by decide
theorem cert_e1211583892726 : check e1211583892726 [[],[],[],[]] .smaller = true := by decide
def e1211583893102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211583893102 : Closed e1211583893102 ∧ code e1211583893102 = 5609630404206 := by decide
theorem cert_e1211583893102 : check e1211583893102 [[],[],[],[]] .smaller = true := by decide
def e1211583893114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211583893114 : Closed e1211583893114 ∧ code e1211583893114 = 5609630404218 := by decide
theorem cert_e1211583893114 : check e1211583893114 [[],[],[],[]] .smaller = true := by decide
def e1211583893302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583893302 : Closed e1211583893302 ∧ code e1211583893302 = 5609630404406 := by decide
theorem cert_e1211583893302 : check e1211583893302 [[],[],[],[]] .smaller = true := by decide
def e1211583893306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583893306 : Closed e1211583893306 ∧ code e1211583893306 = 5609630404410 := by decide
theorem cert_e1211583893306 : check e1211583893306 [[],[],[],[]] .smaller = true := by decide
def e1211583893438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211583893438 : Closed e1211583893438 ∧ code e1211583893438 = 5609630404542 := by decide
theorem cert_e1211583893438 : check e1211583893438 [[],[],[],[]] .sourceHead = true := by decide
def e1211583893470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211583893470 : Closed e1211583893470 ∧ code e1211583893470 = 5609630404574 := by decide
theorem cert_e1211583893470 : check e1211583893470 [[],[],[],[]] .sourceHead = true := by decide
def e1211583900766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211583900766 : Closed e1211583900766 ∧ code e1211583900766 = 5609630411870 := by decide
theorem cert_e1211583900766 : check e1211583900766 [[],[],[],[]] .chain = true := by decide
def e1211583900782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211583900782 : Closed e1211583900782 ∧ code e1211583900782 = 5609630411886 := by decide
theorem cert_e1211583900782 : check e1211583900782 [[],[],[],[]] .chain = true := by decide
def e1211583900794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211583900794 : Closed e1211583900794 ∧ code e1211583900794 = 5609630411898 := by decide
theorem cert_e1211583900794 : check e1211583900794 [[],[],[],[]] .chain = true := by decide
def e1211583900958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211583900958 : Closed e1211583900958 ∧ code e1211583900958 = 5609630412062 := by decide
theorem cert_e1211583900958 : check e1211583900958 [[],[],[],[]] .chain = true := by decide
def e1211583901126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211583901126 : Closed e1211583901126 ∧ code e1211583901126 = 5609630412230 := by decide
theorem cert_e1211583901126 : check e1211583901126 [[],[],[],[]] .chain = true := by decide
def e1211583901150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211583901150 : Closed e1211583901150 ∧ code e1211583901150 = 5609630412254 := by decide
theorem cert_e1211583901150 : check e1211583901150 [[],[],[],[]] .sourceHead = true := by decide
def e1211583901154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211583901154 : Closed e1211583901154 ∧ code e1211583901154 = 5609630412258 := by decide
theorem cert_e1211583901154 : check e1211583901154 [[],[],[],[]] .chain = true := by decide
def e1211583901166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211583901166 : Closed e1211583901166 ∧ code e1211583901166 = 5609630412270 := by decide
theorem cert_e1211583901166 : check e1211583901166 [[],[],[],[]] .sourceHead = true := by decide
def e1211583901466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211583901466 : Closed e1211583901466 ∧ code e1211583901466 = 5609630412570 := by decide
theorem cert_e1211583901466 : check e1211583901466 [[],[],[],[]] .chain = true := by decide
def e1211583901510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211583901510 : Closed e1211583901510 ∧ code e1211583901510 = 5609630412614 := by decide
theorem cert_e1211583901510 : check e1211583901510 [[],[],[],[]] .chain = true := by decide
def e1211583901534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211583901534 : Closed e1211583901534 ∧ code e1211583901534 = 5609630412638 := by decide
theorem cert_e1211583901534 : check e1211583901534 [[],[],[],[]] .sourceHead = true := by decide
def e1211583901562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211583901562 : Closed e1211583901562 ∧ code e1211583901562 = 5609630412666 := by decide
theorem cert_e1211583901562 : check e1211583901562 [[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor42
