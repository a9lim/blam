import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211206360518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211206360518 : Closed e1211206360518 ∧ code e1211206360518 = 5609252871622 := by decide
theorem cert_e1211206360518 : check e1211206360518 [[],[]] .smaller = true := by decide
def e1211206360542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211206360542 : Closed e1211206360542 ∧ code e1211206360542 = 5609252871646 := by decide
theorem cert_e1211206360542 : check e1211206360542 [[],[]] .chain = true := by decide
def e1211206360546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211206360546 : Closed e1211206360546 ∧ code e1211206360546 = 5609252871650 := by decide
theorem cert_e1211206360546 : check e1211206360546 [[],[]] .chain = true := by decide
def e1211206360558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211206360558 : Closed e1211206360558 ∧ code e1211206360558 = 5609252871662 := by decide
theorem cert_e1211206360558 : check e1211206360558 [[],[]] .chain = true := by decide
def e1211206360630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211206360630 : Closed e1211206360630 ∧ code e1211206360630 = 5609252871734 := by decide
theorem cert_e1211206360630 : check e1211206360630 [[],[]] .smaller = true := by decide
def e1211206360634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211206360634 : Closed e1211206360634 ∧ code e1211206360634 = 5609252871738 := by decide
theorem cert_e1211206360634 : check e1211206360634 [[],[]] .smaller = true := by decide
def e1211206360718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211206360718 : Closed e1211206360718 ∧ code e1211206360718 = 5609252871822 := by decide
theorem cert_e1211206360718 : check e1211206360718 [[],[]] .smaller = true := by decide
def e1211206360774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211206360774 : Closed e1211206360774 ∧ code e1211206360774 = 5609252871878 := by decide
theorem cert_e1211206360774 : check e1211206360774 [[],[]] .smaller = true := by decide
def e1211206360798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211206360798 : Closed e1211206360798 ∧ code e1211206360798 = 5609252871902 := by decide
theorem cert_e1211206360798 : check e1211206360798 [[],[]] .chain = true := by decide
def e1211206360822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211206360822 : Closed e1211206360822 ∧ code e1211206360822 = 5609252871926 := by decide
theorem cert_e1211206360822 : check e1211206360822 [[],[]] .chain = true := by decide
def e1211206360854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211206360854 : Closed e1211206360854 ∧ code e1211206360854 = 5609252871958 := by decide
theorem cert_e1211206360854 : check e1211206360854 [[],[]] .chain = true := by decide
def e1211206360930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211206360930 : Closed e1211206360930 ∧ code e1211206360930 = 5609252872034 := by decide
theorem cert_e1211206360930 : check e1211206360930 [[],[]] .chain = true := by decide
def e1211206360942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211206360942 : Closed e1211206360942 ∧ code e1211206360942 = 5609252872046 := by decide
theorem cert_e1211206360942 : check e1211206360942 [[],[]] .chain = true := by decide
def e1211206360950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211206360950 : Closed e1211206360950 ∧ code e1211206360950 = 5609252872054 := by decide
theorem cert_e1211206360950 : check e1211206360950 [[],[]] .chain = true := by decide
def e1211206362910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211206362910 : Closed e1211206362910 ∧ code e1211206362910 = 5609252874014 := by decide
theorem cert_e1211206362910 : check e1211206362910 [[],[]] .smaller = true := by decide
def e1211206363022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211206363022 : Closed e1211206363022 ∧ code e1211206363022 = 5609252874126 := by decide
theorem cert_e1211206363022 : check e1211206363022 [[],[]] .smaller = true := by decide
def e1211206365310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211206365310 : Closed e1211206365310 ∧ code e1211206365310 = 5609252876414 := by decide
theorem cert_e1211206365310 : check e1211206365310 [[],[]] .chain = true := by decide
def e1211206365406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211206365406 : Closed e1211206365406 ∧ code e1211206365406 = 5609252876510 := by decide
theorem cert_e1211206365406 : check e1211206365406 [[],[]] .smaller = true := by decide
def e1211206365434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211206365434 : Closed e1211206365434 ∧ code e1211206365434 = 5609252876538 := by decide
theorem cert_e1211206365434 : check e1211206365434 [[],[]] .smaller = true := by decide
def e1211206365982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211206365982 : Closed e1211206365982 ∧ code e1211206365982 = 5609252877086 := by decide
theorem cert_e1211206365982 : check e1211206365982 [[],[]] .smaller = true := by decide
def e1211206366150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211206366150 : Closed e1211206366150 ∧ code e1211206366150 = 5609252877254 := by decide
theorem cert_e1211206366150 : check e1211206366150 [[],[]] .smaller = true := by decide
def e1211206366174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211206366174 : Closed e1211206366174 ∧ code e1211206366174 = 5609252877278 := by decide
theorem cert_e1211206366174 : check e1211206366174 [[],[]] .chain = true := by decide
def e1211206366178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211206366178 : Closed e1211206366178 ∧ code e1211206366178 = 5609252877282 := by decide
theorem cert_e1211206366178 : check e1211206366178 [[],[]] .chain = true := by decide
def e1211206366190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211206366190 : Closed e1211206366190 ∧ code e1211206366190 = 5609252877294 := by decide
theorem cert_e1211206366190 : check e1211206366190 [[],[]] .chain = true := by decide
def e1211206367342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211206367342 : Closed e1211206367342 ∧ code e1211206367342 = 5609252878446 := by decide
theorem cert_e1211206367342 : check e1211206367342 [[],[]] .smaller = true := by decide
def e1211206367354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211206367354 : Closed e1211206367354 ∧ code e1211206367354 = 5609252878458 := by decide
theorem cert_e1211206367354 : check e1211206367354 [[],[]] .smaller = true := by decide
def e1211206367630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211206367630 : Closed e1211206367630 ∧ code e1211206367630 = 5609252878734 := by decide
theorem cert_e1211206367630 : check e1211206367630 [[],[]] .smaller = true := by decide
def e1211206367686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211206367686 : Closed e1211206367686 ∧ code e1211206367686 = 5609252878790 := by decide
theorem cert_e1211206367686 : check e1211206367686 [[],[]] .smaller = true := by decide
def e1211206367710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211206367710 : Closed e1211206367710 ∧ code e1211206367710 = 5609252878814 := by decide
theorem cert_e1211206367710 : check e1211206367710 [[],[]] .chain = true := by decide
def e1211206367734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211206367734 : Closed e1211206367734 ∧ code e1211206367734 = 5609252878838 := by decide
theorem cert_e1211206367734 : check e1211206367734 [[],[]] .chain = true := by decide
def e1211206368286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211206368286 : Closed e1211206368286 ∧ code e1211206368286 = 5609252879390 := by decide
theorem cert_e1211206368286 : check e1211206368286 [[],[]] .chain = true := by decide
def e1211206368482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211206368482 : Closed e1211206368482 ∧ code e1211206368482 = 5609252879586 := by decide
theorem cert_e1211206368482 : check e1211206368482 [[],[]] .chain = true := by decide
def e1211206368494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211206368494 : Closed e1211206368494 ∧ code e1211206368494 = 5609252879598 := by decide
theorem cert_e1211206368494 : check e1211206368494 [[],[]] .chain = true := by decide
def e1211206368502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211206368502 : Closed e1211206368502 ∧ code e1211206368502 = 5609252879606 := by decide
theorem cert_e1211206368502 : check e1211206368502 [[],[]] .chain = true := by decide
def e1211206404974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211206404974 : Closed e1211206404974 ∧ code e1211206404974 = 5609252916078 := by decide
theorem cert_e1211206404974 : check e1211206404974 [[],[]] .smaller = true := by decide
def e1211206404982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211206404982 : Closed e1211206404982 ∧ code e1211206404982 = 5609252916086 := by decide
theorem cert_e1211206404982 : check e1211206404982 [[],[]] .smaller = true := by decide
def e1211206405038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211206405038 : Closed e1211206405038 ∧ code e1211206405038 = 5609252916142 := by decide
theorem cert_e1211206405038 : check e1211206405038 [[],[]] .smaller = true := by decide
def e1211206405050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211206405050 : Closed e1211206405050 ∧ code e1211206405050 = 5609252916154 := by decide
theorem cert_e1211206405050 : check e1211206405050 [[],[]] .smaller = true := by decide
def e1211206405078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211206405078 : Closed e1211206405078 ∧ code e1211206405078 = 5609252916182 := by decide
theorem cert_e1211206405078 : check e1211206405078 [[],[]] .smaller = true := by decide
def e1211206405082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211206405082 : Closed e1211206405082 ∧ code e1211206405082 = 5609252916186 := by decide
theorem cert_e1211206405082 : check e1211206405082 [[],[]] .smaller = true := by decide
def e1211206405358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211206405358 : Closed e1211206405358 ∧ code e1211206405358 = 5609252916462 := by decide
theorem cert_e1211206405358 : check e1211206405358 [[],[]] .smaller = true := by decide
def e1211206405366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211206405366 : Closed e1211206405366 ∧ code e1211206405366 = 5609252916470 := by decide
theorem cert_e1211206405366 : check e1211206405366 [[],[]] .smaller = true := by decide
def e1211206405694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211206405694 : Closed e1211206405694 ∧ code e1211206405694 = 5609252916798 := by decide
theorem cert_e1211206405694 : check e1211206405694 [[],[]] .smaller = true := by decide
def e1211206405742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211206405742 : Closed e1211206405742 ∧ code e1211206405742 = 5609252916846 := by decide
theorem cert_e1211206405742 : check e1211206405742 [[],[]] .smaller = true := by decide
def e1211206405754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211206405754 : Closed e1211206405754 ∧ code e1211206405754 = 5609252916858 := by decide
theorem cert_e1211206405754 : check e1211206405754 [[],[]] .smaller = true := by decide
def e1211206405942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206405942 : Closed e1211206405942 ∧ code e1211206405942 = 5609252917046 := by decide
theorem cert_e1211206405942 : check e1211206405942 [[],[]] .smaller = true := by decide
def e1211206405946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206405946 : Closed e1211206405946 ∧ code e1211206405946 = 5609252917050 := by decide
theorem cert_e1211206405946 : check e1211206405946 [[],[]] .smaller = true := by decide
def e1211206406030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211206406030 : Closed e1211206406030 ∧ code e1211206406030 = 5609252917134 := by decide
theorem cert_e1211206406030 : check e1211206406030 [[],[]] .smaller = true := by decide
def e1211206406078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211206406078 : Closed e1211206406078 ∧ code e1211206406078 = 5609252917182 := by decide
theorem cert_e1211206406078 : check e1211206406078 [[],[]] .chain = true := by decide
def e1211206406110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211206406110 : Closed e1211206406110 ∧ code e1211206406110 = 5609252917214 := by decide
theorem cert_e1211206406110 : check e1211206406110 [[],[]] .chain = true := by decide
def e1211206413406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e1211206413406 : Closed e1211206413406 ∧ code e1211206413406 = 5609252924510 := by decide
theorem cert_e1211206413406 : check e1211206413406 [[],[]] .chain = true := by decide
def e1211206413422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211206413422 : Closed e1211206413422 ∧ code e1211206413422 = 5609252924526 := by decide
theorem cert_e1211206413422 : check e1211206413422 [[],[]] .smaller = true := by decide
def e1211206413434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211206413434 : Closed e1211206413434 ∧ code e1211206413434 = 5609252924538 := by decide
theorem cert_e1211206413434 : check e1211206413434 [[],[]] .smaller = true := by decide
def e1211206413598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211206413598 : Closed e1211206413598 ∧ code e1211206413598 = 5609252924702 := by decide
theorem cert_e1211206413598 : check e1211206413598 [[],[]] .smaller = true := by decide
def e1211206413766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211206413766 : Closed e1211206413766 ∧ code e1211206413766 = 5609252924870 := by decide
theorem cert_e1211206413766 : check e1211206413766 [[],[]] .smaller = true := by decide
def e1211206413790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211206413790 : Closed e1211206413790 ∧ code e1211206413790 = 5609252924894 := by decide
theorem cert_e1211206413790 : check e1211206413790 [[],[]] .chain = true := by decide
def e1211206413794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e1211206413794 : Closed e1211206413794 ∧ code e1211206413794 = 5609252924898 := by decide
theorem cert_e1211206413794 : check e1211206413794 [[],[]] .chain = true := by decide
def e1211206413806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211206413806 : Closed e1211206413806 ∧ code e1211206413806 = 5609252924910 := by decide
theorem cert_e1211206413806 : check e1211206413806 [[],[]] .chain = true := by decide
def e1211206414106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211206414106 : Closed e1211206414106 ∧ code e1211206414106 = 5609252925210 := by decide
theorem cert_e1211206414106 : check e1211206414106 [[],[]] .smaller = true := by decide
def e1211206414150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211206414150 : Closed e1211206414150 ∧ code e1211206414150 = 5609252925254 := by decide
theorem cert_e1211206414150 : check e1211206414150 [[],[]] .smaller = true := by decide
def e1211206414174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211206414174 : Closed e1211206414174 ∧ code e1211206414174 = 5609252925278 := by decide
theorem cert_e1211206414174 : check e1211206414174 [[],[]] .chain = true := by decide
def e1211206414202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211206414202 : Closed e1211206414202 ∧ code e1211206414202 = 5609252925306 := by decide
theorem cert_e1211206414202 : check e1211206414202 [[],[]] .chain = true := by decide
def e1211206414218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211206414218 : Closed e1211206414218 ∧ code e1211206414218 = 5609252925322 := by decide
theorem cert_e1211206414218 : check e1211206414218 [[],[]] .chain = true := by decide
def e1211206414242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211206414242 : Closed e1211206414242 ∧ code e1211206414242 = 5609252925346 := by decide
theorem cert_e1211206414242 : check e1211206414242 [[],[]] .chain = true := by decide
def e1211206414254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211206414254 : Closed e1211206414254 ∧ code e1211206414254 = 5609252925358 := by decide
theorem cert_e1211206414254 : check e1211206414254 [[],[]] .chain = true := by decide
def e1211206414266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211206414266 : Closed e1211206414266 ∧ code e1211206414266 = 5609252925370 := by decide
theorem cert_e1211206414266 : check e1211206414266 [[],[]] .chain = true := by decide
def e1211206414462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e1211206414462 : Closed e1211206414462 ∧ code e1211206414462 = 5609252925566 := by decide
theorem cert_e1211206414462 : check e1211206414462 [[],[]] .chain = true := by decide
def e1211206414558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211206414558 : Closed e1211206414558 ∧ code e1211206414558 = 5609252925662 := by decide
theorem cert_e1211206414558 : check e1211206414558 [[],[]] .smaller = true := by decide
def e1211206414586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211206414586 : Closed e1211206414586 ∧ code e1211206414586 = 5609252925690 := by decide
theorem cert_e1211206414586 : check e1211206414586 [[],[]] .smaller = true := by decide
def e1211206415134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211206415134 : Closed e1211206415134 ∧ code e1211206415134 = 5609252926238 := by decide
theorem cert_e1211206415134 : check e1211206415134 [[],[]] .smaller = true := by decide
def e1211206415302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211206415302 : Closed e1211206415302 ∧ code e1211206415302 = 5609252926406 := by decide
theorem cert_e1211206415302 : check e1211206415302 [[],[]] .smaller = true := by decide
def e1211206415326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211206415326 : Closed e1211206415326 ∧ code e1211206415326 = 5609252926430 := by decide
theorem cert_e1211206415326 : check e1211206415326 [[],[]] .chain = true := by decide
def e1211206415330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211206415330 : Closed e1211206415330 ∧ code e1211206415330 = 5609252926434 := by decide
theorem cert_e1211206415330 : check e1211206415330 [[],[]] .chain = true := by decide
def e1211206415342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211206415342 : Closed e1211206415342 ∧ code e1211206415342 = 5609252926446 := by decide
theorem cert_e1211206415342 : check e1211206415342 [[],[]] .chain = true := by decide
def e1211206417462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206417462 : Closed e1211206417462 ∧ code e1211206417462 = 5609252928566 := by decide
theorem cert_e1211206417462 : check e1211206417462 [[],[]] .smaller = true := by decide
def e1211206417466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206417466 : Closed e1211206417466 ∧ code e1211206417466 = 5609252928570 := by decide
theorem cert_e1211206417466 : check e1211206417466 [[],[]] .smaller = true := by decide
def e1211206417606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211206417606 : Closed e1211206417606 ∧ code e1211206417606 = 5609252928710 := by decide
theorem cert_e1211206417606 : check e1211206417606 [[],[]] .smaller = true := by decide
def e1211206417630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206417630 : Closed e1211206417630 ∧ code e1211206417630 = 5609252928734 := by decide
theorem cert_e1211206417630 : check e1211206417630 [[],[]] .chain = true := by decide
def e1211206417658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206417658 : Closed e1211206417658 ∧ code e1211206417658 = 5609252928762 := by decide
theorem cert_e1211206417658 : check e1211206417658 [[],[]] .chain = true := by decide
def e1211206417934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211206417934 : Closed e1211206417934 ∧ code e1211206417934 = 5609252929038 := by decide
theorem cert_e1211206417934 : check e1211206417934 [[],[]] .chain = true := by decide
def e1211206418018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211206418018 : Closed e1211206418018 ∧ code e1211206418018 = 5609252929122 := by decide
theorem cert_e1211206418018 : check e1211206418018 [[],[]] .chain = true := by decide
def e1211206418030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211206418030 : Closed e1211206418030 ∧ code e1211206418030 = 5609252929134 := by decide
theorem cert_e1211206418030 : check e1211206418030 [[],[]] .chain = true := by decide
def e1211206418042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211206418042 : Closed e1211206418042 ∧ code e1211206418042 = 5609252929146 := by decide
theorem cert_e1211206418042 : check e1211206418042 [[],[]] .chain = true := by decide
def e1211206436638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211206436638 : Closed e1211206436638 ∧ code e1211206436638 = 5609252947742 := by decide
theorem cert_e1211206436638 : check e1211206436638 [[],[]] .smaller = true := by decide
def e1211206436750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211206436750 : Closed e1211206436750 ∧ code e1211206436750 = 5609252947854 := by decide
theorem cert_e1211206436750 : check e1211206436750 [[],[]] .smaller = true := by decide
def e1211206436798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211206436798 : Closed e1211206436798 ∧ code e1211206436798 = 5609252947902 := by decide
theorem cert_e1211206436798 : check e1211206436798 [[],[]] .chain = true := by decide
def e1211206436846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211206436846 : Closed e1211206436846 ∧ code e1211206436846 = 5609252947950 := by decide
theorem cert_e1211206436846 : check e1211206436846 [[],[]] .chain = true := by decide
def e1211206440502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211206440502 : Closed e1211206440502 ∧ code e1211206440502 = 5609252951606 := by decide
theorem cert_e1211206440502 : check e1211206440502 [[],[]] .smaller = true := by decide
def e1211206440506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211206440506 : Closed e1211206440506 ∧ code e1211206440506 = 5609252951610 := by decide
theorem cert_e1211206440506 : check e1211206440506 [[],[]] .smaller = true := by decide
def e1211206440590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211206440590 : Closed e1211206440590 ∧ code e1211206440590 = 5609252951694 := by decide
theorem cert_e1211206440590 : check e1211206440590 [[],[]] .smaller = true := by decide
def e1211206440646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211206440646 : Closed e1211206440646 ∧ code e1211206440646 = 5609252951750 := by decide
theorem cert_e1211206440646 : check e1211206440646 [[],[]] .smaller = true := by decide
def e1211206440670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211206440670 : Closed e1211206440670 ∧ code e1211206440670 = 5609252951774 := by decide
theorem cert_e1211206440670 : check e1211206440670 [[],[]] .chain = true := by decide
def e1211206440694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211206440694 : Closed e1211206440694 ∧ code e1211206440694 = 5609252951798 := by decide
theorem cert_e1211206440694 : check e1211206440694 [[],[]] .chain = true := by decide
def e1211206440730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211206440730 : Closed e1211206440730 ∧ code e1211206440730 = 5609252951834 := by decide
theorem cert_e1211206440730 : check e1211206440730 [[],[]] .smaller = true := by decide
def e1211206440774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211206440774 : Closed e1211206440774 ∧ code e1211206440774 = 5609252951878 := by decide
theorem cert_e1211206440774 : check e1211206440774 [[],[]] .smaller = true := by decide
def e1211206440798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211206440798 : Closed e1211206440798 ∧ code e1211206440798 = 5609252951902 := by decide
theorem cert_e1211206440798 : check e1211206440798 [[],[]] .chain = true := by decide
def e1211206440826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211206440826 : Closed e1211206440826 ∧ code e1211206440826 = 5609252951930 := by decide
theorem cert_e1211206440826 : check e1211206440826 [[],[]] .chain = true := by decide
def e1211206440918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211206440918 : Closed e1211206440918 ∧ code e1211206440918 = 5609252952022 := by decide
theorem cert_e1211206440918 : check e1211206440918 [[],[]] .chain = true := by decide
def e1211206440922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211206440922 : Closed e1211206440922 ∧ code e1211206440922 = 5609252952026 := by decide
theorem cert_e1211206440922 : check e1211206440922 [[],[]] .chain = true := by decide
def e1211206441070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211206441070 : Closed e1211206441070 ∧ code e1211206441070 = 5609252952174 := by decide
theorem cert_e1211206441070 : check e1211206441070 [[],[]] .smaller = true := by decide
def e1211206441082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211206441082 : Closed e1211206441082 ∧ code e1211206441082 = 5609252952186 := by decide
theorem cert_e1211206441082 : check e1211206441082 [[],[]] .smaller = true := by decide
def e1211206441358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211206441358 : Closed e1211206441358 ∧ code e1211206441358 = 5609252952462 := by decide
theorem cert_e1211206441358 : check e1211206441358 [[],[]] .smaller = true := by decide
def e1211206441414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211206441414 : Closed e1211206441414 ∧ code e1211206441414 = 5609252952518 := by decide
theorem cert_e1211206441414 : check e1211206441414 [[],[]] .smaller = true := by decide
def e1211206441438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211206441438 : Closed e1211206441438 ∧ code e1211206441438 = 5609252952542 := by decide
theorem cert_e1211206441438 : check e1211206441438 [[],[]] .chain = true := by decide
def e1211206441462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211206441462 : Closed e1211206441462 ∧ code e1211206441462 = 5609252952566 := by decide
theorem cert_e1211206441462 : check e1211206441462 [[],[]] .chain = true := by decide
def e1211206442038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206442038 : Closed e1211206442038 ∧ code e1211206442038 = 5609252953142 := by decide
theorem cert_e1211206442038 : check e1211206442038 [[],[]] .smaller = true := by decide
def e1211206442042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206442042 : Closed e1211206442042 ∧ code e1211206442042 = 5609252953146 := by decide
theorem cert_e1211206442042 : check e1211206442042 [[],[]] .smaller = true := by decide
def e1211206442182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211206442182 : Closed e1211206442182 ∧ code e1211206442182 = 5609252953286 := by decide
theorem cert_e1211206442182 : check e1211206442182 [[],[]] .smaller = true := by decide
def e1211206442206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211206442206 : Closed e1211206442206 ∧ code e1211206442206 = 5609252953310 := by decide
theorem cert_e1211206442206 : check e1211206442206 [[],[]] .chain = true := by decide
def e1211206442234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211206442234 : Closed e1211206442234 ∧ code e1211206442234 = 5609252953338 := by decide
theorem cert_e1211206442234 : check e1211206442234 [[],[]] .chain = true := by decide
def e1211206442558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211206442558 : Closed e1211206442558 ∧ code e1211206442558 = 5609252953662 := by decide
theorem cert_e1211206442558 : check e1211206442558 [[],[]] .chain = true := by decide
def e1211206442782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211206442782 : Closed e1211206442782 ∧ code e1211206442782 = 5609252953886 := by decide
theorem cert_e1211206442782 : check e1211206442782 [[],[]] .chain = true := by decide
def e1211206442806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206442806 : Closed e1211206442806 ∧ code e1211206442806 = 5609252953910 := by decide
theorem cert_e1211206442806 : check e1211206442806 [[],[]] .chain = true := by decide
def e1211206442810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206442810 : Closed e1211206442810 ∧ code e1211206442810 = 5609252953914 := by decide
theorem cert_e1211206442810 : check e1211206442810 [[],[]] .chain = true := by decide
def e1211206452190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211206452190 : Closed e1211206452190 ∧ code e1211206452190 = 5609252963294 := by decide
theorem cert_e1211206452190 : check e1211206452190 [[],[]] .chain = true := by decide
def e1211206452206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211206452206 : Closed e1211206452206 ∧ code e1211206452206 = 5609252963310 := by decide
theorem cert_e1211206452206 : check e1211206452206 [[],[]] .chain = true := by decide
def e1211206454038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211206454038 : Closed e1211206454038 ∧ code e1211206454038 = 5609252965142 := by decide
theorem cert_e1211206454038 : check e1211206454038 [[],[]] .chain = true := by decide
def e1211206454114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211206454114 : Closed e1211206454114 ∧ code e1211206454114 = 5609252965218 := by decide
theorem cert_e1211206454114 : check e1211206454114 [[],[]] .chain = true := by decide
def e1211206454126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211206454126 : Closed e1211206454126 ∧ code e1211206454126 = 5609252965230 := by decide
theorem cert_e1211206454126 : check e1211206454126 [[],[]] .chain = true := by decide
def e1211206454134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211206454134 : Closed e1211206454134 ∧ code e1211206454134 = 5609252965238 := by decide
theorem cert_e1211206454134 : check e1211206454134 [[],[]] .chain = true := by decide
def e1211206454154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211206454154 : Closed e1211206454154 ∧ code e1211206454154 = 5609252965258 := by decide
theorem cert_e1211206454154 : check e1211206454154 [[],[]] .chain = true := by decide
def e1211206454178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211206454178 : Closed e1211206454178 ∧ code e1211206454178 = 5609252965282 := by decide
theorem cert_e1211206454178 : check e1211206454178 [[],[]] .chain = true := by decide
def e1211206454190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211206454190 : Closed e1211206454190 ∧ code e1211206454190 = 5609252965294 := by decide
theorem cert_e1211206454190 : check e1211206454190 [[],[]] .chain = true := by decide
def e1211206454202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211206454202 : Closed e1211206454202 ∧ code e1211206454202 = 5609252965306 := by decide
theorem cert_e1211206454202 : check e1211206454202 [[],[]] .chain = true := by decide
def e1211206454230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211206454230 : Closed e1211206454230 ∧ code e1211206454230 = 5609252965334 := by decide
theorem cert_e1211206454230 : check e1211206454230 [[],[]] .chain = true := by decide
def e1211206454234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211206454234 : Closed e1211206454234 ∧ code e1211206454234 = 5609252965338 := by decide
theorem cert_e1211206454234 : check e1211206454234 [[],[]] .chain = true := by decide
def e1211206454302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211206454302 : Closed e1211206454302 ∧ code e1211206454302 = 5609252965406 := by decide
theorem cert_e1211206454302 : check e1211206454302 [[],[]] .chain = true := by decide
def e1211206454498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211206454498 : Closed e1211206454498 ∧ code e1211206454498 = 5609252965602 := by decide
theorem cert_e1211206454498 : check e1211206454498 [[],[]] .chain = true := by decide
def e1211206454510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211206454510 : Closed e1211206454510 ∧ code e1211206454510 = 5609252965614 := by decide
theorem cert_e1211206454510 : check e1211206454510 [[],[]] .chain = true := by decide
def e1211206454518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211206454518 : Closed e1211206454518 ∧ code e1211206454518 = 5609252965622 := by decide
theorem cert_e1211206454518 : check e1211206454518 [[],[]] .chain = true := by decide
def e1211206454798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211206454798 : Closed e1211206454798 ∧ code e1211206454798 = 5609252965902 := by decide
theorem cert_e1211206454798 : check e1211206454798 [[],[]] .chain = true := by decide
def e1211206454882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211206454882 : Closed e1211206454882 ∧ code e1211206454882 = 5609252965986 := by decide
theorem cert_e1211206454882 : check e1211206454882 [[],[]] .chain = true := by decide
def e1211206454894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211206454894 : Closed e1211206454894 ∧ code e1211206454894 = 5609252965998 := by decide
theorem cert_e1211206454894 : check e1211206454894 [[],[]] .chain = true := by decide
def e1211206454906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211206454906 : Closed e1211206454906 ∧ code e1211206454906 = 5609252966010 := by decide
theorem cert_e1211206454906 : check e1211206454906 [[],[]] .chain = true := by decide
def e1211206455070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211206455070 : Closed e1211206455070 ∧ code e1211206455070 = 5609252966174 := by decide
theorem cert_e1211206455070 : check e1211206455070 [[],[]] .chain = true := by decide
def e1211206455094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211206455094 : Closed e1211206455094 ∧ code e1211206455094 = 5609252966198 := by decide
theorem cert_e1211206455094 : check e1211206455094 [[],[]] .chain = true := by decide
def e1211206455098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211206455098 : Closed e1211206455098 ∧ code e1211206455098 = 5609252966202 := by decide
theorem cert_e1211206455098 : check e1211206455098 [[],[]] .chain = true := by decide
def e1211207093486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207093486 : Closed e1211207093486 ∧ code e1211207093486 = 5609253604590 := by decide
theorem cert_e1211207093486 : check e1211207093486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207093494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207093494 : Closed e1211207093494 ∧ code e1211207093494 = 5609253604598 := by decide
theorem cert_e1211207093494 : checkPay e1211207093494 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under],[.under,.under,.under,.right]] = true := by decide
def e1211207100190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211207100190 : Closed e1211207100190 ∧ code e1211207100190 = 5609253611294 := by decide
theorem cert_e1211207100190 : check e1211207100190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207100302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211207100302 : Closed e1211207100302 ∧ code e1211207100302 = 5609253611406 := by decide
theorem cert_e1211207100302 : check e1211207100302 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1211207347054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211207347054 : Closed e1211207347054 ∧ code e1211207347054 = 5609253858158 := by decide
theorem cert_e1211207347054 : check e1211207347054 [[],[]] .chain = true := by decide
def e1211207347062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211207347062 : Closed e1211207347062 ∧ code e1211207347062 = 5609253858166 := by decide
theorem cert_e1211207347062 : check e1211207347062 [[],[]] .chain = true := by decide
def e1211207347126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211207347126 : Closed e1211207347126 ∧ code e1211207347126 = 5609253858230 := by decide
theorem cert_e1211207347126 : check e1211207347126 [[],[]] .chain = true := by decide
def e1211207347566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211207347566 : Closed e1211207347566 ∧ code e1211207347566 = 5609253858670 := by decide
theorem cert_e1211207347566 : check e1211207347566 [[],[]] .chain = true := by decide
def e1211207347574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211207347574 : Closed e1211207347574 ∧ code e1211207347574 = 5609253858678 := by decide
theorem cert_e1211207347574 : check e1211207347574 [[],[]] .chain = true := by decide
def e1211207347630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211207347630 : Closed e1211207347630 ∧ code e1211207347630 = 5609253858734 := by decide
theorem cert_e1211207347630 : check e1211207347630 [[],[]] .chain = true := by decide
def e1211207347642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211207347642 : Closed e1211207347642 ∧ code e1211207347642 = 5609253858746 := by decide
theorem cert_e1211207347642 : check e1211207347642 [[],[]] .chain = true := by decide
def e1211207347670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211207347670 : Closed e1211207347670 ∧ code e1211207347670 = 5609253858774 := by decide
theorem cert_e1211207347670 : check e1211207347670 [[],[]] .chain = true := by decide
def e1211207347674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211207347674 : Closed e1211207347674 ∧ code e1211207347674 = 5609253858778 := by decide
theorem cert_e1211207347674 : check e1211207347674 [[],[]] .chain = true := by decide
def e1211207347894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211207347894 : Closed e1211207347894 ∧ code e1211207347894 = 5609253858998 := by decide
theorem cert_e1211207347894 : check e1211207347894 [[],[]] .chain = true := by decide
def e1211207347926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211207347926 : Closed e1211207347926 ∧ code e1211207347926 = 5609253859030 := by decide
theorem cert_e1211207347926 : check e1211207347926 [[],[]] .chain = true := by decide
def e1211207347930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211207347930 : Closed e1211207347930 ∧ code e1211207347930 = 5609253859034 := by decide
theorem cert_e1211207347930 : check e1211207347930 [[],[]] .chain = true := by decide
def e1211207349614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211207349614 : Closed e1211207349614 ∧ code e1211207349614 = 5609253860718 := by decide
theorem cert_e1211207349614 : check e1211207349614 [[],[]] .chain = true := by decide
def e1211207349622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211207349622 : Closed e1211207349622 ∧ code e1211207349622 = 5609253860726 := by decide
theorem cert_e1211207349622 : check e1211207349622 [[],[]] .chain = true := by decide
def e1211207349678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211207349678 : Closed e1211207349678 ∧ code e1211207349678 = 5609253860782 := by decide
theorem cert_e1211207349678 : check e1211207349678 [[],[]] .chain = true := by decide
def e1211207349690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211207349690 : Closed e1211207349690 ∧ code e1211207349690 = 5609253860794 := by decide
theorem cert_e1211207349690 : check e1211207349690 [[],[]] .chain = true := by decide
def e1211207349718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211207349718 : Closed e1211207349718 ∧ code e1211207349718 = 5609253860822 := by decide
theorem cert_e1211207349718 : check e1211207349718 [[],[]] .chain = true := by decide
def e1211207349722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211207349722 : Closed e1211207349722 ∧ code e1211207349722 = 5609253860826 := by decide
theorem cert_e1211207349722 : check e1211207349722 [[],[]] .chain = true := by decide
def e1211207349934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211207349934 : Closed e1211207349934 ∧ code e1211207349934 = 5609253861038 := by decide
theorem cert_e1211207349934 : check e1211207349934 [[],[]] .chain = true := by decide
end Blc.Floor42
