import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e413500020974 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e413500020974 : Closed e413500020974 ∧ code e413500020974 = 4811546532078 := by decide
theorem cert_e413500020974 : check e413500020974 [] .sourceHead = true := by decide
def e413500020982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e413500020982 : Closed e413500020982 ∧ code e413500020982 = 4811546532086 := by decide
theorem cert_e413500020982 : check e413500020982 [] .sourceHead = true := by decide
def e413500021534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e413500021534 : Closed e413500021534 ∧ code e413500021534 = 4811546532638 := by decide
theorem cert_e413500021534 : check e413500021534 [] .sourceHead = true := by decide
def e413500021646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e413500021646 : Closed e413500021646 ∧ code e413500021646 = 4811546532750 := by decide
theorem cert_e413500021646 : check e413500021646 [] .sourceHead = true := by decide
def e413500021870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e413500021870 : Closed e413500021870 ∧ code e413500021870 = 4811546532974 := by decide
theorem cert_e413500021870 : check e413500021870 [] .sourceHead = true := by decide
def e413500021882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e413500021882 : Closed e413500021882 ∧ code e413500021882 = 4811546532986 := by decide
theorem cert_e413500021882 : check e413500021882 [] .sourceHead = true := by decide
def e413500022046 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e413500022046 : Closed e413500022046 ∧ code e413500022046 = 4811546533150 := by decide
theorem cert_e413500022046 : check e413500022046 [] .sourceHead = true := by decide
def e413500022214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e413500022214 : Closed e413500022214 ∧ code e413500022214 = 4811546533318 := by decide
theorem cert_e413500022214 : check e413500022214 [] .sourceHead = true := by decide
def e413500022326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e413500022326 : Closed e413500022326 ∧ code e413500022326 = 4811546533430 := by decide
theorem cert_e413500022326 : check e413500022326 [] .sourceHead = true := by decide
def e413500022330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e413500022330 : Closed e413500022330 ∧ code e413500022330 = 4811546533434 := by decide
theorem cert_e413500022330 : check e413500022330 [] .sourceHead = true := by decide
def e413500022414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e413500022414 : Closed e413500022414 ∧ code e413500022414 = 4811546533518 := by decide
theorem cert_e413500022414 : check e413500022414 [] .sourceHead = true := by decide
def e413500022470 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e413500022470 : Closed e413500022470 ∧ code e413500022470 = 4811546533574 := by decide
theorem cert_e413500022470 : check e413500022470 [] .sourceHead = true := by decide
def e413500024606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e413500024606 : Closed e413500024606 ∧ code e413500024606 = 4811546535710 := by decide
theorem cert_e413500024606 : check e413500024606 [] .sourceHead = true := by decide
def e413500024718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e413500024718 : Closed e413500024718 ∧ code e413500024718 = 4811546535822 := by decide
theorem cert_e413500024718 : check e413500024718 [] .sourceHead = true := by decide
def e413500027678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e413500027678 : Closed e413500027678 ∧ code e413500027678 = 4811546538782 := by decide
theorem cert_e413500027678 : check e413500027678 [] .sourceHead = true := by decide
def e413500027846 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e413500027846 : Closed e413500027846 ∧ code e413500027846 = 4811546538950 := by decide
theorem cert_e413500027846 : check e413500027846 [] .sourceHead = true := by decide
def e413500029326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e413500029326 : Closed e413500029326 ∧ code e413500029326 = 4811546540430 := by decide
theorem cert_e413500029326 : check e413500029326 [] .sourceHead = true := by decide
def e413500029382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e413500029382 : Closed e413500029382 ∧ code e413500029382 = 4811546540486 := by decide
theorem cert_e413500029382 : check e413500029382 [] .sourceHead = true := by decide
def e413500032622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e413500032622 : Closed e413500032622 ∧ code e413500032622 = 4811546543726 := by decide
theorem cert_e413500032622 : check e413500032622 [] .sourceHead = true := by decide
def e413500032634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e413500032634 : Closed e413500032634 ∧ code e413500032634 = 4811546543738 := by decide
theorem cert_e413500032634 : check e413500032634 [] .sourceHead = true := by decide
def e413500032922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e413500032922 : Closed e413500032922 ∧ code e413500032922 = 4811546544026 := by decide
theorem cert_e413500032922 : check e413500032922 [] .sourceHead = true := by decide
def e413500034158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e413500034158 : Closed e413500034158 ∧ code e413500034158 = 4811546545262 := by decide
theorem cert_e413500034158 : check e413500034158 [] .sourceHead = true := by decide
def e413500034170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e413500034170 : Closed e413500034170 ∧ code e413500034170 = 4811546545274 := by decide
theorem cert_e413500034170 : check e413500034170 [] .sourceHead = true := by decide
def e413500034334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e413500034334 : Closed e413500034334 ∧ code e413500034334 = 4811546545438 := by decide
theorem cert_e413500034334 : check e413500034334 [] .sourceHead = true := by decide
def e413500034502 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e413500034502 : Closed e413500034502 ∧ code e413500034502 = 4811546545606 := by decide
theorem cert_e413500034502 : check e413500034502 [] .sourceHead = true := by decide
def e413500034842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e413500034842 : Closed e413500034842 ∧ code e413500034842 = 4811546545946 := by decide
theorem cert_e413500034842 : check e413500034842 [] .sourceHead = true := by decide
def e413500034886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e413500034886 : Closed e413500034886 ∧ code e413500034886 = 4811546545990 := by decide
theorem cert_e413500034886 : check e413500034886 [] .sourceHead = true := by decide
def e413500035870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e413500035870 : Closed e413500035870 ∧ code e413500035870 = 4811546546974 := by decide
theorem cert_e413500035870 : check e413500035870 [] .sourceHead = true := by decide
def e413500036038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e413500036038 : Closed e413500036038 ∧ code e413500036038 = 4811546547142 := by decide
theorem cert_e413500036038 : check e413500036038 [] .sourceHead = true := by decide
def e413500038342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e413500038342 : Closed e413500038342 ∧ code e413500038342 = 4811546549446 := by decide
theorem cert_e413500038342 : check e413500038342 [] .sourceHead = true := by decide
def e413500039990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e413500039990 : Closed e413500039990 ∧ code e413500039990 = 4811546551094 := by decide
theorem cert_e413500039990 : check e413500039990 [] .sourceHead = true := by decide
def e413500039994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e413500039994 : Closed e413500039994 ∧ code e413500039994 = 4811546551098 := by decide
theorem cert_e413500039994 : check e413500039994 [] .sourceHead = true := by decide
def e413500040090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e413500040090 : Closed e413500040090 ∧ code e413500040090 = 4811546551194 := by decide
theorem cert_e413500040090 : check e413500040090 [] .sourceHead = true := by decide
def e413500040758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e413500040758 : Closed e413500040758 ∧ code e413500040758 = 4811546551862 := by decide
theorem cert_e413500040758 : check e413500040758 [] .sourceHead = true := by decide
def e413500040762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e413500040762 : Closed e413500040762 ∧ code e413500040762 = 4811546551866 := by decide
theorem cert_e413500040762 : check e413500040762 [] .sourceHead = true := by decide
def e413500040846 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e413500040846 : Closed e413500040846 ∧ code e413500040846 = 4811546551950 := by decide
theorem cert_e413500040846 : check e413500040846 [] .sourceHead = true := by decide
def e413500040902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e413500040902 : Closed e413500040902 ∧ code e413500040902 = 4811546552006 := by decide
theorem cert_e413500040902 : check e413500040902 [] .sourceHead = true := by decide
def e413500040986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e413500040986 : Closed e413500040986 ∧ code e413500040986 = 4811546552090 := by decide
theorem cert_e413500040986 : check e413500040986 [] .sourceHead = true := by decide
def e413500041030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e413500041030 : Closed e413500041030 ∧ code e413500041030 = 4811546552134 := by decide
theorem cert_e413500041030 : check e413500041030 [] .sourceHead = true := by decide
def e413500041614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e413500041614 : Closed e413500041614 ∧ code e413500041614 = 4811546552718 := by decide
theorem cert_e413500041614 : check e413500041614 [] .sourceHead = true := by decide
def e413500041670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e413500041670 : Closed e413500041670 ∧ code e413500041670 = 4811546552774 := by decide
theorem cert_e413500041670 : check e413500041670 [] .sourceHead = true := by decide
def e413500042438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e413500042438 : Closed e413500042438 ∧ code e413500042438 = 4811546553542 := by decide
theorem cert_e413500042438 : check e413500042438 [] .sourceHead = true := by decide
def e413500053214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e413500053214 : Closed e413500053214 ∧ code e413500053214 = 4811546564318 := by decide
theorem cert_e413500053214 : check e413500053214 [] .sourceHead = true := by decide
def e413500053238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e413500053238 : Closed e413500053238 ∧ code e413500053238 = 4811546564342 := by decide
theorem cert_e413500053238 : check e413500053238 [] .sourceHead = true := by decide
def e413500053342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e413500053342 : Closed e413500053342 ∧ code e413500053342 = 4811546564446 := by decide
theorem cert_e413500053342 : check e413500053342 [] .sourceHead = true := by decide
def e413500053370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e413500053370 : Closed e413500053370 ∧ code e413500053370 = 4811546564474 := by decide
theorem cert_e413500053370 : check e413500053370 [] .sourceHead = true := by decide
def e413500053462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e413500053462 : Closed e413500053462 ∧ code e413500053462 = 4811546564566 := by decide
theorem cert_e413500053462 : check e413500053462 [] .sourceHead = true := by decide
def e413500053466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e413500053466 : Closed e413500053466 ∧ code e413500053466 = 4811546564570 := by decide
theorem cert_e413500053466 : check e413500053466 [] .sourceHead = true := by decide
def e413500053982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e413500053982 : Closed e413500053982 ∧ code e413500053982 = 4811546565086 := by decide
theorem cert_e413500053982 : check e413500053982 [] .sourceHead = true := by decide
def e413500054006 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e413500054006 : Closed e413500054006 ∧ code e413500054006 = 4811546565110 := by decide
theorem cert_e413500054006 : check e413500054006 [] .sourceHead = true := by decide
def e413500054750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e413500054750 : Closed e413500054750 ∧ code e413500054750 = 4811546565854 := by decide
theorem cert_e413500054750 : check e413500054750 [] .sourceHead = true := by decide
def e413500054778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e413500054778 : Closed e413500054778 ∧ code e413500054778 = 4811546565882 := by decide
theorem cert_e413500054778 : check e413500054778 [] .sourceHead = true := by decide
def e413500055350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e413500055350 : Closed e413500055350 ∧ code e413500055350 = 4811546566454 := by decide
theorem cert_e413500055350 : check e413500055350 [] .sourceHead = true := by decide
def e413500055354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e413500055354 : Closed e413500055354 ∧ code e413500055354 = 4811546566458 := by decide
theorem cert_e413500055354 : check e413500055354 [] .sourceHead = true := by decide
def e413500070126 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e413500070126 : Closed e413500070126 ∧ code e413500070126 = 4811546581230 := by decide
theorem cert_e413500070126 : check e413500070126 [] .sourceHead = true := by decide
def e413500070134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e413500070134 : Closed e413500070134 ∧ code e413500070134 = 4811546581238 := by decide
theorem cert_e413500070134 : check e413500070134 [] .sourceHead = true := by decide
def e413500070686 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e413500070686 : Closed e413500070686 ∧ code e413500070686 = 4811546581790 := by decide
theorem cert_e413500070686 : check e413500070686 [] .sourceHead = true := by decide
def e413500070798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e413500070798 : Closed e413500070798 ∧ code e413500070798 = 4811546581902 := by decide
theorem cert_e413500070798 : check e413500070798 [] .sourceHead = true := by decide
def e413500071022 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e413500071022 : Closed e413500071022 ∧ code e413500071022 = 4811546582126 := by decide
theorem cert_e413500071022 : check e413500071022 [] .sourceHead = true := by decide
def e413500071034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e413500071034 : Closed e413500071034 ∧ code e413500071034 = 4811546582138 := by decide
theorem cert_e413500071034 : check e413500071034 [] .sourceHead = true := by decide
def e413500071198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e413500071198 : Closed e413500071198 ∧ code e413500071198 = 4811546582302 := by decide
theorem cert_e413500071198 : check e413500071198 [] .sourceHead = true := by decide
def e413500071366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e413500071366 : Closed e413500071366 ∧ code e413500071366 = 4811546582470 := by decide
theorem cert_e413500071366 : check e413500071366 [] .sourceHead = true := by decide
def e413500071478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e413500071478 : Closed e413500071478 ∧ code e413500071478 = 4811546582582 := by decide
theorem cert_e413500071478 : check e413500071478 [] .sourceHead = true := by decide
def e413500071482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e413500071482 : Closed e413500071482 ∧ code e413500071482 = 4811546582586 := by decide
theorem cert_e413500071482 : check e413500071482 [] .sourceHead = true := by decide
def e413500071566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e413500071566 : Closed e413500071566 ∧ code e413500071566 = 4811546582670 := by decide
theorem cert_e413500071566 : check e413500071566 [] .sourceHead = true := by decide
def e413500071622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e413500071622 : Closed e413500071622 ∧ code e413500071622 = 4811546582726 := by decide
theorem cert_e413500071622 : check e413500071622 [] .sourceHead = true := by decide
def e413500073758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e413500073758 : Closed e413500073758 ∧ code e413500073758 = 4811546584862 := by decide
theorem cert_e413500073758 : check e413500073758 [] .sourceHead = true := by decide
def e413500073870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e413500073870 : Closed e413500073870 ∧ code e413500073870 = 4811546584974 := by decide
theorem cert_e413500073870 : check e413500073870 [] .sourceHead = true := by decide
def e413500076830 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e413500076830 : Closed e413500076830 ∧ code e413500076830 = 4811546587934 := by decide
theorem cert_e413500076830 : check e413500076830 [] .sourceHead = true := by decide
def e413500076998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e413500076998 : Closed e413500076998 ∧ code e413500076998 = 4811546588102 := by decide
theorem cert_e413500076998 : check e413500076998 [] .sourceHead = true := by decide
def e413500078478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e413500078478 : Closed e413500078478 ∧ code e413500078478 = 4811546589582 := by decide
theorem cert_e413500078478 : check e413500078478 [] .sourceHead = true := by decide
def e413500078534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e413500078534 : Closed e413500078534 ∧ code e413500078534 = 4811546589638 := by decide
theorem cert_e413500078534 : check e413500078534 [] .sourceHead = true := by decide
def e413500124270 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e413500124270 : Closed e413500124270 ∧ code e413500124270 = 4811546635374 := by decide
theorem cert_e413500124270 : check e413500124270 [] .sourceHead = true := by decide
def e413500124282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e413500124282 : Closed e413500124282 ∧ code e413500124282 = 4811546635386 := by decide
theorem cert_e413500124282 : check e413500124282 [] .sourceHead = true := by decide
def e413500124446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e413500124446 : Closed e413500124446 ∧ code e413500124446 = 4811546635550 := by decide
theorem cert_e413500124446 : check e413500124446 [] .sourceHead = true := by decide
def e413500124614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e413500124614 : Closed e413500124614 ∧ code e413500124614 = 4811546635718 := by decide
theorem cert_e413500124614 : check e413500124614 [] .sourceHead = true := by decide
def e413500124954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e413500124954 : Closed e413500124954 ∧ code e413500124954 = 4811546636058 := by decide
theorem cert_e413500124954 : check e413500124954 [] .sourceHead = true := by decide
def e413500124998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e413500124998 : Closed e413500124998 ∧ code e413500124998 = 4811546636102 := by decide
theorem cert_e413500124998 : check e413500124998 [] .sourceHead = true := by decide
def e413500125982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e413500125982 : Closed e413500125982 ∧ code e413500125982 = 4811546637086 := by decide
theorem cert_e413500125982 : check e413500125982 [] .sourceHead = true := by decide
def e413500126150 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e413500126150 : Closed e413500126150 ∧ code e413500126150 = 4811546637254 := by decide
theorem cert_e413500126150 : check e413500126150 [] .sourceHead = true := by decide
def e413500128454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e413500128454 : Closed e413500128454 ∧ code e413500128454 = 4811546639558 := by decide
theorem cert_e413500128454 : check e413500128454 [] .sourceHead = true := by decide
def e413500151350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e413500151350 : Closed e413500151350 ∧ code e413500151350 = 4811546662454 := by decide
theorem cert_e413500151350 : check e413500151350 [] .sourceHead = true := by decide
def e413500151354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e413500151354 : Closed e413500151354 ∧ code e413500151354 = 4811546662458 := by decide
theorem cert_e413500151354 : check e413500151354 [] .sourceHead = true := by decide
def e413500151438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e413500151438 : Closed e413500151438 ∧ code e413500151438 = 4811546662542 := by decide
theorem cert_e413500151438 : check e413500151438 [] .sourceHead = true := by decide
def e413500151494 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e413500151494 : Closed e413500151494 ∧ code e413500151494 = 4811546662598 := by decide
theorem cert_e413500151494 : check e413500151494 [] .sourceHead = true := by decide
def e413500151578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e413500151578 : Closed e413500151578 ∧ code e413500151578 = 4811546662682 := by decide
theorem cert_e413500151578 : check e413500151578 [] .sourceHead = true := by decide
def e413500151622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e413500151622 : Closed e413500151622 ∧ code e413500151622 = 4811546662726 := by decide
theorem cert_e413500151622 : check e413500151622 [] .sourceHead = true := by decide
def e413500152206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e413500152206 : Closed e413500152206 ∧ code e413500152206 = 4811546663310 := by decide
theorem cert_e413500152206 : check e413500152206 [] .sourceHead = true := by decide
def e413500152262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e413500152262 : Closed e413500152262 ∧ code e413500152262 = 4811546663366 := by decide
theorem cert_e413500152262 : check e413500152262 [] .sourceHead = true := by decide
def e413500153030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e413500153030 : Closed e413500153030 ∧ code e413500153030 = 4811546664134 := by decide
theorem cert_e413500153030 : check e413500153030 [] .sourceHead = true := by decide
def e413511020742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413511020742 : Closed e413511020742 ∧ code e413511020742 = 4811557531846 := by decide
theorem cert_e413511020742 : check e413511020742 [] .sourceHead = true := by decide
def e413511045318 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413511045318 : Closed e413511045318 ∧ code e413511045318 = 4811557556422 := by decide
theorem cert_e413511045318 : check e413511045318 [] .sourceHead = true := by decide
def e413511143622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413511143622 : Closed e413511143622 ∧ code e413511143622 = 4811557654726 := by decide
theorem cert_e413511143622 : check e413511143622 [] .sourceHead = true := by decide
def e413511413958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413511413958 : Closed e413511413958 ∧ code e413511413958 = 4811557925062 := by decide
theorem cert_e413511413958 : check e413511413958 [] .sourceHead = true := by decide
def e413511438534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413511438534 : Closed e413511438534 ∧ code e413511438534 = 4811557949638 := by decide
theorem cert_e413511438534 : check e413511438534 [] .sourceHead = true := by decide
def e413512028358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413512028358 : Closed e413512028358 ∧ code e413512028358 = 4811558539462 := by decide
theorem cert_e413512028358 : check e413512028358 [] .sourceHead = true := by decide
def e413517918406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413517918406 : Closed e413517918406 ∧ code e413517918406 = 4811564429510 := by decide
theorem cert_e413517918406 : check e413517918406 [] .sourceHead = true := by decide
def e413517926598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413517926598 : Closed e413517926598 ∧ code e413517926598 = 4811564437702 := by decide
theorem cert_e413517926598 : check e413517926598 [] .sourceHead = true := by decide
def e413517959366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413517959366 : Closed e413517959366 ∧ code e413517959366 = 4811564470470 := by decide
theorem cert_e413517959366 : check e413517959366 [] .sourceHead = true := by decide
def e413518115014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413518115014 : Closed e413518115014 ∧ code e413518115014 = 4811564626118 := by decide
theorem cert_e413518115014 : check e413518115014 [] .sourceHead = true := by decide
def e413518123206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413518123206 : Closed e413518123206 ∧ code e413518123206 = 4811564634310 := by decide
theorem cert_e413518123206 : check e413518123206 [] .sourceHead = true := by decide
def e413518319814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e413518319814 : Closed e413518319814 ∧ code e413518319814 = 4811564830918 := by decide
theorem cert_e413518319814 : check e413518319814 [] .sourceHead = true := by decide
def e417020473542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020473542 : Closed e417020473542 ∧ code e417020473542 = 4815066984646 := by decide
theorem cert_e417020473542 : check e417020473542 [] .sourceHead = true := by decide
def e417020489926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020489926 : Closed e417020489926 ∧ code e417020489926 = 4815067001030 := by decide
theorem cert_e417020489926 : check e417020489926 [] .sourceHead = true := by decide
def e417020604614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020604614 : Closed e417020604614 ∧ code e417020604614 = 4815067115718 := by decide
theorem cert_e417020604614 : check e417020604614 [] .sourceHead = true := by decide
def e417020629190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020629190 : Closed e417020629190 ∧ code e417020629190 = 4815067140294 := by decide
theorem cert_e417020629190 : check e417020629190 [] .sourceHead = true := by decide
def e417020686534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020686534 : Closed e417020686534 ∧ code e417020686534 = 4815067197638 := by decide
theorem cert_e417020686534 : check e417020686534 [] .sourceHead = true := by decide
def e417020694726 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417020694726 : Closed e417020694726 ∧ code e417020694726 = 4815067205830 := by decide
theorem cert_e417020694726 : check e417020694726 [] .sourceHead = true := by decide
def e417021259974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417021259974 : Closed e417021259974 ∧ code e417021259974 = 4815067771078 := by decide
theorem cert_e417021259974 : check e417021259974 [] .sourceHead = true := by decide
def e417021276358 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417021276358 : Closed e417021276358 ∧ code e417021276358 = 4815067787462 := by decide
theorem cert_e417021276358 : check e417021276358 [] .sourceHead = true := by decide
def e417022046406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417022046406 : Closed e417022046406 ∧ code e417022046406 = 4815068557510 := by decide
theorem cert_e417022046406 : check e417022046406 [] .sourceHead = true := by decide
def e417022070982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417022070982 : Closed e417022070982 ∧ code e417022070982 = 4815068582086 := by decide
theorem cert_e417022070982 : check e417022070982 [] .sourceHead = true := by decide
def e417022456006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417022456006 : Closed e417022456006 ∧ code e417022456006 = 4815068967110 := by decide
theorem cert_e417022456006 : check e417022456006 [] .sourceHead = true := by decide
def e417022464198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e417022464198 : Closed e417022464198 ∧ code e417022464198 = 4815068975302 := by decide
theorem cert_e417022464198 : check e417022464198 [] .sourceHead = true := by decide
def e417027108206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e417027108206 : Closed e417027108206 ∧ code e417027108206 = 4815073619310 := by decide
theorem cert_e417027108206 : check e417027108206 [] .sourceHead = true := by decide
def e417027108214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e417027108214 : Closed e417027108214 ∧ code e417027108214 = 4815073619318 := by decide
theorem cert_e417027108214 : check e417027108214 [] .sourceHead = true := by decide
def e417027108270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e417027108270 : Closed e417027108270 ∧ code e417027108270 = 4815073619374 := by decide
theorem cert_e417027108270 : check e417027108270 [] .sourceHead = true := by decide
def e417027108282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e417027108282 : Closed e417027108282 ∧ code e417027108282 = 4815073619386 := by decide
theorem cert_e417027108282 : check e417027108282 [] .sourceHead = true := by decide
def e417027108310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e417027108310 : Closed e417027108310 ∧ code e417027108310 = 4815073619414 := by decide
theorem cert_e417027108310 : check e417027108310 [] .sourceHead = true := by decide
def e417027108314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e417027108314 : Closed e417027108314 ∧ code e417027108314 = 4815073619418 := by decide
theorem cert_e417027108314 : check e417027108314 [] .sourceHead = true := by decide
def e417027108526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e417027108526 : Closed e417027108526 ∧ code e417027108526 = 4815073619630 := by decide
theorem cert_e417027108526 : check e417027108526 [] .sourceHead = true := by decide
def e417027108538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e417027108538 : Closed e417027108538 ∧ code e417027108538 = 4815073619642 := by decide
theorem cert_e417027108538 : check e417027108538 [] .sourceHead = true := by decide
def e417027108586 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e417027108586 : Closed e417027108586 ∧ code e417027108586 = 4815073619690 := by decide
theorem cert_e417027108586 : check e417027108586 [] .sourceHead = true := by decide
def e417027108694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e417027108694 : Closed e417027108694 ∧ code e417027108694 = 4815073619798 := by decide
theorem cert_e417027108694 : check e417027108694 [] .sourceHead = true := by decide
def e417027108698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e417027108698 : Closed e417027108698 ∧ code e417027108698 = 4815073619802 := by decide
theorem cert_e417027108698 : check e417027108698 [] .sourceHead = true := by decide
def e417027108714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e417027108714 : Closed e417027108714 ∧ code e417027108714 = 4815073619818 := by decide
theorem cert_e417027108714 : check e417027108714 [] .sourceHead = true := by decide
def e417027109742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e417027109742 : Closed e417027109742 ∧ code e417027109742 = 4815073620846 := by decide
theorem cert_e417027109742 : check e417027109742 [] .sourceHead = true := by decide
def e417027109750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e417027109750 : Closed e417027109750 ∧ code e417027109750 = 4815073620854 := by decide
theorem cert_e417027109750 : check e417027109750 [] .sourceHead = true := by decide
def e417027109806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e417027109806 : Closed e417027109806 ∧ code e417027109806 = 4815073620910 := by decide
theorem cert_e417027109806 : check e417027109806 [] .sourceHead = true := by decide
def e417027109818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e417027109818 : Closed e417027109818 ∧ code e417027109818 = 4815073620922 := by decide
theorem cert_e417027109818 : check e417027109818 [] .sourceHead = true := by decide
def e417027109846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e417027109846 : Closed e417027109846 ∧ code e417027109846 = 4815073620950 := by decide
theorem cert_e417027109846 : check e417027109846 [] .sourceHead = true := by decide
def e417027109850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e417027109850 : Closed e417027109850 ∧ code e417027109850 = 4815073620954 := by decide
theorem cert_e417027109850 : check e417027109850 [] .sourceHead = true := by decide
def e417027110126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e417027110126 : Closed e417027110126 ∧ code e417027110126 = 4815073621230 := by decide
theorem cert_e417027110126 : check e417027110126 [] .sourceHead = true := by decide
def e417027110134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e417027110134 : Closed e417027110134 ∧ code e417027110134 = 4815073621238 := by decide
theorem cert_e417027110134 : check e417027110134 [] .sourceHead = true := by decide
def e417027110510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e417027110510 : Closed e417027110510 ∧ code e417027110510 = 4815073621614 := by decide
theorem cert_e417027110510 : check e417027110510 [] .sourceHead = true := by decide
def e417027110522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e417027110522 : Closed e417027110522 ∧ code e417027110522 = 4815073621626 := by decide
theorem cert_e417027110522 : check e417027110522 [] .sourceHead = true := by decide
def e417027110710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e417027110710 : Closed e417027110710 ∧ code e417027110710 = 4815073621814 := by decide
theorem cert_e417027110710 : check e417027110710 [] .sourceHead = true := by decide
def e417027110714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e417027110714 : Closed e417027110714 ∧ code e417027110714 = 4815073621818 := by decide
theorem cert_e417027110714 : check e417027110714 [] .sourceHead = true := by decide
def e417027111342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e417027111342 : Closed e417027111342 ∧ code e417027111342 = 4815073622446 := by decide
theorem cert_e417027111342 : check e417027111342 [] .sourceHead = true := by decide
def e417027111354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e417027111354 : Closed e417027111354 ∧ code e417027111354 = 4815073622458 := by decide
theorem cert_e417027111354 : check e417027111354 [] .sourceHead = true := by decide
def e417027111402 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e417027111402 : Closed e417027111402 ∧ code e417027111402 = 4815073622506 := by decide
theorem cert_e417027111402 : check e417027111402 [] .sourceHead = true := by decide
def e417027111534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e417027111534 : Closed e417027111534 ∧ code e417027111534 = 4815073622638 := by decide
theorem cert_e417027111534 : check e417027111534 [] .sourceHead = true := by decide
def e417027111546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e417027111546 : Closed e417027111546 ∧ code e417027111546 = 4815073622650 := by decide
theorem cert_e417027111546 : check e417027111546 [] .sourceHead = true := by decide
def e417027111834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e417027111834 : Closed e417027111834 ∧ code e417027111834 = 4815073622938 := by decide
theorem cert_e417027111834 : check e417027111834 [] .sourceHead = true := by decide
def e417027112150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e417027112150 : Closed e417027112150 ∧ code e417027112150 = 4815073623254 := by decide
theorem cert_e417027112150 : check e417027112150 [] .sourceHead = true := by decide
def e417027112154 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e417027112154 : Closed e417027112154 ∧ code e417027112154 = 4815073623258 := by decide
theorem cert_e417027112154 : check e417027112154 [] .sourceHead = true := by decide
def e417027112170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e417027112170 : Closed e417027112170 ∧ code e417027112170 = 4815073623274 := by decide
theorem cert_e417027112170 : check e417027112170 [] .sourceHead = true := by decide
def e417027112246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e417027112246 : Closed e417027112246 ∧ code e417027112246 = 4815073623350 := by decide
theorem cert_e417027112246 : check e417027112246 [] .sourceHead = true := by decide
def e417027112250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e417027112250 : Closed e417027112250 ∧ code e417027112250 = 4815073623354 := by decide
theorem cert_e417027112250 : check e417027112250 [] .sourceHead = true := by decide
def e417027112346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e417027112346 : Closed e417027112346 ∧ code e417027112346 = 4815073623450 := by decide
theorem cert_e417027112346 : check e417027112346 [] .sourceHead = true := by decide
def e417027115886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e417027115886 : Closed e417027115886 ∧ code e417027115886 = 4815073626990 := by decide
theorem cert_e417027115886 : check e417027115886 [] .sourceHead = true := by decide
def e417027115894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e417027115894 : Closed e417027115894 ∧ code e417027115894 = 4815073626998 := by decide
theorem cert_e417027115894 : check e417027115894 [] .sourceHead = true := by decide
def e417027115950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e417027115950 : Closed e417027115950 ∧ code e417027115950 = 4815073627054 := by decide
theorem cert_e417027115950 : check e417027115950 [] .sourceHead = true := by decide
def e417027115962 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e417027115962 : Closed e417027115962 ∧ code e417027115962 = 4815073627066 := by decide
theorem cert_e417027115962 : check e417027115962 [] .sourceHead = true := by decide
def e417027115990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e417027115990 : Closed e417027115990 ∧ code e417027115990 = 4815073627094 := by decide
theorem cert_e417027115990 : check e417027115990 [] .sourceHead = true := by decide
def e417027115994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e417027115994 : Closed e417027115994 ∧ code e417027115994 = 4815073627098 := by decide
theorem cert_e417027115994 : check e417027115994 [] .sourceHead = true := by decide
def e417027116270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e417027116270 : Closed e417027116270 ∧ code e417027116270 = 4815073627374 := by decide
theorem cert_e417027116270 : check e417027116270 [] .sourceHead = true := by decide
def e417027116278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e417027116278 : Closed e417027116278 ∧ code e417027116278 = 4815073627382 := by decide
theorem cert_e417027116278 : check e417027116278 [] .sourceHead = true := by decide
def e417027116654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e417027116654 : Closed e417027116654 ∧ code e417027116654 = 4815073627758 := by decide
theorem cert_e417027116654 : check e417027116654 [] .sourceHead = true := by decide
def e417027116666 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e417027116666 : Closed e417027116666 ∧ code e417027116666 = 4815073627770 := by decide
theorem cert_e417027116666 : check e417027116666 [] .sourceHead = true := by decide
end Blc.Floor42
