import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194672101302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1194672101302 : Closed e1194672101302 ∧ code e1194672101302 = 5592718612406 := by decide
theorem cert_e1194672101302 : check e1194672101302 [[],[.left],[]] .chain = true := by decide
def e1194672101334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1194672101334 : Closed e1194672101334 ∧ code e1194672101334 = 5592718612438 := by decide
theorem cert_e1194672101334 : check e1194672101334 [[],[.left],[]] .smaller = true := by decide
def e1194672101338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1194672101338 : Closed e1194672101338 ∧ code e1194672101338 = 5592718612442 := by decide
theorem cert_e1194672101338 : check e1194672101338 [[],[.left],[]] .smaller = true := by decide
def e1194672101854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1194672101854 : Closed e1194672101854 ∧ code e1194672101854 = 5592718612958 := by decide
theorem cert_e1194672101854 : check e1194672101854 [[],[.left],[]] .smaller = true := by decide
def e1194672101878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1194672101878 : Closed e1194672101878 ∧ code e1194672101878 = 5592718612982 := by decide
theorem cert_e1194672101878 : check e1194672101878 [[],[.left],[]] .smaller = true := by decide
def e1194672102622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1194672102622 : Closed e1194672102622 ∧ code e1194672102622 = 5592718613726 := by decide
theorem cert_e1194672102622 : check e1194672102622 [[],[.left],[]] .smaller = true := by decide
def e1194672102638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194672102638 : Closed e1194672102638 ∧ code e1194672102638 = 5592718613742 := by decide
theorem cert_e1194672102638 : check e1194672102638 [[],[.left],[]] .chain = true := by decide
def e1194672102646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194672102646 : Closed e1194672102646 ∧ code e1194672102646 = 5592718613750 := by decide
theorem cert_e1194672102646 : check e1194672102646 [[],[.left],[]] .chain = true := by decide
def e1194672102650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1194672102650 : Closed e1194672102650 ∧ code e1194672102650 = 5592718613754 := by decide
theorem cert_e1194672102650 : check e1194672102650 [[],[.left],[]] .smaller = true := by decide
def e1194672103030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1194672103030 : Closed e1194672103030 ∧ code e1194672103030 = 5592718614134 := by decide
theorem cert_e1194672103030 : check e1194672103030 [[],[.left],[]] .chain = true := by decide
def e1194672103222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672103222 : Closed e1194672103222 ∧ code e1194672103222 = 5592718614326 := by decide
theorem cert_e1194672103222 : check e1194672103222 [[],[.left],[]] .smaller = true := by decide
def e1194672103226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672103226 : Closed e1194672103226 ∧ code e1194672103226 = 5592718614330 := by decide
theorem cert_e1194672103226 : check e1194672103226 [[],[.left],[]] .smaller = true := by decide
def e1194672114526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1194672114526 : Closed e1194672114526 ∧ code e1194672114526 = 5592718625630 := by decide
theorem cert_e1194672114526 : check e1194672114526 [[],[.left],[]] .smaller = true := by decide
def e1194672114542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1194672114542 : Closed e1194672114542 ∧ code e1194672114542 = 5592718625646 := by decide
theorem cert_e1194672114542 : check e1194672114542 [[],[.left],[]] .chain = true := by decide
def e1194672114550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1194672114550 : Closed e1194672114550 ∧ code e1194672114550 = 5592718625654 := by decide
theorem cert_e1194672114550 : check e1194672114550 [[],[.left],[]] .chain = true := by decide
def e1194672114554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1194672114554 : Closed e1194672114554 ∧ code e1194672114554 = 5592718625658 := by decide
theorem cert_e1194672114554 : check e1194672114554 [[],[.left],[]] .smaller = true := by decide
def e1194672114606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1194672114606 : Closed e1194672114606 ∧ code e1194672114606 = 5592718625710 := by decide
theorem cert_e1194672114606 : check e1194672114606 [[],[.left],[]] .chain = true := by decide
def e1194672114618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1194672114618 : Closed e1194672114618 ∧ code e1194672114618 = 5592718625722 := by decide
theorem cert_e1194672114618 : check e1194672114618 [[],[.left],[]] .chain = true := by decide
def e1194672114646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1194672114646 : Closed e1194672114646 ∧ code e1194672114646 = 5592718625750 := by decide
theorem cert_e1194672114646 : check e1194672114646 [[],[.left],[]] .chain = true := by decide
def e1194672114650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1194672114650 : Closed e1194672114650 ∧ code e1194672114650 = 5592718625754 := by decide
theorem cert_e1194672114650 : check e1194672114650 [[],[.left],[]] .chain = true := by decide
def e1194672114666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1194672114666 : Closed e1194672114666 ∧ code e1194672114666 = 5592718625770 := by decide
theorem cert_e1194672114666 : check e1194672114666 [[],[.left],[]] .smaller = true := by decide
def e1194672114910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1194672114910 : Closed e1194672114910 ∧ code e1194672114910 = 5592718626014 := by decide
theorem cert_e1194672114910 : check e1194672114910 [[],[.left],[]] .smaller = true := by decide
def e1194672114926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194672114926 : Closed e1194672114926 ∧ code e1194672114926 = 5592718626030 := by decide
theorem cert_e1194672114926 : check e1194672114926 [[],[.left],[]] .chain = true := by decide
def e1194672114934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194672114934 : Closed e1194672114934 ∧ code e1194672114934 = 5592718626038 := by decide
theorem cert_e1194672114934 : check e1194672114934 [[],[.left],[]] .chain = true := by decide
def e1194672114938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1194672114938 : Closed e1194672114938 ∧ code e1194672114938 = 5592718626042 := by decide
theorem cert_e1194672114938 : check e1194672114938 [[],[.left],[]] .smaller = true := by decide
def e1194672115310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194672115310 : Closed e1194672115310 ∧ code e1194672115310 = 5592718626414 := by decide
theorem cert_e1194672115310 : check e1194672115310 [[],[.left],[]] .chain = true := by decide
def e1194672115322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194672115322 : Closed e1194672115322 ∧ code e1194672115322 = 5592718626426 := by decide
theorem cert_e1194672115322 : check e1194672115322 [[],[.left],[]] .chain = true := by decide
def e1194672115510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672115510 : Closed e1194672115510 ∧ code e1194672115510 = 5592718626614 := by decide
theorem cert_e1194672115510 : check e1194672115510 [[],[.left],[]] .chain = true := by decide
def e1194672115514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672115514 : Closed e1194672115514 ∧ code e1194672115514 = 5592718626618 := by decide
theorem cert_e1194672115514 : check e1194672115514 [[],[.left],[]] .chain = true := by decide
def e1194672115610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1194672115610 : Closed e1194672115610 ∧ code e1194672115610 = 5592718626714 := by decide
theorem cert_e1194672115610 : check e1194672115610 [[],[.left],[]] .smaller = true := by decide
def e1194672121270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1194672121270 : Closed e1194672121270 ∧ code e1194672121270 = 5592718632374 := by decide
theorem cert_e1194672121270 : check e1194672121270 [[],[.left],[]] .chain = true := by decide
def e1194672121302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1194672121302 : Closed e1194672121302 ∧ code e1194672121302 = 5592718632406 := by decide
theorem cert_e1194672121302 : check e1194672121302 [[],[.left],[]] .chain = true := by decide
def e1194672121306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1194672121306 : Closed e1194672121306 ∧ code e1194672121306 = 5592718632410 := by decide
theorem cert_e1194672121306 : check e1194672121306 [[],[.left],[]] .chain = true := by decide
def e1194672121462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1194672121462 : Closed e1194672121462 ∧ code e1194672121462 = 5592718632566 := by decide
theorem cert_e1194672121462 : check e1194672121462 [[],[.left],[]] .chain = true := by decide
def e1194672121654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672121654 : Closed e1194672121654 ∧ code e1194672121654 = 5592718632758 := by decide
theorem cert_e1194672121654 : check e1194672121654 [[],[.left],[]] .chain = true := by decide
def e1194672121658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672121658 : Closed e1194672121658 ∧ code e1194672121658 = 5592718632762 := by decide
theorem cert_e1194672121658 : check e1194672121658 [[],[.left],[]] .chain = true := by decide
def e1194672124630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1194672124630 : Closed e1194672124630 ∧ code e1194672124630 = 5592718635734 := by decide
theorem cert_e1194672124630 : check e1194672124630 [[],[.left],[]] .smaller = true := by decide
def e1194672124634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1194672124634 : Closed e1194672124634 ∧ code e1194672124634 = 5592718635738 := by decide
theorem cert_e1194672124634 : check e1194672124634 [[],[.left],[]] .smaller = true := by decide
def e1194672124650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1194672124650 : Closed e1194672124650 ∧ code e1194672124650 = 5592718635754 := by decide
theorem cert_e1194672124650 : check e1194672124650 [[],[.left],[]] .smaller = true := by decide
def e1194672124726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672124726 : Closed e1194672124726 ∧ code e1194672124726 = 5592718635830 := by decide
theorem cert_e1194672124726 : check e1194672124726 [[],[.left],[]] .smaller = true := by decide
def e1194672124730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672124730 : Closed e1194672124730 ∧ code e1194672124730 = 5592718635834 := by decide
theorem cert_e1194672124730 : check e1194672124730 [[],[.left],[]] .smaller = true := by decide
def e1194672124826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1194672124826 : Closed e1194672124826 ∧ code e1194672124826 = 5592718635930 := by decide
theorem cert_e1194672124826 : check e1194672124826 [[],[.left],[]] .smaller = true := by decide
def e1194672350062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1194672350062 : Closed e1194672350062 ∧ code e1194672350062 = 5592718861166 := by decide
theorem cert_e1194672350062 : check e1194672350062 [[],[.left],[]] .chain = true := by decide
def e1194672350070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1194672350070 : Closed e1194672350070 ∧ code e1194672350070 = 5592718861174 := by decide
theorem cert_e1194672350070 : check e1194672350070 [[],[.left],[]] .chain = true := by decide
def e1194672350126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1194672350126 : Closed e1194672350126 ∧ code e1194672350126 = 5592718861230 := by decide
theorem cert_e1194672350126 : check e1194672350126 [[],[.left],[]] .chain = true := by decide
def e1194672350138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1194672350138 : Closed e1194672350138 ∧ code e1194672350138 = 5592718861242 := by decide
theorem cert_e1194672350138 : check e1194672350138 [[],[.left],[]] .chain = true := by decide
def e1194672350166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1194672350166 : Closed e1194672350166 ∧ code e1194672350166 = 5592718861270 := by decide
theorem cert_e1194672350166 : check e1194672350166 [[],[.left],[]] .chain = true := by decide
def e1194672350170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1194672350170 : Closed e1194672350170 ∧ code e1194672350170 = 5592718861274 := by decide
theorem cert_e1194672350170 : check e1194672350170 [[],[.left],[]] .chain = true := by decide
def e1194672351470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1194672351470 : Closed e1194672351470 ∧ code e1194672351470 = 5592718862574 := by decide
theorem cert_e1194672351470 : check e1194672351470 [[],[.left],[]] .chain = true := by decide
def e1194672351478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1194672351478 : Closed e1194672351478 ∧ code e1194672351478 = 5592718862582 := by decide
theorem cert_e1194672351478 : check e1194672351478 [[],[.left],[]] .chain = true := by decide
def e1194672352030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1194672352030 : Closed e1194672352030 ∧ code e1194672352030 = 5592718863134 := by decide
theorem cert_e1194672352030 : check e1194672352030 [[],[.left],[]] .chain = true := by decide
def e1194672352142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1194672352142 : Closed e1194672352142 ∧ code e1194672352142 = 5592718863246 := by decide
theorem cert_e1194672352142 : check e1194672352142 [[],[.left],[]] .chain = true := by decide
def e1194672352366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1194672352366 : Closed e1194672352366 ∧ code e1194672352366 = 5592718863470 := by decide
theorem cert_e1194672352366 : check e1194672352366 [[],[.left],[]] .chain = true := by decide
def e1194672352378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1194672352378 : Closed e1194672352378 ∧ code e1194672352378 = 5592718863482 := by decide
theorem cert_e1194672352378 : check e1194672352378 [[],[.left],[]] .chain = true := by decide
def e1194672352542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1194672352542 : Closed e1194672352542 ∧ code e1194672352542 = 5592718863646 := by decide
theorem cert_e1194672352542 : check e1194672352542 [[],[.left],[]] .chain = true := by decide
def e1194672352710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1194672352710 : Closed e1194672352710 ∧ code e1194672352710 = 5592718863814 := by decide
theorem cert_e1194672352710 : check e1194672352710 [[],[.left],[]] .chain = true := by decide
def e1194672352822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1194672352822 : Closed e1194672352822 ∧ code e1194672352822 = 5592718863926 := by decide
theorem cert_e1194672352822 : check e1194672352822 [[],[.left],[]] .chain = true := by decide
def e1194672352826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1194672352826 : Closed e1194672352826 ∧ code e1194672352826 = 5592718863930 := by decide
theorem cert_e1194672352826 : check e1194672352826 [[],[.left],[]] .chain = true := by decide
def e1194672352910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1194672352910 : Closed e1194672352910 ∧ code e1194672352910 = 5592718864014 := by decide
theorem cert_e1194672352910 : check e1194672352910 [[],[.left],[]] .chain = true := by decide
def e1194672352966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1194672352966 : Closed e1194672352966 ∧ code e1194672352966 = 5592718864070 := by decide
theorem cert_e1194672352966 : check e1194672352966 [[],[.left],[]] .chain = true := by decide
def e1194672353710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1194672353710 : Closed e1194672353710 ∧ code e1194672353710 = 5592718864814 := by decide
theorem cert_e1194672353710 : check e1194672353710 [[],[.left],[]] .chain = true := by decide
def e1194672353722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1194672353722 : Closed e1194672353722 ∧ code e1194672353722 = 5592718864826 := by decide
theorem cert_e1194672353722 : check e1194672353722 [[],[.left],[]] .chain = true := by decide
def e1194672353770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1194672353770 : Closed e1194672353770 ∧ code e1194672353770 = 5592718864874 := by decide
theorem cert_e1194672353770 : check e1194672353770 [[],[.left],[]] .chain = true := by decide
def e1194672354414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1194672354414 : Closed e1194672354414 ∧ code e1194672354414 = 5592718865518 := by decide
theorem cert_e1194672354414 : check e1194672354414 [[],[.left],[]] .chain = true := by decide
def e1194672354426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1194672354426 : Closed e1194672354426 ∧ code e1194672354426 = 5592718865530 := by decide
theorem cert_e1194672354426 : check e1194672354426 [[],[.left],[]] .chain = true := by decide
def e1194672354590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1194672354590 : Closed e1194672354590 ∧ code e1194672354590 = 5592718865694 := by decide
theorem cert_e1194672354590 : check e1194672354590 [[],[.left],[]] .chain = true := by decide
def e1194672354758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1194672354758 : Closed e1194672354758 ∧ code e1194672354758 = 5592718865862 := by decide
theorem cert_e1194672354758 : check e1194672354758 [[],[.left],[]] .chain = true := by decide
def e1194672355098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1194672355098 : Closed e1194672355098 ∧ code e1194672355098 = 5592718866202 := by decide
theorem cert_e1194672355098 : check e1194672355098 [[],[.left],[]] .chain = true := by decide
def e1194672355142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1194672355142 : Closed e1194672355142 ∧ code e1194672355142 = 5592718866246 := by decide
theorem cert_e1194672355142 : check e1194672355142 [[],[.left],[]] .chain = true := by decide
def e1194672355542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1194672355542 : Closed e1194672355542 ∧ code e1194672355542 = 5592718866646 := by decide
theorem cert_e1194672355542 : check e1194672355542 [[],[.left],[]] .chain = true := by decide
def e1194672355546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1194672355546 : Closed e1194672355546 ∧ code e1194672355546 = 5592718866650 := by decide
theorem cert_e1194672355546 : check e1194672355546 [[],[.left],[]] .chain = true := by decide
def e1194672355562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1194672355562 : Closed e1194672355562 ∧ code e1194672355562 = 5592718866666 := by decide
theorem cert_e1194672355562 : check e1194672355562 [[],[.left],[]] .chain = true := by decide
def e1194672355894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1194672355894 : Closed e1194672355894 ∧ code e1194672355894 = 5592718866998 := by decide
theorem cert_e1194672355894 : check e1194672355894 [[],[.left],[]] .chain = true := by decide
def e1194672355898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1194672355898 : Closed e1194672355898 ∧ code e1194672355898 = 5592718867002 := by decide
theorem cert_e1194672355898 : check e1194672355898 [[],[.left],[]] .chain = true := by decide
def e1194672355982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1194672355982 : Closed e1194672355982 ∧ code e1194672355982 = 5592718867086 := by decide
theorem cert_e1194672355982 : check e1194672355982 [[],[.left],[]] .chain = true := by decide
def e1194672356038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1194672356038 : Closed e1194672356038 ∧ code e1194672356038 = 5592718867142 := by decide
theorem cert_e1194672356038 : check e1194672356038 [[],[.left],[]] .chain = true := by decide
def e1194672356122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1194672356122 : Closed e1194672356122 ∧ code e1194672356122 = 5592718867226 := by decide
theorem cert_e1194672356122 : check e1194672356122 [[],[.left],[]] .chain = true := by decide
def e1194672356166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1194672356166 : Closed e1194672356166 ∧ code e1194672356166 = 5592718867270 := by decide
theorem cert_e1194672356166 : check e1194672356166 [[],[.left],[]] .chain = true := by decide
def e1194672360686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1194672360686 : Closed e1194672360686 ∧ code e1194672360686 = 5592718871790 := by decide
theorem cert_e1194672360686 : check e1194672360686 [[],[.left],[]] .chain = true := by decide
def e1194672360694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1194672360694 : Closed e1194672360694 ∧ code e1194672360694 = 5592718871798 := by decide
theorem cert_e1194672360694 : check e1194672360694 [[],[.left],[]] .chain = true := by decide
def e1194672361070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1194672361070 : Closed e1194672361070 ∧ code e1194672361070 = 5592718872174 := by decide
theorem cert_e1194672361070 : check e1194672361070 [[],[.left],[]] .chain = true := by decide
def e1194672361082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1194672361082 : Closed e1194672361082 ∧ code e1194672361082 = 5592718872186 := by decide
theorem cert_e1194672361082 : check e1194672361082 [[],[.left],[]] .chain = true := by decide
def e1194672361270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1194672361270 : Closed e1194672361270 ∧ code e1194672361270 = 5592718872374 := by decide
theorem cert_e1194672361270 : check e1194672361270 [[],[.left],[]] .chain = true := by decide
def e1194672361274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1194672361274 : Closed e1194672361274 ∧ code e1194672361274 = 5592718872378 := by decide
theorem cert_e1194672361274 : check e1194672361274 [[],[.left],[]] .chain = true := by decide
def e1194672363758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1194672363758 : Closed e1194672363758 ∧ code e1194672363758 = 5592718874862 := by decide
theorem cert_e1194672363758 : check e1194672363758 [[],[.left],[]] .chain = true := by decide
def e1194672363766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1194672363766 : Closed e1194672363766 ∧ code e1194672363766 = 5592718874870 := by decide
theorem cert_e1194672363766 : check e1194672363766 [[],[.left],[]] .chain = true := by decide
def e1194672364318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1194672364318 : Closed e1194672364318 ∧ code e1194672364318 = 5592718875422 := by decide
theorem cert_e1194672364318 : check e1194672364318 [[],[.left],[]] .chain = true := by decide
def e1194672364430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1194672364430 : Closed e1194672364430 ∧ code e1194672364430 = 5592718875534 := by decide
theorem cert_e1194672364430 : check e1194672364430 [[],[.left],[]] .chain = true := by decide
def e1194672364654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1194672364654 : Closed e1194672364654 ∧ code e1194672364654 = 5592718875758 := by decide
theorem cert_e1194672364654 : check e1194672364654 [[],[.left],[]] .chain = true := by decide
def e1194672364666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1194672364666 : Closed e1194672364666 ∧ code e1194672364666 = 5592718875770 := by decide
theorem cert_e1194672364666 : check e1194672364666 [[],[.left],[]] .chain = true := by decide
def e1194672364830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1194672364830 : Closed e1194672364830 ∧ code e1194672364830 = 5592718875934 := by decide
theorem cert_e1194672364830 : check e1194672364830 [[],[.left],[]] .chain = true := by decide
def e1194672364998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1194672364998 : Closed e1194672364998 ∧ code e1194672364998 = 5592718876102 := by decide
theorem cert_e1194672364998 : check e1194672364998 [[],[.left],[]] .chain = true := by decide
def e1194672365110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1194672365110 : Closed e1194672365110 ∧ code e1194672365110 = 5592718876214 := by decide
theorem cert_e1194672365110 : check e1194672365110 [[],[.left],[]] .chain = true := by decide
def e1194672365114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1194672365114 : Closed e1194672365114 ∧ code e1194672365114 = 5592718876218 := by decide
theorem cert_e1194672365114 : check e1194672365114 [[],[.left],[]] .chain = true := by decide
def e1194672365198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1194672365198 : Closed e1194672365198 ∧ code e1194672365198 = 5592718876302 := by decide
theorem cert_e1194672365198 : check e1194672365198 [[],[.left],[]] .chain = true := by decide
def e1194672365254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1194672365254 : Closed e1194672365254 ∧ code e1194672365254 = 5592718876358 := by decide
theorem cert_e1194672365254 : check e1194672365254 [[],[.left],[]] .chain = true := by decide
def e1194672367390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1194672367390 : Closed e1194672367390 ∧ code e1194672367390 = 5592718878494 := by decide
theorem cert_e1194672367390 : check e1194672367390 [[],[.left],[]] .chain = true := by decide
def e1194672367502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1194672367502 : Closed e1194672367502 ∧ code e1194672367502 = 5592718878606 := by decide
theorem cert_e1194672367502 : check e1194672367502 [[],[.left],[]] .chain = true := by decide
def e1194672370462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1194672370462 : Closed e1194672370462 ∧ code e1194672370462 = 5592718881566 := by decide
theorem cert_e1194672370462 : check e1194672370462 [[],[.left],[]] .chain = true := by decide
def e1194672370630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1194672370630 : Closed e1194672370630 ∧ code e1194672370630 = 5592718881734 := by decide
theorem cert_e1194672370630 : check e1194672370630 [[],[.left],[]] .chain = true := by decide
def e1194672372110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1194672372110 : Closed e1194672372110 ∧ code e1194672372110 = 5592718883214 := by decide
theorem cert_e1194672372110 : check e1194672372110 [[],[.left],[]] .chain = true := by decide
def e1194672372166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1194672372166 : Closed e1194672372166 ∧ code e1194672372166 = 5592718883270 := by decide
theorem cert_e1194672372166 : check e1194672372166 [[],[.left],[]] .chain = true := by decide
def e1194672375406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1194672375406 : Closed e1194672375406 ∧ code e1194672375406 = 5592718886510 := by decide
theorem cert_e1194672375406 : check e1194672375406 [[],[.left],[]] .chain = true := by decide
def e1194672375418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1194672375418 : Closed e1194672375418 ∧ code e1194672375418 = 5592718886522 := by decide
theorem cert_e1194672375418 : check e1194672375418 [[],[.left],[]] .chain = true := by decide
def e1194672375706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1194672375706 : Closed e1194672375706 ∧ code e1194672375706 = 5592718886810 := by decide
theorem cert_e1194672375706 : check e1194672375706 [[],[.left],[]] .chain = true := by decide
def e1194672376942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1194672376942 : Closed e1194672376942 ∧ code e1194672376942 = 5592718888046 := by decide
theorem cert_e1194672376942 : check e1194672376942 [[],[.left],[]] .chain = true := by decide
def e1194672376954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1194672376954 : Closed e1194672376954 ∧ code e1194672376954 = 5592718888058 := by decide
theorem cert_e1194672376954 : check e1194672376954 [[],[.left],[]] .chain = true := by decide
def e1194672377118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1194672377118 : Closed e1194672377118 ∧ code e1194672377118 = 5592718888222 := by decide
theorem cert_e1194672377118 : check e1194672377118 [[],[.left],[]] .chain = true := by decide
def e1194672377286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1194672377286 : Closed e1194672377286 ∧ code e1194672377286 = 5592718888390 := by decide
theorem cert_e1194672377286 : check e1194672377286 [[],[.left],[]] .chain = true := by decide
def e1194672377626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1194672377626 : Closed e1194672377626 ∧ code e1194672377626 = 5592718888730 := by decide
theorem cert_e1194672377626 : check e1194672377626 [[],[.left],[]] .chain = true := by decide
def e1194672377670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1194672377670 : Closed e1194672377670 ∧ code e1194672377670 = 5592718888774 := by decide
theorem cert_e1194672377670 : check e1194672377670 [[],[.left],[]] .chain = true := by decide
def e1194672378654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1194672378654 : Closed e1194672378654 ∧ code e1194672378654 = 5592718889758 := by decide
theorem cert_e1194672378654 : check e1194672378654 [[],[.left],[]] .chain = true := by decide
def e1194672378822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1194672378822 : Closed e1194672378822 ∧ code e1194672378822 = 5592718889926 := by decide
theorem cert_e1194672378822 : check e1194672378822 [[],[.left],[]] .chain = true := by decide
def e1194672381126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1194672381126 : Closed e1194672381126 ∧ code e1194672381126 = 5592718892230 := by decide
theorem cert_e1194672381126 : check e1194672381126 [[],[.left],[]] .chain = true := by decide
def e1194672382774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1194672382774 : Closed e1194672382774 ∧ code e1194672382774 = 5592718893878 := by decide
theorem cert_e1194672382774 : check e1194672382774 [[],[.left],[]] .chain = true := by decide
def e1194672382778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1194672382778 : Closed e1194672382778 ∧ code e1194672382778 = 5592718893882 := by decide
theorem cert_e1194672382778 : check e1194672382778 [[],[.left],[]] .chain = true := by decide
def e1194672382874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1194672382874 : Closed e1194672382874 ∧ code e1194672382874 = 5592718893978 := by decide
theorem cert_e1194672382874 : check e1194672382874 [[],[.left],[]] .chain = true := by decide
def e1194672383542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1194672383542 : Closed e1194672383542 ∧ code e1194672383542 = 5592718894646 := by decide
theorem cert_e1194672383542 : check e1194672383542 [[],[.left],[]] .chain = true := by decide
def e1194672383546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1194672383546 : Closed e1194672383546 ∧ code e1194672383546 = 5592718894650 := by decide
theorem cert_e1194672383546 : check e1194672383546 [[],[.left],[]] .chain = true := by decide
def e1194672383630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1194672383630 : Closed e1194672383630 ∧ code e1194672383630 = 5592718894734 := by decide
theorem cert_e1194672383630 : check e1194672383630 [[],[.left],[]] .chain = true := by decide
def e1194672383686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1194672383686 : Closed e1194672383686 ∧ code e1194672383686 = 5592718894790 := by decide
theorem cert_e1194672383686 : check e1194672383686 [[],[.left],[]] .chain = true := by decide
def e1194672383770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1194672383770 : Closed e1194672383770 ∧ code e1194672383770 = 5592718894874 := by decide
theorem cert_e1194672383770 : check e1194672383770 [[],[.left],[]] .chain = true := by decide
def e1194672383814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1194672383814 : Closed e1194672383814 ∧ code e1194672383814 = 5592718894918 := by decide
theorem cert_e1194672383814 : check e1194672383814 [[],[.left],[]] .chain = true := by decide
def e1194672384398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1194672384398 : Closed e1194672384398 ∧ code e1194672384398 = 5592718895502 := by decide
theorem cert_e1194672384398 : check e1194672384398 [[],[.left],[]] .chain = true := by decide
def e1194672384454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1194672384454 : Closed e1194672384454 ∧ code e1194672384454 = 5592718895558 := by decide
theorem cert_e1194672384454 : check e1194672384454 [[],[.left],[]] .chain = true := by decide
def e1194672385222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1194672385222 : Closed e1194672385222 ∧ code e1194672385222 = 5592718896326 := by decide
theorem cert_e1194672385222 : check e1194672385222 [[],[.left],[]] .chain = true := by decide
def e1194672395998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1194672395998 : Closed e1194672395998 ∧ code e1194672395998 = 5592718907102 := by decide
theorem cert_e1194672395998 : check e1194672395998 [[],[.left],[]] .smaller = true := by decide
def e1194672396022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1194672396022 : Closed e1194672396022 ∧ code e1194672396022 = 5592718907126 := by decide
theorem cert_e1194672396022 : check e1194672396022 [[],[.left],[]] .smaller = true := by decide
def e1194672396126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1194672396126 : Closed e1194672396126 ∧ code e1194672396126 = 5592718907230 := by decide
theorem cert_e1194672396126 : check e1194672396126 [[],[.left],[]] .smaller = true := by decide
def e1194672396154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1194672396154 : Closed e1194672396154 ∧ code e1194672396154 = 5592718907258 := by decide
theorem cert_e1194672396154 : check e1194672396154 [[],[.left],[]] .smaller = true := by decide
def e1194672396246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1194672396246 : Closed e1194672396246 ∧ code e1194672396246 = 5592718907350 := by decide
theorem cert_e1194672396246 : check e1194672396246 [[],[.left],[]] .smaller = true := by decide
def e1194672396250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1194672396250 : Closed e1194672396250 ∧ code e1194672396250 = 5592718907354 := by decide
theorem cert_e1194672396250 : check e1194672396250 [[],[.left],[]] .smaller = true := by decide
def e1194672396766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1194672396766 : Closed e1194672396766 ∧ code e1194672396766 = 5592718907870 := by decide
theorem cert_e1194672396766 : check e1194672396766 [[],[.left],[]] .smaller = true := by decide
def e1194672396790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1194672396790 : Closed e1194672396790 ∧ code e1194672396790 = 5592718907894 := by decide
theorem cert_e1194672396790 : check e1194672396790 [[],[.left],[]] .smaller = true := by decide
def e1194672397534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1194672397534 : Closed e1194672397534 ∧ code e1194672397534 = 5592718908638 := by decide
theorem cert_e1194672397534 : check e1194672397534 [[],[.left],[]] .smaller = true := by decide
def e1194672397562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1194672397562 : Closed e1194672397562 ∧ code e1194672397562 = 5592718908666 := by decide
theorem cert_e1194672397562 : check e1194672397562 [[],[.left],[]] .smaller = true := by decide
def e1194672398134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672398134 : Closed e1194672398134 ∧ code e1194672398134 = 5592718909238 := by decide
theorem cert_e1194672398134 : check e1194672398134 [[],[.left],[]] .smaller = true := by decide
def e1194672398138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672398138 : Closed e1194672398138 ∧ code e1194672398138 = 5592718909242 := by decide
theorem cert_e1194672398138 : check e1194672398138 [[],[.left],[]] .smaller = true := by decide
def e1194672412910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1194672412910 : Closed e1194672412910 ∧ code e1194672412910 = 5592718924014 := by decide
theorem cert_e1194672412910 : check e1194672412910 [[],[.left],[]] .chain = true := by decide
def e1194672412918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1194672412918 : Closed e1194672412918 ∧ code e1194672412918 = 5592718924022 := by decide
theorem cert_e1194672412918 : check e1194672412918 [[],[.left],[]] .chain = true := by decide
def e1194672413470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1194672413470 : Closed e1194672413470 ∧ code e1194672413470 = 5592718924574 := by decide
theorem cert_e1194672413470 : check e1194672413470 [[],[.left],[]] .chain = true := by decide
def e1194672413582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1194672413582 : Closed e1194672413582 ∧ code e1194672413582 = 5592718924686 := by decide
theorem cert_e1194672413582 : check e1194672413582 [[],[.left],[]] .chain = true := by decide
def e1194672413806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1194672413806 : Closed e1194672413806 ∧ code e1194672413806 = 5592718924910 := by decide
theorem cert_e1194672413806 : check e1194672413806 [[],[.left],[]] .chain = true := by decide
def e1194672413818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1194672413818 : Closed e1194672413818 ∧ code e1194672413818 = 5592718924922 := by decide
theorem cert_e1194672413818 : check e1194672413818 [[],[.left],[]] .chain = true := by decide
def e1194672413982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1194672413982 : Closed e1194672413982 ∧ code e1194672413982 = 5592718925086 := by decide
theorem cert_e1194672413982 : check e1194672413982 [[],[.left],[]] .chain = true := by decide
def e1194672414150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1194672414150 : Closed e1194672414150 ∧ code e1194672414150 = 5592718925254 := by decide
theorem cert_e1194672414150 : check e1194672414150 [[],[.left],[]] .chain = true := by decide
def e1194672414262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1194672414262 : Closed e1194672414262 ∧ code e1194672414262 = 5592718925366 := by decide
theorem cert_e1194672414262 : check e1194672414262 [[],[.left],[]] .chain = true := by decide
def e1194672414266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1194672414266 : Closed e1194672414266 ∧ code e1194672414266 = 5592718925370 := by decide
theorem cert_e1194672414266 : check e1194672414266 [[],[.left],[]] .chain = true := by decide
def e1194672414350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1194672414350 : Closed e1194672414350 ∧ code e1194672414350 = 5592718925454 := by decide
theorem cert_e1194672414350 : check e1194672414350 [[],[.left],[]] .chain = true := by decide
def e1194672414406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1194672414406 : Closed e1194672414406 ∧ code e1194672414406 = 5592718925510 := by decide
theorem cert_e1194672414406 : check e1194672414406 [[],[.left],[]] .chain = true := by decide
def e1194672416542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1194672416542 : Closed e1194672416542 ∧ code e1194672416542 = 5592718927646 := by decide
theorem cert_e1194672416542 : check e1194672416542 [[],[.left],[]] .chain = true := by decide
def e1194672416654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1194672416654 : Closed e1194672416654 ∧ code e1194672416654 = 5592718927758 := by decide
theorem cert_e1194672416654 : check e1194672416654 [[],[.left],[]] .chain = true := by decide
def e1194672419614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1194672419614 : Closed e1194672419614 ∧ code e1194672419614 = 5592718930718 := by decide
theorem cert_e1194672419614 : check e1194672419614 [[],[.left],[]] .chain = true := by decide
def e1194672419782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1194672419782 : Closed e1194672419782 ∧ code e1194672419782 = 5592718930886 := by decide
theorem cert_e1194672419782 : check e1194672419782 [[],[.left],[]] .chain = true := by decide
def e1194672421262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1194672421262 : Closed e1194672421262 ∧ code e1194672421262 = 5592718932366 := by decide
theorem cert_e1194672421262 : check e1194672421262 [[],[.left],[]] .chain = true := by decide
def e1194672421318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1194672421318 : Closed e1194672421318 ∧ code e1194672421318 = 5592718932422 := by decide
theorem cert_e1194672421318 : check e1194672421318 [[],[.left],[]] .chain = true := by decide
def e1194672458606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1194672458606 : Closed e1194672458606 ∧ code e1194672458606 = 5592718969710 := by decide
theorem cert_e1194672458606 : check e1194672458606 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1194672458614 : Closed e1194672458614 ∧ code e1194672458614 = 5592718969718 := by decide
theorem cert_e1194672458614 : check e1194672458614 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1194672458670 : Closed e1194672458670 ∧ code e1194672458670 = 5592718969774 := by decide
theorem cert_e1194672458670 : check e1194672458670 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1194672458682 : Closed e1194672458682 ∧ code e1194672458682 = 5592718969786 := by decide
theorem cert_e1194672458682 : check e1194672458682 [[],[.left],[],[.under]] .smaller = true := by decide
end Blc.Floor42
