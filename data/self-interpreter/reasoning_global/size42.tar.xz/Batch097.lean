import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1204537790062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204537790062 : Closed e1204537790062 ∧ code e1204537790062 = 5602584301166 := by decide
theorem cert_e1204537790062 : check e1204537790062 [[],[]] .smaller = true := by decide
def e1204537790074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204537790074 : Closed e1204537790074 ∧ code e1204537790074 = 5602584301178 := by decide
theorem cert_e1204537790074 : check e1204537790074 [[],[]] .smaller = true := by decide
def e1204537790262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204537790262 : Closed e1204537790262 ∧ code e1204537790262 = 5602584301366 := by decide
theorem cert_e1204537790262 : check e1204537790262 [[],[]] .smaller = true := by decide
def e1204537790266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204537790266 : Closed e1204537790266 ∧ code e1204537790266 = 5602584301370 := by decide
theorem cert_e1204537790266 : check e1204537790266 [[],[]] .smaller = true := by decide
def e1204570643310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1204570643310 : Closed e1204570643310 ∧ code e1204570643310 = 5602617154414 := by decide
theorem cert_e1204570643310 : check e1204570643310 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1204570643318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1204570643318 : Closed e1204570643318 ∧ code e1204570643318 = 5602617154422 := by decide
theorem cert_e1204570643318 : check e1204570643318 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1204570643382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1204570643382 : Closed e1204570643382 ∧ code e1204570643382 = 5602617154486 := by decide
theorem cert_e1204570643382 : check e1204570643382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1204570643822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1204570643822 : Closed e1204570643822 ∧ code e1204570643822 = 5602617154926 := by decide
theorem cert_e1204570643822 : check e1204570643822 [[],[]] .sourceHead = true := by decide
def e1204570643830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1204570643830 : Closed e1204570643830 ∧ code e1204570643830 = 5602617154934 := by decide
theorem cert_e1204570643830 : check e1204570643830 [[],[]] .sourceHead = true := by decide
def e1204570643886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1204570643886 : Closed e1204570643886 ∧ code e1204570643886 = 5602617154990 := by decide
theorem cert_e1204570643886 : check e1204570643886 [[],[]] .sourceHead = true := by decide
def e1204570643898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1204570643898 : Closed e1204570643898 ∧ code e1204570643898 = 5602617155002 := by decide
theorem cert_e1204570643898 : check e1204570643898 [[],[]] .sourceHead = true := by decide
def e1204570643926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1204570643926 : Closed e1204570643926 ∧ code e1204570643926 = 5602617155030 := by decide
theorem cert_e1204570643926 : check e1204570643926 [[],[]] .sourceHead = true := by decide
def e1204570643930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1204570643930 : Closed e1204570643930 ∧ code e1204570643930 = 5602617155034 := by decide
theorem cert_e1204570643930 : check e1204570643930 [[],[]] .sourceHead = true := by decide
def e1204570644150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1204570644150 : Closed e1204570644150 ∧ code e1204570644150 = 5602617155254 := by decide
theorem cert_e1204570644150 : check e1204570644150 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204570644182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1204570644182 : Closed e1204570644182 ∧ code e1204570644182 = 5602617155286 := by decide
theorem cert_e1204570644182 : check e1204570644182 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204570644186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1204570644186 : Closed e1204570644186 ∧ code e1204570644186 = 5602617155290 := by decide
theorem cert_e1204570644186 : check e1204570644186 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204570646382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1204570646382 : Closed e1204570646382 ∧ code e1204570646382 = 5602617157486 := by decide
theorem cert_e1204570646382 : check e1204570646382 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204570646390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1204570646390 : Closed e1204570646390 ∧ code e1204570646390 = 5602617157494 := by decide
theorem cert_e1204570646390 : check e1204570646390 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204570646454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1204570646454 : Closed e1204570646454 ∧ code e1204570646454 = 5602617157558 := by decide
theorem cert_e1204570646454 : check e1204570646454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204570647790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204570647790 : Closed e1204570647790 ∧ code e1204570647790 = 5602617158894 := by decide
theorem cert_e1204570647790 : check e1204570647790 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204570647798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204570647798 : Closed e1204570647798 ∧ code e1204570647798 = 5602617158902 := by decide
theorem cert_e1204570647798 : check e1204570647798 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204570648182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1204570648182 : Closed e1204570648182 ∧ code e1204570648182 = 5602617159286 := by decide
theorem cert_e1204570648182 : check e1204570648182 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204570649454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1204570649454 : Closed e1204570649454 ∧ code e1204570649454 = 5602617160558 := by decide
theorem cert_e1204570649454 : checkPay e1204570649454 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1204570649462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1204570649462 : Closed e1204570649462 ∧ code e1204570649462 = 5602617160566 := by decide
theorem cert_e1204570649462 : checkPay e1204570649462 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e1204570649518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1204570649518 : Closed e1204570649518 ∧ code e1204570649518 = 5602617160622 := by decide
theorem cert_e1204570649518 : checkPay e1204570649518 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204570649530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1204570649530 : Closed e1204570649530 ∧ code e1204570649530 = 5602617160634 := by decide
theorem cert_e1204570649530 : checkPay e1204570649530 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.under]] = true := by decide
def e1204570649558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1204570649558 : Closed e1204570649558 ∧ code e1204570649558 = 5602617160662 := by decide
theorem cert_e1204570649558 : checkPay e1204570649558 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.under,.under,.left,.right]] = true := by decide
def e1204570649562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1204570649562 : Closed e1204570649562 ∧ code e1204570649562 = 5602617160666 := by decide
theorem cert_e1204570649562 : checkPay e1204570649562 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.under,.under,.left,.right]] = true := by decide
def e1204570649838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204570649838 : Closed e1204570649838 ∧ code e1204570649838 = 5602617160942 := by decide
theorem cert_e1204570649838 : checkPay e1204570649838 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204570649846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204570649846 : Closed e1204570649846 ∧ code e1204570649846 = 5602617160950 := by decide
theorem cert_e1204570649846 : checkPay e1204570649846 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204570650222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204570650222 : Closed e1204570650222 ∧ code e1204570650222 = 5602617161326 := by decide
theorem cert_e1204570650222 : checkPay e1204570650222 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204570650234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204570650234 : Closed e1204570650234 ∧ code e1204570650234 = 5602617161338 := by decide
theorem cert_e1204570650234 : checkPay e1204570650234 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204570650422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204570650422 : Closed e1204570650422 ∧ code e1204570650422 = 5602617161526 := by decide
theorem cert_e1204570650422 : checkPay e1204570650422 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1204570650426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204570650426 : Closed e1204570650426 ∧ code e1204570650426 = 5602617161530 := by decide
theorem cert_e1204570650426 : checkPay e1204570650426 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1204570651062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1204570651062 : Closed e1204570651062 ∧ code e1204570651062 = 5602617162166 := by decide
theorem cert_e1204570651062 : check e1204570651062 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570651094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1204570651094 : Closed e1204570651094 ∧ code e1204570651094 = 5602617162198 := by decide
theorem cert_e1204570651094 : check e1204570651094 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570651098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1204570651098 : Closed e1204570651098 ∧ code e1204570651098 = 5602617162202 := by decide
theorem cert_e1204570651098 : check e1204570651098 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570651254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1204570651254 : Closed e1204570651254 ∧ code e1204570651254 = 5602617162358 := by decide
theorem cert_e1204570651254 : check e1204570651254 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570651446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204570651446 : Closed e1204570651446 ∧ code e1204570651446 = 5602617162550 := by decide
theorem cert_e1204570651446 : check e1204570651446 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570651450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204570651450 : Closed e1204570651450 ∧ code e1204570651450 = 5602617162554 := by decide
theorem cert_e1204570651450 : check e1204570651450 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204570658670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1204570658670 : Closed e1204570658670 ∧ code e1204570658670 = 5602617169774 := by decide
theorem cert_e1204570658670 : check e1204570658670 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204570658678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1204570658678 : Closed e1204570658678 ∧ code e1204570658678 = 5602617169782 := by decide
theorem cert_e1204570658678 : check e1204570658678 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204570658742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1204570658742 : Closed e1204570658742 ∧ code e1204570658742 = 5602617169846 := by decide
theorem cert_e1204570658742 : check e1204570658742 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1204570660078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1204570660078 : Closed e1204570660078 ∧ code e1204570660078 = 5602617171182 := by decide
theorem cert_e1204570660078 : check e1204570660078 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204570660086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1204570660086 : Closed e1204570660086 ∧ code e1204570660086 = 5602617171190 := by decide
theorem cert_e1204570660086 : check e1204570660086 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204570660470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1204570660470 : Closed e1204570660470 ∧ code e1204570660470 = 5602617171574 := by decide
theorem cert_e1204570660470 : check e1204570660470 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204570671982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204570671982 : Closed e1204570671982 ∧ code e1204570671982 = 5602617183086 := by decide
theorem cert_e1204570671982 : check e1204570671982 [[],[]] .sourceHead = true := by decide
def e1204570671990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204570671990 : Closed e1204570671990 ∧ code e1204570671990 = 5602617183094 := by decide
theorem cert_e1204570671990 : check e1204570671990 [[],[]] .sourceHead = true := by decide
def e1204570672046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204570672046 : Closed e1204570672046 ∧ code e1204570672046 = 5602617183150 := by decide
theorem cert_e1204570672046 : check e1204570672046 [[],[]] .sourceHead = true := by decide
def e1204570672058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204570672058 : Closed e1204570672058 ∧ code e1204570672058 = 5602617183162 := by decide
theorem cert_e1204570672058 : check e1204570672058 [[],[]] .sourceHead = true := by decide
def e1204570672086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204570672086 : Closed e1204570672086 ∧ code e1204570672086 = 5602617183190 := by decide
theorem cert_e1204570672086 : check e1204570672086 [[],[]] .sourceHead = true := by decide
def e1204570672090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204570672090 : Closed e1204570672090 ∧ code e1204570672090 = 5602617183194 := by decide
theorem cert_e1204570672090 : check e1204570672090 [[],[]] .sourceHead = true := by decide
def e1204570672366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204570672366 : Closed e1204570672366 ∧ code e1204570672366 = 5602617183470 := by decide
theorem cert_e1204570672366 : check e1204570672366 [[],[]] .sourceHead = true := by decide
def e1204570672374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204570672374 : Closed e1204570672374 ∧ code e1204570672374 = 5602617183478 := by decide
theorem cert_e1204570672374 : check e1204570672374 [[],[]] .sourceHead = true := by decide
def e1204570672750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204570672750 : Closed e1204570672750 ∧ code e1204570672750 = 5602617183854 := by decide
theorem cert_e1204570672750 : check e1204570672750 [[],[]] .sourceHead = true := by decide
def e1204570672762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204570672762 : Closed e1204570672762 ∧ code e1204570672762 = 5602617183866 := by decide
theorem cert_e1204570672762 : check e1204570672762 [[],[]] .sourceHead = true := by decide
def e1204570672950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204570672950 : Closed e1204570672950 ∧ code e1204570672950 = 5602617184054 := by decide
theorem cert_e1204570672950 : check e1204570672950 [[],[]] .sourceHead = true := by decide
def e1204570672954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204570672954 : Closed e1204570672954 ∧ code e1204570672954 = 5602617184058 := by decide
theorem cert_e1204570672954 : check e1204570672954 [[],[]] .sourceHead = true := by decide
def e1204570678710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1204570678710 : Closed e1204570678710 ∧ code e1204570678710 = 5602617189814 := by decide
theorem cert_e1204570678710 : check e1204570678710 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204570678742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1204570678742 : Closed e1204570678742 ∧ code e1204570678742 = 5602617189846 := by decide
theorem cert_e1204570678742 : check e1204570678742 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204570678746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1204570678746 : Closed e1204570678746 ∧ code e1204570678746 = 5602617189850 := by decide
theorem cert_e1204570678746 : check e1204570678746 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204570678902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1204570678902 : Closed e1204570678902 ∧ code e1204570678902 = 5602617190006 := by decide
theorem cert_e1204570678902 : check e1204570678902 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204570679094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1204570679094 : Closed e1204570679094 ∧ code e1204570679094 = 5602617190198 := by decide
theorem cert_e1204570679094 : check e1204570679094 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204570679098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1204570679098 : Closed e1204570679098 ∧ code e1204570679098 = 5602617190202 := by decide
theorem cert_e1204570679098 : check e1204570679098 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204571016046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204571016046 : Closed e1204571016046 ∧ code e1204571016046 = 5602617527150 := by decide
theorem cert_e1204571016046 : check e1204571016046 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204571016054 : Closed e1204571016054 ∧ code e1204571016054 = 5602617527158 := by decide
private def t_e1204571016054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1204571016054 : ¬ IsSelfInterpreter e1204571016054 :=
  wSource (t := t_e1204571016054) (replay_sound (ps := []) (t := e1204571016054) (by decide)) (by decide)
def e1204571016110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204571016110 : Closed e1204571016110 ∧ code e1204571016110 = 5602617527214 := by decide
theorem cert_e1204571016110 : check e1204571016110 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204571016122 : Closed e1204571016122 ∧ code e1204571016122 = 5602617527226 := by decide
theorem cert_e1204571016122 : check e1204571016122 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204571016150 : Closed e1204571016150 ∧ code e1204571016150 = 5602617527254 := by decide
private def t_e1204571016150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1204571016150 : ¬ IsSelfInterpreter e1204571016150 :=
  wSource (t := t_e1204571016150) (replay_sound (ps := []) (t := e1204571016150) (by decide)) (by decide)
def e1204571016154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204571016154 : Closed e1204571016154 ∧ code e1204571016154 = 5602617527258 := by decide
theorem cert_e1204571016154 : check e1204571016154 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204571016430 : Closed e1204571016430 ∧ code e1204571016430 = 5602617527534 := by decide
theorem cert_e1204571016430 : check e1204571016430 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204571016438 : Closed e1204571016438 ∧ code e1204571016438 = 5602617527542 := by decide
theorem cert_e1204571016438 : check e1204571016438 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204571016814 : Closed e1204571016814 ∧ code e1204571016814 = 5602617527918 := by decide
theorem cert_e1204571016814 : check e1204571016814 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571016826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204571016826 : Closed e1204571016826 ∧ code e1204571016826 = 5602617527930 := by decide
theorem cert_e1204571016826 : check e1204571016826 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571017014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204571017014 : Closed e1204571017014 ∧ code e1204571017014 = 5602617528118 := by decide
theorem cert_e1204571017014 : check e1204571017014 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1204571017018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204571017018 : Closed e1204571017018 ∧ code e1204571017018 = 5602617528122 := by decide
theorem cert_e1204571017018 : check e1204571017018 [[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e1205812112750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1205812112750 : Closed e1205812112750 ∧ code e1205812112750 = 5603858623854 := by decide
theorem cert_e1205812112750 : check e1205812112750 [[],[]] .smaller = true := by decide
def e1205812112758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1205812112758 : Closed e1205812112758 ∧ code e1205812112758 = 5603858623862 := by decide
theorem cert_e1205812112758 : check e1205812112758 [[],[]] .smaller = true := by decide
def e1205812112814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1205812112814 : Closed e1205812112814 ∧ code e1205812112814 = 5603858623918 := by decide
theorem cert_e1205812112814 : check e1205812112814 [[],[]] .smaller = true := by decide
def e1205812112826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1205812112826 : Closed e1205812112826 ∧ code e1205812112826 = 5603858623930 := by decide
theorem cert_e1205812112826 : check e1205812112826 [[],[]] .smaller = true := by decide
def e1205812112854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1205812112854 : Closed e1205812112854 ∧ code e1205812112854 = 5603858623958 := by decide
theorem cert_e1205812112854 : check e1205812112854 [[],[]] .smaller = true := by decide
def e1205812112858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1205812112858 : Closed e1205812112858 ∧ code e1205812112858 = 5603858623962 := by decide
theorem cert_e1205812112858 : check e1205812112858 [[],[]] .smaller = true := by decide
def e1205812113070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1205812113070 : Closed e1205812113070 ∧ code e1205812113070 = 5603858624174 := by decide
theorem cert_e1205812113070 : check e1205812113070 [[],[]] .smaller = true := by decide
def e1205812113082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1205812113082 : Closed e1205812113082 ∧ code e1205812113082 = 5603858624186 := by decide
theorem cert_e1205812113082 : check e1205812113082 [[],[]] .smaller = true := by decide
def e1205812113130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1205812113130 : Closed e1205812113130 ∧ code e1205812113130 = 5603858624234 := by decide
theorem cert_e1205812113130 : check e1205812113130 [[],[]] .smaller = true := by decide
def e1205812113238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1205812113238 : Closed e1205812113238 ∧ code e1205812113238 = 5603858624342 := by decide
theorem cert_e1205812113238 : check e1205812113238 [[],[]] .smaller = true := by decide
def e1205812113242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1205812113242 : Closed e1205812113242 ∧ code e1205812113242 = 5603858624346 := by decide
theorem cert_e1205812113242 : check e1205812113242 [[],[]] .smaller = true := by decide
def e1205812113258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1205812113258 : Closed e1205812113258 ∧ code e1205812113258 = 5603858624362 := by decide
theorem cert_e1205812113258 : check e1205812113258 [[],[]] .smaller = true := by decide
def e1205812114286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1205812114286 : Closed e1205812114286 ∧ code e1205812114286 = 5603858625390 := by decide
theorem cert_e1205812114286 : check e1205812114286 [[],[]] .smaller = true := by decide
def e1205812114294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1205812114294 : Closed e1205812114294 ∧ code e1205812114294 = 5603858625398 := by decide
theorem cert_e1205812114294 : check e1205812114294 [[],[]] .smaller = true := by decide
def e1205812114350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1205812114350 : Closed e1205812114350 ∧ code e1205812114350 = 5603858625454 := by decide
theorem cert_e1205812114350 : check e1205812114350 [[],[]] .smaller = true := by decide
def e1205812114362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1205812114362 : Closed e1205812114362 ∧ code e1205812114362 = 5603858625466 := by decide
theorem cert_e1205812114362 : check e1205812114362 [[],[]] .smaller = true := by decide
def e1205812114390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1205812114390 : Closed e1205812114390 ∧ code e1205812114390 = 5603858625494 := by decide
theorem cert_e1205812114390 : check e1205812114390 [[],[]] .smaller = true := by decide
def e1205812114394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1205812114394 : Closed e1205812114394 ∧ code e1205812114394 = 5603858625498 := by decide
theorem cert_e1205812114394 : check e1205812114394 [[],[]] .smaller = true := by decide
def e1205812114670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205812114670 : Closed e1205812114670 ∧ code e1205812114670 = 5603858625774 := by decide
theorem cert_e1205812114670 : check e1205812114670 [[],[]] .smaller = true := by decide
def e1205812114678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205812114678 : Closed e1205812114678 ∧ code e1205812114678 = 5603858625782 := by decide
theorem cert_e1205812114678 : check e1205812114678 [[],[]] .smaller = true := by decide
def e1205812115054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812115054 : Closed e1205812115054 ∧ code e1205812115054 = 5603858626158 := by decide
theorem cert_e1205812115054 : check e1205812115054 [[],[]] .smaller = true := by decide
def e1205812115066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812115066 : Closed e1205812115066 ∧ code e1205812115066 = 5603858626170 := by decide
theorem cert_e1205812115066 : check e1205812115066 [[],[]] .smaller = true := by decide
def e1205812115254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812115254 : Closed e1205812115254 ∧ code e1205812115254 = 5603858626358 := by decide
theorem cert_e1205812115254 : check e1205812115254 [[],[]] .smaller = true := by decide
def e1205812115258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812115258 : Closed e1205812115258 ∧ code e1205812115258 = 5603858626362 := by decide
theorem cert_e1205812115258 : check e1205812115258 [[],[]] .smaller = true := by decide
def e1205812115886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1205812115886 : Closed e1205812115886 ∧ code e1205812115886 = 5603858626990 := by decide
theorem cert_e1205812115886 : check e1205812115886 [[],[]] .smaller = true := by decide
def e1205812115898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1205812115898 : Closed e1205812115898 ∧ code e1205812115898 = 5603858627002 := by decide
theorem cert_e1205812115898 : check e1205812115898 [[],[]] .smaller = true := by decide
def e1205812115946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1205812115946 : Closed e1205812115946 ∧ code e1205812115946 = 5603858627050 := by decide
theorem cert_e1205812115946 : check e1205812115946 [[],[]] .smaller = true := by decide
def e1205812116078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205812116078 : Closed e1205812116078 ∧ code e1205812116078 = 5603858627182 := by decide
theorem cert_e1205812116078 : check e1205812116078 [[],[]] .smaller = true := by decide
def e1205812116090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205812116090 : Closed e1205812116090 ∧ code e1205812116090 = 5603858627194 := by decide
theorem cert_e1205812116090 : check e1205812116090 [[],[]] .smaller = true := by decide
def e1205812116378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812116378 : Closed e1205812116378 ∧ code e1205812116378 = 5603858627482 := by decide
theorem cert_e1205812116378 : check e1205812116378 [[],[]] .smaller = true := by decide
def e1205812116694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1205812116694 : Closed e1205812116694 ∧ code e1205812116694 = 5603858627798 := by decide
theorem cert_e1205812116694 : check e1205812116694 [[],[]] .smaller = true := by decide
def e1205812116698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1205812116698 : Closed e1205812116698 ∧ code e1205812116698 = 5603858627802 := by decide
theorem cert_e1205812116698 : check e1205812116698 [[],[]] .smaller = true := by decide
def e1205812116714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1205812116714 : Closed e1205812116714 ∧ code e1205812116714 = 5603858627818 := by decide
theorem cert_e1205812116714 : check e1205812116714 [[],[]] .smaller = true := by decide
def e1205812116790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205812116790 : Closed e1205812116790 ∧ code e1205812116790 = 5603858627894 := by decide
theorem cert_e1205812116790 : check e1205812116790 [[],[]] .smaller = true := by decide
def e1205812116794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205812116794 : Closed e1205812116794 ∧ code e1205812116794 = 5603858627898 := by decide
theorem cert_e1205812116794 : check e1205812116794 [[],[]] .smaller = true := by decide
def e1205812116890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205812116890 : Closed e1205812116890 ∧ code e1205812116890 = 5603858627994 := by decide
theorem cert_e1205812116890 : check e1205812116890 [[],[]] .smaller = true := by decide
def e1205812120430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1205812120430 : Closed e1205812120430 ∧ code e1205812120430 = 5603858631534 := by decide
theorem cert_e1205812120430 : check e1205812120430 [[],[]] .smaller = true := by decide
def e1205812120438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1205812120438 : Closed e1205812120438 ∧ code e1205812120438 = 5603858631542 := by decide
theorem cert_e1205812120438 : check e1205812120438 [[],[]] .smaller = true := by decide
def e1205812120494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1205812120494 : Closed e1205812120494 ∧ code e1205812120494 = 5603858631598 := by decide
theorem cert_e1205812120494 : check e1205812120494 [[],[]] .smaller = true := by decide
def e1205812120506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1205812120506 : Closed e1205812120506 ∧ code e1205812120506 = 5603858631610 := by decide
theorem cert_e1205812120506 : check e1205812120506 [[],[]] .smaller = true := by decide
def e1205812120534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1205812120534 : Closed e1205812120534 ∧ code e1205812120534 = 5603858631638 := by decide
theorem cert_e1205812120534 : check e1205812120534 [[],[]] .smaller = true := by decide
def e1205812120538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1205812120538 : Closed e1205812120538 ∧ code e1205812120538 = 5603858631642 := by decide
theorem cert_e1205812120538 : check e1205812120538 [[],[]] .smaller = true := by decide
def e1205812120814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1205812120814 : Closed e1205812120814 ∧ code e1205812120814 = 5603858631918 := by decide
theorem cert_e1205812120814 : check e1205812120814 [[],[]] .smaller = true := by decide
def e1205812120822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1205812120822 : Closed e1205812120822 ∧ code e1205812120822 = 5603858631926 := by decide
theorem cert_e1205812120822 : check e1205812120822 [[],[]] .smaller = true := by decide
def e1205812121198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1205812121198 : Closed e1205812121198 ∧ code e1205812121198 = 5603858632302 := by decide
theorem cert_e1205812121198 : check e1205812121198 [[],[]] .smaller = true := by decide
def e1205812121210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1205812121210 : Closed e1205812121210 ∧ code e1205812121210 = 5603858632314 := by decide
theorem cert_e1205812121210 : check e1205812121210 [[],[]] .smaller = true := by decide
def e1205812121398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1205812121398 : Closed e1205812121398 ∧ code e1205812121398 = 5603858632502 := by decide
theorem cert_e1205812121398 : check e1205812121398 [[],[]] .smaller = true := by decide
def e1205812121402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1205812121402 : Closed e1205812121402 ∧ code e1205812121402 = 5603858632506 := by decide
theorem cert_e1205812121402 : check e1205812121402 [[],[]] .smaller = true := by decide
def e1205812127150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1205812127150 : Closed e1205812127150 ∧ code e1205812127150 = 5603858638254 := by decide
theorem cert_e1205812127150 : check e1205812127150 [[],[]] .smaller = true := by decide
def e1205812127162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1205812127162 : Closed e1205812127162 ∧ code e1205812127162 = 5603858638266 := by decide
theorem cert_e1205812127162 : check e1205812127162 [[],[]] .smaller = true := by decide
def e1205812127210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1205812127210 : Closed e1205812127210 ∧ code e1205812127210 = 5603858638314 := by decide
theorem cert_e1205812127210 : check e1205812127210 [[],[]] .smaller = true := by decide
def e1205812127342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1205812127342 : Closed e1205812127342 ∧ code e1205812127342 = 5603858638446 := by decide
theorem cert_e1205812127342 : check e1205812127342 [[],[]] .smaller = true := by decide
def e1205812127354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1205812127354 : Closed e1205812127354 ∧ code e1205812127354 = 5603858638458 := by decide
theorem cert_e1205812127354 : check e1205812127354 [[],[]] .smaller = true := by decide
def e1205812127642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1205812127642 : Closed e1205812127642 ∧ code e1205812127642 = 5603858638746 := by decide
theorem cert_e1205812127642 : check e1205812127642 [[],[]] .smaller = true := by decide
def e1205812130518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1205812130518 : Closed e1205812130518 ∧ code e1205812130518 = 5603858641622 := by decide
theorem cert_e1205812130518 : check e1205812130518 [[],[]] .smaller = true := by decide
def e1205812130522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1205812130522 : Closed e1205812130522 ∧ code e1205812130522 = 5603858641626 := by decide
theorem cert_e1205812130522 : check e1205812130522 [[],[]] .smaller = true := by decide
def e1205812130538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1205812130538 : Closed e1205812130538 ∧ code e1205812130538 = 5603858641642 := by decide
theorem cert_e1205812130538 : check e1205812130538 [[],[]] .smaller = true := by decide
def e1205812130614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1205812130614 : Closed e1205812130614 ∧ code e1205812130614 = 5603858641718 := by decide
theorem cert_e1205812130614 : check e1205812130614 [[],[]] .smaller = true := by decide
def e1205812130618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1205812130618 : Closed e1205812130618 ∧ code e1205812130618 = 5603858641722 := by decide
theorem cert_e1205812130618 : check e1205812130618 [[],[]] .smaller = true := by decide
def e1205812130714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1205812130714 : Closed e1205812130714 ∧ code e1205812130714 = 5603858641818 := by decide
theorem cert_e1205812130714 : check e1205812130714 [[],[]] .smaller = true := by decide
def e1205812245950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e1205812245950 : Closed e1205812245950 ∧ code e1205812245950 = 5603858757054 := by decide
theorem cert_e1205812245950 : check e1205812245950 [[],[]] .three = true := by decide
def e1205812245982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1205812245982 : Closed e1205812245982 ∧ code e1205812245982 = 5603858757086 := by decide
theorem cert_e1205812245982 : check e1205812245982 [[],[]] .smaller = true := by decide
def e1205812245998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1205812245998 : Closed e1205812245998 ∧ code e1205812245998 = 5603858757102 := by decide
theorem cert_e1205812245998 : check e1205812245998 [[],[]] .smaller = true := by decide
def e1205812246006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e1205812246006 : Closed e1205812246006 ∧ code e1205812246006 = 5603858757110 := by decide
theorem cert_e1205812246006 : check e1205812246006 [[],[]] .three = true := by decide
def e1205812246206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e1205812246206 : Closed e1205812246206 ∧ code e1205812246206 = 5603858757310 := by decide
theorem cert_e1205812246206 : check e1205812246206 [[],[]] .three = true := by decide
def e1205812246238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e1205812246238 : Closed e1205812246238 ∧ code e1205812246238 = 5603858757342 := by decide
theorem cert_e1205812246238 : check e1205812246238 [[],[]] .smaller = true := by decide
def e1205812246254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1205812246254 : Closed e1205812246254 ∧ code e1205812246254 = 5603858757358 := by decide
theorem cert_e1205812246254 : check e1205812246254 [[],[]] .smaller = true := by decide
def e1205812246262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e1205812246262 : Closed e1205812246262 ∧ code e1205812246262 = 5603858757366 := by decide
theorem cert_e1205812246262 : check e1205812246262 [[],[]] .smaller = true := by decide
def e1205812246266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e1205812246266 : Closed e1205812246266 ∧ code e1205812246266 = 5603858757370 := by decide
theorem cert_e1205812246266 : check e1205812246266 [[],[]] .three = true := by decide
def e1205812246366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1205812246366 : Closed e1205812246366 ∧ code e1205812246366 = 5603858757470 := by decide
theorem cert_e1205812246366 : check e1205812246366 [[],[]] .smaller = true := by decide
def e1205812246382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1205812246382 : Closed e1205812246382 ∧ code e1205812246382 = 5603858757486 := by decide
theorem cert_e1205812246382 : check e1205812246382 [[],[]] .smaller = true := by decide
def e1205812246390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1205812246390 : Closed e1205812246390 ∧ code e1205812246390 = 5603858757494 := by decide
theorem cert_e1205812246390 : check e1205812246390 [[],[]] .smaller = true := by decide
def e1205812246394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1205812246394 : Closed e1205812246394 ∧ code e1205812246394 = 5603858757498 := by decide
theorem cert_e1205812246394 : check e1205812246394 [[],[]] .smaller = true := by decide
def e1205812246446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1205812246446 : Closed e1205812246446 ∧ code e1205812246446 = 5603858757550 := by decide
theorem cert_e1205812246446 : check e1205812246446 [[],[]] .smaller = true := by decide
def e1205812246454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e1205812246454 : Closed e1205812246454 ∧ code e1205812246454 = 5603858757558 := by decide
theorem cert_e1205812246454 : check e1205812246454 [[],[]] .smaller = true := by decide
def e1205812246458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1205812246458 : Closed e1205812246458 ∧ code e1205812246458 = 5603858757562 := by decide
theorem cert_e1205812246458 : check e1205812246458 [[],[]] .smaller = true := by decide
def e1205812246486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e1205812246486 : Closed e1205812246486 ∧ code e1205812246486 = 5603858757590 := by decide
theorem cert_e1205812246486 : check e1205812246486 [[],[]] .three = true := by decide
def e1205812246490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e1205812246490 : Closed e1205812246490 ∧ code e1205812246490 = 5603858757594 := by decide
theorem cert_e1205812246490 : check e1205812246490 [[],[]] .three = true := by decide
def e1205812247230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e1205812247230 : Closed e1205812247230 ∧ code e1205812247230 = 5603858758334 := by decide
theorem cert_e1205812247230 : check e1205812247230 [[],[]] .three = true := by decide
def e1205812247262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1205812247262 : Closed e1205812247262 ∧ code e1205812247262 = 5603858758366 := by decide
theorem cert_e1205812247262 : check e1205812247262 [[],[]] .smaller = true := by decide
def e1205812247278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e1205812247278 : Closed e1205812247278 ∧ code e1205812247278 = 5603858758382 := by decide
theorem cert_e1205812247278 : check e1205812247278 [[],[]] .smaller = true := by decide
def e1205812247286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1205812247286 : Closed e1205812247286 ∧ code e1205812247286 = 5603858758390 := by decide
theorem cert_e1205812247286 : check e1205812247286 [[],[]] .smaller = true := by decide
def e1205812247290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e1205812247290 : Closed e1205812247290 ∧ code e1205812247290 = 5603858758394 := by decide
theorem cert_e1205812247290 : check e1205812247290 [[],[]] .three = true := by decide
def e1205812247390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1205812247390 : Closed e1205812247390 ∧ code e1205812247390 = 5603858758494 := by decide
theorem cert_e1205812247390 : check e1205812247390 [[],[]] .smaller = true := by decide
end Blc.Floor42
