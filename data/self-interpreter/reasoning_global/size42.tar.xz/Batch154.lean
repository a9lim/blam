import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186570998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 1)))))))
theorem wire_e1211186570998 : Closed e1211186570998 ∧ code e1211186570998 = 5609233082102 := by decide
theorem cert_e1211186570998 : check e1211186570998 [[],[]] .smaller = true := by decide
def e1211186571126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))))
theorem wire_e1211186571126 : Closed e1211186571126 ∧ code e1211186571126 = 5609233082230 := by decide
theorem cert_e1211186571126 : check e1211186571126 [[],[]] .smaller = true := by decide
def e1211186571130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0)))))))
theorem wire_e1211186571130 : Closed e1211186571130 ∧ code e1211186571130 = 5609233082234 := by decide
theorem cert_e1211186571130 : check e1211186571130 [[],[]] .smaller = true := by decide
def e1211186571182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 2)))))))
theorem wire_e1211186571182 : Closed e1211186571182 ∧ code e1211186571182 = 5609233082286 := by decide
theorem cert_e1211186571182 : check e1211186571182 [[],[]] .smaller = true := by decide
def e1211186571190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))))
theorem wire_e1211186571190 : Closed e1211186571190 ∧ code e1211186571190 = 5609233082294 := by decide
theorem cert_e1211186571190 : check e1211186571190 [[],[]] .smaller = true := by decide
def e1211186571222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 1)))))))
theorem wire_e1211186571222 : Closed e1211186571222 ∧ code e1211186571222 = 5609233082326 := by decide
theorem cert_e1211186571222 : check e1211186571222 [[],[]] .smaller = true := by decide
def e1211186571226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0)))))))
theorem wire_e1211186571226 : Closed e1211186571226 ∧ code e1211186571226 = 5609233082330 := by decide
theorem cert_e1211186571226 : check e1211186571226 [[],[]] .smaller = true := by decide
def e1211186571742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186571742 : Closed e1211186571742 ∧ code e1211186571742 = 5609233082846 := by decide
theorem cert_e1211186571742 : check e1211186571742 [[],[]] .three = true := by decide
def e1211186571766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186571766 : Closed e1211186571766 ∧ code e1211186571766 = 5609233082870 := by decide
theorem cert_e1211186571766 : check e1211186571766 [[],[]] .three = true := by decide
def e1211186572526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186572526 : Closed e1211186572526 ∧ code e1211186572526 = 5609233083630 := by decide
theorem cert_e1211186572526 : check e1211186572526 [[],[]] .smaller = true := by decide
def e1211186572534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186572534 : Closed e1211186572534 ∧ code e1211186572534 = 5609233083638 := by decide
theorem cert_e1211186572534 : check e1211186572534 [[],[]] .smaller = true := by decide
def e1211186572910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186572910 : Closed e1211186572910 ∧ code e1211186572910 = 5609233084014 := by decide
theorem cert_e1211186572910 : check e1211186572910 [[],[]] .smaller = true := by decide
def e1211186572922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186572922 : Closed e1211186572922 ∧ code e1211186572922 = 5609233084026 := by decide
theorem cert_e1211186572922 : check e1211186572922 [[],[]] .smaller = true := by decide
def e1211186573110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186573110 : Closed e1211186573110 ∧ code e1211186573110 = 5609233084214 := by decide
theorem cert_e1211186573110 : check e1211186573110 [[],[]] .smaller = true := by decide
def e1211186573114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186573114 : Closed e1211186573114 ∧ code e1211186573114 = 5609233084218 := by decide
theorem cert_e1211186573114 : check e1211186573114 [[],[]] .smaller = true := by decide
def e1211186573806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211186573806 : Closed e1211186573806 ∧ code e1211186573806 = 5609233084910 := by decide
theorem cert_e1211186573806 : check e1211186573806 [[],[]] .smaller = true := by decide
def e1211186573814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1)))))))
theorem wire_e1211186573814 : Closed e1211186573814 ∧ code e1211186573814 = 5609233084918 := by decide
theorem cert_e1211186573814 : check e1211186573814 [[],[]] .smaller = true := by decide
def e1211186574198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))))
theorem wire_e1211186574198 : Closed e1211186574198 ∧ code e1211186574198 = 5609233085302 := by decide
theorem cert_e1211186574198 : check e1211186574198 [[],[]] .smaller = true := by decide
def e1211186574202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e1211186574202 : Closed e1211186574202 ∧ code e1211186574202 = 5609233085306 := by decide
theorem cert_e1211186574202 : check e1211186574202 [[],[]] .smaller = true := by decide
def e1211186574294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))))
theorem wire_e1211186574294 : Closed e1211186574294 ∧ code e1211186574294 = 5609233085398 := by decide
theorem cert_e1211186574294 : check e1211186574294 [[],[]] .smaller = true := by decide
def e1211186574314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e1211186574314 : Closed e1211186574314 ∧ code e1211186574314 = 5609233085418 := by decide
theorem cert_e1211186574314 : check e1211186574314 [[],[]] .smaller = true := by decide
def e1211186574574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186574574 : Closed e1211186574574 ∧ code e1211186574574 = 5609233085678 := by decide
theorem cert_e1211186574574 : check e1211186574574 [[],[]] .smaller = true := by decide
def e1211186574582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186574582 : Closed e1211186574582 ∧ code e1211186574582 = 5609233085686 := by decide
theorem cert_e1211186574582 : check e1211186574582 [[],[]] .smaller = true := by decide
def e1211186575134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211186575134 : Closed e1211186575134 ∧ code e1211186575134 = 5609233086238 := by decide
theorem cert_e1211186575134 : check e1211186575134 [[],[]] .smaller = true := by decide
def e1211186575246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2))))))))
theorem wire_e1211186575246 : Closed e1211186575246 ∧ code e1211186575246 = 5609233086350 := by decide
theorem cert_e1211186575246 : check e1211186575246 [[],[]] .smaller = true := by decide
def e1211186575598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e1211186575598 : Closed e1211186575598 ∧ code e1211186575598 = 5609233086702 := by decide
theorem cert_e1211186575598 : check e1211186575598 [[],[]] .smaller = true := by decide
def e1211186575610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211186575610 : Closed e1211186575610 ∧ code e1211186575610 = 5609233086714 := by decide
theorem cert_e1211186575610 : check e1211186575610 [[],[]] .smaller = true := by decide
def e1211186575790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e1211186575790 : Closed e1211186575790 ∧ code e1211186575790 = 5609233086894 := by decide
theorem cert_e1211186575790 : check e1211186575790 [[],[]] .smaller = true := by decide
def e1211186575798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e1211186575798 : Closed e1211186575798 ∧ code e1211186575798 = 5609233086902 := by decide
theorem cert_e1211186575798 : check e1211186575798 [[],[]] .smaller = true := by decide
def e1211186575830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e1211186575830 : Closed e1211186575830 ∧ code e1211186575830 = 5609233086934 := by decide
theorem cert_e1211186575830 : check e1211186575830 [[],[]] .smaller = true := by decide
def e1211186575982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186575982 : Closed e1211186575982 ∧ code e1211186575982 = 5609233087086 := by decide
theorem cert_e1211186575982 : check e1211186575982 [[],[]] .smaller = true := by decide
def e1211186575994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186575994 : Closed e1211186575994 ∧ code e1211186575994 = 5609233087098 := by decide
theorem cert_e1211186575994 : check e1211186575994 [[],[]] .smaller = true := by decide
def e1211186576158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e1211186576158 : Closed e1211186576158 ∧ code e1211186576158 = 5609233087262 := by decide
theorem cert_e1211186576158 : check e1211186576158 [[],[]] .smaller = true := by decide
def e1211186576326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211186576326 : Closed e1211186576326 ∧ code e1211186576326 = 5609233087430 := by decide
theorem cert_e1211186576326 : check e1211186576326 [[],[]] .smaller = true := by decide
def e1211186576502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211186576502 : Closed e1211186576502 ∧ code e1211186576502 = 5609233087606 := by decide
theorem cert_e1211186576502 : check e1211186576502 [[],[]] .smaller = true := by decide
def e1211186576506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186576506 : Closed e1211186576506 ∧ code e1211186576506 = 5609233087610 := by decide
theorem cert_e1211186576506 : check e1211186576506 [[],[]] .smaller = true := by decide
def e1211186576598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e1211186576598 : Closed e1211186576598 ∧ code e1211186576598 = 5609233087702 := by decide
theorem cert_e1211186576598 : check e1211186576598 [[],[]] .smaller = true := by decide
def e1211186576602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e1211186576602 : Closed e1211186576602 ∧ code e1211186576602 = 5609233087706 := by decide
theorem cert_e1211186576602 : check e1211186576602 [[],[]] .smaller = true := by decide
def e1211186576618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e1211186576618 : Closed e1211186576618 ∧ code e1211186576618 = 5609233087722 := by decide
theorem cert_e1211186576618 : check e1211186576618 [[],[]] .smaller = true := by decide
def e1211186576694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186576694 : Closed e1211186576694 ∧ code e1211186576694 = 5609233087798 := by decide
theorem cert_e1211186576694 : check e1211186576694 [[],[]] .smaller = true := by decide
def e1211186576698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186576698 : Closed e1211186576698 ∧ code e1211186576698 = 5609233087802 := by decide
theorem cert_e1211186576698 : check e1211186576698 [[],[]] .smaller = true := by decide
def e1211186576782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211186576782 : Closed e1211186576782 ∧ code e1211186576782 = 5609233087886 := by decide
theorem cert_e1211186576782 : check e1211186576782 [[],[]] .smaller = true := by decide
def e1211186576838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186576838 : Closed e1211186576838 ∧ code e1211186576838 = 5609233087942 := by decide
theorem cert_e1211186576838 : check e1211186576838 [[],[]] .smaller = true := by decide
def e1211186583262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211186583262 : Closed e1211186583262 ∧ code e1211186583262 = 5609233094366 := by decide
theorem cert_e1211186583262 : check e1211186583262 [[],[]] .three = true := by decide
def e1211186583286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211186583286 : Closed e1211186583286 ∧ code e1211186583286 = 5609233094390 := by decide
theorem cert_e1211186583286 : check e1211186583286 [[],[]] .three = true := by decide
def e1211186583390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211186583390 : Closed e1211186583390 ∧ code e1211186583390 = 5609233094494 := by decide
theorem cert_e1211186583390 : check e1211186583390 [[],[]] .three = true := by decide
def e1211186583406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211186583406 : Closed e1211186583406 ∧ code e1211186583406 = 5609233094510 := by decide
theorem cert_e1211186583406 : check e1211186583406 [[],[]] .smaller = true := by decide
def e1211186583414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211186583414 : Closed e1211186583414 ∧ code e1211186583414 = 5609233094518 := by decide
theorem cert_e1211186583414 : check e1211186583414 [[],[]] .smaller = true := by decide
def e1211186583418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211186583418 : Closed e1211186583418 ∧ code e1211186583418 = 5609233094522 := by decide
theorem cert_e1211186583418 : check e1211186583418 [[],[]] .three = true := by decide
def e1211186583478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211186583478 : Closed e1211186583478 ∧ code e1211186583478 = 5609233094582 := by decide
theorem cert_e1211186583478 : check e1211186583478 [[],[]] .smaller = true := by decide
def e1211186583510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211186583510 : Closed e1211186583510 ∧ code e1211186583510 = 5609233094614 := by decide
theorem cert_e1211186583510 : check e1211186583510 [[],[]] .three = true := by decide
def e1211186583514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211186583514 : Closed e1211186583514 ∧ code e1211186583514 = 5609233094618 := by decide
theorem cert_e1211186583514 : check e1211186583514 [[],[]] .three = true := by decide
def e1211186584030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186584030 : Closed e1211186584030 ∧ code e1211186584030 = 5609233095134 := by decide
theorem cert_e1211186584030 : check e1211186584030 [[],[]] .three = true := by decide
def e1211186584054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186584054 : Closed e1211186584054 ∧ code e1211186584054 = 5609233095158 := by decide
theorem cert_e1211186584054 : check e1211186584054 [[],[]] .three = true := by decide
def e1211186584798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186584798 : Closed e1211186584798 ∧ code e1211186584798 = 5609233095902 := by decide
theorem cert_e1211186584798 : check e1211186584798 [[],[]] .three = true := by decide
def e1211186584814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186584814 : Closed e1211186584814 ∧ code e1211186584814 = 5609233095918 := by decide
theorem cert_e1211186584814 : check e1211186584814 [[],[]] .smaller = true := by decide
def e1211186584822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186584822 : Closed e1211186584822 ∧ code e1211186584822 = 5609233095926 := by decide
theorem cert_e1211186584822 : check e1211186584822 [[],[]] .smaller = true := by decide
def e1211186584826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186584826 : Closed e1211186584826 ∧ code e1211186584826 = 5609233095930 := by decide
theorem cert_e1211186584826 : check e1211186584826 [[],[]] .three = true := by decide
def e1211186585206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186585206 : Closed e1211186585206 ∧ code e1211186585206 = 5609233096310 := by decide
theorem cert_e1211186585206 : check e1211186585206 [[],[]] .smaller = true := by decide
def e1211186585398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186585398 : Closed e1211186585398 ∧ code e1211186585398 = 5609233096502 := by decide
theorem cert_e1211186585398 : check e1211186585398 [[],[]] .three = true := by decide
def e1211186585402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186585402 : Closed e1211186585402 ∧ code e1211186585402 = 5609233096506 := by decide
theorem cert_e1211186585402 : check e1211186585402 [[],[]] .three = true := by decide
def e1211186594782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211186594782 : Closed e1211186594782 ∧ code e1211186594782 = 5609233105886 := by decide
theorem cert_e1211186594782 : check e1211186594782 [[],[]] .smaller = true := by decide
def e1211186594798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211186594798 : Closed e1211186594798 ∧ code e1211186594798 = 5609233105902 := by decide
theorem cert_e1211186594798 : check e1211186594798 [[],[]] .smaller = true := by decide
def e1211186596718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211186596718 : Closed e1211186596718 ∧ code e1211186596718 = 5609233107822 := by decide
theorem cert_e1211186596718 : check e1211186596718 [[],[]] .smaller = true := by decide
def e1211186596726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211186596726 : Closed e1211186596726 ∧ code e1211186596726 = 5609233107830 := by decide
theorem cert_e1211186596726 : check e1211186596726 [[],[]] .smaller = true := by decide
def e1211186596782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211186596782 : Closed e1211186596782 ∧ code e1211186596782 = 5609233107886 := by decide
theorem cert_e1211186596782 : check e1211186596782 [[],[]] .smaller = true := by decide
def e1211186596794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211186596794 : Closed e1211186596794 ∧ code e1211186596794 = 5609233107898 := by decide
theorem cert_e1211186596794 : check e1211186596794 [[],[]] .smaller = true := by decide
def e1211186596822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211186596822 : Closed e1211186596822 ∧ code e1211186596822 = 5609233107926 := by decide
theorem cert_e1211186596822 : check e1211186596822 [[],[]] .smaller = true := by decide
def e1211186596826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211186596826 : Closed e1211186596826 ∧ code e1211186596826 = 5609233107930 := by decide
theorem cert_e1211186596826 : check e1211186596826 [[],[]] .smaller = true := by decide
def e1211186597102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186597102 : Closed e1211186597102 ∧ code e1211186597102 = 5609233108206 := by decide
theorem cert_e1211186597102 : check e1211186597102 [[],[]] .smaller = true := by decide
def e1211186597110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186597110 : Closed e1211186597110 ∧ code e1211186597110 = 5609233108214 := by decide
theorem cert_e1211186597110 : check e1211186597110 [[],[]] .smaller = true := by decide
def e1211186597438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211186597438 : Closed e1211186597438 ∧ code e1211186597438 = 5609233108542 := by decide
theorem cert_e1211186597438 : check e1211186597438 [[],[]] .three = true := by decide
def e1211186597486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186597486 : Closed e1211186597486 ∧ code e1211186597486 = 5609233108590 := by decide
theorem cert_e1211186597486 : check e1211186597486 [[],[]] .smaller = true := by decide
def e1211186597498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186597498 : Closed e1211186597498 ∧ code e1211186597498 = 5609233108602 := by decide
theorem cert_e1211186597498 : check e1211186597498 [[],[]] .smaller = true := by decide
def e1211186597686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186597686 : Closed e1211186597686 ∧ code e1211186597686 = 5609233108790 := by decide
theorem cert_e1211186597686 : check e1211186597686 [[],[]] .smaller = true := by decide
def e1211186597690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186597690 : Closed e1211186597690 ∧ code e1211186597690 = 5609233108794 := by decide
theorem cert_e1211186597690 : check e1211186597690 [[],[]] .smaller = true := by decide
def e1211186597774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211186597774 : Closed e1211186597774 ∧ code e1211186597774 = 5609233108878 := by decide
theorem cert_e1211186597774 : check e1211186597774 [[],[]] .three = true := by decide
def e1211186602462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186602462 : Closed e1211186602462 ∧ code e1211186602462 = 5609233113566 := by decide
theorem cert_e1211186602462 : check e1211186602462 [[],[]] .smaller = true := by decide
def e1211186602486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186602486 : Closed e1211186602486 ∧ code e1211186602486 = 5609233113590 := by decide
theorem cert_e1211186602486 : check e1211186602486 [[],[]] .smaller = true := by decide
def e1211186603438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211186603438 : Closed e1211186603438 ∧ code e1211186603438 = 5609233114542 := by decide
theorem cert_e1211186603438 : check e1211186603438 [[],[]] .smaller = true := by decide
def e1211186603450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211186603450 : Closed e1211186603450 ∧ code e1211186603450 = 5609233114554 := by decide
theorem cert_e1211186603450 : check e1211186603450 [[],[]] .smaller = true := by decide
def e1211186603498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211186603498 : Closed e1211186603498 ∧ code e1211186603498 = 5609233114602 := by decide
theorem cert_e1211186603498 : check e1211186603498 [[],[]] .smaller = true := by decide
def e1211186603582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1211186603582 : Closed e1211186603582 ∧ code e1211186603582 = 5609233114686 := by decide
theorem cert_e1211186603582 : check e1211186603582 [[],[]] .three = true := by decide
def e1211186603630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186603630 : Closed e1211186603630 ∧ code e1211186603630 = 5609233114734 := by decide
theorem cert_e1211186603630 : check e1211186603630 [[],[]] .smaller = true := by decide
def e1211186603642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186603642 : Closed e1211186603642 ∧ code e1211186603642 = 5609233114746 := by decide
theorem cert_e1211186603642 : check e1211186603642 [[],[]] .smaller = true := by decide
def e1211186603806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211186603806 : Closed e1211186603806 ∧ code e1211186603806 = 5609233114910 := by decide
theorem cert_e1211186603806 : check e1211186603806 [[],[]] .smaller = true := by decide
def e1211186603918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211186603918 : Closed e1211186603918 ∧ code e1211186603918 = 5609233115022 := by decide
theorem cert_e1211186603918 : check e1211186603918 [[],[]] .smaller = true := by decide
def e1211186603930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186603930 : Closed e1211186603930 ∧ code e1211186603930 = 5609233115034 := by decide
theorem cert_e1211186603930 : check e1211186603930 [[],[]] .smaller = true := by decide
def e1211186603974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1211186603974 : Closed e1211186603974 ∧ code e1211186603974 = 5609233115078 := by decide
theorem cert_e1211186603974 : check e1211186603974 [[],[]] .three = true := by decide
def e1211186603998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 3))))))))
theorem wire_e1211186603998 : Closed e1211186603998 ∧ code e1211186603998 = 5609233115102 := by decide
theorem cert_e1211186603998 : check e1211186603998 [[],[]] .three = true := by decide
def e1211186606318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186606318 : Closed e1211186606318 ∧ code e1211186606318 = 5609233117422 := by decide
theorem cert_e1211186606318 : check e1211186606318 [[],[]] .smaller = true := by decide
def e1211186606326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186606326 : Closed e1211186606326 ∧ code e1211186606326 = 5609233117430 := by decide
theorem cert_e1211186606326 : check e1211186606326 [[],[]] .smaller = true := by decide
def e1211186606806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211186606806 : Closed e1211186606806 ∧ code e1211186606806 = 5609233117910 := by decide
theorem cert_e1211186606806 : check e1211186606806 [[],[]] .smaller = true := by decide
def e1211186606810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211186606810 : Closed e1211186606810 ∧ code e1211186606810 = 5609233117914 := by decide
theorem cert_e1211186606810 : check e1211186606810 [[],[]] .smaller = true := by decide
def e1211186606826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211186606826 : Closed e1211186606826 ∧ code e1211186606826 = 5609233117930 := by decide
theorem cert_e1211186606826 : check e1211186606826 [[],[]] .smaller = true := by decide
def e1211186606902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186606902 : Closed e1211186606902 ∧ code e1211186606902 = 5609233118006 := by decide
theorem cert_e1211186606902 : check e1211186606902 [[],[]] .smaller = true := by decide
def e1211186606906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186606906 : Closed e1211186606906 ∧ code e1211186606906 = 5609233118010 := by decide
theorem cert_e1211186606906 : check e1211186606906 [[],[]] .smaller = true := by decide
def e1211186606990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211186606990 : Closed e1211186606990 ∧ code e1211186606990 = 5609233118094 := by decide
theorem cert_e1211186606990 : check e1211186606990 [[],[]] .smaller = true := by decide
def e1211186607002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186607002 : Closed e1211186607002 ∧ code e1211186607002 = 5609233118106 := by decide
theorem cert_e1211186607002 : check e1211186607002 [[],[]] .smaller = true := by decide
def e1211186607070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186607070 : Closed e1211186607070 ∧ code e1211186607070 = 5609233118174 := by decide
theorem cert_e1211186607070 : check e1211186607070 [[],[]] .three = true := by decide
def e1211186607086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186607086 : Closed e1211186607086 ∧ code e1211186607086 = 5609233118190 := by decide
theorem cert_e1211186607086 : check e1211186607086 [[],[]] .three = true := by decide
def e1211186608526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186608526 : Closed e1211186608526 ∧ code e1211186608526 = 5609233119630 := by decide
theorem cert_e1211186608526 : check e1211186608526 [[],[]] .three = true := by decide
def e1211186608582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186608582 : Closed e1211186608582 ∧ code e1211186608582 = 5609233119686 := by decide
theorem cert_e1211186608582 : check e1211186608582 [[],[]] .three = true := by decide
def e1211186608606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186608606 : Closed e1211186608606 ∧ code e1211186608606 = 5609233119710 := by decide
theorem cert_e1211186608606 : check e1211186608606 [[],[]] .three = true := by decide
def e1211186608622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186608622 : Closed e1211186608622 ∧ code e1211186608622 = 5609233119726 := by decide
theorem cert_e1211186608622 : check e1211186608622 [[],[]] .three = true := by decide
def e1211186608630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186608630 : Closed e1211186608630 ∧ code e1211186608630 = 5609233119734 := by decide
theorem cert_e1211186608630 : check e1211186608630 [[],[]] .three = true := by decide
def e1211186635486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 3)))))))
theorem wire_e1211186635486 : Closed e1211186635486 ∧ code e1211186635486 = 5609233146590 := by decide
theorem cert_e1211186635486 : check e1211186635486 [[],[]] .three = true := by decide
def e1211186635510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))) (.var 1)))))))
theorem wire_e1211186635510 : Closed e1211186635510 ∧ code e1211186635510 = 5609233146614 := by decide
theorem cert_e1211186635510 : check e1211186635510 [[],[]] .three = true := by decide
def e1211186635630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2)))))))
theorem wire_e1211186635630 : Closed e1211186635630 ∧ code e1211186635630 = 5609233146734 := by decide
theorem cert_e1211186635630 : check e1211186635630 [[],[]] .smaller = true := by decide
def e1211186635638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1)))))))
theorem wire_e1211186635638 : Closed e1211186635638 ∧ code e1211186635638 = 5609233146742 := by decide
theorem cert_e1211186635638 : check e1211186635638 [[],[]] .smaller = true := by decide
def e1211186635694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2)))))))
theorem wire_e1211186635694 : Closed e1211186635694 ∧ code e1211186635694 = 5609233146798 := by decide
theorem cert_e1211186635694 : check e1211186635694 [[],[]] .smaller = true := by decide
def e1211186635706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0)))))))
theorem wire_e1211186635706 : Closed e1211186635706 ∧ code e1211186635706 = 5609233146810 := by decide
theorem cert_e1211186635706 : check e1211186635706 [[],[]] .smaller = true := by decide
def e1211186635734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1)))))))
theorem wire_e1211186635734 : Closed e1211186635734 ∧ code e1211186635734 = 5609233146838 := by decide
theorem cert_e1211186635734 : check e1211186635734 [[],[]] .smaller = true := by decide
def e1211186635738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0)))))))
theorem wire_e1211186635738 : Closed e1211186635738 ∧ code e1211186635738 = 5609233146842 := by decide
theorem cert_e1211186635738 : check e1211186635738 [[],[]] .smaller = true := by decide
def e1211186637038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211186637038 : Closed e1211186637038 ∧ code e1211186637038 = 5609233148142 := by decide
theorem cert_e1211186637038 : check e1211186637038 [[],[]] .smaller = true := by decide
def e1211186637046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211186637046 : Closed e1211186637046 ∧ code e1211186637046 = 5609233148150 := by decide
theorem cert_e1211186637046 : check e1211186637046 [[],[]] .smaller = true := by decide
def e1211186637598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211186637598 : Closed e1211186637598 ∧ code e1211186637598 = 5609233148702 := by decide
theorem cert_e1211186637598 : check e1211186637598 [[],[]] .smaller = true := by decide
def e1211186637710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211186637710 : Closed e1211186637710 ∧ code e1211186637710 = 5609233148814 := by decide
theorem cert_e1211186637710 : check e1211186637710 [[],[]] .smaller = true := by decide
def e1211186637918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186637918 : Closed e1211186637918 ∧ code e1211186637918 = 5609233149022 := by decide
theorem cert_e1211186637918 : check e1211186637918 [[],[]] .three = true := by decide
def e1211186637934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186637934 : Closed e1211186637934 ∧ code e1211186637934 = 5609233149038 := by decide
theorem cert_e1211186637934 : check e1211186637934 [[],[]] .smaller = true := by decide
def e1211186637946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186637946 : Closed e1211186637946 ∧ code e1211186637946 = 5609233149050 := by decide
theorem cert_e1211186637946 : check e1211186637946 [[],[]] .smaller = true := by decide
def e1211186638110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186638110 : Closed e1211186638110 ∧ code e1211186638110 = 5609233149214 := by decide
theorem cert_e1211186638110 : check e1211186638110 [[],[]] .smaller = true := by decide
def e1211186638278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186638278 : Closed e1211186638278 ∧ code e1211186638278 = 5609233149382 := by decide
theorem cert_e1211186638278 : check e1211186638278 [[],[]] .smaller = true := by decide
def e1211186638302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e1211186638302 : Closed e1211186638302 ∧ code e1211186638302 = 5609233149406 := by decide
theorem cert_e1211186638302 : check e1211186638302 [[],[]] .three = true := by decide
def e1211186638306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186638306 : Closed e1211186638306 ∧ code e1211186638306 = 5609233149410 := by decide
theorem cert_e1211186638306 : check e1211186638306 [[],[]] .three = true := by decide
def e1211186638318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e1211186638318 : Closed e1211186638318 ∧ code e1211186638318 = 5609233149422 := by decide
theorem cert_e1211186638318 : check e1211186638318 [[],[]] .three = true := by decide
def e1211186638390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186638390 : Closed e1211186638390 ∧ code e1211186638390 = 5609233149494 := by decide
theorem cert_e1211186638390 : check e1211186638390 [[],[]] .smaller = true := by decide
def e1211186638394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186638394 : Closed e1211186638394 ∧ code e1211186638394 = 5609233149498 := by decide
theorem cert_e1211186638394 : check e1211186638394 [[],[]] .smaller = true := by decide
def e1211186638478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186638478 : Closed e1211186638478 ∧ code e1211186638478 = 5609233149582 := by decide
theorem cert_e1211186638478 : check e1211186638478 [[],[]] .smaller = true := by decide
def e1211186638534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186638534 : Closed e1211186638534 ∧ code e1211186638534 = 5609233149638 := by decide
theorem cert_e1211186638534 : check e1211186638534 [[],[]] .smaller = true := by decide
def e1211186638558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e1211186638558 : Closed e1211186638558 ∧ code e1211186638558 = 5609233149662 := by decide
theorem cert_e1211186638558 : check e1211186638558 [[],[]] .three = true := by decide
def e1211186638582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e1211186638582 : Closed e1211186638582 ∧ code e1211186638582 = 5609233149686 := by decide
theorem cert_e1211186638582 : check e1211186638582 [[],[]] .three = true := by decide
def e1211186638614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186638614 : Closed e1211186638614 ∧ code e1211186638614 = 5609233149718 := by decide
theorem cert_e1211186638614 : check e1211186638614 [[],[]] .three = true := by decide
def e1211186638690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186638690 : Closed e1211186638690 ∧ code e1211186638690 = 5609233149794 := by decide
theorem cert_e1211186638690 : check e1211186638690 [[],[]] .three = true := by decide
def e1211186638702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e1211186638702 : Closed e1211186638702 ∧ code e1211186638702 = 5609233149806 := by decide
theorem cert_e1211186638702 : check e1211186638702 [[],[]] .three = true := by decide
def e1211186638710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e1211186638710 : Closed e1211186638710 ∧ code e1211186638710 = 5609233149814 := by decide
theorem cert_e1211186638710 : check e1211186638710 [[],[]] .three = true := by decide
def e1211186639198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 3)))))))
theorem wire_e1211186639198 : Closed e1211186639198 ∧ code e1211186639198 = 5609233150302 := by decide
theorem cert_e1211186639198 : check e1211186639198 [[],[]] .three = true := by decide
def e1211186639214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e1211186639214 : Closed e1211186639214 ∧ code e1211186639214 = 5609233150318 := by decide
theorem cert_e1211186639214 : check e1211186639214 [[],[]] .smaller = true := by decide
def e1211186639222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e1211186639222 : Closed e1211186639222 ∧ code e1211186639222 = 5609233150326 := by decide
theorem cert_e1211186639222 : check e1211186639222 [[],[]] .smaller = true := by decide
def e1211186639226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))) (.var 0)))))))
theorem wire_e1211186639226 : Closed e1211186639226 ∧ code e1211186639226 = 5609233150330 := by decide
theorem cert_e1211186639226 : check e1211186639226 [[],[]] .three = true := by decide
def e1211186639278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2)))))))
theorem wire_e1211186639278 : Closed e1211186639278 ∧ code e1211186639278 = 5609233150382 := by decide
theorem cert_e1211186639278 : check e1211186639278 [[],[]] .smaller = true := by decide
def e1211186639290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0)))))))
theorem wire_e1211186639290 : Closed e1211186639290 ∧ code e1211186639290 = 5609233150394 := by decide
theorem cert_e1211186639290 : check e1211186639290 [[],[]] .smaller = true := by decide
def e1211186639338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0)))))))
theorem wire_e1211186639338 : Closed e1211186639338 ∧ code e1211186639338 = 5609233150442 := by decide
theorem cert_e1211186639338 : check e1211186639338 [[],[]] .smaller = true := by decide
def e1211186639966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186639966 : Closed e1211186639966 ∧ code e1211186639966 = 5609233151070 := by decide
theorem cert_e1211186639966 : check e1211186639966 [[],[]] .three = true := by decide
def e1211186639982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186639982 : Closed e1211186639982 ∧ code e1211186639982 = 5609233151086 := by decide
theorem cert_e1211186639982 : check e1211186639982 [[],[]] .smaller = true := by decide
def e1211186639994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186639994 : Closed e1211186639994 ∧ code e1211186639994 = 5609233151098 := by decide
theorem cert_e1211186639994 : check e1211186639994 [[],[]] .smaller = true := by decide
def e1211186640158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186640158 : Closed e1211186640158 ∧ code e1211186640158 = 5609233151262 := by decide
theorem cert_e1211186640158 : check e1211186640158 [[],[]] .smaller = true := by decide
def e1211186640326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186640326 : Closed e1211186640326 ∧ code e1211186640326 = 5609233151430 := by decide
theorem cert_e1211186640326 : check e1211186640326 [[],[]] .smaller = true := by decide
def e1211186640350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e1211186640350 : Closed e1211186640350 ∧ code e1211186640350 = 5609233151454 := by decide
theorem cert_e1211186640350 : check e1211186640350 [[],[]] .three = true := by decide
def e1211186640354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186640354 : Closed e1211186640354 ∧ code e1211186640354 = 5609233151458 := by decide
theorem cert_e1211186640354 : check e1211186640354 [[],[]] .three = true := by decide
def e1211186640366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e1211186640366 : Closed e1211186640366 ∧ code e1211186640366 = 5609233151470 := by decide
theorem cert_e1211186640366 : check e1211186640366 [[],[]] .three = true := by decide
def e1211186640430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186640430 : Closed e1211186640430 ∧ code e1211186640430 = 5609233151534 := by decide
theorem cert_e1211186640430 : check e1211186640430 [[],[]] .smaller = true := by decide
def e1211186640606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e1211186640606 : Closed e1211186640606 ∧ code e1211186640606 = 5609233151710 := by decide
theorem cert_e1211186640606 : check e1211186640606 [[],[]] .three = true := by decide
def e1211186640610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186640610 : Closed e1211186640610 ∧ code e1211186640610 = 5609233151714 := by decide
theorem cert_e1211186640610 : check e1211186640610 [[],[]] .smaller = true := by decide
def e1211186640622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 2)))))))
theorem wire_e1211186640622 : Closed e1211186640622 ∧ code e1211186640622 = 5609233151726 := by decide
theorem cert_e1211186640622 : check e1211186640622 [[],[]] .smaller = true := by decide
def e1211186640630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e1211186640630 : Closed e1211186640630 ∧ code e1211186640630 = 5609233151734 := by decide
theorem cert_e1211186640630 : check e1211186640630 [[],[]] .three = true := by decide
def e1211186640662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186640662 : Closed e1211186640662 ∧ code e1211186640662 = 5609233151766 := by decide
theorem cert_e1211186640662 : check e1211186640662 [[],[]] .smaller = true := by decide
def e1211186640666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186640666 : Closed e1211186640666 ∧ code e1211186640666 = 5609233151770 := by decide
theorem cert_e1211186640666 : check e1211186640666 [[],[]] .smaller = true := by decide
def e1211186640710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186640710 : Closed e1211186640710 ∧ code e1211186640710 = 5609233151814 := by decide
theorem cert_e1211186640710 : check e1211186640710 [[],[]] .smaller = true := by decide
def e1211186640734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e1211186640734 : Closed e1211186640734 ∧ code e1211186640734 = 5609233151838 := by decide
theorem cert_e1211186640734 : check e1211186640734 [[],[]] .three = true := by decide
end Blc.Floor42
