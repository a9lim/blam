import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210182486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211210182486 : Closed e1211210182486 ∧ code e1211210182486 = 5609256693590 := by decide
theorem cert_e1211210182486 : check e1211210182486 [[],[]] .smaller = true := by decide
def e1211210182490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211210182490 : Closed e1211210182490 ∧ code e1211210182490 = 5609256693594 := by decide
theorem cert_e1211210182490 : check e1211210182490 [[],[]] .smaller = true := by decide
def e1211210182506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211210182506 : Closed e1211210182506 ∧ code e1211210182506 = 5609256693610 := by decide
theorem cert_e1211210182506 : check e1211210182506 [[],[]] .smaller = true := by decide
def e1211210183134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e1211210183134 : Closed e1211210183134 ∧ code e1211210183134 = 5609256694238 := by decide
theorem cert_e1211210183134 : check e1211210183134 [[],[]] .smaller = true := by decide
def e1211210183158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e1211210183158 : Closed e1211210183158 ∧ code e1211210183158 = 5609256694262 := by decide
theorem cert_e1211210183158 : check e1211210183158 [[],[]] .smaller = true := by decide
def e1211210183534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211210183534 : Closed e1211210183534 ∧ code e1211210183534 = 5609256694638 := by decide
theorem cert_e1211210183534 : check e1211210183534 [[],[]] .smaller = true := by decide
def e1211210183542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211210183542 : Closed e1211210183542 ∧ code e1211210183542 = 5609256694646 := by decide
theorem cert_e1211210183542 : check e1211210183542 [[],[]] .smaller = true := by decide
def e1211210183598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211210183598 : Closed e1211210183598 ∧ code e1211210183598 = 5609256694702 := by decide
theorem cert_e1211210183598 : check e1211210183598 [[],[]] .smaller = true := by decide
def e1211210183610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211210183610 : Closed e1211210183610 ∧ code e1211210183610 = 5609256694714 := by decide
theorem cert_e1211210183610 : check e1211210183610 [[],[]] .smaller = true := by decide
def e1211210183638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211210183638 : Closed e1211210183638 ∧ code e1211210183638 = 5609256694742 := by decide
theorem cert_e1211210183638 : check e1211210183638 [[],[]] .smaller = true := by decide
def e1211210183642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211210183642 : Closed e1211210183642 ∧ code e1211210183642 = 5609256694746 := by decide
theorem cert_e1211210183642 : check e1211210183642 [[],[]] .smaller = true := by decide
def e1211210183918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211210183918 : Closed e1211210183918 ∧ code e1211210183918 = 5609256695022 := by decide
theorem cert_e1211210183918 : check e1211210183918 [[],[]] .smaller = true := by decide
def e1211210183926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211210183926 : Closed e1211210183926 ∧ code e1211210183926 = 5609256695030 := by decide
theorem cert_e1211210183926 : check e1211210183926 [[],[]] .smaller = true := by decide
def e1211210184254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e1211210184254 : Closed e1211210184254 ∧ code e1211210184254 = 5609256695358 := by decide
theorem cert_e1211210184254 : check e1211210184254 [[],[]] .smaller = true := by decide
def e1211210184302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210184302 : Closed e1211210184302 ∧ code e1211210184302 = 5609256695406 := by decide
theorem cert_e1211210184302 : check e1211210184302 [[],[]] .smaller = true := by decide
def e1211210184314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210184314 : Closed e1211210184314 ∧ code e1211210184314 = 5609256695418 := by decide
theorem cert_e1211210184314 : check e1211210184314 [[],[]] .smaller = true := by decide
def e1211210184502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210184502 : Closed e1211210184502 ∧ code e1211210184502 = 5609256695606 := by decide
theorem cert_e1211210184502 : check e1211210184502 [[],[]] .smaller = true := by decide
def e1211210184506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210184506 : Closed e1211210184506 ∧ code e1211210184506 = 5609256695610 := by decide
theorem cert_e1211210184506 : check e1211210184506 [[],[]] .smaller = true := by decide
def e1211210184590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e1211210184590 : Closed e1211210184590 ∧ code e1211210184590 = 5609256695694 := by decide
theorem cert_e1211210184590 : check e1211210184590 [[],[]] .smaller = true := by decide
def e1211210184638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e1211210184638 : Closed e1211210184638 ∧ code e1211210184638 = 5609256695742 := by decide
theorem cert_e1211210184638 : check e1211210184638 [[],[]] .chain = true := by decide
def e1211210184670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e1211210184670 : Closed e1211210184670 ∧ code e1211210184670 = 5609256695774 := by decide
theorem cert_e1211210184670 : check e1211210184670 [[],[]] .chain = true := by decide
def e1211210184926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211210184926 : Closed e1211210184926 ∧ code e1211210184926 = 5609256696030 := by decide
theorem cert_e1211210184926 : check e1211210184926 [[],[]] .smaller = true := by decide
def e1211210184954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211210184954 : Closed e1211210184954 ∧ code e1211210184954 = 5609256696058 := by decide
theorem cert_e1211210184954 : check e1211210184954 [[],[]] .smaller = true := by decide
def e1211210185134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1211210185134 : Closed e1211210185134 ∧ code e1211210185134 = 5609256696238 := by decide
theorem cert_e1211210185134 : check e1211210185134 [[],[]] .smaller = true := by decide
def e1211210185146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1211210185146 : Closed e1211210185146 ∧ code e1211210185146 = 5609256696250 := by decide
theorem cert_e1211210185146 : check e1211210185146 [[],[]] .smaller = true := by decide
def e1211210185194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1211210185194 : Closed e1211210185194 ∧ code e1211210185194 = 5609256696298 := by decide
theorem cert_e1211210185194 : check e1211210185194 [[],[]] .smaller = true := by decide
def e1211210185278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211210185278 : Closed e1211210185278 ∧ code e1211210185278 = 5609256696382 := by decide
theorem cert_e1211210185278 : check e1211210185278 [[],[]] .smaller = true := by decide
def e1211210185326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210185326 : Closed e1211210185326 ∧ code e1211210185326 = 5609256696430 := by decide
theorem cert_e1211210185326 : check e1211210185326 [[],[]] .smaller = true := by decide
def e1211210185338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210185338 : Closed e1211210185338 ∧ code e1211210185338 = 5609256696442 := by decide
theorem cert_e1211210185338 : check e1211210185338 [[],[]] .smaller = true := by decide
def e1211210185626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210185626 : Closed e1211210185626 ∧ code e1211210185626 = 5609256696730 := by decide
theorem cert_e1211210185626 : check e1211210185626 [[],[]] .smaller = true := by decide
def e1211210185670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211210185670 : Closed e1211210185670 ∧ code e1211210185670 = 5609256696774 := by decide
theorem cert_e1211210185670 : check e1211210185670 [[],[]] .smaller = true := by decide
def e1211210185942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211210185942 : Closed e1211210185942 ∧ code e1211210185942 = 5609256697046 := by decide
theorem cert_e1211210185942 : check e1211210185942 [[],[]] .smaller = true := by decide
def e1211210185946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211210185946 : Closed e1211210185946 ∧ code e1211210185946 = 5609256697050 := by decide
theorem cert_e1211210185946 : check e1211210185946 [[],[]] .smaller = true := by decide
def e1211210185962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211210185962 : Closed e1211210185962 ∧ code e1211210185962 = 5609256697066 := by decide
theorem cert_e1211210185962 : check e1211210185962 [[],[]] .smaller = true := by decide
def e1211210186038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210186038 : Closed e1211210186038 ∧ code e1211210186038 = 5609256697142 := by decide
theorem cert_e1211210186038 : check e1211210186038 [[],[]] .smaller = true := by decide
def e1211210186042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211210186042 : Closed e1211210186042 ∧ code e1211210186042 = 5609256697146 := by decide
theorem cert_e1211210186042 : check e1211210186042 [[],[]] .smaller = true := by decide
def e1211210186138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211210186138 : Closed e1211210186138 ∧ code e1211210186138 = 5609256697242 := by decide
theorem cert_e1211210186138 : check e1211210186138 [[],[]] .smaller = true := by decide
def e1211210186294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211210186294 : Closed e1211210186294 ∧ code e1211210186294 = 5609256697398 := by decide
theorem cert_e1211210186294 : check e1211210186294 [[],[]] .smaller = true := by decide
def e1211210186298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211210186298 : Closed e1211210186298 ∧ code e1211210186298 = 5609256697402 := by decide
theorem cert_e1211210186298 : check e1211210186298 [[],[]] .smaller = true := by decide
def e1211210186382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211210186382 : Closed e1211210186382 ∧ code e1211210186382 = 5609256697486 := by decide
theorem cert_e1211210186382 : check e1211210186382 [[],[]] .smaller = true := by decide
def e1211210186430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e1211210186430 : Closed e1211210186430 ∧ code e1211210186430 = 5609256697534 := by decide
theorem cert_e1211210186430 : check e1211210186430 [[],[]] .chain = true := by decide
def e1211210186438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211210186438 : Closed e1211210186438 ∧ code e1211210186438 = 5609256697542 := by decide
theorem cert_e1211210186438 : check e1211210186438 [[],[]] .smaller = true := by decide
def e1211210186490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e1211210186490 : Closed e1211210186490 ∧ code e1211210186490 = 5609256697594 := by decide
theorem cert_e1211210186490 : check e1211210186490 [[],[]] .chain = true := by decide
def e1211210186590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e1211210186590 : Closed e1211210186590 ∧ code e1211210186590 = 5609256697694 := by decide
theorem cert_e1211210186590 : check e1211210186590 [[],[]] .chain = true := by decide
def e1211210186618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e1211210186618 : Closed e1211210186618 ∧ code e1211210186618 = 5609256697722 := by decide
theorem cert_e1211210186618 : check e1211210186618 [[],[]] .chain = true := by decide
def e1211210189678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211210189678 : Closed e1211210189678 ∧ code e1211210189678 = 5609256700782 := by decide
theorem cert_e1211210189678 : check e1211210189678 [[],[]] .smaller = true := by decide
def e1211210189686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211210189686 : Closed e1211210189686 ∧ code e1211210189686 = 5609256700790 := by decide
theorem cert_e1211210189686 : check e1211210189686 [[],[]] .smaller = true := by decide
def e1211210189742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211210189742 : Closed e1211210189742 ∧ code e1211210189742 = 5609256700846 := by decide
theorem cert_e1211210189742 : check e1211210189742 [[],[]] .smaller = true := by decide
def e1211210189754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211210189754 : Closed e1211210189754 ∧ code e1211210189754 = 5609256700858 := by decide
theorem cert_e1211210189754 : check e1211210189754 [[],[]] .smaller = true := by decide
def e1211210189782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211210189782 : Closed e1211210189782 ∧ code e1211210189782 = 5609256700886 := by decide
theorem cert_e1211210189782 : check e1211210189782 [[],[]] .smaller = true := by decide
def e1211210189786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211210189786 : Closed e1211210189786 ∧ code e1211210189786 = 5609256700890 := by decide
theorem cert_e1211210189786 : check e1211210189786 [[],[]] .smaller = true := by decide
def e1211210190062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211210190062 : Closed e1211210190062 ∧ code e1211210190062 = 5609256701166 := by decide
theorem cert_e1211210190062 : check e1211210190062 [[],[]] .smaller = true := by decide
def e1211210190070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211210190070 : Closed e1211210190070 ∧ code e1211210190070 = 5609256701174 := by decide
theorem cert_e1211210190070 : check e1211210190070 [[],[]] .smaller = true := by decide
def e1211210190398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211210190398 : Closed e1211210190398 ∧ code e1211210190398 = 5609256701502 := by decide
theorem cert_e1211210190398 : check e1211210190398 [[],[]] .smaller = true := by decide
def e1211210190446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211210190446 : Closed e1211210190446 ∧ code e1211210190446 = 5609256701550 := by decide
theorem cert_e1211210190446 : check e1211210190446 [[],[]] .smaller = true := by decide
def e1211210190458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211210190458 : Closed e1211210190458 ∧ code e1211210190458 = 5609256701562 := by decide
theorem cert_e1211210190458 : check e1211210190458 [[],[]] .smaller = true := by decide
def e1211210190646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211210190646 : Closed e1211210190646 ∧ code e1211210190646 = 5609256701750 := by decide
theorem cert_e1211210190646 : check e1211210190646 [[],[]] .smaller = true := by decide
def e1211210190650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211210190650 : Closed e1211210190650 ∧ code e1211210190650 = 5609256701754 := by decide
theorem cert_e1211210190650 : check e1211210190650 [[],[]] .smaller = true := by decide
def e1211210190734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211210190734 : Closed e1211210190734 ∧ code e1211210190734 = 5609256701838 := by decide
theorem cert_e1211210190734 : check e1211210190734 [[],[]] .smaller = true := by decide
def e1211210190782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e1211210190782 : Closed e1211210190782 ∧ code e1211210190782 = 5609256701886 := by decide
theorem cert_e1211210190782 : check e1211210190782 [[],[]] .chain = true := by decide
def e1211210190814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e1211210190814 : Closed e1211210190814 ∧ code e1211210190814 = 5609256701918 := by decide
theorem cert_e1211210190814 : check e1211210190814 [[],[]] .chain = true := by decide
def e1211210196398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211210196398 : Closed e1211210196398 ∧ code e1211210196398 = 5609256707502 := by decide
theorem cert_e1211210196398 : check e1211210196398 [[],[]] .smaller = true := by decide
def e1211210196410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211210196410 : Closed e1211210196410 ∧ code e1211210196410 = 5609256707514 := by decide
theorem cert_e1211210196410 : check e1211210196410 [[],[]] .smaller = true := by decide
def e1211210196458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211210196458 : Closed e1211210196458 ∧ code e1211210196458 = 5609256707562 := by decide
theorem cert_e1211210196458 : check e1211210196458 [[],[]] .smaller = true := by decide
def e1211210196542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211210196542 : Closed e1211210196542 ∧ code e1211210196542 = 5609256707646 := by decide
theorem cert_e1211210196542 : check e1211210196542 [[],[]] .smaller = true := by decide
def e1211210196590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211210196590 : Closed e1211210196590 ∧ code e1211210196590 = 5609256707694 := by decide
theorem cert_e1211210196590 : check e1211210196590 [[],[]] .smaller = true := by decide
def e1211210196602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211210196602 : Closed e1211210196602 ∧ code e1211210196602 = 5609256707706 := by decide
theorem cert_e1211210196602 : check e1211210196602 [[],[]] .smaller = true := by decide
def e1211210196890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211210196890 : Closed e1211210196890 ∧ code e1211210196890 = 5609256707994 := by decide
theorem cert_e1211210196890 : check e1211210196890 [[],[]] .smaller = true := by decide
def e1211210196934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211210196934 : Closed e1211210196934 ∧ code e1211210196934 = 5609256708038 := by decide
theorem cert_e1211210196934 : check e1211210196934 [[],[]] .smaller = true := by decide
def e1211210199766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211210199766 : Closed e1211210199766 ∧ code e1211210199766 = 5609256710870 := by decide
theorem cert_e1211210199766 : check e1211210199766 [[],[]] .smaller = true := by decide
def e1211210199770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211210199770 : Closed e1211210199770 ∧ code e1211210199770 = 5609256710874 := by decide
theorem cert_e1211210199770 : check e1211210199770 [[],[]] .smaller = true := by decide
def e1211210199786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211210199786 : Closed e1211210199786 ∧ code e1211210199786 = 5609256710890 := by decide
theorem cert_e1211210199786 : check e1211210199786 [[],[]] .smaller = true := by decide
def e1211210199862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211210199862 : Closed e1211210199862 ∧ code e1211210199862 = 5609256710966 := by decide
theorem cert_e1211210199862 : check e1211210199862 [[],[]] .smaller = true := by decide
def e1211210199866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211210199866 : Closed e1211210199866 ∧ code e1211210199866 = 5609256710970 := by decide
theorem cert_e1211210199866 : check e1211210199866 [[],[]] .smaller = true := by decide
def e1211210199962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211210199962 : Closed e1211210199962 ∧ code e1211210199962 = 5609256711066 := by decide
theorem cert_e1211210199962 : check e1211210199962 [[],[]] .smaller = true := by decide
def e1211210201486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211210201486 : Closed e1211210201486 ∧ code e1211210201486 = 5609256712590 := by decide
theorem cert_e1211210201486 : check e1211210201486 [[],[]] .smaller = true := by decide
def e1211210201534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211210201534 : Closed e1211210201534 ∧ code e1211210201534 = 5609256712638 := by decide
theorem cert_e1211210201534 : check e1211210201534 [[],[]] .chain = true := by decide
def e1211210201542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211210201542 : Closed e1211210201542 ∧ code e1211210201542 = 5609256712646 := by decide
theorem cert_e1211210201542 : check e1211210201542 [[],[]] .smaller = true := by decide
def e1211210201594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211210201594 : Closed e1211210201594 ∧ code e1211210201594 = 5609256712698 := by decide
theorem cert_e1211210201594 : check e1211210201594 [[],[]] .chain = true := by decide
def e1211210202334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210202334 : Closed e1211210202334 ∧ code e1211210202334 = 5609256713438 := by decide
theorem cert_e1211210202334 : check e1211210202334 [[],[]] .chain = true := by decide
def e1211210202362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210202362 : Closed e1211210202362 ∧ code e1211210202362 = 5609256713466 := by decide
theorem cert_e1211210202362 : check e1211210202362 [[],[]] .chain = true := by decide
def e1211210314094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e1211210314094 : Closed e1211210314094 ∧ code e1211210314094 = 5609256825198 := by decide
theorem cert_e1211210314094 : check e1211210314094 [[],[]] .smaller = true := by decide
def e1211210314102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e1211210314102 : Closed e1211210314102 ∧ code e1211210314102 = 5609256825206 := by decide
theorem cert_e1211210314102 : check e1211210314102 [[],[]] .smaller = true := by decide
def e1211210315230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211210315230 : Closed e1211210315230 ∧ code e1211210315230 = 5609256826334 := by decide
theorem cert_e1211210315230 : check e1211210315230 [[],[]] .chain = true := by decide
def e1211210315246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211210315246 : Closed e1211210315246 ∧ code e1211210315246 = 5609256826350 := by decide
theorem cert_e1211210315246 : check e1211210315246 [[],[]] .chain = true := by decide
def e1211210315310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211210315310 : Closed e1211210315310 ∧ code e1211210315310 = 5609256826414 := by decide
theorem cert_e1211210315310 : check e1211210315310 [[],[]] .smaller = true := by decide
def e1211210315486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e1211210315486 : Closed e1211210315486 ∧ code e1211210315486 = 5609256826590 := by decide
theorem cert_e1211210315486 : check e1211210315486 [[],[]] .chain = true := by decide
def e1211210315490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211210315490 : Closed e1211210315490 ∧ code e1211210315490 = 5609256826594 := by decide
theorem cert_e1211210315490 : check e1211210315490 [[],[]] .smaller = true := by decide
def e1211210315502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1211210315502 : Closed e1211210315502 ∧ code e1211210315502 = 5609256826606 := by decide
theorem cert_e1211210315502 : check e1211210315502 [[],[]] .smaller = true := by decide
def e1211210315510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e1211210315510 : Closed e1211210315510 ∧ code e1211210315510 = 5609256826614 := by decide
theorem cert_e1211210315510 : check e1211210315510 [[],[]] .chain = true := by decide
def e1211210315542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211210315542 : Closed e1211210315542 ∧ code e1211210315542 = 5609256826646 := by decide
theorem cert_e1211210315542 : check e1211210315542 [[],[]] .smaller = true := by decide
def e1211210315614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211210315614 : Closed e1211210315614 ∧ code e1211210315614 = 5609256826718 := by decide
theorem cert_e1211210315614 : check e1211210315614 [[],[]] .chain = true := by decide
def e1211210315618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211210315618 : Closed e1211210315618 ∧ code e1211210315618 = 5609256826722 := by decide
theorem cert_e1211210315618 : check e1211210315618 [[],[]] .smaller = true := by decide
def e1211210315630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1211210315630 : Closed e1211210315630 ∧ code e1211210315630 = 5609256826734 := by decide
theorem cert_e1211210315630 : check e1211210315630 [[],[]] .smaller = true := by decide
def e1211210315638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1211210315638 : Closed e1211210315638 ∧ code e1211210315638 = 5609256826742 := by decide
theorem cert_e1211210315638 : check e1211210315638 [[],[]] .smaller = true := by decide
def e1211210315642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211210315642 : Closed e1211210315642 ∧ code e1211210315642 = 5609256826746 := by decide
theorem cert_e1211210315642 : check e1211210315642 [[],[]] .chain = true := by decide
def e1211210315694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211210315694 : Closed e1211210315694 ∧ code e1211210315694 = 5609256826798 := by decide
theorem cert_e1211210315694 : check e1211210315694 [[],[]] .chain = true := by decide
def e1211210315702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e1211210315702 : Closed e1211210315702 ∧ code e1211210315702 = 5609256826806 := by decide
theorem cert_e1211210315702 : check e1211210315702 [[],[]] .chain = true := by decide
def e1211210315706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211210315706 : Closed e1211210315706 ∧ code e1211210315706 = 5609256826810 := by decide
theorem cert_e1211210315706 : check e1211210315706 [[],[]] .chain = true := by decide
def e1211210315950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e1211210315950 : Closed e1211210315950 ∧ code e1211210315950 = 5609256827054 := by decide
theorem cert_e1211210315950 : check e1211210315950 [[],[]] .smaller = true := by decide
def e1211210315962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e1211210315962 : Closed e1211210315962 ∧ code e1211210315962 = 5609256827066 := by decide
theorem cert_e1211210315962 : check e1211210315962 [[],[]] .smaller = true := by decide
def e1211210316334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211210316334 : Closed e1211210316334 ∧ code e1211210316334 = 5609256827438 := by decide
theorem cert_e1211210316334 : check e1211210316334 [[],[]] .smaller = true := by decide
def e1211210316510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211210316510 : Closed e1211210316510 ∧ code e1211210316510 = 5609256827614 := by decide
theorem cert_e1211210316510 : check e1211210316510 [[],[]] .chain = true := by decide
def e1211210316514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211210316514 : Closed e1211210316514 ∧ code e1211210316514 = 5609256827618 := by decide
theorem cert_e1211210316514 : check e1211210316514 [[],[]] .smaller = true := by decide
def e1211210316526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e1211210316526 : Closed e1211210316526 ∧ code e1211210316526 = 5609256827630 := by decide
theorem cert_e1211210316526 : check e1211210316526 [[],[]] .smaller = true := by decide
def e1211210316534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211210316534 : Closed e1211210316534 ∧ code e1211210316534 = 5609256827638 := by decide
theorem cert_e1211210316534 : check e1211210316534 [[],[]] .chain = true := by decide
def e1211210316638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211210316638 : Closed e1211210316638 ∧ code e1211210316638 = 5609256827742 := by decide
theorem cert_e1211210316638 : check e1211210316638 [[],[]] .chain = true := by decide
def e1211210316666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211210316666 : Closed e1211210316666 ∧ code e1211210316666 = 5609256827770 := by decide
theorem cert_e1211210316666 : check e1211210316666 [[],[]] .chain = true := by decide
def e1211210316682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211210316682 : Closed e1211210316682 ∧ code e1211210316682 = 5609256827786 := by decide
theorem cert_e1211210316682 : check e1211210316682 [[],[]] .smaller = true := by decide
def e1211210316706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211210316706 : Closed e1211210316706 ∧ code e1211210316706 = 5609256827810 := by decide
theorem cert_e1211210316706 : check e1211210316706 [[],[]] .smaller = true := by decide
def e1211210316718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e1211210316718 : Closed e1211210316718 ∧ code e1211210316718 = 5609256827822 := by decide
theorem cert_e1211210316718 : check e1211210316718 [[],[]] .smaller = true := by decide
def e1211210316730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e1211210316730 : Closed e1211210316730 ∧ code e1211210316730 = 5609256827834 := by decide
theorem cert_e1211210316730 : check e1211210316730 [[],[]] .smaller = true := by decide
def e1211210316758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211210316758 : Closed e1211210316758 ∧ code e1211210316758 = 5609256827862 := by decide
theorem cert_e1211210316758 : check e1211210316758 [[],[]] .chain = true := by decide
def e1211210316762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211210316762 : Closed e1211210316762 ∧ code e1211210316762 = 5609256827866 := by decide
theorem cert_e1211210316762 : check e1211210316762 [[],[]] .chain = true := by decide
def e1211210316886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211210316886 : Closed e1211210316886 ∧ code e1211210316886 = 5609256827990 := by decide
theorem cert_e1211210316886 : check e1211210316886 [[],[]] .smaller = true := by decide
def e1211210316890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211210316890 : Closed e1211210316890 ∧ code e1211210316890 = 5609256827994 := by decide
theorem cert_e1211210316890 : check e1211210316890 [[],[]] .smaller = true := by decide
def e1211210317078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211210317078 : Closed e1211210317078 ∧ code e1211210317078 = 5609256828182 := by decide
theorem cert_e1211210317078 : check e1211210317078 [[],[]] .smaller = true := by decide
def e1211210317150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211210317150 : Closed e1211210317150 ∧ code e1211210317150 = 5609256828254 := by decide
theorem cert_e1211210317150 : check e1211210317150 [[],[]] .chain = true := by decide
def e1211210317154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211210317154 : Closed e1211210317154 ∧ code e1211210317154 = 5609256828258 := by decide
theorem cert_e1211210317154 : check e1211210317154 [[],[]] .smaller = true := by decide
def e1211210317166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211210317166 : Closed e1211210317166 ∧ code e1211210317166 = 5609256828270 := by decide
theorem cert_e1211210317166 : check e1211210317166 [[],[]] .smaller = true := by decide
def e1211210317174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211210317174 : Closed e1211210317174 ∧ code e1211210317174 = 5609256828278 := by decide
theorem cert_e1211210317174 : check e1211210317174 [[],[]] .smaller = true := by decide
def e1211210317178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211210317178 : Closed e1211210317178 ∧ code e1211210317178 = 5609256828282 := by decide
theorem cert_e1211210317178 : check e1211210317178 [[],[]] .chain = true := by decide
def e1211210317194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211210317194 : Closed e1211210317194 ∧ code e1211210317194 = 5609256828298 := by decide
theorem cert_e1211210317194 : check e1211210317194 [[],[]] .smaller = true := by decide
def e1211210317218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211210317218 : Closed e1211210317218 ∧ code e1211210317218 = 5609256828322 := by decide
theorem cert_e1211210317218 : check e1211210317218 [[],[]] .smaller = true := by decide
def e1211210317230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211210317230 : Closed e1211210317230 ∧ code e1211210317230 = 5609256828334 := by decide
theorem cert_e1211210317230 : check e1211210317230 [[],[]] .smaller = true := by decide
def e1211210317242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211210317242 : Closed e1211210317242 ∧ code e1211210317242 = 5609256828346 := by decide
theorem cert_e1211210317242 : check e1211210317242 [[],[]] .smaller = true := by decide
def e1211210317270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211210317270 : Closed e1211210317270 ∧ code e1211210317270 = 5609256828374 := by decide
theorem cert_e1211210317270 : check e1211210317270 [[],[]] .smaller = true := by decide
def e1211210317274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211210317274 : Closed e1211210317274 ∧ code e1211210317274 = 5609256828378 := by decide
theorem cert_e1211210317274 : check e1211210317274 [[],[]] .smaller = true := by decide
def e1211210317290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211210317290 : Closed e1211210317290 ∧ code e1211210317290 = 5609256828394 := by decide
theorem cert_e1211210317290 : check e1211210317290 [[],[]] .chain = true := by decide
def e1211210317486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211210317486 : Closed e1211210317486 ∧ code e1211210317486 = 5609256828590 := by decide
theorem cert_e1211210317486 : check e1211210317486 [[],[]] .chain = true := by decide
def e1211210317494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211210317494 : Closed e1211210317494 ∧ code e1211210317494 = 5609256828598 := by decide
theorem cert_e1211210317494 : check e1211210317494 [[],[]] .chain = true := by decide
def e1211210317498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211210317498 : Closed e1211210317498 ∧ code e1211210317498 = 5609256828602 := by decide
theorem cert_e1211210317498 : check e1211210317498 [[],[]] .chain = true := by decide
def e1211210317526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211210317526 : Closed e1211210317526 ∧ code e1211210317526 = 5609256828630 := by decide
theorem cert_e1211210317526 : check e1211210317526 [[],[]] .chain = true := by decide
def e1211210317530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211210317530 : Closed e1211210317530 ∧ code e1211210317530 = 5609256828634 := by decide
theorem cert_e1211210317530 : check e1211210317530 [[],[]] .chain = true := by decide
def e1211210317546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211210317546 : Closed e1211210317546 ∧ code e1211210317546 = 5609256828650 := by decide
theorem cert_e1211210317546 : check e1211210317546 [[],[]] .chain = true := by decide
def e1211210318318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e1211210318318 : Closed e1211210318318 ∧ code e1211210318318 = 5609256829422 := by decide
theorem cert_e1211210318318 : check e1211210318318 [[],[]] .smaller = true := by decide
def e1211210318326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e1211210318326 : Closed e1211210318326 ∧ code e1211210318326 = 5609256829430 := by decide
theorem cert_e1211210318326 : check e1211210318326 [[],[]] .smaller = true := by decide
def e1211210319086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210319086 : Closed e1211210319086 ∧ code e1211210319086 = 5609256830190 := by decide
theorem cert_e1211210319086 : check e1211210319086 [[],[]] .smaller = true := by decide
def e1211210319094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210319094 : Closed e1211210319094 ∧ code e1211210319094 = 5609256830198 := by decide
theorem cert_e1211210319094 : check e1211210319094 [[],[]] .smaller = true := by decide
def e1211210319646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e1211210319646 : Closed e1211210319646 ∧ code e1211210319646 = 5609256830750 := by decide
theorem cert_e1211210319646 : check e1211210319646 [[],[]] .smaller = true := by decide
def e1211210319758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e1211210319758 : Closed e1211210319758 ∧ code e1211210319758 = 5609256830862 := by decide
theorem cert_e1211210319758 : check e1211210319758 [[],[]] .smaller = true := by decide
def e1211210321374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211210321374 : Closed e1211210321374 ∧ code e1211210321374 = 5609256832478 := by decide
theorem cert_e1211210321374 : check e1211210321374 [[],[]] .chain = true := by decide
def e1211210321390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211210321390 : Closed e1211210321390 ∧ code e1211210321390 = 5609256832494 := by decide
theorem cert_e1211210321390 : check e1211210321390 [[],[]] .chain = true := by decide
def e1211210321454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211210321454 : Closed e1211210321454 ∧ code e1211210321454 = 5609256832558 := by decide
theorem cert_e1211210321454 : check e1211210321454 [[],[]] .smaller = true := by decide
def e1211210321630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e1211210321630 : Closed e1211210321630 ∧ code e1211210321630 = 5609256832734 := by decide
theorem cert_e1211210321630 : check e1211210321630 [[],[]] .chain = true := by decide
def e1211210321634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211210321634 : Closed e1211210321634 ∧ code e1211210321634 = 5609256832738 := by decide
theorem cert_e1211210321634 : check e1211210321634 [[],[]] .smaller = true := by decide
def e1211210321646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1211210321646 : Closed e1211210321646 ∧ code e1211210321646 = 5609256832750 := by decide
theorem cert_e1211210321646 : check e1211210321646 [[],[]] .smaller = true := by decide
def e1211210321654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e1211210321654 : Closed e1211210321654 ∧ code e1211210321654 = 5609256832758 := by decide
theorem cert_e1211210321654 : check e1211210321654 [[],[]] .chain = true := by decide
def e1211210321686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211210321686 : Closed e1211210321686 ∧ code e1211210321686 = 5609256832790 := by decide
theorem cert_e1211210321686 : check e1211210321686 [[],[]] .smaller = true := by decide
def e1211210321758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211210321758 : Closed e1211210321758 ∧ code e1211210321758 = 5609256832862 := by decide
theorem cert_e1211210321758 : check e1211210321758 [[],[]] .chain = true := by decide
def e1211210321762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211210321762 : Closed e1211210321762 ∧ code e1211210321762 = 5609256832866 := by decide
theorem cert_e1211210321762 : check e1211210321762 [[],[]] .smaller = true := by decide
def e1211210321774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1211210321774 : Closed e1211210321774 ∧ code e1211210321774 = 5609256832878 := by decide
theorem cert_e1211210321774 : check e1211210321774 [[],[]] .smaller = true := by decide
def e1211210321782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1211210321782 : Closed e1211210321782 ∧ code e1211210321782 = 5609256832886 := by decide
theorem cert_e1211210321782 : check e1211210321782 [[],[]] .smaller = true := by decide
def e1211210321786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211210321786 : Closed e1211210321786 ∧ code e1211210321786 = 5609256832890 := by decide
theorem cert_e1211210321786 : check e1211210321786 [[],[]] .chain = true := by decide
def e1211210321838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211210321838 : Closed e1211210321838 ∧ code e1211210321838 = 5609256832942 := by decide
theorem cert_e1211210321838 : check e1211210321838 [[],[]] .chain = true := by decide
def e1211210321846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e1211210321846 : Closed e1211210321846 ∧ code e1211210321846 = 5609256832950 := by decide
theorem cert_e1211210321846 : check e1211210321846 [[],[]] .chain = true := by decide
def e1211210321850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211210321850 : Closed e1211210321850 ∧ code e1211210321850 = 5609256832954 := by decide
theorem cert_e1211210321850 : check e1211210321850 [[],[]] .chain = true := by decide
def e1211210322910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211210322910 : Closed e1211210322910 ∧ code e1211210322910 = 5609256834014 := by decide
theorem cert_e1211210322910 : check e1211210322910 [[],[]] .chain = true := by decide
def e1211210322926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211210322926 : Closed e1211210322926 ∧ code e1211210322926 = 5609256834030 := by decide
theorem cert_e1211210322926 : check e1211210322926 [[],[]] .chain = true := by decide
def e1211210324030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e1211210324030 : Closed e1211210324030 ∧ code e1211210324030 = 5609256835134 := by decide
theorem cert_e1211210324030 : check e1211210324030 [[],[]] .smaller = true := by decide
end Blc.Floor42
