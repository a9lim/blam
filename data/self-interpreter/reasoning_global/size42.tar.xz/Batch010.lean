import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801272506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e302801272506 : Closed e302801272506 ∧ code e302801272506 = 4700847783610 := by decide
theorem cert_e302801272506 : check e302801272506 [[.under],[.under]] .three = true := by decide
def e302801272554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e302801272554 : Closed e302801272554 ∧ code e302801272554 = 4700847783658 := by decide
theorem cert_e302801272554 : check e302801272554 [[.under],[.under]] .three = true := by decide
def e302801276382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e302801276382 : Closed e302801276382 ∧ code e302801276382 = 4700847787486 := by decide
theorem cert_e302801276382 : check e302801276382 [[.under],[.under]] .three = true := by decide
def e302801276398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e302801276398 : Closed e302801276398 ∧ code e302801276398 = 4700847787502 := by decide
theorem cert_e302801276398 : check e302801276398 [[.under],[.under]] .three = true := by decide
def e302801276766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e302801276766 : Closed e302801276766 ∧ code e302801276766 = 4700847787870 := by decide
theorem cert_e302801276766 : check e302801276766 [[.under],[.under]] .three = true := by decide
def e302801276794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e302801276794 : Closed e302801276794 ∧ code e302801276794 = 4700847787898 := by decide
theorem cert_e302801276794 : check e302801276794 [[.under],[.under]] .three = true := by decide
def e302801276846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e302801276846 : Closed e302801276846 ∧ code e302801276846 = 4700847787950 := by decide
theorem cert_e302801276846 : check e302801276846 [[.under],[.under]] .three = true := by decide
def e302801276858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e302801276858 : Closed e302801276858 ∧ code e302801276858 = 4700847787962 := by decide
theorem cert_e302801276858 : check e302801276858 [[.under],[.under]] .three = true := by decide
def e302801277918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e302801277918 : Closed e302801277918 ∧ code e302801277918 = 4700847789022 := by decide
theorem cert_e302801277918 : check e302801277918 [[.under],[.under]] .three = true := by decide
def e302801277934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e302801277934 : Closed e302801277934 ∧ code e302801277934 = 4700847789038 := by decide
theorem cert_e302801277934 : check e302801277934 [[.under],[.under]] .three = true := by decide
def e302801280222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801280222 : Closed e302801280222 ∧ code e302801280222 = 4700847791326 := by decide
theorem cert_e302801280222 : check e302801280222 [[.under],[.under]] .three = true := by decide
def e302801280250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801280250 : Closed e302801280250 ∧ code e302801280250 = 4700847791354 := by decide
theorem cert_e302801280250 : check e302801280250 [[.under],[.under]] .three = true := by decide
def e302801280622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801280622 : Closed e302801280622 ∧ code e302801280622 = 4700847791726 := by decide
theorem cert_e302801280622 : check e302801280622 [[.under],[.under]] .three = true := by decide
def e302801280634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801280634 : Closed e302801280634 ∧ code e302801280634 = 4700847791738 := by decide
theorem cert_e302801280634 : check e302801280634 [[.under],[.under]] .three = true := by decide
def e302801285982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e302801285982 : Closed e302801285982 ∧ code e302801285982 = 4700847797086 := by decide
theorem cert_e302801285982 : check e302801285982 [[.under],[.under]] .three = true := by decide
def e302801286010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302801286010 : Closed e302801286010 ∧ code e302801286010 = 4700847797114 := by decide
theorem cert_e302801286010 : check e302801286010 [[.under],[.under]] .three = true := by decide
def e302801286122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302801286122 : Closed e302801286122 ∧ code e302801286122 = 4700847797226 := by decide
theorem cert_e302801286122 : check e302801286122 [[.under],[.under]] .three = true := by decide
def e302801286366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801286366 : Closed e302801286366 ∧ code e302801286366 = 4700847797470 := by decide
theorem cert_e302801286366 : check e302801286366 [[.under],[.under]] .three = true := by decide
def e302801286394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801286394 : Closed e302801286394 ∧ code e302801286394 = 4700847797498 := by decide
theorem cert_e302801286394 : check e302801286394 [[.under],[.under]] .three = true := by decide
def e302801287066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801287066 : Closed e302801287066 ∧ code e302801287066 = 4700847798170 := by decide
theorem cert_e302801287066 : check e302801287066 [[.under],[.under]] .three = true := by decide
def e302801287598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e302801287598 : Closed e302801287598 ∧ code e302801287598 = 4700847798702 := by decide
theorem cert_e302801287598 : check e302801287598 [[.under],[.under]] .three = true := by decide
def e302801287610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302801287610 : Closed e302801287610 ∧ code e302801287610 = 4700847798714 := by decide
theorem cert_e302801287610 : check e302801287610 [[.under],[.under]] .three = true := by decide
def e302801287658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302801287658 : Closed e302801287658 ∧ code e302801287658 = 4700847798762 := by decide
theorem cert_e302801287658 : check e302801287658 [[.under],[.under]] .three = true := by decide
def e302801287790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801287790 : Closed e302801287790 ∧ code e302801287790 = 4700847798894 := by decide
theorem cert_e302801287790 : check e302801287790 [[.under],[.under]] .three = true := by decide
def e302801287802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801287802 : Closed e302801287802 ∧ code e302801287802 = 4700847798906 := by decide
theorem cert_e302801287802 : check e302801287802 [[.under],[.under]] .three = true := by decide
def e302801288090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801288090 : Closed e302801288090 ∧ code e302801288090 = 4700847799194 := by decide
theorem cert_e302801288090 : check e302801288090 [[.under],[.under]] .three = true := by decide
def e302801300958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e302801300958 : Closed e302801300958 ∧ code e302801300958 = 4700847812062 := by decide
theorem cert_e302801300958 : check e302801300958 [[.under],[.under]] .three = true := by decide
def e302801300974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e302801300974 : Closed e302801300974 ∧ code e302801300974 = 4700847812078 := by decide
theorem cert_e302801300974 : check e302801300974 [[.under],[.under]] .three = true := by decide
def e302801301342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e302801301342 : Closed e302801301342 ∧ code e302801301342 = 4700847812446 := by decide
theorem cert_e302801301342 : check e302801301342 [[.under],[.under]] .three = true := by decide
def e302801301370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e302801301370 : Closed e302801301370 ∧ code e302801301370 = 4700847812474 := by decide
theorem cert_e302801301370 : check e302801301370 [[.under],[.under]] .three = true := by decide
def e302801301422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e302801301422 : Closed e302801301422 ∧ code e302801301422 = 4700847812526 := by decide
theorem cert_e302801301422 : check e302801301422 [[.under],[.under]] .three = true := by decide
def e302801301434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e302801301434 : Closed e302801301434 ∧ code e302801301434 = 4700847812538 := by decide
theorem cert_e302801301434 : check e302801301434 [[.under],[.under]] .three = true := by decide
def e302801302494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801302494 : Closed e302801302494 ∧ code e302801302494 = 4700847813598 := by decide
theorem cert_e302801302494 : check e302801302494 [[.under],[.under]] .three = true := by decide
def e302801302510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801302510 : Closed e302801302510 ∧ code e302801302510 = 4700847813614 := by decide
theorem cert_e302801302510 : check e302801302510 [[.under],[.under]] .three = true := by decide
def e302801304798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801304798 : Closed e302801304798 ∧ code e302801304798 = 4700847815902 := by decide
theorem cert_e302801304798 : check e302801304798 [[.under],[.under]] .three = true := by decide
def e302801304826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801304826 : Closed e302801304826 ∧ code e302801304826 = 4700847815930 := by decide
theorem cert_e302801304826 : check e302801304826 [[.under],[.under]] .three = true := by decide
def e302801305198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801305198 : Closed e302801305198 ∧ code e302801305198 = 4700847816302 := by decide
theorem cert_e302801305198 : check e302801305198 [[.under],[.under]] .three = true := by decide
def e302801305210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801305210 : Closed e302801305210 ∧ code e302801305210 = 4700847816314 := by decide
theorem cert_e302801305210 : check e302801305210 [[.under],[.under]] .three = true := by decide
def e302801341278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302801341278 : Closed e302801341278 ∧ code e302801341278 = 4700847852382 := by decide
theorem cert_e302801341278 : check e302801341278 [[.under],[.under]] .three = true := by decide
def e302801341306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302801341306 : Closed e302801341306 ∧ code e302801341306 = 4700847852410 := by decide
theorem cert_e302801341306 : check e302801341306 [[.under],[.under]] .three = true := by decide
def e302801341418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302801341418 : Closed e302801341418 ∧ code e302801341418 = 4700847852522 := by decide
theorem cert_e302801341418 : check e302801341418 [[.under],[.under]] .three = true := by decide
def e302801341662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801341662 : Closed e302801341662 ∧ code e302801341662 = 4700847852766 := by decide
theorem cert_e302801341662 : check e302801341662 [[.under],[.under]] .three = true := by decide
def e302801341690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801341690 : Closed e302801341690 ∧ code e302801341690 = 4700847852794 := by decide
theorem cert_e302801341690 : check e302801341690 [[.under],[.under]] .three = true := by decide
def e302801342362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801342362 : Closed e302801342362 ∧ code e302801342362 = 4700847853466 := by decide
theorem cert_e302801342362 : check e302801342362 [[.under],[.under]] .three = true := by decide
def e302801348014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e302801348014 : Closed e302801348014 ∧ code e302801348014 = 4700847859118 := by decide
theorem cert_e302801348014 : check e302801348014 [[.under],[.under]] .three = true := by decide
def e302801348026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e302801348026 : Closed e302801348026 ∧ code e302801348026 = 4700847859130 := by decide
theorem cert_e302801348026 : check e302801348026 [[.under],[.under]] .three = true := by decide
def e302801348074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e302801348074 : Closed e302801348074 ∧ code e302801348074 = 4700847859178 := by decide
theorem cert_e302801348074 : check e302801348074 [[.under],[.under]] .three = true := by decide
def e302801348206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801348206 : Closed e302801348206 ∧ code e302801348206 = 4700847859310 := by decide
theorem cert_e302801348206 : check e302801348206 [[.under],[.under]] .three = true := by decide
def e302801348218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801348218 : Closed e302801348218 ∧ code e302801348218 = 4700847859322 := by decide
theorem cert_e302801348218 : check e302801348218 [[.under],[.under]] .three = true := by decide
def e302801348506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801348506 : Closed e302801348506 ∧ code e302801348506 = 4700847859610 := by decide
theorem cert_e302801348506 : check e302801348506 [[.under],[.under]] .three = true := by decide
def e302801378014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e302801378014 : Closed e302801378014 ∧ code e302801378014 = 4700847889118 := by decide
theorem cert_e302801378014 : check e302801378014 [[.under],[.under]] .three = true := by decide
def e302801378038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e302801378038 : Closed e302801378038 ∧ code e302801378038 = 4700847889142 := by decide
theorem cert_e302801378038 : check e302801378038 [[.under],[.under]] .three = true := by decide
def e302801378142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e302801378142 : Closed e302801378142 ∧ code e302801378142 = 4700847889246 := by decide
theorem cert_e302801378142 : check e302801378142 [[.under],[.under]] .three = true := by decide
def e302801378170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e302801378170 : Closed e302801378170 ∧ code e302801378170 = 4700847889274 := by decide
theorem cert_e302801378170 : check e302801378170 [[.under],[.under]] .three = true := by decide
def e302801378262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e302801378262 : Closed e302801378262 ∧ code e302801378262 = 4700847889366 := by decide
theorem cert_e302801378262 : check e302801378262 [[.under],[.under]] .three = true := by decide
def e302801378266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e302801378266 : Closed e302801378266 ∧ code e302801378266 = 4700847889370 := by decide
theorem cert_e302801378266 : check e302801378266 [[.under],[.under]] .three = true := by decide
def e302801378654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e302801378654 : Closed e302801378654 ∧ code e302801378654 = 4700847889758 := by decide
theorem cert_e302801378654 : check e302801378654 [[.under],[.under]] .three = true := by decide
def e302801378682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e302801378682 : Closed e302801378682 ∧ code e302801378682 = 4700847889786 := by decide
theorem cert_e302801378682 : check e302801378682 [[.under],[.under]] .three = true := by decide
def e302801378794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e302801378794 : Closed e302801378794 ∧ code e302801378794 = 4700847889898 := by decide
theorem cert_e302801378794 : check e302801378794 [[.under],[.under]] .three = true := by decide
def e302801379158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302801379158 : Closed e302801379158 ∧ code e302801379158 = 4700847890262 := by decide
theorem cert_e302801379158 : check e302801379158 [[.under],[.under]] .three = true := by decide
def e302801379162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302801379162 : Closed e302801379162 ∧ code e302801379162 = 4700847890266 := by decide
theorem cert_e302801379162 : check e302801379162 [[.under],[.under]] .three = true := by decide
def e302801379178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302801379178 : Closed e302801379178 ∧ code e302801379178 = 4700847890282 := by decide
theorem cert_e302801379178 : check e302801379178 [[.under],[.under]] .three = true := by decide
def e302801381086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e302801381086 : Closed e302801381086 ∧ code e302801381086 = 4700847892190 := by decide
theorem cert_e302801381086 : check e302801381086 [[.under],[.under]] .three = true := by decide
def e302801381110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302801381110 : Closed e302801381110 ∧ code e302801381110 = 4700847892214 := by decide
theorem cert_e302801381110 : check e302801381110 [[.under],[.under]] .three = true := by decide
def e302801381214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e302801381214 : Closed e302801381214 ∧ code e302801381214 = 4700847892318 := by decide
theorem cert_e302801381214 : check e302801381214 [[.under],[.under]] .three = true := by decide
def e302801381242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e302801381242 : Closed e302801381242 ∧ code e302801381242 = 4700847892346 := by decide
theorem cert_e302801381242 : check e302801381242 [[.under],[.under]] .three = true := by decide
def e302801381334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302801381334 : Closed e302801381334 ∧ code e302801381334 = 4700847892438 := by decide
theorem cert_e302801381334 : check e302801381334 [[.under],[.under]] .three = true := by decide
def e302801381338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e302801381338 : Closed e302801381338 ∧ code e302801381338 = 4700847892442 := by decide
theorem cert_e302801381338 : check e302801381338 [[.under],[.under]] .three = true := by decide
def e302801381854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e302801381854 : Closed e302801381854 ∧ code e302801381854 = 4700847892958 := by decide
theorem cert_e302801381854 : check e302801381854 [[.under],[.under]] .three = true := by decide
def e302801381878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e302801381878 : Closed e302801381878 ∧ code e302801381878 = 4700847892982 := by decide
theorem cert_e302801381878 : check e302801381878 [[.under],[.under]] .three = true := by decide
def e302801382622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801382622 : Closed e302801382622 ∧ code e302801382622 = 4700847893726 := by decide
theorem cert_e302801382622 : check e302801382622 [[.under],[.under]] .three = true := by decide
def e302801382650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801382650 : Closed e302801382650 ∧ code e302801382650 = 4700847893754 := by decide
theorem cert_e302801382650 : check e302801382650 [[.under],[.under]] .three = true := by decide
def e302801383222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801383222 : Closed e302801383222 ∧ code e302801383222 = 4700847894326 := by decide
theorem cert_e302801383222 : check e302801383222 [[.under],[.under]] .three = true := by decide
def e302801383226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801383226 : Closed e302801383226 ∧ code e302801383226 = 4700847894330 := by decide
theorem cert_e302801383226 : check e302801383226 [[.under],[.under]] .three = true := by decide
def e302801384286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e302801384286 : Closed e302801384286 ∧ code e302801384286 = 4700847895390 := by decide
theorem cert_e302801384286 : check e302801384286 [[.under],[.under]] .three = true := by decide
def e302801384314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302801384314 : Closed e302801384314 ∧ code e302801384314 = 4700847895418 := by decide
theorem cert_e302801384314 : check e302801384314 [[.under],[.under]] .three = true := by decide
def e302801384426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302801384426 : Closed e302801384426 ∧ code e302801384426 = 4700847895530 := by decide
theorem cert_e302801384426 : check e302801384426 [[.under],[.under]] .three = true := by decide
def e302801384670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801384670 : Closed e302801384670 ∧ code e302801384670 = 4700847895774 := by decide
theorem cert_e302801384670 : check e302801384670 [[.under],[.under]] .three = true := by decide
def e302801384698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801384698 : Closed e302801384698 ∧ code e302801384698 = 4700847895802 := by decide
theorem cert_e302801384698 : check e302801384698 [[.under],[.under]] .three = true := by decide
def e302801385370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801385370 : Closed e302801385370 ∧ code e302801385370 = 4700847896474 := by decide
theorem cert_e302801385370 : check e302801385370 [[.under],[.under]] .three = true := by decide
def e302801386710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302801386710 : Closed e302801386710 ∧ code e302801386710 = 4700847897814 := by decide
theorem cert_e302801386710 : check e302801386710 [[.under],[.under]] .three = true := by decide
def e302801386714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302801386714 : Closed e302801386714 ∧ code e302801386714 = 4700847897818 := by decide
theorem cert_e302801386714 : check e302801386714 [[.under],[.under]] .three = true := by decide
def e302801386730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302801386730 : Closed e302801386730 ∧ code e302801386730 = 4700847897834 := by decide
theorem cert_e302801386730 : check e302801386730 [[.under],[.under]] .three = true := by decide
def e302801386806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801386806 : Closed e302801386806 ∧ code e302801386806 = 4700847897910 := by decide
theorem cert_e302801386806 : check e302801386806 [[.under],[.under]] .three = true := by decide
def e302801386810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801386810 : Closed e302801386810 ∧ code e302801386810 = 4700847897914 := by decide
theorem cert_e302801386810 : check e302801386810 [[.under],[.under]] .three = true := by decide
def e302801386906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801386906 : Closed e302801386906 ∧ code e302801386906 = 4700847898010 := by decide
theorem cert_e302801386906 : check e302801386906 [[.under],[.under]] .three = true := by decide
def e302801393374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302801393374 : Closed e302801393374 ∧ code e302801393374 = 4700847904478 := by decide
theorem cert_e302801393374 : check e302801393374 [[.under],[.under]] .three = true := by decide
def e302801393398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302801393398 : Closed e302801393398 ∧ code e302801393398 = 4700847904502 := by decide
theorem cert_e302801393398 : check e302801393398 [[.under],[.under]] .three = true := by decide
def e302801393502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302801393502 : Closed e302801393502 ∧ code e302801393502 = 4700847904606 := by decide
theorem cert_e302801393502 : check e302801393502 [[.under],[.under]] .three = true := by decide
def e302801393530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302801393530 : Closed e302801393530 ∧ code e302801393530 = 4700847904634 := by decide
theorem cert_e302801393530 : check e302801393530 [[.under],[.under]] .three = true := by decide
def e302801393622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302801393622 : Closed e302801393622 ∧ code e302801393622 = 4700847904726 := by decide
theorem cert_e302801393622 : check e302801393622 [[.under],[.under]] .three = true := by decide
def e302801393626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302801393626 : Closed e302801393626 ∧ code e302801393626 = 4700847904730 := by decide
theorem cert_e302801393626 : check e302801393626 [[.under],[.under]] .three = true := by decide
def e302801394142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801394142 : Closed e302801394142 ∧ code e302801394142 = 4700847905246 := by decide
theorem cert_e302801394142 : check e302801394142 [[.under],[.under]] .three = true := by decide
def e302801394166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801394166 : Closed e302801394166 ∧ code e302801394166 = 4700847905270 := by decide
theorem cert_e302801394166 : check e302801394166 [[.under],[.under]] .three = true := by decide
def e302801394910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801394910 : Closed e302801394910 ∧ code e302801394910 = 4700847906014 := by decide
theorem cert_e302801394910 : check e302801394910 [[.under],[.under]] .three = true := by decide
def e302801394938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801394938 : Closed e302801394938 ∧ code e302801394938 = 4700847906042 := by decide
theorem cert_e302801394938 : check e302801394938 [[.under],[.under]] .three = true := by decide
def e302801395510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801395510 : Closed e302801395510 ∧ code e302801395510 = 4700847906614 := by decide
theorem cert_e302801395510 : check e302801395510 [[.under],[.under]] .three = true := by decide
def e302801395514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801395514 : Closed e302801395514 ∧ code e302801395514 = 4700847906618 := by decide
theorem cert_e302801395514 : check e302801395514 [[.under],[.under]] .three = true := by decide
def e302801406814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302801406814 : Closed e302801406814 ∧ code e302801406814 = 4700847917918 := by decide
theorem cert_e302801406814 : check e302801406814 [[.under],[.under]] .three = true := by decide
def e302801406842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302801406842 : Closed e302801406842 ∧ code e302801406842 = 4700847917946 := by decide
theorem cert_e302801406842 : check e302801406842 [[.under],[.under]] .three = true := by decide
def e302801406954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302801406954 : Closed e302801406954 ∧ code e302801406954 = 4700847918058 := by decide
theorem cert_e302801406954 : check e302801406954 [[.under],[.under]] .three = true := by decide
def e302801407198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801407198 : Closed e302801407198 ∧ code e302801407198 = 4700847918302 := by decide
theorem cert_e302801407198 : check e302801407198 [[.under],[.under]] .three = true := by decide
def e302801407226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801407226 : Closed e302801407226 ∧ code e302801407226 = 4700847918330 := by decide
theorem cert_e302801407226 : check e302801407226 [[.under],[.under]] .three = true := by decide
def e302801407898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801407898 : Closed e302801407898 ∧ code e302801407898 = 4700847919002 := by decide
theorem cert_e302801407898 : check e302801407898 [[.under],[.under]] .three = true := by decide
def e302801416918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302801416918 : Closed e302801416918 ∧ code e302801416918 = 4700847928022 := by decide
theorem cert_e302801416918 : check e302801416918 [[.under],[.under]] .three = true := by decide
def e302801416922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302801416922 : Closed e302801416922 ∧ code e302801416922 = 4700847928026 := by decide
theorem cert_e302801416922 : check e302801416922 [[.under],[.under]] .three = true := by decide
def e302801416938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302801416938 : Closed e302801416938 ∧ code e302801416938 = 4700847928042 := by decide
theorem cert_e302801416938 : check e302801416938 [[.under],[.under]] .three = true := by decide
def e302801417014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801417014 : Closed e302801417014 ∧ code e302801417014 = 4700847928118 := by decide
theorem cert_e302801417014 : check e302801417014 [[.under],[.under]] .three = true := by decide
def e302801417018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801417018 : Closed e302801417018 ∧ code e302801417018 = 4700847928122 := by decide
theorem cert_e302801417018 : check e302801417018 [[.under],[.under]] .three = true := by decide
def e302801417114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801417114 : Closed e302801417114 ∧ code e302801417114 = 4700847928218 := by decide
theorem cert_e302801417114 : check e302801417114 [[.under],[.under]] .three = true := by decide
def e302801431918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e302801431918 : Closed e302801431918 ∧ code e302801431918 = 4700847943022 := by decide
theorem cert_e302801431918 : check e302801431918 [[.under],[.under]] .three = true := by decide
def e302801431926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e302801431926 : Closed e302801431926 ∧ code e302801431926 = 4700847943030 := by decide
theorem cert_e302801431926 : check e302801431926 [[.under],[.under]] .three = true := by decide
def e302801431982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e302801431982 : Closed e302801431982 ∧ code e302801431982 = 4700847943086 := by decide
theorem cert_e302801431982 : check e302801431982 [[.under],[.under]] .three = true := by decide
def e302801431994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e302801431994 : Closed e302801431994 ∧ code e302801431994 = 4700847943098 := by decide
theorem cert_e302801431994 : check e302801431994 [[.under],[.under]] .three = true := by decide
def e302801432022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e302801432022 : Closed e302801432022 ∧ code e302801432022 = 4700847943126 := by decide
theorem cert_e302801432022 : check e302801432022 [[.under],[.under]] .three = true := by decide
def e302801432026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e302801432026 : Closed e302801432026 ∧ code e302801432026 = 4700847943130 := by decide
theorem cert_e302801432026 : check e302801432026 [[.under],[.under]] .three = true := by decide
def e302801432238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e302801432238 : Closed e302801432238 ∧ code e302801432238 = 4700847943342 := by decide
theorem cert_e302801432238 : check e302801432238 [[.under],[.under]] .three = true := by decide
def e302801432250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e302801432250 : Closed e302801432250 ∧ code e302801432250 = 4700847943354 := by decide
theorem cert_e302801432250 : check e302801432250 [[.under],[.under]] .three = true := by decide
def e302801432298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e302801432298 : Closed e302801432298 ∧ code e302801432298 = 4700847943402 := by decide
theorem cert_e302801432298 : check e302801432298 [[.under],[.under]] .three = true := by decide
def e302801432406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302801432406 : Closed e302801432406 ∧ code e302801432406 = 4700847943510 := by decide
theorem cert_e302801432406 : check e302801432406 [[.under],[.under]] .three = true := by decide
def e302801432410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302801432410 : Closed e302801432410 ∧ code e302801432410 = 4700847943514 := by decide
theorem cert_e302801432410 : check e302801432410 [[.under],[.under]] .three = true := by decide
def e302801432426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302801432426 : Closed e302801432426 ∧ code e302801432426 = 4700847943530 := by decide
theorem cert_e302801432426 : check e302801432426 [[.under],[.under]] .three = true := by decide
def e302801433454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302801433454 : Closed e302801433454 ∧ code e302801433454 = 4700847944558 := by decide
theorem cert_e302801433454 : check e302801433454 [[.under],[.under]] .three = true := by decide
def e302801433462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e302801433462 : Closed e302801433462 ∧ code e302801433462 = 4700847944566 := by decide
theorem cert_e302801433462 : check e302801433462 [[.under],[.under]] .three = true := by decide
def e302801433518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302801433518 : Closed e302801433518 ∧ code e302801433518 = 4700847944622 := by decide
theorem cert_e302801433518 : check e302801433518 [[.under],[.under]] .three = true := by decide
def e302801433530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e302801433530 : Closed e302801433530 ∧ code e302801433530 = 4700847944634 := by decide
theorem cert_e302801433530 : check e302801433530 [[.under],[.under]] .three = true := by decide
def e302801433558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e302801433558 : Closed e302801433558 ∧ code e302801433558 = 4700847944662 := by decide
theorem cert_e302801433558 : check e302801433558 [[.under],[.under]] .three = true := by decide
def e302801433562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e302801433562 : Closed e302801433562 ∧ code e302801433562 = 4700847944666 := by decide
theorem cert_e302801433562 : check e302801433562 [[.under],[.under]] .three = true := by decide
def e302801433838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302801433838 : Closed e302801433838 ∧ code e302801433838 = 4700847944942 := by decide
theorem cert_e302801433838 : check e302801433838 [[.under],[.under]] .three = true := by decide
def e302801433846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302801433846 : Closed e302801433846 ∧ code e302801433846 = 4700847944950 := by decide
theorem cert_e302801433846 : check e302801433846 [[.under],[.under]] .three = true := by decide
def e302801434222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801434222 : Closed e302801434222 ∧ code e302801434222 = 4700847945326 := by decide
theorem cert_e302801434222 : check e302801434222 [[.under],[.under]] .three = true := by decide
def e302801434234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801434234 : Closed e302801434234 ∧ code e302801434234 = 4700847945338 := by decide
theorem cert_e302801434234 : check e302801434234 [[.under],[.under]] .three = true := by decide
def e302801434422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801434422 : Closed e302801434422 ∧ code e302801434422 = 4700847945526 := by decide
theorem cert_e302801434422 : check e302801434422 [[.under],[.under]] .three = true := by decide
def e302801434426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801434426 : Closed e302801434426 ∧ code e302801434426 = 4700847945530 := by decide
theorem cert_e302801434426 : check e302801434426 [[.under],[.under]] .three = true := by decide
def e302801435054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e302801435054 : Closed e302801435054 ∧ code e302801435054 = 4700847946158 := by decide
theorem cert_e302801435054 : check e302801435054 [[.under],[.under]] .three = true := by decide
def e302801435066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302801435066 : Closed e302801435066 ∧ code e302801435066 = 4700847946170 := by decide
theorem cert_e302801435066 : check e302801435066 [[.under],[.under]] .three = true := by decide
def e302801435114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302801435114 : Closed e302801435114 ∧ code e302801435114 = 4700847946218 := by decide
theorem cert_e302801435114 : check e302801435114 [[.under],[.under]] .three = true := by decide
def e302801435246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801435246 : Closed e302801435246 ∧ code e302801435246 = 4700847946350 := by decide
theorem cert_e302801435246 : check e302801435246 [[.under],[.under]] .three = true := by decide
def e302801435258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801435258 : Closed e302801435258 ∧ code e302801435258 = 4700847946362 := by decide
theorem cert_e302801435258 : check e302801435258 [[.under],[.under]] .three = true := by decide
def e302801435546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801435546 : Closed e302801435546 ∧ code e302801435546 = 4700847946650 := by decide
theorem cert_e302801435546 : check e302801435546 [[.under],[.under]] .three = true := by decide
def e302801435862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302801435862 : Closed e302801435862 ∧ code e302801435862 = 4700847946966 := by decide
theorem cert_e302801435862 : check e302801435862 [[.under],[.under]] .three = true := by decide
def e302801435866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302801435866 : Closed e302801435866 ∧ code e302801435866 = 4700847946970 := by decide
theorem cert_e302801435866 : check e302801435866 [[.under],[.under]] .three = true := by decide
def e302801435882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302801435882 : Closed e302801435882 ∧ code e302801435882 = 4700847946986 := by decide
theorem cert_e302801435882 : check e302801435882 [[.under],[.under]] .three = true := by decide
def e302801435958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801435958 : Closed e302801435958 ∧ code e302801435958 = 4700847947062 := by decide
theorem cert_e302801435958 : check e302801435958 [[.under],[.under]] .three = true := by decide
def e302801435962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801435962 : Closed e302801435962 ∧ code e302801435962 = 4700847947066 := by decide
theorem cert_e302801435962 : check e302801435962 [[.under],[.under]] .three = true := by decide
def e302801436058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801436058 : Closed e302801436058 ∧ code e302801436058 = 4700847947162 := by decide
theorem cert_e302801436058 : check e302801436058 [[.under],[.under]] .three = true := by decide
def e302801439598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302801439598 : Closed e302801439598 ∧ code e302801439598 = 4700847950702 := by decide
theorem cert_e302801439598 : check e302801439598 [[.under],[.under]] .three = true := by decide
def e302801439606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302801439606 : Closed e302801439606 ∧ code e302801439606 = 4700847950710 := by decide
theorem cert_e302801439606 : check e302801439606 [[.under],[.under]] .three = true := by decide
def e302801439662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302801439662 : Closed e302801439662 ∧ code e302801439662 = 4700847950766 := by decide
theorem cert_e302801439662 : check e302801439662 [[.under],[.under]] .three = true := by decide
def e302801439674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302801439674 : Closed e302801439674 ∧ code e302801439674 = 4700847950778 := by decide
theorem cert_e302801439674 : check e302801439674 [[.under],[.under]] .three = true := by decide
def e302801439702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302801439702 : Closed e302801439702 ∧ code e302801439702 = 4700847950806 := by decide
theorem cert_e302801439702 : check e302801439702 [[.under],[.under]] .three = true := by decide
def e302801439706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302801439706 : Closed e302801439706 ∧ code e302801439706 = 4700847950810 := by decide
theorem cert_e302801439706 : check e302801439706 [[.under],[.under]] .three = true := by decide
def e302801439982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801439982 : Closed e302801439982 ∧ code e302801439982 = 4700847951086 := by decide
theorem cert_e302801439982 : check e302801439982 [[.under],[.under]] .three = true := by decide
def e302801439990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801439990 : Closed e302801439990 ∧ code e302801439990 = 4700847951094 := by decide
theorem cert_e302801439990 : check e302801439990 [[.under],[.under]] .three = true := by decide
def e302801440366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801440366 : Closed e302801440366 ∧ code e302801440366 = 4700847951470 := by decide
theorem cert_e302801440366 : check e302801440366 [[.under],[.under]] .three = true := by decide
def e302801440378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801440378 : Closed e302801440378 ∧ code e302801440378 = 4700847951482 := by decide
theorem cert_e302801440378 : check e302801440378 [[.under],[.under]] .three = true := by decide
def e302801440566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801440566 : Closed e302801440566 ∧ code e302801440566 = 4700847951670 := by decide
theorem cert_e302801440566 : check e302801440566 [[.under],[.under]] .three = true := by decide
def e302801440570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801440570 : Closed e302801440570 ∧ code e302801440570 = 4700847951674 := by decide
theorem cert_e302801440570 : check e302801440570 [[.under],[.under]] .three = true := by decide
def e302801446318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e302801446318 : Closed e302801446318 ∧ code e302801446318 = 4700847957422 := by decide
theorem cert_e302801446318 : check e302801446318 [[.under],[.under]] .three = true := by decide
def e302801446330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e302801446330 : Closed e302801446330 ∧ code e302801446330 = 4700847957434 := by decide
theorem cert_e302801446330 : check e302801446330 [[.under],[.under]] .three = true := by decide
end Blc.Floor42
