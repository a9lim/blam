import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203767914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211203767914 : Closed e1211203767914 ∧ code e1211203767914 = 5609250279018 := by decide
theorem cert_e1211203767914 : check e1211203767914 [[],[]] .chain = true := by decide
def e1211203767938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203767938 : Closed e1211203767938 ∧ code e1211203767938 = 5609250279042 := by decide
theorem cert_e1211203767938 : check e1211203767938 [[],[]] .chain = true := by decide
def e1211203767950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203767950 : Closed e1211203767950 ∧ code e1211203767950 = 5609250279054 := by decide
theorem cert_e1211203767950 : check e1211203767950 [[],[]] .chain = true := by decide
def e1211203767962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203767962 : Closed e1211203767962 ∧ code e1211203767962 = 5609250279066 := by decide
theorem cert_e1211203767962 : check e1211203767962 [[],[]] .chain = true := by decide
def e1211203768006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203768006 : Closed e1211203768006 ∧ code e1211203768006 = 5609250279110 := by decide
theorem cert_e1211203768006 : check e1211203768006 [[],[]] .chain = true := by decide
def e1211203768090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203768090 : Closed e1211203768090 ∧ code e1211203768090 = 5609250279194 := by decide
theorem cert_e1211203768090 : check e1211203768090 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203768134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203768134 : Closed e1211203768134 ∧ code e1211203768134 = 5609250279238 := by decide
theorem cert_e1211203768134 : check e1211203768134 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203768350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203768350 : Closed e1211203768350 ∧ code e1211203768350 = 5609250279454 := by decide
theorem cert_e1211203768350 : check e1211203768350 [[],[]] .chain = true := by decide
def e1211203768518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203768518 : Closed e1211203768518 ∧ code e1211203768518 = 5609250279622 := by decide
theorem cert_e1211203768518 : check e1211203768518 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203768542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203768542 : Closed e1211203768542 ∧ code e1211203768542 = 5609250279646 := by decide
theorem cert_e1211203768542 : check e1211203768542 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203768546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203768546 : Closed e1211203768546 ∧ code e1211203768546 = 5609250279650 := by decide
theorem cert_e1211203768546 : check e1211203768546 [[],[]] .chain = true := by decide
def e1211203768558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203768558 : Closed e1211203768558 ∧ code e1211203768558 = 5609250279662 := by decide
theorem cert_e1211203768558 : check e1211203768558 [[],[]] .chain = true := by decide
def e1211203768566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203768566 : Closed e1211203768566 ∧ code e1211203768566 = 5609250279670 := by decide
theorem cert_e1211203768566 : check e1211203768566 [[],[]] .chain = true := by decide
def e1211203768570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203768570 : Closed e1211203768570 ∧ code e1211203768570 = 5609250279674 := by decide
theorem cert_e1211203768570 : check e1211203768570 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203769046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203769046 : Closed e1211203769046 ∧ code e1211203769046 = 5609250280150 := by decide
theorem cert_e1211203769046 : check e1211203769046 [[],[]] .chain = true := by decide
def e1211203769050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203769050 : Closed e1211203769050 ∧ code e1211203769050 = 5609250280154 := by decide
theorem cert_e1211203769050 : check e1211203769050 [[],[]] .chain = true := by decide
def e1211203769066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203769066 : Closed e1211203769066 ∧ code e1211203769066 = 5609250280170 := by decide
theorem cert_e1211203769066 : check e1211203769066 [[],[]] .chain = true := by decide
def e1211203769094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203769094 : Closed e1211203769094 ∧ code e1211203769094 = 5609250280198 := by decide
theorem cert_e1211203769094 : check e1211203769094 [[],[]] .chain = true := by decide
def e1211203769118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203769118 : Closed e1211203769118 ∧ code e1211203769118 = 5609250280222 := by decide
theorem cert_e1211203769118 : check e1211203769118 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203769142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203769142 : Closed e1211203769142 ∧ code e1211203769142 = 5609250280246 := by decide
theorem cert_e1211203769142 : check e1211203769142 [[],[]] .chain = true := by decide
def e1211203769146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203769146 : Closed e1211203769146 ∧ code e1211203769146 = 5609250280250 := by decide
theorem cert_e1211203769146 : check e1211203769146 [[],[]] .chain = true := by decide
def e1211203769218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203769218 : Closed e1211203769218 ∧ code e1211203769218 = 5609250280322 := by decide
theorem cert_e1211203769218 : check e1211203769218 [[],[]] .chain = true := by decide
def e1211203769230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203769230 : Closed e1211203769230 ∧ code e1211203769230 = 5609250280334 := by decide
theorem cert_e1211203769230 : check e1211203769230 [[],[]] .chain = true := by decide
def e1211203769242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203769242 : Closed e1211203769242 ∧ code e1211203769242 = 5609250280346 := by decide
theorem cert_e1211203769242 : check e1211203769242 [[],[]] .chain = true := by decide
def e1211203769286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203769286 : Closed e1211203769286 ∧ code e1211203769286 = 5609250280390 := by decide
theorem cert_e1211203769286 : check e1211203769286 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203770486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211203770486 : Closed e1211203770486 ∧ code e1211203770486 = 5609250281590 := by decide
theorem cert_e1211203770486 : check e1211203770486 [[],[]] .chain = true := by decide
def e1211203770730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211203770730 : Closed e1211203770730 ∧ code e1211203770730 = 5609250281834 := by decide
theorem cert_e1211203770730 : check e1211203770730 [[],[]] .chain = true := by decide
def e1211203770754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203770754 : Closed e1211203770754 ∧ code e1211203770754 = 5609250281858 := by decide
theorem cert_e1211203770754 : check e1211203770754 [[],[]] .chain = true := by decide
def e1211203770766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203770766 : Closed e1211203770766 ∧ code e1211203770766 = 5609250281870 := by decide
theorem cert_e1211203770766 : check e1211203770766 [[],[]] .chain = true := by decide
def e1211203770778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203770778 : Closed e1211203770778 ∧ code e1211203770778 = 5609250281882 := by decide
theorem cert_e1211203770778 : check e1211203770778 [[],[]] .chain = true := by decide
def e1211203770822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203770822 : Closed e1211203770822 ∧ code e1211203770822 = 5609250281926 := by decide
theorem cert_e1211203770822 : check e1211203770822 [[],[]] .chain = true := by decide
def e1211203771446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211203771446 : Closed e1211203771446 ∧ code e1211203771446 = 5609250282550 := by decide
theorem cert_e1211203771446 : check e1211203771446 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203771450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211203771450 : Closed e1211203771450 ∧ code e1211203771450 = 5609250282554 := by decide
theorem cert_e1211203771450 : check e1211203771450 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203771590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203771590 : Closed e1211203771590 ∧ code e1211203771590 = 5609250282694 := by decide
theorem cert_e1211203771590 : check e1211203771590 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203772854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211203772854 : Closed e1211203772854 ∧ code e1211203772854 = 5609250283958 := by decide
private def t_e1211203772854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem cert_e1211203772854 : ¬ IsSelfInterpreter e1211203772854 :=
  wSource (t := t_e1211203772854) (replay_sound (ps := []) (t := e1211203772854) (by decide)) (by decide)
def e1211203772858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211203772858 : Closed e1211203772858 ∧ code e1211203772858 = 5609250283962 := by decide
private def t_e1211203772858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem cert_e1211203772858 : ¬ IsSelfInterpreter e1211203772858 :=
  wSource (t := t_e1211203772858) (replay_sound (ps := []) (t := e1211203772858) (by decide)) (by decide)
def e1211203772886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211203772886 : Closed e1211203772886 ∧ code e1211203772886 = 5609250283990 := by decide
private def t_e1211203772886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem cert_e1211203772886 : ¬ IsSelfInterpreter e1211203772886 :=
  wSource (t := t_e1211203772886) (replay_sound (ps := []) (t := e1211203772886) (by decide)) (by decide)
def e1211203772906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211203772906 : Closed e1211203772906 ∧ code e1211203772906 = 5609250284010 := by decide
private def t_e1211203772906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem cert_e1211203772906 : ¬ IsSelfInterpreter e1211203772906 :=
  wSource (t := t_e1211203772906) (replay_sound (ps := []) (t := e1211203772906) (by decide)) (by decide)
def e1211203773238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203773238 : Closed e1211203773238 ∧ code e1211203773238 = 5609250284342 := by decide
private def t_e1211203773238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem cert_e1211203773238 : ¬ IsSelfInterpreter e1211203773238 :=
  wSource (t := t_e1211203773238) (replay_sound (ps := []) (t := e1211203773238) (by decide)) (by decide)
def e1211203773242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203773242 : Closed e1211203773242 ∧ code e1211203773242 = 5609250284346 := by decide
private def t_e1211203773242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem cert_e1211203773242 : ¬ IsSelfInterpreter e1211203773242 :=
  wSource (t := t_e1211203773242) (replay_sound (ps := []) (t := e1211203773242) (by decide)) (by decide)
def e1211203773338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203773338 : Closed e1211203773338 ∧ code e1211203773338 = 5609250284442 := by decide
private def t_e1211203773338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem cert_e1211203773338 : ¬ IsSelfInterpreter e1211203773338 :=
  wSource (t := t_e1211203773338) (replay_sound (ps := []) (t := e1211203773338) (by decide)) (by decide)
def e1211203774006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203774006 : Closed e1211203774006 ∧ code e1211203774006 = 5609250285110 := by decide
private def t_e1211203774006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem cert_e1211203774006 : ¬ IsSelfInterpreter e1211203774006 :=
  wSource (t := t_e1211203774006) (replay_sound (ps := []) (t := e1211203774006) (by decide)) (by decide)
def e1211203774010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203774010 : Closed e1211203774010 ∧ code e1211203774010 = 5609250285114 := by decide
private def t_e1211203774010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem cert_e1211203774010 : ¬ IsSelfInterpreter e1211203774010 :=
  wSource (t := t_e1211203774010) (replay_sound (ps := []) (t := e1211203774010) (by decide)) (by decide)
def e1211203774094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203774094 : Closed e1211203774094 ∧ code e1211203774094 = 5609250285198 := by decide
private def t_e1211203774094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem cert_e1211203774094 : ¬ IsSelfInterpreter e1211203774094 :=
  wSource (t := t_e1211203774094) (replay_sound (ps := []) (t := e1211203774094) (by decide)) (by decide)
def e1211203774150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203774150 : Closed e1211203774150 ∧ code e1211203774150 = 5609250285254 := by decide
private def t_e1211203774150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem cert_e1211203774150 : ¬ IsSelfInterpreter e1211203774150 :=
  wSource (t := t_e1211203774150) (replay_sound (ps := []) (t := e1211203774150) (by decide)) (by decide)
def e1211203774234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203774234 : Closed e1211203774234 ∧ code e1211203774234 = 5609250285338 := by decide
private def t_e1211203774234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem cert_e1211203774234 : ¬ IsSelfInterpreter e1211203774234 :=
  wSource (t := t_e1211203774234) (replay_sound (ps := []) (t := e1211203774234) (by decide)) (by decide)
def e1211203774278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203774278 : Closed e1211203774278 ∧ code e1211203774278 = 5609250285382 := by decide
private def t_e1211203774278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem cert_e1211203774278 : ¬ IsSelfInterpreter e1211203774278 :=
  wSource (t := t_e1211203774278) (replay_sound (ps := []) (t := e1211203774278) (by decide)) (by decide)
def e1211203774574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211203774574 : Closed e1211203774574 ∧ code e1211203774574 = 5609250285678 := by decide
private def t_e1211203774574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem cert_e1211203774574 : ¬ IsSelfInterpreter e1211203774574 :=
  wSource (t := t_e1211203774574) (replay_sound (ps := []) (t := e1211203774574) (by decide)) (by decide)
def e1211203774586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211203774586 : Closed e1211203774586 ∧ code e1211203774586 = 5609250285690 := by decide
private def t_e1211203774586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem cert_e1211203774586 : ¬ IsSelfInterpreter e1211203774586 :=
  wSource (t := t_e1211203774586) (replay_sound (ps := []) (t := e1211203774586) (by decide)) (by decide)
def e1211203774862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203774862 : Closed e1211203774862 ∧ code e1211203774862 = 5609250285966 := by decide
private def t_e1211203774862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1211203774862 : ¬ IsSelfInterpreter e1211203774862 :=
  wSource (t := t_e1211203774862) (replay_sound (ps := []) (t := e1211203774862) (by decide)) (by decide)
def e1211203774918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203774918 : Closed e1211203774918 ∧ code e1211203774918 = 5609250286022 := by decide
private def t_e1211203774918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1211203774918 : ¬ IsSelfInterpreter e1211203774918 :=
  wSource (t := t_e1211203774918) (replay_sound (ps := []) (t := e1211203774918) (by decide)) (by decide)
def e1211203775542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211203775542 : Closed e1211203775542 ∧ code e1211203775542 = 5609250286646 := by decide
private def t_e1211203775542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem cert_e1211203775542 : ¬ IsSelfInterpreter e1211203775542 :=
  wSource (t := t_e1211203775542) (replay_sound (ps := []) (t := e1211203775542) (by decide)) (by decide)
def e1211203775546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211203775546 : Closed e1211203775546 ∧ code e1211203775546 = 5609250286650 := by decide
private def t_e1211203775546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem cert_e1211203775546 : ¬ IsSelfInterpreter e1211203775546 :=
  wSource (t := t_e1211203775546) (replay_sound (ps := []) (t := e1211203775546) (by decide)) (by decide)
def e1211203775686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203775686 : Closed e1211203775686 ∧ code e1211203775686 = 5609250286790 := by decide
private def t_e1211203775686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem cert_e1211203775686 : ¬ IsSelfInterpreter e1211203775686 :=
  wSource (t := t_e1211203775686) (replay_sound (ps := []) (t := e1211203775686) (by decide)) (by decide)
def e1211203861742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203861742 : Closed e1211203861742 ∧ code e1211203861742 = 5609250372846 := by decide
theorem cert_e1211203861742 : check e1211203861742 [[],[]] .chain = true := by decide
def e1211203861750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203861750 : Closed e1211203861750 ∧ code e1211203861750 = 5609250372854 := by decide
theorem cert_e1211203861750 : check e1211203861750 [[],[]] .chain = true := by decide
def e1211203862126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203862126 : Closed e1211203862126 ∧ code e1211203862126 = 5609250373230 := by decide
theorem cert_e1211203862126 : check e1211203862126 [[],[]] .chain = true := by decide
def e1211203862138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203862138 : Closed e1211203862138 ∧ code e1211203862138 = 5609250373242 := by decide
theorem cert_e1211203862138 : check e1211203862138 [[],[]] .chain = true := by decide
def e1211203862326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203862326 : Closed e1211203862326 ∧ code e1211203862326 = 5609250373430 := by decide
theorem cert_e1211203862326 : check e1211203862326 [[],[]] .chain = true := by decide
def e1211203862330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203862330 : Closed e1211203862330 ∧ code e1211203862330 = 5609250373434 := by decide
theorem cert_e1211203862330 : check e1211203862330 [[],[]] .chain = true := by decide
def e1211203869558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1))))))
theorem wire_e1211203869558 : Closed e1211203869558 ∧ code e1211203869558 = 5609250380662 := by decide
theorem cert_e1211203869558 : check e1211203869558 [[],[]] .smaller = true := by decide
def e1211203869562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 0))))))
theorem wire_e1211203869562 : Closed e1211203869562 ∧ code e1211203869562 = 5609250380666 := by decide
theorem cert_e1211203869562 : check e1211203869562 [[],[]] .smaller = true := by decide
def e1211203869622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1))))))
theorem wire_e1211203869622 : Closed e1211203869622 ∧ code e1211203869622 = 5609250380726 := by decide
theorem cert_e1211203869622 : check e1211203869622 [[],[]] .smaller = true := by decide
def e1211203869658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 0))))))
theorem wire_e1211203869658 : Closed e1211203869658 ∧ code e1211203869658 = 5609250380762 := by decide
theorem cert_e1211203869658 : check e1211203869658 [[],[]] .smaller = true := by decide
def e1211203870070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1))))))
theorem wire_e1211203870070 : Closed e1211203870070 ∧ code e1211203870070 = 5609250381174 := by decide
theorem cert_e1211203870070 : check e1211203870070 [[],[]] .smaller = true := by decide
def e1211203870074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 0))))))
theorem wire_e1211203870074 : Closed e1211203870074 ∧ code e1211203870074 = 5609250381178 := by decide
theorem cert_e1211203870074 : check e1211203870074 [[],[]] .smaller = true := by decide
def e1211203870166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1))))))
theorem wire_e1211203870166 : Closed e1211203870166 ∧ code e1211203870166 = 5609250381270 := by decide
theorem cert_e1211203870166 : check e1211203870166 [[],[]] .smaller = true := by decide
def e1211203870186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 0))))))
theorem wire_e1211203870186 : Closed e1211203870186 ∧ code e1211203870186 = 5609250381290 := by decide
theorem cert_e1211203870186 : check e1211203870186 [[],[]] .smaller = true := by decide
def e1211203870390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1))))))
theorem wire_e1211203870390 : Closed e1211203870390 ∧ code e1211203870390 = 5609250381494 := by decide
theorem cert_e1211203870390 : check e1211203870390 [[],[]] .smaller = true := by decide
def e1211203870422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1))))))
theorem wire_e1211203870422 : Closed e1211203870422 ∧ code e1211203870422 = 5609250381526 := by decide
theorem cert_e1211203870422 : check e1211203870422 [[],[]] .smaller = true := by decide
def e1211203870554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e1211203870554 : Closed e1211203870554 ∧ code e1211203870554 = 5609250381658 := by decide
theorem cert_e1211203870554 : check e1211203870554 [[],[]] .smaller = true := by decide
def e1211203870570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e1211203870570 : Closed e1211203870570 ∧ code e1211203870570 = 5609250381674 := by decide
theorem cert_e1211203870570 : check e1211203870570 [[],[]] .smaller = true := by decide
def e1211203872630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1))))))
theorem wire_e1211203872630 : Closed e1211203872630 ∧ code e1211203872630 = 5609250383734 := by decide
theorem cert_e1211203872630 : check e1211203872630 [[],[]] .smaller = true := by decide
def e1211203872634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 0))))))
theorem wire_e1211203872634 : Closed e1211203872634 ∧ code e1211203872634 = 5609250383738 := by decide
theorem cert_e1211203872634 : check e1211203872634 [[],[]] .smaller = true := by decide
def e1211203872694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1))))))
theorem wire_e1211203872694 : Closed e1211203872694 ∧ code e1211203872694 = 5609250383798 := by decide
theorem cert_e1211203872694 : check e1211203872694 [[],[]] .smaller = true := by decide
def e1211203872730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 0))))))
theorem wire_e1211203872730 : Closed e1211203872730 ∧ code e1211203872730 = 5609250383834 := by decide
theorem cert_e1211203872730 : check e1211203872730 [[],[]] .smaller = true := by decide
def e1211203875702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1))))))
theorem wire_e1211203875702 : Closed e1211203875702 ∧ code e1211203875702 = 5609250386806 := by decide
theorem cert_e1211203875702 : check e1211203875702 [[],[]] .smaller = true := by decide
def e1211203875706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 0))))))
theorem wire_e1211203875706 : Closed e1211203875706 ∧ code e1211203875706 = 5609250386810 := by decide
theorem cert_e1211203875706 : check e1211203875706 [[],[]] .smaller = true := by decide
def e1211203875798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1))))))
theorem wire_e1211203875798 : Closed e1211203875798 ∧ code e1211203875798 = 5609250386902 := by decide
theorem cert_e1211203875798 : check e1211203875798 [[],[]] .smaller = true := by decide
def e1211203875818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 0))))))
theorem wire_e1211203875818 : Closed e1211203875818 ∧ code e1211203875818 = 5609250386922 := by decide
theorem cert_e1211203875818 : check e1211203875818 [[],[]] .smaller = true := by decide
def e1211203877302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1))))))
theorem wire_e1211203877302 : Closed e1211203877302 ∧ code e1211203877302 = 5609250388406 := by decide
theorem cert_e1211203877302 : check e1211203877302 [[],[]] .smaller = true := by decide
def e1211203877334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1))))))
theorem wire_e1211203877334 : Closed e1211203877334 ∧ code e1211203877334 = 5609250388438 := by decide
theorem cert_e1211203877334 : check e1211203877334 [[],[]] .smaller = true := by decide
def e1211203878106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e1211203878106 : Closed e1211203878106 ∧ code e1211203878106 = 5609250389210 := by decide
theorem cert_e1211203878106 : check e1211203878106 [[],[]] .smaller = true := by decide
def e1211203878122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e1211203878122 : Closed e1211203878122 ∧ code e1211203878122 = 5609250389226 := by decide
theorem cert_e1211203878122 : check e1211203878122 [[],[]] .smaller = true := by decide
def e1211203878382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 3))))) (.var 2))))))
theorem wire_e1211203878382 : Closed e1211203878382 ∧ code e1211203878382 = 5609250389486 := by decide
theorem cert_e1211203878382 : check e1211203878382 [[],[]] .chain = true := by decide
def e1211203878390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))) (.var 1))))))
theorem wire_e1211203878390 : Closed e1211203878390 ∧ code e1211203878390 = 5609250389494 := by decide
theorem cert_e1211203878390 : check e1211203878390 [[],[]] .chain = true := by decide
def e1211203878646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))) (.var 1))))))
theorem wire_e1211203878646 : Closed e1211203878646 ∧ code e1211203878646 = 5609250389750 := by decide
theorem cert_e1211203878646 : check e1211203878646 [[],[]] .chain = true := by decide
def e1211203884910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1211203884910 : Closed e1211203884910 ∧ code e1211203884910 = 5609250396014 := by decide
theorem cert_e1211203884910 : check e1211203884910 [[],[]] .chain = true := by decide
def e1211203884918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1211203884918 : Closed e1211203884918 ∧ code e1211203884918 = 5609250396022 := by decide
theorem cert_e1211203884918 : check e1211203884918 [[],[]] .chain = true := by decide
def e1211203884982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1211203884982 : Closed e1211203884982 ∧ code e1211203884982 = 5609250396086 := by decide
theorem cert_e1211203884982 : check e1211203884982 [[],[]] .chain = true := by decide
def e1211203886318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203886318 : Closed e1211203886318 ∧ code e1211203886318 = 5609250397422 := by decide
theorem cert_e1211203886318 : check e1211203886318 [[],[]] .chain = true := by decide
def e1211203886326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203886326 : Closed e1211203886326 ∧ code e1211203886326 = 5609250397430 := by decide
theorem cert_e1211203886326 : check e1211203886326 [[],[]] .chain = true := by decide
def e1211203886710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1211203886710 : Closed e1211203886710 ∧ code e1211203886710 = 5609250397814 := by decide
theorem cert_e1211203886710 : check e1211203886710 [[],[]] .chain = true := by decide
def e1211203898222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211203898222 : Closed e1211203898222 ∧ code e1211203898222 = 5609250409326 := by decide
theorem cert_e1211203898222 : check e1211203898222 [[],[]] .chain = true := by decide
def e1211203898230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211203898230 : Closed e1211203898230 ∧ code e1211203898230 = 5609250409334 := by decide
theorem cert_e1211203898230 : check e1211203898230 [[],[]] .chain = true := by decide
def e1211203898286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211203898286 : Closed e1211203898286 ∧ code e1211203898286 = 5609250409390 := by decide
theorem cert_e1211203898286 : check e1211203898286 [[],[]] .chain = true := by decide
def e1211203898298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211203898298 : Closed e1211203898298 ∧ code e1211203898298 = 5609250409402 := by decide
theorem cert_e1211203898298 : check e1211203898298 [[],[]] .chain = true := by decide
def e1211203898326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211203898326 : Closed e1211203898326 ∧ code e1211203898326 = 5609250409430 := by decide
theorem cert_e1211203898326 : check e1211203898326 [[],[]] .chain = true := by decide
def e1211203898330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211203898330 : Closed e1211203898330 ∧ code e1211203898330 = 5609250409434 := by decide
theorem cert_e1211203898330 : check e1211203898330 [[],[]] .chain = true := by decide
def e1211203898606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203898606 : Closed e1211203898606 ∧ code e1211203898606 = 5609250409710 := by decide
theorem cert_e1211203898606 : check e1211203898606 [[],[]] .chain = true := by decide
def e1211203898614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203898614 : Closed e1211203898614 ∧ code e1211203898614 = 5609250409718 := by decide
theorem cert_e1211203898614 : check e1211203898614 [[],[]] .chain = true := by decide
def e1211203898990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203898990 : Closed e1211203898990 ∧ code e1211203898990 = 5609250410094 := by decide
theorem cert_e1211203898990 : check e1211203898990 [[],[]] .chain = true := by decide
def e1211203899002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203899002 : Closed e1211203899002 ∧ code e1211203899002 = 5609250410106 := by decide
theorem cert_e1211203899002 : check e1211203899002 [[],[]] .chain = true := by decide
def e1211203899190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203899190 : Closed e1211203899190 ∧ code e1211203899190 = 5609250410294 := by decide
theorem cert_e1211203899190 : check e1211203899190 [[],[]] .chain = true := by decide
def e1211203899194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203899194 : Closed e1211203899194 ∧ code e1211203899194 = 5609250410298 := by decide
theorem cert_e1211203899194 : check e1211203899194 [[],[]] .chain = true := by decide
def e1211203905310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203905310 : Closed e1211203905310 ∧ code e1211203905310 = 5609250416414 := by decide
theorem cert_e1211203905310 : check e1211203905310 [[],[]] .chain = true := by decide
def e1211203905422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203905422 : Closed e1211203905422 ∧ code e1211203905422 = 5609250416526 := by decide
theorem cert_e1211203905422 : check e1211203905422 [[],[]] .chain = true := by decide
def e1211203908382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203908382 : Closed e1211203908382 ∧ code e1211203908382 = 5609250419486 := by decide
theorem cert_e1211203908382 : check e1211203908382 [[],[]] .chain = true := by decide
def e1211203908550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203908550 : Closed e1211203908550 ∧ code e1211203908550 = 5609250419654 := by decide
theorem cert_e1211203908550 : check e1211203908550 [[],[]] .chain = true := by decide
def e1211203910030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203910030 : Closed e1211203910030 ∧ code e1211203910030 = 5609250421134 := by decide
theorem cert_e1211203910030 : check e1211203910030 [[],[]] .chain = true := by decide
def e1211203910086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203910086 : Closed e1211203910086 ∧ code e1211203910086 = 5609250421190 := by decide
theorem cert_e1211203910086 : check e1211203910086 [[],[]] .chain = true := by decide
def e1211203937210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 0))))))
theorem wire_e1211203937210 : Closed e1211203937210 ∧ code e1211203937210 = 5609250448314 := by decide
theorem cert_e1211203937210 : check e1211203937210 [[],[]] .smaller = true := by decide
def e1211203937242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 0))))))
theorem wire_e1211203937242 : Closed e1211203937242 ∧ code e1211203937242 = 5609250448346 := by decide
theorem cert_e1211203937242 : check e1211203937242 [[],[]] .smaller = true := by decide
def e1211203939450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211203939450 : Closed e1211203939450 ∧ code e1211203939450 = 5609250450554 := by decide
theorem cert_e1211203939450 : check e1211203939450 [[],[]] .smaller = true := by decide
def e1211203939782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211203939782 : Closed e1211203939782 ∧ code e1211203939782 = 5609250450886 := by decide
theorem cert_e1211203939782 : check e1211203939782 [[],[]] .smaller = true := by decide
def e1211203939810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211203939810 : Closed e1211203939810 ∧ code e1211203939810 = 5609250450914 := by decide
theorem cert_e1211203939810 : check e1211203939810 [[],[]] .chain = true := by decide
def e1211203939822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 2))))))
theorem wire_e1211203939822 : Closed e1211203939822 ∧ code e1211203939822 = 5609250450926 := by decide
theorem cert_e1211203939822 : check e1211203939822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203939898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211203939898 : Closed e1211203939898 ∧ code e1211203939898 = 5609250451002 := by decide
theorem cert_e1211203939898 : check e1211203939898 [[],[]] .smaller = true := by decide
def e1211203940038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211203940038 : Closed e1211203940038 ∧ code e1211203940038 = 5609250451142 := by decide
theorem cert_e1211203940038 : check e1211203940038 [[],[]] .smaller = true := by decide
def e1211203940078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 2)))) (.var 2))))))
theorem wire_e1211203940078 : Closed e1211203940078 ∧ code e1211203940078 = 5609250451182 := by decide
theorem cert_e1211203940078 : check e1211203940078 [[],[]] .chain = true := by decide
def e1211203940086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))) (.var 1))))))
theorem wire_e1211203940086 : Closed e1211203940086 ∧ code e1211203940086 = 5609250451190 := by decide
theorem cert_e1211203940086 : check e1211203940086 [[],[]] .chain = true := by decide
def e1211203940194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203940194 : Closed e1211203940194 ∧ code e1211203940194 = 5609250451298 := by decide
theorem cert_e1211203940194 : check e1211203940194 [[],[]] .chain = true := by decide
def e1211203940206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 2))))))
theorem wire_e1211203940206 : Closed e1211203940206 ∧ code e1211203940206 = 5609250451310 := by decide
theorem cert_e1211203940206 : check e1211203940206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203940214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))) (.var 1))))))
theorem wire_e1211203940214 : Closed e1211203940214 ∧ code e1211203940214 = 5609250451318 := by decide
theorem cert_e1211203940214 : check e1211203940214 [[],[]] .chain = true := by decide
def e1211203940794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 0))))))
theorem wire_e1211203940794 : Closed e1211203940794 ∧ code e1211203940794 = 5609250451898 := by decide
theorem cert_e1211203940794 : check e1211203940794 [[],[]] .smaller = true := by decide
def e1211203940842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 0))))))
theorem wire_e1211203940842 : Closed e1211203940842 ∧ code e1211203940842 = 5609250451946 := by decide
theorem cert_e1211203940842 : check e1211203940842 [[],[]] .smaller = true := by decide
def e1211203941498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211203941498 : Closed e1211203941498 ∧ code e1211203941498 = 5609250452602 := by decide
theorem cert_e1211203941498 : check e1211203941498 [[],[]] .smaller = true := by decide
def e1211203941830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211203941830 : Closed e1211203941830 ∧ code e1211203941830 = 5609250452934 := by decide
theorem cert_e1211203941830 : check e1211203941830 [[],[]] .smaller = true := by decide
def e1211203941858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211203941858 : Closed e1211203941858 ∧ code e1211203941858 = 5609250452962 := by decide
theorem cert_e1211203941858 : check e1211203941858 [[],[]] .chain = true := by decide
def e1211203941870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 2))))))
theorem wire_e1211203941870 : Closed e1211203941870 ∧ code e1211203941870 = 5609250452974 := by decide
theorem cert_e1211203941870 : check e1211203941870 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203942126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e1211203942126 : Closed e1211203942126 ∧ code e1211203942126 = 5609250453230 := by decide
theorem cert_e1211203942126 : check e1211203942126 [[],[]] .chain = true := by decide
def e1211203942134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))) (.var 1))))))
theorem wire_e1211203942134 : Closed e1211203942134 ∧ code e1211203942134 = 5609250453238 := by decide
theorem cert_e1211203942134 : check e1211203942134 [[],[]] .chain = true := by decide
def e1211203942170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203942170 : Closed e1211203942170 ∧ code e1211203942170 = 5609250453274 := by decide
theorem cert_e1211203942170 : check e1211203942170 [[],[]] .smaller = true := by decide
def e1211203942214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203942214 : Closed e1211203942214 ∧ code e1211203942214 = 5609250453318 := by decide
theorem cert_e1211203942214 : check e1211203942214 [[],[]] .smaller = true := by decide
def e1211203942254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e1211203942254 : Closed e1211203942254 ∧ code e1211203942254 = 5609250453358 := by decide
theorem cert_e1211203942254 : check e1211203942254 [[],[]] .chain = true := by decide
def e1211203942266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))) (.var 0))))))
theorem wire_e1211203942266 : Closed e1211203942266 ∧ code e1211203942266 = 5609250453370 := by decide
theorem cert_e1211203942266 : check e1211203942266 [[],[]] .chain = true := by decide
def e1211203942306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1211203942306 : Closed e1211203942306 ∧ code e1211203942306 = 5609250453410 := by decide
theorem cert_e1211203942306 : check e1211203942306 [[],[]] .chain = true := by decide
def e1211203942318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 2))))))
theorem wire_e1211203942318 : Closed e1211203942318 ∧ code e1211203942318 = 5609250453422 := by decide
theorem cert_e1211203942318 : check e1211203942318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203942326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))) (.var 1))))))
theorem wire_e1211203942326 : Closed e1211203942326 ∧ code e1211203942326 = 5609250453430 := by decide
theorem cert_e1211203942326 : check e1211203942326 [[],[]] .chain = true := by decide
def e1211203942330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))) (.var 0))))))
theorem wire_e1211203942330 : Closed e1211203942330 ∧ code e1211203942330 = 5609250453434 := by decide
theorem cert_e1211203942330 : check e1211203942330 [[],[]] .chain = true := by decide
def e1211203942618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 0))))))
theorem wire_e1211203942618 : Closed e1211203942618 ∧ code e1211203942618 = 5609250453722 := by decide
theorem cert_e1211203942618 : check e1211203942618 [[],[]] .smaller = true := by decide
def e1211203942634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e1211203942634 : Closed e1211203942634 ∧ code e1211203942634 = 5609250453738 := by decide
theorem cert_e1211203942634 : check e1211203942634 [[],[]] .smaller = true := by decide
def e1211203942970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211203942970 : Closed e1211203942970 ∧ code e1211203942970 = 5609250454074 := by decide
theorem cert_e1211203942970 : check e1211203942970 [[],[]] .smaller = true := by decide
def e1211203943110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211203943110 : Closed e1211203943110 ∧ code e1211203943110 = 5609250454214 := by decide
theorem cert_e1211203943110 : check e1211203943110 [[],[]] .smaller = true := by decide
def e1211203943150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e1211203943150 : Closed e1211203943150 ∧ code e1211203943150 = 5609250454254 := by decide
theorem cert_e1211203943150 : check e1211203943150 [[],[]] .chain = true := by decide
def e1211203943158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e1211203943158 : Closed e1211203943158 ∧ code e1211203943158 = 5609250454262 := by decide
theorem cert_e1211203943158 : check e1211203943158 [[],[]] .chain = true := by decide
def e1211203943194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203943194 : Closed e1211203943194 ∧ code e1211203943194 = 5609250454298 := by decide
theorem cert_e1211203943194 : check e1211203943194 [[],[]] .smaller = true := by decide
def e1211203943238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203943238 : Closed e1211203943238 ∧ code e1211203943238 = 5609250454342 := by decide
theorem cert_e1211203943238 : check e1211203943238 [[],[]] .smaller = true := by decide
def e1211203943278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e1211203943278 : Closed e1211203943278 ∧ code e1211203943278 = 5609250454382 := by decide
theorem cert_e1211203943278 : check e1211203943278 [[],[]] .chain = true := by decide
def e1211203943290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e1211203943290 : Closed e1211203943290 ∧ code e1211203943290 = 5609250454394 := by decide
theorem cert_e1211203943290 : check e1211203943290 [[],[]] .chain = true := by decide
def e1211203943342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e1211203943342 : Closed e1211203943342 ∧ code e1211203943342 = 5609250454446 := by decide
theorem cert_e1211203943342 : check e1211203943342 [[],[]] .chain = true := by decide
def e1211203943382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e1211203943382 : Closed e1211203943382 ∧ code e1211203943382 = 5609250454486 := by decide
theorem cert_e1211203943382 : check e1211203943382 [[],[]] .chain = true := by decide
def e1211203943386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e1211203943386 : Closed e1211203943386 ∧ code e1211203943386 = 5609250454490 := by decide
theorem cert_e1211203943386 : check e1211203943386 [[],[]] .chain = true := by decide
def e1211203943778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203943778 : Closed e1211203943778 ∧ code e1211203943778 = 5609250454882 := by decide
theorem cert_e1211203943778 : check e1211203943778 [[],[]] .chain = true := by decide
def e1211203943790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e1211203943790 : Closed e1211203943790 ∧ code e1211203943790 = 5609250454894 := by decide
theorem cert_e1211203943790 : check e1211203943790 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203943798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211203943798 : Closed e1211203943798 ∧ code e1211203943798 = 5609250454902 := by decide
theorem cert_e1211203943798 : check e1211203943798 [[],[]] .chain = true := by decide
def e1211203943842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1211203943842 : Closed e1211203943842 ∧ code e1211203943842 = 5609250454946 := by decide
theorem cert_e1211203943842 : check e1211203943842 [[],[]] .chain = true := by decide
def e1211203943854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e1211203943854 : Closed e1211203943854 ∧ code e1211203943854 = 5609250454958 := by decide
theorem cert_e1211203943854 : check e1211203943854 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203943862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))) (.var 1))))))
theorem wire_e1211203943862 : Closed e1211203943862 ∧ code e1211203943862 = 5609250454966 := by decide
theorem cert_e1211203943862 : check e1211203943862 [[],[]] .chain = true := by decide
def e1211203943866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211203943866 : Closed e1211203943866 ∧ code e1211203943866 = 5609250454970 := by decide
theorem cert_e1211203943866 : check e1211203943866 [[],[]] .chain = true := by decide
end Blc.Floor42
