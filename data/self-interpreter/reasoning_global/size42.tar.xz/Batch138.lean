import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182242550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1))))))))
theorem wire_e1211182242550 : Closed e1211182242550 ∧ code e1211182242550 = 5609228753654 := by decide
theorem cert_e1211182242550 : check e1211182242550 [[],[]] .smaller = true := by decide
def e1211182242654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3))))))))
theorem wire_e1211182242654 : Closed e1211182242654 ∧ code e1211182242654 = 5609228753758 := by decide
theorem cert_e1211182242654 : check e1211182242654 [[],[]] .smaller = true := by decide
def e1211182242670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))))
theorem wire_e1211182242670 : Closed e1211182242670 ∧ code e1211182242670 = 5609228753774 := by decide
theorem cert_e1211182242670 : check e1211182242670 [[],[]] .smaller = true := by decide
def e1211182242678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))))
theorem wire_e1211182242678 : Closed e1211182242678 ∧ code e1211182242678 = 5609228753782 := by decide
theorem cert_e1211182242678 : check e1211182242678 [[],[]] .smaller = true := by decide
def e1211182242682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0))))))))
theorem wire_e1211182242682 : Closed e1211182242682 ∧ code e1211182242682 = 5609228753786 := by decide
theorem cert_e1211182242682 : check e1211182242682 [[],[]] .smaller = true := by decide
def e1211182242742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))))
theorem wire_e1211182242742 : Closed e1211182242742 ∧ code e1211182242742 = 5609228753846 := by decide
theorem cert_e1211182242742 : check e1211182242742 [[],[]] .smaller = true := by decide
def e1211182242774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1))))))))
theorem wire_e1211182242774 : Closed e1211182242774 ∧ code e1211182242774 = 5609228753878 := by decide
theorem cert_e1211182242774 : check e1211182242774 [[],[]] .smaller = true := by decide
def e1211182242778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0))))))))
theorem wire_e1211182242778 : Closed e1211182242778 ∧ code e1211182242778 = 5609228753882 := by decide
theorem cert_e1211182242778 : check e1211182242778 [[],[]] .smaller = true := by decide
def e1211182243166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3))))))))
theorem wire_e1211182243166 : Closed e1211182243166 ∧ code e1211182243166 = 5609228754270 := by decide
theorem cert_e1211182243166 : check e1211182243166 [[],[]] .smaller = true := by decide
def e1211182243182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e1211182243182 : Closed e1211182243182 ∧ code e1211182243182 = 5609228754286 := by decide
theorem cert_e1211182243182 : check e1211182243182 [[],[]] .smaller = true := by decide
def e1211182243190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e1211182243190 : Closed e1211182243190 ∧ code e1211182243190 = 5609228754294 := by decide
theorem cert_e1211182243190 : check e1211182243190 [[],[]] .smaller = true := by decide
def e1211182243194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0))))))))
theorem wire_e1211182243194 : Closed e1211182243194 ∧ code e1211182243194 = 5609228754298 := by decide
theorem cert_e1211182243194 : check e1211182243194 [[],[]] .smaller = true := by decide
def e1211182243246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e1211182243246 : Closed e1211182243246 ∧ code e1211182243246 = 5609228754350 := by decide
theorem cert_e1211182243246 : check e1211182243246 [[],[]] .smaller = true := by decide
def e1211182243258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e1211182243258 : Closed e1211182243258 ∧ code e1211182243258 = 5609228754362 := by decide
theorem cert_e1211182243258 : check e1211182243258 [[],[]] .smaller = true := by decide
def e1211182243286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e1211182243286 : Closed e1211182243286 ∧ code e1211182243286 = 5609228754390 := by decide
theorem cert_e1211182243286 : check e1211182243286 [[],[]] .smaller = true := by decide
def e1211182243290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e1211182243290 : Closed e1211182243290 ∧ code e1211182243290 = 5609228754394 := by decide
theorem cert_e1211182243290 : check e1211182243290 [[],[]] .smaller = true := by decide
def e1211182243306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0))))))))
theorem wire_e1211182243306 : Closed e1211182243306 ∧ code e1211182243306 = 5609228754410 := by decide
theorem cert_e1211182243306 : check e1211182243306 [[],[]] .smaller = true := by decide
def e1211182243510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e1211182243510 : Closed e1211182243510 ∧ code e1211182243510 = 5609228754614 := by decide
theorem cert_e1211182243510 : check e1211182243510 [[],[]] .smaller = true := by decide
def e1211182243542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e1211182243542 : Closed e1211182243542 ∧ code e1211182243542 = 5609228754646 := by decide
theorem cert_e1211182243542 : check e1211182243542 [[],[]] .smaller = true := by decide
def e1211182243546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e1211182243546 : Closed e1211182243546 ∧ code e1211182243546 = 5609228754650 := by decide
theorem cert_e1211182243546 : check e1211182243546 [[],[]] .smaller = true := by decide
def e1211182243670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e1211182243670 : Closed e1211182243670 ∧ code e1211182243670 = 5609228754774 := by decide
theorem cert_e1211182243670 : check e1211182243670 [[],[]] .smaller = true := by decide
def e1211182243674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e1211182243674 : Closed e1211182243674 ∧ code e1211182243674 = 5609228754778 := by decide
theorem cert_e1211182243674 : check e1211182243674 [[],[]] .smaller = true := by decide
def e1211182243690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e1211182243690 : Closed e1211182243690 ∧ code e1211182243690 = 5609228754794 := by decide
theorem cert_e1211182243690 : check e1211182243690 [[],[]] .smaller = true := by decide
def e1211182244798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 4))))))))
theorem wire_e1211182244798 : Closed e1211182244798 ∧ code e1211182244798 = 5609228755902 := by decide
theorem cert_e1211182244798 : check e1211182244798 [[],[]] .three = true := by decide
def e1211182244830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 3))))))))
theorem wire_e1211182244830 : Closed e1211182244830 ∧ code e1211182244830 = 5609228755934 := by decide
theorem cert_e1211182244830 : check e1211182244830 [[],[]] .smaller = true := by decide
def e1211182244846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 2))))))))
theorem wire_e1211182244846 : Closed e1211182244846 ∧ code e1211182244846 = 5609228755950 := by decide
theorem cert_e1211182244846 : check e1211182244846 [[],[]] .smaller = true := by decide
def e1211182244854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 5)))) (.var 1))))))))
theorem wire_e1211182244854 : Closed e1211182244854 ∧ code e1211182244854 = 5609228755958 := by decide
theorem cert_e1211182244854 : check e1211182244854 [[],[]] .three = true := by decide
def e1211182245598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3))))))))
theorem wire_e1211182245598 : Closed e1211182245598 ∧ code e1211182245598 = 5609228756702 := by decide
theorem cert_e1211182245598 : check e1211182245598 [[],[]] .smaller = true := by decide
def e1211182245622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e1211182245622 : Closed e1211182245622 ∧ code e1211182245622 = 5609228756726 := by decide
theorem cert_e1211182245622 : check e1211182245622 [[],[]] .smaller = true := by decide
def e1211182245726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3))))))))
theorem wire_e1211182245726 : Closed e1211182245726 ∧ code e1211182245726 = 5609228756830 := by decide
theorem cert_e1211182245726 : check e1211182245726 [[],[]] .smaller = true := by decide
def e1211182245742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e1211182245742 : Closed e1211182245742 ∧ code e1211182245742 = 5609228756846 := by decide
theorem cert_e1211182245742 : check e1211182245742 [[],[]] .smaller = true := by decide
def e1211182245750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))))
theorem wire_e1211182245750 : Closed e1211182245750 ∧ code e1211182245750 = 5609228756854 := by decide
theorem cert_e1211182245750 : check e1211182245750 [[],[]] .smaller = true := by decide
def e1211182245754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e1211182245754 : Closed e1211182245754 ∧ code e1211182245754 = 5609228756858 := by decide
theorem cert_e1211182245754 : check e1211182245754 [[],[]] .smaller = true := by decide
def e1211182245814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))))
theorem wire_e1211182245814 : Closed e1211182245814 ∧ code e1211182245814 = 5609228756918 := by decide
theorem cert_e1211182245814 : check e1211182245814 [[],[]] .smaller = true := by decide
def e1211182245846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e1211182245846 : Closed e1211182245846 ∧ code e1211182245846 = 5609228756950 := by decide
theorem cert_e1211182245846 : check e1211182245846 [[],[]] .smaller = true := by decide
def e1211182245850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e1211182245850 : Closed e1211182245850 ∧ code e1211182245850 = 5609228756954 := by decide
theorem cert_e1211182245850 : check e1211182245850 [[],[]] .smaller = true := by decide
def e1211182246366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211182246366 : Closed e1211182246366 ∧ code e1211182246366 = 5609228757470 := by decide
theorem cert_e1211182246366 : check e1211182246366 [[],[]] .smaller = true := by decide
def e1211182246390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211182246390 : Closed e1211182246390 ∧ code e1211182246390 = 5609228757494 := by decide
theorem cert_e1211182246390 : check e1211182246390 [[],[]] .smaller = true := by decide
def e1211182247038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 5)))))))))
theorem wire_e1211182247038 : Closed e1211182247038 ∧ code e1211182247038 = 5609228758142 := by decide
theorem cert_e1211182247038 : check e1211182247038 [[],[]] .three = true := by decide
def e1211182247134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182247134 : Closed e1211182247134 ∧ code e1211182247134 = 5609228758238 := by decide
theorem cert_e1211182247134 : check e1211182247134 [[],[]] .smaller = true := by decide
def e1211182247150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182247150 : Closed e1211182247150 ∧ code e1211182247150 = 5609228758254 := by decide
theorem cert_e1211182247150 : check e1211182247150 [[],[]] .smaller = true := by decide
def e1211182247158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182247158 : Closed e1211182247158 ∧ code e1211182247158 = 5609228758262 := by decide
theorem cert_e1211182247158 : check e1211182247158 [[],[]] .smaller = true := by decide
def e1211182247162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182247162 : Closed e1211182247162 ∧ code e1211182247162 = 5609228758266 := by decide
theorem cert_e1211182247162 : check e1211182247162 [[],[]] .smaller = true := by decide
def e1211182247486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 4)))))))))
theorem wire_e1211182247486 : Closed e1211182247486 ∧ code e1211182247486 = 5609228758590 := by decide
theorem cert_e1211182247486 : check e1211182247486 [[],[]] .smaller = true := by decide
def e1211182247542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182247542 : Closed e1211182247542 ∧ code e1211182247542 = 5609228758646 := by decide
theorem cert_e1211182247542 : check e1211182247542 [[],[]] .smaller = true := by decide
def e1211182247710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 3)))))))))
theorem wire_e1211182247710 : Closed e1211182247710 ∧ code e1211182247710 = 5609228758814 := by decide
theorem cert_e1211182247710 : check e1211182247710 [[],[]] .smaller = true := by decide
def e1211182247734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182247734 : Closed e1211182247734 ∧ code e1211182247734 = 5609228758838 := by decide
theorem cert_e1211182247734 : check e1211182247734 [[],[]] .smaller = true := by decide
def e1211182247738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182247738 : Closed e1211182247738 ∧ code e1211182247738 = 5609228758842 := by decide
theorem cert_e1211182247738 : check e1211182247738 [[],[]] .smaller = true := by decide
def e1211182247822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.lam (.var 2)))))))))
theorem wire_e1211182247822 : Closed e1211182247822 ∧ code e1211182247822 = 5609228758926 := by decide
theorem cert_e1211182247822 : check e1211182247822 [[],[]] .three = true := by decide
def e1211182248382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 4))))))))
theorem wire_e1211182248382 : Closed e1211182248382 ∧ code e1211182248382 = 5609228759486 := by decide
theorem cert_e1211182248382 : check e1211182248382 [[],[]] .three = true := by decide
def e1211182248414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211182248414 : Closed e1211182248414 ∧ code e1211182248414 = 5609228759518 := by decide
theorem cert_e1211182248414 : check e1211182248414 [[],[]] .smaller = true := by decide
def e1211182248430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))))
theorem wire_e1211182248430 : Closed e1211182248430 ∧ code e1211182248430 = 5609228759534 := by decide
theorem cert_e1211182248430 : check e1211182248430 [[],[]] .smaller = true := by decide
def e1211182248438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 1))))))))
theorem wire_e1211182248438 : Closed e1211182248438 ∧ code e1211182248438 = 5609228759542 := by decide
theorem cert_e1211182248438 : check e1211182248438 [[],[]] .smaller = true := by decide
def e1211182248442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211182248442 : Closed e1211182248442 ∧ code e1211182248442 = 5609228759546 := by decide
theorem cert_e1211182248442 : check e1211182248442 [[],[]] .three = true := by decide
def e1211182248798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e1211182248798 : Closed e1211182248798 ∧ code e1211182248798 = 5609228759902 := by decide
theorem cert_e1211182248798 : check e1211182248798 [[],[]] .smaller = true := by decide
def e1211182248814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e1211182248814 : Closed e1211182248814 ∧ code e1211182248814 = 5609228759918 := by decide
theorem cert_e1211182248814 : check e1211182248814 [[],[]] .smaller = true := by decide
def e1211182248822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e1211182248822 : Closed e1211182248822 ∧ code e1211182248822 = 5609228759926 := by decide
theorem cert_e1211182248822 : check e1211182248822 [[],[]] .smaller = true := by decide
def e1211182248826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e1211182248826 : Closed e1211182248826 ∧ code e1211182248826 = 5609228759930 := by decide
theorem cert_e1211182248826 : check e1211182248826 [[],[]] .smaller = true := by decide
def e1211182248878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e1211182248878 : Closed e1211182248878 ∧ code e1211182248878 = 5609228759982 := by decide
theorem cert_e1211182248878 : check e1211182248878 [[],[]] .smaller = true := by decide
def e1211182248890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e1211182248890 : Closed e1211182248890 ∧ code e1211182248890 = 5609228759994 := by decide
theorem cert_e1211182248890 : check e1211182248890 [[],[]] .smaller = true := by decide
def e1211182248918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e1211182248918 : Closed e1211182248918 ∧ code e1211182248918 = 5609228760022 := by decide
theorem cert_e1211182248918 : check e1211182248918 [[],[]] .smaller = true := by decide
def e1211182248922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e1211182248922 : Closed e1211182248922 ∧ code e1211182248922 = 5609228760026 := by decide
theorem cert_e1211182248922 : check e1211182248922 [[],[]] .smaller = true := by decide
def e1211182248938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e1211182248938 : Closed e1211182248938 ∧ code e1211182248938 = 5609228760042 := by decide
theorem cert_e1211182248938 : check e1211182248938 [[],[]] .smaller = true := by decide
def e1211182249086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 5)))))))))
theorem wire_e1211182249086 : Closed e1211182249086 ∧ code e1211182249086 = 5609228760190 := by decide
theorem cert_e1211182249086 : check e1211182249086 [[],[]] .three = true := by decide
def e1211182249182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182249182 : Closed e1211182249182 ∧ code e1211182249182 = 5609228760286 := by decide
theorem cert_e1211182249182 : check e1211182249182 [[],[]] .smaller = true := by decide
def e1211182249198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182249198 : Closed e1211182249198 ∧ code e1211182249198 = 5609228760302 := by decide
theorem cert_e1211182249198 : check e1211182249198 [[],[]] .smaller = true := by decide
def e1211182249206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182249206 : Closed e1211182249206 ∧ code e1211182249206 = 5609228760310 := by decide
theorem cert_e1211182249206 : check e1211182249206 [[],[]] .smaller = true := by decide
def e1211182249210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182249210 : Closed e1211182249210 ∧ code e1211182249210 = 5609228760314 := by decide
theorem cert_e1211182249210 : check e1211182249210 [[],[]] .smaller = true := by decide
def e1211182249534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 4)))))))))
theorem wire_e1211182249534 : Closed e1211182249534 ∧ code e1211182249534 = 5609228760638 := by decide
theorem cert_e1211182249534 : check e1211182249534 [[],[]] .smaller = true := by decide
def e1211182249582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182249582 : Closed e1211182249582 ∧ code e1211182249582 = 5609228760686 := by decide
theorem cert_e1211182249582 : check e1211182249582 [[],[]] .smaller = true := by decide
def e1211182249594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182249594 : Closed e1211182249594 ∧ code e1211182249594 = 5609228760698 := by decide
theorem cert_e1211182249594 : check e1211182249594 [[],[]] .smaller = true := by decide
def e1211182249758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))))
theorem wire_e1211182249758 : Closed e1211182249758 ∧ code e1211182249758 = 5609228760862 := by decide
theorem cert_e1211182249758 : check e1211182249758 [[],[]] .smaller = true := by decide
def e1211182249782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182249782 : Closed e1211182249782 ∧ code e1211182249782 = 5609228760886 := by decide
theorem cert_e1211182249782 : check e1211182249782 [[],[]] .smaller = true := by decide
def e1211182249786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182249786 : Closed e1211182249786 ∧ code e1211182249786 = 5609228760890 := by decide
theorem cert_e1211182249786 : check e1211182249786 [[],[]] .smaller = true := by decide
def e1211182249870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 2)))))))))
theorem wire_e1211182249870 : Closed e1211182249870 ∧ code e1211182249870 = 5609228760974 := by decide
theorem cert_e1211182249870 : check e1211182249870 [[],[]] .smaller = true := by decide
def e1211182249882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182249882 : Closed e1211182249882 ∧ code e1211182249882 = 5609228760986 := by decide
theorem cert_e1211182249882 : check e1211182249882 [[],[]] .smaller = true := by decide
def e1211182249926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.lam (.var 1)))))))))
theorem wire_e1211182249926 : Closed e1211182249926 ∧ code e1211182249926 = 5609228761030 := by decide
theorem cert_e1211182249926 : check e1211182249926 [[],[]] .three = true := by decide
def e1211182250206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e1211182250206 : Closed e1211182250206 ∧ code e1211182250206 = 5609228761310 := by decide
theorem cert_e1211182250206 : check e1211182250206 [[],[]] .smaller = true := by decide
def e1211182250222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211182250222 : Closed e1211182250222 ∧ code e1211182250222 = 5609228761326 := by decide
theorem cert_e1211182250222 : check e1211182250222 [[],[]] .smaller = true := by decide
def e1211182250230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211182250230 : Closed e1211182250230 ∧ code e1211182250230 = 5609228761334 := by decide
theorem cert_e1211182250230 : check e1211182250230 [[],[]] .smaller = true := by decide
def e1211182250234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e1211182250234 : Closed e1211182250234 ∧ code e1211182250234 = 5609228761338 := by decide
theorem cert_e1211182250234 : check e1211182250234 [[],[]] .smaller = true := by decide
def e1211182250422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211182250422 : Closed e1211182250422 ∧ code e1211182250422 = 5609228761526 := by decide
theorem cert_e1211182250422 : check e1211182250422 [[],[]] .smaller = true := by decide
def e1211182250454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211182250454 : Closed e1211182250454 ∧ code e1211182250454 = 5609228761558 := by decide
theorem cert_e1211182250454 : check e1211182250454 [[],[]] .smaller = true := by decide
def e1211182250458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e1211182250458 : Closed e1211182250458 ∧ code e1211182250458 = 5609228761562 := by decide
theorem cert_e1211182250458 : check e1211182250458 [[],[]] .smaller = true := by decide
def e1211182250558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e1211182250558 : Closed e1211182250558 ∧ code e1211182250558 = 5609228761662 := by decide
theorem cert_e1211182250558 : check e1211182250558 [[],[]] .smaller = true := by decide
def e1211182250614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182250614 : Closed e1211182250614 ∧ code e1211182250614 = 5609228761718 := by decide
theorem cert_e1211182250614 : check e1211182250614 [[],[]] .smaller = true := by decide
def e1211182250782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211182250782 : Closed e1211182250782 ∧ code e1211182250782 = 5609228761886 := by decide
theorem cert_e1211182250782 : check e1211182250782 [[],[]] .smaller = true := by decide
def e1211182250806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182250806 : Closed e1211182250806 ∧ code e1211182250806 = 5609228761910 := by decide
theorem cert_e1211182250806 : check e1211182250806 [[],[]] .smaller = true := by decide
def e1211182250810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182250810 : Closed e1211182250810 ∧ code e1211182250810 = 5609228761914 := by decide
theorem cert_e1211182250810 : check e1211182250810 [[],[]] .smaller = true := by decide
def e1211182250894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211182250894 : Closed e1211182250894 ∧ code e1211182250894 = 5609228761998 := by decide
theorem cert_e1211182250894 : check e1211182250894 [[],[]] .smaller = true := by decide
def e1211182250942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 4))))))))
theorem wire_e1211182250942 : Closed e1211182250942 ∧ code e1211182250942 = 5609228762046 := by decide
theorem cert_e1211182250942 : check e1211182250942 [[],[]] .three = true := by decide
def e1211182250950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e1211182250950 : Closed e1211182250950 ∧ code e1211182250950 = 5609228762054 := by decide
theorem cert_e1211182250950 : check e1211182250950 [[],[]] .smaller = true := by decide
def e1211182250974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 3))))))))
theorem wire_e1211182250974 : Closed e1211182250974 ∧ code e1211182250974 = 5609228762078 := by decide
theorem cert_e1211182250974 : check e1211182250974 [[],[]] .smaller = true := by decide
def e1211182250990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 4))) (.var 2))))))))
theorem wire_e1211182250990 : Closed e1211182250990 ∧ code e1211182250990 = 5609228762094 := by decide
theorem cert_e1211182250990 : check e1211182250990 [[],[]] .three = true := by decide
def e1211182251118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211182251118 : Closed e1211182251118 ∧ code e1211182251118 = 5609228762222 := by decide
theorem cert_e1211182251118 : check e1211182251118 [[],[]] .smaller = true := by decide
def e1211182251126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211182251126 : Closed e1211182251126 ∧ code e1211182251126 = 5609228762230 := by decide
theorem cert_e1211182251126 : check e1211182251126 [[],[]] .smaller = true := by decide
def e1211182251130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211182251130 : Closed e1211182251130 ∧ code e1211182251130 = 5609228762234 := by decide
theorem cert_e1211182251130 : check e1211182251130 [[],[]] .smaller = true := by decide
def e1211182251222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211182251222 : Closed e1211182251222 ∧ code e1211182251222 = 5609228762326 := by decide
theorem cert_e1211182251222 : check e1211182251222 [[],[]] .smaller = true := by decide
def e1211182251226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211182251226 : Closed e1211182251226 ∧ code e1211182251226 = 5609228762330 := by decide
theorem cert_e1211182251226 : check e1211182251226 [[],[]] .smaller = true := by decide
def e1211182251242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211182251242 : Closed e1211182251242 ∧ code e1211182251242 = 5609228762346 := by decide
theorem cert_e1211182251242 : check e1211182251242 [[],[]] .smaller = true := by decide
def e1211182251294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211182251294 : Closed e1211182251294 ∧ code e1211182251294 = 5609228762398 := by decide
theorem cert_e1211182251294 : check e1211182251294 [[],[]] .smaller = true := by decide
def e1211182251318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182251318 : Closed e1211182251318 ∧ code e1211182251318 = 5609228762422 := by decide
theorem cert_e1211182251318 : check e1211182251318 [[],[]] .smaller = true := by decide
def e1211182251322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182251322 : Closed e1211182251322 ∧ code e1211182251322 = 5609228762426 := by decide
theorem cert_e1211182251322 : check e1211182251322 [[],[]] .smaller = true := by decide
def e1211182251406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211182251406 : Closed e1211182251406 ∧ code e1211182251406 = 5609228762510 := by decide
theorem cert_e1211182251406 : check e1211182251406 [[],[]] .smaller = true := by decide
def e1211182251418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182251418 : Closed e1211182251418 ∧ code e1211182251418 = 5609228762522 := by decide
theorem cert_e1211182251418 : check e1211182251418 [[],[]] .smaller = true := by decide
def e1211182251462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211182251462 : Closed e1211182251462 ∧ code e1211182251462 = 5609228762566 := by decide
theorem cert_e1211182251462 : check e1211182251462 [[],[]] .smaller = true := by decide
def e1211182251486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 3))))))))
theorem wire_e1211182251486 : Closed e1211182251486 ∧ code e1211182251486 = 5609228762590 := by decide
theorem cert_e1211182251486 : check e1211182251486 [[],[]] .smaller = true := by decide
def e1211182251502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 2))))))))
theorem wire_e1211182251502 : Closed e1211182251502 ∧ code e1211182251502 = 5609228762606 := by decide
theorem cert_e1211182251502 : check e1211182251502 [[],[]] .smaller = true := by decide
def e1211182251574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211182251574 : Closed e1211182251574 ∧ code e1211182251574 = 5609228762678 := by decide
theorem cert_e1211182251574 : check e1211182251574 [[],[]] .three = true := by decide
def e1211182251578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211182251578 : Closed e1211182251578 ∧ code e1211182251578 = 5609228762682 := by decide
theorem cert_e1211182251578 : check e1211182251578 [[],[]] .three = true := by decide
def e1211182251662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211182251662 : Closed e1211182251662 ∧ code e1211182251662 = 5609228762766 := by decide
theorem cert_e1211182251662 : check e1211182251662 [[],[]] .three = true := by decide
def e1211182251718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211182251718 : Closed e1211182251718 ∧ code e1211182251718 = 5609228762822 := by decide
theorem cert_e1211182251718 : check e1211182251718 [[],[]] .three = true := by decide
def e1211182251758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 2))) (.var 2))))))))
theorem wire_e1211182251758 : Closed e1211182251758 ∧ code e1211182251758 = 5609228762862 := by decide
theorem cert_e1211182251758 : check e1211182251758 [[],[]] .three = true := by decide
def e1211182254014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211182254014 : Closed e1211182254014 ∧ code e1211182254014 = 5609228765118 := by decide
theorem cert_e1211182254014 : check e1211182254014 [[],[]] .smaller = true := by decide
def e1211182254062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211182254062 : Closed e1211182254062 ∧ code e1211182254062 = 5609228765166 := by decide
theorem cert_e1211182254062 : check e1211182254062 [[],[]] .smaller = true := by decide
def e1211182257886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211182257886 : Closed e1211182257886 ∧ code e1211182257886 = 5609228768990 := by decide
theorem cert_e1211182257886 : check e1211182257886 [[],[]] .smaller = true := by decide
def e1211182257910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211182257910 : Closed e1211182257910 ∧ code e1211182257910 = 5609228769014 := by decide
theorem cert_e1211182257910 : check e1211182257910 [[],[]] .smaller = true := by decide
def e1211182258014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211182258014 : Closed e1211182258014 ∧ code e1211182258014 = 5609228769118 := by decide
theorem cert_e1211182258014 : check e1211182258014 [[],[]] .smaller = true := by decide
def e1211182258030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211182258030 : Closed e1211182258030 ∧ code e1211182258030 = 5609228769134 := by decide
theorem cert_e1211182258030 : check e1211182258030 [[],[]] .smaller = true := by decide
def e1211182258038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211182258038 : Closed e1211182258038 ∧ code e1211182258038 = 5609228769142 := by decide
theorem cert_e1211182258038 : check e1211182258038 [[],[]] .smaller = true := by decide
def e1211182258042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211182258042 : Closed e1211182258042 ∧ code e1211182258042 = 5609228769146 := by decide
theorem cert_e1211182258042 : check e1211182258042 [[],[]] .smaller = true := by decide
def e1211182258102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211182258102 : Closed e1211182258102 ∧ code e1211182258102 = 5609228769206 := by decide
theorem cert_e1211182258102 : check e1211182258102 [[],[]] .smaller = true := by decide
def e1211182258134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211182258134 : Closed e1211182258134 ∧ code e1211182258134 = 5609228769238 := by decide
theorem cert_e1211182258134 : check e1211182258134 [[],[]] .smaller = true := by decide
def e1211182258138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211182258138 : Closed e1211182258138 ∧ code e1211182258138 = 5609228769242 := by decide
theorem cert_e1211182258138 : check e1211182258138 [[],[]] .smaller = true := by decide
def e1211182258654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211182258654 : Closed e1211182258654 ∧ code e1211182258654 = 5609228769758 := by decide
theorem cert_e1211182258654 : check e1211182258654 [[],[]] .smaller = true := by decide
def e1211182258678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211182258678 : Closed e1211182258678 ∧ code e1211182258678 = 5609228769782 := by decide
theorem cert_e1211182258678 : check e1211182258678 [[],[]] .smaller = true := by decide
def e1211182259326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 5))))))))))
theorem wire_e1211182259326 : Closed e1211182259326 ∧ code e1211182259326 = 5609228770430 := by decide
theorem cert_e1211182259326 : check e1211182259326 [[],[]] .three = true := by decide
def e1211182259422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182259422 : Closed e1211182259422 ∧ code e1211182259422 = 5609228770526 := by decide
theorem cert_e1211182259422 : check e1211182259422 [[],[]] .smaller = true := by decide
def e1211182259438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182259438 : Closed e1211182259438 ∧ code e1211182259438 = 5609228770542 := by decide
theorem cert_e1211182259438 : check e1211182259438 [[],[]] .smaller = true := by decide
def e1211182259446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182259446 : Closed e1211182259446 ∧ code e1211182259446 = 5609228770550 := by decide
theorem cert_e1211182259446 : check e1211182259446 [[],[]] .smaller = true := by decide
def e1211182259450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182259450 : Closed e1211182259450 ∧ code e1211182259450 = 5609228770554 := by decide
theorem cert_e1211182259450 : check e1211182259450 [[],[]] .smaller = true := by decide
def e1211182259774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211182259774 : Closed e1211182259774 ∧ code e1211182259774 = 5609228770878 := by decide
theorem cert_e1211182259774 : check e1211182259774 [[],[]] .smaller = true := by decide
def e1211182259830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182259830 : Closed e1211182259830 ∧ code e1211182259830 = 5609228770934 := by decide
theorem cert_e1211182259830 : check e1211182259830 [[],[]] .smaller = true := by decide
def e1211182259998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211182259998 : Closed e1211182259998 ∧ code e1211182259998 = 5609228771102 := by decide
theorem cert_e1211182259998 : check e1211182259998 [[],[]] .smaller = true := by decide
def e1211182260022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182260022 : Closed e1211182260022 ∧ code e1211182260022 = 5609228771126 := by decide
theorem cert_e1211182260022 : check e1211182260022 [[],[]] .smaller = true := by decide
def e1211182260026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182260026 : Closed e1211182260026 ∧ code e1211182260026 = 5609228771130 := by decide
theorem cert_e1211182260026 : check e1211182260026 [[],[]] .smaller = true := by decide
def e1211182260110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.lam (.var 2))))))))))
theorem wire_e1211182260110 : Closed e1211182260110 ∧ code e1211182260110 = 5609228771214 := by decide
theorem cert_e1211182260110 : check e1211182260110 [[],[]] .three = true := by decide
def e1211182269374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e1211182269374 : Closed e1211182269374 ∧ code e1211182269374 = 5609228780478 := by decide
theorem cert_e1211182269374 : check e1211182269374 [[],[]] .smaller = true := by decide
def e1211182269406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182269406 : Closed e1211182269406 ∧ code e1211182269406 = 5609228780510 := by decide
theorem cert_e1211182269406 : check e1211182269406 [[],[]] .smaller = true := by decide
def e1211182269422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182269422 : Closed e1211182269422 ∧ code e1211182269422 = 5609228780526 := by decide
theorem cert_e1211182269422 : check e1211182269422 [[],[]] .smaller = true := by decide
def e1211182269430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e1211182269430 : Closed e1211182269430 ∧ code e1211182269430 = 5609228780534 := by decide
theorem cert_e1211182269430 : check e1211182269430 [[],[]] .smaller = true := by decide
def e1211182271326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211182271326 : Closed e1211182271326 ∧ code e1211182271326 = 5609228782430 := by decide
theorem cert_e1211182271326 : check e1211182271326 [[],[]] .smaller = true := by decide
def e1211182271342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211182271342 : Closed e1211182271342 ∧ code e1211182271342 = 5609228782446 := by decide
theorem cert_e1211182271342 : check e1211182271342 [[],[]] .smaller = true := by decide
def e1211182271350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211182271350 : Closed e1211182271350 ∧ code e1211182271350 = 5609228782454 := by decide
theorem cert_e1211182271350 : check e1211182271350 [[],[]] .smaller = true := by decide
def e1211182271354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211182271354 : Closed e1211182271354 ∧ code e1211182271354 = 5609228782458 := by decide
theorem cert_e1211182271354 : check e1211182271354 [[],[]] .smaller = true := by decide
def e1211182271406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211182271406 : Closed e1211182271406 ∧ code e1211182271406 = 5609228782510 := by decide
theorem cert_e1211182271406 : check e1211182271406 [[],[]] .smaller = true := by decide
def e1211182271418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211182271418 : Closed e1211182271418 ∧ code e1211182271418 = 5609228782522 := by decide
theorem cert_e1211182271418 : check e1211182271418 [[],[]] .smaller = true := by decide
def e1211182271446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211182271446 : Closed e1211182271446 ∧ code e1211182271446 = 5609228782550 := by decide
theorem cert_e1211182271446 : check e1211182271446 [[],[]] .smaller = true := by decide
def e1211182271450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211182271450 : Closed e1211182271450 ∧ code e1211182271450 = 5609228782554 := by decide
theorem cert_e1211182271450 : check e1211182271450 [[],[]] .smaller = true := by decide
def e1211182271466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211182271466 : Closed e1211182271466 ∧ code e1211182271466 = 5609228782570 := by decide
theorem cert_e1211182271466 : check e1211182271466 [[],[]] .smaller = true := by decide
def e1211182271614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 5))))))))))
theorem wire_e1211182271614 : Closed e1211182271614 ∧ code e1211182271614 = 5609228782718 := by decide
theorem cert_e1211182271614 : check e1211182271614 [[],[]] .three = true := by decide
def e1211182271710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182271710 : Closed e1211182271710 ∧ code e1211182271710 = 5609228782814 := by decide
theorem cert_e1211182271710 : check e1211182271710 [[],[]] .smaller = true := by decide
def e1211182271726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182271726 : Closed e1211182271726 ∧ code e1211182271726 = 5609228782830 := by decide
theorem cert_e1211182271726 : check e1211182271726 [[],[]] .smaller = true := by decide
def e1211182271734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182271734 : Closed e1211182271734 ∧ code e1211182271734 = 5609228782838 := by decide
theorem cert_e1211182271734 : check e1211182271734 [[],[]] .smaller = true := by decide
def e1211182271738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182271738 : Closed e1211182271738 ∧ code e1211182271738 = 5609228782842 := by decide
theorem cert_e1211182271738 : check e1211182271738 [[],[]] .smaller = true := by decide
def e1211182272062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211182272062 : Closed e1211182272062 ∧ code e1211182272062 = 5609228783166 := by decide
theorem cert_e1211182272062 : check e1211182272062 [[],[]] .smaller = true := by decide
def e1211182272110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182272110 : Closed e1211182272110 ∧ code e1211182272110 = 5609228783214 := by decide
theorem cert_e1211182272110 : check e1211182272110 [[],[]] .smaller = true := by decide
def e1211182272122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182272122 : Closed e1211182272122 ∧ code e1211182272122 = 5609228783226 := by decide
theorem cert_e1211182272122 : check e1211182272122 [[],[]] .smaller = true := by decide
def e1211182272286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211182272286 : Closed e1211182272286 ∧ code e1211182272286 = 5609228783390 := by decide
theorem cert_e1211182272286 : check e1211182272286 [[],[]] .smaller = true := by decide
def e1211182272310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182272310 : Closed e1211182272310 ∧ code e1211182272310 = 5609228783414 := by decide
theorem cert_e1211182272310 : check e1211182272310 [[],[]] .smaller = true := by decide
end Blc.Floor42
