import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211282856822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211282856822 : Closed e1211282856822 ∧ code e1211282856822 = 5609329367926 := by decide
theorem cert_e1211282856822 : check e1211282856822 [[],[]] .chain = true := by decide
def e1211282856886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211282856886 : Closed e1211282856886 ∧ code e1211282856886 = 5609329367990 := by decide
theorem cert_e1211282856886 : check e1211282856886 [[],[]] .chain = true := by decide
def e1211282857326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211282857326 : Closed e1211282857326 ∧ code e1211282857326 = 5609329368430 := by decide
theorem cert_e1211282857326 : check e1211282857326 [[],[]] .chain = true := by decide
def e1211282857334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211282857334 : Closed e1211282857334 ∧ code e1211282857334 = 5609329368438 := by decide
theorem cert_e1211282857334 : check e1211282857334 [[],[]] .chain = true := by decide
def e1211282857390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211282857390 : Closed e1211282857390 ∧ code e1211282857390 = 5609329368494 := by decide
theorem cert_e1211282857390 : check e1211282857390 [[],[]] .chain = true := by decide
def e1211282857402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211282857402 : Closed e1211282857402 ∧ code e1211282857402 = 5609329368506 := by decide
theorem cert_e1211282857402 : check e1211282857402 [[],[]] .chain = true := by decide
def e1211282857430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211282857430 : Closed e1211282857430 ∧ code e1211282857430 = 5609329368534 := by decide
theorem cert_e1211282857430 : check e1211282857430 [[],[]] .chain = true := by decide
def e1211282857434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211282857434 : Closed e1211282857434 ∧ code e1211282857434 = 5609329368538 := by decide
theorem cert_e1211282857434 : check e1211282857434 [[],[]] .chain = true := by decide
def e1211282857654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211282857654 : Closed e1211282857654 ∧ code e1211282857654 = 5609329368758 := by decide
theorem cert_e1211282857654 : check e1211282857654 [[],[]] .chain = true := by decide
def e1211282857686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211282857686 : Closed e1211282857686 ∧ code e1211282857686 = 5609329368790 := by decide
theorem cert_e1211282857686 : check e1211282857686 [[],[]] .chain = true := by decide
def e1211282857690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211282857690 : Closed e1211282857690 ∧ code e1211282857690 = 5609329368794 := by decide
theorem cert_e1211282857690 : check e1211282857690 [[],[]] .chain = true := by decide
def e1211282859886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211282859886 : Closed e1211282859886 ∧ code e1211282859886 = 5609329370990 := by decide
theorem cert_e1211282859886 : check e1211282859886 [[],[]] .chain = true := by decide
def e1211282859894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211282859894 : Closed e1211282859894 ∧ code e1211282859894 = 5609329370998 := by decide
theorem cert_e1211282859894 : check e1211282859894 [[],[]] .chain = true := by decide
def e1211282859958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211282859958 : Closed e1211282859958 ∧ code e1211282859958 = 5609329371062 := by decide
theorem cert_e1211282859958 : check e1211282859958 [[],[]] .chain = true := by decide
def e1211282861294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282861294 : Closed e1211282861294 ∧ code e1211282861294 = 5609329372398 := by decide
theorem cert_e1211282861294 : check e1211282861294 [[],[]] .chain = true := by decide
def e1211282861302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282861302 : Closed e1211282861302 ∧ code e1211282861302 = 5609329372406 := by decide
theorem cert_e1211282861302 : check e1211282861302 [[],[]] .chain = true := by decide
def e1211282861686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282861686 : Closed e1211282861686 ∧ code e1211282861686 = 5609329372790 := by decide
theorem cert_e1211282861686 : check e1211282861686 [[],[]] .chain = true := by decide
def e1211282862190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211282862190 : Closed e1211282862190 ∧ code e1211282862190 = 5609329373294 := by decide
theorem cert_e1211282862190 : check e1211282862190 [[],[]] .chain = true := by decide
def e1211282862366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211282862366 : Closed e1211282862366 ∧ code e1211282862366 = 5609329373470 := by decide
theorem cert_e1211282862366 : check e1211282862366 [[],[]] .chain = true := by decide
def e1211282862562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211282862562 : Closed e1211282862562 ∧ code e1211282862562 = 5609329373666 := by decide
theorem cert_e1211282862562 : check e1211282862562 [[],[]] .chain = true := by decide
def e1211282862574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211282862574 : Closed e1211282862574 ∧ code e1211282862574 = 5609329373678 := by decide
theorem cert_e1211282862574 : check e1211282862574 [[],[]] .sourceHead = true := by decide
def e1211282862958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211282862958 : Closed e1211282862958 ∧ code e1211282862958 = 5609329374062 := by decide
theorem cert_e1211282862958 : check e1211282862958 [[],[]] .chain = true := by decide
def e1211282862966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211282862966 : Closed e1211282862966 ∧ code e1211282862966 = 5609329374070 := by decide
theorem cert_e1211282862966 : check e1211282862966 [[],[]] .chain = true := by decide
def e1211282863022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211282863022 : Closed e1211282863022 ∧ code e1211282863022 = 5609329374126 := by decide
theorem cert_e1211282863022 : check e1211282863022 [[],[]] .chain = true := by decide
def e1211282863034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211282863034 : Closed e1211282863034 ∧ code e1211282863034 = 5609329374138 := by decide
theorem cert_e1211282863034 : check e1211282863034 [[],[]] .chain = true := by decide
def e1211282863062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211282863062 : Closed e1211282863062 ∧ code e1211282863062 = 5609329374166 := by decide
theorem cert_e1211282863062 : check e1211282863062 [[],[]] .chain = true := by decide
def e1211282863066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211282863066 : Closed e1211282863066 ∧ code e1211282863066 = 5609329374170 := by decide
theorem cert_e1211282863066 : check e1211282863066 [[],[]] .chain = true := by decide
def e1211282863342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282863342 : Closed e1211282863342 ∧ code e1211282863342 = 5609329374446 := by decide
theorem cert_e1211282863342 : check e1211282863342 [[],[]] .chain = true := by decide
def e1211282863350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282863350 : Closed e1211282863350 ∧ code e1211282863350 = 5609329374454 := by decide
theorem cert_e1211282863350 : check e1211282863350 [[],[]] .chain = true := by decide
def e1211282863726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282863726 : Closed e1211282863726 ∧ code e1211282863726 = 5609329374830 := by decide
theorem cert_e1211282863726 : check e1211282863726 [[],[]] .chain = true := by decide
def e1211282863738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282863738 : Closed e1211282863738 ∧ code e1211282863738 = 5609329374842 := by decide
theorem cert_e1211282863738 : check e1211282863738 [[],[]] .chain = true := by decide
def e1211282863878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282863878 : Closed e1211282863878 ∧ code e1211282863878 = 5609329374982 := by decide
theorem cert_e1211282863878 : check e1211282863878 [[],[]] .chain = true := by decide
def e1211282863902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211282863902 : Closed e1211282863902 ∧ code e1211282863902 = 5609329375006 := by decide
theorem cert_e1211282863902 : check e1211282863902 [[],[]] .sourceHead = true := by decide
def e1211282863926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282863926 : Closed e1211282863926 ∧ code e1211282863926 = 5609329375030 := by decide
theorem cert_e1211282863926 : check e1211282863926 [[],[]] .chain = true := by decide
def e1211282863930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282863930 : Closed e1211282863930 ∧ code e1211282863930 = 5609329375034 := by decide
theorem cert_e1211282863930 : check e1211282863930 [[],[]] .chain = true := by decide
def e1211282864182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211282864182 : Closed e1211282864182 ∧ code e1211282864182 = 5609329375286 := by decide
theorem cert_e1211282864182 : check e1211282864182 [[],[]] .chain = true := by decide
def e1211282864270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211282864270 : Closed e1211282864270 ∧ code e1211282864270 = 5609329375374 := by decide
theorem cert_e1211282864270 : check e1211282864270 [[],[]] .chain = true := by decide
def e1211282864354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211282864354 : Closed e1211282864354 ∧ code e1211282864354 = 5609329375458 := by decide
theorem cert_e1211282864354 : check e1211282864354 [[],[]] .chain = true := by decide
def e1211282864366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211282864366 : Closed e1211282864366 ∧ code e1211282864366 = 5609329375470 := by decide
theorem cert_e1211282864366 : check e1211282864366 [[],[]] .sourceHead = true := by decide
def e1211282864374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211282864374 : Closed e1211282864374 ∧ code e1211282864374 = 5609329375478 := by decide
theorem cert_e1211282864374 : check e1211282864374 [[],[]] .sourceHead = true := by decide
def e1211282864566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211282864566 : Closed e1211282864566 ∧ code e1211282864566 = 5609329375670 := by decide
theorem cert_e1211282864566 : check e1211282864566 [[],[]] .chain = true := by decide
def e1211282864598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211282864598 : Closed e1211282864598 ∧ code e1211282864598 = 5609329375702 := by decide
theorem cert_e1211282864598 : check e1211282864598 [[],[]] .chain = true := by decide
def e1211282864602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211282864602 : Closed e1211282864602 ∧ code e1211282864602 = 5609329375706 := by decide
theorem cert_e1211282864602 : check e1211282864602 [[],[]] .chain = true := by decide
def e1211282864758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282864758 : Closed e1211282864758 ∧ code e1211282864758 = 5609329375862 := by decide
theorem cert_e1211282864758 : check e1211282864758 [[],[]] .chain = true := by decide
def e1211282864902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282864902 : Closed e1211282864902 ∧ code e1211282864902 = 5609329376006 := by decide
theorem cert_e1211282864902 : check e1211282864902 [[],[]] .chain = true := by decide
def e1211282864926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211282864926 : Closed e1211282864926 ∧ code e1211282864926 = 5609329376030 := by decide
theorem cert_e1211282864926 : check e1211282864926 [[],[]] .sourceHead = true := by decide
def e1211282864950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282864950 : Closed e1211282864950 ∧ code e1211282864950 = 5609329376054 := by decide
theorem cert_e1211282864950 : check e1211282864950 [[],[]] .chain = true := by decide
def e1211282864954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282864954 : Closed e1211282864954 ∧ code e1211282864954 = 5609329376058 := by decide
theorem cert_e1211282864954 : check e1211282864954 [[],[]] .chain = true := by decide
def e1211282865038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211282865038 : Closed e1211282865038 ∧ code e1211282865038 = 5609329376142 := by decide
theorem cert_e1211282865038 : check e1211282865038 [[],[]] .sourceHead = true := by decide
def e1211282866606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211282866606 : Closed e1211282866606 ∧ code e1211282866606 = 5609329377710 := by decide
theorem cert_e1211282866606 : check e1211282866606 [[],[]] .chain = true := by decide
def e1211282866618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211282866618 : Closed e1211282866618 ∧ code e1211282866618 = 5609329377722 := by decide
theorem cert_e1211282866618 : check e1211282866618 [[],[]] .chain = true := by decide
def e1211282867310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211282867310 : Closed e1211282867310 ∧ code e1211282867310 = 5609329378414 := by decide
theorem cert_e1211282867310 : check e1211282867310 [[],[]] .chain = true := by decide
def e1211282867322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211282867322 : Closed e1211282867322 ∧ code e1211282867322 = 5609329378426 := by decide
theorem cert_e1211282867322 : check e1211282867322 [[],[]] .chain = true := by decide
def e1211282867486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211282867486 : Closed e1211282867486 ∧ code e1211282867486 = 5609329378590 := by decide
theorem cert_e1211282867486 : check e1211282867486 [[],[]] .chain = true := by decide
def e1211282867654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211282867654 : Closed e1211282867654 ∧ code e1211282867654 = 5609329378758 := by decide
theorem cert_e1211282867654 : check e1211282867654 [[],[]] .chain = true := by decide
def e1211282867758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211282867758 : Closed e1211282867758 ∧ code e1211282867758 = 5609329378862 := by decide
theorem cert_e1211282867758 : check e1211282867758 [[],[]] .chain = true := by decide
def e1211282867938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211282867938 : Closed e1211282867938 ∧ code e1211282867938 = 5609329379042 := by decide
theorem cert_e1211282867938 : check e1211282867938 [[],[]] .chain = true := by decide
def e1211282867950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211282867950 : Closed e1211282867950 ∧ code e1211282867950 = 5609329379054 := by decide
theorem cert_e1211282867950 : check e1211282867950 [[],[]] .sourceHead = true := by decide
def e1211282868106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211282868106 : Closed e1211282868106 ∧ code e1211282868106 = 5609329379210 := by decide
theorem cert_e1211282868106 : check e1211282868106 [[],[]] .chain = true := by decide
def e1211282868130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211282868130 : Closed e1211282868130 ∧ code e1211282868130 = 5609329379234 := by decide
theorem cert_e1211282868130 : check e1211282868130 [[],[]] .chain = true := by decide
def e1211282868142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211282868142 : Closed e1211282868142 ∧ code e1211282868142 = 5609329379246 := by decide
theorem cert_e1211282868142 : check e1211282868142 [[],[]] .sourceHead = true := by decide
def e1211282868154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211282868154 : Closed e1211282868154 ∧ code e1211282868154 = 5609329379258 := by decide
theorem cert_e1211282868154 : check e1211282868154 [[],[]] .sourceHead = true := by decide
def e1211282869614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211282869614 : Closed e1211282869614 ∧ code e1211282869614 = 5609329380718 := by decide
theorem cert_e1211282869614 : check e1211282869614 [[],[]] .chain = true := by decide
def e1211282869622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211282869622 : Closed e1211282869622 ∧ code e1211282869622 = 5609329380726 := by decide
theorem cert_e1211282869622 : check e1211282869622 [[],[]] .chain = true := by decide
def e1211282869678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211282869678 : Closed e1211282869678 ∧ code e1211282869678 = 5609329380782 := by decide
theorem cert_e1211282869678 : check e1211282869678 [[],[]] .chain = true := by decide
def e1211282869690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211282869690 : Closed e1211282869690 ∧ code e1211282869690 = 5609329380794 := by decide
theorem cert_e1211282869690 : check e1211282869690 [[],[]] .chain = true := by decide
def e1211282869718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211282869718 : Closed e1211282869718 ∧ code e1211282869718 = 5609329380822 := by decide
theorem cert_e1211282869718 : check e1211282869718 [[],[]] .chain = true := by decide
def e1211282869722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211282869722 : Closed e1211282869722 ∧ code e1211282869722 = 5609329380826 := by decide
theorem cert_e1211282869722 : check e1211282869722 [[],[]] .chain = true := by decide
def e1211282869934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211282869934 : Closed e1211282869934 ∧ code e1211282869934 = 5609329381038 := by decide
theorem cert_e1211282869934 : check e1211282869934 [[],[]] .chain = true := by decide
def e1211282869946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211282869946 : Closed e1211282869946 ∧ code e1211282869946 = 5609329381050 := by decide
theorem cert_e1211282869946 : check e1211282869946 [[],[]] .chain = true := by decide
def e1211282869994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211282869994 : Closed e1211282869994 ∧ code e1211282869994 = 5609329381098 := by decide
theorem cert_e1211282869994 : check e1211282869994 [[],[]] .chain = true := by decide
def e1211282870102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211282870102 : Closed e1211282870102 ∧ code e1211282870102 = 5609329381206 := by decide
theorem cert_e1211282870102 : check e1211282870102 [[],[]] .chain = true := by decide
def e1211282870106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211282870106 : Closed e1211282870106 ∧ code e1211282870106 = 5609329381210 := by decide
theorem cert_e1211282870106 : check e1211282870106 [[],[]] .chain = true := by decide
def e1211282870122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211282870122 : Closed e1211282870122 ∧ code e1211282870122 = 5609329381226 := by decide
theorem cert_e1211282870122 : check e1211282870122 [[],[]] .chain = true := by decide
def e1211282870382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211282870382 : Closed e1211282870382 ∧ code e1211282870382 = 5609329381486 := by decide
theorem cert_e1211282870382 : check e1211282870382 [[],[]] .chain = true := by decide
def e1211282870558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211282870558 : Closed e1211282870558 ∧ code e1211282870558 = 5609329381662 := by decide
theorem cert_e1211282870558 : check e1211282870558 [[],[]] .chain = true := by decide
def e1211282870754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211282870754 : Closed e1211282870754 ∧ code e1211282870754 = 5609329381858 := by decide
theorem cert_e1211282870754 : check e1211282870754 [[],[]] .chain = true := by decide
def e1211282870766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211282870766 : Closed e1211282870766 ∧ code e1211282870766 = 5609329381870 := by decide
theorem cert_e1211282870766 : check e1211282870766 [[],[]] .sourceHead = true := by decide
def e1211282871150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211282871150 : Closed e1211282871150 ∧ code e1211282871150 = 5609329382254 := by decide
theorem cert_e1211282871150 : check e1211282871150 [[],[]] .chain = true := by decide
def e1211282871158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211282871158 : Closed e1211282871158 ∧ code e1211282871158 = 5609329382262 := by decide
theorem cert_e1211282871158 : check e1211282871158 [[],[]] .chain = true := by decide
def e1211282871214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211282871214 : Closed e1211282871214 ∧ code e1211282871214 = 5609329382318 := by decide
theorem cert_e1211282871214 : check e1211282871214 [[],[]] .chain = true := by decide
def e1211282871226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211282871226 : Closed e1211282871226 ∧ code e1211282871226 = 5609329382330 := by decide
theorem cert_e1211282871226 : check e1211282871226 [[],[]] .chain = true := by decide
def e1211282871254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211282871254 : Closed e1211282871254 ∧ code e1211282871254 = 5609329382358 := by decide
theorem cert_e1211282871254 : check e1211282871254 [[],[]] .chain = true := by decide
def e1211282871258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211282871258 : Closed e1211282871258 ∧ code e1211282871258 = 5609329382362 := by decide
theorem cert_e1211282871258 : check e1211282871258 [[],[]] .chain = true := by decide
def e1211282871534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211282871534 : Closed e1211282871534 ∧ code e1211282871534 = 5609329382638 := by decide
theorem cert_e1211282871534 : check e1211282871534 [[],[]] .chain = true := by decide
def e1211282871542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211282871542 : Closed e1211282871542 ∧ code e1211282871542 = 5609329382646 := by decide
theorem cert_e1211282871542 : check e1211282871542 [[],[]] .chain = true := by decide
def e1211282871918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282871918 : Closed e1211282871918 ∧ code e1211282871918 = 5609329383022 := by decide
theorem cert_e1211282871918 : check e1211282871918 [[],[]] .chain = true := by decide
def e1211282871930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282871930 : Closed e1211282871930 ∧ code e1211282871930 = 5609329383034 := by decide
theorem cert_e1211282871930 : check e1211282871930 [[],[]] .chain = true := by decide
def e1211282872070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282872070 : Closed e1211282872070 ∧ code e1211282872070 = 5609329383174 := by decide
theorem cert_e1211282872070 : check e1211282872070 [[],[]] .chain = true := by decide
def e1211282872094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211282872094 : Closed e1211282872094 ∧ code e1211282872094 = 5609329383198 := by decide
theorem cert_e1211282872094 : check e1211282872094 [[],[]] .sourceHead = true := by decide
def e1211282872118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282872118 : Closed e1211282872118 ∧ code e1211282872118 = 5609329383222 := by decide
theorem cert_e1211282872118 : check e1211282872118 [[],[]] .chain = true := by decide
def e1211282872122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282872122 : Closed e1211282872122 ∧ code e1211282872122 = 5609329383226 := by decide
theorem cert_e1211282872122 : check e1211282872122 [[],[]] .chain = true := by decide
def e1211282872750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211282872750 : Closed e1211282872750 ∧ code e1211282872750 = 5609329383854 := by decide
theorem cert_e1211282872750 : check e1211282872750 [[],[]] .chain = true := by decide
def e1211282872762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211282872762 : Closed e1211282872762 ∧ code e1211282872762 = 5609329383866 := by decide
theorem cert_e1211282872762 : check e1211282872762 [[],[]] .chain = true := by decide
def e1211282872810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211282872810 : Closed e1211282872810 ∧ code e1211282872810 = 5609329383914 := by decide
theorem cert_e1211282872810 : check e1211282872810 [[],[]] .chain = true := by decide
def e1211282872942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211282872942 : Closed e1211282872942 ∧ code e1211282872942 = 5609329384046 := by decide
theorem cert_e1211282872942 : check e1211282872942 [[],[]] .chain = true := by decide
def e1211282872954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211282872954 : Closed e1211282872954 ∧ code e1211282872954 = 5609329384058 := by decide
theorem cert_e1211282872954 : check e1211282872954 [[],[]] .chain = true := by decide
def e1211282873242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282873242 : Closed e1211282873242 ∧ code e1211282873242 = 5609329384346 := by decide
theorem cert_e1211282873242 : check e1211282873242 [[],[]] .chain = true := by decide
def e1211282873370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211282873370 : Closed e1211282873370 ∧ code e1211282873370 = 5609329384474 := by decide
theorem cert_e1211282873370 : check e1211282873370 [[],[]] .chain = true := by decide
def e1211282873414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211282873414 : Closed e1211282873414 ∧ code e1211282873414 = 5609329384518 := by decide
theorem cert_e1211282873414 : check e1211282873414 [[],[]] .chain = true := by decide
def e1211282873442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211282873442 : Closed e1211282873442 ∧ code e1211282873442 = 5609329384546 := by decide
theorem cert_e1211282873442 : check e1211282873442 [[],[]] .chain = true := by decide
def e1211282873454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211282873454 : Closed e1211282873454 ∧ code e1211282873454 = 5609329384558 := by decide
theorem cert_e1211282873454 : check e1211282873454 [[],[]] .sourceHead = true := by decide
def e1211282873466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211282873466 : Closed e1211282873466 ∧ code e1211282873466 = 5609329384570 := by decide
theorem cert_e1211282873466 : check e1211282873466 [[],[]] .sourceHead = true := by decide
def e1211282873558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211282873558 : Closed e1211282873558 ∧ code e1211282873558 = 5609329384662 := by decide
theorem cert_e1211282873558 : check e1211282873558 [[],[]] .chain = true := by decide
def e1211282873562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211282873562 : Closed e1211282873562 ∧ code e1211282873562 = 5609329384666 := by decide
theorem cert_e1211282873562 : check e1211282873562 [[],[]] .chain = true := by decide
def e1211282873578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211282873578 : Closed e1211282873578 ∧ code e1211282873578 = 5609329384682 := by decide
theorem cert_e1211282873578 : check e1211282873578 [[],[]] .chain = true := by decide
def e1211282873606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282873606 : Closed e1211282873606 ∧ code e1211282873606 = 5609329384710 := by decide
theorem cert_e1211282873606 : check e1211282873606 [[],[]] .chain = true := by decide
def e1211282873630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211282873630 : Closed e1211282873630 ∧ code e1211282873630 = 5609329384734 := by decide
theorem cert_e1211282873630 : check e1211282873630 [[],[]] .sourceHead = true := by decide
def e1211282873654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282873654 : Closed e1211282873654 ∧ code e1211282873654 = 5609329384758 := by decide
theorem cert_e1211282873654 : check e1211282873654 [[],[]] .chain = true := by decide
def e1211282873658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282873658 : Closed e1211282873658 ∧ code e1211282873658 = 5609329384762 := by decide
theorem cert_e1211282873658 : check e1211282873658 [[],[]] .chain = true := by decide
def e1211282873754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211282873754 : Closed e1211282873754 ∧ code e1211282873754 = 5609329384858 := by decide
theorem cert_e1211282873754 : check e1211282873754 [[],[]] .chain = true := by decide
def e1211282873798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211282873798 : Closed e1211282873798 ∧ code e1211282873798 = 5609329384902 := by decide
theorem cert_e1211282873798 : check e1211282873798 [[],[]] .sourceHead = true := by decide
def e1211282874582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211282874582 : Closed e1211282874582 ∧ code e1211282874582 = 5609329385686 := by decide
theorem cert_e1211282874582 : check e1211282874582 [[],[]] .chain = true := by decide
def e1211282874586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211282874586 : Closed e1211282874586 ∧ code e1211282874586 = 5609329385690 := by decide
theorem cert_e1211282874586 : check e1211282874586 [[],[]] .chain = true := by decide
def e1211282874934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211282874934 : Closed e1211282874934 ∧ code e1211282874934 = 5609329386038 := by decide
theorem cert_e1211282874934 : check e1211282874934 [[],[]] .chain = true := by decide
def e1211282874938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211282874938 : Closed e1211282874938 ∧ code e1211282874938 = 5609329386042 := by decide
theorem cert_e1211282874938 : check e1211282874938 [[],[]] .chain = true := by decide
def e1211282875022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211282875022 : Closed e1211282875022 ∧ code e1211282875022 = 5609329386126 := by decide
theorem cert_e1211282875022 : check e1211282875022 [[],[]] .chain = true := by decide
def e1211282875078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211282875078 : Closed e1211282875078 ∧ code e1211282875078 = 5609329386182 := by decide
theorem cert_e1211282875078 : check e1211282875078 [[],[]] .chain = true := by decide
def e1211282875158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211282875158 : Closed e1211282875158 ∧ code e1211282875158 = 5609329386262 := by decide
theorem cert_e1211282875158 : check e1211282875158 [[],[]] .chain = true := by decide
def e1211282875234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211282875234 : Closed e1211282875234 ∧ code e1211282875234 = 5609329386338 := by decide
theorem cert_e1211282875234 : check e1211282875234 [[],[]] .chain = true := by decide
def e1211282875246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211282875246 : Closed e1211282875246 ∧ code e1211282875246 = 5609329386350 := by decide
theorem cert_e1211282875246 : check e1211282875246 [[],[]] .sourceHead = true := by decide
def e1211282875254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211282875254 : Closed e1211282875254 ∧ code e1211282875254 = 5609329386358 := by decide
theorem cert_e1211282875254 : check e1211282875254 [[],[]] .sourceHead = true := by decide
def e1211282875274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211282875274 : Closed e1211282875274 ∧ code e1211282875274 = 5609329386378 := by decide
theorem cert_e1211282875274 : check e1211282875274 [[],[]] .chain = true := by decide
def e1211282875298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211282875298 : Closed e1211282875298 ∧ code e1211282875298 = 5609329386402 := by decide
theorem cert_e1211282875298 : check e1211282875298 [[],[]] .chain = true := by decide
def e1211282875310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211282875310 : Closed e1211282875310 ∧ code e1211282875310 = 5609329386414 := by decide
theorem cert_e1211282875310 : check e1211282875310 [[],[]] .sourceHead = true := by decide
def e1211282875322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211282875322 : Closed e1211282875322 ∧ code e1211282875322 = 5609329386426 := by decide
theorem cert_e1211282875322 : check e1211282875322 [[],[]] .sourceHead = true := by decide
def e1211282875350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211282875350 : Closed e1211282875350 ∧ code e1211282875350 = 5609329386454 := by decide
theorem cert_e1211282875350 : check e1211282875350 [[],[]] .sourceHead = true := by decide
def e1211282875354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211282875354 : Closed e1211282875354 ∧ code e1211282875354 = 5609329386458 := by decide
theorem cert_e1211282875354 : check e1211282875354 [[],[]] .sourceHead = true := by decide
def e1211282876086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211282876086 : Closed e1211282876086 ∧ code e1211282876086 = 5609329387190 := by decide
theorem cert_e1211282876086 : check e1211282876086 [[],[]] .chain = true := by decide
def e1211282876118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211282876118 : Closed e1211282876118 ∧ code e1211282876118 = 5609329387222 := by decide
theorem cert_e1211282876118 : check e1211282876118 [[],[]] .chain = true := by decide
def e1211282876122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211282876122 : Closed e1211282876122 ∧ code e1211282876122 = 5609329387226 := by decide
theorem cert_e1211282876122 : check e1211282876122 [[],[]] .chain = true := by decide
def e1211282876246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211282876246 : Closed e1211282876246 ∧ code e1211282876246 = 5609329387350 := by decide
theorem cert_e1211282876246 : check e1211282876246 [[],[]] .chain = true := by decide
def e1211282876250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211282876250 : Closed e1211282876250 ∧ code e1211282876250 = 5609329387354 := by decide
theorem cert_e1211282876250 : check e1211282876250 [[],[]] .chain = true := by decide
def e1211282876266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211282876266 : Closed e1211282876266 ∧ code e1211282876266 = 5609329387370 := by decide
theorem cert_e1211282876266 : check e1211282876266 [[],[]] .chain = true := by decide
def e1211282876470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211282876470 : Closed e1211282876470 ∧ code e1211282876470 = 5609329387574 := by decide
theorem cert_e1211282876470 : check e1211282876470 [[],[]] .chain = true := by decide
def e1211282876558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211282876558 : Closed e1211282876558 ∧ code e1211282876558 = 5609329387662 := by decide
theorem cert_e1211282876558 : check e1211282876558 [[],[]] .chain = true := by decide
def e1211282876642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211282876642 : Closed e1211282876642 ∧ code e1211282876642 = 5609329387746 := by decide
theorem cert_e1211282876642 : check e1211282876642 [[],[]] .chain = true := by decide
def e1211282876654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211282876654 : Closed e1211282876654 ∧ code e1211282876654 = 5609329387758 := by decide
theorem cert_e1211282876654 : check e1211282876654 [[],[]] .sourceHead = true := by decide
def e1211282876662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211282876662 : Closed e1211282876662 ∧ code e1211282876662 = 5609329387766 := by decide
theorem cert_e1211282876662 : check e1211282876662 [[],[]] .sourceHead = true := by decide
def e1211282876854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211282876854 : Closed e1211282876854 ∧ code e1211282876854 = 5609329387958 := by decide
theorem cert_e1211282876854 : check e1211282876854 [[],[]] .chain = true := by decide
def e1211282876886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211282876886 : Closed e1211282876886 ∧ code e1211282876886 = 5609329387990 := by decide
theorem cert_e1211282876886 : check e1211282876886 [[],[]] .chain = true := by decide
def e1211282876890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211282876890 : Closed e1211282876890 ∧ code e1211282876890 = 5609329387994 := by decide
theorem cert_e1211282876890 : check e1211282876890 [[],[]] .chain = true := by decide
def e1211282877046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211282877046 : Closed e1211282877046 ∧ code e1211282877046 = 5609329388150 := by decide
theorem cert_e1211282877046 : check e1211282877046 [[],[]] .chain = true := by decide
def e1211282877190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282877190 : Closed e1211282877190 ∧ code e1211282877190 = 5609329388294 := by decide
theorem cert_e1211282877190 : check e1211282877190 [[],[]] .chain = true := by decide
def e1211282877214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211282877214 : Closed e1211282877214 ∧ code e1211282877214 = 5609329388318 := by decide
theorem cert_e1211282877214 : check e1211282877214 [[],[]] .sourceHead = true := by decide
def e1211282877238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282877238 : Closed e1211282877238 ∧ code e1211282877238 = 5609329388342 := by decide
theorem cert_e1211282877238 : check e1211282877238 [[],[]] .chain = true := by decide
def e1211282877242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282877242 : Closed e1211282877242 ∧ code e1211282877242 = 5609329388346 := by decide
theorem cert_e1211282877242 : check e1211282877242 [[],[]] .chain = true := by decide
def e1211282877326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211282877326 : Closed e1211282877326 ∧ code e1211282877326 = 5609329388430 := by decide
theorem cert_e1211282877326 : check e1211282877326 [[],[]] .sourceHead = true := by decide
def e1211282877466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211282877466 : Closed e1211282877466 ∧ code e1211282877466 = 5609329388570 := by decide
theorem cert_e1211282877466 : check e1211282877466 [[],[]] .chain = true := by decide
def e1211282877510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211282877510 : Closed e1211282877510 ∧ code e1211282877510 = 5609329388614 := by decide
theorem cert_e1211282877510 : check e1211282877510 [[],[]] .chain = true := by decide
def e1211282877538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211282877538 : Closed e1211282877538 ∧ code e1211282877538 = 5609329388642 := by decide
theorem cert_e1211282877538 : check e1211282877538 [[],[]] .chain = true := by decide
def e1211282877550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211282877550 : Closed e1211282877550 ∧ code e1211282877550 = 5609329388654 := by decide
theorem cert_e1211282877550 : check e1211282877550 [[],[]] .sourceHead = true := by decide
def e1211282877562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211282877562 : Closed e1211282877562 ∧ code e1211282877562 = 5609329388666 := by decide
theorem cert_e1211282877562 : check e1211282877562 [[],[]] .sourceHead = true := by decide
def e1211282877654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211282877654 : Closed e1211282877654 ∧ code e1211282877654 = 5609329388758 := by decide
theorem cert_e1211282877654 : check e1211282877654 [[],[]] .chain = true := by decide
def e1211282877658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211282877658 : Closed e1211282877658 ∧ code e1211282877658 = 5609329388762 := by decide
theorem cert_e1211282877658 : check e1211282877658 [[],[]] .chain = true := by decide
def e1211282877674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211282877674 : Closed e1211282877674 ∧ code e1211282877674 = 5609329388778 := by decide
theorem cert_e1211282877674 : check e1211282877674 [[],[]] .chain = true := by decide
def e1211282877702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211282877702 : Closed e1211282877702 ∧ code e1211282877702 = 5609329388806 := by decide
theorem cert_e1211282877702 : check e1211282877702 [[],[]] .chain = true := by decide
def e1211282877726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211282877726 : Closed e1211282877726 ∧ code e1211282877726 = 5609329388830 := by decide
theorem cert_e1211282877726 : check e1211282877726 [[],[]] .sourceHead = true := by decide
def e1211282877750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211282877750 : Closed e1211282877750 ∧ code e1211282877750 = 5609329388854 := by decide
theorem cert_e1211282877750 : check e1211282877750 [[],[]] .chain = true := by decide
def e1211282877754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211282877754 : Closed e1211282877754 ∧ code e1211282877754 = 5609329388858 := by decide
theorem cert_e1211282877754 : check e1211282877754 [[],[]] .chain = true := by decide
end Blc.Floor42
