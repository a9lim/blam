import Batch060
import ExtraBase
namespace Blc.Floor42.Extra060
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1131193055722 : Term := (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem ex_e1131193055722 : ¬ IsSelfInterpreter e1131193055722 := by
  intro he
  have hp := replay_sound (t := e1131193055722) (u := t_e1131193055722) (ps := [[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))) h
#print axioms ex_e1131193055722
private def t_e1131193056474 : Term := (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem ex_e1131193056474 : ¬ IsSelfInterpreter e1131193056474 := by
  intro he
  have hp := replay_sound (t := e1131193056474) (u := t_e1131193056474) (ps := [[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))) h
#print axioms ex_e1131193056474
private def t_e1131193109750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1131193109750 : ¬ IsSelfInterpreter e1131193109750 := by
  intro he
  have hp := replay_sound (t := e1131193109750) (u := t_e1131193109750) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (so_dead (by decide) (SO.app (SO.var 1) (SO.var 1)))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1131193109750
end Blc.Floor42.Extra060
