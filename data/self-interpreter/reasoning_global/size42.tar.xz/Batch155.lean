import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186640738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186640738 : Closed e1211186640738 ∧ code e1211186640738 = 5609233151842 := by decide
theorem cert_e1211186640738 : check e1211186640738 [[],[]] .smaller = true := by decide
def e1211186640750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 2)))))))
theorem wire_e1211186640750 : Closed e1211186640750 ∧ code e1211186640750 = 5609233151854 := by decide
theorem cert_e1211186640750 : check e1211186640750 [[],[]] .smaller = true := by decide
def e1211186640758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 1)))))))
theorem wire_e1211186640758 : Closed e1211186640758 ∧ code e1211186640758 = 5609233151862 := by decide
theorem cert_e1211186640758 : check e1211186640758 [[],[]] .smaller = true := by decide
def e1211186640762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e1211186640762 : Closed e1211186640762 ∧ code e1211186640762 = 5609233151866 := by decide
theorem cert_e1211186640762 : check e1211186640762 [[],[]] .three = true := by decide
def e1211186640778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186640778 : Closed e1211186640778 ∧ code e1211186640778 = 5609233151882 := by decide
theorem cert_e1211186640778 : check e1211186640778 [[],[]] .three = true := by decide
def e1211186640802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186640802 : Closed e1211186640802 ∧ code e1211186640802 = 5609233151906 := by decide
theorem cert_e1211186640802 : check e1211186640802 [[],[]] .three = true := by decide
def e1211186640814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e1211186640814 : Closed e1211186640814 ∧ code e1211186640814 = 5609233151918 := by decide
theorem cert_e1211186640814 : check e1211186640814 [[],[]] .three = true := by decide
def e1211186640822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e1211186640822 : Closed e1211186640822 ∧ code e1211186640822 = 5609233151926 := by decide
theorem cert_e1211186640822 : check e1211186640822 [[],[]] .three = true := by decide
def e1211186640826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e1211186640826 : Closed e1211186640826 ∧ code e1211186640826 = 5609233151930 := by decide
theorem cert_e1211186640826 : check e1211186640826 [[],[]] .three = true := by decide
def e1211186641078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 1)))))))
theorem wire_e1211186641078 : Closed e1211186641078 ∧ code e1211186641078 = 5609233152182 := by decide
theorem cert_e1211186641078 : check e1211186641078 [[],[]] .smaller = true := by decide
def e1211186641110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e1211186641110 : Closed e1211186641110 ∧ code e1211186641110 = 5609233152214 := by decide
theorem cert_e1211186641110 : check e1211186641110 [[],[]] .smaller = true := by decide
def e1211186641114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e1211186641114 : Closed e1211186641114 ∧ code e1211186641114 = 5609233152218 := by decide
theorem cert_e1211186641114 : check e1211186641114 [[],[]] .smaller = true := by decide
def e1211186641130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e1211186641130 : Closed e1211186641130 ∧ code e1211186641130 = 5609233152234 := by decide
theorem cert_e1211186641130 : check e1211186641130 [[],[]] .smaller = true := by decide
def e1211186641462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186641462 : Closed e1211186641462 ∧ code e1211186641462 = 5609233152566 := by decide
theorem cert_e1211186641462 : check e1211186641462 [[],[]] .smaller = true := by decide
def e1211186641466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186641466 : Closed e1211186641466 ∧ code e1211186641466 = 5609233152570 := by decide
theorem cert_e1211186641466 : check e1211186641466 [[],[]] .smaller = true := by decide
def e1211186641550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186641550 : Closed e1211186641550 ∧ code e1211186641550 = 5609233152654 := by decide
theorem cert_e1211186641550 : check e1211186641550 [[],[]] .smaller = true := by decide
def e1211186641606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186641606 : Closed e1211186641606 ∧ code e1211186641606 = 5609233152710 := by decide
theorem cert_e1211186641606 : check e1211186641606 [[],[]] .smaller = true := by decide
def e1211186641630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e1211186641630 : Closed e1211186641630 ∧ code e1211186641630 = 5609233152734 := by decide
theorem cert_e1211186641630 : check e1211186641630 [[],[]] .three = true := by decide
def e1211186641654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e1211186641654 : Closed e1211186641654 ∧ code e1211186641654 = 5609233152758 := by decide
theorem cert_e1211186641654 : check e1211186641654 [[],[]] .three = true := by decide
def e1211186641686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186641686 : Closed e1211186641686 ∧ code e1211186641686 = 5609233152790 := by decide
theorem cert_e1211186641686 : check e1211186641686 [[],[]] .smaller = true := by decide
def e1211186641690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186641690 : Closed e1211186641690 ∧ code e1211186641690 = 5609233152794 := by decide
theorem cert_e1211186641690 : check e1211186641690 [[],[]] .smaller = true := by decide
def e1211186641734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186641734 : Closed e1211186641734 ∧ code e1211186641734 = 5609233152838 := by decide
theorem cert_e1211186641734 : check e1211186641734 [[],[]] .smaller = true := by decide
def e1211186641758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e1211186641758 : Closed e1211186641758 ∧ code e1211186641758 = 5609233152862 := by decide
theorem cert_e1211186641758 : check e1211186641758 [[],[]] .three = true := by decide
def e1211186641762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186641762 : Closed e1211186641762 ∧ code e1211186641762 = 5609233152866 := by decide
theorem cert_e1211186641762 : check e1211186641762 [[],[]] .smaller = true := by decide
def e1211186641774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e1211186641774 : Closed e1211186641774 ∧ code e1211186641774 = 5609233152878 := by decide
theorem cert_e1211186641774 : check e1211186641774 [[],[]] .smaller = true := by decide
def e1211186641782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e1211186641782 : Closed e1211186641782 ∧ code e1211186641782 = 5609233152886 := by decide
theorem cert_e1211186641782 : check e1211186641782 [[],[]] .smaller = true := by decide
def e1211186641786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e1211186641786 : Closed e1211186641786 ∧ code e1211186641786 = 5609233152890 := by decide
theorem cert_e1211186641786 : check e1211186641786 [[],[]] .three = true := by decide
def e1211186641846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e1211186641846 : Closed e1211186641846 ∧ code e1211186641846 = 5609233152950 := by decide
theorem cert_e1211186641846 : check e1211186641846 [[],[]] .smaller = true := by decide
def e1211186641878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e1211186641878 : Closed e1211186641878 ∧ code e1211186641878 = 5609233152982 := by decide
theorem cert_e1211186641878 : check e1211186641878 [[],[]] .three = true := by decide
def e1211186641882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e1211186641882 : Closed e1211186641882 ∧ code e1211186641882 = 5609233152986 := by decide
theorem cert_e1211186641882 : check e1211186641882 [[],[]] .three = true := by decide
def e1211186642006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e1211186642006 : Closed e1211186642006 ∧ code e1211186642006 = 5609233153110 := by decide
theorem cert_e1211186642006 : check e1211186642006 [[],[]] .three = true := by decide
def e1211186642010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e1211186642010 : Closed e1211186642010 ∧ code e1211186642010 = 5609233153114 := by decide
theorem cert_e1211186642010 : check e1211186642010 [[],[]] .three = true := by decide
def e1211186642198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186642198 : Closed e1211186642198 ∧ code e1211186642198 = 5609233153302 := by decide
theorem cert_e1211186642198 : check e1211186642198 [[],[]] .three = true := by decide
def e1211186642274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186642274 : Closed e1211186642274 ∧ code e1211186642274 = 5609233153378 := by decide
theorem cert_e1211186642274 : check e1211186642274 [[],[]] .three = true := by decide
def e1211186642286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211186642286 : Closed e1211186642286 ∧ code e1211186642286 = 5609233153390 := by decide
theorem cert_e1211186642286 : check e1211186642286 [[],[]] .three = true := by decide
def e1211186642294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211186642294 : Closed e1211186642294 ∧ code e1211186642294 = 5609233153398 := by decide
theorem cert_e1211186642294 : check e1211186642294 [[],[]] .three = true := by decide
def e1211186642314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186642314 : Closed e1211186642314 ∧ code e1211186642314 = 5609233153418 := by decide
theorem cert_e1211186642314 : check e1211186642314 [[],[]] .three = true := by decide
def e1211186642338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186642338 : Closed e1211186642338 ∧ code e1211186642338 = 5609233153442 := by decide
theorem cert_e1211186642338 : check e1211186642338 [[],[]] .three = true := by decide
def e1211186642350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211186642350 : Closed e1211186642350 ∧ code e1211186642350 = 5609233153454 := by decide
theorem cert_e1211186642350 : check e1211186642350 [[],[]] .three = true := by decide
def e1211186642358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 1)))))))
theorem wire_e1211186642358 : Closed e1211186642358 ∧ code e1211186642358 = 5609233153462 := by decide
theorem cert_e1211186642358 : check e1211186642358 [[],[]] .three = true := by decide
def e1211186642362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211186642362 : Closed e1211186642362 ∧ code e1211186642362 = 5609233153466 := by decide
theorem cert_e1211186642362 : check e1211186642362 [[],[]] .three = true := by decide
def e1211186642390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211186642390 : Closed e1211186642390 ∧ code e1211186642390 = 5609233153494 := by decide
theorem cert_e1211186642390 : check e1211186642390 [[],[]] .three = true := by decide
def e1211186642394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211186642394 : Closed e1211186642394 ∧ code e1211186642394 = 5609233153498 := by decide
theorem cert_e1211186642394 : check e1211186642394 [[],[]] .three = true := by decide
def e1211186643934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 3)))))))
theorem wire_e1211186643934 : Closed e1211186643934 ∧ code e1211186643934 = 5609233155038 := by decide
theorem cert_e1211186643934 : check e1211186643934 [[],[]] .three = true := by decide
def e1211186643958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e1211186643958 : Closed e1211186643958 ∧ code e1211186643958 = 5609233155062 := by decide
theorem cert_e1211186643958 : check e1211186643958 [[],[]] .three = true := by decide
def e1211186644718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2)))))))
theorem wire_e1211186644718 : Closed e1211186644718 ∧ code e1211186644718 = 5609233155822 := by decide
theorem cert_e1211186644718 : check e1211186644718 [[],[]] .smaller = true := by decide
def e1211186644726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1)))))))
theorem wire_e1211186644726 : Closed e1211186644726 ∧ code e1211186644726 = 5609233155830 := by decide
theorem cert_e1211186644726 : check e1211186644726 [[],[]] .smaller = true := by decide
def e1211186644910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2)))))))
theorem wire_e1211186644910 : Closed e1211186644910 ∧ code e1211186644910 = 5609233156014 := by decide
theorem cert_e1211186644910 : check e1211186644910 [[],[]] .smaller = true := by decide
def e1211186644950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1)))))))
theorem wire_e1211186644950 : Closed e1211186644950 ∧ code e1211186644950 = 5609233156054 := by decide
theorem cert_e1211186644950 : check e1211186644950 [[],[]] .smaller = true := by decide
def e1211186645470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186645470 : Closed e1211186645470 ∧ code e1211186645470 = 5609233156574 := by decide
theorem cert_e1211186645470 : check e1211186645470 [[],[]] .three = true := by decide
def e1211186645494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186645494 : Closed e1211186645494 ∧ code e1211186645494 = 5609233156598 := by decide
theorem cert_e1211186645494 : check e1211186645494 [[],[]] .three = true := by decide
def e1211186646254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186646254 : Closed e1211186646254 ∧ code e1211186646254 = 5609233157358 := by decide
theorem cert_e1211186646254 : check e1211186646254 [[],[]] .smaller = true := by decide
def e1211186646262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186646262 : Closed e1211186646262 ∧ code e1211186646262 = 5609233157366 := by decide
theorem cert_e1211186646262 : check e1211186646262 [[],[]] .smaller = true := by decide
def e1211186646590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 4))))))))
theorem wire_e1211186646590 : Closed e1211186646590 ∧ code e1211186646590 = 5609233157694 := by decide
theorem cert_e1211186646590 : check e1211186646590 [[],[]] .three = true := by decide
def e1211186646638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186646638 : Closed e1211186646638 ∧ code e1211186646638 = 5609233157742 := by decide
theorem cert_e1211186646638 : check e1211186646638 [[],[]] .smaller = true := by decide
def e1211186646650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186646650 : Closed e1211186646650 ∧ code e1211186646650 = 5609233157754 := by decide
theorem cert_e1211186646650 : check e1211186646650 [[],[]] .smaller = true := by decide
def e1211186646838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186646838 : Closed e1211186646838 ∧ code e1211186646838 = 5609233157942 := by decide
theorem cert_e1211186646838 : check e1211186646838 [[],[]] .smaller = true := by decide
def e1211186646842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186646842 : Closed e1211186646842 ∧ code e1211186646842 = 5609233157946 := by decide
theorem cert_e1211186646842 : check e1211186646842 [[],[]] .smaller = true := by decide
def e1211186646926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e1211186646926 : Closed e1211186646926 ∧ code e1211186646926 = 5609233158030 := by decide
theorem cert_e1211186646926 : check e1211186646926 [[],[]] .three = true := by decide
def e1211186649326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e1211186649326 : Closed e1211186649326 ∧ code e1211186649326 = 5609233160430 := by decide
theorem cert_e1211186649326 : check e1211186649326 [[],[]] .smaller = true := by decide
def e1211186649334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211186649334 : Closed e1211186649334 ∧ code e1211186649334 = 5609233160438 := by decide
theorem cert_e1211186649334 : check e1211186649334 [[],[]] .smaller = true := by decide
def e1211186649886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e1211186649886 : Closed e1211186649886 ∧ code e1211186649886 = 5609233160990 := by decide
theorem cert_e1211186649886 : check e1211186649886 [[],[]] .smaller = true := by decide
def e1211186649998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211186649998 : Closed e1211186649998 ∧ code e1211186649998 = 5609233161102 := by decide
theorem cert_e1211186649998 : check e1211186649998 [[],[]] .smaller = true := by decide
def e1211186650206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e1211186650206 : Closed e1211186650206 ∧ code e1211186650206 = 5609233161310 := by decide
theorem cert_e1211186650206 : check e1211186650206 [[],[]] .three = true := by decide
def e1211186650222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211186650222 : Closed e1211186650222 ∧ code e1211186650222 = 5609233161326 := by decide
theorem cert_e1211186650222 : check e1211186650222 [[],[]] .smaller = true := by decide
def e1211186650234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186650234 : Closed e1211186650234 ∧ code e1211186650234 = 5609233161338 := by decide
theorem cert_e1211186650234 : check e1211186650234 [[],[]] .smaller = true := by decide
def e1211186650398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211186650398 : Closed e1211186650398 ∧ code e1211186650398 = 5609233161502 := by decide
theorem cert_e1211186650398 : check e1211186650398 [[],[]] .smaller = true := by decide
def e1211186650566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186650566 : Closed e1211186650566 ∧ code e1211186650566 = 5609233161670 := by decide
theorem cert_e1211186650566 : check e1211186650566 [[],[]] .smaller = true := by decide
def e1211186650590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e1211186650590 : Closed e1211186650590 ∧ code e1211186650590 = 5609233161694 := by decide
theorem cert_e1211186650590 : check e1211186650590 [[],[]] .three = true := by decide
def e1211186650594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211186650594 : Closed e1211186650594 ∧ code e1211186650594 = 5609233161698 := by decide
theorem cert_e1211186650594 : check e1211186650594 [[],[]] .three = true := by decide
def e1211186650606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e1211186650606 : Closed e1211186650606 ∧ code e1211186650606 = 5609233161710 := by decide
theorem cert_e1211186650606 : check e1211186650606 [[],[]] .three = true := by decide
def e1211186650678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211186650678 : Closed e1211186650678 ∧ code e1211186650678 = 5609233161782 := by decide
theorem cert_e1211186650678 : check e1211186650678 [[],[]] .smaller = true := by decide
def e1211186650682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186650682 : Closed e1211186650682 ∧ code e1211186650682 = 5609233161786 := by decide
theorem cert_e1211186650682 : check e1211186650682 [[],[]] .smaller = true := by decide
def e1211186650766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211186650766 : Closed e1211186650766 ∧ code e1211186650766 = 5609233161870 := by decide
theorem cert_e1211186650766 : check e1211186650766 [[],[]] .smaller = true := by decide
def e1211186650822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186650822 : Closed e1211186650822 ∧ code e1211186650822 = 5609233161926 := by decide
theorem cert_e1211186650822 : check e1211186650822 [[],[]] .smaller = true := by decide
def e1211186650846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e1211186650846 : Closed e1211186650846 ∧ code e1211186650846 = 5609233161950 := by decide
theorem cert_e1211186650846 : check e1211186650846 [[],[]] .three = true := by decide
def e1211186650870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e1211186650870 : Closed e1211186650870 ∧ code e1211186650870 = 5609233161974 := by decide
theorem cert_e1211186650870 : check e1211186650870 [[],[]] .three = true := by decide
def e1211186650902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186650902 : Closed e1211186650902 ∧ code e1211186650902 = 5609233162006 := by decide
theorem cert_e1211186650902 : check e1211186650902 [[],[]] .three = true := by decide
def e1211186650978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186650978 : Closed e1211186650978 ∧ code e1211186650978 = 5609233162082 := by decide
theorem cert_e1211186650978 : check e1211186650978 [[],[]] .three = true := by decide
def e1211186650990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e1211186650990 : Closed e1211186650990 ∧ code e1211186650990 = 5609233162094 := by decide
theorem cert_e1211186650990 : check e1211186650990 [[],[]] .three = true := by decide
def e1211186650998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e1211186650998 : Closed e1211186650998 ∧ code e1211186650998 = 5609233162102 := by decide
theorem cert_e1211186650998 : check e1211186650998 [[],[]] .three = true := by decide
def e1211186652958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211186652958 : Closed e1211186652958 ∧ code e1211186652958 = 5609233164062 := by decide
theorem cert_e1211186652958 : check e1211186652958 [[],[]] .smaller = true := by decide
def e1211186653070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211186653070 : Closed e1211186653070 ∧ code e1211186653070 = 5609233164174 := by decide
theorem cert_e1211186653070 : check e1211186653070 [[],[]] .smaller = true := by decide
def e1211186655358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186655358 : Closed e1211186655358 ∧ code e1211186655358 = 5609233166462 := by decide
theorem cert_e1211186655358 : check e1211186655358 [[],[]] .three = true := by decide
def e1211186655454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186655454 : Closed e1211186655454 ∧ code e1211186655454 = 5609233166558 := by decide
theorem cert_e1211186655454 : check e1211186655454 [[],[]] .smaller = true := by decide
def e1211186655482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186655482 : Closed e1211186655482 ∧ code e1211186655482 = 5609233166586 := by decide
theorem cert_e1211186655482 : check e1211186655482 [[],[]] .smaller = true := by decide
def e1211186656030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186656030 : Closed e1211186656030 ∧ code e1211186656030 = 5609233167134 := by decide
theorem cert_e1211186656030 : check e1211186656030 [[],[]] .smaller = true := by decide
def e1211186656198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186656198 : Closed e1211186656198 ∧ code e1211186656198 = 5609233167302 := by decide
theorem cert_e1211186656198 : check e1211186656198 [[],[]] .smaller = true := by decide
def e1211186656222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186656222 : Closed e1211186656222 ∧ code e1211186656222 = 5609233167326 := by decide
theorem cert_e1211186656222 : check e1211186656222 [[],[]] .three = true := by decide
def e1211186656226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186656226 : Closed e1211186656226 ∧ code e1211186656226 = 5609233167330 := by decide
theorem cert_e1211186656226 : check e1211186656226 [[],[]] .three = true := by decide
def e1211186656238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186656238 : Closed e1211186656238 ∧ code e1211186656238 = 5609233167342 := by decide
theorem cert_e1211186656238 : check e1211186656238 [[],[]] .three = true := by decide
def e1211186657390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186657390 : Closed e1211186657390 ∧ code e1211186657390 = 5609233168494 := by decide
theorem cert_e1211186657390 : check e1211186657390 [[],[]] .smaller = true := by decide
def e1211186657402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186657402 : Closed e1211186657402 ∧ code e1211186657402 = 5609233168506 := by decide
theorem cert_e1211186657402 : check e1211186657402 [[],[]] .smaller = true := by decide
def e1211186657678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186657678 : Closed e1211186657678 ∧ code e1211186657678 = 5609233168782 := by decide
theorem cert_e1211186657678 : check e1211186657678 [[],[]] .smaller = true := by decide
def e1211186657734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186657734 : Closed e1211186657734 ∧ code e1211186657734 = 5609233168838 := by decide
theorem cert_e1211186657734 : check e1211186657734 [[],[]] .smaller = true := by decide
def e1211186657758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186657758 : Closed e1211186657758 ∧ code e1211186657758 = 5609233168862 := by decide
theorem cert_e1211186657758 : check e1211186657758 [[],[]] .three = true := by decide
def e1211186657782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186657782 : Closed e1211186657782 ∧ code e1211186657782 = 5609233168886 := by decide
theorem cert_e1211186657782 : check e1211186657782 [[],[]] .three = true := by decide
def e1211186658334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186658334 : Closed e1211186658334 ∧ code e1211186658334 = 5609233169438 := by decide
theorem cert_e1211186658334 : check e1211186658334 [[],[]] .three = true := by decide
def e1211186658530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186658530 : Closed e1211186658530 ∧ code e1211186658530 = 5609233169634 := by decide
theorem cert_e1211186658530 : check e1211186658530 [[],[]] .three = true := by decide
def e1211186658542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186658542 : Closed e1211186658542 ∧ code e1211186658542 = 5609233169646 := by decide
theorem cert_e1211186658542 : check e1211186658542 [[],[]] .three = true := by decide
def e1211186658550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186658550 : Closed e1211186658550 ∧ code e1211186658550 = 5609233169654 := by decide
theorem cert_e1211186658550 : check e1211186658550 [[],[]] .three = true := by decide
def e1211186659806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 3)))))))
theorem wire_e1211186659806 : Closed e1211186659806 ∧ code e1211186659806 = 5609233170910 := by decide
theorem cert_e1211186659806 : check e1211186659806 [[],[]] .three = true := by decide
def e1211186659822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211186659822 : Closed e1211186659822 ∧ code e1211186659822 = 5609233170926 := by decide
theorem cert_e1211186659822 : check e1211186659822 [[],[]] .smaller = true := by decide
def e1211186659830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 1)))))))
theorem wire_e1211186659830 : Closed e1211186659830 ∧ code e1211186659830 = 5609233170934 := by decide
theorem cert_e1211186659830 : check e1211186659830 [[],[]] .smaller = true := by decide
def e1211186659834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211186659834 : Closed e1211186659834 ∧ code e1211186659834 = 5609233170938 := by decide
theorem cert_e1211186659834 : check e1211186659834 [[],[]] .three = true := by decide
def e1211186660190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e1211186660190 : Closed e1211186660190 ∧ code e1211186660190 = 5609233171294 := by decide
theorem cert_e1211186660190 : check e1211186660190 [[],[]] .three = true := by decide
def e1211186660206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e1211186660206 : Closed e1211186660206 ∧ code e1211186660206 = 5609233171310 := by decide
theorem cert_e1211186660206 : check e1211186660206 [[],[]] .smaller = true := by decide
def e1211186660218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e1211186660218 : Closed e1211186660218 ∧ code e1211186660218 = 5609233171322 := by decide
theorem cert_e1211186660218 : check e1211186660218 [[],[]] .smaller = true := by decide
def e1211186660270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e1211186660270 : Closed e1211186660270 ∧ code e1211186660270 = 5609233171374 := by decide
theorem cert_e1211186660270 : check e1211186660270 [[],[]] .smaller = true := by decide
def e1211186660330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e1211186660330 : Closed e1211186660330 ∧ code e1211186660330 = 5609233171434 := by decide
theorem cert_e1211186660330 : check e1211186660330 [[],[]] .smaller = true := by decide
def e1211186660574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186660574 : Closed e1211186660574 ∧ code e1211186660574 = 5609233171678 := by decide
theorem cert_e1211186660574 : check e1211186660574 [[],[]] .three = true := by decide
def e1211186660590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186660590 : Closed e1211186660590 ∧ code e1211186660590 = 5609233171694 := by decide
theorem cert_e1211186660590 : check e1211186660590 [[],[]] .smaller = true := by decide
def e1211186660598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186660598 : Closed e1211186660598 ∧ code e1211186660598 = 5609233171702 := by decide
theorem cert_e1211186660598 : check e1211186660598 [[],[]] .smaller = true := by decide
def e1211186660602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186660602 : Closed e1211186660602 ∧ code e1211186660602 = 5609233171706 := by decide
theorem cert_e1211186660602 : check e1211186660602 [[],[]] .three = true := by decide
def e1211186660926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 4))))))))
theorem wire_e1211186660926 : Closed e1211186660926 ∧ code e1211186660926 = 5609233172030 := by decide
theorem cert_e1211186660926 : check e1211186660926 [[],[]] .three = true := by decide
def e1211186660974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186660974 : Closed e1211186660974 ∧ code e1211186660974 = 5609233172078 := by decide
theorem cert_e1211186660974 : check e1211186660974 [[],[]] .smaller = true := by decide
def e1211186660986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186660986 : Closed e1211186660986 ∧ code e1211186660986 = 5609233172090 := by decide
theorem cert_e1211186660986 : check e1211186660986 [[],[]] .smaller = true := by decide
def e1211186661150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211186661150 : Closed e1211186661150 ∧ code e1211186661150 = 5609233172254 := by decide
theorem cert_e1211186661150 : check e1211186661150 [[],[]] .smaller = true := by decide
def e1211186661262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 2))))))))
theorem wire_e1211186661262 : Closed e1211186661262 ∧ code e1211186661262 = 5609233172366 := by decide
theorem cert_e1211186661262 : check e1211186661262 [[],[]] .smaller = true := by decide
def e1211186661274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186661274 : Closed e1211186661274 ∧ code e1211186661274 = 5609233172378 := by decide
theorem cert_e1211186661274 : check e1211186661274 [[],[]] .smaller = true := by decide
def e1211186661318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211186661318 : Closed e1211186661318 ∧ code e1211186661318 = 5609233172422 := by decide
theorem cert_e1211186661318 : check e1211186661318 [[],[]] .three = true := by decide
def e1211186661342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 3)))))))
theorem wire_e1211186661342 : Closed e1211186661342 ∧ code e1211186661342 = 5609233172446 := by decide
theorem cert_e1211186661342 : check e1211186661342 [[],[]] .three = true := by decide
def e1211186662494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e1211186662494 : Closed e1211186662494 ∧ code e1211186662494 = 5609233173598 := by decide
theorem cert_e1211186662494 : check e1211186662494 [[],[]] .three = true := by decide
def e1211186662510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211186662510 : Closed e1211186662510 ∧ code e1211186662510 = 5609233173614 := by decide
theorem cert_e1211186662510 : check e1211186662510 [[],[]] .smaller = true := by decide
def e1211186662522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186662522 : Closed e1211186662522 ∧ code e1211186662522 = 5609233173626 := by decide
theorem cert_e1211186662522 : check e1211186662522 [[],[]] .smaller = true := by decide
def e1211186662686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211186662686 : Closed e1211186662686 ∧ code e1211186662686 = 5609233173790 := by decide
theorem cert_e1211186662686 : check e1211186662686 [[],[]] .smaller = true := by decide
def e1211186662854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186662854 : Closed e1211186662854 ∧ code e1211186662854 = 5609233173958 := by decide
theorem cert_e1211186662854 : check e1211186662854 [[],[]] .smaller = true := by decide
def e1211186662878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e1211186662878 : Closed e1211186662878 ∧ code e1211186662878 = 5609233173982 := by decide
theorem cert_e1211186662878 : check e1211186662878 [[],[]] .three = true := by decide
def e1211186662882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211186662882 : Closed e1211186662882 ∧ code e1211186662882 = 5609233173986 := by decide
theorem cert_e1211186662882 : check e1211186662882 [[],[]] .three = true := by decide
def e1211186662894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e1211186662894 : Closed e1211186662894 ∧ code e1211186662894 = 5609233173998 := by decide
theorem cert_e1211186662894 : check e1211186662894 [[],[]] .three = true := by decide
def e1211186662958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211186662958 : Closed e1211186662958 ∧ code e1211186662958 = 5609233174062 := by decide
theorem cert_e1211186662958 : check e1211186662958 [[],[]] .smaller = true := by decide
def e1211186663134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e1211186663134 : Closed e1211186663134 ∧ code e1211186663134 = 5609233174238 := by decide
theorem cert_e1211186663134 : check e1211186663134 [[],[]] .three = true := by decide
def e1211186663138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211186663138 : Closed e1211186663138 ∧ code e1211186663138 = 5609233174242 := by decide
theorem cert_e1211186663138 : check e1211186663138 [[],[]] .smaller = true := by decide
def e1211186663150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211186663150 : Closed e1211186663150 ∧ code e1211186663150 = 5609233174254 := by decide
theorem cert_e1211186663150 : check e1211186663150 [[],[]] .smaller = true := by decide
def e1211186663158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211186663158 : Closed e1211186663158 ∧ code e1211186663158 = 5609233174262 := by decide
theorem cert_e1211186663158 : check e1211186663158 [[],[]] .three = true := by decide
def e1211186663190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186663190 : Closed e1211186663190 ∧ code e1211186663190 = 5609233174294 := by decide
theorem cert_e1211186663190 : check e1211186663190 [[],[]] .smaller = true := by decide
def e1211186663194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186663194 : Closed e1211186663194 ∧ code e1211186663194 = 5609233174298 := by decide
theorem cert_e1211186663194 : check e1211186663194 [[],[]] .smaller = true := by decide
def e1211186663238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186663238 : Closed e1211186663238 ∧ code e1211186663238 = 5609233174342 := by decide
theorem cert_e1211186663238 : check e1211186663238 [[],[]] .smaller = true := by decide
def e1211186663262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e1211186663262 : Closed e1211186663262 ∧ code e1211186663262 = 5609233174366 := by decide
theorem cert_e1211186663262 : check e1211186663262 [[],[]] .three = true := by decide
def e1211186663266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186663266 : Closed e1211186663266 ∧ code e1211186663266 = 5609233174370 := by decide
theorem cert_e1211186663266 : check e1211186663266 [[],[]] .smaller = true := by decide
def e1211186663278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211186663278 : Closed e1211186663278 ∧ code e1211186663278 = 5609233174382 := by decide
theorem cert_e1211186663278 : check e1211186663278 [[],[]] .smaller = true := by decide
def e1211186663286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 1)))))))
theorem wire_e1211186663286 : Closed e1211186663286 ∧ code e1211186663286 = 5609233174390 := by decide
theorem cert_e1211186663286 : check e1211186663286 [[],[]] .smaller = true := by decide
def e1211186663290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211186663290 : Closed e1211186663290 ∧ code e1211186663290 = 5609233174394 := by decide
theorem cert_e1211186663290 : check e1211186663290 [[],[]] .three = true := by decide
def e1211186663306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186663306 : Closed e1211186663306 ∧ code e1211186663306 = 5609233174410 := by decide
theorem cert_e1211186663306 : check e1211186663306 [[],[]] .three = true := by decide
def e1211186663330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186663330 : Closed e1211186663330 ∧ code e1211186663330 = 5609233174434 := by decide
theorem cert_e1211186663330 : check e1211186663330 [[],[]] .three = true := by decide
def e1211186663342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e1211186663342 : Closed e1211186663342 ∧ code e1211186663342 = 5609233174446 := by decide
theorem cert_e1211186663342 : check e1211186663342 [[],[]] .three = true := by decide
def e1211186663350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211186663350 : Closed e1211186663350 ∧ code e1211186663350 = 5609233174454 := by decide
theorem cert_e1211186663350 : check e1211186663350 [[],[]] .three = true := by decide
def e1211186663354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211186663354 : Closed e1211186663354 ∧ code e1211186663354 = 5609233174458 := by decide
theorem cert_e1211186663354 : check e1211186663354 [[],[]] .three = true := by decide
def e1211186663550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186663550 : Closed e1211186663550 ∧ code e1211186663550 = 5609233174654 := by decide
theorem cert_e1211186663550 : check e1211186663550 [[],[]] .three = true := by decide
def e1211186663646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186663646 : Closed e1211186663646 ∧ code e1211186663646 = 5609233174750 := by decide
theorem cert_e1211186663646 : check e1211186663646 [[],[]] .smaller = true := by decide
def e1211186663674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186663674 : Closed e1211186663674 ∧ code e1211186663674 = 5609233174778 := by decide
theorem cert_e1211186663674 : check e1211186663674 [[],[]] .smaller = true := by decide
def e1211186664222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186664222 : Closed e1211186664222 ∧ code e1211186664222 = 5609233175326 := by decide
theorem cert_e1211186664222 : check e1211186664222 [[],[]] .smaller = true := by decide
def e1211186664390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186664390 : Closed e1211186664390 ∧ code e1211186664390 = 5609233175494 := by decide
theorem cert_e1211186664390 : check e1211186664390 [[],[]] .smaller = true := by decide
def e1211186664414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186664414 : Closed e1211186664414 ∧ code e1211186664414 = 5609233175518 := by decide
theorem cert_e1211186664414 : check e1211186664414 [[],[]] .three = true := by decide
def e1211186664418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186664418 : Closed e1211186664418 ∧ code e1211186664418 = 5609233175522 := by decide
theorem cert_e1211186664418 : check e1211186664418 [[],[]] .three = true := by decide
def e1211186664430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186664430 : Closed e1211186664430 ∧ code e1211186664430 = 5609233175534 := by decide
theorem cert_e1211186664430 : check e1211186664430 [[],[]] .three = true := by decide
def e1211186665534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186665534 : Closed e1211186665534 ∧ code e1211186665534 = 5609233176638 := by decide
theorem cert_e1211186665534 : check e1211186665534 [[],[]] .smaller = true := by decide
def e1211186665950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186665950 : Closed e1211186665950 ∧ code e1211186665950 = 5609233177054 := by decide
theorem cert_e1211186665950 : check e1211186665950 [[],[]] .three = true := by decide
def e1211186665954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186665954 : Closed e1211186665954 ∧ code e1211186665954 = 5609233177058 := by decide
theorem cert_e1211186665954 : check e1211186665954 [[],[]] .smaller = true := by decide
def e1211186665966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186665966 : Closed e1211186665966 ∧ code e1211186665966 = 5609233177070 := by decide
theorem cert_e1211186665966 : check e1211186665966 [[],[]] .smaller = true := by decide
end Blc.Floor42
