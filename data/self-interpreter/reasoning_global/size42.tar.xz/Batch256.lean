import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211583548662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211583548662 : Closed e1211583548662 ∧ code e1211583548662 = 5609630059766 := by decide
theorem cert_e1211583548662 : check e1211583548662 [[],[],[],[]] .smaller = true := by decide
def e1211583548666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211583548666 : Closed e1211583548666 ∧ code e1211583548666 = 5609630059770 := by decide
theorem cert_e1211583548666 : check e1211583548666 [[],[],[],[]] .three = true := by decide
def e1211583549038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211583549038 : Closed e1211583549038 ∧ code e1211583549038 = 5609630060142 := by decide
theorem cert_e1211583549038 : check e1211583549038 [[],[],[],[]] .smaller = true := by decide
def e1211583549050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211583549050 : Closed e1211583549050 ∧ code e1211583549050 = 5609630060154 := by decide
theorem cert_e1211583549050 : check e1211583549050 [[],[],[],[]] .smaller = true := by decide
def e1211583549238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583549238 : Closed e1211583549238 ∧ code e1211583549238 = 5609630060342 := by decide
theorem cert_e1211583549238 : check e1211583549238 [[],[],[],[]] .smaller = true := by decide
def e1211583549242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583549242 : Closed e1211583549242 ∧ code e1211583549242 = 5609630060346 := by decide
theorem cert_e1211583549242 : check e1211583549242 [[],[],[],[]] .smaller = true := by decide
def e1211583549338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211583549338 : Closed e1211583549338 ∧ code e1211583549338 = 5609630060442 := by decide
theorem cert_e1211583549338 : check e1211583549338 [[],[],[],[]] .three = true := by decide
def e1211583549374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 4))))))))))
theorem wire_e1211583549374 : Closed e1211583549374 ∧ code e1211583549374 = 5609630060478 := by decide
theorem cert_e1211583549374 : check e1211583549374 [[],[],[],[]] .three = true := by decide
def e1211583549382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e1211583549382 : Closed e1211583549382 ∧ code e1211583549382 = 5609630060486 := by decide
theorem cert_e1211583549382 : check e1211583549382 [[],[],[],[]] .three = true := by decide
def e1211583549406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 3))))))))))
theorem wire_e1211583549406 : Closed e1211583549406 ∧ code e1211583549406 = 5609630060510 := by decide
theorem cert_e1211583549406 : check e1211583549406 [[],[],[],[]] .three = true := by decide
def e1211583554998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211583554998 : Closed e1211583554998 ∧ code e1211583554998 = 5609630066102 := by decide
theorem cert_e1211583554998 : check e1211583554998 [[],[],[],[]] .smaller = true := by decide
def e1211583555030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211583555030 : Closed e1211583555030 ∧ code e1211583555030 = 5609630066134 := by decide
theorem cert_e1211583555030 : check e1211583555030 [[],[],[],[]] .smaller = true := by decide
def e1211583555034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211583555034 : Closed e1211583555034 ∧ code e1211583555034 = 5609630066138 := by decide
theorem cert_e1211583555034 : check e1211583555034 [[],[],[],[]] .smaller = true := by decide
def e1211583555190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211583555190 : Closed e1211583555190 ∧ code e1211583555190 = 5609630066294 := by decide
theorem cert_e1211583555190 : check e1211583555190 [[],[],[],[]] .smaller = true := by decide
def e1211583555382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583555382 : Closed e1211583555382 ∧ code e1211583555382 = 5609630066486 := by decide
theorem cert_e1211583555382 : check e1211583555382 [[],[],[],[]] .smaller = true := by decide
def e1211583555386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583555386 : Closed e1211583555386 ∧ code e1211583555386 = 5609630066490 := by decide
theorem cert_e1211583555386 : check e1211583555386 [[],[],[],[]] .smaller = true := by decide
def e1211583558358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211583558358 : Closed e1211583558358 ∧ code e1211583558358 = 5609630069462 := by decide
theorem cert_e1211583558358 : check e1211583558358 [[],[],[],[]] .three = true := by decide
def e1211583558362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211583558362 : Closed e1211583558362 ∧ code e1211583558362 = 5609630069466 := by decide
theorem cert_e1211583558362 : check e1211583558362 [[],[],[],[]] .three = true := by decide
def e1211583558378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211583558378 : Closed e1211583558378 ∧ code e1211583558378 = 5609630069482 := by decide
theorem cert_e1211583558378 : check e1211583558378 [[],[],[],[]] .three = true := by decide
def e1211583558454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583558454 : Closed e1211583558454 ∧ code e1211583558454 = 5609630069558 := by decide
theorem cert_e1211583558454 : check e1211583558454 [[],[],[],[]] .three = true := by decide
def e1211583558458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583558458 : Closed e1211583558458 ∧ code e1211583558458 = 5609630069562 := by decide
theorem cert_e1211583558458 : check e1211583558458 [[],[],[],[]] .three = true := by decide
def e1211583558554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211583558554 : Closed e1211583558554 ∧ code e1211583558554 = 5609630069658 := by decide
theorem cert_e1211583558554 : check e1211583558554 [[],[],[],[]] .three = true := by decide
def e1211583558590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211583558590 : Closed e1211583558590 ∧ code e1211583558590 = 5609630069694 := by decide
theorem cert_e1211583558590 : check e1211583558590 [[],[],[],[]] .three = true := by decide
def e1211583558646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211583558646 : Closed e1211583558646 ∧ code e1211583558646 = 5609630069750 := by decide
theorem cert_e1211583558646 : check e1211583558646 [[],[],[],[]] .three = true := by decide
def e1211583560078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211583560078 : Closed e1211583560078 ∧ code e1211583560078 = 5609630071182 := by decide
theorem cert_e1211583560078 : check e1211583560078 [[],[],[],[]] .three = true := by decide
def e1211583560134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211583560134 : Closed e1211583560134 ∧ code e1211583560134 = 5609630071238 := by decide
theorem cert_e1211583560134 : check e1211583560134 [[],[],[],[]] .three = true := by decide
def e1211583560158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211583560158 : Closed e1211583560158 ∧ code e1211583560158 = 5609630071262 := by decide
theorem cert_e1211583560158 : check e1211583560158 [[],[],[],[]] .three = true := by decide
def e1211583560182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211583560182 : Closed e1211583560182 ∧ code e1211583560182 = 5609630071286 := by decide
theorem cert_e1211583560182 : check e1211583560182 [[],[],[],[]] .three = true := by decide
def e1211583783646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e1211583783646 : Closed e1211583783646 ∧ code e1211583783646 = 5609630294750 := by decide
theorem cert_e1211583783646 : check e1211583783646 [[],[],[],[]] .chain = true := by decide
def e1211583783670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e1211583783670 : Closed e1211583783670 ∧ code e1211583783670 = 5609630294774 := by decide
theorem cert_e1211583783670 : check e1211583783670 [[],[],[],[]] .chain = true := by decide
def e1211583783790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211583783790 : Closed e1211583783790 ∧ code e1211583783790 = 5609630294894 := by decide
theorem cert_e1211583783790 : check e1211583783790 [[],[],[],[]] .chain = true := by decide
def e1211583783798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211583783798 : Closed e1211583783798 ∧ code e1211583783798 = 5609630294902 := by decide
theorem cert_e1211583783798 : check e1211583783798 [[],[],[],[]] .chain = true := by decide
def e1211583783854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e1211583783854 : Closed e1211583783854 ∧ code e1211583783854 = 5609630294958 := by decide
theorem cert_e1211583783854 : check e1211583783854 [[],[],[],[]] .chain = true := by decide
def e1211583783866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e1211583783866 : Closed e1211583783866 ∧ code e1211583783866 = 5609630294970 := by decide
theorem cert_e1211583783866 : check e1211583783866 [[],[],[],[]] .chain = true := by decide
def e1211583783894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211583783894 : Closed e1211583783894 ∧ code e1211583783894 = 5609630294998 := by decide
theorem cert_e1211583783894 : check e1211583783894 [[],[],[],[]] .chain = true := by decide
def e1211583783898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211583783898 : Closed e1211583783898 ∧ code e1211583783898 = 5609630295002 := by decide
theorem cert_e1211583783898 : check e1211583783898 [[],[],[],[]] .chain = true := by decide
def e1211583785198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211583785198 : Closed e1211583785198 ∧ code e1211583785198 = 5609630296302 := by decide
theorem cert_e1211583785198 : check e1211583785198 [[],[],[],[]] .chain = true := by decide
def e1211583785206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211583785206 : Closed e1211583785206 ∧ code e1211583785206 = 5609630296310 := by decide
theorem cert_e1211583785206 : check e1211583785206 [[],[],[],[]] .chain = true := by decide
def e1211583785758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211583785758 : Closed e1211583785758 ∧ code e1211583785758 = 5609630296862 := by decide
theorem cert_e1211583785758 : check e1211583785758 [[],[],[],[]] .chain = true := by decide
def e1211583785870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211583785870 : Closed e1211583785870 ∧ code e1211583785870 = 5609630296974 := by decide
theorem cert_e1211583785870 : check e1211583785870 [[],[],[],[]] .chain = true := by decide
def e1211583786078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211583786078 : Closed e1211583786078 ∧ code e1211583786078 = 5609630297182 := by decide
theorem cert_e1211583786078 : check e1211583786078 [[],[],[],[]] .chain = true := by decide
def e1211583786094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211583786094 : Closed e1211583786094 ∧ code e1211583786094 = 5609630297198 := by decide
theorem cert_e1211583786094 : check e1211583786094 [[],[],[],[]] .chain = true := by decide
def e1211583786106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211583786106 : Closed e1211583786106 ∧ code e1211583786106 = 5609630297210 := by decide
theorem cert_e1211583786106 : check e1211583786106 [[],[],[],[]] .chain = true := by decide
def e1211583786270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211583786270 : Closed e1211583786270 ∧ code e1211583786270 = 5609630297374 := by decide
theorem cert_e1211583786270 : check e1211583786270 [[],[],[],[]] .chain = true := by decide
def e1211583786438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211583786438 : Closed e1211583786438 ∧ code e1211583786438 = 5609630297542 := by decide
theorem cert_e1211583786438 : check e1211583786438 [[],[],[],[]] .chain = true := by decide
def e1211583786462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e1211583786462 : Closed e1211583786462 ∧ code e1211583786462 = 5609630297566 := by decide
theorem cert_e1211583786462 : check e1211583786462 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211583786466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211583786466 : Closed e1211583786466 ∧ code e1211583786466 = 5609630297570 := by decide
theorem cert_e1211583786466 : check e1211583786466 [[],[],[],[]] .chain = true := by decide
def e1211583786478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e1211583786478 : Closed e1211583786478 ∧ code e1211583786478 = 5609630297582 := by decide
theorem cert_e1211583786478 : check e1211583786478 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211583786550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211583786550 : Closed e1211583786550 ∧ code e1211583786550 = 5609630297654 := by decide
theorem cert_e1211583786550 : check e1211583786550 [[],[],[],[]] .chain = true := by decide
def e1211583786554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211583786554 : Closed e1211583786554 ∧ code e1211583786554 = 5609630297658 := by decide
theorem cert_e1211583786554 : check e1211583786554 [[],[],[],[]] .chain = true := by decide
def e1211583786638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211583786638 : Closed e1211583786638 ∧ code e1211583786638 = 5609630297742 := by decide
theorem cert_e1211583786638 : check e1211583786638 [[],[],[],[]] .chain = true := by decide
def e1211583786694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211583786694 : Closed e1211583786694 ∧ code e1211583786694 = 5609630297798 := by decide
theorem cert_e1211583786694 : check e1211583786694 [[],[],[],[]] .chain = true := by decide
def e1211583786718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e1211583786718 : Closed e1211583786718 ∧ code e1211583786718 = 5609630297822 := by decide
theorem cert_e1211583786718 : check e1211583786718 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211583786742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e1211583786742 : Closed e1211583786742 ∧ code e1211583786742 = 5609630297846 := by decide
theorem cert_e1211583786742 : check e1211583786742 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583786774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211583786774 : Closed e1211583786774 ∧ code e1211583786774 = 5609630297878 := by decide
theorem cert_e1211583786774 : check e1211583786774 [[],[],[],[]] .chain = true := by decide
def e1211583786850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211583786850 : Closed e1211583786850 ∧ code e1211583786850 = 5609630297954 := by decide
theorem cert_e1211583786850 : check e1211583786850 [[],[],[],[]] .chain = true := by decide
def e1211583786862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e1211583786862 : Closed e1211583786862 ∧ code e1211583786862 = 5609630297966 := by decide
theorem cert_e1211583786862 : check e1211583786862 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583786870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e1211583786870 : Closed e1211583786870 ∧ code e1211583786870 = 5609630297974 := by decide
theorem cert_e1211583786870 : check e1211583786870 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583787358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211583787358 : Closed e1211583787358 ∧ code e1211583787358 = 5609630298462 := by decide
theorem cert_e1211583787358 : check e1211583787358 [[],[],[],[]] .chain = true := by decide
def e1211583787386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211583787386 : Closed e1211583787386 ∧ code e1211583787386 = 5609630298490 := by decide
theorem cert_e1211583787386 : check e1211583787386 [[],[],[],[]] .chain = true := by decide
def e1211583787438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211583787438 : Closed e1211583787438 ∧ code e1211583787438 = 5609630298542 := by decide
theorem cert_e1211583787438 : check e1211583787438 [[],[],[],[]] .chain = true := by decide
def e1211583787450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211583787450 : Closed e1211583787450 ∧ code e1211583787450 = 5609630298554 := by decide
theorem cert_e1211583787450 : check e1211583787450 [[],[],[],[]] .chain = true := by decide
def e1211583787498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211583787498 : Closed e1211583787498 ∧ code e1211583787498 = 5609630298602 := by decide
theorem cert_e1211583787498 : check e1211583787498 [[],[],[],[]] .chain = true := by decide
def e1211583788126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211583788126 : Closed e1211583788126 ∧ code e1211583788126 = 5609630299230 := by decide
theorem cert_e1211583788126 : check e1211583788126 [[],[],[],[]] .chain = true := by decide
def e1211583788142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211583788142 : Closed e1211583788142 ∧ code e1211583788142 = 5609630299246 := by decide
theorem cert_e1211583788142 : check e1211583788142 [[],[],[],[]] .chain = true := by decide
def e1211583788154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211583788154 : Closed e1211583788154 ∧ code e1211583788154 = 5609630299258 := by decide
theorem cert_e1211583788154 : check e1211583788154 [[],[],[],[]] .chain = true := by decide
def e1211583788318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211583788318 : Closed e1211583788318 ∧ code e1211583788318 = 5609630299422 := by decide
theorem cert_e1211583788318 : check e1211583788318 [[],[],[],[]] .chain = true := by decide
def e1211583788486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211583788486 : Closed e1211583788486 ∧ code e1211583788486 = 5609630299590 := by decide
theorem cert_e1211583788486 : check e1211583788486 [[],[],[],[]] .chain = true := by decide
def e1211583788510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211583788510 : Closed e1211583788510 ∧ code e1211583788510 = 5609630299614 := by decide
theorem cert_e1211583788510 : check e1211583788510 [[],[],[],[]] .sourceHead = true := by decide
def e1211583788514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211583788514 : Closed e1211583788514 ∧ code e1211583788514 = 5609630299618 := by decide
theorem cert_e1211583788514 : check e1211583788514 [[],[],[],[]] .chain = true := by decide
def e1211583788526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211583788526 : Closed e1211583788526 ∧ code e1211583788526 = 5609630299630 := by decide
theorem cert_e1211583788526 : check e1211583788526 [[],[],[],[]] .sourceHead = true := by decide
def e1211583788826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211583788826 : Closed e1211583788826 ∧ code e1211583788826 = 5609630299930 := by decide
theorem cert_e1211583788826 : check e1211583788826 [[],[],[],[]] .chain = true := by decide
def e1211583788870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211583788870 : Closed e1211583788870 ∧ code e1211583788870 = 5609630299974 := by decide
theorem cert_e1211583788870 : check e1211583788870 [[],[],[],[]] .chain = true := by decide
def e1211583788894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211583788894 : Closed e1211583788894 ∧ code e1211583788894 = 5609630299998 := by decide
theorem cert_e1211583788894 : check e1211583788894 [[],[],[],[]] .sourceHead = true := by decide
def e1211583788922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211583788922 : Closed e1211583788922 ∧ code e1211583788922 = 5609630300026 := by decide
theorem cert_e1211583788922 : check e1211583788922 [[],[],[],[]] .sourceHead = true := by decide
def e1211583788938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211583788938 : Closed e1211583788938 ∧ code e1211583788938 = 5609630300042 := by decide
theorem cert_e1211583788938 : check e1211583788938 [[],[],[],[]] .chain = true := by decide
def e1211583788962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211583788962 : Closed e1211583788962 ∧ code e1211583788962 = 5609630300066 := by decide
theorem cert_e1211583788962 : check e1211583788962 [[],[],[],[]] .chain = true := by decide
def e1211583788974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211583788974 : Closed e1211583788974 ∧ code e1211583788974 = 5609630300078 := by decide
theorem cert_e1211583788974 : check e1211583788974 [[],[],[],[]] .sourceHead = true := by decide
def e1211583788986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211583788986 : Closed e1211583788986 ∧ code e1211583788986 = 5609630300090 := by decide
theorem cert_e1211583788986 : check e1211583788986 [[],[],[],[]] .sourceHead = true := by decide
def e1211583789270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211583789270 : Closed e1211583789270 ∧ code e1211583789270 = 5609630300374 := by decide
theorem cert_e1211583789270 : check e1211583789270 [[],[],[],[]] .chain = true := by decide
def e1211583789274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211583789274 : Closed e1211583789274 ∧ code e1211583789274 = 5609630300378 := by decide
theorem cert_e1211583789274 : check e1211583789274 [[],[],[],[]] .chain = true := by decide
def e1211583789290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211583789290 : Closed e1211583789290 ∧ code e1211583789290 = 5609630300394 := by decide
theorem cert_e1211583789290 : check e1211583789290 [[],[],[],[]] .chain = true := by decide
def e1211583789622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211583789622 : Closed e1211583789622 ∧ code e1211583789622 = 5609630300726 := by decide
theorem cert_e1211583789622 : check e1211583789622 [[],[],[],[]] .chain = true := by decide
def e1211583789626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211583789626 : Closed e1211583789626 ∧ code e1211583789626 = 5609630300730 := by decide
theorem cert_e1211583789626 : check e1211583789626 [[],[],[],[]] .chain = true := by decide
def e1211583789710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211583789710 : Closed e1211583789710 ∧ code e1211583789710 = 5609630300814 := by decide
theorem cert_e1211583789710 : check e1211583789710 [[],[],[],[]] .chain = true := by decide
def e1211583789766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211583789766 : Closed e1211583789766 ∧ code e1211583789766 = 5609630300870 := by decide
theorem cert_e1211583789766 : check e1211583789766 [[],[],[],[]] .chain = true := by decide
def e1211583789790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211583789790 : Closed e1211583789790 ∧ code e1211583789790 = 5609630300894 := by decide
theorem cert_e1211583789790 : check e1211583789790 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583789814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211583789814 : Closed e1211583789814 ∧ code e1211583789814 = 5609630300918 := by decide
theorem cert_e1211583789814 : check e1211583789814 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211583789850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211583789850 : Closed e1211583789850 ∧ code e1211583789850 = 5609630300954 := by decide
theorem cert_e1211583789850 : check e1211583789850 [[],[],[],[]] .chain = true := by decide
def e1211583789894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211583789894 : Closed e1211583789894 ∧ code e1211583789894 = 5609630300998 := by decide
theorem cert_e1211583789894 : check e1211583789894 [[],[],[],[]] .chain = true := by decide
def e1211583789918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211583789918 : Closed e1211583789918 ∧ code e1211583789918 = 5609630301022 := by decide
theorem cert_e1211583789918 : check e1211583789918 [[],[],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211583789946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211583789946 : Closed e1211583789946 ∧ code e1211583789946 = 5609630301050 := by decide
theorem cert_e1211583789946 : check e1211583789946 [[],[],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211583790038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211583790038 : Closed e1211583790038 ∧ code e1211583790038 = 5609630301142 := by decide
private def t_e1211583790038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem cert_e1211583790038 : ¬ IsSelfInterpreter e1211583790038 :=
  wSource (t := t_e1211583790038) (replay_sound (ps := []) (t := e1211583790038) (by decide)) (by decide)
def e1211583790042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211583790042 : Closed e1211583790042 ∧ code e1211583790042 = 5609630301146 := by decide
private def t_e1211583790042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem cert_e1211583790042 : ¬ IsSelfInterpreter e1211583790042 :=
  wSource (t := t_e1211583790042) (replay_sound (ps := []) (t := e1211583790042) (by decide)) (by decide)
def e1211583790166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211583790166 : Closed e1211583790166 ∧ code e1211583790166 = 5609630301270 := by decide
theorem cert_e1211583790166 : check e1211583790166 [[],[],[],[]] .chain = true := by decide
def e1211583790170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211583790170 : Closed e1211583790170 ∧ code e1211583790170 = 5609630301274 := by decide
theorem cert_e1211583790170 : check e1211583790170 [[],[],[],[]] .chain = true := by decide
def e1211583790358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211583790358 : Closed e1211583790358 ∧ code e1211583790358 = 5609630301462 := by decide
theorem cert_e1211583790358 : check e1211583790358 [[],[],[],[]] .chain = true := by decide
def e1211583790434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211583790434 : Closed e1211583790434 ∧ code e1211583790434 = 5609630301538 := by decide
theorem cert_e1211583790434 : check e1211583790434 [[],[],[],[]] .chain = true := by decide
def e1211583790446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211583790446 : Closed e1211583790446 ∧ code e1211583790446 = 5609630301550 := by decide
theorem cert_e1211583790446 : check e1211583790446 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211583790454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211583790454 : Closed e1211583790454 ∧ code e1211583790454 = 5609630301558 := by decide
theorem cert_e1211583790454 : check e1211583790454 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211583790474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211583790474 : Closed e1211583790474 ∧ code e1211583790474 = 5609630301578 := by decide
theorem cert_e1211583790474 : check e1211583790474 [[],[],[],[]] .chain = true := by decide
def e1211583790498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211583790498 : Closed e1211583790498 ∧ code e1211583790498 = 5609630301602 := by decide
theorem cert_e1211583790498 : check e1211583790498 [[],[],[],[]] .chain = true := by decide
def e1211583790510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211583790510 : Closed e1211583790510 ∧ code e1211583790510 = 5609630301614 := by decide
theorem cert_e1211583790510 : check e1211583790510 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211583790522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211583790522 : Closed e1211583790522 ∧ code e1211583790522 = 5609630301626 := by decide
theorem cert_e1211583790522 : check e1211583790522 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211583790550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211583790550 : Closed e1211583790550 ∧ code e1211583790550 = 5609630301654 := by decide
private def t_e1211583790550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e1211583790550 : ¬ IsSelfInterpreter e1211583790550 :=
  wSource (t := t_e1211583790550) (replay_sound (ps := []) (t := e1211583790550) (by decide)) (by decide)
def e1211583790554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211583790554 : Closed e1211583790554 ∧ code e1211583790554 = 5609630301658 := by decide
private def t_e1211583790554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e1211583790554 : ¬ IsSelfInterpreter e1211583790554 :=
  wSource (t := t_e1211583790554) (replay_sound (ps := []) (t := e1211583790554) (by decide)) (by decide)
def e1211583792094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3))))))))
theorem wire_e1211583792094 : Closed e1211583792094 ∧ code e1211583792094 = 5609630303198 := by decide
theorem cert_e1211583792094 : check e1211583792094 [[],[],[],[]] .chain = true := by decide
def e1211583792118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1))))))))
theorem wire_e1211583792118 : Closed e1211583792118 ∧ code e1211583792118 = 5609630303222 := by decide
theorem cert_e1211583792118 : check e1211583792118 [[],[],[],[]] .chain = true := by decide
def e1211583793630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211583793630 : Closed e1211583793630 ∧ code e1211583793630 = 5609630304734 := by decide
theorem cert_e1211583793630 : check e1211583793630 [[],[],[],[]] .chain = true := by decide
def e1211583793654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211583793654 : Closed e1211583793654 ∧ code e1211583793654 = 5609630304758 := by decide
theorem cert_e1211583793654 : check e1211583793654 [[],[],[],[]] .chain = true := by decide
def e1211583794414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211583794414 : Closed e1211583794414 ∧ code e1211583794414 = 5609630305518 := by decide
theorem cert_e1211583794414 : check e1211583794414 [[],[],[],[]] .chain = true := by decide
def e1211583794422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211583794422 : Closed e1211583794422 ∧ code e1211583794422 = 5609630305526 := by decide
theorem cert_e1211583794422 : check e1211583794422 [[],[],[],[]] .chain = true := by decide
def e1211583794750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4)))))))))
theorem wire_e1211583794750 : Closed e1211583794750 ∧ code e1211583794750 = 5609630305854 := by decide
theorem cert_e1211583794750 : check e1211583794750 [[],[],[],[]] .chain = true := by decide
def e1211583794798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211583794798 : Closed e1211583794798 ∧ code e1211583794798 = 5609630305902 := by decide
theorem cert_e1211583794798 : check e1211583794798 [[],[],[],[]] .chain = true := by decide
def e1211583794810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211583794810 : Closed e1211583794810 ∧ code e1211583794810 = 5609630305914 := by decide
theorem cert_e1211583794810 : check e1211583794810 [[],[],[],[]] .chain = true := by decide
def e1211583794998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211583794998 : Closed e1211583794998 ∧ code e1211583794998 = 5609630306102 := by decide
theorem cert_e1211583794998 : check e1211583794998 [[],[],[],[]] .chain = true := by decide
def e1211583795002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211583795002 : Closed e1211583795002 ∧ code e1211583795002 = 5609630306106 := by decide
theorem cert_e1211583795002 : check e1211583795002 [[],[],[],[]] .chain = true := by decide
def e1211583795086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2)))))))))
theorem wire_e1211583795086 : Closed e1211583795086 ∧ code e1211583795086 = 5609630306190 := by decide
theorem cert_e1211583795086 : check e1211583795086 [[],[],[],[]] .chain = true := by decide
def e1211583797486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211583797486 : Closed e1211583797486 ∧ code e1211583797486 = 5609630308590 := by decide
theorem cert_e1211583797486 : check e1211583797486 [[],[],[],[]] .chain = true := by decide
def e1211583797494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211583797494 : Closed e1211583797494 ∧ code e1211583797494 = 5609630308598 := by decide
theorem cert_e1211583797494 : check e1211583797494 [[],[],[],[]] .chain = true := by decide
def e1211583798046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211583798046 : Closed e1211583798046 ∧ code e1211583798046 = 5609630309150 := by decide
theorem cert_e1211583798046 : check e1211583798046 [[],[],[],[]] .chain = true := by decide
def e1211583798158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211583798158 : Closed e1211583798158 ∧ code e1211583798158 = 5609630309262 := by decide
theorem cert_e1211583798158 : check e1211583798158 [[],[],[],[]] .chain = true := by decide
def e1211583798366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211583798366 : Closed e1211583798366 ∧ code e1211583798366 = 5609630309470 := by decide
theorem cert_e1211583798366 : check e1211583798366 [[],[],[],[]] .chain = true := by decide
def e1211583798382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211583798382 : Closed e1211583798382 ∧ code e1211583798382 = 5609630309486 := by decide
theorem cert_e1211583798382 : check e1211583798382 [[],[],[],[]] .chain = true := by decide
def e1211583798394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211583798394 : Closed e1211583798394 ∧ code e1211583798394 = 5609630309498 := by decide
theorem cert_e1211583798394 : check e1211583798394 [[],[],[],[]] .chain = true := by decide
def e1211583798558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211583798558 : Closed e1211583798558 ∧ code e1211583798558 = 5609630309662 := by decide
theorem cert_e1211583798558 : check e1211583798558 [[],[],[],[]] .chain = true := by decide
def e1211583798726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211583798726 : Closed e1211583798726 ∧ code e1211583798726 = 5609630309830 := by decide
theorem cert_e1211583798726 : check e1211583798726 [[],[],[],[]] .chain = true := by decide
def e1211583798750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e1211583798750 : Closed e1211583798750 ∧ code e1211583798750 = 5609630309854 := by decide
theorem cert_e1211583798750 : check e1211583798750 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211583798754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211583798754 : Closed e1211583798754 ∧ code e1211583798754 = 5609630309858 := by decide
theorem cert_e1211583798754 : check e1211583798754 [[],[],[],[]] .chain = true := by decide
def e1211583798766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e1211583798766 : Closed e1211583798766 ∧ code e1211583798766 = 5609630309870 := by decide
theorem cert_e1211583798766 : check e1211583798766 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211583798838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211583798838 : Closed e1211583798838 ∧ code e1211583798838 = 5609630309942 := by decide
theorem cert_e1211583798838 : check e1211583798838 [[],[],[],[]] .chain = true := by decide
def e1211583798842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211583798842 : Closed e1211583798842 ∧ code e1211583798842 = 5609630309946 := by decide
theorem cert_e1211583798842 : check e1211583798842 [[],[],[],[]] .chain = true := by decide
def e1211583798926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211583798926 : Closed e1211583798926 ∧ code e1211583798926 = 5609630310030 := by decide
theorem cert_e1211583798926 : check e1211583798926 [[],[],[],[]] .chain = true := by decide
def e1211583798982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211583798982 : Closed e1211583798982 ∧ code e1211583798982 = 5609630310086 := by decide
theorem cert_e1211583798982 : check e1211583798982 [[],[],[],[]] .chain = true := by decide
def e1211583799006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e1211583799006 : Closed e1211583799006 ∧ code e1211583799006 = 5609630310110 := by decide
theorem cert_e1211583799006 : check e1211583799006 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1211583799030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e1211583799030 : Closed e1211583799030 ∧ code e1211583799030 = 5609630310134 := by decide
theorem cert_e1211583799030 : check e1211583799030 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211583799062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211583799062 : Closed e1211583799062 ∧ code e1211583799062 = 5609630310166 := by decide
theorem cert_e1211583799062 : check e1211583799062 [[],[],[],[]] .chain = true := by decide
def e1211583799138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211583799138 : Closed e1211583799138 ∧ code e1211583799138 = 5609630310242 := by decide
theorem cert_e1211583799138 : check e1211583799138 [[],[],[],[]] .chain = true := by decide
def e1211583799150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e1211583799150 : Closed e1211583799150 ∧ code e1211583799150 = 5609630310254 := by decide
theorem cert_e1211583799150 : check e1211583799150 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211583799158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e1211583799158 : Closed e1211583799158 ∧ code e1211583799158 = 5609630310262 := by decide
theorem cert_e1211583799158 : check e1211583799158 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211583801118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211583801118 : Closed e1211583801118 ∧ code e1211583801118 = 5609630312222 := by decide
theorem cert_e1211583801118 : check e1211583801118 [[],[],[],[]] .chain = true := by decide
def e1211583801230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211583801230 : Closed e1211583801230 ∧ code e1211583801230 = 5609630312334 := by decide
theorem cert_e1211583801230 : check e1211583801230 [[],[],[],[]] .chain = true := by decide
def e1211583803518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5))))))))))
theorem wire_e1211583803518 : Closed e1211583803518 ∧ code e1211583803518 = 5609630314622 := by decide
theorem cert_e1211583803518 : check e1211583803518 [[],[],[],[]] .chain = true := by decide
def e1211583804190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211583804190 : Closed e1211583804190 ∧ code e1211583804190 = 5609630315294 := by decide
theorem cert_e1211583804190 : check e1211583804190 [[],[],[],[]] .chain = true := by decide
def e1211583804358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211583804358 : Closed e1211583804358 ∧ code e1211583804358 = 5609630315462 := by decide
theorem cert_e1211583804358 : check e1211583804358 [[],[],[],[]] .chain = true := by decide
def e1211583804382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211583804382 : Closed e1211583804382 ∧ code e1211583804382 = 5609630315486 := by decide
theorem cert_e1211583804382 : check e1211583804382 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211583804386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211583804386 : Closed e1211583804386 ∧ code e1211583804386 = 5609630315490 := by decide
theorem cert_e1211583804386 : check e1211583804386 [[],[],[],[]] .chain = true := by decide
def e1211583804398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211583804398 : Closed e1211583804398 ∧ code e1211583804398 = 5609630315502 := by decide
theorem cert_e1211583804398 : check e1211583804398 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211583805838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211583805838 : Closed e1211583805838 ∧ code e1211583805838 = 5609630316942 := by decide
theorem cert_e1211583805838 : check e1211583805838 [[],[],[],[]] .chain = true := by decide
def e1211583805894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211583805894 : Closed e1211583805894 ∧ code e1211583805894 = 5609630316998 := by decide
theorem cert_e1211583805894 : check e1211583805894 [[],[],[],[]] .chain = true := by decide
def e1211583805918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211583805918 : Closed e1211583805918 ∧ code e1211583805918 = 5609630317022 := by decide
theorem cert_e1211583805918 : check e1211583805918 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583805942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211583805942 : Closed e1211583805942 ∧ code e1211583805942 = 5609630317046 := by decide
theorem cert_e1211583805942 : check e1211583805942 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211583806494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211583806494 : Closed e1211583806494 ∧ code e1211583806494 = 5609630317598 := by decide
theorem cert_e1211583806494 : check e1211583806494 [[],[],[],[]] .chain = true := by decide
def e1211583806690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211583806690 : Closed e1211583806690 ∧ code e1211583806690 = 5609630317794 := by decide
theorem cert_e1211583806690 : check e1211583806690 [[],[],[],[]] .chain = true := by decide
def e1211583806702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211583806702 : Closed e1211583806702 ∧ code e1211583806702 = 5609630317806 := by decide
theorem cert_e1211583806702 : check e1211583806702 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583806710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211583806710 : Closed e1211583806710 ∧ code e1211583806710 = 5609630317814 := by decide
theorem cert_e1211583806710 : check e1211583806710 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211583807966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e1211583807966 : Closed e1211583807966 ∧ code e1211583807966 = 5609630319070 := by decide
theorem cert_e1211583807966 : check e1211583807966 [[],[],[],[]] .chain = true := by decide
def e1211583807994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e1211583807994 : Closed e1211583807994 ∧ code e1211583807994 = 5609630319098 := by decide
theorem cert_e1211583807994 : check e1211583807994 [[],[],[],[]] .chain = true := by decide
def e1211583808734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211583808734 : Closed e1211583808734 ∧ code e1211583808734 = 5609630319838 := by decide
theorem cert_e1211583808734 : check e1211583808734 [[],[],[],[]] .chain = true := by decide
def e1211583808762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211583808762 : Closed e1211583808762 ∧ code e1211583808762 = 5609630319866 := by decide
theorem cert_e1211583808762 : check e1211583808762 [[],[],[],[]] .chain = true := by decide
end Blc.Floor42
