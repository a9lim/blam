import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209570256734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1209570256734 : Closed e1209570256734 ∧ code e1209570256734 = 5607616767838 := by decide
theorem cert_e1209570256734 : check e1209570256734 [[],[]] .smaller = true := by decide
def e1209570256750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1209570256750 : Closed e1209570256750 ∧ code e1209570256750 = 5607616767854 := by decide
theorem cert_e1209570256750 : check e1209570256750 [[],[]] .smaller = true := by decide
def e1209570256758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1209570256758 : Closed e1209570256758 ∧ code e1209570256758 = 5607616767862 := by decide
theorem cert_e1209570256758 : check e1209570256758 [[],[]] .smaller = true := by decide
def e1209570256762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1209570256762 : Closed e1209570256762 ∧ code e1209570256762 = 5607616767866 := by decide
theorem cert_e1209570256762 : check e1209570256762 [[],[]] .smaller = true := by decide
def e1209570256822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1209570256822 : Closed e1209570256822 ∧ code e1209570256822 = 5607616767926 := by decide
theorem cert_e1209570256822 : check e1209570256822 [[],[]] .smaller = true := by decide
def e1209570256854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1209570256854 : Closed e1209570256854 ∧ code e1209570256854 = 5607616767958 := by decide
theorem cert_e1209570256854 : check e1209570256854 [[],[]] .smaller = true := by decide
def e1209570256858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1209570256858 : Closed e1209570256858 ∧ code e1209570256858 = 5607616767962 := by decide
theorem cert_e1209570256858 : check e1209570256858 [[],[]] .smaller = true := by decide
def e1209570257374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209570257374 : Closed e1209570257374 ∧ code e1209570257374 = 5607616768478 := by decide
theorem cert_e1209570257374 : check e1209570257374 [[],[]] .smaller = true := by decide
def e1209570257398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209570257398 : Closed e1209570257398 ∧ code e1209570257398 = 5607616768502 := by decide
theorem cert_e1209570257398 : check e1209570257398 [[],[]] .smaller = true := by decide
def e1209570258142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209570258142 : Closed e1209570258142 ∧ code e1209570258142 = 5607616769246 := by decide
theorem cert_e1209570258142 : check e1209570258142 [[],[]] .smaller = true := by decide
def e1209570258158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209570258158 : Closed e1209570258158 ∧ code e1209570258158 = 5607616769262 := by decide
theorem cert_e1209570258158 : check e1209570258158 [[],[]] .smaller = true := by decide
def e1209570258166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209570258166 : Closed e1209570258166 ∧ code e1209570258166 = 5607616769270 := by decide
theorem cert_e1209570258166 : check e1209570258166 [[],[]] .smaller = true := by decide
def e1209570258170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209570258170 : Closed e1209570258170 ∧ code e1209570258170 = 5607616769274 := by decide
theorem cert_e1209570258170 : check e1209570258170 [[],[]] .smaller = true := by decide
def e1209570258550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209570258550 : Closed e1209570258550 ∧ code e1209570258550 = 5607616769654 := by decide
theorem cert_e1209570258550 : check e1209570258550 [[],[]] .smaller = true := by decide
def e1209570258742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209570258742 : Closed e1209570258742 ∧ code e1209570258742 = 5607616769846 := by decide
theorem cert_e1209570258742 : check e1209570258742 [[],[]] .smaller = true := by decide
def e1209570258746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209570258746 : Closed e1209570258746 ∧ code e1209570258746 = 5607616769850 := by decide
theorem cert_e1209570258746 : check e1209570258746 [[],[]] .smaller = true := by decide
def e1209570259806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1209570259806 : Closed e1209570259806 ∧ code e1209570259806 = 5607616770910 := by decide
theorem cert_e1209570259806 : check e1209570259806 [[],[]] .smaller = true := by decide
def e1209570259822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1209570259822 : Closed e1209570259822 ∧ code e1209570259822 = 5607616770926 := by decide
theorem cert_e1209570259822 : check e1209570259822 [[],[]] .smaller = true := by decide
def e1209570259830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1209570259830 : Closed e1209570259830 ∧ code e1209570259830 = 5607616770934 := by decide
theorem cert_e1209570259830 : check e1209570259830 [[],[]] .smaller = true := by decide
def e1209570259834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1209570259834 : Closed e1209570259834 ∧ code e1209570259834 = 5607616770938 := by decide
theorem cert_e1209570259834 : check e1209570259834 [[],[]] .smaller = true := by decide
def e1209570259886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1209570259886 : Closed e1209570259886 ∧ code e1209570259886 = 5607616770990 := by decide
theorem cert_e1209570259886 : check e1209570259886 [[],[]] .smaller = true := by decide
def e1209570259898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1209570259898 : Closed e1209570259898 ∧ code e1209570259898 = 5607616771002 := by decide
theorem cert_e1209570259898 : check e1209570259898 [[],[]] .smaller = true := by decide
def e1209570259926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1209570259926 : Closed e1209570259926 ∧ code e1209570259926 = 5607616771030 := by decide
theorem cert_e1209570259926 : check e1209570259926 [[],[]] .smaller = true := by decide
def e1209570259930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1209570259930 : Closed e1209570259930 ∧ code e1209570259930 = 5607616771034 := by decide
theorem cert_e1209570259930 : check e1209570259930 [[],[]] .smaller = true := by decide
def e1209570259946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1209570259946 : Closed e1209570259946 ∧ code e1209570259946 = 5607616771050 := by decide
theorem cert_e1209570259946 : check e1209570259946 [[],[]] .smaller = true := by decide
def e1209570260190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209570260190 : Closed e1209570260190 ∧ code e1209570260190 = 5607616771294 := by decide
theorem cert_e1209570260190 : check e1209570260190 [[],[]] .smaller = true := by decide
def e1209570260206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209570260206 : Closed e1209570260206 ∧ code e1209570260206 = 5607616771310 := by decide
theorem cert_e1209570260206 : check e1209570260206 [[],[]] .smaller = true := by decide
def e1209570260214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209570260214 : Closed e1209570260214 ∧ code e1209570260214 = 5607616771318 := by decide
theorem cert_e1209570260214 : check e1209570260214 [[],[]] .smaller = true := by decide
def e1209570260218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209570260218 : Closed e1209570260218 ∧ code e1209570260218 = 5607616771322 := by decide
theorem cert_e1209570260218 : check e1209570260218 [[],[]] .smaller = true := by decide
def e1209570260590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209570260590 : Closed e1209570260590 ∧ code e1209570260590 = 5607616771694 := by decide
theorem cert_e1209570260590 : check e1209570260590 [[],[]] .smaller = true := by decide
def e1209570260602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209570260602 : Closed e1209570260602 ∧ code e1209570260602 = 5607616771706 := by decide
theorem cert_e1209570260602 : check e1209570260602 [[],[]] .smaller = true := by decide
def e1209570260790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209570260790 : Closed e1209570260790 ∧ code e1209570260790 = 5607616771894 := by decide
theorem cert_e1209570260790 : check e1209570260790 [[],[]] .smaller = true := by decide
def e1209570260794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209570260794 : Closed e1209570260794 ∧ code e1209570260794 = 5607616771898 := by decide
theorem cert_e1209570260794 : check e1209570260794 [[],[]] .smaller = true := by decide
def e1209570260890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209570260890 : Closed e1209570260890 ∧ code e1209570260890 = 5607616771994 := by decide
theorem cert_e1209570260890 : check e1209570260890 [[],[]] .smaller = true := by decide
def e1209570261430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1209570261430 : Closed e1209570261430 ∧ code e1209570261430 = 5607616772534 := by decide
theorem cert_e1209570261430 : check e1209570261430 [[],[]] .smaller = true := by decide
def e1209570261462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1209570261462 : Closed e1209570261462 ∧ code e1209570261462 = 5607616772566 := by decide
theorem cert_e1209570261462 : check e1209570261462 [[],[]] .smaller = true := by decide
def e1209570261466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1209570261466 : Closed e1209570261466 ∧ code e1209570261466 = 5607616772570 := by decide
theorem cert_e1209570261466 : check e1209570261466 [[],[]] .smaller = true := by decide
def e1209570261622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209570261622 : Closed e1209570261622 ∧ code e1209570261622 = 5607616772726 := by decide
theorem cert_e1209570261622 : check e1209570261622 [[],[]] .smaller = true := by decide
def e1209570261814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209570261814 : Closed e1209570261814 ∧ code e1209570261814 = 5607616772918 := by decide
theorem cert_e1209570261814 : check e1209570261814 [[],[]] .smaller = true := by decide
def e1209570261818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209570261818 : Closed e1209570261818 ∧ code e1209570261818 = 5607616772922 := by decide
theorem cert_e1209570261818 : check e1209570261818 [[],[]] .smaller = true := by decide
def e1209570262230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1209570262230 : Closed e1209570262230 ∧ code e1209570262230 = 5607616773334 := by decide
theorem cert_e1209570262230 : check e1209570262230 [[],[]] .smaller = true := by decide
def e1209570262234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1209570262234 : Closed e1209570262234 ∧ code e1209570262234 = 5607616773338 := by decide
theorem cert_e1209570262234 : check e1209570262234 [[],[]] .smaller = true := by decide
def e1209570262250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1209570262250 : Closed e1209570262250 ∧ code e1209570262250 = 5607616773354 := by decide
theorem cert_e1209570262250 : check e1209570262250 [[],[]] .smaller = true := by decide
def e1209570262326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209570262326 : Closed e1209570262326 ∧ code e1209570262326 = 5607616773430 := by decide
theorem cert_e1209570262326 : check e1209570262326 [[],[]] .smaller = true := by decide
def e1209570262330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209570262330 : Closed e1209570262330 ∧ code e1209570262330 = 5607616773434 := by decide
theorem cert_e1209570262330 : check e1209570262330 [[],[]] .smaller = true := by decide
def e1209570262426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209570262426 : Closed e1209570262426 ∧ code e1209570262426 = 5607616773530 := by decide
theorem cert_e1209570262426 : check e1209570262426 [[],[]] .smaller = true := by decide
def e1209570268894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1209570268894 : Closed e1209570268894 ∧ code e1209570268894 = 5607616779998 := by decide
theorem cert_e1209570268894 : check e1209570268894 [[],[]] .smaller = true := by decide
def e1209570268918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1209570268918 : Closed e1209570268918 ∧ code e1209570268918 = 5607616780022 := by decide
theorem cert_e1209570268918 : check e1209570268918 [[],[]] .smaller = true := by decide
def e1209570269022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1209570269022 : Closed e1209570269022 ∧ code e1209570269022 = 5607616780126 := by decide
theorem cert_e1209570269022 : check e1209570269022 [[],[]] .smaller = true := by decide
def e1209570269038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1209570269038 : Closed e1209570269038 ∧ code e1209570269038 = 5607616780142 := by decide
theorem cert_e1209570269038 : check e1209570269038 [[],[]] .smaller = true := by decide
def e1209570269046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1209570269046 : Closed e1209570269046 ∧ code e1209570269046 = 5607616780150 := by decide
theorem cert_e1209570269046 : check e1209570269046 [[],[]] .smaller = true := by decide
def e1209570269050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1209570269050 : Closed e1209570269050 ∧ code e1209570269050 = 5607616780154 := by decide
theorem cert_e1209570269050 : check e1209570269050 [[],[]] .smaller = true := by decide
def e1209570269110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1209570269110 : Closed e1209570269110 ∧ code e1209570269110 = 5607616780214 := by decide
theorem cert_e1209570269110 : check e1209570269110 [[],[]] .smaller = true := by decide
def e1209570269142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1209570269142 : Closed e1209570269142 ∧ code e1209570269142 = 5607616780246 := by decide
theorem cert_e1209570269142 : check e1209570269142 [[],[]] .smaller = true := by decide
def e1209570269146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1209570269146 : Closed e1209570269146 ∧ code e1209570269146 = 5607616780250 := by decide
theorem cert_e1209570269146 : check e1209570269146 [[],[]] .smaller = true := by decide
def e1209570269662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1209570269662 : Closed e1209570269662 ∧ code e1209570269662 = 5607616780766 := by decide
theorem cert_e1209570269662 : check e1209570269662 [[],[]] .smaller = true := by decide
def e1209570269686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1209570269686 : Closed e1209570269686 ∧ code e1209570269686 = 5607616780790 := by decide
theorem cert_e1209570269686 : check e1209570269686 [[],[]] .smaller = true := by decide
def e1209570270430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1209570270430 : Closed e1209570270430 ∧ code e1209570270430 = 5607616781534 := by decide
theorem cert_e1209570270430 : check e1209570270430 [[],[]] .smaller = true := by decide
def e1209570270446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1209570270446 : Closed e1209570270446 ∧ code e1209570270446 = 5607616781550 := by decide
theorem cert_e1209570270446 : check e1209570270446 [[],[]] .smaller = true := by decide
def e1209570270454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1209570270454 : Closed e1209570270454 ∧ code e1209570270454 = 5607616781558 := by decide
theorem cert_e1209570270454 : check e1209570270454 [[],[]] .smaller = true := by decide
def e1209570270458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1209570270458 : Closed e1209570270458 ∧ code e1209570270458 = 5607616781562 := by decide
theorem cert_e1209570270458 : check e1209570270458 [[],[]] .smaller = true := by decide
def e1209570270838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1209570270838 : Closed e1209570270838 ∧ code e1209570270838 = 5607616781942 := by decide
theorem cert_e1209570270838 : check e1209570270838 [[],[]] .smaller = true := by decide
def e1209570271030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570271030 : Closed e1209570271030 ∧ code e1209570271030 = 5607616782134 := by decide
theorem cert_e1209570271030 : check e1209570271030 [[],[]] .smaller = true := by decide
def e1209570271034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570271034 : Closed e1209570271034 ∧ code e1209570271034 = 5607616782138 := by decide
theorem cert_e1209570271034 : check e1209570271034 [[],[]] .smaller = true := by decide
def e1209570282334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1209570282334 : Closed e1209570282334 ∧ code e1209570282334 = 5607616793438 := by decide
theorem cert_e1209570282334 : check e1209570282334 [[],[]] .smaller = true := by decide
def e1209570282350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1209570282350 : Closed e1209570282350 ∧ code e1209570282350 = 5607616793454 := by decide
theorem cert_e1209570282350 : check e1209570282350 [[],[]] .smaller = true := by decide
def e1209570282358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1209570282358 : Closed e1209570282358 ∧ code e1209570282358 = 5607616793462 := by decide
theorem cert_e1209570282358 : check e1209570282358 [[],[]] .smaller = true := by decide
def e1209570282362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1209570282362 : Closed e1209570282362 ∧ code e1209570282362 = 5607616793466 := by decide
theorem cert_e1209570282362 : check e1209570282362 [[],[]] .smaller = true := by decide
def e1209570282414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1209570282414 : Closed e1209570282414 ∧ code e1209570282414 = 5607616793518 := by decide
theorem cert_e1209570282414 : check e1209570282414 [[],[]] .smaller = true := by decide
def e1209570282426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1209570282426 : Closed e1209570282426 ∧ code e1209570282426 = 5607616793530 := by decide
theorem cert_e1209570282426 : check e1209570282426 [[],[]] .smaller = true := by decide
def e1209570282454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1209570282454 : Closed e1209570282454 ∧ code e1209570282454 = 5607616793558 := by decide
theorem cert_e1209570282454 : check e1209570282454 [[],[]] .smaller = true := by decide
def e1209570282458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1209570282458 : Closed e1209570282458 ∧ code e1209570282458 = 5607616793562 := by decide
theorem cert_e1209570282458 : check e1209570282458 [[],[]] .smaller = true := by decide
def e1209570282474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1209570282474 : Closed e1209570282474 ∧ code e1209570282474 = 5607616793578 := by decide
theorem cert_e1209570282474 : check e1209570282474 [[],[]] .smaller = true := by decide
def e1209570282718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1209570282718 : Closed e1209570282718 ∧ code e1209570282718 = 5607616793822 := by decide
theorem cert_e1209570282718 : check e1209570282718 [[],[]] .smaller = true := by decide
def e1209570282734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1209570282734 : Closed e1209570282734 ∧ code e1209570282734 = 5607616793838 := by decide
theorem cert_e1209570282734 : check e1209570282734 [[],[]] .smaller = true := by decide
def e1209570282742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1209570282742 : Closed e1209570282742 ∧ code e1209570282742 = 5607616793846 := by decide
theorem cert_e1209570282742 : check e1209570282742 [[],[]] .smaller = true := by decide
def e1209570282746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1209570282746 : Closed e1209570282746 ∧ code e1209570282746 = 5607616793850 := by decide
theorem cert_e1209570282746 : check e1209570282746 [[],[]] .smaller = true := by decide
def e1209570283118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1209570283118 : Closed e1209570283118 ∧ code e1209570283118 = 5607616794222 := by decide
theorem cert_e1209570283118 : check e1209570283118 [[],[]] .smaller = true := by decide
def e1209570283130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1209570283130 : Closed e1209570283130 ∧ code e1209570283130 = 5607616794234 := by decide
theorem cert_e1209570283130 : check e1209570283130 [[],[]] .smaller = true := by decide
def e1209570283318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570283318 : Closed e1209570283318 ∧ code e1209570283318 = 5607616794422 := by decide
theorem cert_e1209570283318 : check e1209570283318 [[],[]] .smaller = true := by decide
def e1209570283322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570283322 : Closed e1209570283322 ∧ code e1209570283322 = 5607616794426 := by decide
theorem cert_e1209570283322 : check e1209570283322 [[],[]] .smaller = true := by decide
def e1209570283418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1209570283418 : Closed e1209570283418 ∧ code e1209570283418 = 5607616794522 := by decide
theorem cert_e1209570283418 : check e1209570283418 [[],[]] .smaller = true := by decide
def e1209570289078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1209570289078 : Closed e1209570289078 ∧ code e1209570289078 = 5607616800182 := by decide
theorem cert_e1209570289078 : check e1209570289078 [[],[]] .smaller = true := by decide
def e1209570289110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1209570289110 : Closed e1209570289110 ∧ code e1209570289110 = 5607616800214 := by decide
theorem cert_e1209570289110 : check e1209570289110 [[],[]] .smaller = true := by decide
def e1209570289114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1209570289114 : Closed e1209570289114 ∧ code e1209570289114 = 5607616800218 := by decide
theorem cert_e1209570289114 : check e1209570289114 [[],[]] .smaller = true := by decide
def e1209570289270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1209570289270 : Closed e1209570289270 ∧ code e1209570289270 = 5607616800374 := by decide
theorem cert_e1209570289270 : check e1209570289270 [[],[]] .smaller = true := by decide
def e1209570289462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570289462 : Closed e1209570289462 ∧ code e1209570289462 = 5607616800566 := by decide
theorem cert_e1209570289462 : check e1209570289462 [[],[]] .smaller = true := by decide
def e1209570289466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570289466 : Closed e1209570289466 ∧ code e1209570289466 = 5607616800570 := by decide
theorem cert_e1209570289466 : check e1209570289466 [[],[]] .smaller = true := by decide
def e1209570292438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1209570292438 : Closed e1209570292438 ∧ code e1209570292438 = 5607616803542 := by decide
theorem cert_e1209570292438 : check e1209570292438 [[],[]] .smaller = true := by decide
def e1209570292442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1209570292442 : Closed e1209570292442 ∧ code e1209570292442 = 5607616803546 := by decide
theorem cert_e1209570292442 : check e1209570292442 [[],[]] .smaller = true := by decide
def e1209570292458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1209570292458 : Closed e1209570292458 ∧ code e1209570292458 = 5607616803562 := by decide
theorem cert_e1209570292458 : check e1209570292458 [[],[]] .smaller = true := by decide
def e1209570292534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1209570292534 : Closed e1209570292534 ∧ code e1209570292534 = 5607616803638 := by decide
theorem cert_e1209570292534 : check e1209570292534 [[],[]] .smaller = true := by decide
def e1209570292538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1209570292538 : Closed e1209570292538 ∧ code e1209570292538 = 5607616803642 := by decide
theorem cert_e1209570292538 : check e1209570292538 [[],[]] .smaller = true := by decide
def e1209570292634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1209570292634 : Closed e1209570292634 ∧ code e1209570292634 = 5607616803738 := by decide
theorem cert_e1209570292634 : check e1209570292634 [[],[]] .smaller = true := by decide
def e1209570517870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1209570517870 : Closed e1209570517870 ∧ code e1209570517870 = 5607617028974 := by decide
theorem cert_e1209570517870 : check e1209570517870 [[],[]] .smaller = true := by decide
def e1209570517878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1209570517878 : Closed e1209570517878 ∧ code e1209570517878 = 5607617028982 := by decide
theorem cert_e1209570517878 : check e1209570517878 [[],[]] .smaller = true := by decide
def e1209570517934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1209570517934 : Closed e1209570517934 ∧ code e1209570517934 = 5607617029038 := by decide
theorem cert_e1209570517934 : check e1209570517934 [[],[]] .smaller = true := by decide
def e1209570517946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1209570517946 : Closed e1209570517946 ∧ code e1209570517946 = 5607617029050 := by decide
theorem cert_e1209570517946 : check e1209570517946 [[],[]] .smaller = true := by decide
def e1209570517974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1209570517974 : Closed e1209570517974 ∧ code e1209570517974 = 5607617029078 := by decide
theorem cert_e1209570517974 : check e1209570517974 [[],[]] .smaller = true := by decide
def e1209570517978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1209570517978 : Closed e1209570517978 ∧ code e1209570517978 = 5607617029082 := by decide
theorem cert_e1209570517978 : check e1209570517978 [[],[]] .smaller = true := by decide
def e1209570519278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209570519278 : Closed e1209570519278 ∧ code e1209570519278 = 5607617030382 := by decide
theorem cert_e1209570519278 : check e1209570519278 [[],[]] .smaller = true := by decide
def e1209570519286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209570519286 : Closed e1209570519286 ∧ code e1209570519286 = 5607617030390 := by decide
theorem cert_e1209570519286 : check e1209570519286 [[],[]] .smaller = true := by decide
def e1209570519838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209570519838 : Closed e1209570519838 ∧ code e1209570519838 = 5607617030942 := by decide
theorem cert_e1209570519838 : check e1209570519838 [[],[]] .smaller = true := by decide
def e1209570519950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209570519950 : Closed e1209570519950 ∧ code e1209570519950 = 5607617031054 := by decide
theorem cert_e1209570519950 : check e1209570519950 [[],[]] .smaller = true := by decide
def e1209570520174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209570520174 : Closed e1209570520174 ∧ code e1209570520174 = 5607617031278 := by decide
theorem cert_e1209570520174 : check e1209570520174 [[],[]] .smaller = true := by decide
def e1209570520186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209570520186 : Closed e1209570520186 ∧ code e1209570520186 = 5607617031290 := by decide
theorem cert_e1209570520186 : check e1209570520186 [[],[]] .smaller = true := by decide
def e1209570520350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209570520350 : Closed e1209570520350 ∧ code e1209570520350 = 5607617031454 := by decide
theorem cert_e1209570520350 : check e1209570520350 [[],[]] .smaller = true := by decide
def e1209570520518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209570520518 : Closed e1209570520518 ∧ code e1209570520518 = 5607617031622 := by decide
theorem cert_e1209570520518 : check e1209570520518 [[],[]] .smaller = true := by decide
def e1209570520630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209570520630 : Closed e1209570520630 ∧ code e1209570520630 = 5607617031734 := by decide
theorem cert_e1209570520630 : check e1209570520630 [[],[]] .smaller = true := by decide
def e1209570520634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209570520634 : Closed e1209570520634 ∧ code e1209570520634 = 5607617031738 := by decide
theorem cert_e1209570520634 : check e1209570520634 [[],[]] .smaller = true := by decide
def e1209570520718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209570520718 : Closed e1209570520718 ∧ code e1209570520718 = 5607617031822 := by decide
theorem cert_e1209570520718 : check e1209570520718 [[],[]] .smaller = true := by decide
def e1209570520774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209570520774 : Closed e1209570520774 ∧ code e1209570520774 = 5607617031878 := by decide
theorem cert_e1209570520774 : check e1209570520774 [[],[]] .smaller = true := by decide
def e1209570521518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1209570521518 : Closed e1209570521518 ∧ code e1209570521518 = 5607617032622 := by decide
theorem cert_e1209570521518 : check e1209570521518 [[],[]] .smaller = true := by decide
def e1209570521530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1209570521530 : Closed e1209570521530 ∧ code e1209570521530 = 5607617032634 := by decide
theorem cert_e1209570521530 : check e1209570521530 [[],[]] .smaller = true := by decide
def e1209570521578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1209570521578 : Closed e1209570521578 ∧ code e1209570521578 = 5607617032682 := by decide
theorem cert_e1209570521578 : check e1209570521578 [[],[]] .smaller = true := by decide
def e1209570522222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209570522222 : Closed e1209570522222 ∧ code e1209570522222 = 5607617033326 := by decide
theorem cert_e1209570522222 : check e1209570522222 [[],[]] .smaller = true := by decide
def e1209570522234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209570522234 : Closed e1209570522234 ∧ code e1209570522234 = 5607617033338 := by decide
theorem cert_e1209570522234 : check e1209570522234 [[],[]] .smaller = true := by decide
def e1209570522398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209570522398 : Closed e1209570522398 ∧ code e1209570522398 = 5607617033502 := by decide
theorem cert_e1209570522398 : check e1209570522398 [[],[]] .smaller = true := by decide
def e1209570522566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209570522566 : Closed e1209570522566 ∧ code e1209570522566 = 5607617033670 := by decide
theorem cert_e1209570522566 : check e1209570522566 [[],[]] .smaller = true := by decide
def e1209570522906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1209570522906 : Closed e1209570522906 ∧ code e1209570522906 = 5607617034010 := by decide
theorem cert_e1209570522906 : check e1209570522906 [[],[]] .smaller = true := by decide
def e1209570522950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1209570522950 : Closed e1209570522950 ∧ code e1209570522950 = 5607617034054 := by decide
theorem cert_e1209570522950 : check e1209570522950 [[],[]] .smaller = true := by decide
def e1209570523350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1209570523350 : Closed e1209570523350 ∧ code e1209570523350 = 5607617034454 := by decide
theorem cert_e1209570523350 : check e1209570523350 [[],[]] .smaller = true := by decide
def e1209570523354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1209570523354 : Closed e1209570523354 ∧ code e1209570523354 = 5607617034458 := by decide
theorem cert_e1209570523354 : check e1209570523354 [[],[]] .smaller = true := by decide
def e1209570523370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1209570523370 : Closed e1209570523370 ∧ code e1209570523370 = 5607617034474 := by decide
theorem cert_e1209570523370 : check e1209570523370 [[],[]] .smaller = true := by decide
def e1209570523702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209570523702 : Closed e1209570523702 ∧ code e1209570523702 = 5607617034806 := by decide
theorem cert_e1209570523702 : check e1209570523702 [[],[]] .smaller = true := by decide
def e1209570523706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209570523706 : Closed e1209570523706 ∧ code e1209570523706 = 5607617034810 := by decide
theorem cert_e1209570523706 : check e1209570523706 [[],[]] .smaller = true := by decide
def e1209570523790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209570523790 : Closed e1209570523790 ∧ code e1209570523790 = 5607617034894 := by decide
theorem cert_e1209570523790 : check e1209570523790 [[],[]] .smaller = true := by decide
def e1209570523846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209570523846 : Closed e1209570523846 ∧ code e1209570523846 = 5607617034950 := by decide
theorem cert_e1209570523846 : check e1209570523846 [[],[]] .smaller = true := by decide
def e1209570523930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1209570523930 : Closed e1209570523930 ∧ code e1209570523930 = 5607617035034 := by decide
theorem cert_e1209570523930 : check e1209570523930 [[],[]] .smaller = true := by decide
def e1209570523974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1209570523974 : Closed e1209570523974 ∧ code e1209570523974 = 5607617035078 := by decide
theorem cert_e1209570523974 : check e1209570523974 [[],[]] .smaller = true := by decide
def e1209570528494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1209570528494 : Closed e1209570528494 ∧ code e1209570528494 = 5607617039598 := by decide
theorem cert_e1209570528494 : check e1209570528494 [[],[]] .smaller = true := by decide
def e1209570528502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1209570528502 : Closed e1209570528502 ∧ code e1209570528502 = 5607617039606 := by decide
theorem cert_e1209570528502 : check e1209570528502 [[],[]] .smaller = true := by decide
def e1209570528878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1209570528878 : Closed e1209570528878 ∧ code e1209570528878 = 5607617039982 := by decide
theorem cert_e1209570528878 : check e1209570528878 [[],[]] .smaller = true := by decide
def e1209570528890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1209570528890 : Closed e1209570528890 ∧ code e1209570528890 = 5607617039994 := by decide
theorem cert_e1209570528890 : check e1209570528890 [[],[]] .smaller = true := by decide
def e1209570529078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1209570529078 : Closed e1209570529078 ∧ code e1209570529078 = 5607617040182 := by decide
theorem cert_e1209570529078 : check e1209570529078 [[],[]] .smaller = true := by decide
def e1209570529082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1209570529082 : Closed e1209570529082 ∧ code e1209570529082 = 5607617040186 := by decide
theorem cert_e1209570529082 : check e1209570529082 [[],[]] .smaller = true := by decide
def e1209570531566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1209570531566 : Closed e1209570531566 ∧ code e1209570531566 = 5607617042670 := by decide
theorem cert_e1209570531566 : check e1209570531566 [[],[]] .smaller = true := by decide
def e1209570531574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1209570531574 : Closed e1209570531574 ∧ code e1209570531574 = 5607617042678 := by decide
theorem cert_e1209570531574 : check e1209570531574 [[],[]] .smaller = true := by decide
def e1209570532126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1209570532126 : Closed e1209570532126 ∧ code e1209570532126 = 5607617043230 := by decide
theorem cert_e1209570532126 : check e1209570532126 [[],[]] .smaller = true := by decide
def e1209570532238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1209570532238 : Closed e1209570532238 ∧ code e1209570532238 = 5607617043342 := by decide
theorem cert_e1209570532238 : check e1209570532238 [[],[]] .smaller = true := by decide
def e1209570532462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1209570532462 : Closed e1209570532462 ∧ code e1209570532462 = 5607617043566 := by decide
theorem cert_e1209570532462 : check e1209570532462 [[],[]] .smaller = true := by decide
def e1209570532474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1209570532474 : Closed e1209570532474 ∧ code e1209570532474 = 5607617043578 := by decide
theorem cert_e1209570532474 : check e1209570532474 [[],[]] .smaller = true := by decide
def e1209570532638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1209570532638 : Closed e1209570532638 ∧ code e1209570532638 = 5607617043742 := by decide
theorem cert_e1209570532638 : check e1209570532638 [[],[]] .smaller = true := by decide
def e1209570532806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1209570532806 : Closed e1209570532806 ∧ code e1209570532806 = 5607617043910 := by decide
theorem cert_e1209570532806 : check e1209570532806 [[],[]] .smaller = true := by decide
def e1209570532918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1209570532918 : Closed e1209570532918 ∧ code e1209570532918 = 5607617044022 := by decide
theorem cert_e1209570532918 : check e1209570532918 [[],[]] .smaller = true := by decide
def e1209570532922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1209570532922 : Closed e1209570532922 ∧ code e1209570532922 = 5607617044026 := by decide
theorem cert_e1209570532922 : check e1209570532922 [[],[]] .smaller = true := by decide
def e1209570533006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1209570533006 : Closed e1209570533006 ∧ code e1209570533006 = 5607617044110 := by decide
theorem cert_e1209570533006 : check e1209570533006 [[],[]] .smaller = true := by decide
def e1209570533062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1209570533062 : Closed e1209570533062 ∧ code e1209570533062 = 5607617044166 := by decide
theorem cert_e1209570533062 : check e1209570533062 [[],[]] .smaller = true := by decide
def e1209570535198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209570535198 : Closed e1209570535198 ∧ code e1209570535198 = 5607617046302 := by decide
theorem cert_e1209570535198 : check e1209570535198 [[],[]] .smaller = true := by decide
def e1209570535310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209570535310 : Closed e1209570535310 ∧ code e1209570535310 = 5607617046414 := by decide
theorem cert_e1209570535310 : check e1209570535310 [[],[]] .smaller = true := by decide
def e1209570538270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209570538270 : Closed e1209570538270 ∧ code e1209570538270 = 5607617049374 := by decide
theorem cert_e1209570538270 : check e1209570538270 [[],[]] .smaller = true := by decide
def e1209570538438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209570538438 : Closed e1209570538438 ∧ code e1209570538438 = 5607617049542 := by decide
theorem cert_e1209570538438 : check e1209570538438 [[],[]] .smaller = true := by decide
def e1209570539918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209570539918 : Closed e1209570539918 ∧ code e1209570539918 = 5607617051022 := by decide
theorem cert_e1209570539918 : check e1209570539918 [[],[]] .smaller = true := by decide
def e1209570539974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209570539974 : Closed e1209570539974 ∧ code e1209570539974 = 5607617051078 := by decide
theorem cert_e1209570539974 : check e1209570539974 [[],[]] .smaller = true := by decide
def e1209570543214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1209570543214 : Closed e1209570543214 ∧ code e1209570543214 = 5607617054318 := by decide
theorem cert_e1209570543214 : check e1209570543214 [[],[]] .smaller = true := by decide
def e1209570543226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1209570543226 : Closed e1209570543226 ∧ code e1209570543226 = 5607617054330 := by decide
theorem cert_e1209570543226 : check e1209570543226 [[],[]] .smaller = true := by decide
def e1209570543514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1209570543514 : Closed e1209570543514 ∧ code e1209570543514 = 5607617054618 := by decide
theorem cert_e1209570543514 : check e1209570543514 [[],[]] .smaller = true := by decide
def e1209570544750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1209570544750 : Closed e1209570544750 ∧ code e1209570544750 = 5607617055854 := by decide
theorem cert_e1209570544750 : check e1209570544750 [[],[]] .smaller = true := by decide
def e1209570544762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1209570544762 : Closed e1209570544762 ∧ code e1209570544762 = 5607617055866 := by decide
theorem cert_e1209570544762 : check e1209570544762 [[],[]] .smaller = true := by decide
def e1209570544926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1209570544926 : Closed e1209570544926 ∧ code e1209570544926 = 5607617056030 := by decide
theorem cert_e1209570544926 : check e1209570544926 [[],[]] .smaller = true := by decide
end Blc.Floor42
